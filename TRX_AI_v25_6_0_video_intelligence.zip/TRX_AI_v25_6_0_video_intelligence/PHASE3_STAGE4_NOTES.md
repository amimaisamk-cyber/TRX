# فاز ۳ — مرحله ۴: Shadow Mode / مقایسه نمادین-عصبی / Dataset

**نسخه:** v25.4.9
**محدوده:** فقط Stage 4 از برنامه ۱۰ مرحله‌ای فاز ۳.

## آنچه پیاده شد

- `trx_ai/phase3/shadow.py`
  - پل read-only از مسیر زنده Conversation Intelligence به Phase 3.
  - استفاده از `ContextSnapshot` موجود؛ هیچ Context Manager موازی ساخته نشده.
  - اجرای Native Model فقط از طریق `Phase3InferenceService` موجود.
  - ثبت وضعیت symbolic و خروجی neural در یک رکورد Shadow.
  - fail-soft: هیچ خطای Shadow نباید turn را خراب کند.
- `trx_ai/phase3/evaluation_dataset.py`
  - ذخیره JSONL برای داده‌های ارزیابی Shadow.
  - I/O کاملاً fail-soft.
  - متن خام ذخیره نمی‌شود؛ `normalized_text` به‌عنوان نمونه ارزیابی ثبت می‌شود.
- `conversation_engine.py`
  - فقط یک hook اختیاری و lazy اضافه شده.
  - فقط وقتی `TRX_PHASE3_ENABLED=true` و mode برابر `shadow` باشد اجرا می‌شود.
  - خروجی Shadow هیچ کنترلی روی route یا response ندارد.
  - با config پیش‌فرض، رفتار قبلی دقیقاً حفظ می‌شود.

## محدودیت عمدی

مدل فعلی هنوز `task_heads.py` ندارد و بنابراین خروجی ساختاریافته‌ی neural برای
`topic/emotion/relation/...` تولید نمی‌کند. Stage 4 **نباید** برای این فیلدها
agreement جعلی بسازد. بنابراین مقایسه در این مرحله به‌صورت صادقانه
`raw_neural_output_only` ثبت می‌شود و `structured_agreement_score=None` است.
مقایسه ساختاریافته پس از ساخت task heads انجام خواهد شد.

## مسیر

```text
Live Conversation
  -> existing symbolic pipeline
  -> symbolic decision/state
  -> Stage-4 Shadow Hook (optional)
  -> ContextSnapshot (read-only)
  -> Feature Builder
  -> Inference Service
  -> Native Neural trial inference
  -> Shadow Record
  -> Evaluation JSONL

Live response/route <--- هیچ خروجی از Shadow برنمی‌گردد
```

## فعال‌سازی

پیش‌فرض همچنان خاموش است:

```text
TRX_PHASE3_ENABLED=false
TRX_PHASE3_MODE=disabled
```

برای اجرای Shadow صریحاً باید فعال شود:

```text
TRX_PHASE3_ENABLED=true
TRX_PHASE3_MODE=shadow
```

Dataset پیش‌فرض:

```text
logs/phase3_shadow_dataset.jsonl
```

و با `TRX_PHASE3_SHADOW_DATASET_PATH` قابل تغییر است.

## معیار پایان Stage 4

- اتصال read-only به Context زنده: انجام شد.
- اجرای inference در Shadow: انجام شد.
- route/response زنده تحت تأثیر neural نیست: حفظ شد.
- ثبت مقایسه symbolic/neural: انجام شد.
- dataset ارزیابی: انجام شد.
- task heads/fusion/production: عمداً انجام نشدند.
