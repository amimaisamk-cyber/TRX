# زیرساختِ Evaluation یکپارچه (`trx_ai/eval/`) — یادداشتِ فنی

پیاده‌سازیِ بندِ ۶ روادمپِ نسخه‌ی بعدی («Evaluation داخلی») — قدمِ اول
از شش‌گانه‌ی ارتقا، چون بدونِ یک عددِ پایه (baseline)، هیچ‌کدام از پنج
قدمِ بعدی (NLU غنی، Memory Context-Aware، Router Decision Engine،
Reflection قوی، Feedback عمومی) قابلِ سنجش نیست — دقیقاً طبقِ تأکیدِ
خودِ روادمپ: «نه با حس و حدس».

## چرا یک پکیجِ جدید (`trx_ai/eval/`) و نه فقط توسعه‌ی `nlu/eval/`؟
`trx_ai/nlu/eval/run_eval.py` از قبل وجود داشت اما فقط یک لایه را
می‌سنجید: دقتِ `IntentEngine.detect` (متن → نیت). ماژول‌هایِ جدید هر
کدام یک لایه‌ی دیگر را می‌سنجند که `run_eval.py` اصلاً نمی‌بیند:

| ماژول | چه چیزی را می‌سنجد | چرا لازم بود |
|---|---|---|
| `router_eval.py` | متن → نیت → **ابزار** | نیتِ درست تشخیص داده شود ولی `score_tools` ابزارِ اشتباه انتخاب کند — خطایی که `run_eval.py` نمی‌بیند |
| `memory_eval.py` | `resolve_pronoun` + `get_relevant_memory` | باگ‌هایی مثلِ «اکبر عبدی → کوروش کبیر» دقیقاً همین‌جا رخ می‌دهند، نه در NLU |
| `regression_eval.py` | تست‌هایِ رگرسیونِ ایمنی/پزشکی | شمارشِ عینیِ pass/fail، نه فقط «تست‌ها سبزند یا نه» |
| `report.py` | جمعِ سه‌تا + مقایسه با baseline | خروجیِ دقیقاً به‌فرمِ خواسته‌شده‌ی روادمپ |

`nlu/eval/run_eval.py` دست‌نخورده ماند (فقط یک تابعِ `evaluate() -> dict`
به آن اضافه شد تا `report.py` بتواند بدونِ parse‌کردنِ چاپ، به نتیجه‌ی
ساختاریافته دسترسی داشته باشد؛ خروجیِ خط‌فرمانیِ `main()` عیناً همان
قبلی است).

## طراحیِ دیتاست: بدونِ منبعِ سومِ حقیقت
هم `router_eval.py` و هم `nlu/eval/dataset.py` مستقیماً از
`IntentSpec.positive_examples`/`negative_examples` (که همین‌الان کنارِ
کلیدواژه‌هایِ هر نیت در `nlu/intents/*.py` هستند) دیتاست می‌سازند. یک
فایلِ جدایِ ۲۰-۳۰ جمله‌ای ساخته نشد — چون خودش می‌شد یک منبعِ سومِ
واگرایی (دقیقاً همان مشکلی که `registry.py` قبلاً برایِ
`INTENT_PATTERNS`/`ToolScorer.TOOLS` حل کرده بود).

## ایزوله‌سازیِ `memory_eval.py` از SQLiteِ واقعی
`MemoryEngine` به یک آبجکتِ `db` با سه متد نیاز دارد
(`get_profile`/`set_profile`/`get_profile_by_prefix`). به‌جایِ ساختنِ
یک `DatabaseManager` واقعی (فایلِ SQLite روی دیسک، کند برایِ CI)،
`_fakedb.FakeProfileDB` یک دیکشنریِ درون‌حافظه‌ای با همین سه متد است.
`vector_db=None` می‌ماند — یعنی این eval فقط لایه‌ی لغویِ
`MemoryCorrectionEngine.find` را می‌سنجد، نه جستجویِ برداری (که به
`sentence-transformers`/`chromadb` نیاز دارد و اختیاری است).

سناریوهایِ `memory_eval.py` دقیقاً همان جریانِ دوگامیِ واقعیِ برنامه را
شبیه‌سازی می‌کنند (نگاه کنید به `core_engine/turn_processor.finalize`):
اول `extract_topic_entity` + `add_message(topic=...)`، بعد در نوبتِ
بعدی `resolve_pronoun`. یکی از سناریوها عیناً همان مثالِ مستندشده در
`PRONOUN_MEMORY_BUGFIX_NOTES.md` است — تا اگر کسی بعداً pattern‌هایِ
`resolve_pronoun` را دوباره شل کند، بلافاصله در عدد افت دیده شود.

## `regression_eval.py`: چرا subprocess نه؟
اجرایِ pytest با subprocess به مسیرِ اجرا/محیطِ virtualenv حساس است و
کندتر است. در عوض از APIِ برنامه‌نویسیِ خودِ pytest
(`pytest.main(args, plugins=[...])`) با یک پلاگینِ سبک استفاده شده که
فقط `pytest_runtest_logreport` را گوش می‌دهد و pass/fail را می‌شمارد —
درون همان فرآیندِ پایتون، بدونِ وابستگیِ اضافه (`pytest-json-report` یا
مشابه). اگر pytest نصب نباشد (این پکیج، عمداً، فقط در
`requirements-dev.txt` است)، به‌جایِ کرش، یک نتیجه‌ی روشن برمی‌گردد و
بقیه‌ی گزارش (NLU/Memory/Router) بدونِ وقفه چاپ می‌شود.

فهرستِ فعلیِ `REGRESSION_TEST_FILES` فقط شاملِ
`tests/test_medical_safety_regression.py` است — تنها فایلی که صراحتاً
با این نام‌گذاری در پروژه وجود دارد. با اضافه‌شدنِ تست‌هایِ رگرسیونِ
جدید (مثلاً برایِ Memory/Router پس از ارتقاهایِ بعدی)، فقط باید به همین
تاپل اضافه شوند.

## `baseline.py` و `report.py`
`eval_baseline.json` (در ریشه‌ی پروژه) آخرین اسنپ‌شات را نگه می‌دارد.
اجرایِ:

```bash
python -m trx_ai.eval.report            # فقط گزارش، بدونِ تغییرِ baseline
python -m trx_ai.eval.report --save      # گزارش + جایگزینیِ baseline با نتیجه‌ی فعلی
```

خروجیِ نمونه (دقیقاً فرمِ خواسته‌شده‌ی روادمپ):

```
NLU accuracy       91% → 95% ↑
Memory precision   78% → 92% ↑
Router accuracy    87% → 94% ↑
Regressions (fail) 12 → 3 ↓   (از 41 تست)
```

پیشنهاد: `eval_baseline.json` در گیت commit شود تا هر PR بتواند عددِ
«قبل» را از رویِ خودِ فایل ببیند، و در CI با `--save` (یا بدونِ آن، صرفاً
برایِ گزارش) اجرا شود؛ کدِ خروجِ `report.py` وقتی رگرسیون/نقضِ
منفی/فایلِ گم‌شده باشد ۱ است، وگرنه ۰ — قابلِ استفاده به‌عنوانِ
شرطِ CI.

## یک یافته‌ی واقعی همین حالا (نه فرضی)
اجرایِ `router_eval.py` رویِ کدِ فعلی یک ناسازگاریِ واقعی پیدا کرد:
جمله‌ی «می‌خوام یکم درد دل کنم» (نمونه‌ی مثبتِ نیتِ `emotional_support`)
با زنجیره‌ی فعلیِ `detect → score_tools` به ابزارِ `medical` می‌رسد، نه
`emotional_support`. این دقیقاً از نوعِ خطایی است که `run_eval.py`
(چون فقط `intent` را چک می‌کند، نه ابزارِ نهایی) هرگز نشان نمی‌داد.
رفعِ این مورد خارج از محدوده‌ی همین قدم است (چون این قدم فقط
«اندازه‌گیری»، نه «اصلاح» است) — ولی حالا در `router_eval.py --failures`
همیشه قابلِ ردیابی است، و نامزدِ اولِ رفع در قدمِ بعدی (۳: Router →
Decision Engine) است.

## محدودیت‌هایِ شناخته‌شده (صادقانه)
- `router_eval.py` فقط نیت‌هایی را می‌سنجد که `ref_tool` دارند (یعنی
  ابزارِ مستقیم). نیت‌هایِ گفتگویی/ساختاری (smalltalk، دستوراتِ
  ساختاری) اینجا سنجیده نمی‌شوند — قدمِ ۳ (Decision Engine با
  خروجی‌هایِ `NO_TOOL`/`ASK_CLARIFICATION`/...) قرار است این خلأ را پر
  کند.
- `memory_eval.py` فقط لایه‌ی لغوی را می‌سنجد (بدونِ vector_db). وقتی
  قدمِ ۲ (`MemoryScore` ترکیبی) ساخته شود، این هارنس باید
  `topic_continuity`/`entity_continuity`/`temporal_relevance` را هم
  جداگانه بسنجد.
- `regression_eval.py` فقط یک فایل را می‌شناسد؛ عمداً کوچک شروع شده تا
  دروغِ «پوششِ کامل» نگوید.
