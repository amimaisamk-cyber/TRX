# v25.5.7 — Controlled Context Effect Experiment

سندِ این نسخه دقیقاً پیامِ امیر است («چهار تصمیمِ قفل‌شده» + سه سناریوی
مشخص). خطِ قرمزِ صریح: **کاملاً ADVISORY/SHADOW**، بدونِ اثر رویِ
`RoutingDecision`، بدونِ اثر رویِ پاسخِ نهاییِ کاربر، و `core.py` دست
نخورد.

## Current State
- v25.5.6: ثابت شد `pattern_context` واقعاً بینِ دو مکالمه‌یِ متفاوت،
  متفاوت است (Context Diff) -- اما هیچ مدرکی وجود نداشت که این تفاوت
  اصلاً *می‌تواند* رویِ خروجیِ یک مدلِ زبانی اثر بگذارد.

## Weakness
- بدونِ این آزمایش، Coordinator یک زیرساختِ کاملاً نظری می‌ماند: شاید
  دادهِ جمع‌شده اصلاً برایِ یک LLM بی‌معنی/بی‌اثر باشد و کلِ مسیر یک
  «توهمِ پیشرفتِ» بزرگ‌تر باشد -- دقیقاً همان خطری که سندِ اصلیِ پروژه
  (`TRX_AI_v25.4.0_Critical_Audit.txt`) از اول هشدار داده بود.

## Upgrade Goal
- سنجیدنِ اینکه آیا حذفِ عمدیِ `pattern_context` از یک context واقعی،
  باعثِ تفاوتِ قابلِ‌اندازه‌گیری در خروجیِ Local LLM می‌شود یا نه --
  با یک معیارِ عددیِ از‌پیش‌تعیین‌شده، رویِ چند سناریویِ ثابت.
- بدونِ اینکه حتی یک بیت از رفتارِ production عوض شود.

## Approach
طبقِ scopeِ نهاییِ خودِ امیر («v25.5.7 — CONTROLLED CONTEXT EFFECT
EXPERIMENT»):

1. **`trx_ai/nervous_system/experiments/context_effect_experiment.py`**
   (جدید): برایِ هر سناریو، یک `UnifiedConversationContext` واقعی
   می‌سازد (با روشن‌کردنِ موقتِ و امنِ `TRX_NERVOUS_SYSTEM_ENABLED`،
   دقیقاً هم‌الگو با خودِ تست‌ها)، سپس `ctx_reduced` را با
   `dataclasses.replace` می‌سازد (**فقط** `pattern_context["engine"]=None`،
   طبقِ خطِ قرمزِ «هیچ حذفِ دیگری»). هر دو context به یک بلوکِ متنیِ
   کوتاه در `system_prompt` تبدیل می‌شوند (تنها تفاوتِ مجاز بینِ FULL/
   REDUCED)؛ `user_text`/`history` با `assert` تضمین می‌شوند که کاملاً
   یکسان بمانند.
2. سه معیارِ عددیِ از‌پیش‌تعیین‌شده (`exact_match`, `similarity` از
   `difflib.SequenceMatcher`, `length_delta`) + یک آستانه‌یِ ثابتِ
   `_SIMILARITY_OBSERVED_THRESHOLD = 0.95` -- تا اختلافِ صرفاً نگارشی
   (فاصله/newline) به‌غلط «تفاوتِ رفتاری» حساب نشود.
3. `semantic_difference` همیشه، بدونِ استثنا، `"NOT_PROVEN"` است --
   این آزمایش هیچ‌وقت ادعایِ فهمِ معنایی نمی‌کند (دقیقاً طبقِ تمایزی که
   امیر در بازبینیِ v25.5.6 گذاشت).
4. سه سناریویِ دقیقاً هم‌آن‌هایی که امیر داد: `joke_feedback`،
   `good_mood`، `give_up` -- نه بیشتر، نه رویِ داده‌یِ واقعیِ کاربر.
5. **`scripts/run_context_effect_experiment.py`** (جدید): تنها راهِ
   اجرا -- یک اسکریپتِ دستی، نه بخشی از هیچ مسیرِ زنده.
6. تغییراتِ افزودنیِ کوچک در سه فایلِ *موجود* (طبقِ توافق: «مگر واقعاً
   یک dependency اجتناب‌ناپذیر پیدا شود»):
   - `interfaces.py` / `llama_cpp_adapter.py`: پارامترِ اختیاریِ
     `seed: Optional[int] = None` -- اجتناب‌ناپذیر بود چون بدونِ seedِ
     ثابت، تفاوتِ FULL/REDUCED می‌توانست فقط randomnessِ مدل باشد
     (دقیقاً هشدارِ خودِ امیر).
   - `conversational_bridge.py`: یک تابعِ عمومیِ `get_adapter()` --
     برایِ استفاده‌یِ مجددِ singleton بدونِ بازنویسیِ منطقِ لود.
   - `core.py` **دست نخورد.**

## Capability Impact
- **بهبود یافت:** Evidence/Validation -- برایِ اولین‌بار، شواهدِ
  کمّی (نه حدس) داریم که `pattern_context` *می‌تواند* خروجیِ یک LLM
  واقعی را عوض کند.
- **بدونِ تغییر:** Intelligence/Reliability/Communication/Final
  Decision در production -- چون این آزمایش هیچ‌جایِ مسیرِ زنده صدا زده
  نمی‌شود.

## Risk
- ریسکِ اصلی که امیر مشخصاً هشدار داد: «تفاوت به‌خاطرِ randomness
  باشد، نه context». رفعِ آن: `seed` ثابت + `temperature` پیش‌فرض `0.0`
  + `user_text`/`history` تضمین‌شده یکسان (با `assert` در خودِ کد، نه
  فقط در تست).
- ریسکِ نشتِ این آزمایش به مسیرِ زنده: رفعِ آن با معماری، نه فقط قول --
  `run_experiment` هیچ‌جا از `conversation_engine.py`، `core.py`، یا
  `tool_router.py` import/صدا زده نمی‌شود؛ فقط برعکس (خودش
  `conversation_engine.process` را به‌عنوانِ مصرف‌کننده صدا می‌زند، نه
  برعکس). تستِ
  `test_experiment_never_touches_routing_decision_or_final_response`
  این را با اجرایِ واقعیِ `process()` قبل/بعدِ آزمایش تأیید کرد.
- ریسکِ رگرسیون در `llama_cpp_adapter.py`: رفعِ آن با `seed` فقط وقتی
  به `create_chat_completion` پاس داده می‌شود که صریحاً داده شده باشد؛
  تستِ `test_seed_omitted_when_not_given_zero_behavior_change` و کلِ
  مجموعه‌یِ قدیمیِ `tests/test_local_llm_integration.py` (۱۳ تست) بدونِ
  تغییر دوباره اجرا و Pass شدند.

## Preservation
- `core.py`: صفر تغییر.
- `ConversationPatternEngine`, `conversation_engine.py`, هر ماژولِ
  دیگرِ `trx_ai/conversation/`: صفر تغییر نسبت به v25.5.6.
- فقط سه فایلِ *موجود* تغییر کردند (هر سه در `trx_model/`، همه‌شان
  فقط افزودنیِ اختیاری با پیش‌فرضِ بی‌اثر) -- `diff -rq` نسبت به v25.5.6
  این را تأیید می‌کند.

## Validation
- **مثلِ v25.5.6، این‌بار هم کدِ واقعی اجرا شد** (با همان stubِ
  یک‌بارمصرفِ محلیِ `aiohttp`/`pytest` -- در تحویل نیست): فایلِ واقعیِ
  `tests/test_context_effect_experiment_v25_5_7.py` → **۱۲ از ۱۲ تست
  Pass**، شاملِ:
  - محاسباتِ خالصِ diff/format (بدونِ نیاز به هیچ مدلی)،
  - پارامترِ `seed` واقعاً در `LlamaCppModelAdapter.chat` (با
    fake llama factory، بدونِ نیازِ به نصبِ واقعیِ کتابخانه)،
  - `run_experiment` سرتاسری با یک fake adapter که واقعاً به context
    حساس است (PASS) و یکی که حساس نیست (INCONCLUSIVE)،
  - خرابیِ یک سناریو بقیه را متوقف نمی‌کند،
  - فلگِ `TRX_NERVOUS_SYSTEM_ENABLED` بعد از آزمایش دقیقاً به حالتِ
    قبلی برمی‌گردد،
  - **مهم‌ترین تست:** خروجیِ `conversation_engine.process` قبل و بعدِ
    اجرایِ کاملِ آزمایش کاملاً یکسان می‌ماند.
- رگرسیون: `tests/test_nervous_system_v25_5_5.py` (۷/۷)،
  `tests/test_nervous_system_v25_5_6.py` (۸/۸)، و
  `tests/test_local_llm_integration.py` (۱۳/۱۳ -- `unittest`، بدونِ
  نیاز به شیمِ pytest) -- همه دوباره اجرا و Pass شدند. **جمعاً ۴۰ تست،
  صفر شکست.**
- **محدودیتِ صادقانه‌یِ این نسخه:** هیچ فایلِ GGUFِ واقعی/`llama-cpp-python`ی
  واقعی در این sandbox نیست (نه شبکه، نه مدلِ چندگیگابایتی). یعنی
  نتیجه‌یِ بالا (PASS با adapterِ حساس‌به‌context) رویِ یک **fake
  adapter** اثبات شد، نه رویِ خودِ Qwen2.5 یا هر مدلِ واقعی. این دقیقاً
  همان چیزی است که خطِ قرمزِ سوم را اثبات می‌کند (مکانیزمِ آزمایش درست
  کار می‌کند)، ولی **جایگزینِ اجرایِ رسمیِ امیر رویِ Local LLMِ واقعیِ
  خودش نیست.** امیر باید:
  ```
  python scripts/run_context_effect_experiment.py --json
  ```
  را رویِ محیطِ خودش (با `TRX_LOCAL_LLM_MODEL_PATH` تنظیم‌شده) اجرا کند
  و `overall_result` واقعی را گزارش دهد.

## Result
- ✅ مکانیزمِ آزمایش (FULL/REDUCED، seedِ ثابت، معیارهایِ از‌پیش‌تعیین‌شده،
  `semantic_difference` همیشه `NOT_PROVEN`) ساخته و با کدِ واقعی
  تأیید شد.
- ✅ صفر اثر رویِ production (با تست، نه فقط ادعا).
- ✅ صفر رگرسیون در ۴۰ تستِ موجود + جدید.
- ⚠️ نتیجه‌یِ رسمیِ «آیا رویِ Local LLMِ واقعیِ امیر هم PASS می‌شود؟» هنوز
  معلق است -- نیازمندِ اجرایِ دستیِ خودِ امیر.
- ⚠️ حتی اگر PASS شود، این **هنوز** به‌معنیِ «TRX معنیِ فیدبک را فهمیده»
  نیست (`semantic_difference` همیشه `NOT_PROVEN`) و **هنوز** به‌معنیِ
  «سیستمِ عصبی در تولید فعال شده» نیست (Coordinator هنوز SHADOW است) --
  این نسخه فقط یک لایه‌یِ آزمایشگاهیِ جدید اضافه کرد، نه وضعیتِ خودِ
  production را عوض کرد.

---

## پیشنهاد برایِ نسخه‌یِ بعدی
دو مسیر، به انتخابِ امیر (بعد از دیدنِ نتیجه‌یِ رسمیِ آزمایش):
- اگر PASS شد رویِ مدلِ واقعی: طراحیِ اتصالِ *واقعیِ* ADVISORY در
  خودِ `tool_router.py` (نه فقط آزمایشگاه) -- هنوز بدونِ اثر رویِ
  `RoutingDecision`، فقط لاگ/مقایسه در کنارِ پاسخِ واقعی.
- اگر INCONCLUSIVE شد: بازبینیِ `_format_pattern_block` (شاید فرمتِ
  فعلیِ تزریق برایِ این مدلِ خاص ضعیف است) قبل از هر تصمیمِ بزرگ‌تر.

---

## اصلاحیه (بعد از بازبینیِ امیر -- در همین نسخه اعمال شد)

امیر با اجرایِ مستقلِ ۴۰ تست (`40 passed in 1.05s`) و خودِ اسکریپت
(نتیجه‌یِ صادقانه‌یِ `SKIPPED_NO_MODEL` رویِ محیطِ بدونِ مدلِ او -- تأییدِ
اینکه سیستم PASSِ جعلی نمی‌دهد) v25.5.7 را تأیید کرد. یک نکته‌یِ دقیقِ
مستندسازی هم پیدا کرد:

> کامنتِ `# بدونِ ردِ پا` کنارِ `state_tracker.reset_snapshot` نادرست
> است. `conversation_engine.process` واقعاً عوارضِ جانبیِ واقعی دارد
> (`conversation_logger.log_turn_decision` یک خطِ لاگ می‌نویسد؛
> `NervousSystemCoordinator` خودِ context را در بافرِ محدودِ
> درون‌حافظه‌اش نگه می‌دارد). عبارتِ درست: **«No production behavioral
> effect»**، نه **«No side effect»**.

این تمایز کاملاً درست است و در همین فایل (`context_effect_experiment.py`،
docstringِ `_build_unified_context`) اصلاح شد -- بدونِ تغییرِ هیچ
منطقی؛ فقط دقتِ ادعا. جمع‌بندی: این آزمایش هیچ اثری رویِ *رفتارِ
تصمیم‌گیریِ production* ندارد؛ ولی *بدونِ اثرِ جانبیِ مطلق* نیست (لاگ +
یک context در حافظه‌یِ Coordinator تا اخراجِ LRU طبیعی).
