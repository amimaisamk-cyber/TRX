# TRX AI Medical v2.1 Upgrade

## Safety
- Safety is evaluated before routing, diagnosis, or online retrieval.
- Red-flag detection now has a conservative negation guard to reduce false escalation for phrases such as «درد قفسه سینه ندارم».
- Diagnostic match score is explicitly separate from confidence/evidence level.
- The public response layer avoids presenting local medication dosage rows as individualized prescriptions.

## Architecture
- `care.py` is the orchestration boundary.
- Router, Safety, Diagnosis, Dialogue, Knowledge, Medication, First Aid, Response and Models are independently addressable.
- Local knowledge is the default source; online knowledge remains a provider behind an interface.
- `MedicalRequest` and `MedicalResponse` provide stable internal contracts.
- Configurable thresholds, ranking weights, limits and feature flags live in `MedicalConfig`.

## Compatibility
- `MedicalAIEngine` remains the public facade.
- Legacy `medical/dialogue.py`, `medical/online.py`, `medical/formatting.py` entry points are retained.
- Legacy ranking field `percent` is retained internally for compatibility only; it must not be interpreted or rendered as probability.

## Validation
- Medical test suite: 30 passed.
- Full project suite: 200 passed, 1 unrelated pre-existing conversation-pattern assertion remains failing.

## اتصالِ گسترده‌تر به پایگاه‌های رسمیِ آنلاینِ دارو + تداخل (v2.1 → v2.2)

انگیزه: پایگاه‌داده‌ی محلی (`data/medications.py`, `data/diseases.py`,
`data/interactions.py`) عمداً کوچک نگه داشته شده (چند ده دارو/بیماری/
تداخل) — جا دادنِ همه‌ی داروها و بیماری‌هایِ دنیا در کد ممکن نیست و
اصلاً هدفِ این پروژه هم نبوده. تا پیش از این نسخه، وقتی دارویی در این
پایگاه‌داده نبود، سیستم فقط به MedlinePlus/ویکی‌پدیا/جستجویِ عمومیِ وب
سقوط می‌کرد که برایِ اطلاعاتِ *رسمیِ* دارو (دوز دقیق، برچسبِ FDA) کافی
نبود.

تغییرات:
- `medical/knowledge/drug_sources.py` (جدید): اتصال به **RxNorm**
  (نرمال‌سازیِ نام + شناسه‌ی RxCUI) و **openFDA** (برچسبِ رسمیِ دارو:
  کاربرد/دوز/هشدار/عوارض) — هر دو بدونِ نیاز به کلیدِ API.
- `medical/knowledge/interaction_online.py` (جدید): بررسیِ آنلاینِ
  تداخلِ دارویی از طریقِ RxNav، به‌جایِ تکیه‌یِ صرف بر فهرستِ محلیِ
  محدود؛ نتیجه با فرمتِ محلی سازگار است و در `response/formatter.py`
  با نتیجه‌ی محلی ادغام/نمایش داده می‌شود (هرکدام با برچسبِ منبع).
- `medical/online.py`: شاخه‌ی تداخلِ دارویی (که قبلاً در مسیرِ آنلاینِ
  چت اصلاً وجود نداشت و به‌اشتباه در شاخه‌ی «اطلاعاتِ دارو» گم می‌شد)
  حالا مستقل است و هم از پایگاه‌دانشِ محلی هم از RxNav استفاده می‌کند؛
  شاخه‌ی «اطلاعاتِ دارو» هم برایِ داروهایِ خارج از پایگاه‌داده‌ی محلی
  اول RxNorm/openFDA را امتحان می‌کند، سپس (اگر آن‌ها هم چیزی نداشتند)
  دانشنامه‌ی عمومی را.
- `medical/config.py`: پرچمِ جدیدِ `enable_drug_apis` (پیش‌فرض: روشن)
  برایِ خاموش‌کردنِ مستقلِ اتصال‌هایِ RxNorm/openFDA، جدا از
  `enable_online` که کلِ فallbackِ آنلاین (شاملِ Medline/ویکی‌پدیا) را
  کنترل می‌کند.
- رفعِ یک باگِ از قبل‌موجود: استخراجِ نامِ دارو از عبارت‌هایی مثلِ
  «اطلاعاتِ **داروی** X» به‌اشتباه «ی X» را به‌جایِ «X» می‌گرفت (چون
  کسره‌یِ اضافه پس از «دارو» بخشی از خودِ کلمه‌ی جستجوشده تلقی می‌شد)؛
  این مستقیماً روی کیفیتِ جستجویِ آنلاینِ جدید اثر می‌گذاشت، پس همین‌جا
  هم در `online.py` و هم در مسیرِ سینکِ `care.py` اصلاح شد.

محدودیت‌هایِ باقی‌مانده (صادقانه، نه ادعایِ کامل‌بودن):
- بدونِ اینترنت، سیستم دقیقاً به همان رفتارِ قبلی (فقط پایگاه‌دانشِ
  محلی + پیامِ صریحِ «بررسیِ آنلاین ممکن نشد») برمی‌گردد؛ هیچ‌جا سکوت
  را به‌معنایِ «بدونِ تداخل/بدونِ اطلاعات» جا نمی‌زند.
- RxNorm/openFDA فقط انگلیسی‌اند؛ پلِ ترجمه (`TranslatorEngine`) ممکن
  است برایِ نام‌هایِ خیلی نایاب یا اسم‌هایِ تجاریِ محلیِ ایرانی (که
  معادلِ بین‌المللی‌شان فرق دارد) شکست بخورد یا نتیجه‌ی نادرست بدهد —
  در این حالت به‌جایِ حدس، به دانشنامه‌ی عمومی سقوط می‌کند.
- این اتصال، دوزِ شخصی‌سازی‌شده تولید نمی‌کند و نباید بکند؛ خروجی همیشه
  با «این جایگزینِ نسخه‌ی پزشک/داروساز نیست» همراه است.
