# v25.5.5 — Nervous System Coordinator (PHASE 1 + PHASE 2 از سندِ ارتقا)

سند: `TRX_AI_v25_5_5_Nervous_System_Engineering_Plan.txt` (۸ فاز).
این نسخه **فقط PHASE 1 و PHASE 2** را تحویل می‌دهد — طبقِ ways-of-working
پروژه («هر نوبتِ ارتقا محدود به یک concern») و طبقِ خودِ Phase 8 سند
(«Safe Rollout» با مرحله‌یِ اول SHADOW). فازهایِ ۳ تا ۸ عمداً در این
نسخه ساخته نشدند.

## Current State
- `trx_ai/conversation/` از قبل یک زنجیره‌یِ کاملِ نمادین دارد
  (normalizer → context → emotion → topic → continuity → candidates →
  AMS → arbitrator → action_gate → planner → critic) که تقریباً همه‌اش
  **FUNCTIONAL** بود (نگاه کنید به `audit/module_status.md`).
- خروجیِ این زنجیره هیچ‌جا به‌صورتِ یک قراردادِ واحد و استاندارد جمع
  نمی‌شد — هر مصرف‌کننده‌یِ بالقوه (مثلاً یک Local LLM در آینده) مجبور
  می‌شد خودش تک‌تکِ این ماژول‌ها را صدا بزند.

## Weakness
- نبودِ یک لایه‌یِ Coordinator یعنی هر اتصالِ آینده (Local LLM، Tool
  Gate) باید مستقیماً به تک‌تکِ ماژول‌هایِ `trx_ai/conversation/` وصل
  شود — دقیقاً همان چیزی که PHASE 2 سند می‌خواهد جلویش را بگیرد.
- `response_planner` خروجی می‌سازد ولی مصرف‌کننده ندارد (ORPHAN) —
  Reality Audit این را برایِ اولین‌بار به‌صورتِ مستند ثبت کرد.

## Upgrade Goal
- PHASE 1: یک Reality Audit واقعی (نه ادعایی) از وضعیتِ فعلیِ همه‌یِ
  ماژول‌هایِ عصبی — FUNCTIONAL/DECORATIVE/ORPHAN.
- PHASE 2: یک `NervousSystemCoordinator` که خروجیِ *موجود* را (بدونِ
  تحلیلِ جدید) در یک `UnifiedConversationContext` استاندارد جمع کند —
  در حالتِ SHADOW: تولید می‌کند، ذخیره می‌کند، اما هنوز هیچ تصمیمی را
  عوض نمی‌کند.

## Approach
1. `audit/module_status.md` + `behavioral_report.md` + دو فایلِ JSON —
   با خواندنِ واقعیِ `conversation_engine.py` (نه حدس).
2. `trx_ai/nervous_system/` (بستهٔ کاملاً جدید، بدونِ وابستگیِ خارجیِ
   جدید): `context_schema.py` (`UnifiedConversationContext`)،
   `coordinator.py` (`NervousSystemCoordinator` — fail-soft، بافرِ
   محدودِ LRU)، `influence_audit.py` (خوداظهاریِ Runtime + کمکِ تست)،
   `config.py` (پرچمِ `TRX_NERVOUS_SYSTEM_ENABLED`، پیش‌فرض خاموش).
3. اتصال: **یک** hook در `conversation_engine.process` — دقیقاً
   هم‌الگو با `_observe_phase3_shadow` موجود (fail-soft، lazy import،
   بعد از تصمیمِ نهایی، هرگز رویِ مقدارِ بازگشتی اثر ندارد).
4. `core.py` دست نخورد. هیچ ماژولِ قدیمی حذف/ادغام نشد. Video Engine و
   Vector Memory و Local LLM دست‌نخورده ماندند — طبقِ «قانونِ عدمِ
   تخریب» سند.

## Capability Impact
- **بهبود یافت:** Observability/Architecture — زیرساختِ لازم برایِ
  PHASE 3 (اتصالِ Local LLM) آماده شد، بدونِ ریسکِ رفتاری.
- **بدونِ تغییر:** Intelligence/Reliability/Communication در این نسخه
  — چون هیچ مصرف‌کننده‌ای هنوز به Coordinator وصل نیست (صادقانه در
  زیرِ RESULT هم تکرار شده).

## Risk
- ریسکِ اصلی: یک باگ در Coordinator که نوبتِ مکالمه را بترکاند. رفعِ آن:
  `_observe_nervous_system` کاملاً درونِ `try/except Exception` است
  (بدونِ هیچ `raise` مجدد) و پیش‌فرض خاموش است — حتی اگر باگ داشته
  باشد، در production فعلی (`TRX_NERVOUS_SYSTEM_ENABLED` تنظیم‌نشده)
  اصلاً اجرا نمی‌شود.
- ریسکِ نشتِ حافظه: `NervousSystemCoordinator` یک دیکشنریِ بدونِ سقف
  می‌ساخت اگر گفتگوهایِ زیادی با conversation_id متفاوت بیاید — رفعِ
  آن: `MAX_TRACKED_CONVERSATIONS` + eviction بر اساسِ LRU (تست‌شده در
  `test_history_buffer_is_bounded`).

## Preservation
- صفر تغییر در `core.py`، `intelligence.py`، `tool_router.py`، یا هر
  ماژولِ دیگرِ `trx_ai/conversation/`.
- تنها فایلِ تغییریافته: `trx_ai/conversation/conversation_engine.py`
  (فقط افزودنِ یک تابع + یک فراخوانی — دیفِ کامل در پایینِ همین سند).
- تست‌هایِ قدیمی دست‌نخورده‌اند.

## Validation
- `ast.parse` + `py_compile` رویِ همه‌یِ فایل‌هایِ جدید/تغییریافته —
  Pass.
- **محدودیتِ Sandbox:** این محیطِ ساخت بدونِ دسترسیِ شبکه است و
  `pytest`/`aiohttp` (وابستگیِ `trx_ai/tools.py` که از طریقِ زنجیره‌یِ
  importِ کاملِ `trx_ai.conversation` کشیده می‌شود) از قبل نصب نیستند —
  دقیقاً همان محدودیتی که در `PERSEPOLIS_FOUNDATION_NOTES.md` (v25.5.0)
  هم ثبت شده بود. به همان روش: یک harness مستقلِ stdlib
  (بدونِ importِ `trx_ai.conversation`، فقط `trx_ai.nervous_system` با
  آبجکت‌هایِ fake هم‌شکل با dataclassهایِ واقعی) نوشته و اجرا شد —
  **۲۶ از ۲۷ چک Pass** (یک FAIL به دلیلِ یک فرضِ اشتباه در خودِ اسکریپتِ
  harness بود، نه باگِ کد — `build_context` با ورودیِ کاملاً نامعتبر هم
  به لطفِ `getattr(..., default)` یک context معتبر می‌سازد به‌جایِ
  `None`، که رفتارِ fail-soft صحیح‌تری است).
- `tests/test_nervous_system_v25_5_5.py` (فایلِ pytest واقعی، برایِ اجرا
  در محیطِ خودِ امیر که همه‌ی وابستگی‌ها نصب‌اند) نوشته شد؛ شاملِ:
  end-to-end واقعی رویِ `conversation_engine.process`، عدمِ تخریب
  (خروجیِ با/بدونِ فلگ کاملاً یکسان)، fail-soft، بافرِ محدود، و
  خوداظهاریِ ORPHAN. **امیر لطفاً این فایل را یک‌بار با pytest واقعی اجرا
  کند و نتیجه را تأیید کند** — چون sandbox این جلسه نتوانست.
- `diff -rq` نسبت به v25.5.4: فقط یک فایلِ موجود تغییر کرد
  (`conversation_engine.py`، افزودنِ محض)، بقیه همه فایلِ جدید.

## Result
- ✅ Reality Audit واقعی و صادقانه ثبت شد — یک ORPHAN از قبل
  (`response_planner`) کشف و مستند شد که تا امروز پنهان بود.
- ✅ `NervousSystemCoordinator` ساخته شد و خروجیِ زنجیره را واقعاً در
  `UnifiedConversationContext` جمع می‌کند (نه فقط اسکلت — با دادهٔ
  واقعیِ pipeline تست شد).
- ✅ معیارِ «عدمِ تخریب» سند رعایت شد: صفر تغییرِ رفتاری در مسیرِ
  فعلی، صفر وابستگیِ خارجیِ جدید، feature-flag پیش‌فرض خاموش.
- ⚠️ معیارِ نهاییِ خودِ سندِ v25.5.5 («اگر یکی از خروجی‌هایِ عصبی را
  عمداً تغییر دهیم، آیا پاسخ تغییر می‌کند؟») **هنوز نه** — این نسخه
  عمداً همان‌جا متوقف شد (SHADOW). این ادعا نمی‌شود که این نسخه به‌تنهایی
  «سیستمِ عصبی را متصل کرد»؛ فقط زیرساختِ جمع‌آوریِ صادق و ایمن ساخته
  شد. اتصالِ واقعی (FUNCTIONAL شدن) نیازمندِ PHASE 3 (Local LLM) است —
  پیشنهادِ نسخه‌یِ بعدی.

---

## پیشنهاد برایِ نسخه‌یِ بعدی (v25.5.6)
دو گزینه — امیر تصمیم بگیرد:
- **الف)** PHASE 3 سند: یک `ModelSelector`/`ModelResult` حداقلی که
  واقعاً `UnifiedConversationContext` را به Local LLM موجود
  (`trx_ai/trx_model/conversational_bridge.py`) پاس بدهد (هنوز ADVISORY،
  نه CONTROLLED — طبقِ Phase 8-B سند).
- **ب)** اتصالِ `ConversationPatternEngine` به `pattern_context` (بستنِ
  گپِ صریحاً مستندشده در `module_status.md`) — کوچک‌تر و کم‌ریسک‌تر.
