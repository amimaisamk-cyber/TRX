> **TRX AI v25.0.0-architect:** این نسخه یک لایه Runtime Intelligence، context budgeting، retry/backoff برای LLM و secret hygiene اضافه می‌کند.
>
> **TRX AI v25.4.9:** مرحله‌های ۱ تا ۴ از فازِ ۳ (Stage 4 در حالت Shadow و بدون کنترلِ پاسخ) (`TRX Native Neural
> Cognitive Layer`) ساخته شد -- `neural_adapter.py` (اتصالِ واقعی به
> `trx_model`: load/unload، تستِ سازگاریِ tokenizer/model، inference
> آزمایشی)، و `inference_service.py` + `latency_guard.py` +
> `fallback.py` + `telemetry.py` (سرویسِ واحدِ orchestration با
> timeout، بررسیِ RAM، fallbackِ اجباری، و تله‌متریِ bounded). همچنان
> **بدونِ اتصال به Core/`intelligence.py`/گفتگویِ زنده** -- با
> `TRX_PHASE3_ENABLED=false` (پیش‌فرض) هیچ رفتارِ زنده‌ای اجرا نمی‌شود.
> ۳۰ تستِ جدید (جمعاً ۵۶ تستِ فاز ۳) همه پاس. جزئیات در
> `PHASE3_STAGE2_3_NOTES.md`.
>
> **TRX AI v25.4.7:** مرحله‌ی ۱ از فازِ ۳ (`TRX Native Neural Cognitive
> Layer`) ساخته شد -- `trx_ai/phase3/`: `schemas.py` (`NeuralAdvice`،
> `FusionDecision`، `NeuralInputFeatures`)، `config.py` (kill-switch
> پیش‌فرض خاموش، شش حالتِ اجرا از `disabled` تا
> `controlled_production`)، `feature_builder.py` (تبدیلِ
> `ContextSnapshot` موجود به featureِ محدودشده، بدونِ تاریخچه‌ی
> بی‌نهایت). طبقِ دستورِ صریح: **بدونِ اتصالِ واقعی به Core یا
> `trx_model`** -- هیچ فایلِ موجودی تغییر نکرد، صفر importِ جدید
> (`aiohttp` و بقیه دست‌نخورده). ۲۶ تستِ جدید (`unittest`، چون
> `pytest` در sandbox نصب نیست) همه پاس. جزئیات در
> `PHASE3_FOUNDATION_NOTES.md`.
>
> **TRX AI v25.4.6:** فازِ دومِ آموزش فعال شد --
> `trx_ai/trx_model/training/data_pipeline/`: Cleaning/Dedup/Quality
> Scoring، تقسیمِ train/validation در سطحِ سند (بدونِ Data Leakage)،
> Smoke Testِ اجباریِ ۱۱-موردی، Checkpointِ سه‌سطحی (latest/best/
> periodic) با نوشتنِ اتمیک، مانیتورِ منابع، و Generalization Test.
> رویِ پیکره‌ی واقعیِ پروژه: Validation Loss از ۶.۵۵ به ۵.۰۵
> (Perplexity از ۶۹۹ به ۱۵۶). هیچ فایلِ v25.4.4/v25.4.5 تغییر نکرد.
> جزئیات در `NATIVE_MODEL_TRAINING_PHASE2_NOTES.md`.
>
> **TRX AI v25.4.5:** چرخه‌ی کاملِ آموزشِ TRX Native Model فعال شد --
> `trx_ai/trx_model/training/`: Forward Cache، Causal Cross Entropy،
> Backward تحلیلیِ کامل (RMSNorm/RoPE/Attention/SwiGLU/Weight Tying)،
> Gradient Clipping، AdamW، Checkpoint با Resume واقعی. تأییدشده با
> Gradient Check (max rel error ۹.۹e-۷)، Tiny Overfit، و اجرایِ
> end-to-end رویِ پیکره‌ی واقعیِ پروژه (Validation Loss از ۶.۸۱ به
> ۵.۲۰). هیچ فایلِ موجودی تغییر نکرد. جزئیات در
> `NATIVE_MODEL_TRAINING_NOTES.md`.
>
> **TRX AI v25.4.4:** زیرساختِ مدلِ بومیِ TRX اضافه شد --
> `trx_ai/trx_model/`: توکنایزرِ BPE سطحِ بایت (آموزش‌دیده رویِ پیکره‌ی
> خودِ پروژه، lossless)، هسته‌ی Transformer با RoPE/RMSNorm/SwiGLU/
> causal attention، و یک `ModelInterface`/`ModelAdapter` مستقل --
> همه با numpy، بدونِ torch. عمداً به مسیرِ پاسخِ چتِ فعلی وصل نشده
> (فقط زیرساخت، نه جایگزینی). جزئیات در `NATIVE_MODEL_NOTES.md`.
>
> **TRX AI v25.4.2:** لایه‌ی مشاهده‌پذیری (`trace.py`/دستورِ «ردیابی»)
> که از قبل به مسیرِ اصلیِ چت وصل بود، حالا نوبت‌هایِ عکس/فایل را هم
> پوشش می‌دهد -- قبلاً «ردیابی» بعدِ آپلود، رکوردِ نوبتِ متنیِ قبلی را
> نشان می‌داد. جزئیات در `OBSERVABILITY_UPGRADE_NOTES.md`.
>
> **TRX AI v25.4.1:** دو تابعِ `reply_hints`/`communication_profile` که
> در یک تغییرِ قبلی اضافه شده بودند ولی هیچ‌جا صدا زده نمی‌شدند (کدِ
> مُرده -- طبقِ Audit، بخشِ ۱: «توهمِ پیشرفت»)، حالا واقعاً در
> `ResponseEngine` استفاده می‌شوند: چرخشِ hint بر اساسِ نوبت (تا پاسخ‌ها
> تکراری/رباتی نباشند) و کوتاه‌سازیِ بدنه‌یِ نتیجه برایِ کاربرِ
> خسته/کلافه. جزئیات در `CHANGELOG.md`.
>
> **TRX AI v25.4.0:** لایه‌ی Context در `trx_ai/agent/cognition/` حالا
> واقعاً به حافظه‌ی کوتاه/بلندمدتِ موجود (`ai.memory`) و به شمارشِ
> شکست‌هایِ اخیر (`ai.user_state_memory`) وصل است -- قبلاً این پارامترها
> فقط تعریف شده بودند اما هیچ‌جا واقعاً پُر/خوانده نمی‌شدند. جزئیات در
> `CONTEXT_CORE_UPGRADE_NOTES.md`.
>
> **TRX AI v25.2.0:** یک مکانیزمِ تصمیم‌گیریِ خودمختار (Autonomous Agent
> Loop) اضافه شد -- با پیشوندِ `عامل: <هدف>` در چت، هوش مصنوعی خودش
> ابزارها (وب، بینایی، پایگاه‌دانش، ماشین‌حساب، ترجمه، فایل، کد،
> یادآوری) را زنجیره‌ای صدا می‌زند تا هدف را حل کند. جزئیاتِ کامل در
> `AGENT_LOOP_NOTES.md`.

# TRX Enterprise AI — نسخه‌ی حرفه‌ای (v20.1)

بازآرایی معماری نسخه‌ی تک‌فایلیِ اصلی (`20_هوش_مصنوعی.py`، ۳۷۳۲ خط) به یک
پکیج پایتون ماژولار، بدون حذف یا تغییر هیچ‌یک از قابلیت‌های موجود.

## v25.5.10 — رفعِ باگ: Therapy Companion بازخوردِ «تکراری شدی» را نادیده می‌گرفت

از یک سندِ تحلیلیِ مستقل: کاربر صریحاً گفت «این حرف‌ها رو دقیقاً به
همین ترتیب قبلاً ازت شنیدم» و Therapy Companion این بازخورد را
نادیده گرفت -- یک مکانیزمِ ضدِ تکرارِ از‌قبل‌موجود (`last_used`) هرگز
واقعاً وصل نشده بود، و هیچ تشخیصی برایِ «بازخورد دربارهٔ رفتارِ خودِ
TRX» وجود نداشت. هر دو رفع شد؛ تغییرات کاملاً محدود به
`trx_ai/medical/therapy/`. ۲۳/۲۳ تست Pass (۱۱ جدید، صفر رگرسیون).
سه یافته‌یِ دیگرِ همان سند (Conversation Controller، زنجیره‌یِ ارجاعِ
ضمنی، contextِ موتورِ پزشکی) عمداً باز ماندند. جزئیات:
`audit/THERAPY_REPETITION_FEEDBACK_v25_5_10.md`.

## v25.5.9 — رفعِ باگ: عدمِ تشخیصِ «چه کار خاصی بلدی» (SmallTalkEngine)

از همان ترنسکریپتِ v25.5.8: regexِ دسته‌یِ `capability` فقط شکلِ جمعِ
ثابت («چه کارهایی بلدی») را می‌گرفت و با پارافریزهایِ طبیعی («چه کار
خاصی بلدی») سازگار نبود -- به boilerplateِ عمومی سقوط می‌کرد. با
گسترشِ الگو (بدونِ تغییرِ منطقِ دیگر) رفع شد. ۱۳/۱۳ تست Pass. جزئیات و
دو مشکلِ دیگرِ همان ترنسکریپت که هنوز باز مانده‌اند:
`audit/SMALLTALK_CAPABILITY_MISS_v25_5_9.md`.

## v25.5.8 — رفعِ باگ: «همراهِ روان‌شناختیِ جعلی» (گزارشِ واقعیِ امیر)

طبقِ یک ترنسکریپتِ واقعیِ گفتگو: پیام‌هایِ بی‌ربط به سلامت («چیزی
نمیخوام بدونم😂»، «واقعا رد دادی»، ...) زیرِ برچسبِ «💙 همراهِ
روان‌شناختی» یک متنِ ثابتِ «تغذیه/خواب/ورزش» می‌گرفتند -- چون NLUِ
بیرونی (معنایی) و موتورِ پزشکی (فقط کلیدواژه‌ای) در تشخیصِ
emotional_support با هم مخالف بودند و کسی این عدمِ توافق را چک
نمی‌کرد. با یک کلیدِ صریحِ `source` در خروجیِ موتورِ پزشکی رفع شد --
کاملاً افزودنی، ۲۸/۲۸ تستِ جدید + ۲۵ تستِ قدیمی Pass. جزئیات:
`audit/EMOTIONAL_SUPPORT_MISROUTE_v25_5_8.md`. باگِ دومِ همان گزارش
(ارجاعِ ضمیر به موضوعِ قدیمی) هنوز باز است -- برایِ نسخه‌ی بعدی.

## v25.5.7 — Controlled Context Effect Experiment (کاملاً ADVISORY/SHADOW)

اولین آزمایشِ کنترل‌شده برایِ سنجیدنِ اینکه آیا `pattern_context`
*می‌تواند* خروجیِ Local LLM را عوض کند -- طبقِ scopeِ قفل‌شده‌ی امیر
(FULL در برابرِ REDUCED، seed/temperature/history/user_text کاملاً
یکسان، سه معیارِ عددیِ از‌پیش‌تعیین‌شده، `semantic_difference` همیشه
`NOT_PROVEN`). فقط از طریقِ `scripts/run_context_effect_experiment.py`
اجرا می‌شود -- هیچ‌جایِ مسیرِ زنده به آن وصل نیست؛ `core.py` دست نخورد.
جزئیات و نتیجه‌ی معلقِ اجرایِ رسمی رویِ Local LLMِ واقعی:
`NERVOUS_SYSTEM_NOTES_v25_5_7.md`.

## v25.5.6 — Pattern Bridge: اتصالِ ConversationPatternEngine (زیرمجموعه‌یِ stateless، هنوز SHADOW)

نسخه‌یِ عمداً کوچک: فقط `ConversationPatternEngine → pattern_context →
NervousSystemCoordinator → UnifiedConversationContext → SHADOW`. Local
LLM/Final Decision/Tool Router عمداً بیرون از این نسخه ماندند.

خروجیِ واقعیِ زیرمجموعه‌یِ stateless (`build_pattern`) حالا در
`pattern_context["engine"]` ذخیره می‌شود -- با یک آزمایشِ A/B واقعی
(«یه جوک بگو» در برابرِ «یه جوک بگو + چقدر بی‌مزه 😂») اثبات شد که دو
مکالمه‌یِ متفاوت واقعاً دو `pattern_context` متفاوت می‌سازند. این‌بار
تست‌ها هم روی کدِ واقعی اجرا شدند (نه فقط اسکلتِ آن) -- جزئیات:
`NERVOUS_SYSTEM_NOTES_v25_5_6.md`.

## v25.5.5 — Nervous System Coordinator (PHASE 1 + PHASE 2 از سندِ v25.5.5، مرحله‌یِ SHADOW)

سندِ `TRX_AI_v25_5_5_Nervous_System_Engineering_Plan.txt` هدفش وصل‌کردنِ
مهندسی‌شده‌یِ ماژول‌هایِ عصبیِ موجود (`trx_ai/conversation/*`) به یک
مسیرِ تصمیم‌گیریِ مشترک است — بدونِ حذفِ چیزی و بدونِ تغییرِ گسترده در
`core.py`. این نسخه فقط دو فازِ اول را تحویل می‌دهد:

- **Reality Audit** (`audit/module_status.md` و سه فایلِ همراه): برایِ
  اولین‌بار مستند شد که `response_planner` خروجی می‌سازد ولی مصرف‌کننده
  ندارد (ORPHAN) — بقیه‌یِ زنجیره (normalizer تا response_critic) از قبل
  FUNCTIONAL بود.
- **`trx_ai/nervous_system/`** (بستهٔ کاملاً جدید، صفر وابستگیِ خارجی):
  `NervousSystemCoordinator` خروجیِ همان زنجیره‌یِ موجود را در یک
  `UnifiedConversationContext` استاندارد جمع می‌کند. با
  `TRX_NERVOUS_SYSTEM_ENABLED=1` (پیش‌فرض **خاموش**) فعال می‌شود.

**صادقانه:** این Coordinator در این نسخه عمداً **ORPHAN** است — هنوز
هیچ مصرف‌کننده‌ای (Local LLM، Tool Gate) به `UnifiedConversationContext`
وصل نشده؛ فقط زیرساختِ جمع‌آوری ساخته شد. جزئیاتِ کامل:
`NERVOUS_SYSTEM_NOTES_v25_5_5.md`.

## v25.5.3 — اتصالِ اختیاریِ یک مدلِ زبانیِ واقعی و محلی (پیش‌فرض خاموش)

یک آداپتورِ جدید (`llama_cpp_adapter.py`) که `ModelInterface`ی خودِ
پروژه (بخشِ ۱۱ سند) را رویِ یک مدلِ زبانیِ متن‌بازِ محلی (فایلِ GGUF،
از طریقِ `llama-cpp-python`) پیاده می‌کند — کاملاً محلی، بدونِ اینترنت،
بدونِ APIِ خارجی. با یک کلیدِ خاموش/روشن (`TRX_LOCAL_LLM_ENABLED`،
پیش‌فرض خاموش) به مسیرِ fallbackِ عمومیِ گفتگو وصل شده — دقیقاً جایِ
همون boilerplateِ رباتیِ قدیمی. راهنمایِ کاملِ فعال‌سازی:
`LOCAL_LLM_INTEGRATION_NOTES.md`.

## v25.5.2 — رفعِ باگ: تصحیحِ صریحِ کاربر («یاد گرفتم») واقعاً اثر می‌کند

قبلاً بعدِ اینکه کاربر یک تشخیصِ اشتباهِ نیت را تصحیح می‌کرد، دفعه‌ی
بعدِ همان پیام دقیقاً همان تشخیصِ غلط تکرار می‌شد — سیستم می‌گفت «یاد
گرفتم» ولی چیزی عوض نمی‌شد. علتش یک سقفِ ایمنی در
`conversation/intent_candidates.py` بود که برایِ جلوگیری از تطبیق‌هایِ
فازیِ تصادفی ساخته شده بود، اما بینِ «فازیِ تصادفی» و «تصحیحِ صریحِ
کاربر» تمایز قائل نمی‌شد. جزئیاتِ کامل و اثباتِ اجراشده در
`BUGFIX_v25_5_2_FEEDBACK_FUZZY_CAP.md`.

## v25.5.0 — Persepolis Foundation (شروعِ معماریِ تخت‌جمشید/خورشید/ماه)

یک مرحله‌ی جدید و بلندمدت شروع شده: تبدیلِ تدریجیِ TRX به یک «تمدنِ
نرم‌افزاری» طبقِ سندِ `TRX_AI_Persepolis_Solar_Lunar_Complete_Blueprint.txt`.
این نسخه فقط **مرحله‌ی ۱ (Persepolis Foundation)** است — قراردادِ
مشترکِ `DomainManifest`/`HealthReport`/`EventEnvelope`، یک
`HealthRegistry` و `EventBus` سبک و fail-soft، و یک registryِ اعلانیِ
Domainهای واقعیِ موجود (`trx_ai/civilization/`). **هیچ رفتارِ فعلی
تغییر نکرده** و این پکیج به هیچ مسیرِ زنده‌ای وصل نیست؛ جزئیات کامل و
نتیجه‌ی mapping در `PERSEPOLIS_FOUNDATION_NOTES.md`. Solar Runtime،
Lunar Runtime و Solar Resource Controller در مراحلِ بعدی ساخته
می‌شوند.

## چرا این بازآرایی؟

نسخه‌ی اصلی همه‌چیز — از دیتابیس گرفته تا موتور پزشکی و رابط کاربری —
را در یک فایل واحد نگه می‌داشت. این کار نگهداری، تست و توسعه‌ی تیمی را
دشوار می‌کند. در این نسخه، هر مسئولیت به یک ماژول مستقل منتقل شده است.

## ساختار پروژه

```
trx_ai/
├── __init__.py          نسخه‌ی پکیج
├── logging_config.py     پیکربندی متمرکز لاگ (فایل چرخشی + کنسول)
├── dependencies.py       بررسی/نصب پکیج‌ها + پرچم‌های وابستگی اختیاری
├── config.py             مسیرهای داده، صداها، شخصیت‌های هوش مصنوعی
├── models.py             dataclass های مشترک (Message, ToolScore, ...)
├── database.py           DatabaseManager (SQLite: پروفایل/دانش/تاریخچه)
├── memory_store.py        MemoryEngine, CacheManager, VectorDatabase, SessionManager
├── intelligence.py        IntentEngine, ToolScorer, ReflectionEngine, AutonomousLearningEngine
├── medical.py             MedicalAIEngine
├── tools.py               Calculator, Translator, WebSearch, Weather, FileManager, CodeIntelligence
├── interpreter.py         PersianPythonInterpreter
├── plugins.py             PluginSystem
├── agent/                 مکانیزمِ تصمیم‌گیریِ خودمختار (Autonomous Agent
│                          Loop) -- زنجیره‌کردنِ ابزارها بدونِ دخالتِ
│                          دستیِ کاربر در هر مرحله؛ رجوع به
│                          AGENT_LOOP_NOTES.md
├── audio.py               AudioVoiceEngine (edge-tts)
├── ui.py                  UIEngine (رابط کاربری Rich، ترمینال)
├── gui_ui_engine.py        GuiUIEngine (پلِ رویداد برایِ GUI/وب، مشترکِ Qt و مرورگر)
├── gui_app.py               رابطِ گرافیکیِ دسکتاپ (PySide6/Qt)
├── llm_engine.py            پاسخ‌دهیِ مولد از طریقِ REST APIِ Gemini (بدونِ SDK سنگین)
├── webserver.py             سرورِ aiohttp برایِ رابطِ وب
├── web_assets.py            صفحه‌ی HTML/CSS/JS تعبیه‌شده‌ی رابطِ وب
└── core.py                TRXEnterpriseAI (هماهنگ‌کننده‌ی اصلی) + حلقه‌ی تعامل
main.py                    نقطه‌ی ورودِ ترمینالی
gui_main.py                نقطه‌ی ورودِ رابطِ گرافیکیِ Qt
web_main.py                نقطه‌ی ورودِ رابطِ وب (توصیه‌شده برایِ موبایل)
requirements.txt             نصبِ پیش‌فرض (اصلی/سبک) -- شاملِ requirements-core.txt
requirements-core.txt        وابستگی‌هایِ اجباری
requirements-ai.txt          اختیاری: لایه‌یِ Semantic/NLU (sentence-transformers, ...)
requirements-vision.txt      اختیاری: بهبودِ کیفیتِ عکسِ کلاسیکِ سریع‌تر (opencv, ...)
requirements-dev.txt         اختیاری: اجرایِ تست‌ها (pytest)
CHANGELOG.md                فهرست دقیق تغییرات نسبت به نسخه‌ی اصلی
```

## اجرا

### نسخه‌ی ترمینالی (Termux و مشابه)

```bash
pip install -r requirements.txt
python main.py
```

برای فعال‌کردنِ لایه‌یِ Semantic/NLU (translator/planning/dictionary
با شباهتِ معنایی به‌جایِ فقط کلیدواژه) یا بهبودِ کیفیتِ عکسِ کلاسیکِ
سریع‌تر، این‌ها را هم نصب کنید (اختیاری، سنگین‌تر، ممکن است روی
Termux/اندروید همیشه wheelِ آماده نداشته باشند):

```bash
pip install -r requirements-ai.txt
pip install -r requirements-vision.txt
```

نصب خودکار پکیج‌های گم‌شده هنگام اجرا هم مثل قبل فعال است؛ برای غیرفعال‌کردنش:

```bash
TRX_AUTO_INSTALL=0 python main.py
```

### نسخه‌ی گرافیکی (دسکتاپ، PySide6/Qt)

```bash
python gui_main.py
```

PySide6 خودکار نصب می‌شود (اگر نبود). این نسخه دقیقاً همان موتور را
اجرا می‌کند (پزشکی، آنالیزگرِ کد، کارها/یادآوری، چندزبانگی، صدا) در
یک پنجره‌ی چتِ راست‌به‌چپ، بدونِ نیاز به کتابخانه‌های شکل‌دهیِ فارسی —
چون Qt متنِ فارسی/عربی را به‌صورتِ بومی و درست رندر می‌کند.

**محدودیت:** PySide6 یک وابستگیِ کامپایل‌شده‌ی سنگین است و رویِ خیلی
از محیط‌هایِ اندروید (Pydroid3/Termux) اصلاً نصب نمی‌شود. برایِ آن
پلتفرم‌ها از نسخه‌ی وب پایین استفاده کنید.

### نسخه‌ی وب (توصیه‌شده برایِ موبایل/اندروید — بدونِ هیچ وابستگیِ گرافیکی)

```bash
python web_main.py
```

یک سرورِ سبک (با همان `aiohttp` که از قبل CORE پروژه است) بالا
می‌آید و مرورگرِ پیش‌فرض را رویِ `http://127.0.0.1:8765` باز می‌کند.
رابطش یک صفحه‌ی چتِ تک‌فایلیِ مدرن است (HTML/CSS/JS تعبیه‌شده در
`trx_ai/web_assets.py`؛ چیزی روی دیسک نوشته/سرو نمی‌شود از فایلِ
جدا، پس مشکلاتِ مسیرِ نسبی که در Pydroid3 دیده شده اینجا رخ نمی‌دهد):

- استریمِ زنده‌ی پاسخ‌ها (توکن‌به‌توکن، دقیقاً حسِ ChatGPT/Claude)
- پوسته‌ی تیره/روشن با یک کلیک
- کاملاً واکنش‌گرا (موبایل/دسکتاپ)
- روی Pydroid3: برنامه را اجرا کنید، بعد مرورگرِ خودِ گوشی (Chrome) را
  باز و به همان آدرس بروید (اگر مرورگر خودکار باز نشد)

متغیرهایِ محیطیِ این نسخه:

```bash
TRX_WEB_HOST=0.0.0.0 python web_main.py   # دسترسی از دستگاه‌های دیگرِ همان شبکه
TRX_WEB_PORT=9000 python web_main.py      # تغییرِ پورت
TRX_NO_BROWSER=1 python web_main.py       # بازنکردنِ خودکارِ مرورگر
TRX_WEB_TOKEN=رمز-دلخواه-شما python web_main.py  # نیازِ اجباریِ توکن برایِ دسترسی
```

🔐 **نکته‌ی امنیتی:** با `TRX_WEB_HOST=0.0.0.0`، هر کسِ دیگری رویِ همان
شبکه (Wi-Fi مشترک) می‌تواند به گفتگو/حافظه/هزینه‌هایِ شما وصل شود، مگر
اینکه `TRX_WEB_TOKEN` را از قبل تنظیم کنید. اگر این کار را نکنید، خودِ
برنامه یک توکنِ موقت می‌سازد و آدرسِ کاملش (شاملِ `?token=...`) را در
کنسول چاپ می‌کند — همان آدرس را باز کنید، نه آدرسِ ساده.

**محدودیتِ شناخته‌شده (هر سه رابط):** مدِ REPL چندخطیِ «مفسر کدِ
فارسی» فعلاً فقط در نسخه‌ی ترمینالی کار می‌کند.

## پاسخ‌دهیِ عمومی — سه لایه، بدونِ نیاز به هیچ APIای

قبلاً هر پیامی که به هیچ نیتِ خاصی (ماشین‌حساب، ترجمه، پزشکی، ...)
نمی‌خورد، مستقیم می‌رفت سراغِ Gemini API؛ بدونِ آن هم فقط چند جمله‌ی
ثابتِ تکراری می‌گفت. الان این «پاسخِ عمومی» سه لایه دارد که به‌ترتیب
امتحان می‌شوند — دو لایه‌ی اول کاملاً رایگان و بدونِ کلید هستند:

1. **`SmallTalkEngine` (کاملاً محلی، صفر تماسِ شبکه‌ای):** برایِ
   گفتگویِ روزمره — سلام/احوال‌پرسی/تشکر/خداحافظی/معرفیِ خود/سؤالِ
   توانایی‌ها — چند پاسخِ متنوع و طبیعی به‌صورتِ تصادفی انتخاب می‌شود
   (نه یک جمله‌ی ثابتِ تکراری).
2. **جستجویِ خودکارِ ویکی‌پدیا/DuckDuckGo:** اگر پیام شکلِ یک سؤالِ
   دانشی/واقعیت‌محور دارد (کلمه‌ی پرسشی یا «؟»)، قبل از Gemini مستقیم
   ویکی‌پدیایِ فارسی و DuckDuckGo را امتحان می‌کند — رایگان، بدونِ
   کلید، فقط نیازمندِ اینترنت.
3. **Gemini API (اختیاری):** فقط اگر دو لایه‌ی بالا جوابی نداشتند
   (یعنی سؤال واقعاً باز/خلاقانه/فلسفی است)، در صورتِ تنظیم‌بودنِ
   `GEMINI_API_KEY`، از آن استفاده می‌شود؛ وگرنه به یک پاسخِ سادهٔ
   نهایی سقوط می‌کند — برنامه هیچ‌وقت کرش نمی‌کند یا بدونِ پاسخ
   نمی‌ماند.

نتیجه: برایِ اکثرِ استفاده‌هایِ روزمره (احوال‌پرسی، سؤالاتِ دانشی مثلِ
«کوروش کبیر کیست»، محاسبات، ترجمه، مدیریتِ کارها) اصلاً نیازی به کلیدِ
Gemini نیست. کلید فقط برایِ بهبودِ کیفیتِ پاسخِ سؤالاتِ کاملاً باز/
خلاقانه لازم می‌شود.

برایِ فعال‌سازیِ لایه‌ی سوم (اختیاری)، یک کلیدِ رایگان از
https://aistudio.google.com/apikey بگیرید و پیش از اجرا تنظیمش کنید:

```bash
export GEMINI_API_KEY="کلید-شما"
python main.py   # یا gui_main.py / web_main.py
```

(روی Pydroid3 که export معمولیِ شل در دسترس نیست، در ابتدایِ هرکدام
از این سه فایلِ ورودی یک خطِ `os.environ["GEMINI_API_KEY"] = "..."`
آماده گذاشته شده — کلیدتان را همان‌جا بچسبانید.)

## متغیرهای محیطی

| متغیر | توضیح | پیش‌فرض |
|---|---|---|
| `TRX_AUTO_INSTALL` | نصب خودکار پکیج‌های ضروری (`0` برای غیرفعال) | `1` |
| `TRX_LOG_LEVEL` | سطح لاگ فایل (`DEBUG`, `INFO`, `WARNING`, ...) | `INFO` |
| `TRX_LOG_DIR` | مسیر پوشه‌ی لاگ | `logs` |
| `TRX_AUDIO_DIR` / `TRX_PLUGINS_DIR` / `TRX_FILES_DIR` / `TRX_TEMP_DIR` | مسیر پوشه‌های داده | مقادیر قبلی |

## نکات امنیتی مهم (بدون تغییر در رفتار، فقط شفاف‌سازی)

- **ماشین‌حساب (`CalculatorEngine`)** از ابتدا با `ast.parse` امن پیاده‌سازی
  شده بود (نه `eval`)؛ همان‌طور حفظ شده است.
- **مفسر پایتون فارسی (`PersianPythonInterpreter`)** و **سیستم پلاگین
  (`PluginSystem`)** به‌طور ذاتی کد را با `exec()` اجرا می‌کنند — این خودِ
  قابلیت اصلی آن‌هاست و عمداً حفظ شده، اما اکنون هر اجرای پلاگین یک خط
  هشدار در لاگ ثبت می‌کند. **این ابزارها را فقط با کد مورد اعتماد خودتان
  استفاده کنید و آن‌ها را به‌عنوان سرویس عمومی در معرض کاربران ناشناس
  قرار ندهید.**
- نصب خودکار پکیج‌ها با `pip` اکنون قابل غیرفعال‌سازی صریح است.
- خطاهای داخلی (پایگاه‌داده، شبکه، ChromaDB، پلاگین‌ها) علاوه بر پیام
  فارسیِ قبلی، اکنون با جزئیات کامل (traceback) در `logs/trx_ai.log`
  ثبت می‌شوند — پیش‌تر این اطلاعات به‌کلی از دست می‌رفت.

## آنچه *تغییر نکرده*

طبق درخواست، هیچ قابلیتی حذف یا رفتار آن تغییر داده نشده است: تمام
دستورات فارسی، شخصیت‌ها، موتور پزشکی، حافظه‌ی برداری، مفسر فارسی،
سیستم پلاگین و منطق مسیریابی ابزارها دقیقاً همان کد قبلی هستند، فقط در
فایل‌های جداگانه سازمان‌دهی شده‌اند. جزئیات کامل در `CHANGELOG.md`.


## 🔊 Web GUI — Microsoft Neural Persian TTS

در Web GUI برای دکمه «🔊 خواندن»، از `edge-tts` و صدای Microsoft Neural
`fa-IR-DilaraNeural` استفاده می‌شود. این صدا **صدای نصب‌شده روی گوشی نیست** و
نباید از تنظیمات Android آن را نصب کنید.

در Pydroid فقط یک بار اجرا کنید:

```bash
pip install -U edge-tts aiohttp
```

سپس Web GUI را اجرا کنید. با زدن دکمه «🔊 خواندن» زیر پاسخ AI، TRX متن همان
پاسخ را با صدای Microsoft Neural تولید کرده و به مرورگر می‌فرستد؛ فایل MP3
روی دیسک پروژه ذخیره نمی‌شود.

اگر `edge-tts` نصب نباشد، برنامه باید پیام «edge-tts نصب نیست» بدهد؛ نباید
پیام «صدای فارسی دستگاه را نصب کنید» نمایش دهد.

## Conversation Pattern Engine v2

TRX AI now learns interaction patterns from multi-turn conversations. The pattern engine extracts dialogue act, user need, emotion profile, topic signals, conversation arc, sentiment direction and response strategy. It persists compact patterns locally and retrieves relevant ones for future LLM prompts without adding a heavy dependency.


## قابلیت‌های ارتقایافته v21

### پزشکی هوشمند
- پرسش‌های تکمیلی چندمرحله‌ای برای افزایش کیفیت تحلیل علائم.
- ترکیب دانش محلی و منابع پزشکی آنلاین در صورت فعال بودن.
- استفاده: از بخش پزشکی سؤال را با علائم، مدت، شدت، سن و سابقه ارسال کنید.

### گفتگوی عمیق و الگو سازی
- تشخیص بهتر درد دل، نگرانی، شادی و نیاز کاربر.
- استفاده: گفتگو را طبیعی ادامه دهید؛ موتور الگوهای مکالمه را برای پاسخ مناسب‌تر استفاده می‌کند.

### قابلیت‌های جدید
1. حالت پرسش‌گر تطبیقی پزشکی: قبل از نتیجه‌گیری اطلاعات کمبود را درخواست می‌کند.
2. حافظه سبک احساسی گفتگو: سبک پاسخ را بر اساس روند گفتگو تنظیم می‌کند.


## ارتقای موتور پزشکی v21.2 — Medical Precision Upgrade

- اضافه شدن جمع‌آوری اطلاعات تکمیلی قبل از تحلیل علائم: سن، مدت علائم، شدت، سابقه بیماری، داروها و عوامل خطر.
- بهبود امتیازدهی احتمال‌ها با ترکیب چند علامت به جای تطبیق یک کلمه.
- مقایسه چند احتمال نزدیک و توضیح تفاوت‌های کلیدی آن‌ها.
- اولویت بالاتر برای علائم هشدار و جلوگیری از اطمینان کاذب.
- تولید سؤال بعدی هوشمند برای کاهش ابهام پزشکی.
- جداسازی اطلاعات عمومی سلامت از تشخیص قطعی پزشکی.


## Gemini Vision / OCR
Gemini API key can be supplied through GEMINI_API_KEY, GOOGLE_API_KEY, TRX_GEMINI_API_KEY, or a local `gemini_key.txt` file in the project root. Do not commit a real key. The image viewer/OCR routes use the same Gemini Vision transport.
