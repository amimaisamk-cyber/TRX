# زیرساختِ مدلِ بومیِ TRX — `trx_ai/trx_model/` (v25.4.4)

## خواسته

سندِ معماریِ TRX (بخش‌هایِ ۱۱ تا ۱۳) این pipeline را به‌عنوانِ «مدلِ
اختصاصیِ TRX» تعریف کرده بود:

```
متن -> Tokenizer -> Embedding -> Transformer Core -> پیش‌بینیِ توکن -> متن
```

و صریحاً خواسته بود که این مسیر **مستقل از خودِ TRX** پیاده شود (بخشِ
۱۱: «TRX → Intelligence Runtime → Model Adapter → Model») تا در آینده
مدل قابلِ تعویض باشد، بدونِ آنکه بقیه‌ی سیستم بازنویسی شود.

## چرا یک پکیجِ کاملاً جدا (`trx_ai/trx_model/`) و نه تغییرِ `intelligence.py`؟

دقیقاً همان استدلالِ pattern-یِ موجود در پروژه (`AGENT_LOOP_NOTES.md`،
`COGNITION_CORE_NOTES.md`): تولیدِ متنِ فعلیِ چت از مسیرِ دیگری
(`core.py` + موتورهایِ NLU/response موجود) عبور می‌کند و اصلاً به این
تغییر نیازی نداشت. این‌جا مسئله «جایگزینیِ چیزی موجود» نبود، بلکه
«ساختنِ زیرساختی که هنوز وجود نداشت» بود -- پس طبقِ قانونِ قرمزِ ۱
(حذف/جایگزینیِ ممنوع بدونِ معادلِ قوی‌ترِ تست‌شده)، هیچ فایلِ موجودی
تغییر نکرد؛ فقط اضافه شد.

## چه چیزی واقعاً پیاده شده (نه ادعا -- قابلِ اجرا و تست)

| فایل | مسئولیت |
|---|---|
| `tokenizer.py` | BPE سطحِ بایت: `train`/`encode`/`decode`/`save`/`load`. Lossless برایِ هر متنِ UTF-8 (فارسی/انگلیسی/کد/اعداد/اموجی) -- بخشِ ۱۲-الفِ سند. |
| `transformer_core.py` | `RMSNorm`، `precompute_rope`/`apply_rope`، `CausalSelfAttention` (ماسکِ علّیِ واقعی)، `SwiGLUFeedForward`، `TransformerBlock` -- دقیقاً درسِ Qwen در بخشِ ۵ سند. |
| `model.py` | `TRXModelConfig` + `TRXNativeModel`: embedding -> N×block -> RMSNorm -> output head (وزنِ tied با embedding) -> logits. `generate()` حلقه‌ی autoregressive واقعی. `save_weights`/`load_weights`. |
| `interfaces.py` | `ModelInterface` (ABC) -- قراردادِ contract-based بخشِ ۹ سند. |
| `model_adapter.py` | `TRXNativeModelAdapter(ModelInterface)` -- پنهان‌سازیِ tokenizer+model پشتِ `generate(text) -> text`؛ بخشِ ۱۱ سند. |
| `scripts/train_native_tokenizer.py` | آموزشِ توکنایزرِ پیش‌فرض رویِ پیکره‌یِ واقعیِ خودِ پروژه (تمامِ `*.md` ریشه، ۲۲ فایل/۱۸۳٬۴۴۰ کاراکتر) -- بدونِ اینترنت/دیتاستِ بیرونی. خروجی در `trx_ai/trx_model/data/tokenizer.json` (~۷.۶ کیلوبایت، ۹۰۰ توکن). |
| `tests/test_native_model.py` | ۲۰ تستِ واحد (جزئیات پایین‌تر). |

هر فرمولِ ریاضیِ اینجا واقعاً با numpy اجرا می‌شود -- نه mock، نه
placeholder. مثال‌هایِ قابلِ اثبات:

- `decode(encode(x)) == x` برایِ هر رشته (byte-level BPE ذاتاً lossless
  است -- تست شده رویِ فارسی/انگلیسی/کد/اموجی).
- RoPE واقعاً یک چرخش است: نُرمِ بردار را حفظ می‌کند (تست‌شده).
- ماسکِ علّی واقعاً کار می‌کند: تغییرِ آخرین توکنِ ورودی، logits
  موقعیت‌هایِ قبلی را تغییر نمی‌دهد، فقط موقعیتِ خودش را (تست‌شده --
  این دقیقاً معنایِ ریاضیِ «پیش‌بینیِ توکنِ بعدی بدونِ دیدنِ آینده»ست).
- ساختنِ مدل با یک seedِ ثابت، همیشه همان وزن‌ها و همان forward pass
  را می‌دهد (تست‌شده) -- بازتولیدپذیری، نه رفتارِ تصادفیِ پنهان.

## چه چیزی عمداً پیاده **نشده** (گزارشِ صادقانه‌یِ scope)

- **آموزش (Stage 14 سند):** هیچ loss function، optimizer، backprop یا
  pretraining loop وجود ندارد. وزن‌ها با seed تصادفی مقداردهیِ اولیه
  شده‌اند. `generate()` واقعاً forward pass و نمونه‌برداری انجام
  می‌دهد، اما چون وزن‌ها آموزش‌ندیده‌اند خروجی زبانیِ بی‌معنی خواهد بود
  -- این محدودیت، نه یک باگ، بلکه مرزِ صریحِ همین مرحله است.
- **Batch/GPU/بهینه‌سازیِ کارایی:** `forward` فقط یک دنباله در هر
  فراخوانی می‌پذیرد (numpy رویِ CPU). طبقِ بخشِ ۱۳ سند («Scaling نباید
  قبل از correctness باشد»)، این مرحله عمداً بهینه‌سازی نشده.
- **اتصال به مسیرِ پاسخِ چت:** `TRXNativeModelAdapter` جایی در
  `core.py`/`intelligence.py` صدا زده نمی‌شود. تصمیمِ صریح (طبقِ
  انتخابِ کاربر): این نسخه فقط «زیرساخت»، نه «جایگزینیِ چیزی که الان
  متن تولید می‌کند».
- **Knowledge Graph / Memory-vs-Knowledge (بخش‌هایِ ۱۶-۱۷ سند):** خارج
  از scope همین افزودن.

## تست‌ها (۲۰ مورد در `tests/test_native_model.py`)

دسته‌بندی: tokenizer (۶ تست: pre-tokenize، round-trip قبل/بعدِ آموزش،
قطعیتِ آموزش، سازگاریِ vocab_size، ذخیره/بارگذاری) + هسته‌ی عددی (۲
تست: RMSNorm، حفظِ نُرم توسطِ RoPE) + مدل (۸ تست: شکلِ خروجی، ردِ ورودیِ
خارج‌ازبازه، ردِ batch، **علّیتِ واقعیِ ماسک**، قطعیتِ ساخت، ذخیره/
بارگذاریِ وزن، طولِ generate) + adapter (۳ تست: رعایتِ `ModelInterface`،
end-to-end generate، ردِ ناسازگاریِ vocab_size).

اجرا (نیازمندِ `pytest` -- ر.ک. `requirements-dev.txt`؛ در محیطِ
sandboxِ بدونِ اینترنتِ این نشست pytest در دسترس نبود، پس هر ۲۰ مورد
به‌صورتِ دستی/مستقیم هم اجرا و پاس شدند، جزئیات در تاریخچه‌ی جلسه):

```bash
pytest tests/test_native_model.py -v
```

## چگونه در آینده به Stage 14 (آموزش) می‌رسیم

مسیرِ بعدی (خارج از این افزودن): `loss.py` (cross-entropy رویِ
logits/next-token)، `optimizer.py` (SGD/Adam ساده -- همچنان با numpy
یا معرفیِ صریحِ یک وابستگیِ سنگین‌تر مثلِ torch با بحثِ جداگانه)،
`train.py` (حلقه‌ی pretraining رویِ پیکره‌یِ بزرگ‌تر). طبقِ بخشِ ۱۴-۱۵
سند، پیش از هر آموزشی، کیفیتِ داده (تکرار/تناقض/نویز) باید بررسی شود.

## معیارِ عبور (طبقِ بخشِ ۴۰ سند)

Implementation ✅ · Tests ✅ (۲۰/۲۰) · Documentation ✅ (همین فایل) ·
Regression Check ✅ (هیچ فایلِ موجودی تغییر نکرد؛ فقط افزوده شد).
