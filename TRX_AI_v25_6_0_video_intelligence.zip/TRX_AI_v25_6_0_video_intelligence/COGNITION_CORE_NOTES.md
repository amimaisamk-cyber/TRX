# لایه‌یِ Cognition Core (بخشِ ۲ سندِ ارتقا) -- v1

## خواسته (خلاصه‌یِ سندِ ورودی)

سند (`TRX AI — COGNITION CORE UPGRADE`) خواسته بود که TRX در نگاهِ
کاربر «یک AI که در صورتِ نیاز از Web استفاده می‌کند» باشد، نه «یک
مرورگرِ هوشمند». اصلِ بنیادی: **AI CORE > AGENT > TOOLS**، نه
**WEB > AGENT > ANSWER**. راه‌حلِ پیشنهادیِ سند: یک لایه‌ی مرکزیِ جدید
(`Understanding → Context → Reasoning → Planning → Agent → Reflection
→ Response`) که *قبل* از هر انتخابِ ابزار «فکر کند».

## چرا یک پکیجِ جدا (`trx_ai/agent/cognition/`) و نه تغییرِ مستقیمِ `planner.py`؟

دقیقاً همان استدلالِ `AGENT_LOOP_NOTES.md` درباره‌یِ خودِ `trx_ai/agent/`:
جداییِ مسئولیت. `HeuristicPlanner` (در `planner.py`) کارش «امتیازدهیِ
کلیدواژه‌ایِ ابزارها» است و این کار را خوب انجام می‌دهد -- مشکلِ سند
این نبود که امتیازدهی بد است، بلکه این بود که **هیچ گامِ فکریِ قبل از
آن** وجود نداشت. پس به‌جایِ بازنویسیِ `planner.py`/`tool_registry.py`:

- `trx_ai/agent/cognition/` یک لایه‌ی *بالادستیِ* کاملاً جداست.
- `AgentLoop` (و همه‌ی گاردریل/Scratchpad/Reflectionِ موجودش)
  دست‌نخورده می‌ماند -- `AgentController` (در `decision.py`) فقط آن را
  چندبار (یک‌بار به‌ازایِ هر گامِ برنامه) با یک `allowed_tools` فیلترشده
  صدا می‌زند.
- تنها نقطه‌ی اتصال به کدِ موجود، همان قلابِ از-قبل-موجودِ
  `llm_decide` در `planner.py` است (نگاه کنید به بخشِ زیر) -- یعنی
  حتیِ `planner.py` هم نیازی به تغییرِ ساختاری نداشت.
- در `core.py`، `_handle_agent_task` به‌جایِ ساختنِ مستقیمِ
  `AgentLoop(...)`، حالا `CognitionCore(...)` می‌سازد. خروجی هنوز
  همان `AgentTrace` قبلی است -- بقیه‌ی `core.py` (نمایشِ trace، ثبتِ
  تاریخچه) هیچ تغییری نخواست.

## معماریِ ماژولار (هشت مسئولیتِ جدا، دقیقاً بخشِ ۳ سند)

```
trx_ai/agent/cognition/
├── state.py           CognitionState (۱۱ حالتِ بخشِ ۱۵) + CognitionStateTracker
├── understanding.py    Understanding: intent (رویِ IntentEngine) + user_state/
│                        phase/strategy (رویِ understanding.py قدیمی) + request_kind جدید
├── context.py           ContextEngine: ترکیبِ Scratchpad + موضوعِ فعال
├── reasoning.py          ReasoningEngine: «نیاز به ابزار؟ Web مجاز است؟» -- قلبِ سند
├── planning.py            PlanningEngine: تجزیه‌ی هدف به مرحله(ها)
├── decision.py             AgentController: اجرایِ Plan رویِ AgentLoop موجود
├── reflection.py            CognitionReflector: ارزیابیِ واقعیِ نتیجه + کاندیدِ Replan
└── response.py               ResponseEngine: پاسخِ طبیعی (گفتگو یا ترکیبِ گام‌ها)

__init__.py: CognitionCore -- هماهنگ‌کننده‌ی نهایی (Understanding→...→Response)
```

هیچ‌کدام NLU را از صفر بازنویسی نکردند (بخشِ ۳.۱ سند: «نباید صرفاً
keyword matching باشد») -- `understanding.py` رویِ `IntentEngine` و
`trx_ai.understanding.build_understanding` (از یک سندِ ارتقایِ قبلی)
سوار است؛ `response.py` رویِ `response_strategy.reply_hint` سوار است.

## `reasoning.py` -- پیاده‌سازیِ مستقیمِ NEVER_USE_WEB_BY_DEFAULT (بخشِ ۱۱)

قانون به این ترتیب چک می‌شود (اولین موردِ منطبق برنده است):

1. **گفتگو/احساسِ محض** (بدونِ هیچ سرنخِ کاری) → `needs_tool=False`،
   هیچ ابزاری صدا زده نمی‌شود. (TEST1 سند)
2. **سرنخِ محلیِ صریح** (کد/فایل/محاسبه/ترجمه/هوا/تسک) → همان ابزار،
   Web صریحاً از allowed-set حذف می‌شود. (TEST2 سند)
3. **نیازِ زنده/صریح** (STRONG: «قیمت/نرخ/اخبار/آخرین/جدیدترین»؛ یا
   WEAK زمانی مثلِ «امروز/الان» *فقط* همراهِ یک نشانه‌ی پرسشِ صریح) یا
   درخواستِ صریحِ «جستجو کن» → Web مجاز. (TEST5 سند)
4. **پرسشِ دانشیِ عمومی** («چیست»/«کیست») → هم دانشِ محلی هم Web مجازند؛
   کدام واقعاً انتخاب می‌شود همچنان با رتبه‌بندیِ طبیعیِ
   `ToolRegistry.rank` است -- اینجا فقط اجازه داده می‌شود، تحمیل نمی‌شود.
5. **پیش‌فرضِ نهایی**: هیچ‌کدامِ بالا -- ابزار امتحان می‌شود ولی Web
   کنار گذاشته می‌شود. این دقیقاً معنیِ «NEVER_USE_WEB_BY_DEFAULT» است:
   سکوت/ابهام هرگز به معنیِ «پس برو تو وب بگرد» نیست.

نکته‌ی مهمِ پیاده‌سازی: مرحله‌ی ۳ عمداً «امروز»/«الان» را به‌تنهایی
کافی نمی‌داند -- «امروز خیلی خسته‌ام» نباید Web را فعال کند، ولی
«قیمتِ امروزِ دلار چنده؟» باید. برایِ همین بازارهایِ زمانی به دو سطحِ
STRONG/WEAK تقسیم شدند (نگاه کنید به `_is_live_info` در `reasoning.py`).

`preferred_tool` صرفاً یک *سرنخ* برای `planner.py` نیست -- واقعاً اثر
دارد: `decision.py` از همان قلابِ اختیاریِ `llm_decide` که
`AgentPlanner` از قبل برایِ اتصالِ یک LLM طراحی کرده بود استفاده
می‌کند (نگاه کنید به `AGENT_LOOP_NOTES.md`)، و در اولین تصمیمِ هر
زیرگام، پیشنهادِ Reasoning Engine را به‌جایِ heuristic تزریق می‌کند --
اگر ابزارِ پیشنهادی در دسترس نبود یا شکست خورد، بی‌صدا به heuristicِ
معمولی سقوط می‌کند.

## `planning.py` -- تجزیه‌ی هدف، نه بازنویسیِ اجرا (بخشِ ۶)

فقط وقتی `ReasoningEngine` تشخیص دهد جمله واقعاً چندبخشی است (اتصال‌
دهنده‌هایِ «و بعد»/«سپس»/«؛»/«و همچنین»)، هدف به حداکثر ۴ زیرگام
(`MAX_PLAN_STEPS`، محدودیتِ گوشی طبقِ بخشِ ۲۶) تقسیم می‌شود. هر زیرگام
جداگانه رویِ `AgentLoop` اجرا می‌شود و نتیجه‌ی گامِ قبل به‌عنوانِ زمینه
به گامِ بعد پاس داده می‌شود (`decision.py`).

## `reflection.py` + Replan محدود (بخشِ ۸ و ۲۵)

`CognitionReflector` فقط `success=True/False` را قبول نمی‌کند؛ چک
می‌کند آیا شکست به‌خاطرِ *نبودِ Web* بود (یعنی Web از آن گام حذف شده
بود *و* هیچ ابزارِ دیگری هم جواب نداد). اگر بله و بودجه باقی مانده،
`CognitionCore` **یک‌بار** همان گام(ها) را با Web مجاز دوباره اجرا
می‌کند -- Error Recovery، نه شکستِ کاملِ بی‌بازگشت.

## نقطه‌ی اتصال در `core.py`

فقط یک خط عوض شد: `AgentLoop(registry, AgentConfig(verbose=False)).run(goal)`
→ `CognitionCore(registry, AgentConfig(verbose=False)).run(goal, ai=self, db=self.db)`.
شکلِ خروجی (`AgentTrace`) عیناً همان است، پس نمایشِ trace/ثبتِ
تاریخچه در `core.py` نیازی به تغییر نداشت.

## چگونه بدونِ رابطِ کاربری استفاده کنیم

```python
from trx_ai.agent import AgentConfig, build_default_registry, CognitionCore

registry = build_default_registry(ai)  # ai = نمونه‌ی TRXEnterpriseAI
trace = await CognitionCore(registry, AgentConfig(max_steps=6)).run(
    "این پروژه رو بررسی کن و بعدش مشکل اصلی رو پیدا کن.",
    ai=ai, db=ai.db,
)
print(trace.final_answer)
```

## تست‌ها

`tests/test_cognition_core.py` (بدونِ شبکه/دیتابیسِ واقعی، مثلِ
`test_agent_loop.py`) -- دقیقاً مثال‌هایِ رفتاریِ بخشِ ۱۸ سند را پوشش
می‌دهد:

- `ReasoningEngine.assess`: TEST1 (گفتگو)، TEST2 (کد، بدونِ Web)،
  TEST5 (اطلاعاتِ زنده، Web مجاز)، ابهام (NEVER_USE_WEB_BY_DEFAULT)،
  TEST6 (تشخیصِ چندمرحله‌ای)
- `PlanningEngine.build_plan`: تک‌مرحله‌ای در برابرِ چندمرحله‌ای
- `CognitionCore.run` سرتاسری: همان موارد + **تستِ «بدونِ Web»ِ بخشِ
  ۲۱ سند** (رجیستری اصلاً `web_search` ندارد و گفتگو/تحلیلِ کد باید
  همچنان کار کنند) + هدفِ خالی

اجرا (پس از نصبِ `pytest`، که در این محیطِ آفلاین در دسترس نبود --
تست‌ها به‌صورتِ دستی/بدونِ pytest هم اجرا و تأیید شدند):

```bash
pytest tests/test_cognition_core.py -v
```

## Definition of Done سند (بخشِ ۳۱) -- وضعیتِ واقعی

| بند | وضعیت |
|---|---|
| AI Core مرکزِ تصمیم‌گیری | ✅ `CognitionCore` قبل از هر ابزاری اجرا می‌شود |
| Web فقط یک Capability | ✅ `ReasoningEngine` -- NEVER_USE_WEB_BY_DEFAULT |
| Conversation بدونِ Web | ✅ (تست شد) |
| Memory بدونِ Web | ✅ (ContextEngine/Scratchpad ابزار نیستند) |
| Code Analysis بدونِ Web | ✅ (تست شد) |
| File Analysis بدونِ Web | ⚠️ الگوی regexِ آماده هست (`file_read` در `_LOCAL_TOOL_PATTERNS`)، ولی تستِ اختصاصی نوشته نشد |
| Planning بدونِ Web | ✅ `PlanningEngine` هیچ وابستگی‌ای به Web ندارد |
| Agent چندمرحله‌ای | ✅ `PlanningEngine` + `AgentController` (تست شد) |
| Reflection واقعی | ✅ `CognitionReflector` (نه صرفاً `True`) |
| Replan | ⚠️ فقط یک‌بار و فقط برایِ حالتِ خاصِ «Web نبود» -- Replanِ عمومی (مثلاً تعویضِ ابزار در شکست‌هایِ غیرِ-Web) هنوز نیست |
| Tool Failure قابلِ بازیابی | ✅ از طریقِ `LoopGuard`/`AgentLoop` موجود (تغییری نکرد) |
| Context در مکالمه | ✅ (v25.4.0) `ContextEngine` حالا از `ai.memory.get_context`/`get_relevant_memory`/`current_topic` هم تغذیه می‌شود، نه فقط `entity_stack`؛ `ReasoningEngine.assess` هم واقعاً `context` را می‌خواند. جزئیات در `CONTEXT_CORE_UPGRADE_NOTES.md`. باقی‌مانده: تاریخچه هنوز به ۶ پیامِ آخر محدود است، نه کلِ مکالمه |
| API اجباری نیست | ✅ (چیزی در این لایه به API وابسته نیست) |
| قابلیت‌هایِ قبلی حذف نشدند | ✅ `AgentLoop`/`planner.py`/`tool_registry.py` دست‌نخورده‌اند |
| Persian Interpreter حفظ شد | ✅ (این لایه کاری با آن نداشت) |
| UI متمرکز بر Conversation | ➖ خارج از محدوده‌ی این فاز (فقط Backend) |
| Agent State قابلِ‌دیباگ | ✅ `CognitionStateTracker.format_trace_fa()` |
| تست‌هایِ Multi-Step | ✅ |
| تستِ کاملِ بدونِ Web | ✅ (یک تستِ سطحِ‌بالا؛ بنچمارکِ کاملِ ۳۰-موردیِ بخشِ ۱۹ سند نوشته نشد) |

## محدودیت‌هایِ آگاهانه‌یِ این نسخه (v1)

- **بنچمارکِ رسمیِ بخشِ ۱۹/۲۱ سند** (۳۰+ درخواست در ۱۱ دسته، با ثبتِ
  «آیا Web لازم بود/استفاده شد») نوشته نشد -- فقط معادلِ کوچک‌ترش در
  `tests/test_cognition_core.py` هست. این طبیعتاً فازِ بعدی است.
- الگوهایِ `_LOCAL_TOOL_PATTERNS`/`_is_live_info` در `reasoning.py`
  کاملاً regex-based و فارسی‌محورند (هم‌سبکِ بقیه‌ی پروژه)؛ مثلِ هر
  heuristicی، جمله‌هایِ غیرمعمول ممکن است اشتباه دسته‌بندی شوند --
  دقیقاً به همان دلیلِ `HeuristicPlanner` که قلابِ `llm_decide` برایِ
  آینده باز گذاشته شده (این لایه هم از همان قلاب استفاده می‌کند).
- ~~`ContextEngine` فعلاً فقط `ai.memory.entity_stack` را می‌خواند~~
  **رفع شد در v25.4.0** -- رجوع به `CONTEXT_CORE_UPGRADE_NOTES.md`.
  باقی‌مانده: سقفِ ۶ پیامِ آخر (نه کلِ مکالمه)، و `AgentBridge.
  handle_task` هنوز تستِ سرتاسریِ خودش را ندارد (فقط اجزایِ زیرینش
  -- `ContextEngine`/`ReasoningEngine` -- پوشش دارند).
- `CognitionReflector` تشخیصِ «اطلاعاتِ متناقض» (یکی از سؤال‌هایِ
  صریحِ بخشِ ۸) را پیاده نکرده -- فقط شکست/موفقیت و علتِ نبودِ Web را
  چک می‌کند.
