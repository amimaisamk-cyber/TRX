# -*- coding: utf-8 -*-
"""
تست‌های واحد برای GuiUIEngine (trx_ai/gui_ui_engine.py) — فقط بخشِ
غیرِ‌Qt (صفِ رویداد، تبدیلِ رندرهای rich به متنِ ساده، تبدیلِ ارقام).
هیچ‌کدام از این تست‌ها نیازی به PySide6 یا نمایشگر ندارند.
"""

import asyncio

import pytest

pytest.importorskip("rich", reason="نیازمندِ rich (طبق requirements.txt)")

from trx_ai.gui_ui_engine import GuiUIEngine


@pytest.fixture()
def engine():
    return GuiUIEngine()


def _drain(engine):
    events = []
    while not engine.events.empty():
        events.append(engine.events.get_nowait())
    return events


def test_console_print_strips_rich_markup(engine):
    engine.console.print("[bold cyan]سلام[/bold cyan] دنیا")
    events = _drain(engine)
    assert len(events) == 1
    assert events[0].kind == "raw"
    assert "[bold" not in events[0].payload["text"]
    assert "سلام" in events[0].payload["text"] and "دنیا" in events[0].payload["text"]


def test_show_header_emits_status_event(engine):
    engine.show_header("علی", "رسمی", "پروژه‌ی من")
    events = _drain(engine)
    assert len(events) == 1
    assert events[0].kind == "status"
    assert events[0].payload["user"] == "علی"
    assert events[0].payload["personality"] == "رسمی"


def test_show_guide_emits_rows(engine):
    engine.show_guide()
    events = _drain(engine)
    assert len(events) == 1
    assert events[0].kind == "guide"
    assert len(events[0].payload["rows"]) > 0


def test_animated_print_emits_message_event(engine):
    asyncio.run(engine.animated_print("متنِ پاسخ", "عنوانِ تست", "cyan"))
    events = _drain(engine)
    assert len(events) == 1
    assert events[0].kind == "message"
    assert events[0].payload["text"] == "متنِ پاسخ"
    assert events[0].payload["title"] == "عنوانِ تست"


def test_show_emergency_and_followup_emit_distinct_event_kinds(engine):
    engine.show_emergency("پیامِ اورژانسی")
    engine.show_followup_question("سؤالِ پیگیری")
    events = _drain(engine)
    kinds = [e.kind for e in events]
    assert kinds == ["emergency", "followup"]


def test_voice_events(engine):
    engine.voice_prompt()
    engine.voice_saved("/tmp/out.mp3")
    engine.voice_failed()
    events = _drain(engine)
    kinds = [e.kind for e in events]
    assert kinds == ["voice_prompt", "voice_saved", "voice_failed"]
    assert events[1].payload["path"] == "/tmp/out.mp3"


def test_status_context_manager_emits_start_and_end(engine):
    with engine.thinking("در حال بررسی..."):
        pass
    events = _drain(engine)
    assert [e.kind for e in events] == ["status_start", "status_end"]
    assert events[0].payload["label"] == "در حال بررسی..."


def test_digit_and_date_helpers_match_terminal_ui_engine(engine):
    assert engine.e2f(123) == "۱۲۳"
    assert engine.f2e("۱۲۳") == "123"
    date_str, time_str = engine.get_farsi_date_time()
    assert date_str and time_str
