# -*- coding: utf-8 -*-
"""
تست‌هایِ ``nlu/multi_intent.py`` و ``nlu/disambiguator.py``.

به‌روزرسانی (ارتقایِ وایرینگِ ابهام): ``disambiguator.py`` دیگر «وایر
نشده» نیست -- ``core_engine/tool_router.py`` و ``core_engine/turn_processor.py``
اکنون واقعاً از ``should_ask_followup``/``build_followup_question`` و
تابعِ تازه‌ی ``match_clarification_reply`` استفاده می‌کنند (نگاه کنید به
``tests/test_ambiguity_disambiguation_wiring.py`` برایِ تستِ end-to-endِ
همین اتصال). این فایل هم‌چنان مسئولِ قفل‌کردنِ رفتارِ *خامِ* هر تابع
(بدونِ نیاز به ``TRXEnterpriseAI`` کامل) است.

``multi_intent.py`` هنوز طبقِ توضیحِ قبلی وایر نشده (منتظرِ پشتیبانیِ
چندنیتی در core.py) -- این بخش از توضیح هنوز صادق است.
"""
from __future__ import annotations

import pytest

from trx_ai.nlu.disambiguator import (
    DEFAULT_MARGIN_THRESHOLD,
    build_followup_question,
    match_clarification_reply,
    should_ask_followup,
)
from trx_ai.nlu.multi_intent import split_clauses, split_intents
from trx_ai.nlu.scorer import detect


# ---------------------------------------------------------------------------
#   disambiguator.py
# ---------------------------------------------------------------------------
def test_should_ask_followup_true_when_top_two_are_close():
    ranked = [("weather", 0.50), ("currency", 0.48)]
    assert should_ask_followup(ranked) is True


def test_should_ask_followup_false_when_clear_winner():
    ranked = [("weather", 0.90), ("currency", 0.10)]
    assert should_ask_followup(ranked) is False


@pytest.mark.parametrize("ranked", [
    [],
    [("weather", 0.9)],
])
def test_should_ask_followup_false_with_fewer_than_two_candidates(ranked):
    assert should_ask_followup(ranked) is False


def test_should_ask_followup_false_when_best_score_is_zero():
    # هر دو صفرند -- یعنی اصلاً سرنخی نبوده، نه اینکه ابهامِ واقعی باشد.
    assert should_ask_followup([("weather", 0.0), ("currency", 0.0)]) is False


def test_should_ask_followup_respects_custom_margin_threshold():
    ranked = [("weather", 0.60), ("currency", 0.50)]  # margin = 0.166..
    assert should_ask_followup(ranked, margin_threshold=0.10) is False
    assert should_ask_followup(ranked, margin_threshold=0.20) is True


def test_build_followup_question_uses_friendly_names():
    q = build_followup_question(("weather", "currency"))
    assert "آب‌وهوا" in q
    assert "قیمتِ ارز/طلا" in q
    assert q.endswith("؟")


def test_build_followup_question_falls_back_to_raw_name_for_unknown_intent():
    q = build_followup_question(("some_new_intent", "weather"))
    assert "some_new_intent" in q
    assert "آب‌وهوا" in q


def test_default_margin_threshold_is_a_reasonable_fraction():
    assert 0.0 < DEFAULT_MARGIN_THRESHOLD < 1.0


def test_match_clarification_reply_matches_intent_id_directly():
    assert match_clarification_reply("weather", ("weather", "currency")) == "weather"


def test_match_clarification_reply_matches_friendly_persian_name():
    assert match_clarification_reply("همون آب‌وهوا رو میگم", ("weather", "currency")) == "weather"


def test_match_clarification_reply_returns_none_when_unclear():
    assert match_clarification_reply("نه هیچ‌کدوم، یه چیز دیگه", ("weather", "currency")) is None


def test_match_clarification_reply_returns_none_for_empty_reply():
    assert match_clarification_reply("", ("weather", "currency")) is None
    assert match_clarification_reply("   ", ("weather", "currency")) is None


# ---------------------------------------------------------------------------
#   multi_intent.py
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected_clause_count", [
    ("هوای تهران چطوره و دلار چنده؟", 2),
    ("هوای تهران چطوره، دلار چنده، ساعت چنده؟", 3),
    ("پایتون چیست", 1),
    ("", 0),
])
def test_split_clauses_splits_on_common_conjunctions(text, expected_clause_count):
    assert len(split_clauses(text)) == expected_clause_count


def test_split_intents_returns_both_intents_for_two_clause_sentence():
    results = split_intents("هوای تهران چطوره و دلار چنده؟", detect_fn=detect)
    intents = {r.intent for r in results}
    assert intents == {"weather", "currency"}


def test_split_intents_falls_back_to_whole_sentence_for_single_intent():
    """یک جمله‌ی تک‌بندی نباید به‌زور شکسته شود -- خروجی باید دقیقاً همان
    چیزی باشد که ``detect`` مستقیم می‌داد (رفتارِ قبل از این قابلیت)."""
    text = "پایتون چیست"
    direct = detect(text)
    (only,) = split_intents(text, detect_fn=detect)
    assert only.intent == direct.intent
    assert only.confidence == direct.confidence


def test_split_intents_dedupes_repeated_intent_across_clauses():
    """اگر دو بند به یک نیتِ یکسان برسند، فقط یک‌بار در خروجی می‌آید."""
    results = split_intents("هوای تهران چطوره و هوای شیراز چطوره؟", detect_fn=detect)
    intents = [r.intent for r in results]
    assert intents.count("weather") <= 1


def test_split_intents_ignores_weak_clauses_and_falls_back():
    """اگر هیچ بندی به‌تنهایی نیتِ قوی نداد، به نمره‌دهیِ کلِ جمله
    برمی‌گردد (نه لیستِ خالی) -- طبقِ مستندِ خودِ تابع."""
    results = split_intents("سلام و خداحافظ", detect_fn=detect)
    assert len(results) >= 1
