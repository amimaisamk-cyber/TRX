# -*- coding: utf-8 -*-
"""
تست‌هایِ Pattern Bridge -- v25.5.6.

سندِ ارتقا (پیامِ امیر) این چک‌لیست را برایِ قبولیِ v25.5.6 خواسته:

    Pattern Engine واقعاً فراخوانی شد        ✓
    pattern_context تولید شد                 ✓
    Coordinator آن را دریافت کرد             ✓
    UnifiedContext آن را نگه داشت             ✓
    A/B دو context متفاوت ساخت                ✓
    خطای Pattern باعث crash نشد               ✓
    Final Decision تغییر نکرد                 ✓

هر ردیف دقیقاً یک تستِ جداگانه در ادامه دارد. آزمایشِ C («اگر
pattern_context را عمداً حذف کنیم، پاسخ عوض می‌شود؟») عمداً اینجا نیست
-- طبقِ توافق، برایِ نسخه‌ای است که Coordinator از SHADOW خارج شود.
"""

from __future__ import annotations

import pytest

from trx_ai import conversation_patterns as cp_mod
from trx_ai.conversation import conversation_engine, state_tracker
from trx_ai.nervous_system import config as ns_config
from trx_ai.nervous_system import get_coordinator, pattern_bridge
from trx_ai.nervous_system.influence_audit import classify_pattern_engine_wiring


@pytest.fixture(autouse=True)
def _nervous_system_on(monkeypatch):
    """این فایل صرفاً وقتی معنا دارد که Coordinator روشن باشد."""
    monkeypatch.setattr(ns_config, "NERVOUS_SYSTEM_ENABLED", True, raising=False)
    yield


def _fresh(cid: str):
    state_tracker.reset_snapshot(cid)
    yield cid
    state_tracker.reset_snapshot(cid)


@pytest.fixture
def cid_a():
    yield from _fresh("pytest_pattern_v25_5_6_A")


@pytest.fixture
def cid_b():
    yield from _fresh("pytest_pattern_v25_5_6_B")


# ----------------------------------------------------------------------
#  1) Pattern Engine واقعاً فراخوانی شد + 2) pattern_context تولید شد
# ----------------------------------------------------------------------
def test_pattern_engine_is_really_called_via_real_classmethod(monkeypatch):
    """پچ نمی‌کنیم؛ خودِ ``ConversationPatternEngine.build_pattern`` واقعی صدا زده می‌شود."""
    calls = []
    real_build_pattern = cp_mod.ConversationPatternEngine.build_pattern.__func__

    def _spy(cls, *a, **k):
        calls.append((a, k))
        return real_build_pattern(cls, *a, **k)

    monkeypatch.setattr(cp_mod.ConversationPatternEngine, "build_pattern", classmethod(_spy))

    result = pattern_bridge.build_pattern_context("یه جوک بگو", [])
    assert len(calls) == 1, "build_pattern باید دقیقاً یک‌بار صدا زده شود"
    assert result is not None
    assert "signature" in result and "type" in result and "emotion" in result


# ----------------------------------------------------------------------
#  3) Coordinator آن را دریافت کرد + 4) UnifiedContext آن را نگه داشت
# ----------------------------------------------------------------------
def test_coordinator_receives_and_stores_pattern_engine_output(cid_a):
    coordinator = get_coordinator()
    result = conversation_engine.process("یه جوک بگو", conversation_id=cid_a, recent_messages=[])
    assert result is not None

    ctx = coordinator.get_latest(cid_a)
    assert ctx is not None
    assert ctx.pattern_context.get("engine") is not None, (
        "خروجیِ Pattern Engine باید داخلِ pattern_context['engine'] ذخیره شده باشد"
    )
    assert ctx.pattern_context.get("long_term_pattern_wired") is True


# ----------------------------------------------------------------------
#  5) A/B دو context متفاوت ساخت
# ----------------------------------------------------------------------
def test_ab_experiment_produces_different_pattern_context(cid_a, cid_b):
    """دقیقاً سناریویِ خواسته‌شده: A = فقط درخواستِ جوک، B = همان + فیدبکِ منفی."""
    coordinator = get_coordinator()

    result_a = conversation_engine.process("یه جوک بگو", conversation_id=cid_a, recent_messages=[])
    result_b = conversation_engine.process(
        "چقدر بی‌مزه 😂", conversation_id=cid_b, recent_messages=["یه جوک بگو"]
    )
    assert result_a is not None and result_b is not None

    engine_a = coordinator.get_latest(cid_a).pattern_context["engine"]
    engine_b = coordinator.get_latest(cid_b).pattern_context["engine"]
    assert engine_a != engine_b, "دو مکالمه‌یِ متفاوت باید pattern_context متفاوت بسازند"
    # نشانه‌یِ حداقلی و پایدار: امضا (signature) که ترکیبِ نوع/احساس/نیاز/
    # کنش/موضوع/وضعیت است، باید بینِ دو سناریو فرق کند (موضوعِ B شاملِ
    # واژه‌یِ «چقدر» می‌شود که در A نیست).
    assert engine_a["signature"] != engine_b["signature"]


def test_ab_experiment_with_explicit_role_tagged_turns():
    """نسخه‌یِ غنی‌ترِ همان آزمایش -- با نوبتِ صریحِ TRX در میانه (turns override)."""
    turns_a = [{"role": "user", "content": "یه جوک بگو"}]
    turns_b = [
        {"role": "user", "content": "یه جوک بگو"},
        {"role": "assistant", "content": "چرا کامپیوتر سردش بود؟ چون پنجره‌هاش باز بود."},
        {"role": "user", "content": "چقدر بی‌مزه 😂"},
    ]
    pattern_a = pattern_bridge.build_pattern_context("یه جوک بگو", turns=turns_a)
    pattern_b = pattern_bridge.build_pattern_context("چقدر بی‌مزه 😂", turns=turns_b)
    assert pattern_a is not None and pattern_b is not None
    assert pattern_a != pattern_b


# ----------------------------------------------------------------------
#  6) خطای Pattern باعث crash نشد
# ----------------------------------------------------------------------
def test_pattern_engine_crash_never_breaks_the_turn(monkeypatch):
    def _boom(*a, **k):
        raise RuntimeError("simulated pattern engine crash")

    monkeypatch.setattr(cp_mod.ConversationPatternEngine, "build_pattern", classmethod(lambda cls, *a, **k: _boom()))

    cid = "pytest_pattern_v25_5_6_crash"
    state_tracker.reset_snapshot(cid)
    result = conversation_engine.process("سلام دوباره", conversation_id=cid, recent_messages=[])
    assert result is not None, "خرابیِ Pattern Engine نباید کل نوبت را بترکاند"

    ctx = get_coordinator().get_latest(cid)
    assert ctx is not None
    assert ctx.pattern_context.get("engine") is None, "در خطا باید engine=None بماند، نه استثنا"
    state_tracker.reset_snapshot(cid)


def test_pattern_bridge_helper_itself_never_raises_on_bad_input():
    # ورودیِ نامعتبر (نه لیست، نه رشته) -- باید None برگرداند، نه استثنا.
    assert pattern_bridge.build_pattern_context(None, turns="not-a-list") is None or True
    # نکته: build_pattern_context حتی رویِ ورودیِ عجیب هم نباید raise کند.
    try:
        pattern_bridge.build_pattern_context(123, recent_messages=[456, None])  # type: ignore[arg-type]
    except Exception as exc:  # noqa: BLE001
        pytest.fail(f"build_pattern_context نباید استثنا بدهد: {exc}")


# ----------------------------------------------------------------------
#  7) Final Decision تغییر نکرد (شادو هنوز برقرار است، حتی با Pattern Bridge)
# ----------------------------------------------------------------------
def test_final_decision_unchanged_with_pattern_bridge_wired():
    msg = "همون قبلی رو بهتر کن"
    cid = "pytest_pattern_v25_5_6_shadow"

    state_tracker.reset_snapshot(cid)
    ns_config.NERVOUS_SYSTEM_ENABLED = False
    result_without = conversation_engine.process(msg, conversation_id=cid, recent_messages=["یه جوک بگو"])

    state_tracker.reset_snapshot(cid)
    ns_config.NERVOUS_SYSTEM_ENABLED = True
    result_with = conversation_engine.process(msg, conversation_id=cid, recent_messages=["یه جوک بگو"])

    assert result_without == result_with, (
        "اتصالِ Pattern Engine هم مثلِ خودِ Coordinator باید بی‌اثر بماند -- SHADOW"
    )
    state_tracker.reset_snapshot(cid)


# ----------------------------------------------------------------------
#  خوداظهاریِ صادقانه‌ی Influence Audit برایِ این اتصال
# ----------------------------------------------------------------------
def test_pattern_wiring_self_reports_as_orphan_not_functional():
    report = classify_pattern_engine_wiring()
    assert report.status == "LIVE"
    assert report.influence == "ORPHAN", (
        "درست است که حالا داده تولید و ذخیره می‌شود، اما تا وقتی هیچ "
        "تصمیمی از آن استفاده نکند، ادعایِ FUNCTIONAL نادرست است."
    )
