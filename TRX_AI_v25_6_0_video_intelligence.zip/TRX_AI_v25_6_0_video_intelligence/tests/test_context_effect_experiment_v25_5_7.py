# -*- coding: utf-8 -*-
"""
تست‌هایِ Controlled Context Effect Experiment -- v25.5.7.

سه دسته:

1. واحدهایِ محاسباتیِ خالص (`_diff`, `_format_pattern_block`) -- بدونِ
   نیاز به هیچ مدلی.
2. آداپتورِ ``seed`` در ``LlamaCppModelAdapter`` (افزوده‌یِ این نسخه) --
   با تزریقِ ``llama_factory`` (دقیقاً هم‌الگو با
   ``tests/test_local_llm_integration.py``ی موجود)، بدونِ نیاز به
   نصبِ واقعیِ ``llama-cpp-python``.
3. ``run_experiment`` سرتاسری -- با یک آدپتورِ fake که
   ``conversational_bridge.get_adapter`` را monkeypatch می‌کند، طوری که
   از هیچ فایلِ GGUFِ واقعی استفاده نمی‌کند، ولی مسیرِ واقعیِ
   ``conversation_engine.process`` → ``NervousSystemCoordinator`` →
   ``pattern_bridge`` را کامل طی می‌کند.

هر تستِ این دسته‌ی سوم یکی از موادِ چک‌لیستِ توافق‌شده را می‌سنجد --
خطِ قرمزهایِ SHADOW/ADVISORY را هم به‌صراحت تأیید می‌کند (بدونِ اثر رویِ
production).
"""

from __future__ import annotations

import os
import tempfile

import pytest

from trx_ai.nervous_system import config as ns_config
from trx_ai.nervous_system.experiments import context_effect_experiment as cee
from trx_ai.trx_model import conversational_bridge


# ----------------------------------------------------------------------
#  1) واحدهایِ محاسباتیِ خالص
# ----------------------------------------------------------------------
def test_diff_exact_match():
    d = cee._diff("سلام دوست من", "سلام دوست من")
    assert d["exact_match"] is True
    assert d["similarity"] == 1.0
    assert d["length_delta"] == 0
    assert d["behavioral_difference"] == "NOT_OBSERVED"
    assert d["semantic_difference"] == "NOT_PROVEN"


def test_diff_whitespace_only_is_not_observed():
    """فقط اختلافِ فاصله/newline نباید «تفاوتِ رفتاری» حساب شود."""
    d = cee._diff("سلام   دوست من", "سلام دوست من\n")
    assert d["behavioral_difference"] == "NOT_OBSERVED"


def test_diff_real_difference_is_observed():
    d = cee._diff(
        "چرا کامپیوتر سردش بود؟ چون پنجره‌هاش باز بود.",
        "ببخشید، شوخیِ بهتری الان به ذهنم نمی‌رسه.",
    )
    assert d["exact_match"] is False
    assert d["similarity"] < cee._SIMILARITY_OBSERVED_THRESHOLD
    assert d["behavioral_difference"] == "OBSERVED"
    assert d["semantic_difference"] == "NOT_PROVEN"  # هیچ‌وقت چیزِ دیگری نیست


def test_format_pattern_block_includes_key_fields():
    engine = {
        "type": "general", "emotion": "neutral", "need": "conversation",
        "dialogue_act": "statement", "arc": "focused:general",
        "sentiment_direction": "stable", "strategy": "no_es",
    }
    block = cee._format_pattern_block(engine)
    assert "neutral" in block and "conversation" in block and "no_es" in block


# ----------------------------------------------------------------------
#  2) پارامترِ seed در LlamaCppModelAdapter (افزوده‌یِ v25.5.7)
# ----------------------------------------------------------------------
class _FakeLlamaCapturesKwargs:
    def __init__(self, **_kwargs):
        self.calls: list = []

    def tokenize(self, raw_bytes):
        return [1]

    def detokenize(self, ids):
        return b"x"

    def create_chat_completion(self, **kwargs):
        self.calls.append(kwargs)
        return {"choices": [{"message": {"content": "ok"}}]}


@pytest.fixture
def fake_model_path():
    fd, path = tempfile.mkstemp(suffix=".gguf")
    os.close(fd)
    with open(path, "wb") as f:
        f.write(b"not-a-real-model")
    yield path
    os.unlink(path)


def test_seed_is_passed_through_when_given(fake_model_path):
    from trx_ai.trx_model.llama_cpp_adapter import LlamaCppModelAdapter

    adapter = LlamaCppModelAdapter(model_path=fake_model_path, llama_factory=_FakeLlamaCapturesKwargs)
    adapter.chat(system_prompt="s", user_text="u", seed=42)
    assert adapter._llama.calls[0].get("seed") == 42


def test_seed_omitted_when_not_given_zero_behavior_change(fake_model_path):
    """پیش‌فرض (``seed=None``) نباید کلیدِ ``seed`` را اصلاً به کتابخانه بفرستد --
    یعنی صفر تغییرِ رفتار برایِ هر فراخوانِ قبلی/موجودِ بدونِ seed."""
    from trx_ai.trx_model.llama_cpp_adapter import LlamaCppModelAdapter

    adapter = LlamaCppModelAdapter(model_path=fake_model_path, llama_factory=_FakeLlamaCapturesKwargs)
    adapter.chat(system_prompt="s", user_text="u")
    assert "seed" not in adapter._llama.calls[0]


# ----------------------------------------------------------------------
#  3) run_experiment سرتاسری
# ----------------------------------------------------------------------
class _FakeAdapterContextSensitive:
    """پاسخ واقعاً به وجود/نبودِ بلوکِ pattern در system_prompt وابسته است."""

    def __init__(self):
        self.calls: list = []

    def chat(self, *, system_prompt, user_text, history=None, max_new_tokens=512, temperature=0.6, seed=None):
        self.calls.append(dict(system_prompt=system_prompt, user_text=user_text, history=history, seed=seed, temperature=temperature))
        if "زمینه‌یِ مکالمه" in system_prompt:
            return "پاسخِ آگاه از زمینه: می‌دونم شوخیم بد بود!"
        return "باشه، یه جوکِ دیگه می‌گم."


class _FakeAdapterContextBlind:
    """پاسخ همیشه یکسان است -- برایِ تستِ مسیرِ INCONCLUSIVE."""

    def chat(self, *, system_prompt, user_text, history=None, max_new_tokens=512, temperature=0.6, seed=None):
        return "یک پاسخِ ثابت، مستقل از context."


class _FakeAdapterRaisesForScenario:
    def __init__(self, boom_on: str):
        self.boom_on = boom_on

    def chat(self, *, system_prompt, user_text, history=None, max_new_tokens=512, temperature=0.6, seed=None):
        if self.boom_on in user_text:
            raise RuntimeError("simulated model crash")
        return "پاسخِ عادی."


@pytest.fixture(autouse=True)
def _restore_ns_flag():
    original = ns_config.NERVOUS_SYSTEM_ENABLED
    yield
    ns_config.NERVOUS_SYSTEM_ENABLED = original


def test_skipped_when_no_model_available(monkeypatch):
    monkeypatch.setattr(conversational_bridge, "get_adapter", lambda: None)
    report = cee.run_experiment()
    assert report.overall_result == "SKIPPED_NO_MODEL"
    assert report.scenarios == ()


def test_pass_when_context_actually_changes_output(monkeypatch):
    fake = _FakeAdapterContextSensitive()
    monkeypatch.setattr(conversational_bridge, "get_adapter", lambda: fake)

    report = cee.run_experiment(
        scenarios=(cee.DEFAULT_SCENARIOS[0],),  # فقط سناریویِ joke_feedback
        seed=42, temperature=0.0,
    )

    assert report.overall_result == "PASS"
    assert len(report.scenarios) == 1
    result = report.scenarios[0]
    assert result.status == "OK"
    assert result.behavioral_difference == "OBSERVED"
    assert result.semantic_difference == "NOT_PROVEN"
    assert result.full_pattern_engine is not None, "pattern engine باید واقعاً فراخوانی شده باشد"

    # خطِ قرمز: user_text و history بینِ دو تماس (FULL/REDUCED) باید کاملاً یکسان باشند.
    assert len(fake.calls) == 2
    call_full, call_reduced = fake.calls
    assert call_full["user_text"] == call_reduced["user_text"]
    assert call_full["history"] == call_reduced["history"]
    assert call_full["system_prompt"] != call_reduced["system_prompt"]
    # generation config هم باید بینِ دو تماس یکسان باشد (seed/temperature ثابت).
    assert call_full["seed"] == call_reduced["seed"] == 42
    assert call_full["temperature"] == call_reduced["temperature"] == 0.0


def test_inconclusive_when_output_identical(monkeypatch):
    monkeypatch.setattr(conversational_bridge, "get_adapter", lambda: _FakeAdapterContextBlind())
    report = cee.run_experiment(scenarios=(cee.DEFAULT_SCENARIOS[0],))
    assert report.overall_result == "INCONCLUSIVE"
    assert report.scenarios[0].behavioral_difference == "NOT_OBSERVED"


def test_single_scenario_crash_does_not_abort_whole_experiment(monkeypatch):
    fake = _FakeAdapterRaisesForScenario(boom_on="چقدر بی‌مزه")
    monkeypatch.setattr(conversational_bridge, "get_adapter", lambda: fake)

    report = cee.run_experiment(scenarios=cee.DEFAULT_SCENARIOS)
    statuses = {s.scenario_name: s.status for s in report.scenarios}
    assert statuses["joke_feedback"] == "ERROR"
    assert statuses["good_mood"] == "OK"
    assert statuses["give_up"] == "OK"


def test_experiment_never_leaves_nervous_system_flag_enabled_afterward(monkeypatch):
    monkeypatch.setattr(conversational_bridge, "get_adapter", lambda: _FakeAdapterContextBlind())
    ns_config.NERVOUS_SYSTEM_ENABLED = False
    cee.run_experiment(scenarios=(cee.DEFAULT_SCENARIOS[0],))
    assert ns_config.NERVOUS_SYSTEM_ENABLED is False, (
        "آزمایش باید فلگِ production را دقیقاً به حالتِ قبلی برگرداند"
    )


def test_experiment_never_touches_routing_decision_or_final_response(monkeypatch):
    """خطِ قرمزِ اصلی: خروجیِ conversation_engine.process (یعنی تصمیمِ نهایی)
    باید کاملاً مستقل از اجرایِ این آزمایش بماند."""
    from trx_ai.conversation import conversation_engine, state_tracker

    monkeypatch.setattr(conversational_bridge, "get_adapter", lambda: _FakeAdapterContextSensitive())

    cid = "pytest_v25_5_7_isolation_check"
    state_tracker.reset_snapshot(cid)
    ns_config.NERVOUS_SYSTEM_ENABLED = False
    before = conversation_engine.process("یه جوک بگو", conversation_id=cid, recent_messages=[])

    cee.run_experiment(scenarios=(cee.DEFAULT_SCENARIOS[0],))

    state_tracker.reset_snapshot(cid)
    ns_config.NERVOUS_SYSTEM_ENABLED = False
    after = conversation_engine.process("یه جوک بگو", conversation_id=cid, recent_messages=[])

    assert before == after
    state_tracker.reset_snapshot(cid)
