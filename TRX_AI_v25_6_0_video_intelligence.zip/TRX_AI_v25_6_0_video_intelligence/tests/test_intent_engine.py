# -*- coding: utf-8 -*-
"""
تست‌های واحد برای IntentEngine.detect_intent (trx_ai/intelligence.py).

هدف: جلوگیری از رگرسیون در تشخیصِ نیت — اگر در آینده کلیدواژه یا
regex‌ای تغییر/حذف شود و باعث شود جمله‌ای که باید نیتِ X تشخیص داده
شود به‌جایش نیتِ دیگری بگیرد، این تست‌ها همان لحظه شکست می‌خورند.

این ماژول (intelligence.py) هیچ وابستگیِ سنگینی ندارد (فقط `re`)، پس
تست‌ها سریع و بدون نیاز به شبکه/دیتابیس اجرا می‌شوند.
"""

import pytest

from trx_ai.intelligence import IntentEngine, JokeEngine


# هر مورد: (متنِ ورودی، نیتِ موردانتظار)
# این نمونه‌ها مستقیماً از کلیدواژه‌ها/regexهای واقعیِ INTENT_PATTERNS و
# STRUCTURAL_COMMANDS گرفته شده‌اند تا تست‌ها با منطقِ واقعیِ موتور
# هم‌راستا بمانند، نه یک انتظارِ فرضی.
INTENT_CASES = [
    ("۵ بعلاوه ۳ چقدر میشه", "calculator"),
    ("۱۰ ضربدر ۲ چند میشه", "calculator"),
    ("این جمله رو به انگلیسی ترجمه کن", "translator"),
    ("معنی کلمه‌ی سلام چیه", "dictionary"),
    ("این کد رو تحلیل کن: def f(): pass", "code_analyzer"),
    ("تحلیل پروژه رو انجام بده", "project_analysis"),
    ("چاپ(سلام دنیا)", "persian_interpreter"),
    ("بگو(سلام)", "persian_interpreter"),
    ("الان ساعت چنده", "system_time"),
    ("تاریخ امروز چیه", "system_time"),
    ("یاد بگیر: من قهوه دوست دارم", "self_learning"),
    ("به خاطر بسپار: تولدم مرداده", "self_learning"),
    ("نام من علی است", "profile_update"),
    ("اسم من چیه", "profile_query"),
    ("من کی هستم", "profile_query"),
    ("دارم روی یک پروژه‌ی جدید کار می‌کنم", "memory_save"),
    ("یادت هست قبلاً چی گفته بودم", "memory_query"),
    ("شخصیت رسمی", "personality_change"),
    ("مد دوستانه", "personality_change"),
    ("در وب جستجو کن هوش مصنوعی چیست", "web_search"),
    ("هوای تهران چطوره", "weather"),
    ("قیمت دلار چنده", "currency"),
    ("قیمت طلا امروز", "currency"),
    ("سردرد و تب دارم", "medical"),
    ("گلودرد و سرفه دارم چیکار کنم", "medical"),
    ("سلام چطوری", "general"),
    ("خروج", "exit"),
    ("exit", "exit"),
    ("راهنما", "help"),
]


@pytest.mark.parametrize("text,expected_intent", INTENT_CASES)
def test_detect_intent_matches_expected(text, expected_intent):
    intent, confidence, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == expected_intent, (
        f"ورودی {text!r} باید نیتِ '{expected_intent}' می‌گرفت، اما '{intent}' گرفت "
        f"(اطمینان={confidence})."
    )
    assert 0.0 <= confidence <= 1.0


def test_detect_intent_empty_string_falls_back_to_general():
    intent, confidence, _ = IntentEngine.detect_intent("", None, None)
    assert intent == "general"


def test_medical_negation_reduces_but_does_not_zero_the_score():
    """
    «تب ندارم» باید همچنان به دیکشنری امتیازِ نیتِ پزشکی بدهد (چون هنوز
    درباره‌ی سلامتی صحبت می‌کند) اما با قطعیتِ کمتر از «تب دارم» — طبق
    منطقِ NEGATIONS در intelligence.py.
    """
    _, confidence_with_symptom, _ = IntentEngine.detect_intent("تب دارم", None, None)
    _, confidence_negated, _ = IntentEngine.detect_intent("تب ندارم", None, None)
    assert confidence_negated <= confidence_with_symptom


def test_structural_commands_are_high_confidence():
    """دستورات ساختاریِ لنگرشده (خروج/راهنما/...) باید همیشه اطمینانِ ۰.۹۸ بدهند."""
    intent, confidence, _ = IntentEngine.detect_intent("خروج", None, None)
    assert intent == "exit"
    assert confidence == 0.98


# ---------------------------------------------------------------------------
#   پرسش‌های دانشِ عمومی (کیست/چیست/چگونه/کجاست) باید به وب/ویکی‌پدیا
#   هدایت شوند، نه به «general» با اطمینانِ پیش‌فرضِ پایین، و نه (برای
#   مواردی مثل «پایتون چیست») به‌اشتباه به code_analyzer فقط به‌خاطرِ
#   وجودِ کلمه‌ی «پایتون».
# ---------------------------------------------------------------------------
KNOWLEDGE_QUESTION_CASES = [
    "پایتون چیست",
    "انیشتین کیست",
    "هوش مصنوعی چگونه کار می‌کند",
    "موتور بخار چگونه کار می‌کند",
    "تهران کجاست",
    "موتور بخار چیست و چگونه کار می‌کند",
    # فرمِ محاوره‌ای («چیه»/«کیه») -- قبلاً فقط فرمِ رسمی («چیست»/«کیست»)
    # پوشش داشت، پس این‌ها به‌جایِ web_search به general (اطمینانِ
    # پیش‌فرضِ ۰.۴) سقوط می‌کردند.
    "RTX4090 چیه",
    "GPT-5 چیه",
    "انیشتین کیه",
]


@pytest.mark.parametrize("text", KNOWLEDGE_QUESTION_CASES)
def test_knowledge_questions_route_to_web_search(text):
    intent, confidence, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == "web_search", f"{text!r} باید به web_search هدایت می‌شد، نه {intent!r}"


def test_code_question_with_actual_code_still_routes_to_code_analyzer():
    """نباید فقط به‌خاطرِ کلماتِ پرسشی، درخواستِ واقعیِ تحلیلِ کد قربانی شود."""
    intent, _, _ = IntentEngine.detect_intent("این کد رو تحلیل کن: def f(): pass", None, None)
    assert intent == "code_analyzer"


@pytest.mark.parametrize("text", [
    "مراحل انجام این کار چیست؟",
    "مراحل انجام این کار چیه",
])
def test_specific_intent_keyphrase_beats_generic_knowledge_question_catchall(text):
    """
    باگِ واقعی: الگویِ عمومیِ «X چیست/چیه» در web_search قبلاً بدونِ
    قید‌وشرط weight×۱.۵=۱۰.۵ امتیاز می‌داد، حتی وقتی جمله یک عبارتِ
    کلیدیِ دوکلمه‌ایِ نیتِ خیلی خاص‌تری (اینجا «مراحل انجام» در planning)
    هم داشت -- یعنی «مراحل انجام این کار چیست؟» به‌جایِ planning به
    web_search می‌رفت. این دقیقاً همان چیزی است که یک تلاشِ قبلی برایِ
    اضافه‌کردنِ فرمِ محاوره‌ای باعثش شد و revert خورد؛ اکنون
    ``IntentSpec.fallback_regex`` این الگوهایِ عمومی را به یک لایه‌ی
    *نجات‌دهنده* تبدیل کرده که وقتی نیتِ دیگری سرنخِ خاص (کلیدواژه‌یِ
    چندکلمه‌ای یا regexِ صریح) دارد، خودش را سرکوب می‌کند.
    """
    intent, _, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == "planning", f"{text!r} باید به planning هدایت می‌شد، نه {intent!r}"


# ---------------------------------------------------------------------------
#   نیتِ «joke» و ساختاریِ «یادت هست/یادته/یادت میاد»
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("text", [
    "یه جوک بگو", "جوک بگو", "لطیفه بگو", "منو بخندون", "بخندونم",
])
def test_joke_requests_are_detected(text):
    intent, confidence, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == "joke"
    assert confidence >= 0.9


@pytest.mark.parametrize("text", [
    "یادت هست", "یادته", "یادت هست چی گفتم", "یادت میاد", "یادت هست اسمم چیه",
])
def test_memory_recall_phrasing_is_structural_and_reliable(text):
    """
    این‌ها باید همیشه (با اطمینانِ ساختاریِ ۰.۹۸) به memory_query هدایت
    شوند، حتی وقتی جمله شاملِ عبارتی مثل «اسمم چیه» هم باشد که در غیرِ
    این صورت با profile_query رقابت می‌کرد.
    """
    intent, confidence, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == "memory_query"
    assert confidence == 0.98


def test_bare_name_question_without_yadet_still_goes_to_profile_query():
    """بدونِ «یادت»، «اسمم چیه» باید همچنان مستقیماً profile_query بماند."""
    intent, _, _ = IntentEngine.detect_intent("اسمم چیه", None, None)
    assert intent == "profile_query"


def test_joke_engine_returns_nonempty_string():
    joke = JokeEngine.get_random_joke()
    assert isinstance(joke, str) and joke.strip()


def test_joke_engine_avoids_immediate_repeat():
    last = JokeEngine.get_random_joke()
    for _ in range(10):
        nxt = JokeEngine.get_random_joke(exclude=last)
        assert nxt != last
        last = nxt


# ---------------------------------------------------------------------------
#   نیت‌های مدیریتِ کارها/یادآوری‌ها (task_add/task_list/task_done/task_delete)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected_intent", [
    ("یادم بنداز فردا ساعت ۵ به دکتر زنگ بزنم", "task_add"),
    ("یادآوری کن که نون بخرم", "task_add"),
    ("کارهام چیه", "task_list"),
    ("لیست کارها", "task_list"),
    ("کار ۲ رو انجام دادم", "task_done"),
    ("کار ۳ رو حذف کن", "task_delete"),
    ("حذف کار ۴", "task_delete"),
])
def test_task_manager_intents_are_structural_and_reliable(text, expected_intent):
    intent, confidence, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == expected_intent
    assert confidence == 0.98


def test_detect_intent_is_case_and_arabic_char_insensitive():
    """
    نرمال‌سازیِ داخلیِ IntentEngine باید «ي» عربی را معادل «ی» فارسی
    بداند (متن‌های کپی‌شده از منابع عربی/قدیمی رایج‌اند).
    """
    intent_fa, _, _ = IntentEngine.detect_intent("قیمت دلار", None, None)
    intent_ar_yeh, _, _ = IntentEngine.detect_intent("قيمت دلار", None, None)
    assert intent_fa == intent_ar_yeh == "currency"
