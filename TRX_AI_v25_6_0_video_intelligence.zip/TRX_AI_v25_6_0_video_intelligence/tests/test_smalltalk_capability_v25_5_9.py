# -*- coding: utf-8 -*-
"""
تست‌هایِ اصلاحِ باگِ v25.5.9 -- الگویِ regexِ دسته‌ی «capability» در
``SmallTalkEngine`` (`trx_ai/nlu/smalltalk_registry.py`) خیلی محدود بود.

گزارشِ واقعیِ امیر (همان ترنسکریپت): «چه کار خاصی بلدی» و «چه کار خاصی
بلدی ی» به‌جایِ پاسخِ فهرستِ قابلیت‌ها (که «چیکار بلدی»، چند خط بالاتر
در همان گفتگو، درست گرفت)، به boilerplateِ عمومیِ «من TRX AI هستم...»
سقوط کردند.

ریشه: regexِ قدیمی فقط شکلِ جمعِ ثابت («چه کارهایی بلدی») را می‌گرفت و
هیچ کلمه‌ی میانی (این‌جا: صفتِ «خاصی») را تحمل نمی‌کرد؛ `fuzzy_enabled`
هم `False` بود، پس هیچ لایه‌ی نجاتی برایِ این پارافریزِ کاملاً طبیعی
وجود نداشت.

این فایل مستقیماً `SmallTalkEngine.categorize` (تابعِ استاتیک، بدونِ
وابستگی به core.py -- طبقِ خودِ docstringِ کلاس) را صدا می‌زند؛ نیازی به
شبیه‌سازیِ کلِ اپلیکیشن نیست.
"""

from __future__ import annotations

from trx_ai.intelligence import SmallTalkEngine


REAL_BUG_MESSAGES = (
    "چه کار خاصی بلدی",
    "چه کار خاصی بلدی ی",  # دقیقاً همان تایپوی واقعیِ ترنسکریپت
)


def test_real_bug_messages_now_classified_as_capability():
    for msg in REAL_BUG_MESSAGES:
        assert SmallTalkEngine.categorize(msg) == "capability", msg


def test_original_working_phrasing_still_works_no_regression():
    """اثباتِ عدمِ تخریب: عبارتی که از قبل کار می‌کرد، هنوز کار می‌کند."""
    for msg in ("چیکار بلدی", "چیکار می کنی", "چه کارهایی بلدی", "چه کمکی می تونی بکنی"):
        assert SmallTalkEngine.categorize(msg) == "capability", msg


def test_other_natural_paraphrases_also_now_covered():
    for msg in ("چه کاری بلدی", "چه کار جالبی بلدی", "چه کار عجیبی بلدی"):
        assert SmallTalkEngine.categorize(msg) == "capability", msg


def test_unrelated_messages_still_not_classified_as_capability():
    """اثباتِ عدمِ false-positiveِ جدید -- پهن‌ترکردنِ regex نباید چیزِ
    بی‌ربطی را هم بگیرد."""
    for msg in ("امروز حالم خوبه", "کارم امروز تموم شد", "کار زیادی دارم امروز"):
        assert SmallTalkEngine.categorize(msg) != "capability", msg


def test_capability_response_pool_is_still_reachable():
    """اطمینان از اینکه دسته‌بندیِ درست، به یک پاسخِ واقعیِ فهرستِ
    قابلیت‌ها هم می‌رسد (نه فقط برچسبِ داخلی)."""
    name = SmallTalkEngine.categorize("چه کار خاصی بلدی")
    assert name == "capability"
    responses = SmallTalkEngine._RESPONSES[name]
    assert any("محاسبه" in r or "ترجمه" in r for r in responses)
