import pytest
from trx_ai.runtime_intelligence import RuntimeIntelligence, normalize_user_text

def test_normalize_digits_and_spaces():
    assert normalize_user_text("  تست   ۱۲۳  ") == "تست 123"

def test_duplicate_detection():
    r = RuntimeIntelligence()
    assert r.inspect("سلام").duplicate is False
    assert r.inspect("سلام").duplicate is True

def test_context_is_bounded():
    ctx = RuntimeIntelligence.build_context([], "x" * 10000, "", max_chars=1000)
    assert len(ctx) <= 1000

@pytest.mark.parametrize("answer,ok", [("", False), ("سلام", True), ("abc", True)])
def test_quality_gate(answer, ok):
    assert RuntimeIntelligence.quality_check(answer, "q")["ok"] is ok
