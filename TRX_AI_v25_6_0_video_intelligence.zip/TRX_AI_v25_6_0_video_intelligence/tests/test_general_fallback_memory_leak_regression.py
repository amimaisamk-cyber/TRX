# -*- coding: utf-8 -*-
"""
تستِ رگرسیونِ باگِ «حلقه‌ی بازخوردِ حافظه» در پاسخِ عمومیِ محلی.

گزارشِ واقعی از امیر: بعد از چند نوبت، پاسخ‌های `_general_answer`
(شاخه‌ی نهاییِ کاملاً محلی) به‌جای پاسخِ ساده، شروع کردند به نمایشِ
دامپِ خامِ حافظه‌ی داخلی -- شاملِ timestampهای بریده‌شده مثلِ
"[2026-09-1" و تکرارِ تو‌درتویِ همان جمله‌ی «در حال پردازشِ سؤال شما».

ریشه‌ی مشکل: خط ۷۸۷-۷۸۸ (نسخه‌ی قبل از این ارتقا) متنِ داخلیِ
``context`` (شاملِ پیام‌هایِ قبلیِ AI) را مستقیماً در ``answer`` درج
می‌کرد. چون ``answer`` بلافاصله با ``ai._finalize`` دوباره در حافظه
ذخیره می‌شود، هر نوبتِ بعدی همان دامپ را دوباره در خودش تو‌درتو
می‌کرد -- یک رشدِ نمایی که با هر برش (truncate) در نقطه‌ی اشتباهی قطع
می‌شد و خروجیِ به‌هم‌ریخته تولید می‌کرد.

این فایل هم سطحِ ساختاری (اطمینان از اینکه الگوی نشتی به کدِ اصلی
برنگشته) و هم سطحِ رفتاری (دو نوبتِ پیاپیِ واقعی از طریقِ خودِ
``ToolRouter._general_answer``، دقیقاً مثلِ سناریویِ گزارش‌شده) را
پوشش می‌دهد.
"""

from __future__ import annotations

import asyncio
import re
from unittest.mock import patch

from trx_ai.core_engine import tool_router as tool_router_module
from trx_ai.core_engine.tool_router import ToolRouter
from trx_ai.memory_store import MemoryEngine
from trx_ai.runtime_intelligence import RuntimeIntelligence


# ---------------------------------------------------------------------------
# ساختاری: مطمئن شو الگویِ نشتی هرگز به کدِ اصلی برنمی‌گردد
# ---------------------------------------------------------------------------

def test_source_never_echoes_raw_context_into_visible_answer():
    import inspect

    source = inspect.getsource(tool_router_module)
    assert "بر اساس گفتگوی قبلی" not in source, (
        "متنِ داخلیِ context نباید دوباره مستقیم در پاسخِ کاربر تزریق شود "
        "-- این دقیقاً همان باگِ حلقه‌ی بازخوردِ حافظه بود."
    )


# ---------------------------------------------------------------------------
# رفتاری: دو نوبتِ پیاپی از مسیرِ واقعیِ _general_answer
# ---------------------------------------------------------------------------

class _FakeDB:
    """کمترین چیزی که MemoryEngine/MemoryCorrectionEngine برای ساخته‌شدن لازم دارند."""

    def get_profile_by_prefix(self, prefix):
        return []

    def get_profile(self, key, default=None):
        return default


class _FakeConversationPatterns:
    """آفلاین و خنثی نگه‌داشتنِ شاخه‌هایِ بالادستیِ smalltalk/empathy."""

    def prompt_context(self, text):
        return ""

    def emotional_support_mode(self, text):
        return False

    def _recent_context_text(self):
        return ""

    def local_empathetic_reply(self, text):
        return None


class _FakeUserStateMemory:
    def recent_failures(self):
        return 0


class _FakeAI:
    """
    فقط ویژگی‌هایی که مسیرِ ``_general_answer`` تا شاخه‌ی نهاییِ
    محلی لازم دارد -- ``memory`` و ``runtime`` عمداً پیاده‌سازیِ
    واقعیِ پروژه هستند (نه fake) تا خودِ حلقه‌ی بازخورد واقعاً
    بازتولید و بررسی شود، نه یک نسخه‌ی ساده‌شده‌ی آن.
    """

    def __init__(self):
        self.memory = MemoryEngine(_FakeDB())
        self.runtime = RuntimeIntelligence()
        self.conversation_patterns = _FakeConversationPatterns()
        self.user_state_memory = _FakeUserStateMemory()
        self.current_trace = None
        self.db = None
        self.presented = []  # ثبتِ همه‌ی چیزهایی که به کاربر نمایش داده شده

    async def _present(self, text, title="", style="cyan"):
        self.presented.append(text)

    def _finalize(self, query, response, start_time, intent, confidence):
        # دقیقاً همان چیزی که core.py واقعی انجام می‌دهد: پاسخ را در
        # حافظه ذخیره کن -- این خطِ حیاتیِ بازتولیدِ باگ است.
        self.memory.add_message("user", query)
        self.memory.add_message("ai", response)


def test_two_consecutive_fallback_turns_never_nest_previous_reply():
    async def _run():
        ai = _FakeAI()
        router = ToolRouter(ai)

        class _NeutralState:
            primary_state = "neutral"
            states = []
            uncertain = True

        with patch.object(tool_router_module.SmallTalkEngine, "categorize", return_value=None), \
             patch.object(tool_router_module.user_state_engine, "detect", return_value=_NeutralState()), \
             patch.object(tool_router_module.conversation_phase, "detect_phase", return_value="neutral"), \
             patch.object(tool_router_module.response_strategy, "choose_strategy", return_value="none"):

            # پیامِ اولِ کاربر -- بدونِ هیچ context ی از قبل
            first_message = "منم خوبم"
            answer1 = await router._general_answer(
                ai, first_message, first_message, "🤖", "با احترام، ", "cyan"
            )
            ai._finalize(first_message, answer1, 0.0, "general", 0.5)

            # پیامِ دومِ کاربر -- الان حافظه شاملِ پیامِ اول و پاسخِ اول است
            second_message = "چه خبرا"
            answer2 = await router._general_answer(
                ai, second_message, second_message, "🤖", "با احترام، ", "cyan"
            )

        # قبلِ رفعِ باگ، answer2 شاملِ متنِ answer1 (به‌همراه پیشوندِ
        # «بر اساس گفتگوی قبلی» و برشِ ناقصِ آن) می‌شد. الان نباید هیچ‌کدام
        # از این‌ها در پاسخِ دوم دیده شود.
        assert "بر اساس گفتگوی قبلی" not in answer2
        assert "حافظه مرتبط" not in answer2
        assert first_message not in answer2  # متنِ نوبتِ قبلی نباید echo شود
        # طولِ answer2 نباید بلندتر از یک آستانه‌ی معقول برایِ همین قالبِ
        # ثابت باشد -- قبل از رفعِ باگ، همین‌جا context تزریق‌شده باعثِ
        # صدها کاراکترِ اضافه می‌شد.
        assert len(answer2) < 300, f"طولِ غیرمنتظره -- نشانه‌ی احتمالیِ نشتِ context: {len(answer2)}"
        # و هیچ الگویِ timestampِ بریده‌شده (نشانه‌ی نشتِ دامپِ حافظه)
        assert not re.search(r"\[\d{4}-\d{2}-\d{2}", answer2)

    asyncio.run(_run())


def test_ten_consecutive_fallback_turns_stay_short_and_clean():
    """
    اثباتِ نبودِ رشدِ نمایی: حتی بعدِ ۱۰ نوبتِ پیاپیِ فقط-فال‌بک، طولِ
    پاسخ نباید رشدِ فزاینده داشته باشد (قبل از رفعِ باگ، این طول با هر
    نوبت به‌خاطرِ تو‌درتوشدنِ context بزرگ‌تر می‌شد).
    """
    async def _run():
        ai = _FakeAI()
        router = ToolRouter(ai)

        class _NeutralState:
            primary_state = "neutral"
            states = []
            uncertain = True

        lengths = []
        with patch.object(tool_router_module.SmallTalkEngine, "categorize", return_value=None), \
             patch.object(tool_router_module.user_state_engine, "detect", return_value=_NeutralState()), \
             patch.object(tool_router_module.conversation_phase, "detect_phase", return_value="neutral"), \
             patch.object(tool_router_module.response_strategy, "choose_strategy", return_value="none"):

            for i in range(10):
                msg = f"پیامِ شماره {i}"
                answer = await router._general_answer(ai, msg, msg, "🤖", "با احترام، ", "cyan")
                ai._finalize(msg, answer, 0.0, "general", 0.5)
                lengths.append(len(answer))

        # همه‌ی طول‌ها باید تقریباً یکسان بمانند (نه رشدِ فزاینده)
        assert max(lengths) - min(lengths) < 40, f"طولِ پاسخ رشدِ غیرمنتظره داشت: {lengths}"
        assert max(lengths) < 300, "پاسخِ فال‌بک نباید حجیم شود -- نشانه‌ی نشتِ context است"

    asyncio.run(_run())
