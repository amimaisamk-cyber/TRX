# -*- coding: utf-8 -*-
"""
tests/test_native_model.py -- تستِ واحدِ trx_ai.trx_model (بخشِ ۱۱-۱۳
سندِ معماری). این‌ها تستِ «شکل ظاهریِ کد» نیستند؛ هرکدام یک ادعایِ
ریاضی/معماریِ مشخص را می‌سنجند (round-trip بدونِ افتِ اطلاعات، علّیتِ
واقعیِ ماسکِ توجه، بازتولیدپذیریِ وزن‌ها، ...).
"""

from __future__ import annotations

import numpy as np
import pytest

from trx_ai.trx_model.tokenizer import ByteLevelBPETokenizer, pre_tokenize
from trx_ai.trx_model.transformer_core import RMSNorm, precompute_rope, apply_rope
from trx_ai.trx_model.model import TRXModelConfig, TRXNativeModel
from trx_ai.trx_model.model_adapter import TRXNativeModelAdapter
from trx_ai.trx_model.interfaces import ModelInterface


SAMPLE_TEXTS = [
    "سلام دنیا! این یک تستِ فارسی است با اعدادِ ۱۲۳ و علائم: ،.؟!",
    "Hello world 123 -- mixed English/Persian: سلام World!",
    "def foo(x):\n    return x * 2  # کدِ پایتون با کامنتِ فارسی\n",
    "😀 ایموجی و نمادها © § ± ∞ هم باید بدونِ خطا کار کنند.",
    "",
]

TRAIN_CORPUS = SAMPLE_TEXTS * 20 + [
    "تکرارِ کلماتِ پرتکرار برای اینکه BPE چیزی برای ادغام‌کردن داشته باشد "
    "تکرارِ کلماتِ پرتکرار برای اینکه BPE چیزی برای ادغام‌کردن داشته باشد."
]


@pytest.fixture(scope="module")
def trained_tokenizer() -> ByteLevelBPETokenizer:
    tok = ByteLevelBPETokenizer()
    tok.train(TRAIN_CORPUS, vocab_size=320)
    return tok


# --------------------------------------------------------------- tokenizer ----


def test_pretokenize_groups_homogeneous_runs():
    assert pre_tokenize("سلام Hi 123!") == ["سلام", " ", "Hi", " ", "123", "!"]
    assert pre_tokenize("") == []


@pytest.mark.parametrize("text", SAMPLE_TEXTS)
def test_tokenizer_roundtrip_is_lossless(trained_tokenizer, text):
    ids = trained_tokenizer.encode(text)
    assert trained_tokenizer.decode(ids) == text


def test_tokenizer_roundtrip_before_training_is_also_lossless(text=None):
    # حتی بدونِ هیچ merge (توکنایزرِ تازه‌ساز)، سطحِ بایت باید lossless بماند.
    tok = ByteLevelBPETokenizer()
    for text in SAMPLE_TEXTS:
        assert tok.decode(tok.encode(text)) == text


def test_tokenizer_training_is_deterministic():
    tok_a = ByteLevelBPETokenizer()
    tok_a.train(TRAIN_CORPUS, vocab_size=300)
    tok_b = ByteLevelBPETokenizer()
    tok_b.train(TRAIN_CORPUS, vocab_size=300)
    assert tok_a.merges == tok_b.merges


def test_tokenizer_vocab_size_matches_config(trained_tokenizer):
    assert trained_tokenizer.vocab_size == trained_tokenizer.base_vocab_size + 3  # pad/bos/eos
    assert trained_tokenizer.base_vocab_size <= 320


def test_tokenizer_save_load_roundtrip(tmp_path, trained_tokenizer):
    path = tmp_path / "tok.json"
    trained_tokenizer.save(str(path))
    loaded = ByteLevelBPETokenizer.load(str(path))
    assert loaded.merges == trained_tokenizer.merges
    for text in SAMPLE_TEXTS:
        assert loaded.decode(loaded.encode(text)) == trained_tokenizer.decode(trained_tokenizer.encode(text))


# ------------------------------------------------------------ transformer_core ----


def test_rmsnorm_output_has_unit_rms():
    rng = np.random.default_rng(0)
    x = rng.normal(0, 5.0, size=(10, 32))
    norm = RMSNorm(32)
    out = norm(x)
    rms = np.sqrt(np.mean(np.square(out), axis=-1))
    assert np.allclose(rms, 1.0, atol=1e-5)


def test_rope_preserves_vector_norm():
    # RoPE یک چرخش است -- باید نُرمِ بردار را حفظ کند (خاصیتِ ریاضیِ
    # پایه‌ای که هر پیاده‌سازیِ درستِ RoPE باید داشته باشد).
    cos, sin = precompute_rope(head_dim=8, max_seq_len=16)
    rng = np.random.default_rng(1)
    x = rng.normal(0, 1, size=(16, 2, 8))  # (seq, n_heads, head_dim)
    rotated = apply_rope(x, cos, sin)
    norm_before = np.linalg.norm(x, axis=-1)
    norm_after = np.linalg.norm(rotated, axis=-1)
    assert np.allclose(norm_before, norm_after, atol=1e-8)


# ------------------------------------------------------------------- model ----


@pytest.fixture
def tiny_model() -> TRXNativeModel:
    config = TRXModelConfig(vocab_size=64, d_model=16, n_layers=2, n_heads=2, d_ff=32, max_seq_len=32, seed=7)
    return TRXNativeModel(config)


def test_forward_output_shape(tiny_model):
    ids = np.array([1, 2, 3, 4, 5])
    logits = tiny_model.forward(ids)
    assert logits.shape == (5, 64)
    assert np.all(np.isfinite(logits))


def test_forward_rejects_out_of_range_ids(tiny_model):
    with pytest.raises(ValueError):
        tiny_model.forward(np.array([0, 1, 999]))


def test_forward_rejects_batched_input(tiny_model):
    with pytest.raises(ValueError):
        tiny_model.forward(np.array([[1, 2], [3, 4]]))


def test_causal_mask_is_actually_causal(tiny_model):
    """هستِ اصلیِ «پیش‌بینیِ توکنِ بعدی»: خروجی در موقعیتِ ``t`` نباید
    به توکن‌هایِ *بعد* از ``t`` وابسته باشد. تغییرِ آخرین توکن نباید
    logits موقعیت‌هایِ قبلی را تغییر دهد."""
    base = np.array([1, 2, 3, 4, 5])
    changed = np.array([1, 2, 3, 4, 63])  # فقط آخرین توکن فرق دارد

    logits_base = tiny_model.forward(base)
    logits_changed = tiny_model.forward(changed)

    # موقعیت‌هایِ ۰ تا ۳ فقط به توکن‌هایِ ۰..خودشان وابسته‌اند -> باید یکسان بمانند.
    assert np.allclose(logits_base[:4], logits_changed[:4], atol=1e-10)
    # موقعیتِ آخر (که به توکنِ تغییریافته وابسته است) باید فرق کند.
    assert not np.allclose(logits_base[4], logits_changed[4], atol=1e-10)


def test_model_construction_is_deterministic_given_seed():
    cfg = TRXModelConfig(vocab_size=32, d_model=8, n_layers=1, n_heads=2, d_ff=16, seed=123)
    m1 = TRXNativeModel(cfg)
    m2 = TRXNativeModel(cfg)
    ids = np.array([0, 1, 2])
    assert np.array_equal(m1.forward(ids), m2.forward(ids))


def test_save_load_weights_reproduces_forward(tmp_path, tiny_model):
    ids = np.array([1, 2, 3])
    before = tiny_model.forward(ids)
    path = tmp_path / "weights.npz"
    tiny_model.save_weights(str(path))

    # مدلِ تازه با seed متفاوت (تا مطمئن شویم واقعاً از فایل لود می‌کند، نه seed).
    cfg = tiny_model.config
    fresh = TRXNativeModel(TRXModelConfig(**{**cfg.__dict__, "seed": cfg.seed + 1}))
    fresh.load_weights(str(path))
    after = fresh.forward(ids)
    assert np.allclose(before, after)


def test_generate_returns_requested_length_and_valid_ids(tiny_model):
    rng = np.random.default_rng(0)
    out = tiny_model.generate([1, 2, 3], max_new_tokens=10, rng=rng)
    assert len(out) == 3 + 10
    assert all(0 <= i < tiny_model.config.vocab_size for i in out)


# ------------------------------------------------------------- model_adapter ----


def test_adapter_implements_model_interface(trained_tokenizer):
    config = TRXModelConfig(vocab_size=trained_tokenizer.vocab_size, d_model=16, n_layers=1, n_heads=2, d_ff=32)
    adapter = TRXNativeModelAdapter(trained_tokenizer, config=config)
    assert isinstance(adapter, ModelInterface)


def test_adapter_end_to_end_generate(trained_tokenizer):
    config = TRXModelConfig(vocab_size=trained_tokenizer.vocab_size, d_model=16, n_layers=1, n_heads=2, d_ff=32, max_seq_len=64)
    adapter = TRXNativeModelAdapter(trained_tokenizer, config=config, rng_seed=0)
    result = adapter.generate("سلام", max_new_tokens=8)
    assert isinstance(result, str)


def test_adapter_rejects_mismatched_vocab_size(trained_tokenizer):
    bad_config = TRXModelConfig(vocab_size=trained_tokenizer.vocab_size + 1, d_model=16, n_layers=1, n_heads=2, d_ff=32)
    with pytest.raises(ValueError):
        TRXNativeModelAdapter(trained_tokenizer, config=bad_config)
