# -*- coding: utf-8 -*-
"""
تست‌های واحد برای ابزارهای کمکیِ خالص (بدون وابستگی به شبکه/UI) در
trx_ai/core.py: _extract_search_subject و _extract_city_name.

نکته: core.py وابستگی‌های سنگین (aiohttp, rich, edge-tts, ...) دارد؛
اگر این‌ها نصب نباشند (طبق requirements.txt)، این فایل به‌جای شکست
خوردن، skip می‌شود.
"""

import pytest

pytest.importorskip("aiohttp", reason="نیازمندِ aiohttp (طبق requirements.txt)")
pytest.importorskip("bs4", reason="نیازمندِ beautifulsoup4 (طبق requirements.txt)")
pytest.importorskip("rich", reason="نیازمندِ rich (طبق requirements.txt)")

from trx_ai.core import TRXEnterpriseAI


@pytest.mark.parametrize("text,expected", [
    ("پایتون چیست", "پایتون"),
    ("انیشتین کیست", "انیشتین"),
    ("تهران کجاست", "تهران"),
    ("هوش مصنوعی چگونه کار می‌کند", "هوش مصنوعی"),
    ("موتور بخار چیست و چگونه کار می‌کند", "موتور بخار"),
    ("سرچ کن هوش مصنوعی", "هوش مصنوعی"),
    ("جستجو مکانیک کوانتومی", "مکانیک کوانتومی"),
])
def test_extract_search_subject_strips_question_scaffolding(text, expected):
    assert TRXEnterpriseAI._extract_search_subject(text) == expected


def test_extract_search_subject_falls_back_to_original_text_if_nothing_left():
    result = TRXEnterpriseAI._extract_search_subject("چیست")
    assert result  # هرگز نباید رشته‌ی خالی برگرداند


# ---------------------------------------------------------------------------
#   استخراج نامِ شهر برای آب‌وهوا — قبلاً باگ داشت: text.replace("هوا","")
#   روی «هوای تهران چطوره» چون «هوا» زیررشته‌ی «هوای» است، «ی تهران
#   چطوره» را به‌عنوانِ نامِ شهر برمی‌گرداند، نه «تهران».
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected_city", [
    ("هوای تهران چطوره", "تهران"),
    ("آب و هوای اصفهان", "اصفهان"),
    ("هوای مشهد امروز چطوره", "مشهد"),
    ("دمای هوای شیراز چقدره", "شیراز"),
    ("هوا چطوره", "تهران"),   # بدونِ نامِ شهر باید پیش‌فرضِ تهران برگردد
    ("هوا", "تهران"),
])
def test_extract_city_name_strips_question_scaffolding(text, expected_city):
    assert TRXEnterpriseAI._extract_city_name(text) == expected_city


def test_extract_city_name_never_leaves_stray_characters():
    """رگرسیونِ دقیق برای باگِ اصلی: نتیجه نباید با حرفِ اضافیِ 'ی' شروع شود."""
    result = TRXEnterpriseAI._extract_city_name("هوای تهران چطوره")
    assert not result.startswith("ی ")
    assert result == "تهران"
