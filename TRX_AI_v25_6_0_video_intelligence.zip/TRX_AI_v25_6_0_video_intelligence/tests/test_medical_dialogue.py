# -*- coding: utf-8 -*-
"""
تست‌های واحد برای گفتگوی تعاملیِ تشخیصِ پزشکی (trx_ai/medical.py).

این تست‌ها نیاز به شبکه ندارند (فقط منطقِ محلیِ استخراج/رتبه‌بندیِ
علائم و گفتگوی بله/خیر را می‌سنجند)، اما medical.py به‌طور غیرمستقیم
از طریق tools.py به aiohttp/beautifulsoup4 وابسته است؛ اگر این پکیج‌ها
نصب نباشند (مثلاً در یک محیطِ CI حداقلی)، این فایل به‌جای شکست خوردن،
skip می‌شود.
"""

import pytest

aiohttp = pytest.importorskip("aiohttp", reason="نیازمندِ aiohttp (طبق requirements.txt)")
bs4 = pytest.importorskip("bs4", reason="نیازمندِ beautifulsoup4 (طبق requirements.txt)")

from trx_ai.medical import MedicalAIEngine


@pytest.fixture()
def engine():
    return MedicalAIEngine()


# ---------------------------------------------------------------------------
#   پارس‌کردن پاسخِ بله/خیر
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("answer,expected", [
    ("بله", True), ("بلی", True), ("آره", True), ("دارم", True),
    ("خیر", False), ("نه", False), ("ندارم", False), ("نخیر", False),
    ("نمیدونم", None), ("شاید", None), ("", None),
])
def test_parse_yes_no(engine, answer, expected):
    assert engine._parse_yes_no(answer) is expected


def test_parse_yes_no_handles_trailing_punctuation(engine):
    assert engine._parse_yes_no("بله!") is True
    assert engine._parse_yes_no("خیر.") is False


# ---------------------------------------------------------------------------
#   گفتگوی تشخیصی
# ---------------------------------------------------------------------------
def test_no_symptoms_returns_done_immediately(engine):
    result = engine.start_symptom_check("test-session", "امروز هوا خوبه")
    assert result["done"] is True
    assert "علائم مشخصی" in result["message"]


def test_emergency_short_circuits_dialogue(engine):
    result = engine.start_symptom_check("test-session", "درد قفسه سینه دارم و نفس بالا نمیاد")
    assert result["done"] is True
    assert result.get("emergency") is True
    assert not engine.has_active_dialogue("test-session")


def test_ambiguous_symptoms_trigger_followup_question(engine):
    result = engine.start_symptom_check("session-a", "تب و سردرد دارم")
    # با فقط دو علامتِ نسبتاً عمومی، چند بیماری کاندید می‌شوند؛ انتظار
    # می‌رود موتور به‌جای حدسِ فوری، سؤال پیگیری بپرسد.
    assert result["done"] is False
    assert "؟" in result["message"]
    assert engine.has_active_dialogue("session-a")


def test_dialogue_clears_after_reaching_final_diagnosis(engine):
    session_key = "session-b"
    result = engine.start_symptom_check(session_key, "تب و سردرد دارم")
    assert result["done"] is False

    # حداکثر ۴ سؤال پیگیری مجاز است (MAX_FOLLOWUP_QUESTIONS)؛ همیشه با
    # «خیر» جواب می‌دهیم تا مطمئن شویم گفتگو در نهایت (نه برای همیشه)
    # به یک تشخیص می‌رسد.
    guard = 0
    while engine.has_active_dialogue(session_key) and guard < 10:
        result = engine.answer_symptom_check(session_key, "خیر")
        guard += 1

    assert result["done"] is True
    assert not engine.has_active_dialogue(session_key)
    # «خیر» به‌عنوانِ پاسخِ اولِ سؤالِ زمینه (مدت/شدت) اطلاعاتی حمل
    # نمی‌کند، پس یک بار به‌عنوانِ پاسخِ نامفهوم شمرده و دوباره پرسیده
    # می‌شود (نگاه کنید به context_validator + guard‌ِ ضدِ حلقه‌یِ
    # بی‌پایان در manager.answer)، قبل از این‌که با فرضِ «نامشخص» ادامه
    # پیدا کند. یعنی سقفِ واقعیِ تعدادِ رفت‌وبرگشت، MAX_FOLLOWUP_QUESTIONS
    # به‌علاوه‌یِ همین یک بازپرسیِ مجاز است.
    assert guard <= MedicalAIEngine.MAX_FOLLOWUP_QUESTIONS + 1


def test_emergency_answer_mid_dialogue_aborts_immediately(engine):
    session_key = "session-c"
    result = engine.start_symptom_check(session_key, "تب و سردرد دارم")
    assert result["done"] is False

    result = engine.answer_symptom_check(session_key, "بله ولی الان تشنج هم کردم")
    assert result["done"] is True
    assert result.get("emergency") is True
    assert not engine.has_active_dialogue(session_key)


def test_unclear_context_answer_reprompts_without_advancing_dialogue(engine):
    """
    این تست قبلاً فرض کرده بود که اولین پیامِ engine همیشه یک سؤالِ
    بله/خیرِ علامتی است (پس last_symptom را قبل از هر پاسخی می‌خواند و
    انتظار داشت بعد از یک پاسخِ نامفهوم هم همان بماند). اما «تب و سردرد
    دارم» نه شدت دارد نه مدت، پس اولین سؤال واقعی CONTEXT_QUESTION است
    (last_symptom در این مرحله هنوز None است) -- و باگِ واقعی این بود که
    یک پاسخِ نامفهوم در همین مرحله، بدونِ اعتبارسنجی، گفتگو را جلو
    می‌برد. این تست دقیقاً همان مرحله را می‌سنجد.
    """
    session_key = "session-d"
    result = engine.start_symptom_check(session_key, "تب و سردرد دارم")
    assert result["done"] is False
    assert engine._dialogues[session_key]["last_symptom"] is None
    turns_before = engine._dialogues[session_key]["turns"]

    result = engine.answer_symptom_check(session_key, "نمیدونم والا")
    assert result["done"] is False
    assert engine.has_active_dialogue(session_key)
    # گفتگو نباید پیشرفت کرده باشد: نه turns افزایش یافته، نه از حالتِ
    # «منتظرِ زمینه» خارج شده (که یعنی هنوز last_symptom ست نشده).
    assert engine._dialogues[session_key]["turns"] == turns_before
    assert engine._dialogues[session_key]["last_symptom"] is None
    # «نمیدونم والا» یک الگویِ صریحِ امتناع است، پس پیامِ بازخواستِ
    # مخصوصِ امتناع را می‌بینیم، نه سؤالِ اصلیِ عیناً تکرارشده.
    from trx_ai.medical.dialogue.questions import CONTEXT_QUESTION
    assert result["message"] != CONTEXT_QUESTION
    assert "حدسِ تقریبی" in result["message"]

    # حالا یک پاسخِ واقعی می‌دهیم؛ این‌بار باید گفتگو واقعاً جلو برود.
    result = engine.answer_symptom_check(session_key, "از دو روز پیش، متوسط")
    assert result["done"] is False
    assert engine._dialogues[session_key]["turns"] == turns_before + 1
    assert engine._dialogues[session_key]["last_symptom"] is not None


def test_two_unclear_context_answers_in_a_row_do_not_deadlock(engine):
    """
    اگر کاربر پشتِ‌سرِهم پاسخِ نامفهوم بدهد، سیستم نباید تا ابد همان
    سؤال را تکرار کند (این خودش یک تجربه‌یِ بد و یک ریسکِ حلقه‌یِ
    بی‌پایان است). بعد از یک بار تلاشِ دوباره، باید بدونِ اطلاعاتِ
    مدت/شدت به مرحله‌یِ بعد برود.
    """
    session_key = "session-d3"
    engine.start_symptom_check(session_key, "تب و سردرد دارم")

    result = engine.answer_symptom_check(session_key, "چی بگم والا")
    assert result["done"] is False
    assert engine._dialogues[session_key]["last_symptom"] is None  # هنوز در مرحله‌یِ زمینه

    result = engine.answer_symptom_check(session_key, "نمیدونم")
    # این‌بار دیگر نباید گیر کند؛ باید به سؤالِ بعدی (یا پایان) برسد.
    assert result["done"] is False
    assert engine._dialogues[session_key]["last_symptom"] is not None


def test_unclear_yes_no_answer_reprompts_without_advancing_dialogue(engine):
    session_key = "session-d2"
    result = engine.start_symptom_check(session_key, "تب و سردرد دارم")
    assert result["done"] is False
    # ابتدا از مرحله‌یِ سؤالِ زمینه با یک پاسخِ معتبر عبور می‌کنیم تا به
    # مرحله‌یِ سؤالِ بله/خیرِ علامتی برسیم.
    result = engine.answer_symptom_check(session_key, "از دو روز پیش، متوسط")
    assert result["done"] is False
    symptom_asked = engine._dialogues[session_key]["last_symptom"]
    assert symptom_asked is not None

    result = engine.answer_symptom_check(session_key, "شاید، نمیدونم")
    assert result["done"] is False
    assert engine.has_active_dialogue(session_key)
    # هنوز همان علامتِ قبلی پرسیده می‌شود (پاسخ نامفهوم بود و گفتگو
    # پیشرفت نکرد)، هرچند متنِ سؤال برای وضوح بیشتر کمی تغییر می‌کند.
    assert engine._dialogues[session_key]["last_symptom"] == symptom_asked
    assert symptom_asked in result["message"]


def test_has_active_dialogue_is_isolated_per_session(engine):
    engine.start_symptom_check("session-x", "تب و سردرد دارم")
    assert engine.has_active_dialogue("session-x")
    assert not engine.has_active_dialogue("session-y")


def test_cancel_dialogue_clears_state(engine):
    engine.start_symptom_check("session-z", "تب و سردرد دارم")
    assert engine.has_active_dialogue("session-z")
    engine.cancel_dialogue("session-z")
    assert not engine.has_active_dialogue("session-z")


# ---------------------------------------------------------------------------
#   _decisive: قطعی‌بودنِ نتیجه نباید فقط به «تعدادِ کاندید» وابسته باشد
# ---------------------------------------------------------------------------
def test_single_weak_candidate_is_not_decisive(engine):
    """
    باگِ قبلی: اگر رتبه‌بندی فقط یک کاندید برمی‌گرداند (مثلاً چون
    پایگاه‌داده‌ی کوچک است)، بدونِ توجه به امتیازش «قطعی» فرض می‌شد.
    این تست مستقیماً manager._decisive را با یک کاندیدِ ضعیف می‌سنجد --
    نباید صرفِ وجودِ یک نتیجه، تصمیمِ پایانِ گفتگو را قطعی کند.
    """
    weak_single = [{"disease": "X", "score": 0.15}]
    assert engine.dialogue._decisive(weak_single) is False

    strong_single = [{"disease": "X", "score": 0.95}]
    assert engine.dialogue._decisive(strong_single) is True


def test_large_gap_with_low_top_score_is_not_decisive(engine):
    """
    باگِ قبلی: منطقِ چندکاندیدی از OR استفاده می‌کرد (score>=0.80 *یا*
    gap>=0.20)، پس یک شکافِ بزرگ با امتیازِ خیلی پایین هم قطعی حساب
    می‌شد. حالا باید AND باشد: هم امتیاز کافی، هم شکاف کافی.
    """
    low_score_big_gap = [
        {"disease": "X", "score": 0.25},
        {"disease": "Y", "score": 0.02},
    ]
    assert engine.dialogue._decisive(low_score_big_gap) is False

    high_score_big_gap = [
        {"disease": "X", "score": 0.85},
        {"disease": "Y", "score": 0.10},
    ]
    assert engine.dialogue._decisive(high_score_big_gap) is True
