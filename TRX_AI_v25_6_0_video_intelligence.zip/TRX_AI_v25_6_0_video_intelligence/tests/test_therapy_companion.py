from trx_ai.medical import MedicalAIEngine
from trx_ai.medical.models import MedicalRequest
from trx_ai.medical.therapy.engine import TherapyCompanionEngine
from trx_ai.medical.therapy import emotions


def test_non_crisis_distress_gets_companion_reply_not_generic_health_tips():
    r = MedicalAIEngine().handle_request(MedicalRequest("امروز خیلی ناراحتم و دلم گرفته", session_id="t1"))
    assert r.intent == "EMOTIONAL_SUPPORT"
    assert "تغذیه متعادل" not in r.answer  # پاسخِ عمومیِ قدیمی نباید برگردد
    assert r.answer.strip()


def test_physical_symptom_keywords_still_go_to_symptom_analysis_not_therapy():
    r = MedicalAIEngine().handle_request(MedicalRequest("تب و سردرد دارم", session_id="t2"))
    assert r.intent == "SYMPTOM_ANALYSIS"


def test_self_harm_phrase_returns_crisis_with_real_hotline_numbers():
    eng = TherapyCompanionEngine()
    r = eng.respond("crisis1", "دیگه نمیخوام زندگی کنم")
    assert r["status"] == "crisis"
    assert r["emergency"] is True
    assert "۱۲۳" in r["message"]
    assert "۱۱۵" in r["message"]


def test_ambiguous_end_it_phrase_is_treated_as_crisis_not_closing():
    """«می‌خوام تمومش کنم» می‌تواند کنایه‌ی رایج فارسی برای پایان‌دادن به
    زندگی باشد -- نباید با عبارتِ بی‌خطرِ «بسه، گفتگو را تمام کن» قاطی شود."""
    eng = TherapyCompanionEngine()
    r = eng.respond("crisis2", "واقعا می‌خوام تمومش کنم")
    assert r["status"] == "crisis"
    assert r["emergency"] is True


def test_negated_self_harm_does_not_trigger_crisis_in_therapy_engine():
    eng = TherapyCompanionEngine()
    r = eng.respond("neg1", "اصلا به فکر خودکشی نیستم فقط یکم ناراحتم")
    assert r["status"] != "crisis"
    assert r["emergency"] is False


def test_crisis_message_shown_once_then_shortened_reminder():
    eng = TherapyCompanionEngine()
    first = eng.respond("s1", "دیگه نمیخوام زندگی کنم")
    second = eng.respond("s1", "واقعا میخوام بمیرم")
    assert len(second["message"]) < len(first["message"])
    assert "۱۲۳" in second["message"]


def test_session_continues_across_turns_without_repeating_keywords():
    """بعد از پیامِ اولِ احساسی، پیامِ بعدی حتی بدونِ هیچ کلیدواژه‌ای باید
    همچنان به همراهِ روان‌شناختی برسد، نه به پاسخِ عمومی."""
    eng = MedicalAIEngine()
    r1 = eng.handle_request(MedicalRequest("امروز خیلی ناراحتم", session_id="cont1"))
    assert r1.intent == "EMOTIONAL_SUPPORT"
    r2 = eng.handle_request(MedicalRequest("بابام دیروز سرم داد زد", session_id="cont1"))
    assert r2.intent == "EMOTIONAL_SUPPORT"


def test_explicit_unrelated_command_exits_companion_continuation():
    eng = TherapyCompanionEngine()
    eng.respond("cont2", "امروز خیلی ناراحتم")
    assert eng.has_active_session("cont2") is True
    assert eng.looks_like_unrelated_command("ساعت چنده الان") is True


def test_explicit_closing_phrase_ends_session():
    eng = TherapyCompanionEngine()
    eng.respond("close1", "ناراحتم")
    assert eng.has_active_session("close1") is True
    eng.respond("close1", "بسه دیگه ممنون")
    assert eng.has_active_session("close1") is False


def test_professional_referral_only_after_sustained_distress_not_first_message():
    eng = TherapyCompanionEngine()
    r = eng.respond("ref1", "امروز خیلی ناراحتم")
    assert "روان‌شناس" not in r["message"]


def test_emotion_detector_never_used_as_clinical_label_in_reply():
    """هیچ پاسخی نباید کلمه‌ی «تشخیص» یا نامِ یک اختلالِ روانی را به کاربر نسبت دهد."""
    eng = TherapyCompanionEngine()
    for msg in ("ناراحتم", "استرس دارم", "تنهام", "عصبانی‌ام", "دیگه نمی‌تونم"):
        r = eng.respond(f"clinical_{msg}", msg)
        assert "افسردگی دارید" not in r["message"]
        assert "اختلال" not in r["message"]


def test_emotions_module_detects_expected_labels():
    assert emotions.detect("امروز خیلی ناراحتم") == "sad"
    assert emotions.detect("خیلی اضطراب دارم") == "anxious"
    assert emotions.detect("خیلی تنهام") == "lonely"
    assert emotions.detect("سلام چطوری") == "neutral"
