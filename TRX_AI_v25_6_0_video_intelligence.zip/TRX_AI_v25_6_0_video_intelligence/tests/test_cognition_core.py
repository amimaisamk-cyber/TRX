# -*- coding: utf-8 -*-
"""
تست‌های واحد برایِ ``trx_ai.agent.cognition`` (Cognition Core Upgrade).

همان فلسفه‌ی ``tests/test_agent_loop.py``: ابزارهایِ ساختگیِ آفلاین،
بدونِ شبکه/دیتابیسِ واقعی، تا تست‌ها سریع و دیتومینستیک بمانند.
دسته‌بندیِ تست‌ها دقیقاً مثالِ‌هایِ رفتاریِ بخشِ ۱۸ سندِ ارتقا را
پوشش می‌دهد (TEST1..TEST6) + قانونِ NEVER_USE_WEB_BY_DEFAULT (بخشِ ۱۱).
"""

from __future__ import annotations

import asyncio

from trx_ai import response_strategy
from trx_ai.agent import AgentConfig, AgentTool, ToolRegistry
from trx_ai.agent.cognition import CognitionCore
from trx_ai.agent.cognition.context import ContextEngine
from trx_ai.agent.cognition.decision import StepRun
from trx_ai.agent.cognition.planning import PlanningEngine, PlanStep
from trx_ai.agent.cognition.reasoning import ReasoningEngine
from trx_ai.agent.cognition.reflection import ReflectionReport
from trx_ai.agent.cognition.response import ResponseEngine
from trx_ai.agent.cognition.understanding import Understanding, analyze
from trx_ai.agent.types import AgentTrace, StopReason


# ==================================================================
#   ابزارهایِ ساختگی
# ==================================================================


async def _web_stub(query: str = "", **_) -> str:
    return f"[WEB] نتیجه‌ی جستجو برایِ «{query}» با جزئیاتِ کافی برایِ عبور از Reflection."


async def _calc_stub(query: str = "", **_) -> str:
    return "[CALC] نتیجه‌ی محاسبه: ۴۲ (جزئیاتِ کافی برایِ عبورِ Reflection)."


async def _code_stub(query: str = "", **_) -> str:
    return "[CODE] تحلیلِ کد انجام شد و خطا پیدا شد (جزئیاتِ کافی برایِ عبورِ Reflection)."


def _make_registry() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(
        AgentTool(name="web_search", description="وب", keywords=["چیست", "کیست", "جستجو"], run=_web_stub)
    )
    registry.register(
        AgentTool(name="calculator", description="ماشین‌حساب", keywords=["+", "-", "محاسبه"], run=_calc_stub)
    )
    registry.register(
        AgentTool(
            name="code_intelligence",
            description="کد",
            keywords=["کد", "def", "خطا", "بررسی", "پروژه", "مشکل"],
            run=_code_stub,
        )
    )
    return registry


# ==================================================================
#   ReasoningEngine -- بخشِ ۵/۱۱ سند
# ==================================================================


def test_reasoning_conversational_needs_no_tool():
    """TEST1 سند: «از دستت خسته شدم» -> گفتگو، نه Web/ابزار."""
    u = analyze("از دستت خسته شدم.")
    ctx = ContextEngine.build()
    verdict = ReasoningEngine.assess(u, ctx)
    assert verdict.needs_tool is False
    assert verdict.allow_web is False


def test_reasoning_code_error_excludes_web():
    """TEST2 سند: «این کد چرا کار نمی‌کنه؟» -> Code Analysis، نه Web."""
    u = analyze("این کد چرا خطا می‌ده؟ ```def f(): pass```")
    ctx = ContextEngine.build()
    verdict = ReasoningEngine.assess(u, ctx)
    assert verdict.needs_tool is True
    assert verdict.allow_web is False
    assert verdict.preferred_tool == "code_intelligence"


def test_reasoning_live_info_allows_web():
    """TEST5 سند: «قیمتِ امروزِ دلار چنده؟» -> Web/Live Information مجاز."""
    u = analyze("قیمتِ امروزِ دلار چنده؟")
    ctx = ContextEngine.build()
    verdict = ReasoningEngine.assess(u, ctx)
    assert verdict.needs_tool is True
    assert verdict.allow_web is True
    assert verdict.preferred_tool == "web_search"


def test_reasoning_ambiguous_text_never_defaults_to_web():
    """NEVER_USE_WEB_BY_DEFAULT (بخشِ ۱۱): بدونِ سرنخِ صریح، Web مجاز نیست."""
    u = analyze("راجع به این موضوع بیشتر بگو")
    ctx = ContextEngine.build()
    verdict = ReasoningEngine.assess(u, ctx)
    assert verdict.allow_web is False


def test_reasoning_multi_step_detected():
    """TEST6 سند: هدفِ چندمرحله‌ای تشخیص داده شود."""
    u = analyze("این پروژه رو بررسی کن و بعدش مشکل اصلی رو پیدا کن.")
    ctx = ContextEngine.build()
    verdict = ReasoningEngine.assess(u, ctx)
    assert verdict.is_multi_step is True


# ==================================================================
#   PlanningEngine -- بخشِ ۶ سند
# ==================================================================


def test_planning_single_step_for_simple_goal():
    u = analyze("این کد چرا خطا می‌ده؟")
    verdict = ReasoningEngine.assess(u, ContextEngine.build())
    plan = PlanningEngine.build_plan(u.text, verdict)
    assert plan.is_multi_step is False
    assert len(plan.steps) == 1


def test_planning_splits_multi_step_goal():
    goal = "این پروژه رو بررسی کن و بعدش مشکل اصلی رو پیدا کن."
    u = analyze(goal)
    verdict = ReasoningEngine.assess(u, ContextEngine.build())
    plan = PlanningEngine.build_plan(goal, verdict)
    assert plan.is_multi_step is True
    assert len(plan.steps) == 2


# ==================================================================
#   CognitionCore (سرتاسری) -- بخشِ ۲/۷ سند
# ==================================================================


def test_cognition_core_conversation_calls_no_tool():
    async def _run():
        core = CognitionCore(_make_registry(), AgentConfig(verbose=False))
        trace = await core.run("از دستت خسته شدم.")
        tools_used = [s.action.tool_name for s in trace.steps if s.action.tool_name]
        assert tools_used == []
        assert trace.success is True

    asyncio.run(_run())


def test_cognition_core_code_task_avoids_web():
    async def _run():
        core = CognitionCore(_make_registry(), AgentConfig(verbose=False))
        trace = await core.run("این کد چرا خطا می‌ده؟ ```def f(): pass```")
        tools_used = [s.action.tool_name for s in trace.steps if s.action.tool_name]
        assert "code_intelligence" in tools_used
        assert "web_search" not in tools_used

    asyncio.run(_run())


def test_cognition_core_live_info_uses_web():
    async def _run():
        core = CognitionCore(_make_registry(), AgentConfig(verbose=False))
        trace = await core.run("قیمتِ امروزِ دلار چنده؟")
        tools_used = [s.action.tool_name for s in trace.steps if s.action.tool_name]
        assert "web_search" in tools_used

    asyncio.run(_run())


def test_cognition_core_ambiguous_text_does_not_call_web_by_default():
    async def _run():
        core = CognitionCore(_make_registry(), AgentConfig(verbose=False))
        trace = await core.run("راجع به این موضوع بیشتر بگو")
        tools_used = [s.action.tool_name for s in trace.steps if s.action.tool_name]
        assert "web_search" not in tools_used

    asyncio.run(_run())


def test_cognition_core_multi_step_goal_executes_both_steps():
    async def _run():
        core = CognitionCore(
            _make_registry(), AgentConfig(verbose=False, max_steps=6, max_wall_seconds=20)
        )
        trace = await core.run("این پروژه رو بررسی کن و بعدش مشکل اصلی رو پیدا کن.")
        assert trace.success is True
        # هر دو مرحله باید در پاسخِ نهایی حضور داشته باشند (شماره‌گذاریِ ۱./۲.)
        assert "1." in trace.final_answer and "2." in trace.final_answer

    asyncio.run(_run())


def test_cognition_core_without_web_tool_still_works():
    """
    تستِ «بدونِ Web» (بخشِ ۲۱ سند): اگر ابزارِ web_search اصلاً در
    رجیستری ثبت نشده باشد (کاملاً غیرفعال)، بقیه‌ی قابلیت‌ها (گفتگو،
    تحلیلِ کد) همچنان باید کار کنند.
    """

    async def _run():
        registry = ToolRegistry()
        registry.register(
            AgentTool(
                name="code_intelligence",
                description="کد",
                keywords=["کد", "def", "خطا"],
                run=_code_stub,
            )
        )
        core = CognitionCore(registry, AgentConfig(verbose=False))

        conv_trace = await core.run("امروز خیلی خسته‌ام.")
        assert conv_trace.success is True

        code_trace = await core.run("این کد چرا خطا می‌ده؟ ```def f(): pass```")
        assert code_trace.success is True
        assert any(s.action.tool_name == "code_intelligence" for s in code_trace.steps)

    asyncio.run(_run())


# ==================================================================
#   ارتقایِ Core (v25.4.0) -- اتصالِ واقعیِ Context به حافظه
#   (پیش از این، ``long_term_hint`` همیشه خالی می‌ماند و ``context``
#   در ``ReasoningEngine.assess`` هیچ‌وقت خوانده نمی‌شد -- تستِ زیر
#   دقیقاً همان دو نقصِ رفع‌شده را قفل می‌کند.)
# ==================================================================


class _FakeMemory:
    """جایگزینِ ساختگیِ ``MemoryEngine`` -- فقط همان چند متد/فیلدی که
    ``ContextEngine.build`` استفاده می‌کند، بدونِ هیچ وابستگیِ سنگین."""

    def __init__(self):
        self.current_topic = "RTX4090"
        self.entity_stack = ["RTX4090"]
        self.short_term = list(range(5))

    def get_context(self, max_messages=6, include_summary=True):
        return "[۱۲:۰۰] کاربر: RTX4090 چیه؟\n[۱۲:۰۱] AI: یک کارتِ گرافیکه."

    def get_relevant_memory(self, query, limit=3):
        return [{"type": "fact", "content": "RTX4090 محصولِ NVIDIA است.", "score": 0.9}]


class _FakeAI:
    def __init__(self):
        self.memory = _FakeMemory()


def test_context_engine_pulls_long_term_hint_from_real_memory():
    """قبل از ارتقا: ``long_term_hint`` همیشه ``""`` بود، حتی وقتی
    ``ai.memory.get_relevant_memory`` نتیجه‌ی مرتبط داشت."""
    ctx = ContextEngine.build(ai=_FakeAI(), query="RTX4090 چیه")
    assert ctx.active_topic == "RTX4090"
    assert "RTX4090" in ctx.recent_history_text
    assert "NVIDIA" in ctx.long_term_hint
    assert ctx.turn_count == 5


def test_context_engine_without_ai_stays_backward_compatible():
    """بدونِ ``ai``/``query`` (مثلِ همه‌ی تست‌هایِ قبلیِ این فایل)، رفتار
    باید دقیقاً مثلِ قبل از ارتقا بمانَد -- خالی، بدونِ خطا."""
    ctx = ContextEngine.build()
    assert ctx.active_topic == ""
    assert ctx.long_term_hint == ""
    assert ctx.recent_history_text == ""
    assert ctx.turn_count == 0


def test_reasoning_rationale_now_reflects_real_context():
    """قبل از ارتقا: ``context`` پارامترِ ``assess`` بود اما هیچ‌جایِ
    بدنه‌ی تابع خوانده نمی‌شد -- یعنی موضوعِ فعال/شکست‌هایِ قبلی/سرنخِ
    حافظه هیچ اثری روی rationale (یا هرجایِ دیگر) نداشتند.

    «قیمتش چنده؟» عمداً انتخاب شده: نه سرنخِ محلی دارد، نه ``STRONG``
    (چون فاصله‌یِ بعدِ «قیمت» نیست: «قیمتش» نه «قیمتِ »)، نه ``WEAK``یِ
    زمانی -- یعنی طبقِ NEVER_USE_WEB_BY_DEFAULT به شاخه‌ی ۵ (پیش‌فرضِ
    محافظه‌کارانه) می‌رسد. نکته‌یِ تست این‌جا خودِ *تصمیم* نیست (که
    عمداً دست‌نخورده مانده) بلکه این‌که rationale آن حالا واقعاً از
    Context خبر دارد.
    """
    u = analyze("قیمتش چنده؟")
    ctx = ContextEngine.build(ai=_FakeAI(), query="قیمتش چنده", previous_failures=3)
    verdict = ReasoningEngine.assess(u, ctx)
    assert "Context:" in verdict.rationale
    assert "RTX4090" in verdict.rationale
    assert "تلاشِ ناموفق" in verdict.rationale
    # تصمیمِ ابزار عمداً دست‌نخورده مانده (بخشِ ۵ سند، شاخه‌ی پیش‌فرضِ
    # محافظه‌کارانه) -- این ارتقا فقط rationale را غنی می‌کند، نه منطقِ
    # انتخاب را؛ یعنی هیچ تستِ رفتاریِ قبلی نباید عوض شود.
    assert verdict.needs_tool is True
    assert verdict.allow_web is False
    assert verdict.preferred_tool is None


def test_cognition_core_empty_goal_returns_error_gracefully():
    async def _run():
        core = CognitionCore(_make_registry(), AgentConfig(verbose=False))
        trace = await core.run("   ")
        assert trace.success is False
        assert trace.final_answer

    asyncio.run(_run())


# ==================================================================
#   ارتقایِ Communication Core (v25.4.1) -- اتصالِ واقعیِ
#   ``communication_profile``/``reply_hints`` به ``ResponseEngine``
#   (پیش از این دو تابع نوشته شده بودند ولی هیچ‌جا صدا زده نمی‌شدند --
#   دقیقاً همان الگویِ «توهمِ پیشرفت» که در Audit مشخص شد).
# ==================================================================


def _make_understanding(strategy: str, user_state: str, turn_count: int) -> Understanding:
    raw = {"context": {"turn_count": turn_count, "previous_failures": 0}}
    return Understanding(
        text="خیلی خسته‌ام ولی این کار رو انجام بده",
        request_kind="command",
        intent="task",
        intent_confidence=0.5,
        user_state=user_state,
        user_state_secondary=[],
        response_strategy=strategy,
        conversation_phase="ongoing",
        raw=raw,
    )


def test_reply_hint_backward_compatible_with_first_variant():
    """``reply_hint`` (مفرد) باید دقیقاً همان نسخه‌ی اولِ ``reply_hints``
    را برگرداند -- فراخوان‌هایِ موجود مثلِ ``tool_router.py`` نباید هیچ
    رگرسیونی ببینند."""
    for strategy, variants in response_strategy.STRATEGY_REPLY_HINTS.items():
        assert response_strategy.reply_hint(strategy) == variants[0]


def test_response_engine_rotates_hint_variants_by_turn_count():
    """قبل از این ارتقا، هر بار که کاربر «خسته‌ام» می‌گفت، دقیقاً همان
    یک جمله برمی‌گشت -- حالا با نوبت‌هایِ مختلف، نسخه‌ی متفاوتی انتخاب
    می‌شود (بخشِ ۱۳ سند: «آیا پاسخ‌ها طبیعی هستند؟»)."""
    variants = response_strategy.reply_hints("empathetic_short")
    assert len(variants) > 1, "این تست فقط برایِ راهبردهایِ چندنسخه‌ای معنا دارد"

    u_turn0 = _make_understanding("empathetic_short", "tired", 0)
    u_turn1 = _make_understanding("empathetic_short", "tired", 1)
    hint0 = ResponseEngine._pick_hint("empathetic_short", u_turn0)
    hint1 = ResponseEngine._pick_hint("empathetic_short", u_turn1)

    assert hint0 in variants and hint1 in variants
    assert hint0 != hint1
    assert hint0 == variants[0]  # نوبتِ صفر -> همان رفتارِ قبل از ارتقا


def test_response_engine_single_variant_strategy_is_stable():
    """راهبردهایی که هنوز فقط یک نسخه دارند نباید با تغییرِ turn_count
    رفتارشان عوض شود."""
    variants = response_strategy.reply_hints("celebrate_success")
    assert len(variants) == 1
    for turn in (0, 1, 5, 100):
        u = _make_understanding("celebrate_success", "satisfied", turn)
        assert ResponseEngine._pick_hint("celebrate_success", u) == variants[0]


def test_response_engine_shortens_body_for_short_length_profile():
    """``communication_profile(...)["length"] == "short"`` باید واقعاً
    بدنه‌ی نتیجه را کوتاه کند -- قبل از این ارتقا ``communication_profile``
    هیچ‌جا خوانده نمی‌شد."""
    assert response_strategy.communication_profile("empathetic_short")["length"] == "short"

    long_answer = "نتیجه‌ی کاملِ ابزار. " * 80
    trace = AgentTrace(
        goal="x", final_answer=long_answer, success=True,
        stop_reason=StopReason.GOAL_SATISFIED, steps=[],
    )
    step = PlanStep(index=0, text="انجامِ کار", preferred_tool=None, allow_web=False)
    run = StepRun(step=step, trace=trace)
    report = ReflectionReport(satisfied=True, confidence=0.9)

    u_tired = _make_understanding("empathetic_short", "tired", 0)
    body, *_ = ResponseEngine.compose_plan_result(u_tired, [run], report)
    assert len(body) < len(long_answer)
    assert body.startswith(response_strategy.reply_hints("empathetic_short")[0])


def test_response_engine_neutral_state_body_untouched():
    """مسیرِ خنثی (که همه‌ی تست‌هایِ قبلیِ این فایل رویش تکیه می‌کنند)
    نباید هیچ تغییری ببیند -- نه hint، نه کوتاه‌سازی."""
    long_answer = "نتیجه‌ی کاملِ ابزار. " * 80
    trace = AgentTrace(
        goal="x", final_answer=long_answer, success=True,
        stop_reason=StopReason.GOAL_SATISFIED, steps=[],
    )
    step = PlanStep(index=0, text="انجامِ کار", preferred_tool=None, allow_web=False)
    run = StepRun(step=step, trace=trace)
    report = ReflectionReport(satisfied=True, confidence=0.9)

    u_neutral = _make_understanding("normal", "neutral", 3)
    body, *_ = ResponseEngine.compose_plan_result(u_neutral, [run], report)
    assert body == long_answer.strip()
