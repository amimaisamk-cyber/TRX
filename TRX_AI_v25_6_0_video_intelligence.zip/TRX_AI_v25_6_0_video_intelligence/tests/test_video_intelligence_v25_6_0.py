# -*- coding: utf-8 -*-
"""
تست‌هایِ ارتقایِ «Video Intelligence» (v25.6.0) -- نقشهٔ فازها: A معنا، B گراف، C زمان/دوربین/حرکت،
D صدا، E رندر، F تنوع/قطعیت، G اعتبارسنجی/ترمیم، H منابع، I چندصحنه‌ای، J یکپارچگی، K سازگاریِ عقب‌رو.
تست‌هایِ «probe» رندرِ واقعیِ JS را در Node اجرا می‌کنند و بدونِ Node skip می‌شوند.
"""

import copy
import json

import pytest

from trx_ai.video import (pipeline, project as pj, scene_planner as sp, semantic_validator as sv, repair as rp,
                          resource_guard as rg, render_probe, audio_planner as ap, timeline_engine as tl,
                          environment_library as envlib, object_library as objlib, explain, patch_engine,
                          runtime_manager as rt, session_manager as sm, html_generator, scene_builder,
                          request_normalizer, validator as safety)
from trx_ai.video.scene_graph import SceneGraph, Node
from trx_ai.video.scene_schema import SceneSpec
from trx_ai.video.semantic_planner import understand, extract_requirements
from trx_ai.video.renderers import HTMLCanvasRenderer  # noqa: F401
from trx_ai.video.renderers.html_canvas import supported_drawer_kinds as drawer_kinds

NIGHT_RAIN = ("یک صحنه بارانی شبانه بساز که دوربین آرام به سمت یک خانه قدیمی نزدیک شود "
              "و صدای باران شنیده شود. رعد و برق هم باشد، بدون موسیقی")
needs_node = pytest.mark.skipif(not render_probe.available(), reason="Node در دسترس نیست")


@pytest.fixture(autouse=True)
def isolated(monkeypatch, tmp_path):
    store = sm.SceneSessionStore(persist_path=None)
    monkeypatch.setattr(sm, "_default_store", store)
    monkeypatch.setattr(rt, "_files_dir", lambda: str(tmp_path))
    return store


# ======================= A) Semantic Planner =======================

def test_negation_music_is_requirement_not_feature():
    it = understand("یک صحنه جنگل بساز بدون موسیقی")
    assert it.audio["music"] is False
    reqs = extract_requirements(it)
    m = [r for r in reqs if r.kind == "music"]
    assert m and m[0].negated


def test_word_boundary_no_false_moon_or_night():
    assert understand("یه ماهی بساز").subject is None            # «ماهی» ≠ «ماه»
    assert understand("یه چیز شبیه خانه").time_of_day is None    # «شبیه» ≠ «شب»


def test_event_order_preserved():
    it = understand("باران شروع شود و سپس متوقف شود، رعد و برق هم باشد")
    kinds = [e.kind for e in it.events]
    assert kinds.index("rain_start") < kinds.index("rain_stop")
    assert [e.order for e in it.events] == list(range(len(it.events)))


def test_explicit_vs_default_requirements():
    reqs = extract_requirements(understand("یک ویدیو بساز"))
    assert reqs == []                          # هیچ خواستهٔ صریحی نیست → هیچ requirement ساختگی
    ids = [r.id for r in extract_requirements(understand(NIGHT_RAIN))]
    assert ids == [f"REQ-{i:03d}" for i in range(1, len(ids) + 1)]


def test_empty_or_vague_request_never_asks_question_and_builds():
    b = pipeline.build_video("یک ویدیو بساز")
    assert b.status == "ok" and b.html


def test_identity_request_is_recorded_unsupported_not_silently_ignored():
    b = pipeline.build_video("ویدیویی دیپ فیک از یک فرد واقعی بساز")
    c = [r for r in b.results if r.kind == "constraint"]
    assert c and c[0].status == sv.UNSUPPORTED


def test_duration_and_aspect_extraction():
    it = understand("یک ویدیوی ۳۰ ثانیه‌ای عمودی 9:16 بساز")
    assert it.duration == 30.0 and it.aspect_ratio == "9:16"
    assert understand("۵ دقیقه ویدیو").duration == 60.0       # سقفِ موبایل + ثبتِ uncertainty
    assert any(u.field == "duration" for u in understand("۵ دقیقه ویدیو").uncertainty)


def test_semantic_key_ignores_wording_but_not_meaning():
    a = understand("یک صحنه بارانی شبانه")
    b = understand("شبانه، صحنه‌ی بارانی")
    c = understand("یک صحنه برفی شبانه")
    assert a.semantic_key() == b.semantic_key() != c.semantic_key()


def test_intent_roundtrip():
    from trx_ai.video.semantic_planner.intent import VideoIntent
    it = understand(NIGHT_RAIN)
    assert VideoIntent.from_dict(json.loads(json.dumps(it.to_dict()))).semantic_key() == it.semantic_key()


# ======================= B) Scene Graph =======================

def test_graph_rejects_dangling_cycle_and_unknown_relation():
    g = SceneGraph()
    g.add(Node(id="a", type="x"))
    g.add(Node(id="b", type="x", parent="a"))
    g.nodes["a"].parent = "b"
    assert any("حلقه" in e for e in g.validate())
    g2 = SceneGraph()
    g2.add(Node(id="a", type="x"))
    g2.relations.append(__import__("trx_ai.video.scene_graph", fromlist=["Relation"]).Relation("near", "a", "zzz"))
    assert any("ناموجود" in e for e in g2.validate())
    with pytest.raises(ValueError):
        g2.relate("teleports_to", "a", "a")


def test_planned_scene_graph_valid_and_camera_target_exists():
    b = pipeline.build_video(NIGHT_RAIN)
    sc = b.project.scenes[0]
    g = SceneGraph.from_dict(sc.graph)
    assert g.validate() == []
    assert sc.camera.target in g.nodes
    assert ("looks_at", "camera", "subject") in [(r.kind, r.source, r.target) for r in g.relations]
    assert ("illuminated_by", "subject", "window_light") in [(r.kind, r.source, r.target) for r in g.relations]


def test_invalid_camera_target_is_caught_structurally():
    sc = pipeline.build_video(NIGHT_RAIN).project.scenes[0]
    sc.camera.target = "ghost"
    assert any("camera.target" in e for e in sv.validate_structure(sc))


# ======================= C) Timeline / Camera / Motion =======================

def test_timeline_dependency_resolution_and_cycle():
    ev = tl.resolve([tl.Planned("a", "x", at=1.0), tl.Planned("b", "y", after="a", offset=0.5)], 10)
    assert {e.id: e.time for e in ev} == {"a": 1.0, "b": 1.5}
    with pytest.raises(tl.TimelineError):
        tl.resolve([tl.Planned("a", "x", after="b"), tl.Planned("b", "y", after="a")], 5)


def test_rain_start_then_stop_curve_matches_events():
    b = pipeline.build_video("باران شروع شود و سپس متوقف شود", max_repairs=0)
    sc = b.project.scenes[0]
    vals = [tl.value_at(sc.timeline, "weather", "intensity", sc.duration * i / 50) for i in range(51)]
    assert vals[0] < 0.1 and max(vals) > 0.9 and vals[-1] < 0.1
    assert all(r.status == sv.PASS for r in b.results)


def test_slow_dolly_in_uses_eased_motion_toward_target():
    sc = pipeline.build_video(NIGHT_RAIN).project.scenes[0]
    c = sc.camera
    assert c.move == "dolly_in" and c.zoom_end > c.zoom_start and c.easing != "linear" and c.target == "subject"
    assert (c.origin_x, c.origin_y) != (0.5, 0.5) or True


def test_follow_camera_targets_character_and_walk_direction():
    b = pipeline.build_video("شخصیت از چپ به راست راه برود و دوربین او را دنبال کند")
    sc = b.project.scenes[0]
    assert sc.camera.move == "follow" and sc.camera.target in ("subject", "character_1")
    mv = [e for e in sc.timeline if e.event == "motion"][0]
    assert mv.to > mv.value
    assert all(r.status == sv.PASS for r in b.results)


# ======================= D) Audio =======================

def test_explicit_silence_has_no_events_and_music_never_auto():
    b = pipeline.build_video("زیر آب بدونِ صدا")
    assert b.project.global_audio() == [] and b.project.explicit_silence
    b2 = pipeline.build_video("جنگل بارانی")
    assert not any(e["type"] == "music" for e in b2.project.global_audio())


def test_every_planned_source_has_synth_recipe_in_js():
    html = pipeline.build_video("جنگل بارانی با رعد و برق و موسیقی و راه رفتن شخصیت از چپ به راست و در باز شود").html
    facts = sv.inspect_html(html)
    used = {e["source"] for e in facts.project["global_audio"]}
    assert used - {"tts"} <= facts.recipes, used - facts.recipes


def test_sync_report_all_ok_for_complex_scene():
    b = pipeline.build_video("شب بارانی، رعد و برق، شخصیت از چپ به راست راه برود با صدای قدم، در باز شود با صدای در", max_repairs=0)
    sync = [s for sc in b.project.scenes for s in ap.sync_report(sc)]
    assert sync and all(s["ok"] for s in sync), sync


def test_thunder_always_follows_flash_within_tolerance():
    sc = pipeline.build_video("رعد و برق").project.scenes[0]
    for t in [e for e in sc.audio.events if e["source"] == "thunder"]:
        d = min(t["start"] - f.time for f in sc.timeline if f.event == "flash" and t["start"] >= f.time)
        assert 0 <= d <= ap.SYNC_TOLERANCE_S


def test_narration_fits_scene_and_has_subtitles():
    b = pipeline.build_video("تخت جمشید غروب، ۸ ثانیه، با روایت فارسی")
    n = b.project.narration()
    assert n and n["start"] + n["duration"] <= b.project.total
    assert any(lb["role"] == "subtitle" for lb in b.project.scenes[0].labels)
    assert next(r for r in b.results if r.kind == "narration").status == sv.PASS


def test_audio_event_schema_validation_catches_bad_events():
    bad = [{"id": "x", "type": "ambience", "source": "rain", "start": -1, "duration": 1, "volume": 3, "loop": False}]
    errs = ap.validate_events(bad, 8)
    assert errs and any("ناقص" in e for e in errs)


# ======================= E) Renderer contract =======================

def test_drawers_cover_all_known_kinds_and_weather():
    d = set(drawer_kinds())
    assert set(objlib.KNOWN_KINDS) <= d
    assert {"rain", "snow", "fog"} <= d


def test_unsupported_kinds_are_not_drawable_and_flagged():
    assert not (set(objlib.UNSUPPORTED_KINDS) & set(drawer_kinds()))
    b = pipeline.build_video("یک اژدها بساز")
    r = next(r for r in b.results if r.kind == "subject")
    assert r.status == sv.UNSUPPORTED and "placeholder" in r.evidence


def test_html_passes_legacy_safety_validator_and_is_self_contained():
    html = pipeline.build_video(NIGHT_RAIN).html
    rep = safety.validate_html(html)
    assert rep["passed"], rep["issues"]
    assert "http://" not in html and "https://" not in html


@needs_node
@pytest.mark.parametrize("env", list(envlib.SUPPORTED_ENVIRONMENTS))
def test_every_environment_renders_without_runtime_error(env):
    from trx_ai.video import project as P
    it = understand(f"یک صحنه بساز")
    it.environment = env
    proj = P.build_project(it)
    html = pipeline.render_project(proj)
    pr = render_probe.probe(html, [0.5, proj.total / 2, proj.total - 0.3])
    assert pr["errors"] == [] and pr["runtime_error"] is None
    assert all(sum(f["ops"].values()) > 20 for f in pr["frames"])


# ======================= F) Determinism & variation =======================

def _strip_ids(d):
    s = json.dumps(d, sort_keys=True, ensure_ascii=False)
    import re
    return re.sub(r"scene_\d+_[0-9a-f]{6}|vp_\d+_[0-9a-f]{6}", "ID", s)


def test_same_seed_same_output_different_seed_differs():
    a = pj.build_project(understand("جنگل seed=7"))
    b = pj.build_project(understand("جنگل seed=7"))
    c = pj.build_project(understand("جنگل seed=8"))
    assert _strip_ids(a.to_dict()) == _strip_ids(b.to_dict())
    assert _strip_ids(a.to_dict()) != _strip_ids(c.to_dict())


def test_ten_trees_are_not_identical():
    env = envlib.build_environment("forest", 3, "high")
    trees = [d for d in env["decor"] if d["k"] == "tree"]
    assert len(trees) >= 8 and len({(d["h"], d["w"], d["x"], d["tone"]) for d in trees}) == len(trees)


def test_stable_seed_derived_from_meaning():
    assert sp.stable_seed(understand("جنگل بارانی")) == sp.stable_seed(understand("بارانیِ جنگل"))


def test_old_house_is_more_worn_than_new():
    a = objlib.make_object("house", 1, old=True)["wear"]
    b = objlib.make_object("house", 1, old=False)["wear"]
    assert a > b


# ======================= G) Validation & Repair =======================

def _broken(prompt):
    b = pipeline.build_video(prompt, max_repairs=0)
    return b


def test_validator_detects_missing_weather_and_repair_restores_it():
    b = pipeline.build_video("یک صحنه بارانی شبانه با خانه", max_repairs=0)
    sc = b.project.scenes[0]
    g = sp.load_graph(sc)
    g.remove("weather")
    sp.save_graph(sc, g)
    sc.weather = "none"
    sc.timeline = [e for e in sc.timeline if e.target != "weather"]
    html = pipeline.render_project(b.project)
    res = sv.check_requirements(b.requirements, html)
    assert any(r.status == sv.FAIL and r.kind == "weather" for r in res)
    rp.repair(b.project, b.intent, [r for r in res if r.status == sv.FAIL])
    html2 = pipeline.render_project(b.project)
    res2 = sv.check_requirements(b.requirements, html2)
    assert all(r.status == sv.PASS for r in res2), [(r.kind, r.status, r.evidence) for r in res2]


def test_validator_detects_bad_camera_target_and_repair_fixes_only_camera_related():
    b = pipeline.build_video(NIGHT_RAIN, max_repairs=0)
    sc = b.project.scenes[0]
    sc.camera.target = "ghost"
    res = sv.check_requirements(b.requirements, pipeline.render_project(b.project))
    assert any(r.kind == "camera" and r.status == sv.FAIL for r in res)
    weather_before = json.dumps(sp.load_graph(sc).get("weather").to_dict(), sort_keys=True)
    rp.repair(b.project, b.intent, [r for r in res if r.status == sv.FAIL])
    assert sc.camera.target == "subject"
    assert json.dumps(sp.load_graph(sc).get("weather").to_dict(), sort_keys=True) == weather_before


def test_dropped_audio_event_detected_and_repaired():
    b = pipeline.build_video("باران با صدای باران", max_repairs=0)
    b.project.scenes[0].audio.events = []
    res = sv.check_requirements(b.requirements, pipeline.render_project(b.project))
    assert any(r.kind == "audio" and r.status == sv.FAIL for r in res)
    rp.repair(b.project, b.intent, [r for r in res if r.status == sv.FAIL])
    res2 = sv.check_requirements(b.requirements, pipeline.render_project(b.project))
    assert all(r.status == sv.PASS for r in res2)


def test_unsupported_is_never_repaired_or_hidden():
    b = pipeline.build_video("یک اژدها بساز")
    assert b.repairs == []
    assert b.status in ("ok", "degraded")        # UNSUPPORTED شکست نیست ولی گزارش می‌شود
    assert "پشتیبانی نشد" in explain.user_summary(b)


def test_repair_loop_terminates_when_no_progress():
    b = pipeline.build_video("رعد و برق", max_repairs=3)
    assert len(b.repairs) <= 3


def test_sync_break_detected_by_quality_report():
    b = pipeline.build_video("رعد و برق", max_repairs=0)
    th = next(e for e in b.project.scenes[0].audio.events if e["source"] == "thunder")
    th["start"] += 5
    html = pipeline.render_project(b.project)
    res, rep = pipeline.verify(b.project, html, b.requirements)
    assert rep["sync"]["failed"] and not rep["passed"]


# ======================= H) Resource guard =======================

def test_degradation_prefers_secondary_detail_and_keeps_required():
    it = understand("شب بارانی با خانه و صدای باران، شخصیت از چپ به راست")
    proj = pj.build_project(it, quality="high")
    before = rg.estimate(proj)
    saved = {k: v for k, v in rg.PROFILES["low"].items()}
    rg.PROFILES["low"]["max_cost"] = 1.5
    try:
        d = rg.degrade(proj, "low")
    finally:
        rg.PROFILES["low"].update(saved)
    assert d and rg.estimate(proj)["cost"] < before["cost"]
    sc = proj.scenes[0]
    g = sp.load_graph(sc)
    assert g.get("subject") and g.get("weather") and g.get("camera")
    assert any(e["source"] == "rain" for e in sc.audio.events)            # صدایِ صریح حذف نمی‌شود
    assert [e for e in sc.timeline if e.event == "motion"]


def test_cancel_and_timeout_are_cooperative():
    tok = rg.CancelToken()
    tok.cancel()
    with pytest.raises(rg.VideoCancelled):
        pipeline.build_video(NIGHT_RAIN, token=tok)
    with pytest.raises(rg.VideoTimeout):
        pipeline.build_video(NIGHT_RAIN, token=rg.CancelToken(timeout_s=-1))


def test_plan_cache_hits_only_for_same_meaning_and_returns_independent_copy():
    cache = rg.PlanCache()
    a = pipeline.build_video("جنگل بارانی شبانه", cache=cache)
    b = pipeline.build_video("شبانه جنگل بارانی", cache=cache)
    c = pipeline.build_video("جنگل برفی شبانه", cache=cache)
    assert (a.cache_hit, b.cache_hit, c.cache_hit) == (False, True, False)
    assert b.project.scenes[0].scene_id != a.project.scenes[0].scene_id        # شناسهٔ تازه
    b.project.scenes[0].lighting.intensity = 0.01
    d = pipeline.build_video("جنگل بارانی شبانه", cache=cache)
    assert d.project.scenes[0].lighting.intensity != 0.01                      # mutation نشت نمی‌کند


def test_profile_changes_render_scale_and_html_stays_under_cap():
    lo = pipeline.build_video("جنگل بارانی", quality="low")
    hi = pipeline.build_video("جنگل بارانی", quality="high")
    assert lo.project.scenes[0].render_scale["w"] < hi.project.scenes[0].render_scale["w"]
    assert hi.report["html_bytes"] < 300_000


# ======================= I) Multi-scene & continuity =======================

def test_three_scene_story_is_continuous_and_each_scene_differs_in_camera():
    b = pipeline.build_video("یک داستان سه‌صحنه‌ای از یک خانه در شب بارانی")
    assert len(b.project.scenes) == 3 and len(b.project.transitions) == 2
    assert b.report["continuity_errors"] == []
    moves = [s.camera.move for s in b.project.scenes]
    assert len(set(moves)) >= 2
    assert abs(b.project.total - sum(s.duration for s in b.project.scenes)) < 1e-6
    assert all(r.status == sv.PASS for r in b.results)


def test_continuity_break_is_detected():
    b = pipeline.build_video("یک داستان سه‌صحنه‌ای از یک خانه")
    b.project.scenes[1].weather = "snow"
    b.project.scenes[2].seed += 1
    errs = sv.continuity_issues(b.project)
    assert any("آب‌وهوا" in e for e in errs) and any("seed" in e for e in errs)


def test_global_audio_merges_continuous_ambience_across_scenes():
    b = pipeline.build_video("داستان سه‌صحنه‌ای جنگل با صدای باد")
    wind = [e for e in b.project.global_audio() if e["source"] == "wind"]
    assert len(wind) == 1 and abs(wind[0]["duration"] - b.project.total) < 0.05


def test_time_transition_across_scenes_only_at_boundary():
    b = pipeline.build_video("داستان سه‌صحنه‌ای روستا، تغییر نور از روز به شب")
    tods = [s.time_of_day for s in b.project.scenes]
    assert tods[0] == "day" and tods[-1] == "night"
    assert b.report["continuity_errors"] == []


# ======================= J) Runtime integration =======================

def test_runtime_create_uses_v2_and_reports_requirements(tmp_path):
    r = rt.handle_video_request("s1", "video_generation", NIGHT_RAIN)
    assert r["status"] == "success" and r["diagnostics"]["engine"] == "v2"
    assert r["diagnostics"]["requirements"]["FAIL"] == 0 and r["user_summary"]
    html = open(r["html_path"], encoding="utf-8").read()
    assert safety.validate_html(html)["passed"]


def test_runtime_patch_on_v2_scene_changes_lighting_and_keeps_session():
    r1 = rt.handle_video_request("s2", "video_generation", NIGHT_RAIN)
    sess = sm.get_default_store().get("s2")
    before = sess.project.scenes[0].lighting.intensity
    r2 = rt.handle_video_request("s2", "video_edit_scene", "نور رو کم کن")
    assert r2["status"] == "success" and r2["mode"] == "patch" and r2["diagnostics"]["engine"] == "v2"
    after = sm.get_default_store().get("s2").project.scenes[0].lighting.intensity
    assert after < before
    assert r2["scene_id"] == r1["scene_id"]


def test_patch_slow_down_resyncs_footsteps_with_motion():
    rt.handle_video_request("s3", "video_generation", "شخصیت از چپ به راست راه برود با صدای قدم، ۱۰ ثانیه")
    rt.handle_video_request("s3", "video_edit_scene", "حرکت رو آهسته تر کن")
    sc = sm.get_default_store().get("s3").project.scenes[0]
    mv = [e for e in sc.timeline if e.event == "motion"][0]
    steps = [e for e in sc.audio.events if e["source"] == "footstep"]
    assert steps and all(mv.time - 1e-6 <= s["start"] <= mv.time + mv.duration + 1e-6 for s in steps)
    assert all(s["ok"] for s in ap.sync_report(sc))


def test_kill_switch_forces_legacy_engine(monkeypatch):
    monkeypatch.setenv("TRX_VIDEO_ENGINE", "legacy")
    r = rt.handle_video_request("s4", "video_generation", "یه صحنه جنگل بساز")
    assert r["status"] == "success" and r["diagnostics"].get("engine") != "v2"


def test_v2_failure_falls_back_to_legacy(monkeypatch):
    def boom(*a, **k):
        raise RuntimeError("synthetic v2 failure")
    monkeypatch.setattr(pipeline, "build_video", boom)
    r = rt.handle_video_request("s5", "video_generation", "یه صحنه جنگل بساز")
    assert r["status"] == "success" and r["diagnostics"].get("engine") != "v2"


def test_session_persistence_roundtrip_with_project(tmp_path):
    path = str(tmp_path / "sess.json")
    store = sm.SceneSessionStore(persist_path=path)
    b = pipeline.build_video("داستان سه‌صحنه‌ای از خانه")
    store.save("p", b.project.scenes[0], "x.html", b.project)
    again = sm.SceneSessionStore(persist_path=path).get("p")
    assert again.project is not None and len(again.project.scenes) == 3
    assert again.scene is again.project.scenes[0]
    html2 = pipeline.render_project(again.project)
    assert safety.validate_html(html2)["passed"]


# ======================= K) Backward compatibility =======================

def test_legacy_scene_dict_still_loads_and_renders_with_legacy_generator():
    norm = request_normalizer.normalize_request("یه صحنه ۶ ثانیه‌ای زیر آب بساز با حباب")
    sc = scene_builder.build_scene(norm, quality="medium")
    d = sc.to_dict()
    for k in ("seed", "environment", "graph", "labels", "requirements"):   # شبیه‌سازیِ دادهٔ ذخیره‌شدهٔ نسخه‌هایِ قبل
        d.pop(k, None)
    for o in d["objects"]:
        for k in ("kind", "seed", "pos_x", "pos_y", "size", "attrs"):
            o.pop(k, None)
    sc2 = SceneSpec.from_dict(d)
    assert sc2.validate() == [] and safety.validate_html(html_generator.generate_html(sc2))["passed"]


def test_old_timeline_events_serialize_to_old_shape():
    sc = scene_builder.build_scene(request_normalizer.normalize_request("یه صحنه جنگل"), quality="low")
    for e in sc.timeline:
        d = e.to_dict()
        assert set(d) == {"time", "event"}


def test_architecture_no_import_cycles_semantic_planner_independent():
    import ast, pathlib
    root = pathlib.Path(__file__).resolve().parent.parent / "trx_ai" / "video" / "semantic_planner"
    for f in root.glob("*.py"):
        tree = ast.parse(f.read_text(encoding="utf-8"))
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom) and n.module:
                assert not (n.level >= 2 and n.module.startswith(("video", "core_engine"))), (f.name, n.module)
                assert "html_generator" not in n.module and "renderers" not in n.module


# ======================= L) Render probe: واقعاً اجرا و بازرسی =======================

def _frame(pr, i):
    return pr["frames"][i]["stats"]


@needs_node
def test_probe_flash_appears_at_flash_time_and_thunder_fires_after():
    b = pipeline.build_video("رعد و برق", max_repairs=0)
    sc = b.project.scenes[0]
    tf = [e.time for e in sc.timeline if e.event == "flash"][0]
    th = [e for e in sc.audio.events if e["source"] == "thunder"][0]["start"]
    pr = render_probe.probe(b.html, [tf + 0.05, tf + 2.0], [tf - 0.5, tf + 0.1, th + 0.1])
    assert _frame(pr, 0).get("flash") == 1 and "flash" not in _frame(pr, 1)
    fired = pr["audio"]["fired"]
    assert any("thunder" in f for f in fired)


@needs_node
def test_probe_rain_absent_after_stop_and_present_before():
    b = pipeline.build_video("باران شروع شود و سپس متوقف شود", max_repairs=0)
    D = b.project.total
    sc = b.project.scenes[0]
    stop = [e for e in sc.timeline if e.id == "wx_stop"][0]
    pr = render_probe.probe(b.html, [stop.time - 0.5, stop.time + stop.duration + 0.3])
    assert _frame(pr, 0).get("rain", 0) > 0 and _frame(pr, 1).get("rain", 0) == 0


@needs_node
def test_probe_character_moves_right_and_camera_zooms_in():
    b = pipeline.build_video("شخصیت از چپ به راست راه برود و دوربین او را دنبال کند، ۱۰ ثانیه", max_repairs=0)
    pr = render_probe.probe(b.html, [1.5, 5.0, 8.5])
    xs = [_frame(pr, i)["char_x"] for i in range(3)]
    assert xs[0] < xs[1] < xs[2]
    b2 = pipeline.build_video(NIGHT_RAIN, max_repairs=0)
    pr2 = render_probe.probe(b2.html, [0.2, 4.0, 7.5])
    zs = [_frame(pr2, i)["cam_zoom_x1000"] for i in range(3)]
    assert zs[0] < zs[1] < zs[2]


@needs_node
def test_probe_day_to_night_darkens_sky_and_lights_window():
    b = pipeline.build_video("تغییر نور از روز به شب در یک روستا با پنجره روشن", max_repairs=0)
    pr = render_probe.probe(b.html, [0.3, b.project.total - 0.3])
    assert "celestial:sun" in _frame(pr, 0) and "celestial:moon" in _frame(pr, 1)
    assert "window_light" not in _frame(pr, 0) and "window_light" in _frame(pr, 1)


@needs_node
def test_probe_silence_and_music_policy_in_runtime():
    b = pipeline.build_video("جنگل با صدای باد بدون موسیقی", max_repairs=0)
    pr = render_probe.probe(b.html, [1.0], [0.5, 1.0, 2.0])
    assert pr["audio"]["on"]
    assert pr["audio"]["voices"] and all("wind" in v for v in pr["audio"]["voices"])   # فقط باد؛ هیچ voiceِ music نیست
