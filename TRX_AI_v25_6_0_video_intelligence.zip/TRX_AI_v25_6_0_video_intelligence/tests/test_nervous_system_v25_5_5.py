# -*- coding: utf-8 -*-
"""
تست‌هایِ Nervous System Coordinator -- v25.5.5 (PHASE 1 + PHASE 2 سند).

سه چیز اثبات می‌شود:

1. ``UnifiedConversationContext`` واقعاً از خروجیِ real pipeline
   (``conversation_engine.process`` end-to-end، نه mock) ساخته می‌شود و
   فیلدهایش با تصمیمِ واقعی هم‌خوان‌اند.
2. **عدمِ تخریب (SHADOW safety):** روشن‌کردنِ Coordinator
   (``TRX_NERVOUS_SYSTEM_ENABLED=1``) حتی یک بیت از خروجیِ
   ``RoutingDecision``/سه‌تاییِ legacy را تغییر نمی‌دهد -- دقیقاً معیارِ
   PHASE 8 سند («مرحله‌یِ SHADOW»).
3. **fail-soft واقعی:** اگر خودِ Coordinator خطا بدهد، نوبتِ مکالمه
   هنوز جواب می‌دهد (استثنا هرگز بیرون نمی‌رود).
"""

from __future__ import annotations

import os

import pytest

from trx_ai.conversation import conversation_engine, state_tracker
from trx_ai.nervous_system import config as ns_config
from trx_ai.nervous_system import get_coordinator
from trx_ai.nervous_system.coordinator import NervousSystemCoordinator
from trx_ai.nervous_system.context_schema import UnifiedConversationContext
from trx_ai.nervous_system.influence_audit import (
    assert_non_interference,
    classify_coordinator_influence,
)


@pytest.fixture
def conv_id():
    cid = "pytest_nervous_system_v25_5_5"
    state_tracker.reset_snapshot(cid)
    yield cid
    state_tracker.reset_snapshot(cid)


@pytest.fixture(autouse=True)
def _reset_ns_flag(monkeypatch):
    """هر تست با فلگِ خاموش (پیش‌فرضِ واقعیِ production) شروع می‌شود."""
    monkeypatch.delenv("TRX_NERVOUS_SYSTEM_ENABLED", raising=False)
    monkeypatch.setattr(ns_config, "NERVOUS_SYSTEM_ENABLED", False, raising=False)
    yield


# ----------------------------------------------------------------------
#  1) ساختِ UnifiedConversationContext از یک pipeline واقعی
# ----------------------------------------------------------------------
def test_coordinator_builds_context_from_real_pipeline(conv_id, monkeypatch):
    monkeypatch.setattr(ns_config, "NERVOUS_SYSTEM_ENABLED", True, raising=False)

    # conversation_engine خودش ``from ..nervous_system import get_coordinator``
    # را در زمانِ اجرا (نه در زمانِ importِ ماژول) صدا می‌زند -- پس همان
    # singleton واقعی را می‌خوانیم؛ نیازی به monkeypatch نیست.
    real_coordinator = get_coordinator()

    result = conversation_engine.process(
        "امروز خیلی حالم خوبه",
        conversation_id=conv_id,
    )
    assert result is not None

    ctx = real_coordinator.get_latest(conv_id)
    assert ctx is not None, "وقتی فلگ روشن است، Coordinator باید یک context ذخیره کرده باشد"
    assert isinstance(ctx, UnifiedConversationContext)
    assert ctx.conversation_id == conv_id
    assert ctx.current_message == "امروز خیلی حالم خوبه"
    assert ctx.intent == result[0]
    assert ctx.intent_confidence == pytest.approx(result[1])
    assert ctx.source_modules  # لیستِ ماژول‌هایِ منبع خالی نیست
    assert ctx.built_at > 0
    assert ctx.turn_latency_ms >= 0


def test_coordinator_disabled_by_default_produces_no_context(conv_id):
    """پیش‌فرضِ production: فلگ خاموش -- هیچ context ای ذخیره نمی‌شود."""
    coordinator = get_coordinator()
    result = conversation_engine.process("سلام", conversation_id=conv_id)
    assert result is not None
    # ممکن است از تست‌هایِ قبلی چیزی برایِ همین conv_id نمانده باشد؛
    # نکته‌یِ اصلی این است که هیچ رکوردِ *جدیدی* برایِ همین پیام اضافه
    # نشد -- چون فلگ خاموش است.
    latest = coordinator.get_latest(conv_id)
    if latest is not None:
        assert latest.current_message != "سلام"


# ----------------------------------------------------------------------
#  2) عدمِ تخریب -- خروجیِ نهایی با/بدونِ Coordinator کاملاً یکسان است
# ----------------------------------------------------------------------
def test_shadow_mode_never_changes_final_decision(conv_id, monkeypatch):
    message = "همون قبلی رو بهتر کن"

    state_tracker.reset_snapshot(conv_id)
    monkeypatch.setattr(ns_config, "NERVOUS_SYSTEM_ENABLED", False, raising=False)
    result_without = conversation_engine.process(message, conversation_id=conv_id)

    state_tracker.reset_snapshot(conv_id)
    monkeypatch.setattr(ns_config, "NERVOUS_SYSTEM_ENABLED", True, raising=False)
    result_with = conversation_engine.process(message, conversation_id=conv_id)

    assert result_without == result_with, (
        "SHADOW mode باید بی‌اثر باشد: روشن‌کردنِ Coordinator نباید حتی "
        "یک فیلد از (intent, confidence, raw_text) را تغییر دهد"
    )


def test_assert_non_interference_helper_matches_manual_check(conv_id, monkeypatch):
    from trx_ai.conversation.schemas import RoutingDecision

    a = RoutingDecision(route="conversation", selected_intent="general", confidence=0.5, raw_text="x")
    b = RoutingDecision(route="conversation", selected_intent="general", confidence=0.5, raw_text="x")
    c = RoutingDecision(route="tool", selected_intent="weather", confidence=0.9, raw_text="x")

    assert assert_non_interference(a, b) is True
    assert assert_non_interference(a, c) is False


# ----------------------------------------------------------------------
#  3) fail-soft -- خطایِ داخلیِ Coordinator نباید نوبت را بترکاند
# ----------------------------------------------------------------------
def test_coordinator_failure_never_breaks_the_turn(conv_id, monkeypatch):
    monkeypatch.setattr(ns_config, "NERVOUS_SYSTEM_ENABLED", True, raising=False)

    broken = NervousSystemCoordinator()

    def _boom(**kwargs):
        raise RuntimeError("simulated coordinator failure")

    monkeypatch.setattr(broken, "build_context", _boom)
    monkeypatch.setattr("trx_ai.nervous_system.get_coordinator", lambda: broken, raising=False)

    # نکته: چون ایمپورت داخلِ تابع است (``from ..nervous_system import
    # get_coordinator``)، پچِ بالا رویِ ماژولِ nervous_system کافی است --
    # هر بار ``_observe_nervous_system`` اجرا شود، همین نسخه‌ی پچ‌شده را
    # می‌گیرد.
    result = conversation_engine.process("چیکارا بلدی؟", conversation_id=conv_id)
    assert result is not None, "خرابیِ Coordinator نباید کل نوبت را بترکاند"


# ----------------------------------------------------------------------
#  4) خوداظهاریِ صادقانه‌یِ Influence Audit (PHASE 1)
# ----------------------------------------------------------------------
def test_coordinator_self_reports_as_orphan_in_shadow_stage():
    report = classify_coordinator_influence()
    assert report.influence == "ORPHAN", (
        "در مرحله‌یِ SHADOW فعلی، هیچ مصرف‌کننده‌ای وصل نیست -- ادعایِ "
        "FUNCTIONAL در این مرحله خودش یک نمونه‌یِ «توهمِ پیشرفت» است."
    )
    assert report.status == "LIVE"


# ----------------------------------------------------------------------
#  5) بافرِ محدود -- بدونِ نشتِ حافظه
# ----------------------------------------------------------------------
def test_history_buffer_is_bounded():
    coordinator = NervousSystemCoordinator(history_maxlen=3, max_conversations=2)

    for i in range(10):
        ctx = UnifiedConversationContext(conversation_id="c1", current_message=f"m{i}")
        coordinator.record(ctx)

    history = coordinator.get_history("c1")
    assert len(history) == 3
    assert history[-1].current_message == "m9"

    # سقفِ تعدادِ گفتگوها -- اضافه‌کردنِ گفتگویِ سوم باید قدیمی‌ترین را حذف کند
    coordinator.record(UnifiedConversationContext(conversation_id="c2", current_message="a"))
    coordinator.record(UnifiedConversationContext(conversation_id="c3", current_message="b"))
    assert coordinator.tracked_conversation_count() <= 2
