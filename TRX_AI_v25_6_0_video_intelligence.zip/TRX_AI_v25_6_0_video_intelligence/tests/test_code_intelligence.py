# -*- coding: utf-8 -*-
"""
تست‌های واحد برای CodeIntelligence (trx_ai/tools.py) — آنالیزگرِ کد بر
پایه‌ی ast. هدف: جلوگیری از رگرسیون در تشخیصِ مشکلاتِ امنیتی/ساختاری و
در استخراجِ کد از متنِ آزادِ فارسی.
"""

import pytest

aiohttp = pytest.importorskip("aiohttp", reason="نیازمندِ aiohttp (طبق requirements.txt)")
bs4 = pytest.importorskip("bs4", reason="نیازمندِ beautifulsoup4 (طبق requirements.txt)")

from trx_ai.tools import CodeIntelligence


def test_empty_input_is_rejected():
    result = CodeIntelligence.analyze_and_fix("")
    assert "هیچ کدی" in result


def test_clean_code_gets_perfect_score():
    code = '''
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b
'''
    result = CodeIntelligence.analyze_and_fix(code)
    assert "100/۱۰۰" in result
    assert "هیچ مشکلِ قابل‌توجهی پیدا نشد" in result


def test_syntax_error_is_reported_with_line_number():
    code = "def f()\n    print('hi')"
    result = CodeIntelligence.analyze_and_fix(code)
    assert "خطای سینتکس" in result
    assert "خط 1" in result


@pytest.mark.parametrize("dangerous_call", ["eval(x)", "exec(x)", "os.system(x)", "pickle.loads(x)"])
def test_dangerous_calls_are_flagged_as_security_issues(dangerous_call):
    code = f"def f(x):\n    return {dangerous_call}\n"
    result = CodeIntelligence.analyze_and_fix(code)
    assert "مشکلاتِ امنیتی" in result


def test_bare_except_is_flagged():
    code = "def f():\n    try:\n        pass\n    except:\n        pass\n"
    result = CodeIntelligence.analyze_and_fix(code)
    assert "except:" in result and "بدون مشخص‌کردنِ نوعِ خطا" in result


def test_mutable_default_argument_is_flagged():
    code = "def f(items=[]):\n    items.append(1)\n    return items\n"
    result = CodeIntelligence.analyze_and_fix(code)
    assert "آرگومانِ پیش‌فرضِ قابل‌تغییر" in result


def test_extracts_code_from_persian_prefix_and_fence():
    code = """این کد رو تحلیل کن:
```python
def add(a, b):
    return a + b
```"""
    result = CodeIntelligence.analyze_and_fix(code)
    # نباید به‌خاطرِ پیشوندِ فارسی، خطای سینتکسِ کاذب بدهد
    assert "خطای سینتکس" not in result
    assert "🟢 عالی" in result


def test_high_complexity_and_deep_nesting_are_flagged():
    code = """
def complicated(a, b, c, d, e, f, g):
    if a:
        if b:
            if c:
                if d:
                    for i in range(10):
                        if e and f or g:
                            print(i)
    return a
"""
    result = CodeIntelligence.analyze_and_fix(code)
    assert "تو‌در‌تو شده" in result
    assert "آرگومان" in result  # هشدارِ تعداد زیادِ آرگومان‌ها


def test_analyze_project_reports_summary_for_real_directory(tmp_path):
    (tmp_path / "a.py").write_text("def foo():\n    pass\n", encoding="utf-8")
    (tmp_path / "b.py").write_text("class Bar:\n    def method(self):\n        pass\n", encoding="utf-8")

    result = CodeIntelligence.analyze_project(str(tmp_path))
    assert "تعداد فایل‌ها: 2" in result
    assert "تعداد توابع" in result
    assert "تعداد کلاس‌ها" in result


def test_analyze_project_missing_directory():
    result = CodeIntelligence.analyze_project("/this/path/does/not/exist")
    assert "وجود ندارد" in result
