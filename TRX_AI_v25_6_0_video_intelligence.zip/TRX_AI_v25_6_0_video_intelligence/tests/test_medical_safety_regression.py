from trx_ai.medical import MedicalAIEngine
from trx_ai.medical.safety.redflags import check_any_redflags

def test_negated_emergency_does_not_escalate():
    assert check_any_redflags("درد قفسه سینه ندارم") is None

def test_negated_self_harm_does_not_escalate():
    assert check_any_redflags("نمی‌خوام خودکشی کنم") is None

def test_real_emergency_escalates():
    assert check_any_redflags("الان نمی‌توانم نفس بکشم") is not None

def test_public_engine_returns_structured_response():
    r=MedicalAIEngine().handle_request(__import__('trx_ai.medical', fromlist=['MedicalRequest']).MedicalRequest("تب و سردرد دارم"))
    d=r.to_dict(); assert d["intent"] == "SYMPTOM_ANALYSIS"; assert "probability" not in d
