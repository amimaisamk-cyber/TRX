import pytest

from trx_ai.conversation_patterns import ConversationPatternEngine


def test_build_emotional_pattern():
    turns = [
        {"role": "user", "content": "امروز خیلی خوشحالم چون پروژه‌ام بالاخره درست شد"},
        {"role": "assistant", "content": "چه خوب!"},
        {"role": "user", "content": "می‌خوام ادامه‌اش بدم و چند قابلیت جدید اضافه کنم"},
    ]
    p = ConversationPatternEngine.build_pattern(turns)
    assert p["emotion"] in {"happy", "excited"}
    assert p["type"] in {"celebration", "planning", "technical"}
    assert p["strategy"]
    assert p["topics"]


def test_relevance_prefers_matching_emotion_and_topic(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "test.db"))
    engine = ConversationPatternEngine(db)
    engine.add({"id": "1", "type": "venting", "emotion": "sad", "topics": ["دوست", "ناراحت"], "strategy": "همدلانه", "strength": 0.8})
    engine.add({"id": "2", "type": "technical", "emotion": "neutral", "topics": ["پایتون"], "strategy": "فنی", "strength": 0.8})
    found = engine.relevant("از رفتار دوستم ناراحتم و دلم گرفته")
    ids = [p["id"] for p in found]
    # توجه: قبلاً اینجا `found[0]["id"] == "1"` چک می‌شد -- یعنی فرض شده
    # بود «۱» همیشه رتبه‌ی اولِ *مطلق* را می‌گیرد. اما engine از قبل
    # صدها الگویِ builtin هم دارد، و بعد از رفعِ باگِ source_bonus (که
    # قبلاً بدونِ‌قید‌وشرط امتیاز می‌داد)، اگر یکی از آن الگوهایِ
    # builtin واقعاً متنِ نزدیک‌تری به پرسش داشته باشد، حق دارد رتبه‌ی
    # بالاتری بگیرد -- این خودِ رفتارِ *درستِ* رتبه‌بندیِ مبتنی‌بر شاهد
    # است، نه رگرسیون. چیزی که این تست واقعاً باید تضمین کند (و اسمش هم
    # همین را می‌گوید): «۱» (احساس/موضوعِ منطبق) باید هم در نتایج باشد و
    # هم رتبه‌اش از «۲» (کاملاً نامنطبق) بالاتر باشد -- نه رتبه‌ی مطلقِ
    # اول در برابرِ کلِ کاتالوگ.
    assert "1" in ids
    if "2" in ids:
        assert ids.index("1") < ids.index("2")


def test_pattern_captures_dialogue_need_and_arc():
    turns = [
        {"role": "user", "content": "امروز خیلی ناراحتم و دلم گرفته"},
        {"role": "assistant", "content": "می‌فهمم."},
        {"role": "user", "content": "بعدش دوستم پیام داد و حالم بهتر شد"},
        {"role": "assistant", "content": "خوبه که بهتر شدی."},
        {"role": "user", "content": "حالا می‌خوام درباره پروژه‌ام حرف بزنم"},
    ]
    p = ConversationPatternEngine.build_pattern(turns)
    assert p["need"] in {"emotional_support", "companionship", "planning", "conversation"}
    assert p["dialogue_act"] in {"request", "sharing", "continuation"}
    assert "->" in p["arc"] or p["arc"].startswith("focused:")


def test_pattern_prompt_contains_current_state(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "test.db"))
    engine = ConversationPatternEngine(db)
    engine.add({"id": "1", "type": "venting", "emotion": "sad", "need": "emotional_support", "dialogue_act": "sharing", "topics": ["دوست"], "strategy": "همدلانه", "strength": 0.9})
    ctx = engine.prompt_context("از رفتار دوستم ناراحتم")
    assert "وضعیت فعلی" in ctx
    assert "راهبرد" in ctx


def test_every_user_message_becomes_an_utterance_pattern(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "test.db"))
    engine = ConversationPatternEngine(db)
    engine.observe("user", "امروز خیلی خسته‌ام و دلم گرفته")
    engine.observe("assistant", "می‌فهمم.")
    engine.observe("user", "فقط می‌خواستم با یکی حرف بزنم")
    learned = engine.recent_utterance_patterns(10)
    assert len(learned) == 2
    assert "فقط" in learned[0]["text"] and "حرف بزنم" in learned[0]["text"]
    assert learned[1]["support_mode"] is True


def test_sad_user_gets_companionship_not_unsolicited_solution(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "test.db"))
    engine = ConversationPatternEngine(db)
    assert engine.emotional_support_mode("امروز خیلی ناراحتم و دلم گرفته") is True
    assert engine.emotional_support_mode("ناراحتم، راهکار بده") is False
    engine.observe("user", "از رفتار دوستم خیلی ناراحتم")
    ctx = engine.prompt_context("دلم گرفته و فقط می‌خوام حرف بزنم")
    assert "اول دردش را بشنو" in ctx
    assert "راهکار" in ctx


def test_broad_builtin_conversation_corpus_is_seeded(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "seed.db"))
    engine = ConversationPatternEngine(db)
    assert len(engine.patterns) >= 140
    types = {p.get("type") for p in engine.patterns if p.get("source") == "builtin"}
    assert {"venting", "technical", "planning", "learning", "creative", "storytelling"}.issubset(types)


def test_pattern_has_signature_confidence_and_sequence_fields():
    turns = [
        {"role": "user", "content": "امروز خیلی ناراحتم و دلم گرفته"},
        {"role": "assistant", "content": "می‌فهمم."},
        {"role": "user", "content": "بعدش دوستم پیام داد و حالم بهتر شد"},
    ]
    p = ConversationPatternEngine.build_pattern(turns)
    assert p["signature"] == ConversationPatternEngine.signature(p)
    assert "|" in p["signature"]
    assert 0.0 <= p["confidence"] <= 1.0
    assert p["act_sequence"] and len(p["act_sequence"]) == 2
    # بدونِ sentence-transformers نصب‌شده، context_emb باید بی‌صدا None بماند
    # (بدونِ رگرسیون -- دقیقاً مثلِ emb).
    assert p["context_emb"] is None


def test_sequence_similarity_is_order_aware():
    a = ["question", "sharing", "gratitude"]
    assert ConversationPatternEngine.sequence_similarity(a, a) == 1.0
    assert ConversationPatternEngine.sequence_similarity(a, list(reversed(a))) < 1.0
    assert ConversationPatternEngine.sequence_similarity([], a) == 0.0
    assert ConversationPatternEngine.sequence_similarity(a, []) == 0.0


def test_repeated_utterance_signature_raises_confidence(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "sig.db"))
    engine = ConversationPatternEngine(db)
    engine.observe("user", "امروز خیلی ناراحتم و دلم گرفته")
    engine.observe("assistant", "می‌فهمم.")
    # بازآراییِ *دقیقِ* همان کلماتِ جمله‌ی اول (نه یک پیامِ تازه با یک
    # کلمه‌ی جدید) -- برایِ اینکه واقعاً بی‌حساسیت‌بودنِ امضا نسبت به
    # ترتیبِ کلمات را تست کند. با «بازم دلم گرفته...» (که «بازم» را
    # به‌جایِ «خیلی» جایگزین می‌کرد) این تست باگ‌دار بود: امضا با
    # bigramِ حساس‌به‌ترتیب می‌ساخت، پس حتی *معنایِ کاملاً یکسان* هم
    # قبلاً گاهی امضایِ متفاوت می‌گرفت -- رجوع به توضیحِ کاملِ
    # ``ConversationPatternEngine.signature``.
    engine.observe("user", "دلم گرفته و امروز خیلی ناراحتم")
    learned = engine.recent_utterance_patterns(2)
    newest, older = learned[0], learned[1]
    # دومین گفته با همان امضایِ رفتاریِ اولی، باید تکرار را دیده باشد و
    # اطمینانش نسبت به اطمینانِ صرفاً لغویِ خام کمی بالاتر رفته باشد.
    assert newest["repeat_count"] >= 1
    assert newest["signature"] == older["signature"]


def test_signature_frequency_counts_matching_signatures(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "freq.db"))
    engine = ConversationPatternEngine(db)
    engine.observe("user", "امروز خیلی ناراحتم و دلم گرفته")
    engine.observe("user", "بازم دلم گرفته و ناراحتم امروز")
    sig = engine.recent_utterance_patterns(1)[0]["signature"]
    assert engine.signature_frequency(sig) >= 1


def test_prompt_context_surfaces_confidence(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "conf.db"))
    engine = ConversationPatternEngine(db)
    engine.add({"id": "1", "type": "venting", "emotion": "sad", "need": "emotional_support", "dialogue_act": "sharing", "topics": ["دوست"], "strategy": "همدلانه", "strength": 0.9})
    ctx = engine.prompt_context("از رفتار دوستم ناراحتم")
    assert "اطمینانِ برچسب" in ctx


def test_broad_corpus_retrieves_different_domains(tmp_path):
    from trx_ai.database import DatabaseManager
    db = DatabaseManager(str(tmp_path / "domains.db"))
    engine = ConversationPatternEngine(db)
    queries = {
        "پایتون و خطای برنامه": "technical",
        "برای سفر برنامه می‌خوام": "planning",
        "دلم گرفته فقط گوش بده": "venting",
        "یک داستان علمی تخیلی بساز": "creative",
        "امروز یک اتفاق عجیب افتاد": "storytelling",
        "چطور یک مفهوم را یاد بگیرم؟": "learning",
    }
    for q, expected in queries.items():
        found = engine.relevant(q, 6)
        assert any(p.get("type") == expected for p in found), (q, expected, [p.get("type") for p in found])


# ---------------------------------------------------------------------------
#   باگِ واقعی: تطبیقِ substringِ خام (نه مرزِ کلمه) در کلیدواژه‌های
#   احساس/نوع/نیاز -- کشف‌شده و رفع‌شده در همین ارتقاء.
# ---------------------------------------------------------------------------
def test_type_cue_does_not_match_inside_unrelated_word():
    """«کد» (نشانه‌ی technical) نباید داخلِ «کدام»/«کدوم» match بگیرد."""
    t = ConversationPatternEngine._conversation_type(
        "کدام رستوران بهتره؟ نمیدونم کدومو انتخاب کنم"
    )
    assert t != "technical", f"باگِ substring برگشته: نوع اشتباهاً {t!r} شد"


@pytest.mark.parametrize("text,expected", [
    ("امروز رفتم خونه", False),   # «نه» داخلِ «خونه»
    ("چه بهانه‌ی جالبی", False),   # «نه» داخلِ «بهانه»
    ("وقت ندارم امروز", True),    # نفیِ واقعی باید هنوز تشخیص داده شود
    ("نمیخوام برم", True),        # پیشوندِ چسبیده‌ی «نمی»
    ("نمی‌خوام برم", True),       # همان با نیم‌فاصله‌ی واقعی
    ("امروز حالم خوبه", False),   # هیچ نشانه‌ی نفی‌ای ندارد
])
def test_negation_uses_word_boundary_not_raw_substring(text, expected):
    assert ConversationPatternEngine._negation(text) is expected
