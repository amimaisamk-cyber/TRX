# -*- coding: utf-8 -*-
"""
تست‌های واحد برای ابزارهای کمکیِ غیرِ نمایشیِ UIEngine (trx_ai/ui.py):
تبدیل ارقام فارسی/انگلیسی و تبدیل تقویم. این تست‌ها به رندرِ واقعیِ
ترمینال کاری ندارند، فقط منطقِ محاسباتی را می‌سنجند.
"""

import pytest

rich = pytest.importorskip("rich", reason="نیازمندِ rich (طبق requirements.txt)")

from trx_ai.ui import UIEngine


@pytest.fixture()
def ui():
    return UIEngine()


def test_e2f_converts_english_digits_to_persian(ui):
    assert ui.e2f(12345) == "۱۲۳۴۵"
    assert ui.e2f("2024") == "۲۰۲۴"


def test_f2e_converts_persian_digits_to_english(ui):
    assert ui.f2e("۱۲۳۴۵") == "12345"


def test_e2f_and_f2e_are_inverses(ui):
    original = "20260707"
    assert ui.f2e(ui.e2f(original)) == original


def test_get_farsi_date_time_returns_two_non_empty_strings(ui):
    date_str, time_str = ui.get_farsi_date_time()
    assert date_str and time_str
    # باید فقط ارقامِ فارسی در خروجی باشد، نه ارقامِ انگلیسی (ASCII)
    assert not any(ch in "0123456789" for ch in date_str)


def test_reshape_fa_never_raises_on_arbitrary_text(ui):
    from trx_ai.ui import reshape_fa
    # نباید برای متنِ خالی، فقط‌انگلیسی، یا آمیخته خطا بدهد
    assert reshape_fa("") == ""
    assert isinstance(reshape_fa("hello"), str)
    assert isinstance(reshape_fa("سلام دنیا! Hello World 123"), str)


@pytest.mark.parametrize("known_gregorian,expected_jalali", [
    # ۲۰ مارس ۲۰۲۴ برابر است با ۱ فروردین ۱۴۰۳ (نوروز)
    ((2024, 3, 20), (1403, 1, 1)),
])
def test_gregorian_to_jalali_known_dates(ui, known_gregorian, expected_jalali):
    result = ui._gregorian_to_jalali(*known_gregorian)
    assert result == expected_jalali
