# -*- coding: utf-8 -*-
"""
tests/test_native_model_training_phase2.py -- تستِ واحدِ بسته‌یِ
``trx_ai.trx_model.training.data_pipeline`` (سندِ فازِ دومِ آموزشِ
Native Model: آماده‌سازیِ داده، Smoke Test، Checkpoint سه‌سطحی،
Resume، Generalization).
"""

from __future__ import annotations

import os
import tempfile

import numpy as np
import pytest

from trx_ai.trx_model.model import TRXModelConfig, TRXNativeModel
from trx_ai.trx_model.tokenizer import ByteLevelBPETokenizer
from trx_ai.trx_model.training.checkpoint import CheckpointMeta
from trx_ai.trx_model.training.data_pipeline import checkpoint_policy
from trx_ai.trx_model.training.data_pipeline.cleaning import clean_document, remove_duplicate_lines
from trx_ai.trx_model.training.data_pipeline.corpus_builder import (
    Document,
    run_cleaning_stage,
    run_quality_stage,
    split_into_paragraph_documents,
)
from trx_ai.trx_model.training.data_pipeline.dedup import deduplicate
from trx_ai.trx_model.training.data_pipeline.generalization_test import _has_repeating_ngram
from trx_ai.trx_model.training.data_pipeline.quality import score_document
from trx_ai.trx_model.training.data_pipeline.resource_monitor import ResourceMonitor, check_disk_space
from trx_ai.trx_model.training.data_pipeline.sequence_packing_check import check_sequence_packing
from trx_ai.trx_model.training.data_pipeline.smoke_test import SmokeTestFailure, run_smoke_test
from trx_ai.trx_model.training.data_pipeline.split import split_documents
from trx_ai.trx_model.training.dataset import build_sequences, train_val_split
from trx_ai.trx_model.training.optim import AdamW


# ------------------------------------------------------------------ cleaning ----


def test_clean_document_removes_empty_and_short():
    assert clean_document("").kept is False
    assert clean_document("   \n\n  ").kept is False
    assert clean_document("کوتاه").kept is False  # زیرِ MIN_MEANINGFUL_LENGTH


def test_clean_document_strips_html_and_keeps_persian_content():
    raw = "<div>سلام <b>دنیا</b> این یک متنِ نسبتاً طولانی برایِ تستِ HTML است.</div>"
    result = clean_document(raw)
    assert result.kept
    assert "<div>" not in result.cleaned_text
    assert "سلام" in result.cleaned_text


def test_clean_document_preserves_zwnj():
    raw = "این متن نیم‌فاصله‌ی فارسی را باید حفظ کند و طول کافی داشته باشد."
    result = clean_document(raw)
    assert result.kept
    assert "\u200c" in result.cleaned_text


def test_remove_duplicate_lines_keeps_first_occurrence():
    text = "خط اول\nخط دوم\nخط اول\nخط سوم"
    out = remove_duplicate_lines(text)
    assert out.count("خط اول") == 1
    assert "خط دوم" in out and "خط سوم" in out


# --------------------------------------------------------------------- dedup ----


def test_deduplicate_removes_exact_duplicates():
    docs = [
        Document(doc_id="a", source="s", language="fa", raw_text="", cleaned_text="متن یکسان برای تست", status="kept"),
        Document(doc_id="b", source="s", language="fa", raw_text="", cleaned_text="متن یکسان برای تست", status="kept"),
        Document(doc_id="c", source="s", language="fa", raw_text="", cleaned_text="متنِ کاملاً متفاوت", status="kept"),
    ]
    kept, report = deduplicate(docs)
    assert len(kept) == 2
    assert report.removed_duplicates == 1


# ------------------------------------------------------------------- quality ----


def test_quality_score_tiers_well_formed_vs_repetitive():
    good_text = (
        "این یک پاراگرافِ نسبتاً خوب و متنوع است که جمله‌های معقولی دارد. "
        "هر جمله معنایِ متفاوتی می‌دهد و از تکرارِ بی‌جا پرهیز می‌کند.\n\n"
        "پاراگرافِ دوم هم ساختارِ مشخصی دارد و به موضوعِ متن ادامه می‌دهد."
    )
    repetitive_text = "تکرار تکرار تکرار تکرار تکرار تکرار تکرار تکرار تکرار تکرار."

    good = score_document(good_text)
    bad = score_document(repetitive_text)
    assert good.score > bad.score
    assert good.tier in ("A", "B")


def test_quality_score_bounds():
    qs = score_document("متنی با طولِ متوسط برای بررسیِ محدوده‌یِ امتیاز.")
    assert 0.0 <= qs.score <= 1.0
    assert qs.tier in ("A", "B", "C")


# -------------------------------------------------------------- corpus_builder ----


def test_split_into_paragraph_documents_respects_min_chars_and_max_docs():
    sources = [("doc1.md", "پاراگرافِ اول با طولِ کافی برای عبور از حداقل.\n\nکوتاه\n\nپاراگرافِ سوم هم طولِ کافی دارد.")]
    docs = split_into_paragraph_documents(sources, min_chars=20, max_docs=10)
    assert len(docs) == 2  # پاراگرافِ «کوتاه» رد شده
    assert all(d.status == "pending" for d in docs)


def test_run_cleaning_and_quality_stage_sets_status():
    sources = [("doc1.md", "این یک پاراگرافِ آموزشیِ نسبتاً کاملی است که باید بعدِ پاک‌سازی نگه داشته شود.")]
    docs = split_into_paragraph_documents(sources, min_chars=20, max_docs=10)
    run_cleaning_stage(docs)
    assert docs[0].status == "kept"
    assert docs[0].cleaned_text is not None
    run_quality_stage(docs)
    assert docs[0].quality_tier in ("A", "B", "C")


# ----------------------------------------------------------------------- split ----


def test_split_documents_is_leakage_safe_and_reproducible():
    docs = [Document(doc_id=f"d{i}", source="s", language="fa", raw_text="", cleaned_text=f"متن شماره {i}", status="kept") for i in range(30)]
    with tempfile.TemporaryDirectory() as d:
        train1, val1, r1 = split_documents(docs, d, val_fraction=0.2, seed=0)
        train_ids1 = {doc.doc_id for doc in train1}
        val_ids1 = {doc.doc_id for doc in val1}
        assert train_ids1.isdisjoint(val_ids1)
        assert len(train1) + len(val1) == 30

        train2, val2, r2 = split_documents(docs, d, val_fraction=0.2, seed=999)  # seed دیگر -- باید همان split ذخیره‌شده را استفاده کند
        assert r2.reused_fixed_split is True
        assert {doc.doc_id for doc in val2} == val_ids1


# --------------------------------------------------------------- sequence packing ----


def test_sequence_packing_shift_is_correct_for_real_tokenizer():
    tok = ByteLevelBPETokenizer()
    tok.train(["یک متنِ آزمایشیِ نسبتاً بلند برایِ آموزشِ توکنایزر و بررسیِ شیفتِ توالی"] * 5, vocab_size=280)
    result = check_sequence_packing(tok, "این یک جمله‌ی آزمایشی است")
    assert result.shift_correct is True
    assert len(result.input_ids) == len(result.target_ids)


# ------------------------------------------------------------------ smoke test ----


def _build_tiny_setup(vocab_size=24, d_model=16):
    tok = ByteLevelBPETokenizer()
    tok.train(["متنِ آموزشیِ تکراری برایِ ساختِ توکنایزرِ کوچکِ آزمایشی جهتِ تستِ واحد"] * 5, vocab_size=vocab_size)
    cfg = TRXModelConfig(vocab_size=tok.vocab_size, d_model=d_model, n_layers=2, n_heads=2, d_ff=32, max_seq_len=16, seed=1)
    model = TRXNativeModel(cfg)
    texts = ["این یک متنِ آزمایشیِ نسبتاً طولانی برایِ ساختِ چند دنباله‌یِ آموزشی است."] * 6
    seqs = build_sequences(tok, texts, seq_len=8)
    train_seqs, val_seqs = train_val_split(seqs, val_fraction=0.3, seed=0)
    return model, tok, train_seqs, val_seqs


def test_smoke_test_passes_on_healthy_setup():
    model, tok, train_seqs, val_seqs = _build_tiny_setup()
    report = run_smoke_test(model, tok, train_seqs, val_seqs)
    assert "generation_runs" in report.passed_checks
    assert len(report.passed_checks) == 11  # دقیقاً ۱۱ موردِ چک‌لیستِ بخشِ ۱۱ سند


def test_smoke_test_fails_fast_on_empty_dataset():
    model, tok, _, val_seqs = _build_tiny_setup()
    with pytest.raises(SmokeTestFailure):
        run_smoke_test(model, tok, [], val_seqs)


def test_smoke_test_fails_on_vocab_mismatch():
    model, tok, train_seqs, val_seqs = _build_tiny_setup()
    other_tok = ByteLevelBPETokenizer()
    other_tok.train(["یک توکنایزرِ کاملاً متفاوت با vocab_size دیگر"] * 5, vocab_size=300)
    with pytest.raises(SmokeTestFailure):
        run_smoke_test(model, other_tok, train_seqs, val_seqs)


# ------------------------------------------------------------- checkpoint policy ----


def test_checkpoint_policy_atomic_save_and_resume():
    model, tok, train_seqs, val_seqs = _build_tiny_setup()
    from trx_ai.trx_model.training.autograd_cache import build_param_map

    params = build_param_map(model)
    optimizer = AdamW(param_names=params.keys(), lr=1e-2)
    grads = {k: np.ones_like(v) * 0.001 for k, v in params.items()}
    optimizer.step(params, grads)

    with tempfile.TemporaryDirectory() as d:
        meta = CheckpointMeta(
            epoch=0, step=1, training_loss=1.0, validation_loss=2.0, best_validation_loss=None,
            tokenizer_vocab_size=tok.vocab_size, tokenizer_num_merges=len(tok.merges), seed=0,
        )
        checkpoint_policy.save_latest(d, model, optimizer, tok, meta)
        assert os.path.exists(os.path.join(d, "latest", "latest.weights.npz"))

        best_path = checkpoint_policy.save_best_if_improved(d, model, optimizer, tok, meta)
        assert best_path is not None

        # بهبودِ کمتر -- best نباید عوض شود
        worse_meta = CheckpointMeta(**{**meta.__dict__, "validation_loss": 3.0})
        no_update = checkpoint_policy.save_best_if_improved(d, model, optimizer, tok, worse_meta)
        assert no_update is None

        model2 = TRXNativeModel(model.config)
        params2 = build_param_map(model2)
        optimizer2 = AdamW(param_names=params2.keys(), lr=1e-2)
        resumed_meta, warnings = checkpoint_policy.resume_from_latest(d, model2, optimizer2, tok, expected_seed=0)
        assert resumed_meta.step == 1
        assert all(np.allclose(params[k], params2[k]) for k in params)
        assert warnings == []


def test_checkpoint_policy_periodic_prunes_old_checkpoints():
    model, tok, train_seqs, val_seqs = _build_tiny_setup()
    from trx_ai.trx_model.training.autograd_cache import build_param_map

    params = build_param_map(model)
    optimizer = AdamW(param_names=params.keys(), lr=1e-2)

    with tempfile.TemporaryDirectory() as d:
        for step in range(1, 6):
            meta = CheckpointMeta(
                epoch=0, step=step, training_loss=1.0, validation_loss=None, best_validation_loss=None,
                tokenizer_vocab_size=tok.vocab_size, tokenizer_num_merges=len(tok.merges), seed=0,
            )
            checkpoint_policy.save_periodic(d, model, optimizer, tok, meta, keep_last=2)
        periodic_dir = os.path.join(d, "periodic")
        meta_files = [f for f in os.listdir(periodic_dir) if f.endswith(".meta.json")]
        assert len(meta_files) == 2


def test_resume_warns_on_seed_mismatch():
    model, tok, train_seqs, val_seqs = _build_tiny_setup()
    from trx_ai.trx_model.training.autograd_cache import build_param_map

    params = build_param_map(model)
    optimizer = AdamW(param_names=params.keys(), lr=1e-2)

    with tempfile.TemporaryDirectory() as d:
        meta = CheckpointMeta(
            epoch=0, step=1, training_loss=1.0, validation_loss=None, best_validation_loss=None,
            tokenizer_vocab_size=tok.vocab_size, tokenizer_num_merges=len(tok.merges), seed=5,
        )
        checkpoint_policy.save_latest(d, model, optimizer, tok, meta)
        model2 = TRXNativeModel(model.config)
        optimizer2 = AdamW(param_names=build_param_map(model2).keys(), lr=1e-2)
        _, warnings = checkpoint_policy.resume_from_latest(d, model2, optimizer2, tok, expected_seed=999)
        assert len(warnings) == 1
        assert warnings[0].kind == "seed_mismatch"


# ---------------------------------------------------------------- resource monitor ----


def test_check_disk_space_returns_positive_number():
    free_mb = check_disk_space(".")
    assert free_mb > 0


def test_resource_monitor_flags_low_disk_threshold():
    monitor = ResourceMonitor(min_disk_free_mb=10**9, workdir=".")  # آستانه‌ای که هیچ دیسکی نمی‌رسد
    check = monitor.check()
    assert check.should_stop is True


# ------------------------------------------------------------- generalization ----


def test_has_repeating_ngram_detects_loop():
    looping = "abcdabcdabcdabcdabcd"
    has_rep, gram = _has_repeating_ngram(looping, n=4, min_repeats=3)
    assert has_rep is True
    assert gram == "abcd"


def test_has_repeating_ngram_false_on_normal_text():
    normal = "این یک متنِ کاملاً معمولی است بدونِ هیچ تکرارِ غیرعادی."
    has_rep, _ = _has_repeating_ngram(normal, n=4, min_repeats=3)
    assert has_rep is False
