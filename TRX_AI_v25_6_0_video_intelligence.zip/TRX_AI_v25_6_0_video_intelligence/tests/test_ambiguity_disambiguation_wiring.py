# -*- coding: utf-8 -*-
"""
تست‌هایِ وایرینگِ واقعیِ سیستمِ «ابهام» -- بخشِ ۲: اتصال به مسیرِ اصلی.

``tests/test_nlu_disambiguation_and_multi_intent.py`` منطقِ خامِ
``nlu/disambiguator.py`` (``should_ask_followup``/``build_followup_question``)
را از قبل قفل کرده بود، اما خودِ آن فایل صراحتاً می‌گفت این ماژول «به
هیچ UI/core.py وصل نیست». این فایل دقیقاً همان شکاف را می‌بندد: نشان
می‌دهد که با ارتقایِ حاضر --

    1) ``core_engine/tool_router.py`` وقتی دو ابزارِ نامزد امتیازِ
       نزدیکی دارند (و IntentEngine خودش مطمئن نیست)، به‌جایِ اجرای
       حدسی، سؤالِ ``build_followup_question`` را می‌پرسد و
       ``ai._pending_disambiguation`` را ست می‌کند؛
    2) ``core_engine/turn_processor.py`` پیامِ *بعدیِ* کاربر را به‌عنوانِ
       پاسخِ همان سؤال تفسیر می‌کند -- یا با تطبیقِ مستقیم
       (``disambiguator.match_clarification_reply``)، یا (اگر تطبیق
       نامشخص بود) با ترکیبِ متنِ اصلی + توضیحِ تازه و سپردنِ آن به
       تشخیصِ کاملِ نیت --

واقعاً به‌صورتِ end-to-end روی خودِ ``TRXEnterpriseAI`` کار می‌کند، نه
فقط این‌که دو تابعِ مستقل جدا از هم درست کار می‌کنند.

همان فلسفه‌ی بقیه‌ی تست‌های پروژه: بدونِ شبکه/pytest-asyncio؛ توابعِ
async با ``asyncio.run(...)`` مستقیماً اجرا می‌شوند. برایِ اینکه هر
شاخه‌ی دقیقِ گیتِ ابهام کنترل‌شده تست شود (نه وابسته به این‌که
IntentEngine/ToolScorerِ واقعی امروز دقیقاً چه امتیازی می‌دهند -- که با
تغییرِ آینده‌یِ کلیدواژه‌ها ممکن است عوض شود)، ``IntentEngine.detect_intent``
و ``ToolScorer.score_tools`` عمداً monkeypatch می‌شوند؛ این دقیقاً همان
مرزِ مسئولیتی‌ست که خودِ این ارتقا اضافه کرده (نه چیزی که NLU باید
تشخیص بدهد).
"""

from __future__ import annotations

import asyncio

import trx_ai.core_engine.tool_router as tool_router_mod
import trx_ai.core_engine.turn_processor as turn_processor_mod
from trx_ai.core import TRXEnterpriseAI
from trx_ai.tools import WeatherEngine


def _make_ai():
    ai = TRXEnterpriseAI()
    ai._presented = []

    async def fake_present(text, title="", style="cyan"):
        ai._presented.append(text)

    ai._present = fake_present
    return ai


def _patch_close_scores(monkeypatch, top_two=("weather", "currency"), scores=(2.0, 1.9)):
    def fake_score_tools(text, intent, confidence, context=None):
        return top_two[0], {top_two[0]: scores[0], top_two[1]: scores[1]}, 0.55

    monkeypatch.setattr(tool_router_mod.ToolScorer, "score_tools", staticmethod(fake_score_tools))


def _patch_intent(monkeypatch, intent="general", confidence=0.4):
    def fake_detect_intent(text, modes, db):
        return intent, confidence, {}

    monkeypatch.setattr(turn_processor_mod.IntentEngine, "detect_intent", staticmethod(fake_detect_intent))
    return fake_detect_intent


# ======================================================================
#   بخشِ ۱: گیتِ ابهام باید سؤال بپرسد، نه اجرا کند
# ======================================================================


def test_close_tie_asks_clarifying_question_instead_of_executing(monkeypatch):
    ai = _make_ai()
    _patch_intent(monkeypatch, intent="general", confidence=0.4)
    _patch_close_scores(monkeypatch)

    asyncio.run(ai._process_turn("یه چیزی بگو ببینم چی میشه"))

    assert ai._pending_disambiguation is not None
    assert ai._pending_disambiguation["top_two"] == ("weather", "currency")
    assert len(ai._presented) == 1
    assert "آب‌وهوا" in ai._presented[-1] and "ارز" in ai._presented[-1]


def test_clear_winner_does_not_ask_and_executes_normally(monkeypatch):
    ai = _make_ai()
    _patch_intent(monkeypatch, intent="calculator", confidence=0.95)
    # فاصله‌ی امتیاز زیاد است -- نباید سؤال بپرسد.
    _patch_close_scores(monkeypatch, top_two=("calculator", "currency"), scores=(5.0, 0.2))

    asyncio.run(ai._process_turn("۲+۲ چند میشه"))

    assert ai._pending_disambiguation is None


def test_high_intent_confidence_suppresses_ambiguity_gate(monkeypatch):
    """
    حتی اگر امتیازِ دو ابزار خیلی نزدیک باشد، وقتی خودِ IntentEngine
    از قبل به نیتِ اصلی مطمئن است (>= MAX_INTENT_CONFIDENCE_FOR_AMBIGUITY)،
    سؤالِ ابهام نباید کاربر را معطل کند.
    """
    ai = _make_ai()
    _patch_intent(monkeypatch, intent="calculator", confidence=0.99)
    _patch_close_scores(monkeypatch, top_two=("calculator", "currency"), scores=(5.0, 4.9))

    asyncio.run(ai._process_turn("۳+۳ چند میشه"))

    assert ai._pending_disambiguation is None


def test_tiny_noisy_scores_do_not_trigger_ambiguity(monkeypatch):
    """
    نسبتِ نزدیک بینِ دو امتیازِ ناچیز (نویز) نباید سؤال بسازد --
    ``MIN_AMBIGUITY_SCORE`` دقیقاً همین حالت را فیلتر می‌کند.
    """
    ai = _make_ai()
    _patch_intent(monkeypatch, intent="general", confidence=0.3)
    _patch_close_scores(monkeypatch, top_two=("weather", "currency"), scores=(0.1, 0.09))

    asyncio.run(ai._process_turn("سلام یه چیزی"))

    assert ai._pending_disambiguation is None


def test_medical_intent_is_exempt_from_ambiguity_gate(monkeypatch):
    """
    نیت‌هایِ حساس (پزشکی/همراهِ روان‌شناختی/تحلیلِ پروژه) قبل از رسیدن
    به این گیت خودشان return می‌کنند، اما این تست تضمین می‌کند حتی اگر
    مسیرِ کد در آینده عوض شود، این نیت‌ها در فهرستِ exempt باقی می‌مانند.
    """
    assert "medical" in tool_router_mod.AMBIGUITY_EXEMPT_INTENTS
    assert "emotional_support" in tool_router_mod.AMBIGUITY_EXEMPT_INTENTS


# ======================================================================
#   بخشِ ۲: تفسیرِ پاسخِ کاربر به سؤالِ ابهام
# ======================================================================


def test_direct_match_reply_routes_to_matched_tool_without_reasking(monkeypatch):
    ai = _make_ai()
    _patch_intent(monkeypatch, intent="general", confidence=0.4)
    _patch_close_scores(monkeypatch)

    asyncio.run(ai._process_turn("یه چیزی بگو"))
    assert ai._pending_disambiguation is not None

    async def fake_weather(session, text):
        return "هوای امروز آفتابی است."

    monkeypatch.setattr(WeatherEngine, "get_weather", staticmethod(fake_weather))

    ai._presented.clear()
    asyncio.run(ai._process_turn("منظورم آب‌وهوا بود"))

    assert ai._pending_disambiguation is None, "بعدِ پاسخ، حالتِ انتظار باید پاک شود"
    assert ai._presented and "آفتابی" in ai._presented[-1]


def test_unclear_reply_combines_original_text_and_reroutes(monkeypatch):
    ai = _make_ai()
    _patch_intent(monkeypatch, intent="general", confidence=0.4)
    _patch_close_scores(monkeypatch)

    asyncio.run(ai._process_turn("یه چیزی بگو"))
    assert ai._pending_disambiguation is not None

    seen_texts = []

    def fake_detect_intent_after(text, modes, db):
        seen_texts.append(text)
        return "joke", 0.9, {}

    monkeypatch.setattr(
        turn_processor_mod.IntentEngine, "detect_intent", staticmethod(fake_detect_intent_after)
    )

    ai._presented.clear()
    asyncio.run(ai._process_turn("نه، یه جوک بگو"))

    assert ai._pending_disambiguation is None
    assert seen_texts, "پاسخِ نامشخص باید دوباره به IntentEngine کاملِ سپرده شود"
    assert "یه چیزی بگو" in seen_texts[0] and "یه جوک بگو" in seen_texts[0]
    assert ai._presented, "بعدِ رفعِ ابهام باید یک پاسخِ واقعی نمایش داده شود"
