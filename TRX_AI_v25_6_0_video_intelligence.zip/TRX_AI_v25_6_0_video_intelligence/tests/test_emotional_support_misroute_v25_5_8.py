# -*- coding: utf-8 -*-
"""
تست‌هایِ اصلاحِ باگِ v25.5.8 -- «همراهِ روان‌شناختیِ جعلی».

گزارشِ واقعیِ امیر (ترنسکریپتِ گفتگو): پیام‌هایی مثلِ «چیزی نمیخوام
بدونم😂»، «واقعا رد دادی»، «ول کن خدا وکیلی»، «کاری نیست» -- که هیچ‌کدام
واقعاً حاکی از پریشانیِ عاطفی نیستند -- زیرِ برچسبِ «💙 همراهِ
روان‌شناختی» یک متنِ ثابتِ «تغذیه متعادل/فعالیتِ بدنی/خوابِ کافی...»
می‌گرفتند؛ سه پیامِ کاملاً متفاوت، سه پاسخِ کاملاً یکسان.

ریشه: ``trx_ai/nlu/intents/psychology.py`` نیتِ ``emotional_support`` را
با ``semantic_enabled=True`` تعریف کرده -- یعنی NLUِ بیرونی می‌تواند این
نیت را فقط از رویِ شباهتِ معنایی تشخیص بدهد، حتی بدونِ هیچ‌کدام از
``EMOTIONAL_SUPPORT_KEYWORDS``ِ تحت‌اللفظی. اما
``handle_medical_query_online`` (موتورِ پزشکی) فقط تحت‌اللفظی چک می‌کند؛
وقتی مطابقت نمی‌بیند، به ``health_advice()`` (متنِ ثابت) سقوط می‌کند --
و ``tool_router.py`` بدونِ آگاهی از این سقوط، همچنان برچسبِ «همراهِ
روان‌شناختی» را نشان می‌داد.

این فایل سه لایه را تست می‌کند: (۱) خودِ ``handle_medical_query_online``
حالا کلیدِ ``source`` را درست می‌گذارد، (۲) ``format_medical_response_online``
(مسیرِ شخصیتِ «دکتر کامل») این کلید را گم نمی‌کند، (۳)
``ToolRouter.execute`` با ``source`` غیرِ ``"therapy"`` دیگر برچسبِ
گمراه‌کننده و متنِ ثابت نشان نمی‌دهد.
"""

from __future__ import annotations

import asyncio

import pytest

from trx_ai.medical import MedicalAIEngine
from trx_ai.medical import online as medical_online
from trx_ai.core_engine.tool_router import ToolRouter, _EMOTIONAL_SUPPORT_FALLTHROUGH_REPLIES


# دقیقاً همان چهار پیامی که در ترنسکریپتِ واقعیِ امیر باعثِ باگ شدند.
REAL_BUG_MESSAGES = (
    "چیزی نمیخوام بدونم😂",
    "واقعا رد دادی",
    "ول کن خدا وکیلی",
    "کاری نیست",
)


# ----------------------------------------------------------------------
#  1) خودِ موتور -- online.py::handle_medical_query_online
# ----------------------------------------------------------------------
@pytest.mark.parametrize("message", REAL_BUG_MESSAGES)
def test_real_bug_messages_are_tagged_general_advice_not_therapy(message):
    engine = MedicalAIEngine()
    result = asyncio.run(
        medical_online.handle_medical_query_online(engine, message, session=None, session_key=f"bug:{message}")
    )
    assert result["source"] == "general_advice", (
        f"پیامِ «{message}» نباید source=therapy بگیرد -- هیچ کلیدواژه‌ی "
        f"احساسیِ تحت‌اللفظی در آن نیست."
    )
    assert "تغذیه متعادل" in result["message"]  # همان متنِ ثابتِ قدیمی، ولی حالا برچسب‌گذاری‌شده


def test_real_emotional_keyword_message_is_tagged_therapy():
    engine = MedicalAIEngine()
    result = asyncio.run(
        medical_online.handle_medical_query_online(
            engine, "امروز خیلی ناراحتم و دلم گرفته", session=None, session_key="real1"
        )
    )
    assert result["source"] == "therapy"
    assert "تغذیه متعادل" not in result["message"]


def test_active_therapy_session_continuation_is_tagged_therapy():
    """پیامِ دوم به بعدِ یک گفتگویِ فعالِ همراهی -- حتی بدونِ کلیدواژه --
    باید هم‌چنان source=therapy بگیرد (رفتارِ درستِ موجود، نباید بشکند)."""
    engine = MedicalAIEngine()
    first = asyncio.run(
        medical_online.handle_medical_query_online(engine, "خیلی غمگینم امروز", session=None, session_key="cont1")
    )
    assert first["source"] == "therapy"
    second = asyncio.run(
        medical_online.handle_medical_query_online(engine, "از صبح همینطوری بودم", session=None, session_key="cont1")
    )
    assert second["source"] == "therapy"


def test_physical_symptom_and_first_aid_are_unaffected():
    """اثباتِ عدمِ رگرسیون: مسیرهایِ دیگر اصلاً به این قسمت نمی‌رسند."""
    engine = MedicalAIEngine()
    r1 = asyncio.run(medical_online.handle_medical_query_online(engine, "تب و سردرد دارم", session=None, session_key="s1"))
    assert r1.get("source") != "general_advice"  # این یکی از شاخه‌ی symptom برمی‌گردد، نه از health_advice
    r2 = asyncio.run(medical_online.handle_medical_query_online(engine, "خونریزی شدید داره", session=None, session_key="s2"))
    assert "source" not in r2 or r2.get("source") != "general_advice"


# ----------------------------------------------------------------------
#  2) مسیرِ شخصیتِ «دکتر کامل» -- care.py::format_medical_response_online
# ----------------------------------------------------------------------
@pytest.mark.parametrize("message", REAL_BUG_MESSAGES)
def test_source_survives_the_doctor_persona_formatting_path(message):
    engine = MedicalAIEngine()
    result = asyncio.run(
        engine.format_medical_response_online(message, session=None, personality="دکتر کامل", session_key=f"doc:{message}")
    )
    assert result.get("source") == "general_advice", (
        "قبل از v25.5.8 این کلید اینجا گم می‌شد -- format_medical_response_online "
        "یک دیکشنریِ تازه می‌ساخت که source نداشت."
    )


# ----------------------------------------------------------------------
#  3) ToolRouter.execute -- رفتارِ نمایش
# ----------------------------------------------------------------------
class _FakeUI:
    def __init__(self):
        self.console = self
        self.emergencies = []

    def print(self, *a, **k):
        pass

    def show_emergency(self, text):
        self.emergencies.append(text)


class _FakeMemory:
    def resolve_pronoun(self, text):
        return text, None


class _FakeAI:
    """حداقلِ لازم برایِ رسیدن به شاخه‌ی ``intent == "emotional_support"`` در
    ``ToolRouter.execute`` -- طبقِ ردیابیِ واقعیِ کد (کش/حافظه/دانشِ‌آفلاین
    همه برایِ این نیت skip می‌شوند چون در ``SKIP_CACHE_INTENTS`` است)."""

    def __init__(self, medical_result: dict):
        self._medical_result = medical_result
        self.stats = {"total_requests": 0}
        self.ui = _FakeUI()
        self.memory = _FakeMemory()
        self.current_trace = None
        self.presented: list[tuple[str, str, str]] = []
        self.finalized: list[tuple] = []

    def _get_personality_prefix(self):
        return "🤖", "پاسخ", "green"

    async def _handle_medical_query(self, text):
        return self._medical_result

    async def _present(self, answer, label, style):
        self.presented.append((answer, label, style))

    def _finalize(self, original_text, answer, start_time, intent, confidence):
        self.finalized.append((original_text, answer, intent, confidence))


def test_tool_router_hides_therapy_label_when_source_is_general_advice():
    fake_result = {
        "done": True,
        "message": "💚 **توصیه‌های کلی سلامت:**\n\n• تغذیه متعادل...",
        "source": "general_advice",
    }
    ai = _FakeAI(fake_result)
    router = ToolRouter(ai)

    asyncio.run(router.execute("emotional_support", 0.9, "چیزی نمیخوام بدونم😂"))

    assert len(ai.presented) == 1
    answer, label, style = ai.presented[0]
    assert label == "💬 مکالمه", "دیگر نباید برچسبِ «همراهِ روان‌شناختی» بگیرد"
    assert answer in _EMOTIONAL_SUPPORT_FALLTHROUGH_REPLIES
    assert "تغذیه متعادل" not in answer, "متنِ ثابتِ پزشکی دیگر نباید به کاربر نشان داده شود"
    assert len(ai.finalized) == 1


def test_tool_router_keeps_therapy_label_when_source_is_therapy():
    fake_result = {
        "done": True,
        "message": "شنیدمت. این حس از کِی شروع شد؟",
        "source": "therapy",
    }
    ai = _FakeAI(fake_result)
    router = ToolRouter(ai)

    asyncio.run(router.execute("emotional_support", 0.95, "امروز ناراحتم"))

    assert len(ai.presented) == 1
    answer, label, style = ai.presented[0]
    assert label == "💙 همراه شما | Therapy Companion"
    assert answer == fake_result["message"]


def test_tool_router_emergency_path_unaffected_by_source_field():
    """خطِ قرمز: مسیرِ اورژانسی باید مستقل از ``source`` هم‌چنان کار کند."""
    fake_result = {"done": True, "message": "🚨 اورژانس!", "emergency": True, "source": "therapy"}
    ai = _FakeAI(fake_result)
    router = ToolRouter(ai)

    asyncio.run(router.execute("emotional_support", 0.99, "دیگه نمیخوام زندگی کنم"))

    assert ai.ui.emergencies == ["🚨 اورژانس!"]
    assert ai.presented == []  # اورژانسی از مسیرِ show_emergency می‌رود، نه _present
