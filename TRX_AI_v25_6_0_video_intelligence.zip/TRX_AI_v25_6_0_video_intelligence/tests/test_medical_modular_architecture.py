from trx_ai.medical import MedicalAIEngine, MedicalRequest, MedicalResponse
from trx_ai.medical.safety.negation import symptom_state
from trx_ai.medical.router import MedicalRouter
from trx_ai.medical.diagnosis.normalizer import normalize


def test_public_api_stable():
    e=MedicalAIEngine()
    assert callable(e.handle_medical_query)
    assert isinstance(MedicalRequest('تب'), MedicalRequest)
    assert isinstance(MedicalResponse(), MedicalResponse)


def test_router_is_intent_only():
    r=MedicalRouter()
    assert r.route('تب و سردرد دارم') == 'SYMPTOM_ANALYSIS'
    assert r.route('اطلاعات داروی استامینوفن') == 'MEDICATION_INFORMATION'
    assert r.route('تداخل استامینوفن و ایبوپروفن') == 'DRUG_INTERACTION'


def test_negation():
    assert symptom_state('درد قفسه سینه دارم', 'درد قفسه سینه').value == 'PRESENT'
    assert symptom_state('درد قفسه سینه ندارم', 'درد قفسه سینه').value == 'ABSENT'


def test_normalizer_canonical_ids():
    xs=normalize('سرم درد می کند و نفس کم میارم')
    assert {x.id for x in xs} >= {'HEADACHE','SHORTNESS_OF_BREATH'}


def test_match_score_is_not_probability():
    result=MedicalAIEngine().analyze_symptoms('تب و سردرد دارم')
    assert 'match_score' in result
    assert 'uncertainty' in result
    assert 'probability' not in result


def test_care_handles_emergency_before_router():
    e=MedicalAIEngine()
    result=e.start_symptom_check('safety','درد قفسه سینه دارم و نفس بالا نمیاد')
    assert result.get('emergency') is True


# ---------------------------------------------------------------------------
#   entities.py: استخراجِ نامِ دارو/بیماری باید در همه‌ی مسیرها یکسان باشد
# ---------------------------------------------------------------------------
def test_drug_name_extraction_recognizes_ampoule():
    """
    قبلاً regexِ online.py اصلاً «آمپول» را نمی‌شناخت (فقط دارو/قرص/شربت)،
    در حالی‌که regexِ care.py می‌شناخت -- یعنی همین جمله بسته به مسیرِ
    ورودی نتیجه‌ی متفاوتی می‌داد. حالا هر دو از entities.py مشترک استفاده
    می‌کنند.
    """
    from trx_ai.medical.entities import extract_drug_name
    assert extract_drug_name("اطلاعات آمپول پنی سیلین") == "پنی سیلین"


def test_drug_name_extraction_does_not_false_match_inside_longer_word():
    """
    باگِ واقعی: بدونِ مرزبندیِ کلمه (\\b)، «اطلاعاتی» چون خودش شاملِ
    زیررشته‌یِ «اطلاعات» است، به‌اشتباه با کلیدواژه‌یِ بیماری تطبیق
    می‌خورد.
    """
    from trx_ai.medical.entities import extract_disease_name
    result = extract_disease_name("اطلاعاتی درباره‌ی بیماری دیابت می‌خوام")
    assert result == "دیابت"


def test_medication_intent_uses_shared_entity_extractor():
    e = MedicalAIEngine()
    r = e.handle_request(MedicalRequest("اطلاعات آمپول پنی سیلین"))
    assert r.intent == "MEDICATION_INFORMATION"
    # نباید بگوید «لطفاً نام دارو را مشخص کنید» -- یعنی استخراج موفق بود.
    assert "مشخص کنید" not in r.answer
