# -*- coding: utf-8 -*-
"""
تست‌های واحد برایِ PersianPythonInterpreter (trx_ai/interpreter.py) —
مخصوصاً منطقِ تورفتگی (translate()) که قبلاً یک باگِ جدی داشت: تورفتگی
بر اساسِ فاصله‌هایِ واقعیِ کاربر ردیابی نمی‌شد، فقط با دیدنِ «:» عمق
زیاد می‌شد و به‌ندرت کم. نتیجه: خطی که کاربر با فاصله‌گذاری صریحاً
بیرونِ یک بلاک نشان داده بود، برایِ همیشه داخلِ همان بلاک می‌ماند.

این فایل دقیقاً همان الگوهایی را پوشش می‌دهد که در بررسیِ Parser لازم
دانسته شده بود: dedent برای if/for/while، بلوک‌هایِ تودرتو، بلوکِ
خالی، فاصله‌هایِ متفاوت، ترکیبِ tab+space، خطِ خالی، و کامنت بینِ
بلوک‌ها.
"""

import pytest

from trx_ai.interpreter import PersianPythonInterpreter


@pytest.fixture()
def interp():
    return PersianPythonInterpreter()


def _run(interp, code):
    """کد را اجرا و خروجیِ چاپ‌شده را برمی‌گرداند (برایِ ادعا روی نتیجه‌ی واقعی، نه فقط ترجمه)."""
    import io
    import contextlib

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        log = interp.smart_execute(code, auto_confirm=True)
    return buf.getvalue(), log


# ---------------------------------------------------------------------------
#   dedent پایه: if / for / while
# ---------------------------------------------------------------------------
def test_if_dedent(interp):
    code = 'اگر درست:\n    چاپ("A")\nچاپ("B")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["A", "B"]
    assert "✅" in log


def test_for_dedent(interp):
    code = 'برای i در تعداد(2):\n    چاپ(i)\nچاپ("B")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["0", "1", "B"]
    assert "✅" in log


def test_while_dedent(interp):
    code = 'تاوقتی درست:\n    چاپ("once")\n    توقف\nچاپ("after")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["once", "after"]
    assert "✅" in log


# ---------------------------------------------------------------------------
#   تودرتو
# ---------------------------------------------------------------------------
def test_if_inside_for(interp):
    code = (
        'برای i در تعداد(3):\n'
        '    اگر i برابر 1:\n'
        '        چاپ("one")\n'
        'چاپ("done")'
    )
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["one", "done"]
    assert "✅" in log


def test_for_inside_if(interp):
    code = (
        'اگر درست:\n'
        '    برای i در تعداد(2):\n'
        '        چاپ(i)\n'
        '    چاپ("done")\n'
        'چاپ("end")'
    )
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["0", "1", "done", "end"]
    assert "✅" in log


def test_multi_level_nesting(interp):
    code = (
        'اگر درست:\n'
        '    اگر درست:\n'
        '        اگر درست:\n'
        '            چاپ("deep")\n'
        '        چاپ("level2")\n'
        '    چاپ("level1")\n'
        'چاپ("level0")'
    )
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["deep", "level2", "level1", "level0"]
    assert "✅" in log


def test_else_dedents_to_if_level(interp):
    code = 'اگر غلط:\n    چاپ("A")\nوگرنه:\n    چاپ("B")'
    out, log = _run(interp, code)
    assert out.strip() == "B"
    assert "✅" in log


# ---------------------------------------------------------------------------
#   بلوکِ خالی (کاربر فراموش کرده تورفتگی بدهد) — باید با اصلاحِ خودکار جبران شود
# ---------------------------------------------------------------------------
def test_missing_indent_is_auto_fixed(interp):
    code = 'اگر درست:\nچاپ("A")'
    out, log = _run(interp, code)
    assert out.strip() == "A"
    assert "✅" in log
    assert "تورفتگی فراموش شده" in log


# ---------------------------------------------------------------------------
#   فاصله‌هایِ متفاوت (نه فقط ۴تایی) و ترکیبِ tab+space
# ---------------------------------------------------------------------------
def test_two_space_indent(interp):
    code = 'اگر درست:\n  چاپ("A")\nچاپ("B")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["A", "B"]
    assert "✅" in log


def test_tab_indent(interp):
    code = 'اگر درست:\n\tچاپ("A")\nچاپ("B")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["A", "B"]
    assert "✅" in log


# ---------------------------------------------------------------------------
#   خطِ خالی وسطِ بلوک نباید بلوک را زودتر از موعد ببندد
# ---------------------------------------------------------------------------
def test_blank_line_inside_block(interp):
    code = 'اگر درست:\n    چاپ("A")\n\n    چاپ("B")\nچاپ("C")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["A", "B", "C"]
    assert "✅" in log


# ---------------------------------------------------------------------------
#   کامنت بینِ بلوک‌ها — باید کاملاً نادیده گرفته شود، نه توکنایز
# ---------------------------------------------------------------------------
def test_full_line_comment_inside_block(interp):
    code = 'اگر درست:\n    # این یک کامنت است\n    چاپ("A")\nچاپ("B")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["A", "B"]
    assert "✅" in log


def test_trailing_inline_comment(interp):
    code = 'چاپ("A")  # توضیح است\nچاپ("B")'
    out, log = _run(interp, code)
    assert out.strip().split("\n") == ["A", "B"]
    assert "✅" in log


def test_hash_inside_string_is_not_treated_as_comment(interp):
    code = 'چاپ("قیمت #۱")'
    out, log = _run(interp, code)
    assert "#۱" in out
    assert "✅" in log
