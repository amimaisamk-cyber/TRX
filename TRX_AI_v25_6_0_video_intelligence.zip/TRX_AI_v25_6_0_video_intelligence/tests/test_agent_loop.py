# -*- coding: utf-8 -*-
"""
تست‌های واحد برایِ `trx_ai.agent` (حلقه‌ی عامل خودمختار).

عمداً از موتورهایِ واقعیِ ``tools.py``/``vision.py`` که به شبکه/فایل
نیاز دارند استفاده نمی‌شود -- به‌جایش ``AgentTool`` هایِ ساختگی (stub)
با ``ToolRegistry`` مستقل ساخته می‌شوند تا تست‌ها سریع، آفلاین و
دیتومینستیک بمانند. تستِ ``build_default_registry`` جداگانه و فقط
روی *ساختارِ* رجیستری (نه رفتارِ شبکه‌ای) بررسی می‌شود.
"""

from __future__ import annotations

import asyncio

import pytest

from trx_ai.agent import (
    ActionType,
    AgentConfig,
    AgentLoop,
    AgentTool,
    GuardrailViolation,
    LoopGuard,
    Scratchpad,
    StopReason,
    ToolRegistry,
    ToolResult,
    build_default_registry,
)


# ==================================================================
#   ابزارهایِ ساختگی برایِ تست
# ==================================================================


async def _short_result(query: str = "", **_) -> str:
    return "ک"  # عمداً کوتاه -> ReflectionEngine راضی نمی‌شود


async def _good_result(query: str = "", **_) -> str:
    return f"پاسخِ کاملی برایِ «{query}» با جزئیاتِ کافی برایِ عبورِ Reflection."


async def _boom(query: str = "", **_) -> str:
    raise RuntimeError("خرابیِ عمدیِ ابزار برایِ تستِ مسیرِ خطا")


def _make_registry(**tools: AgentTool) -> ToolRegistry:
    registry = ToolRegistry()
    for tool in tools.values():
        registry.register(tool)
    return registry


# ==================================================================
#   AgentTool / ToolRegistry
# ==================================================================


def test_tool_score_zero_without_keywords():
    tool = AgentTool(name="x", description="d", run=_good_result, keywords=[])
    assert tool.score("هر متنی") == 0.0


def test_tool_score_matches_keyword():
    tool = AgentTool(name="weather", description="d", run=_good_result, keywords=["آب و هوا"])
    assert tool.score("آب و هوا چطوره؟") > 0.0
    assert tool.score("جمعیتِ ایران چقدره") == 0.0


def test_registry_rank_orders_by_score_and_respects_exclude():
    registry = _make_registry(
        weather=AgentTool(name="weather", description="d", run=_good_result, keywords=["آب و هوا"]),
        calc=AgentTool(name="calc", description="d", run=_good_result, keywords=["محاسبه"]),
    )
    ranked = registry.rank("آب و هوا رو بگو")
    assert ranked[0][0].name == "weather"

    ranked_excluded = registry.rank("آب و هوا رو بگو", exclude={"weather"})
    assert all(tool.name != "weather" for tool, _score in ranked_excluded)


def test_run_safe_never_raises_on_tool_exception():
    async def _run():
        tool = AgentTool(name="broken", description="d", run=_boom, keywords=["x"])
        result = await tool.run_safe(query="x")
        assert isinstance(result, ToolResult)
        assert result.ok is False
        assert "RuntimeError" in (result.error or "")
    asyncio.run(_run())


def test_run_safe_reports_success():
    async def _run():
        tool = AgentTool(name="ok", description="d", run=_good_result, keywords=["x"])
        result = await tool.run_safe(query="سؤالِ آزمایشی")
        assert result.ok is True
        assert "سؤالِ آزمایشی" in result.output
    asyncio.run(_run())


# ==================================================================
#   Scratchpad
# ==================================================================


def test_scratchpad_tracks_tried_tools_and_success():
    pad = Scratchpad()
    assert pad.has_any_success is False
    pad.add_result(ToolResult(tool_name="a", ok=False, error="نشد"))
    pad.add_result(ToolResult(tool_name="b", ok=True, output="جواب"))
    assert pad.tried_tools == {"a", "b"}
    assert pad.has_any_success is True
    assert "جواب" in pad.successful_texts()


def test_scratchpad_context_text_is_bounded():
    pad = Scratchpad(max_chars=50)
    pad.add_result(ToolResult(tool_name="a", ok=True, output="س" * 200))
    text = pad.context_text()
    assert len(text) <= 60  # ۵۰ + بریدگیِ « …»


# ==================================================================
#   LoopGuard
# ==================================================================


def test_guard_blocks_after_max_steps():
    guard = LoopGuard(AgentConfig(max_steps=1, max_calls_per_tool=5))
    guard.check_before_call("t", {"query": "x"})
    guard.record_call("t", {"query": "x"})
    guard.record_step()
    with pytest.raises(GuardrailViolation):
        guard.check_before_call("t2", {"query": "y"})


def test_guard_blocks_exact_duplicate_call():
    guard = LoopGuard(AgentConfig(max_steps=5, max_calls_per_tool=5))
    guard.check_before_call("t", {"query": "x"})
    guard.record_call("t", {"query": "x"})
    with pytest.raises(GuardrailViolation):
        guard.check_before_call("t", {"query": "x"})


def test_guard_blocks_tool_outside_allowlist():
    guard = LoopGuard(AgentConfig(allowed_tools={"a"}))
    with pytest.raises(GuardrailViolation):
        guard.check_before_call("b", {})


def test_guard_blocks_over_per_tool_cap():
    guard = LoopGuard(AgentConfig(max_steps=10, max_calls_per_tool=1))
    guard.check_before_call("t", {"query": "1"})
    guard.record_call("t", {"query": "1"})
    with pytest.raises(GuardrailViolation):
        guard.check_before_call("t", {"query": "2"})


# ==================================================================
#   AgentLoop (end-to-end با ابزارهایِ ساختگی)
# ==================================================================


def test_loop_finishes_immediately_when_no_tool_matches():
    async def _run():
        registry = _make_registry(
            weather=AgentTool(name="weather", description="d", run=_good_result, keywords=["آب و هوا"]),
        )
        trace = await AgentLoop(registry, AgentConfig()).run("یک شعر بگو")
        assert trace.stop_reason == StopReason.NEEDS_USER_INPUT
        assert trace.success is False
        assert trace.tool_calls_made() == 0
    asyncio.run(_run())


def test_loop_completes_with_single_good_tool():
    async def _run():
        registry = _make_registry(
            search=AgentTool(name="search", description="d", run=_good_result, keywords=["جمعیت", "ایران"]),
        )
        trace = await AgentLoop(registry, AgentConfig()).run("جمعیتِ ایران چقدره؟")
        assert trace.success is True
        assert trace.stop_reason == StopReason.GOAL_SATISFIED
        assert trace.tool_calls_made() == 1
        assert "جمعیتِ ایران چقدره؟" in trace.final_answer
    asyncio.run(_run())


def test_loop_chains_multiple_tools_when_first_is_insufficient():
    async def _run():
        registry = _make_registry(
            search=AgentTool(name="search", description="d", run=_short_result, keywords=["جمعیت"]),
            calc=AgentTool(name="calc", description="d", run=_good_result, keywords=["تقسیم"]),
        )
        trace = await AgentLoop(registry, AgentConfig(max_steps=5)).run("جمعیت رو پیدا کن و تقسیم کن")
        assert trace.tool_calls_made() == 2
        assert {s.action.tool_name for s in trace.steps if s.action.type == ActionType.TOOL_CALL} == {
            "search",
            "calc",
        }
    asyncio.run(_run())


def test_loop_stops_on_budget_exhausted_with_many_insufficient_tools():
    async def _run():
        registry = _make_registry(**{
            f"t{i}": AgentTool(name=f"t{i}", description="d", run=_short_result, keywords=["هدف"])
            for i in range(5)
        })
        trace = await AgentLoop(registry, AgentConfig(max_steps=2, max_calls_per_tool=1)).run("یک هدفِ آزمایشی")
        assert trace.stop_reason == StopReason.BUDGET_EXHAUSTED
        assert len(trace.steps) == 2
    asyncio.run(_run())


def test_loop_survives_tool_exception_and_tries_next_tool():
    async def _run():
        registry = _make_registry(
            broken=AgentTool(name="broken", description="d", run=_boom, keywords=["هدف", "آزمایشی"]),
            good=AgentTool(name="good", description="d", run=_good_result, keywords=["هدف", "آزمایشی"]),
        )
        trace = await AgentLoop(registry, AgentConfig(max_steps=4)).run("یک هدفِ آزمایشی")
        assert trace.success is True
        used = [s.action.tool_name for s in trace.steps if s.action.type == ActionType.TOOL_CALL]
        assert "broken" in used
        assert "good" in used
    asyncio.run(_run())


def test_loop_rejects_empty_goal():
    async def _run():
        registry = ToolRegistry()
        trace = await AgentLoop(registry, AgentConfig()).run("   ")
        assert trace.success is False
        assert trace.stop_reason == StopReason.ERROR
    asyncio.run(_run())


# ==================================================================
#   build_default_registry -- فقط بررسیِ ساختار (بدونِ شبکه)
# ==================================================================


class _FakeSessionMgr:
    active_session = "default"


class _FakeDB:
    def search_knowledge(self, query):
        return None


class _FakeAI:
    """جانشینِ حداقلیِ ``TRXEnterpriseAI`` -- فقط attributeهایی که
    ``build_default_registry`` واقعاً می‌خواند."""

    session = None
    db = _FakeDB()
    session_mgr = _FakeSessionMgr()
    image_engine = None
    task_manager = None
    _last_image_path = None


def test_build_default_registry_registers_expected_tools():
    registry = build_default_registry(_FakeAI())
    names = set(registry.names())
    assert {
        "web_search",
        "knowledge_base",
        "weather",
        "calculator",
        "translator",
        "vision",
        "code_intelligence",
        "file_read",
        "add_task",
    }.issubset(names)


def test_default_calculator_tool_is_safe_and_offline():
    async def _run():
        registry = build_default_registry(_FakeAI())
        calc = registry.get("calculator")
        result = await calc.run_safe(query="(2 + 3) * 5")
        assert result.ok is True
        assert "25" in result.output
    asyncio.run(_run())


def test_default_vision_tool_without_uploaded_image():
    async def _run():
        registry = build_default_registry(_FakeAI())
        vision = registry.get("vision")
        result = await vision.run_safe(query="این عکس چیه؟")
        assert result.ok is True
        assert "آپلود نشده" in result.output
    asyncio.run(_run())
