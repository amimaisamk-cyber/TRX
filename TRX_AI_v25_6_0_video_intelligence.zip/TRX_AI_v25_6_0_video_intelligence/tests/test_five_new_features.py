# -*- coding: utf-8 -*-
"""
تست‌های واحد برای ۵ قابلیتِ جدید: تبدیلِ واحد، تولیدِ رمزِ عبور،
محاسبه‌ی BMI، مدیریتِ خرج‌ها، و پشتیبان‌گیری/بازیابی.
"""

import pytest

from trx_ai.health_utils import HealthCalculator, PasswordGenerator, UnitConverter
from trx_ai.expenses import parse_expense, ExpenseManager
from trx_ai.intelligence import IntentEngine


# ---------------------------------------------------------------------------
#   تشخیصِ نیت برایِ هر ۵ قابلیت
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected_intent", [
    ("۱۰ کیلومتر به مایل", "unit_convert"),
    ("۲۰ درجه سانتیگراد به فارنهایت", "unit_convert"),
    ("رمز عبور قوی بساز", "password_gen"),
    ("بی‌ام‌آی من چنده وزنم ۷۰ قدم ۱۷۵", "bmi"),
    ("خرج کردم ۵۰ هزار تومان برای نهار", "expense_add"),
    ("خلاصه خرج‌هام رو نشون بده", "expense_summary"),
    ("پشتیبان‌گیری کن", "backup_data"),
    ("بازیابی کن", "restore_data"),
])
def test_new_feature_intents(text, expected_intent):
    intent, confidence, _ = IntentEngine.detect_intent(text, None, None)
    assert intent == expected_intent
    assert confidence == 0.98  # همه‌ی این‌ها structural command هستند


# ---------------------------------------------------------------------------
#   UnitConverter
# ---------------------------------------------------------------------------
def test_length_conversion():
    result = UnitConverter.convert_from_text("۱۰ کیلومتر به مایل")
    assert "6.21" in result and "مایل" in result


def test_weight_conversion():
    result = UnitConverter.convert_from_text("۵ کیلوگرم به پوند")
    assert "پوند" in result


def test_temperature_conversion():
    result = UnitConverter.convert_from_text("۲۰ درجه سانتیگراد به فارنهایت")
    assert "68" in result


def test_incompatible_units_rejected():
    result = UnitConverter.convert_from_text("۱۰ کیلومتر به کیلوگرم")
    assert "❌" in result


# ---------------------------------------------------------------------------
#   PasswordGenerator
# ---------------------------------------------------------------------------
def test_password_default_length():
    p = PasswordGenerator.generate()
    assert len(p) == 16


def test_password_contains_all_character_classes():
    p = PasswordGenerator.generate(20)
    assert any(c.islower() for c in p)
    assert any(c.isupper() for c in p)
    assert any(c.isdigit() for c in p)
    assert any(c in "!@#$%^&*()-_=+" for c in p)


def test_password_length_clamped_to_reasonable_range():
    assert len(PasswordGenerator.generate(2)) >= 8
    assert len(PasswordGenerator.generate(9999)) <= 128


def test_password_generate_from_text_respects_requested_length():
    result = PasswordGenerator.generate_from_text("رمز عبور با طول 24 بساز")
    assert "24 کاراکتر" in result


# ---------------------------------------------------------------------------
#   HealthCalculator (BMI)
# ---------------------------------------------------------------------------
def test_bmi_normal_category():
    result = HealthCalculator.calculate_from_text("بی‌ام‌آی من چنده وزنم ۷۰ قدم ۱۷۵")
    assert "22.9" in result
    assert "طبیعی" in result


def test_bmi_missing_data_gives_clear_error():
    result = HealthCalculator.calculate_from_text("بی ام ای من چیه")
    assert "❌" in result


@pytest.mark.parametrize("weight,height,expected_category", [
    (45, 175, "کم‌وزن"),
    (70, 175, "طبیعی"),
    (85, 175, "اضافه‌وزن"),
    (110, 175, "چاق"),
])
def test_bmi_categories(weight, height, expected_category):
    text = f"بی‌ام‌آی من چنده وزنم {weight} قدم {height}"
    result = HealthCalculator.calculate_from_text(text)
    assert expected_category in result


# ---------------------------------------------------------------------------
#   ExpenseManager
# ---------------------------------------------------------------------------
def test_parse_expense_extracts_amount_and_category():
    parsed = parse_expense("خرج کردم ۵۰ هزار تومان برای نهار")
    assert parsed["amount"] == 50_000
    assert parsed["category"] == "غذا"


def test_parse_expense_million_multiplier():
    parsed = parse_expense("۲ میلیون تومان برای اجاره خونه دادم")
    assert parsed["amount"] == 2_000_000
    assert parsed["category"] == "قبض"


def test_parse_expense_unrecognized_category_falls_back_to_misc():
    parsed = parse_expense("۱۰۰۰۰ تومان دادم بابت یه چیز عجیب")
    assert parsed["category"] == "متفرقه"


def test_expense_manager_add_and_summary():
    class FakeDB:
        def __init__(self):
            self.rows = []
        def add_expense(self, amount, category, note, project):
            self.rows.append((len(self.rows) + 1, amount, category, note, "2026-07-14 10:00:00"))
        def list_expenses(self, project=None, since=None):
            return self.rows

    db = FakeDB()
    manager = ExpenseManager(db)
    result = manager.add_from_text("خرج کردم ۵۰ هزار تومان برای نهار")
    assert result["amount"] == 50_000

    summary = manager.format_summary()
    assert "غذا" in summary
    assert "50" in summary.replace("٬", ",").replace(",", "")
