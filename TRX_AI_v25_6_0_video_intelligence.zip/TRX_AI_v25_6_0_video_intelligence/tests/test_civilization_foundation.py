# -*- coding: utf-8 -*-
"""تست‌های Persepolis Foundation (مرحله‌ی ۱ از معماریِ تخت‌جمشید)."""

from __future__ import annotations

import pytest

from trx_ai.civilization import (
    DomainManifest,
    DomainRegistry,
    EventBus,
    EventEnvelope,
    HealthRegistry,
    HealthReport,
    HealthStatus,
    aggregate_status,
    build_default_registry,
)
from trx_ai.civilization.domains.registry import DomainNotFoundError, DomainRegistrationError


# ---------------------------------------------------------------------------
# contracts
# ---------------------------------------------------------------------------

def test_domain_manifest_is_a_plain_immutable_value():
    manifest = DomainManifest(name="x", version="1.0", capabilities=["a"], dependencies=[])
    assert manifest.name == "x"
    with pytest.raises(Exception):
        manifest.name = "y"  # frozen dataclass


def test_event_envelope_generates_id_and_timestamp():
    e1 = EventEnvelope(event_type="turn.completed", source_domain="conversation")
    e2 = EventEnvelope(event_type="turn.completed", source_domain="conversation")
    assert e1.event_id != e2.event_id
    assert e1.created_at > 0


# ---------------------------------------------------------------------------
# health registry -- must be fail-soft
# ---------------------------------------------------------------------------

def test_health_registry_runs_healthy_check():
    registry = HealthRegistry()
    registry.register("demo", lambda: HealthReport(domain="demo", status=HealthStatus.HEALTHY))
    report = registry.run_one("demo")
    assert report.status == HealthStatus.HEALTHY


def test_health_registry_unknown_domain_returns_none_not_raise():
    registry = HealthRegistry()
    assert registry.run_one("does-not-exist") is None


def test_health_registry_swallows_exceptions_from_check_fn():
    registry = HealthRegistry()

    def broken_check():
        raise RuntimeError("boom")

    registry.register("broken", broken_check)
    report = registry.run_one("broken")
    assert report.status == HealthStatus.UNKNOWN
    assert "boom" in report.detail or "RuntimeError" in report.detail


def test_health_registry_run_all_is_independent_per_domain():
    registry = HealthRegistry()
    registry.register("ok", lambda: HealthReport(domain="ok", status=HealthStatus.HEALTHY))
    registry.register("bad", lambda: (_ for _ in ()).throw(ValueError("x")))
    results = registry.run_all()
    assert results["ok"].status == HealthStatus.HEALTHY
    assert results["bad"].status == HealthStatus.UNKNOWN


def test_health_registry_rejects_non_report_return_value():
    registry = HealthRegistry()
    registry.register("weird", lambda: "not a report")
    report = registry.run_one("weird")
    assert report.status == HealthStatus.UNKNOWN


def test_aggregate_status_picks_worst():
    reports = {
        "a": HealthReport(domain="a", status=HealthStatus.HEALTHY),
        "b": HealthReport(domain="b", status=HealthStatus.DEGRADED),
        "c": HealthReport(domain="c", status=HealthStatus.HEALTHY),
    }
    assert aggregate_status(reports) == HealthStatus.DEGRADED


def test_aggregate_status_empty_is_unknown():
    assert aggregate_status({}) == HealthStatus.UNKNOWN


# ---------------------------------------------------------------------------
# event bus -- bounded, fail-soft
# ---------------------------------------------------------------------------

def test_event_bus_publish_and_recent():
    bus = EventBus(buffer_size=10)
    bus.publish(EventEnvelope(event_type="t1", source_domain="d1"))
    bus.publish(EventEnvelope(event_type="t2", source_domain="d1"))
    recent = bus.recent(limit=10)
    assert len(recent) == 2
    assert recent[-1].event_type == "t2"


def test_event_bus_is_bounded():
    bus = EventBus(buffer_size=3)
    for i in range(10):
        bus.publish(EventEnvelope(event_type=f"t{i}", source_domain="d"))
    assert len(bus) == 3
    assert [e.event_type for e in bus.recent(10)] == ["t7", "t8", "t9"]


def test_event_bus_subscriber_receives_matching_type_only():
    bus = EventBus()
    received = []
    bus.subscribe("turn.completed", lambda e: received.append(e.event_type))
    bus.publish(EventEnvelope(event_type="turn.completed", source_domain="d"))
    bus.publish(EventEnvelope(event_type="other", source_domain="d"))
    assert received == ["turn.completed"]


def test_event_bus_wildcard_subscriber_receives_everything():
    bus = EventBus()
    received = []
    bus.subscribe_all(lambda e: received.append(e.event_type))
    bus.publish(EventEnvelope(event_type="a", source_domain="d"))
    bus.publish(EventEnvelope(event_type="b", source_domain="d"))
    assert received == ["a", "b"]


def test_event_bus_subscriber_exception_does_not_break_publish_or_other_subscribers():
    bus = EventBus()
    received = []

    def broken_handler(_event):
        raise RuntimeError("subscriber exploded")

    bus.subscribe("t", broken_handler)
    bus.subscribe("t", lambda e: received.append(e.event_type))

    # نباید exception به بیرون درز کند
    bus.publish(EventEnvelope(event_type="t", source_domain="d"))
    assert received == ["t"]
    # و باید در بافر ذخیره شده باشد حتی با وجودِ subscriber شکسته
    assert len(bus) == 1


def test_event_bus_rejects_non_positive_buffer_size():
    with pytest.raises(ValueError):
        EventBus(buffer_size=0)


# ---------------------------------------------------------------------------
# domain registry
# ---------------------------------------------------------------------------

def test_domain_registry_register_and_get():
    registry = DomainRegistry()
    registry.register(DomainManifest(name="demo", version="1.0"))
    assert registry.get("demo").version == "1.0"


def test_domain_registry_duplicate_without_replace_raises():
    registry = DomainRegistry()
    registry.register(DomainManifest(name="demo", version="1.0"))
    with pytest.raises(DomainRegistrationError):
        registry.register(DomainManifest(name="demo", version="2.0"))


def test_domain_registry_duplicate_with_replace_overwrites():
    registry = DomainRegistry()
    registry.register(DomainManifest(name="demo", version="1.0"))
    registry.register(DomainManifest(name="demo", version="2.0"), replace=True)
    assert registry.get("demo").version == "2.0"


def test_domain_registry_missing_raises_not_found():
    registry = DomainRegistry()
    with pytest.raises(DomainNotFoundError):
        registry.get("nope")
    assert registry.get_or_none("nope") is None


def test_build_default_registry_covers_mapped_domains():
    registry = build_default_registry()
    names = set(registry.names())
    # همان دامنه‌هایی که mapping مرحله‌ی ۰ شناسایی کرد
    for expected in ("conversation", "nlu", "medical", "phase3", "core_engine", "tools", "memory_store"):
        assert expected in names


def test_build_default_registry_is_pure_and_repeatable():
    r1 = build_default_registry()
    r2 = build_default_registry()
    assert r1.names() == r2.names()
    assert r1 is not r2  # هر فراخوانی یک نمونه‌ی مستقلِ جدید


def test_civilization_package_has_no_static_import_of_live_path():
    """
    اطمینانِ ایستا (نه فقط ادعا در docstring) از اینکه هیچ فایلِ این
    پکیج مستقیماً ``trx_ai.core``/``trx_ai.intelligence``/
    ``trx_ai.conversation`` را import نمی‌کند -- یعنی additive بودن
    یک قرارداد تست‌شده است، نه فقط یک جمله در کامنت.

    از AST استفاده می‌شود (نه substring روی متنِ خام فایل) چون
    docstringهایِ همین فایل‌ها عمداً به این نام‌ها اشاره می‌کنند تا
    توضیح بدهند که import نشده‌اند -- substring ساده آن جمله‌های
    توضیحی را هم به اشتباه «نقض» می‌شمرد.
    """
    import ast
    import pathlib

    forbidden_roots = ("trx_ai.core", "trx_ai.intelligence", "trx_ai.conversation")
    package_dir = pathlib.Path(__file__).resolve().parent.parent / "trx_ai" / "civilization"

    def imported_dotted_names(tree: ast.AST):
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    yield alias.name
            elif isinstance(node, ast.ImportFrom):
                if node.level and node.level > 0:
                    continue  # importهای نسبی (داخلِ خودِ این پکیج) مدنظر نیستند
                if node.module:
                    yield node.module

    for py_file in package_dir.rglob("*.py"):
        tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
        for dotted_name in imported_dotted_names(tree):
            for forbidden_module in forbidden_roots:
                assert not dotted_name.startswith(forbidden_module), (
                    f"{py_file} statically imports {dotted_name}"
                )
