# -*- coding: utf-8 -*-
"""
تست‌های واحد برایِ لایه‌ی مشاهده‌پذیری (``trx_ai.core_engine.trace``).

قبل از این ارتقا، این ماژول -- با اینکه به‌طورِ کامل به مسیرِ اصلیِ چت
(`TurnProcessor.process_turn`) وصل شده بود -- هیچ تستِ اختصاصی نداشت،
و مهم‌تر: نوبت‌هایِ «عکس»/«فایل» (`process_image_turn`/`process_file_turn`)
هیچ‌وقت trace نمی‌ساختند. این فایل هم رفتارِ پایه‌ایِ خودِ
``TurnTrace``/``TraceRecorder``/``TraceLog`` را قفل می‌کند، هم دقیقاً
همان نقصی را که در ``OBSERVABILITY_UPGRADE_NOTES.md`` مستند شده رگرسیون
می‌کند: بعدِ آپلودِ عکس/فایل، ``ai.trace_log`` باید واقعاً یک رکوردِ
مربوط به همان نوبت داشته باشد -- نه رکوردِ نوبتِ متنیِ قبلی.

همان فلسفه‌ی بقیه‌ی تست‌های پروژه: بدونِ شبکه/pytest-asyncio؛ توابعِ
async با ``asyncio.run(...)`` مستقیماً اجرا می‌شوند.
"""

from __future__ import annotations

import asyncio

from trx_ai.core_engine.trace import TraceLog, TraceRecorder, TurnTrace
from trx_ai.core_engine.turn_processor import TurnProcessor
from trx_ai.vision import ImageEngine


# ======================================================================
#   بخشِ ۱: رفتارِ پایه‌ایِ خودِ trace.py (بدونِ نیاز به شیءِ ai)
# ======================================================================


def test_trace_recorder_mark_sets_known_fields():
    rec = TraceRecorder("سلام")
    rec.mark(detected_intent="smalltalk", confidence=0.9, selected_route="general:smalltalk")
    assert rec.data.detected_intent == "smalltalk"
    assert rec.data.confidence == 0.9
    assert rec.data.selected_route == "general:smalltalk"
    assert rec.data.input == "سلام"


def test_trace_recorder_route_note_appends_to_history_not_overwrite():
    rec = TraceRecorder("متن")
    rec.mark(route_note="مرحله‌ی اول")
    rec.mark(route_note="مرحله‌ی دوم")
    assert rec.data.route_history == ["مرحله‌ی اول", "مرحله‌ی دوم"]


def test_trace_recorder_unknown_field_is_fail_soft_not_raised():
    rec = TraceRecorder("متن")
    # فیلدی که در TurnTrace تعریف نشده -- نباید AttributeError بدهد،
    # فقط باید در route_history ثبت شود (طبقِ کامنتِ خودِ trace.py).
    rec.mark(some_undefined_field="x")
    assert any("some_undefined_field" in note for note in rec.data.route_history)


def test_trace_recorder_finish_computes_latency_if_missing():
    rec = TraceRecorder("متن")
    trace = rec.finish()
    assert isinstance(trace, TurnTrace)
    assert trace.latency_ms is not None and trace.latency_ms >= 0


def test_trace_recorder_finish_respects_explicit_latency():
    rec = TraceRecorder("متن")
    rec.mark(latency_ms=999)
    trace = rec.finish()
    assert trace.latency_ms == 999


def test_trace_log_maxlen_evicts_oldest():
    log = TraceLog(maxlen=3)
    for i in range(5):
        rec = TraceRecorder(f"پیامِ {i}")
        log.push(rec.finish())
    assert len(log) == 3
    remaining_inputs = [t.input for t in log]
    assert remaining_inputs == ["پیامِ 2", "پیامِ 3", "پیامِ 4"]


def test_trace_log_last_n_returns_most_recent_in_order():
    log = TraceLog(maxlen=10)
    for i in range(4):
        log.push(TraceRecorder(f"پیامِ {i}").finish())
    last_two = log.last(2)
    assert [t.input for t in last_two] == ["پیامِ 2", "پیامِ 3"]


def test_trace_log_last_default_returns_single_most_recent():
    log = TraceLog(maxlen=10)
    log.push(TraceRecorder("اول").finish())
    log.push(TraceRecorder("دوم").finish())
    assert [t.input for t in log.last()] == ["دوم"]


def test_trace_log_empty_last_returns_empty_list():
    log = TraceLog(maxlen=10)
    assert log.last() == []
    assert log.last(3) == []


# ======================================================================
#   بخشِ ۲: قفلِ رگرسیونِ نقصِ اصلی -- عکس/فایل حالا trace می‌سازند
# ======================================================================


class _StubUIConsole:
    def status(self, *_a, **_k):
        class _Ctx:
            def __enter__(self_inner):
                return self_inner

            def __exit__(self_inner, *exc):
                return False

        return _Ctx()


class _StubUI:
    def __init__(self):
        self.console = _StubUIConsole()


class _MinimalAI:
    """
    فقط دقیقاً همان attributeهایی که مسیرِ خطایِ اعتبارسنجیِ
    ``process_image_turn``/``process_file_turn`` به آن‌ها نیاز دارد --
    نه یک شیءِ AI کامل. مسیرِ finalize (موفقیت‌آمیز) در این فایل تست
    نمی‌شود چون به db/memory/user_state واقعی نیاز دارد؛ آن مسیر از
    طریقِ همان الگویی که ``process_turn`` قبلاً استفاده می‌کند (و از قبل
    تست شده) پوشش داده می‌شود -- اینجا فقط نقصِ *جدید* (نبودِ trace در
    شاخه‌های زودبازگشت) قفل می‌شود.
    """

    def __init__(self, tmp_files_dir="/tmp/trx_ai_test_files"):
        self.ui = _StubUI()
        self.trace_log = TraceLog(maxlen=50)
        self.current_trace = None
        self._presented = []
        # ImageEngine واقعی است (نه ساختگی) -- چون validation قبلِ هر
        # I/O واقعی رد می‌شود (رجوع کنید به ``ImageEngine.save_incoming``),
        # نیازی به mock نیست.
        self.image_engine = ImageEngine(tmp_files_dir)

    async def _present(self, answer, title, style):
        self._presented.append((answer, title, style))


def test_image_turn_validation_error_creates_and_pushes_trace():
    ai = _MinimalAI()
    tp = TurnProcessor(ai)

    async def _run():
        # بایتِ خالی -- ImageEngine.save_incoming همیشه این را رد می‌کند،
        # پس نیازی به یک ImageEngine واقعی/ساختگی نیست.
        await tp.process_image_turn(b"", "image/jpeg", caption="")

    asyncio.run(_run())

    assert len(ai.trace_log) == 1
    tr = ai.trace_log.last()[0]
    assert tr.selected_route == "vision:validation_error"
    assert tr.error and "خالی" in tr.error
    assert ai.current_trace is None, "trace باید بعدِ ثبت، پاک شود (نه برایِ نوبتِ بعدی بمانَد)"
    assert len(ai._presented) == 1


def test_file_turn_validation_error_creates_and_pushes_trace():
    ai = _MinimalAI()
    tp = TurnProcessor(ai)

    async def _run():
        # بایتِ خالی -- FileManager.save_incoming همیشه این را رد می‌کند.
        await tp.process_file_turn(b"", "test.txt", caption="")

    asyncio.run(_run())

    assert len(ai.trace_log) == 1
    tr = ai.trace_log.last()[0]
    assert tr.selected_route == "file:validation_error"
    assert tr.error and "خالی" in tr.error
    assert ai.current_trace is None
    assert len(ai._presented) == 1


def test_image_and_file_turn_traces_do_not_leak_into_each_other():
    """
    قبل از این ارتقا، چون ``process_image_turn``/``process_file_turn``
    هیچ trace نمی‌ساختند، ``ai.current_trace`` مقدارِ نوبتِ متنیِ *قبلی*
    (یا None) می‌ماند. این تست مطمئن می‌شود که هر نوبتِ عکس/فایل، trace
    مخصوصِ خودش را می‌سازد -- نه اینکه چیزی از نوبتِ قبلی را دوباره صدا کند.
    """
    ai = _MinimalAI()
    tp = TurnProcessor(ai)

    async def _run():
        await tp.process_image_turn(b"", "image/jpeg", caption="اول")
        await tp.process_file_turn(b"", "دوم.txt", caption="")

    asyncio.run(_run())

    assert len(ai.trace_log) == 2
    first, second = list(ai.trace_log)
    assert first.input == "[عکس] اول"
    assert second.input == "[فایل: دوم.txt]"
    assert first.trace_id != second.trace_id
