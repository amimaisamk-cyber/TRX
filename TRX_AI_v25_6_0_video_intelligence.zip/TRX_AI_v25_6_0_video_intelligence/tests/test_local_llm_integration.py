# -*- coding: utf-8 -*-
"""
تست‌هایِ v25.5.3 -- آداپتورِ مدلِ زبانیِ محلی + پلِ گفتگو.

طبقِ همان فلسفه‌ی بقیه‌ی تست‌هایِ پروژه: بدونِ نصبِ واقعیِ
``llama-cpp-python`` (این sandbox اینترنت ندارد) با تزریقِ یک stub
تستِ منطقِ *خودمان* را انجام می‌دهیم -- نه تستِ خودِ کتابخانه‌ی
llama.cpp که مسئولیتِ ما نیست.

سه دسته:
    ۱) ``LlamaCppModelAdapter`` -- قراردادِ ModelInterface + خطایِ صریح
       وقتی فایلِ مدل نیست.
    ۲) ``conversational_bridge`` -- کلیدِ خاموش/روشن، و اینکه هر خطایی
       بی‌صدا ``None`` برمی‌گرداند (هرگز کرش نمی‌کند).
    ۳) رگرسیون: وقتی کلید خاموش است، خروجیِ ``tool_router``ی که این
       پل را صدا می‌زند دقیقاً همان چیزی‌ست که قبل از این تغییر بود --
       یعنی این افزوده هیچ رفتارِ موجودی را عوض نکرده.
"""

from __future__ import annotations

import os
import tempfile
import unittest


class FakeLlama:
    """Stubِ حداقلیِ ``llama_cpp.Llama`` برایِ تست -- بدونِ وزنِ واقعی."""

    def __init__(self, model_path, n_ctx, n_threads, n_gpu_layers):
        self.model_path = model_path
        self.calls: list = []

    def tokenize(self, raw_bytes):
        return [1, 2, 3]

    def detokenize(self, ids):
        return "سلام".encode("utf-8")

    def create_chat_completion(self, messages, max_tokens, temperature):
        self.calls.append((messages, max_tokens, temperature))
        user_msg = messages[-1]["content"]
        return {"choices": [{"message": {"content": f"پاسخِ آزمایشی: {user_msg}"}}]}


class BrokenFakeLlama:
    """Stubی که خروجیِ نامعتبر می‌دهد -- برایِ تستِ مسیرِ خطا."""

    def __init__(self, *a, **k):
        pass

    def create_chat_completion(self, **kwargs):
        return {"unexpected": "shape"}


class LlamaCppModelAdapterTests(unittest.TestCase):
    def setUp(self):
        fd, self.model_path = tempfile.mkstemp(suffix=".gguf")
        os.close(fd)
        with open(self.model_path, "wb") as f:
            f.write(b"fake-weights-not-a-real-model")

    def tearDown(self):
        os.unlink(self.model_path)

    def test_raises_clear_error_when_model_file_missing(self):
        from trx_ai.trx_model.llama_cpp_adapter import (
            LlamaCppModelAdapter,
            LocalLLMNotAvailableError,
        )

        with self.assertRaises(LocalLLMNotAvailableError):
            LlamaCppModelAdapter(model_path="/definitely/does/not/exist.gguf")

    def test_chat_builds_correct_message_roles_and_returns_text(self):
        from trx_ai.trx_model.llama_cpp_adapter import LlamaCppModelAdapter

        adapter = LlamaCppModelAdapter(model_path=self.model_path, llama_factory=FakeLlama)
        reply = adapter.chat(
            system_prompt="تو TRX هستی",
            user_text="سلام",
            history=[("user", "قبلاً"), ("assistant", "جواب قبلی")],
        )
        self.assertEqual(reply, "پاسخِ آزمایشی: سلام")
        sent_messages = adapter._llama.calls[0][0]
        self.assertEqual(sent_messages[0], {"role": "system", "content": "تو TRX هستی"})
        self.assertEqual(sent_messages[-1], {"role": "user", "content": "سلام"})

    def test_model_interface_contract_encode_decode(self):
        from trx_ai.trx_model.llama_cpp_adapter import LlamaCppModelAdapter
        from trx_ai.trx_model.interfaces import ModelInterface

        adapter = LlamaCppModelAdapter(model_path=self.model_path, llama_factory=FakeLlama)
        self.assertIsInstance(adapter, ModelInterface)
        self.assertEqual(adapter.encode("هرچی"), [1, 2, 3])
        self.assertEqual(adapter.decode([1, 2, 3]), "سلام")

    def test_unexpected_llama_output_raises_not_silently_returns_garbage(self):
        from trx_ai.trx_model.llama_cpp_adapter import (
            LlamaCppModelAdapter,
            LocalLLMNotAvailableError,
        )

        adapter = LlamaCppModelAdapter(model_path=self.model_path, llama_factory=BrokenFakeLlama)
        with self.assertRaises(LocalLLMNotAvailableError):
            adapter.chat(system_prompt="", user_text="سلام")


class ConversationalBridgeTests(unittest.TestCase):
    def setUp(self):
        from trx_ai.trx_model import conversational_bridge

        self.bridge = conversational_bridge
        self.bridge.reset_for_tests()
        self._env_backup = dict(os.environ)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._env_backup)
        self.bridge.reset_for_tests()

    def test_disabled_by_default_returns_none(self):
        os.environ.pop("TRX_LOCAL_LLM_ENABLED", None)
        self.assertFalse(self.bridge.is_enabled())
        self.assertIsNone(self.bridge.try_generate_reply("سلام"))

    def test_enabled_but_model_missing_returns_none_not_crash(self):
        os.environ["TRX_LOCAL_LLM_ENABLED"] = "true"
        os.environ["TRX_LOCAL_LLM_MODEL_PATH"] = "/nonexistent/model.gguf"
        result = self.bridge.try_generate_reply("سلام")
        self.assertIsNone(result)

    def test_enabled_with_working_adapter_returns_real_reply(self):
        import trx_ai.trx_model.llama_cpp_adapter as llama_cpp_adapter_mod

        os.environ["TRX_LOCAL_LLM_ENABLED"] = "true"
        os.environ["TRX_LOCAL_LLM_MODEL_PATH"] = __file__  # هر فایلِ موجودی کافی‌ست
        original_llama_cpp_adapter = llama_cpp_adapter_mod.LlamaCppModelAdapter

        def _patched(model_path, **kwargs):
            return original_llama_cpp_adapter(model_path=model_path, llama_factory=FakeLlama)

        llama_cpp_adapter_mod.LlamaCppModelAdapter = _patched
        try:
            result = self.bridge.try_generate_reply("چی درمورد کوروش کبیر میدونی")
            self.assertIsNotNone(result)
            self.assertIn("چی درمورد کوروش کبیر میدونی", result)
        finally:
            llama_cpp_adapter_mod.LlamaCppModelAdapter = original_llama_cpp_adapter


class ToolRouterFallbackNoRegressionTests(unittest.TestCase):
    """
    وقتی کلید خاموش است (پیش‌فرض)، این تست تضمین می‌کند
    ``conversational_bridge.try_generate_reply`` دقیقاً همان چیزی که
    قبل از v25.5.3 بود را برمی‌گرداند (``None``) -- یعنی
    ``tool_router.py`` بدونِ تغییر به boilerplateِ قدیمی می‌رود.
    این یک تستِ سطحِ‌واحد است روی خودِ تابعِ پل، نه یک راه‌اندازیِ کاملِ
    ``TRXEnterpriseAI`` (که در محیطِ بدونِ pytest/فیکسچرهایِ پروژه
    پرهزینه است) -- اما دقیقاً همان شرطی را چک می‌کند که کدِ
    ``tool_router.py`` برایِ تصمیم‌گیری استفاده می‌کند.
    """

    def test_bridge_returns_none_by_default_so_old_boilerplate_path_runs(self):
        from trx_ai.trx_model import conversational_bridge

        conversational_bridge.reset_for_tests()
        os.environ.pop("TRX_LOCAL_LLM_ENABLED", None)
        self.assertIsNone(conversational_bridge.try_generate_reply("هر پیامِ دلخواه"))


class ConversationalModelInterface_ContractTests(unittest.TestCase):
    """
    رفعِ نکته‌یِ معماریِ ۲۰۲۶-۰۹-۲۰: ``conversational_bridge`` نباید
    کورکورانه رویِ ``.chat`` حساب کند؛ باید صریحاً چک کند که آداپتور
    واقعاً ``ConversationalModelInterface`` را پیاده کرده.
    """

    def test_llama_adapter_declares_conversational_interface(self):
        from trx_ai.trx_model.llama_cpp_adapter import LlamaCppModelAdapter
        from trx_ai.trx_model.interfaces import ConversationalModelInterface

        fd, path = tempfile.mkstemp(suffix=".gguf")
        os.close(fd)
        with open(path, "wb") as f:
            f.write(b"fake")
        try:
            adapter = LlamaCppModelAdapter(model_path=path, llama_factory=FakeLlama)
            self.assertIsInstance(adapter, ConversationalModelInterface)
        finally:
            os.unlink(path)

    def test_bridge_refuses_adapter_without_chat_capability(self):
        """
        یک Adapterِ جعلی که فقط ``ModelInterface`` (بدونِ ``chat``) را
        پیاده می‌کند نباید باعثِ کرش بشه -- باید تمیز None برگرده.
        """
        from trx_ai.trx_model import conversational_bridge
        from trx_ai.trx_model.interfaces import ModelInterface

        class GenerateOnlyAdapter(ModelInterface):
            def encode(self, text):
                return [1]

            def decode(self, ids):
                return "x"

            def generate(self, prompt, max_new_tokens=32, **kwargs):
                return "بدونِ chat"

        conversational_bridge.reset_for_tests()
        env_backup = dict(os.environ)
        os.environ["TRX_LOCAL_LLM_ENABLED"] = "true"
        conversational_bridge._adapter_instance = GenerateOnlyAdapter()
        try:
            result = conversational_bridge.try_generate_reply("سلام")
            self.assertIsNone(result)
        finally:
            os.environ.clear()
            os.environ.update(env_backup)
            conversational_bridge.reset_for_tests()


class BuildHistoryFromDbTests(unittest.TestCase):
    """رفعِ ایرادِ ۲۰۲۶-۰۹-۲۰: تاریخچه‌ی واقعی، نه ``None``."""

    class FakeDBWithHistory:
        def get_recent_history(self, limit=6):
            # DESC از دیتابیسِ واقعی -- جدیدترین اول
            return [
                (3, "پایتختش چی بود؟", "تخت‌جمشید / پاسارگاد بسته به دوره."),
                (2, "کوروش کبیر کی بود؟", "بنیان‌گذارِ هخامنشی."),
            ]

    def test_returns_chronological_role_content_pairs(self):
        from trx_ai.trx_model.conversational_bridge import build_history_from_db

        pairs = build_history_from_db(self.FakeDBWithHistory())
        self.assertEqual(
            pairs,
            [
                ("user", "کوروش کبیر کی بود؟"),
                ("assistant", "بنیان‌گذارِ هخامنشی."),
                ("user", "پایتختش چی بود؟"),
                ("assistant", "تخت‌جمشید / پاسارگاد بسته به دوره."),
            ],
        )

    def test_missing_get_recent_history_returns_empty_not_crash(self):
        from trx_ai.trx_model.conversational_bridge import build_history_from_db

        class NoHistoryDB:
            pass

        self.assertEqual(build_history_from_db(NoHistoryDB()), [])
        self.assertEqual(build_history_from_db(None), [])

    def test_try_generate_reply_uses_real_history_when_db_given(self):
        import trx_ai.trx_model.llama_cpp_adapter as llama_cpp_adapter_mod
        from trx_ai.trx_model import conversational_bridge

        conversational_bridge.reset_for_tests()
        env_backup = dict(os.environ)
        os.environ["TRX_LOCAL_LLM_ENABLED"] = "true"
        os.environ["TRX_LOCAL_LLM_MODEL_PATH"] = __file__
        original = llama_cpp_adapter_mod.LlamaCppModelAdapter

        def _patched(model_path, **kwargs):
            return original(model_path=model_path, llama_factory=FakeLlama)

        llama_cpp_adapter_mod.LlamaCppModelAdapter = _patched
        try:
            conversational_bridge.try_generate_reply(
                "خب حالا زمانِ فرمانرواییش؟", db=self.FakeDBWithHistory()
            )
            adapter = conversational_bridge._adapter_instance
            sent_messages = adapter._llama.calls[0][0]
            # system + ۲ ردیفِ تاریخچه (هرکدام user+assistant) + پیامِ جاری
            roles_in_order = [m["role"] for m in sent_messages]
            self.assertEqual(
                roles_in_order,
                ["system", "user", "assistant", "user", "assistant", "user"],
            )
            self.assertEqual(sent_messages[-1]["content"], "خب حالا زمانِ فرمانرواییش؟")
            self.assertEqual(sent_messages[1]["content"], "کوروش کبیر کی بود؟")
            self.assertEqual(sent_messages[3]["content"], "پایتختش چی بود؟")
        finally:
            llama_cpp_adapter_mod.LlamaCppModelAdapter = original
            os.environ.clear()
            os.environ.update(env_backup)
            conversational_bridge.reset_for_tests()


if __name__ == "__main__":
    unittest.main()
