# -*- coding: utf-8 -*-
"""
پیکربندی مشترک تست‌ها: مسیر ریشه‌ی پروژه (پوشه‌ی بالاترِ trx_ai/) را به
sys.path اضافه می‌کند تا صرف‌نظر از اینکه pytest از کجا اجرا می‌شود،
`import trx_ai...` همیشه کار کند.
"""

import os
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)
