# -*- coding: utf-8 -*-
"""
تستِ رگرسیونِ باگِ ۲۰۲۶-۰۹-۲۰: «سقفِ فازیِ ۰.۳» تصحیحِ صریحِ کاربر را
هم سقف می‌زد -- نگاه کنید به ``BUGFIX_v25_5_2_FEEDBACK_FUZZY_CAP.md``
برایِ شرحِ کامل.

سه تست، دقیقاً همان الگویِ ``test_general_fallback_memory_leak_regression.py``:
    ۱) تستِ واحدِ intent_candidates: بعدِ ثبتِ یک تصحیح، همان نیت دیگر
       سقف نمی‌خورد و شاهدِ آن matcher=feedback است.
    ۲) تستِ end-to-end رویِ خودِ conversation_engine.process: قبل از
       تصحیح مبهم می‌ماند (طبیعی)، بعد از تصحیح دقیقاً همان نیتِ
       تصحیح‌شده را برمی‌گرداند -- یعنی «یاد گرفتم» واقعاً اثر دارد.
    ۳) تستِ عدمِ رگرسیون: مثالِ واقعیِ «اما واقعاً خوشحالم» (تطبیقِ
       فازیِ تصادفیِ «اما»≈«دما») هنوز هم سقف می‌خورد -- یعنی این رفع
       محافظِ اصلی را ضعیف نکرده، فقط یک استثنایِ دقیق اضافه کرده.

بدونِ pytest واقعی در این محیط (طبقِ محدودیتِ شناخته‌شده‌ی sandbox)؛
با ``unittest`` استاندارد نوشته شده تا مستقیماً با
``python3 -m unittest`` هم قابلِ اجرا باشد.
"""

from __future__ import annotations

import sys
import unittest


class FakeDB:
    def __init__(self):
        self._corrections: list[tuple[str, str]] = []

    def record_intent_correction(self, text, intent):
        self._corrections.append((text, intent))
        return True

    def get_intent_corrections(self, limit=200):
        return self._corrections


class FeedbackCorrectionNotFuzzyCappedTests(unittest.TestCase):
    def setUp(self):
        from trx_ai.conversation import intent_candidates, emotion_analyzer
        from trx_ai.nlu import feedback

        self.intent_candidates = intent_candidates
        self.emotion_analyzer = emotion_analyzer
        self.feedback = feedback
        self.query = "چی درمورد کوروش کبیر میدونی"

    def _candidates_for(self, text, db):
        emo = self.emotion_analyzer.analyze(
            text, context_text="", previous_emotion=None, db=db
        ).value
        return self.intent_candidates.generate(
            text, emotion=emo, context_modes=None, db=db
        ).value

    def test_corrected_intent_is_not_capped_after_feedback(self):
        db = FakeDB()
        self.feedback.record_correction(self.query, "web_search", db)

        candidates = self._candidates_for(self.query, db)
        web_search = next((c for c in candidates if c.name == "web_search"), None)

        self.assertIsNotNone(web_search, "web_search باید به‌عنوانِ نامزد ظاهر شود")
        self.assertGreaterEqual(
            web_search.score, 0.55,
            "امتیازِ نامزدِ تصحیح‌شده نباید به ۰.۳ سقف بخورد",
        )
        self.assertTrue(
            any(e.startswith("feedback:") for e in web_search.evidence),
            "شاهدِ نامزد باید نشان بدهد از تصحیحِ کاربر آمده، نه فازیِ تصادفی",
        )
        self.assertNotIn("fuzzy_only", web_search.evidence)

    def test_end_to_end_conversation_engine_uses_the_correction(self):
        from trx_ai.conversation import conversation_engine, state_tracker

        db = FakeDB()
        conversation_id = "test-conversation-feedback-fix"
        state_tracker.reset_snapshot(conversation_id)
        # شبیه‌سازیِ همان چیزی که در گفتگویِ واقعیِ کاربر افتاد: یک
        # موضوعِ قبلی (کارهام) که هنوز در state باقی مانده.
        state_tracker.update_snapshot(conversation_id, active_topic="کارهام")

        before = conversation_engine.process(
            self.query, conversation_id=conversation_id, context_modes=None,
            db=db, recent_messages=[], topic_hint=None,
        )
        self.assertIsNotNone(before)
        intent_before, _confidence_before, _ = before
        # قبل از تصحیح، مبهم‌ماندن (conversation_follow_up) رفتارِ
        # طبیعی و درستی‌ست -- این تست ادعا نمی‌کند این حالت باگ است.
        self.assertEqual(intent_before, "conversation_follow_up")

        self.feedback.record_correction(self.query, "web_search", db)

        after = conversation_engine.process(
            self.query, conversation_id=conversation_id, context_modes=None,
            db=db, recent_messages=[], topic_hint=None,
        )
        self.assertIsNotNone(after)
        intent_after, confidence_after, _ = after
        self.assertEqual(
            intent_after, "web_search",
            "بعدِ ثبتِ تصحیح، همان پیامِ دقیقاً یکسان باید به نیتِ "
            "تصحیح‌شده برود -- نه دوباره conversation_follow_up",
        )
        self.assertGreaterEqual(confidence_after, 0.55)

        state_tracker.reset_snapshot(conversation_id)

    def test_genuine_fuzzy_match_is_still_capped_no_regression(self):
        # مثالِ واقعیِ مستندشده در خودِ intent_candidates.py: «اما»≈«دما».
        db = None
        candidates = self._candidates_for("اما واقعاً خوشحالم", db)
        weather = next((c for c in candidates if c.name == "weather"), None)
        self.assertIsNotNone(weather, "نامزدِ فازیِ weather باید هنوز تولید شود")
        self.assertLessEqual(
            weather.score, 0.3,
            "تطبیقِ فازیِ واقعی (بدونِ تصحیحِ کاربر) باید هنوز سقف بخورد",
        )
        self.assertIn("fuzzy_only", weather.evidence)


if __name__ == "__main__":
    # اجازه می‌دهد فایل مستقیم با ``python3 tests/test_....py`` هم اجرا
    # شود، نه فقط با discovery.
    sys.path.insert(0, ".")
    unittest.main()
