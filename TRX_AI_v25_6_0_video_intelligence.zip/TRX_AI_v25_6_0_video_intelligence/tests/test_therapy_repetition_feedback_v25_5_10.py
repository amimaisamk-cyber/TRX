"""
v25.5.10 -- بازخوردِ کاربر درباره‌ی تکراری‌بودنِ پاسخ‌هایِ Therapy
Companion باید صادقانه پذیرفته شود، نه با یک بازتابِ کلیشه‌ایِ دیگر
جواب داده شود؛ و پاسخ‌هایِ پیاپی نباید بدونِ دلیل عیناً تکرار شوند.
"""

from trx_ai.medical.therapy.engine import TherapyCompanionEngine
from trx_ai.medical.therapy import emotions


# ----------------------------------------------------------------------
# emotions.is_repetition_feedback -- تشخیصِ خودِ الگو
# ----------------------------------------------------------------------

def test_real_reported_sentence_is_detected_as_repetition_feedback():
    text = "این حرف‌ها رو دقیقاً به همین ترتیب قبلاً ازت شنیدم"
    assert emotions.is_repetition_feedback(text) is True


def test_direct_repetition_complaint_phrases_are_detected():
    for text in (
        "تکراری شد",
        "همیشه همینو میگی",
        "داری تکرار می‌کنی",
    ):
        assert emotions.is_repetition_feedback(text) is True, text


def test_past_marker_plus_second_person_verb_combo_is_detected():
    assert emotions.is_repetition_feedback("همینو قبلاً بهم گفتی") is True


def test_unrelated_past_tense_about_third_party_is_not_misdetected():
    """«قبلاً بهش گفتم» به شخصِ سوم اشاره دارد (فعلِ اول‌شخص)، نه به
    TRX -- نباید به‌غلط بازخوردِ تکرار تشخیص داده شود، وگرنه وسطِ
    افشایِ یک تجربه‌ی حساس یک پاسخِ نامربوط می‌دهیم."""
    text = "قبلاً بهش گفتم که دیگه نمیخوام باهاش باشم"
    assert emotions.is_repetition_feedback(text) is False


def test_ordinary_distress_message_is_not_misdetected():
    assert emotions.is_repetition_feedback("امروز خیلی ناراحتم و دلم گرفته") is False


def test_plain_past_reference_without_repeat_verb_is_not_misdetected():
    assert emotions.is_repetition_feedback("قبلاً یه بار این اتفاق برام افتاده بود") is False


# ----------------------------------------------------------------------
# TherapyCompanionEngine.respond -- رفتارِ کاملِ موتور
# ----------------------------------------------------------------------

def test_repetition_feedback_gets_acknowledgment_not_generic_reflection():
    eng = TherapyCompanionEngine()
    eng.respond("rep1", "امروز خیلی ناراحتم")
    r = eng.respond("rep1", "این حرف‌ها رو دقیقاً به همین ترتیب قبلاً ازت شنیدم")
    assert r["status"] == "ok"
    assert r["emergency"] is False
    # نباید بازتابِ کلیشه‌ایِ معمولی («شنیدمت.»/«متوجه‌ام.») باشد
    assert "شنیدمت" not in r["message"]
    assert "حق داری" in r["message"] or "راست می" in r["message"]


def test_repetition_feedback_does_not_trigger_crisis_or_emergency():
    eng = TherapyCompanionEngine()
    r = eng.respond("rep2", "این حرف‌ها رو قبلاً ازت شنیدم")
    assert r["status"] != "crisis"
    assert r["emergency"] is False


def test_repetition_feedback_still_advances_session_stage():
    """چک می‌کنیم که مسیرِ جدید از ثبتِ نوبت (record_turn) جا نمونده --
    وگرنه session.stage هیچ‌وقت پیش نمی‌رود."""
    eng = TherapyCompanionEngine()
    session = eng.sessions.get("rep3")
    turns_before = session.turn_count
    eng.respond("rep3", "این حرف‌ها رو قبلاً ازت شنیدم")
    assert session.turn_count == turns_before + 1


# ----------------------------------------------------------------------
# جلوگیری از تکرارِ فوریِ همان جمله در نوبت‌هایِ پیاپی
# ----------------------------------------------------------------------

def test_consecutive_neutral_reflections_do_not_repeat_immediately():
    """استخرِ neutral فقط ۲ عضو دارد؛ با last_used درست وصل‌شده، هیچ‌وقت
    دو نوبتِ پشت‌سرهم عیناً یک جمله تکرار نمی‌شود (قطعی، نه آماری)."""
    eng = TherapyCompanionEngine()
    first = eng.respond("dup1", "سلام چطوری")
    second = eng.respond("dup1", "خب دیگه چی بگم")
    assert first["message"] != second["message"]


def test_session_tracks_last_reflection_and_question():
    eng = TherapyCompanionEngine()
    session = eng.sessions.get("dup2")
    eng.respond("dup2", "خیلی ناراحتم")
    assert session.last_reflection is not None
    assert session.last_question is not None
