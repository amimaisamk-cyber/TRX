# -*- coding: utf-8 -*-
"""
تست‌های واحد برایِ ۵ قابلیتِ جدید: پشتیبان‌گیری/بازیابی، خرج‌ها، تبدیلِ
واحد، تولیدِ رمزِ عبور، BMI.
"""

import pytest

pytest.importorskip("aiohttp", reason="نیازمندِ aiohttp (طبق requirements.txt)")
pytest.importorskip("bs4", reason="نیازمندِ beautifulsoup4 (طبق requirements.txt)")

from trx_ai.database import DatabaseManager
from trx_ai.expenses import ExpenseManager
from trx_ai.health_utils import HealthCalculator, PasswordGenerator, UnitConverter


@pytest.fixture()
def db(tmp_path):
    return DatabaseManager(str(tmp_path / "test.db"))


# ---------------------------------------------------------------------------
#   خرج‌ها
# ---------------------------------------------------------------------------
def test_expense_add_from_text_extracts_amount_and_category(db):
    em = ExpenseManager(db)
    result = em.add_from_text("خرج کردم ۵۰ هزار تومان برای نهار")
    assert result["amount"] == 50_000
    assert result["category"] == "غذا"


def test_expense_summary_reports_correct_total(db):
    em = ExpenseManager(db)
    em.add_from_text("خرج کردم ۵۰ هزار تومان برای نهار")
    em.add_from_text("۲۰۰ هزار تومان بابت تاکسی")
    summary = em.format_summary()
    assert "250" in summary.replace("٬", "")


def test_expense_add_without_amount_returns_none():
    em = ExpenseManager(db=None)
    result = em.add_from_text("سلام چطوری")
    assert result["amount"] is None


# ---------------------------------------------------------------------------
#   پشتیبان‌گیری/بازیابی
# ---------------------------------------------------------------------------
def test_backup_and_restore_round_trip(db, tmp_path):
    db.set_profile("user_name", "علی")
    em = ExpenseManager(db)
    em.add_from_text("خرج کردم ۱۰۰ هزار تومان برای خرید")

    exported = db.export_all_data()
    assert exported["profile"]
    assert len(exported["expenses"]) == 1

    db2 = DatabaseManager(str(tmp_path / "restored.db"))
    imported_count = db2.import_all_data(exported)
    assert imported_count > 0
    assert db2.get_profile("user_name") == "علی"
    assert len(db2.list_expenses()) == 1


# ---------------------------------------------------------------------------
#   تبدیلِ واحد
# ---------------------------------------------------------------------------
def test_unit_converter_length():
    result = UnitConverter.convert_from_text("۱۰ کیلومتر به مایل")
    assert "مایل" in result and "❌" not in result


def test_unit_converter_temperature():
    result = UnitConverter.convert_from_text("۱۰۰ سانتیگراد به فارنهایت")
    assert "212" in result


# ---------------------------------------------------------------------------
#   تولیدِ رمزِ عبور
# ---------------------------------------------------------------------------
def test_password_generator_produces_strong_password():
    result = PasswordGenerator.generate_from_text("رمز عبور قوی بساز")
    # استخراجِ خودِ رمز از داخلِ بک‌تیک‌ها در پیام
    import re
    match = re.search(r'`([^`]+)`', result)
    assert match, "رمز عبور در خروجی پیدا نشد"
    password = match.group(1)
    assert len(password) >= 8
    assert any(c.islower() for c in password)
    assert any(c.isupper() for c in password)
    assert any(c.isdigit() for c in password)


def test_password_generator_produces_different_passwords_each_time():
    p1 = PasswordGenerator.generate_from_text("رمز عبور بساز")
    p2 = PasswordGenerator.generate_from_text("رمز عبور بساز")
    assert p1 != p2


# ---------------------------------------------------------------------------
#   BMI
# ---------------------------------------------------------------------------
def test_bmi_calculates_correct_category():
    result = HealthCalculator.calculate_from_text("bmi من چنده وزنم ۷۰ قدم ۱۷۵")
    assert "22.9" in result or "22٫9" in result
    assert "طبیعی" in result


@pytest.mark.parametrize("text", [
    "bmi من چنده وزنم ۷۰ قدم ۱۷۵",
    "من ۷۰ کیلو وزن دارم و قدم ۱۷۵ سانته",   # عدد قبل از کلمه (باگِ قبلی)
    "وزنم: ۷۰ و قدم: ۱۷۵",                     # علامتِ نگارشی بینِ کلمه و عدد (باگِ قبلی)
    "قدم ۱۷۵ و وزنم ۷۰",                       # ترتیبِ معکوس
])
def test_bmi_parses_various_natural_phrasings(text):
    """رگرسیون برایِ باگِ گزارش‌شده: قبلاً فقط الگویِ 'وزن ۷۰' (عدد بلافاصله بعد از کلمه) کار می‌کرد."""
    result = HealthCalculator.calculate_from_text(text)
    assert "❌" not in result
    assert "22.9" in result


def test_bmi_rejects_unreasonable_values():
    result = HealthCalculator.calculate_from_text("وزنم ۷۰۰۰ قدم ۱۷۵")
    assert "❌" in result


def test_bmi_output_includes_disclaimer_not_diagnosis():
    result = HealthCalculator.calculate_from_text("bmi من چنده وزنم ۷۰ قدم ۱۷۵")
    assert "تشخیص" in result  # باید صراحتاً بگوید این تشخیصِ پزشکی نیست
