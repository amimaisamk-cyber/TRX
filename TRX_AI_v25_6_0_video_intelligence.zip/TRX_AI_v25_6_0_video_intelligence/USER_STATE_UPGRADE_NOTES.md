# User State + Conversation Phase + Response Strategy -- یادداشتِ ارتقا

پیاده‌سازیِ کاملِ سندِ «TRX AI — USER STATE & CONVERSATIONAL UNDERSTANDING
UPGRADE». سه محورِ کاملاً مستقل، بدونِ حذف/بازنویسیِ چیزی از معماریِ
قبلی (Intent Engine، NLU pipeline، Conversation Pattern Engine همه
دست‌نخورده‌اند).

## فایل‌هایِ جدید

- `trx_ai/nlu/user_state_types.py` -- `UserStateSpec` / `StateHit` /
  `SingleState` / `UserStateResult`.
- `trx_ai/nlu/user_state_registry.py` -- تعریفِ ۱۴ حالتِ پایه (بخشِ ۴).
- `trx_ai/nlu/user_state.py` -- موتورِ تشخیص (کلیدواژه → مترادف → فازی
  → معنایی → زمینه → fusion → اطمینان/ابهام)، `UserStateSessionMemory`
  (بخشِ ۱۹: state با TTL، جدا از حافظه‌ی دائمی)، و یادگیریِ بازخورد
  (بخشِ ۲۰: `record_state_correction`).
- `trx_ai/nlu/conversation_phase.py` -- تشخیصِ مرحله‌یِ مکالمه (بخشِ ۱۲)
  + پالایشِ `repeated_failure`.
- `trx_ai/response_strategy.py` -- نگاشتِ حالت+مرحله → راهبردِ پاسخ
  (بخشِ ۱۳/۱۴) + `reply_hint()` (جمله‌هایِ کوتاهِ آفلاین).
- `trx_ai/understanding.py` -- `build_understanding()`: ساختارِ
  `ConversationUnderstanding` (بخشِ ۳۳)، فقط برایِ صدازننده‌هایی که
  می‌خواهند همه‌چیز را یک‌جا داشته باشند (اختیاری -- core.py مستقیماً
  از موتورهایِ زیرین استفاده می‌کند، نه از این تابع).

## چه چیزی در فایل‌هایِ قدیمی تغییر کرد

- `conversation_patterns.py`: `build_pattern` / `_utterance_pattern` /
  `observe` یک پارامترِ اختیاریِ `user_state=None` گرفتند؛ `signature()`
  این فیلد را هم به امضا اضافه می‌کند (پیش‌فرض `"unknown"` برایِ
  داده‌یِ قدیمی -- بدونِ رگرسیون، بخشِ ۱۰).
- `core.py`:
  - `self.user_state_memory = UserStateSessionMemory()` در `__init__`.
  - `_finalize()`: هر نوبت وضعیتِ کاربر تشخیص داده و هم در
    `user_state_memory` هم در `conversation_patterns.observe(...,
    user_state=...)` ثبت می‌شود.
  - لایه‌ی ۴ (fallback کاملاً محلیِ `_execute_route`): اگر
    `conversation_patterns.local_empathetic_reply` چیزی نداشت (چون
    تاکسونومیِ قدیمی‌اش فقط sad/angry/anxious/confused/happy/excited/
    hopeful/grateful را می‌شناسد)، قبل از سقوط به پیامِ رباتیِ عمومی،
    موتورِ User State + Phase + Strategy امتحان می‌شود -- برایِ
    tired/frustrated/disengaged/bored/curious/stressed/satisfied/
    dissatisfied که تاکسونومیِ قدیمی برایشان چیزی نداشت.

## نکته‌هایِ طراحیِ مهم (برایِ توسعه‌ی بعدی)

- **دو تاکسونومیِ emotion عمداً جدا مانده‌اند**: `conversation_patterns`
  خودش (sad/angry/anxious/...) و `user_state` (tired/frustrated/...).
  ادغام‌شان اشتباه است -- اولی رویِ *معناشناسیِ الگو* (strategy/topic)
  کار می‌کند، دومی رویِ *لحنِ لحظه‌ای*. اگر لازم شد این دو را نزدیک‌تر
  کنید، از طریقِ ``user_state`` فیلدِ اضافه‌ای که به pattern اضافه شده
  استفاده کنید، نه با ادغامِ خودِ enumها.
- **CONTEXT_WEIGHT** (در `user_state.py`) عمداً محافظه‌کارانه (۰.۳)
  نگه داشته شده: زمینه باید بتواند سیگنالِ جدید اضافه کند (مثالِ
  دیباگِ چندنوبتی)، اما نباید یک پیامِ فعلیِ کاملاً واضح را با
  حالتِ نامرتبطِ نوبتِ قبلی «نامطمئن» کند. اگر لازم شد بالاتر ببرید،
  حتماً با یک سناریویِ دو-نوبتیِ نامرتبط (نه فقط سناریوهایِ هم‌راستا)
  دوباره تست کنید.
- **بدونِ فایلِ eval/dataset رسمی** (بخشِ ۳۰ سند) -- قدمِ بعدیِ
  پیشنهادی، نه انجام‌شده: یک `dataset/user_state.json` مشابهِ
  ساختارِ evalِ نیت‌ها.
- **Multi-Intent/Disambiguator** (بخش‌هایِ ۲۵/۲۶): این پیاده‌سازی به
  آن‌ها دست نزده -- `user_state` کاملاً موازی و بدونِ اثر رویِ
  Intent/Disambiguation فعلی اجرا می‌شود.
