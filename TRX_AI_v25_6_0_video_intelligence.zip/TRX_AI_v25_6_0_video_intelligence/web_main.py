# -*- coding: utf-8 -*-
"""
نقطه‌ی ورودِ رابطِ کاربریِ وب (جایگزینِ HTML/JS برایِ gui_main.py/PySide6).

اجرا:
    python web_main.py
    (سپس مرورگر خودکار باز می‌شود؛ اگر نشد، به http://127.0.0.1:8765 بروید)

چرا این رابط، نه gui_main.py:
    این نسخه هیچ وابستگیِ گرافیکیِ کامپایل‌شده‌ای (PySide6/Qt) ندارد —
    فقط از aiohttp استفاده می‌کند که از قبل CORE پروژه است. رویِ
    Pydroid3/Termux/اندروید که PySide6 معمولاً نصب نمی‌شود، این تنها
    رابطِ گرافیکیِ کاملاً کارکردنی است. رابطِ آن هم در مرورگرِ خودِ
    دستگاه باز می‌شود، پس هیچ‌چیزِ جدیدی لازم نیست نصب شود.

متغیرهای محیطیِ مفید:
    TRX_WEB_HOST=0.0.0.0  برایِ دسترسی از دستگاه‌هایِ دیگرِ همان شبکه
                           (پیش‌فرض فقط 127.0.0.1، یعنی فقط همین دستگاه)
    TRX_WEB_PORT=8765     تغییرِ پورت
    TRX_NO_BROWSER=1      باز نکردنِ خودکارِ مرورگر
"""

from __future__ import annotations

import os
import sys


def _ensure_project_root_on_path() -> None:
    """
    توضیحِ کامل در main.py._ensure_project_root_on_path. خلاصه: بعضی
    اجراکننده‌ها (مثلِ Pydroid3 روی اندروید که فایل را با exec() اجرا
    می‌کند) پوشه‌ی محتویِ اسکریپت را خودکار به sys.path اضافه نمی‌کنند
    و بدونِ این تابع خطایِ زیر رخ می‌دهد:
        ModuleNotFoundError: No module named 'trx_ai.dependencies';
        'trx_ai' is not a package
    """
    candidates = []
    file_path = globals().get("__file__")
    if file_path:
        candidates.append(os.path.dirname(os.path.abspath(file_path)))
    if sys.argv and sys.argv[0]:
        candidates.append(os.path.dirname(os.path.abspath(sys.argv[0])))
    candidates.append(os.getcwd())

    for base in candidates:
        if base and os.path.isdir(os.path.join(base, "trx_ai")) and base not in sys.path:
            sys.path.insert(0, base)
            return


_ensure_project_root_on_path()

from trx_ai.dependencies import ensure_required_packages  # noqa: E402  (باید بعد از بوت‌استرپِ مسیر باشد)

# پکیج‌های ضروری (rich، aiohttp، edge_tts و ...) — همان‌هایی که
# main.py/gui_main.py هم نیاز دارند. نکته: PySide6 اینجا لازم نیست،
# چون این رابط از Qt استفاده نمی‌کند.
ensure_required_packages()

from trx_ai import webserver  # noqa: E402


def main() -> None:
    host = os.environ.get("TRX_WEB_HOST", "127.0.0.1")
    port = int(os.environ.get("TRX_WEB_PORT", "8765"))
    open_browser = os.environ.get("TRX_NO_BROWSER", "") != "1"
    try:
        webserver.run(host=host, port=port, open_browser=open_browser)
    except KeyboardInterrupt:
        print("\n👋 سرور متوقف شد.")


if __name__ == "__main__":
    main()
