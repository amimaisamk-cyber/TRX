# فاز ۳ — مرحله‌ی ۱: schemas + config + feature_builder

**نسخه:** v25.4.7
**سند مرجع:** `TRX_AI_Phase3_Native_Neural_Cognitive_Layer_Complete_Design.txt` (نسخه‌ی طراحی P3.0)
**مرحله:** ۱ از ۱۰ (بخشِ ۱۹ سند)

## هدف این مرحله

طبقِ متنِ صریحِ سند:

> مرحله ۱: ساخت schemas / ساخت config / ساخت feature builder / بدون اتصال واقعی به Core

این نسخه دقیقاً همین محدوده را پیاده کرده -- نه یک کلمه بیشتر. مراحلِ
۲ تا ۱۰ (اتصالِ `neural_adapter.py` به `trx_model`، `inference_service.py`،
Shadow Mode، Fusion Engine، Draft Generation، Controlled Production)
عمداً ساخته نشده‌اند.

## چرا این ترتیب

طبقِ قانونِ اصلیِ خودِ پروژه («اول معماری را جدا می‌کنیم، بعد
قابلیت‌های جدید اضافه می‌کنیم») و اصلِ غیرقابلِ‌مذاکره‌ی ۳ سندِ فاز ۳
(«Core نباید به مدل وابستگیِ سخت داشته باشد»)، ساختنِ قراردادهایِ
داده و تنظیمات پیش از هر خطِ کدِ inference یعنی:

- بقیه‌ی فاز ۳ (از مرحله‌ی ۲ به بعد) به یک زبانِ مشترکِ ثابت وصل
  می‌شود، نه به جزئیاتِ پیاده‌سازیِ در حالِ تغییر.
- تا رسیدن به Shadow Mode (مرحله‌ی ۴)، هیچ رفتارِ زنده‌ای در معرضِ
  ریسک نیست -- چون چیزی برای اجرا وجود ندارد، فقط دیتاکلاس و تابعِ
  خالص.

## چیزی که ساخته شد

| فایل | مسئولیت | متناظر با بخشِ سند |
|---|---|---|
| `trx_ai/phase3/schemas.py` | `NeuralAdvice`، `FusionDecision`، `NeuralInputFeatures`، `DiscourseRelation`، `ResponseMode`، `DecisionSource` | بخش‌هایِ ۵.۲، ۵.۶، ۷، ۸ |
| `trx_ai/phase3/config.py` | `Phase3Config` (frozen) + `get_config()` env-driven، شش `Phase3Mode`، `ALL_TASKS` | بخشِ ۶ (config.py) و ۱۱ (حالت‌های اجرا) |
| `trx_ai/phase3/feature_builder.py` | `build_features()` -- تبدیلِ `ContextSnapshot` موجود + تاریخچه به `NeuralInputFeatures` محدودشده | بخشِ ۶ (feature_builder.py) |
| `trx_ai/phase3/tests/test_phase3_foundation.py` | ۲۶ تستِ واحد | -- |

## تصمیم‌هایِ طراحیِ مهم

### ۱. پیش‌فرضِ config همیشه خاموش است

بر خلافِ `trx_ai/conversation/config.py` (که پیش‌فرضش `True` است چون
آن سامانه از قبل تکمیل و تأیید شده)، اینجا `Phase3Config.enabled`
پیش‌فرض `False` و `mode` پیش‌فرض `DISABLED` است -- چون `neural_adapter.py`
هنوز اصلاً وجود ندارد؛ `enabled=True` بدونِ آن، دروغی در تنظیمات
می‌بود. `get_config()` هرگز بر اساسِ یک رشته‌ی نامعتبر یا نبودِ
`neural_adapter` crash نمی‌کند -- همیشه به `DISABLED` سقوط می‌کند.

### ۲. `DiscourseRelation` جدا از `TopicRelation` موجود

`trx_ai/conversation/schemas.py` از قبل یک `TopicRelation` symbolic
دارد. سندِ فاز ۳ یک enum کمی متفاوت می‌خواهد (با یک عضوِ اضافه:
`emotional_update`). به‌جایِ دستکاریِ enumِ موجود (که یک فایلِ فعال و
تست‌شده است) یا کپی‌کاریِ بی‌قاعده، یک enum جدا با نگاشتِ کاملاً
مستندشده در docstring ساخته شد -- `fusion_engine.py` (مرحله‌ی ۶) وقتی
ساخته شود، این نگاشت را آماده پیدا می‌کند و دوباره طراحی نمی‌کند.

### ۳. `feature_builder.build_features` هیچ importی از trx_model ندارد

عمداً. این تابع فقط `trx_ai.conversation.schemas` را می‌خواند (منبعِ
واحدِ حقیقتِ context، طبقِ اصلِ سند «فاز ۳ نباید Context Manager
مستقل بسازد») و هیچ وابستگی به مدل/tokenizer ندارد -- یعنی مرحله‌ی ۲
(اتصالِ `neural_adapter`) می‌تواند این تابع را به‌عنوانِ یک لایه‌ی
کاملاً مستقل و از قبل تست‌شده مصرف کند.

### ۴. تست‌ها با `unittest`، نه `pytest`

sandbox این نشست شبکه ندارد و `pytest` نصب نیست (`pip install pytest`
با خطایِ «No matching distribution» شکست خورد -- شواهد در همین
نشست). چون این ماژول‌ها فقط دیتاکلاس و تابعِ خالص‌اند و به هیچ
fixture/async‌ای نیاز ندارند، به‌جایِ ساختنِ shim یا فرض‌کردنِ محیطِ
توسعه‌ی کاربر، از `unittest` استاندارد (همیشه در دسترس) استفاده شد --
تا خودِ اثباتِ این مرحله هم به ابزارِ نصب‌نشده وابسته نباشد.

## اعتبارسنجی

```
$ python3 -m unittest trx_ai.phase3.tests.test_phase3_foundation -v
...
Ran 26 tests in 0.002s
OK
```

بررسیِ جداگانه‌ی «صفر وابستگیِ جدید»:

```python
import trx_ai
import trx_ai.conversation.schemas as cs
import trx_ai.phase3 as p3
# موفق -- بدونِ نیاز به aiohttp که زنجیره‌ی
# trx_ai.conversation.conversation_engine به آن نیاز دارد.
```

## چیزی که این نسخه *نیست*

- بدونِ `neural_adapter.py` -- هیچ اتصالی به `trx_ai/trx_model/` وجود ندارد.
- بدونِ `inference_service.py`، `fusion_engine.py`، `policy_bridge.py`، `draft_generator.py`، `latency_guard.py`، `fallback.py`، `telemetry.py`، `versioning.py` -- همه‌یِ این‌ها بخشِ مراحلِ ۲ تا ۸ سند هستند.
- بدونِ `advice_validator.py` -- اعتبارسنجیِ واقعیِ خروجیِ مدل (بازه‌ی confidence، NaN/Inf) هنوز پیاده نشده؛ `NeuralAdvice`/`FusionDecision` فعلاً فقط شکلِ داده‌اند، دقیقاً مثلِ فلسفه‌ی `conversation/schemas.py`.
- بدونِ هیچ تغییری در `core.py`، `intelligence.py`، یا `trx_ai/conversation/*` -- صفر ریسکِ رگرسیون برایِ رفتارِ زنده‌ی فعلی.

## گامِ بعدی (مرحله‌ی ۲ سند)

طبقِ بخشِ ۱۹: «اتصالِ Neural Adapter به `trx_model` / فقط inference
آزمایشی / تستِ load/unload / تستِ سازگاریِ tokenizer/model». این باید
جداگانه و با تأییدِ صریح شروع شود -- طبقِ قانونِ «STOP → UNDERSTAND →
CHECK ARCHITECTURE → ... » پیش از هر تغییرِ بعدی.
