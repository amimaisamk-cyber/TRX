# PHASE 1 — Reality Audit — v25.5.5

این سند طبقِ قالبِ دقیقِ `TRX_AI_v25_5_5_Nervous_System_Engineering_Plan.txt`
(بخشِ PHASE 1) پر شده -- برایِ هر ماژولِ عصبیِ *موجود* که در مسیرِ واقعیِ
`conversation_engine.process()` اجرا می‌شود. آزمونِ هر ردیف همان سؤالِ
سند است: «اگر خروجیِ این ماژول را حذف کنم، رفتار TRX تغییر می‌کند؟»

روشِ ارزیابی: خواندنِ واقعیِ `conversation_engine.py` (نقطه‌ی ورودیِ
یگانه‌ی پکیج -- طبقِ کامنتِ بالایِ خودِ آن فایل) و ردیابیِ اینکه خروجیِ
هر ماژول *واقعاً* در یک شاخه/تصمیم/state-update بعدی استفاده می‌شود یا
فقط لاگ می‌شود.

---

### normalizer
- path: `trx_ai/conversation/normalizer.py`
- status: LIVE
- inputs: raw_text
- outputs: MessageRecord (normalized_text)
- consumers: تقریباً همه‌ی ماژول‌هایِ بعدی (`normalized_text` ورودیِ topic_tracker، continuity_analyzer، ambiguity_manager)
- tests: دارد (تست‌هایِ conversation/tests)
- influence: **FUNCTIONAL**
- reason_to_keep: اگر `normalized_text` خالی باشد، `process()` مستقیماً `None` برمی‌گرداند (سطر ۱۲۷-۱۲۸) -- تغییرِ مستقیم در مسیر.

### context_manager
- path: `trx_ai/conversation/context_manager.py`
- status: LIVE
- inputs: recent_messages, snapshot, long_term_snippets
- outputs: ContextBundle
- consumers: این نسخه (v25.5.5) -- `bundle.long_term` حالا مصرف‌کننده‌ی جدید دارد: `NervousSystemCoordinator.build_context` (memory_context). پیش از این نسخه، `bundle.recent` مصرف‌کننده‌ی مستقیم نداشت (فقط به continuity_analyzer/response_planner پاس داده می‌شد که خودشان از آن استفاده نمی‌کردند -- نگاه کنید به ردیفِ response_planner).
- tests: دارد
- influence: **FUNCTIONAL** (`bundle.structured` = snapshot مستقیماً در همه‌ی مراحل استفاده می‌شود)
- reason_to_keep: منبعِ ContextSnapshot برایِ تمامِ ماژول‌هایِ بعدی.

### state_tracker
- path: `trx_ai/conversation/state_tracker.py`
- status: LIVE
- outputs: ContextSnapshot (خواندن + نوشتن)
- consumers: همه‌ی ماژول‌ها (خواندن)، `conversation_engine.process` (نوشتنِ نهایی)
- influence: **FUNCTIONAL**
- reason_to_keep: تنها منبعِ حافظه‌یِ کوتاه‌مدتِ بینِ نوبت‌ها.

### emotion_analyzer
- path: `trx_ai/conversation/emotion_analyzer.py`
- status: LIVE
- outputs: EmotionReading
- consumers: continuity_analyzer (mixed_emotion)، state_tracker.update_snapshot، Coordinator (emotional_state)
- influence: **FUNCTIONAL**
- reason_to_keep: `emotion.mixed_emotion` مستقیماً وارد `continuity_analyzer.score` می‌شود.

### topic_tracker
- path: `trx_ai/conversation/topic_tracker.py`
- status: LIVE
- outputs: (TopicRelation, evidence)
- consumers: continuity_analyzer، ambiguity_manager، response_critic، conversation_logger، Coordinator
- influence: **FUNCTIONAL**
- reason_to_keep: `response_critic.review` مستقیماً بر اساسِ `relation` پرچمِ `topic_break_risk` می‌سازد که رویِ score/route اثر می‌گذارد.

### continuity_analyzer
- path: `trx_ai/conversation/continuity_analyzer.py`
- status: LIVE
- outputs: continuity_score
- consumers: `intent_arbitrator.arbitrate` (پارامترِ ورودی)، state_tracker (`context_confidence`)
- influence: **FUNCTIONAL**
- reason_to_keep: مستقیماً به arbitrator پاس داده می‌شود.

### intent_candidates
- path: `trx_ai/conversation/intent_candidates.py`
- status: LIVE
- outputs: tuple[IntentCandidate, ...]
- consumers: ambiguity_manager (`has_strong_tool_candidate`)، intent_arbitrator
- influence: **FUNCTIONAL**

### ambiguity_manager (AMS)
- path: `trx_ai/conversation/ambiguity_manager.py`
- status: LIVE
- outputs: AmbiguityAssessment
- consumers: candidates (اگر `candidate_name` باشد، یک IntentCandidate جدید اضافه می‌شود)، state_tracker (`state_updates` مستقیماً اعمال می‌شود)
- influence: **FUNCTIONAL**

### intent_arbitrator
- path: `trx_ai/conversation/intent_arbitrator.py`
- status: LIVE
- outputs: RoutingDecision (پیش از Action Gate)
- consumers: action_gate، response_critic، خروجیِ نهاییِ `process()`
- influence: **FUNCTIONAL**

### action_gate
- path: `trx_ai/conversation/action_gate.py`
- status: LIVE
- outputs: RoutingDecision (اصلاح‌شده -- می‌تواند `blocked_tools`/route را عوض کند)
- consumers: response_critic، خروجیِ نهایی
- influence: **FUNCTIONAL**

### response_planner
- path: `trx_ai/conversation/response_planner.py`
- status: LIVE (اجرا می‌شود)
- outputs: ResponsePlan
- consumers: **هیچ‌کدام در نسخه‌یِ فعلی.** خروجی (`response_planner.plan(...)`) در `conversation_engine.py` سطر ۲۰۰ ساخته می‌شود ولی مقدارِ بازگشتی در هیچ متغیری ذخیره نمی‌شود -- یعنی دور ریخته می‌شود.
- tests: دارد (مستقل)
- influence: **ORPHAN**
- reason_to_keep: طبقِ کامنتِ خودِ کد (سطرِ ۱۹۷-۱۹۹): «صرفاً برایِ لاگ/آینده؛ روی انتخابِ نهایی اثر مستقیم ندارد» -- این یک محدودیتِ *مستندشده* است، نه باگ. Coordinator این نسخه هم آن را مصرف نمی‌کند (فقط از داده‌هایِ خامِ قبل از آن استفاده می‌کند) -- گزینه‌یِ اتصالِ `ResponsePlan` به `UnifiedConversationContext.pattern_context` برایِ نسخه‌ی بعدی باز مانده.

### response_critic
- path: `trx_ai/conversation/response_critic.py`
- status: LIVE
- outputs: (RoutingDecision اصلاح‌شده، critic_flags)
- consumers: state_tracker (لاگ)، Coordinator (`pattern_context.critic_flags`)، خروجیِ نهایی
- influence: **FUNCTIONAL**

### conversation_logger
- path: `trx_ai/conversation/conversation_logger.py`
- status: LIVE
- outputs: side-effect (لاگ)
- consumers: هیچ (فقط مشاهده/دیباگ)
- influence: **DECORATIVE** (عمداً -- یک لاگر هرگز نباید رویِ تصمیم اثر بگذارد؛ این طبیعیِ نقشِ آن است، نه ضعف)

### conversation_patterns.ConversationPatternEngine (خارج از پکیجِ conversation/)
- path: `trx_ai/conversation_patterns.py`
- status: LIVE (در `core.py` مستقیماً استفاده می‌شود -- `local_empathetic_reply`, `mood_report`)
- consumers: `core.py` (مسیرِ fallback وقتی Gemini در دسترس نیست)، دستورِ «تحلیل احساسی»؛ **از v25.5.6:** زیرمجموعه‌یِ stateless آن (`build_pattern`) هم از طریقِ `trx_ai/nervous_system/pattern_bridge.py` صدا زده می‌شود.
- influence: **FUNCTIONAL در مسیرِ خودش** (بدونِ تغییر). نسبت به Nervous System Coordinator: **از ORPHAN به «داده‌یِ واقعی، ولی هنوز بدونِ مصرف‌کننده‌یِ تصمیم‌گیر» ارتقا یافت** -- نگاه کنید به ردیفِ جدیدِ زیر.
- گپِ باقی‌مانده (صادقانه): فقط زیرمجموعه‌یِ **stateless** (`build_pattern` -- یک `@classmethod`، بدونِ DB) وصل شد. بخشِ DB-backed (`observe`, `mood_report`, `relevant`, فرکانسِ امضا در طولِ زمان -- که نیازمندِ نمونه‌یِ واقعیِ `ConversationPatternEngine(db)` در سطحِ اپلیکیشن‌اند، نه در `conversation_engine.process()`) هنوز وصل نیست. این یک تصمیمِ عمدی برایِ کوچک‌نگه‌داشتنِ v25.5.6 بود.

### nervous_system.pattern_bridge (جدیدِ v25.5.6)
- path: `trx_ai/nervous_system/pattern_bridge.py`
- status: LIVE
- inputs: `current_message` + `recent_messages` (یا `turns` صریح برایِ فراخوان‌هایی که تاریخچه‌یِ نقش‌دار دارند)
- outputs: خلاصه‌یِ واقعیِ `ConversationPatternEngine.build_pattern` (بدونِ بردارهایِ عددیِ خام)
- consumers: `nervous_system.coordinator.build_context` (فیلدِ `pattern_context["engine"]`)؛ **از v25.5.7:** همین فیلد در آزمایشِ کنترل‌شده هم مصرف می‌شود (نگاه کنید به ردیفِ زیر).
- tests: `tests/test_nervous_system_v25_5_6.py`
- influence: **ORPHAN نسبت به تصمیم‌گیری** (طبقِ طرح -- Coordinator هنوز SHADOW است)، اما **FUNCTIONAL نسبت به خودِ pattern_context**: آزمایشِ A/B ثابت کرد دو مکالمه‌یِ متفاوت واقعاً دو `pattern_context["engine"]` متفاوت می‌سازند (نگاه کنید به `classify_pattern_engine_wiring()` در `influence_audit.py` برایِ خوداظهاریِ دقیق‌ترِ این وضعیتِ میانی).

### nervous_system.experiments.context_effect_experiment (جدیدِ v25.5.7)
- path: `trx_ai/nervous_system/experiments/context_effect_experiment.py` + `scripts/run_context_effect_experiment.py`
- status: LIVE، ولی **فقط دستی** -- هیچ‌جایِ مسیرِ زنده (`conversation_engine.process` در تولید، `core.py`، `tool_router.py`) این ماژول را صدا نمی‌زند. فقط اسکریپتِ `scripts/run_context_effect_experiment.py` آن را اجرا می‌کند.
- inputs: `UnifiedConversationContext` (FULL، از طریقِ همان مسیرِ v25.5.5/۶) + یک نسخه‌ی `REDUCED` (`dataclasses.replace` با `pattern_context["engine"]=None`، هیچ فیلدِ دیگری تغییر نمی‌کند)
- outputs: `ExperimentReport` (شاملِ `exact_match`/`similarity`/`length_delta`/`behavioral_difference`/`semantic_difference` برایِ هر سناریو -- `semantic_difference` همیشه `"NOT_PROVEN"`)
- consumers: هیچ‌کدام در مسیرِ تولید -- فقط خروجیِ چاپ‌شده/JSONِ اسکریپت برایِ مطالعه‌یِ امیر.
- influence: **کاملاً ORPHAN نسبت به production (عمدی و طبقِ توافق)** -- این ماژول اصلاً قرار نیست FUNCTIONAL شود؛ نقشش «سنجش»، نه «تصمیم‌گیری» است. نتیجه‌یِ خودِ آزمایش (PASS/INCONCLUSIVE) رویِ اینکه آیا `pattern_context` *می‌تواند* خروجیِ Local LLM را عوض کند شهادت می‌دهد -- نه اینکه امروز عوض می‌کند (چون امروز هیچ مصرف‌کننده‌ای در تولید وصل نیست).
- گپِ صادقانه: نتیجه فقط ثابت می‌کند «خروجیِ متن فرق کرد»، نه «TRX معنیِ فیدبک را فهمید» (`semantic_difference` همیشه `NOT_PROVEN`).

### trx_model.llama_cpp_adapter / interfaces / conversational_bridge (تغییرِ کوچکِ افزودنیِ v25.5.7)
- تغییر: پارامترِ اختیاریِ `seed: Optional[int] = None` به `ConversationalModelInterface.chat` و `LlamaCppModelAdapter.chat` اضافه شد (فقط وقتی صریحاً داده شود به `create_chat_completion` پاس داده می‌شود)؛ یک تابعِ عمومیِ جدید `conversational_bridge.get_adapter()` هم اضافه شد.
- influence: **FUNCTIONAL فقط برایِ فراخوان‌هایی که صریحاً `seed` می‌دهند** (یعنی فقط آزمایشِ v25.5.7). برایِ مسیرِ تولیدِ موجود (`try_generate_reply`) که هیچ‌وقت `seed` پاس نمی‌دهد: **صفر تغییرِ رفتار** -- تستِ `test_seed_omitted_when_not_given_zero_behavior_change` این را تأیید می‌کند.

---

## جدیدِ این نسخه (v25.5.5)

### nervous_system.coordinator (NervousSystemCoordinator)
- path: `trx_ai/nervous_system/coordinator.py`
- status: LIVE
- inputs: خروجیِ همه‌یِ ماژول‌هایِ بالا (بعد از تکمیلِ تصمیمِ نمادین) + از v25.5.6: `pattern_engine_context` (خروجیِ `pattern_bridge`)
- outputs: UnifiedConversationContext
- consumers: **هیچ مسیرِ تصمیم‌گیری‌ای هنوز.** فقط در `NervousSystemCoordinator` در حافظه ذخیره می‌شود.
- influence: **ORPHAN (طبق‌طرح، نه نقص)** -- این خودِ مرحله‌یِ SHADOW سند (PHASE 8-A) است. نگاه کنید به `trx_ai/nervous_system/influence_audit.py:classify_coordinator_influence()` که همین طبقه‌بندی را در Runtime هم برمی‌گرداند -- کد و سند از هم جدا نمی‌افتند.
- گیت: `TRX_NERVOUS_SYSTEM_ENABLED` (پیش‌فرض `False`) -- در پیش‌فرضِ production حتی همین جمع‌آوریِ observational هم اجرا نمی‌شود.
- مسیرِ تبدیل به FUNCTIONAL: PHASE 3 سند (Local LLM مصرف‌کننده‌یِ `UnifiedConversationContext` شود) -- در این نسخه ساخته نشده.

---

## نتیجه‌گیریِ صادقانه‌ی این Audit (به‌روزشده در v25.5.6)

- تقریباً کلِ زنجیره‌یِ نمادین (normalizer → ... → response_critic) از قبل **FUNCTIONAL** بود -- «توهمِ پیشرفت» در همین بخش وجود نداشت.
- تنها ORPHAN واقعیِ *پیش از* v25.5.5: `response_planner` (مستندشده، عمدی) -- هنوز هم‌چنان ORPHAN است؛ v25.5.6 آن را دست نزد.
- گپی که v25.5.5 مستند کرده بود (`ConversationPatternEngine` وصل نیست) در v25.5.6 **جزئاً بسته شد**: زیرمجموعه‌یِ stateless (`build_pattern`) اکنون واقعاً صدا زده می‌شود و خروجی‌اش در `pattern_context["engine"]` ذخیره می‌شود -- با آزمایشِ A/B اثبات‌شده (دو context واقعاً متفاوت). بخشِ DB-backed (تاریخچه‌یِ چندنشستی) هنوز باز است.
- **v25.5.7:** برایِ اولین‌بار ثابت شد که `pattern_context` (وقتی از طریقِ prompt به یک LLM واقعی تزریق شود) می‌تواند خروجیِ متن را واقعاً عوض کند -- در یک محیطِ کاملاً کنترل‌شده (fake adapter در این sandbox؛ اجرایِ رسمی رویِ Local LLMِ واقعی هنوز منتظرِ امیر است). این هنوز به‌معنیِ FUNCTIONAL شدنِ Coordinator در تولید نیست -- چون این آزمایش عمداً هیچ‌جایِ مسیرِ زنده صدا زده نمی‌شود.
- Coordinator هنوز عمداً ORPHAN نسبت به تصمیم‌گیریِ نهایی تحویل داده می‌شود؛ ادعایِ «سیستمِ عصبیِ متصل» هنوز **نمی‌شود**. معیارِ نهاییِ سند («اگر یکی از خروجی‌هایِ عصبی را عمداً تغییر دهیم، آیا پاسخ تغییر می‌کند؟») برایِ خودِ *تولید* هنوز **نه** است؛ برایِ *آزمایشگاه* (v25.5.7) اولین شواهدِ مثبت به‌دست آمد -- تمایزِ این دو، صریحاً در `NERVOUS_SYSTEM_NOTES_v25_5_7.md` ثبت شده.
