# TRX Video Intelligence — v25.6.0 (ارتقایِ موتورِ ویدیو بر اساسِ TRX_VIDEO_SUPER_UPGRADE_SPEC_v1)

## مسئله‌یِ ریشه‌ای
موتورِ v25.5.x «preset + substring» بود: `request_normalizer` بر پایهٔ `in` کار می‌کرد («شبیه» ← شب، «ماهی» ← ماه)،
نفی («بدونِ موسیقی») و ترتیبِ رویدادها را نمی‌فهمید، دوربین هدف نداشت، `AudioSpec` فقط برچسب بود و هیچ بازبینیِ
«آنچه ساخته شد = آنچه خواسته شد» وجود نداشت.

## معماری (اول جداسازی، بعد قابلیت) — زنجیرهٔ جدید
```
text → semantic_planner (VideoIntent + Requirement[REQ-001..])
     → scene_planner (Scene Graph + Timeline + Audio Plan)  ← environment/object/style libraries، camera/motion planners
     → resource_guard.degrade → renderers.HTMLCanvasRenderer (VideoRenderer ABC)
     → semantic_validator (روی JSِ جاسازی‌شده در HTML نهایی) → repair (فقط ensure_*هایِ مربوط) → … حداکثر ۳ دور
```
`runtime_manager` فقط `pipeline.build_video` را صدا می‌زند؛ خطایِ v2 → fallback به مسیرِ legacyِ دست‌نخورده.
Kill-switch: `TRX_VIDEO_ENGINE=legacy`. هیچ فایلِ legacy حذف نشد (Red Rule 1).

## فازها
| فاز | وضعیت | شاهد |
|---|---|---|
| A Semantic Planner | انجام | boundary-aware، نفی، ترتیب، شاهدِ متنی، ردیابیِ REQ |
| B Scene Graph | انجام | `scene_graph.py` + اعتبارسنجیِ ارجاع/حلقه/relation؛ camera.target باید گره باشد |
| C Timeline/Camera/Motion | انجام | `timeline_engine` (dependency+cycle)، دوربینِ target-محور، Motion profile |
| D Audio | انجام | recipe واقعیِ WebAudio برایِ rain/wind/underwater/city/forest/thunder/footstep/door/pad؛ sync با Timeline |
| E Renderer | انجام | ۹ لایه، دکورِ پارامتری، ۱۶ محیط، backend abstraction |
| F Style/Determinism | انجام | style روی نور/دوربین/حرکت/صدا؛ seed قطعی |
| G Validation+Repair+Report | انجام | PASS/FAIL/UNSUPPORTED با evidence؛ quality_report قابل‌اندازه‌گیری |
| H Resource/Cancel/Cache | انجام | degradation اولویت‌دار، CancelToken+timeout، PlanCache معنا-محور |
| چندصحنه‌ای | انجام (حداکثر ۶ صحنه) | continuity (seed/محیط/سبک/آب‌وهوا/هویتِ سوژه)، ادغامِ ambience |

## باگ‌هایِ واقعی که *خودِ تست‌ها* پیدا کردند (قبل از تحویل)
1. `[،]` (U+060C) داخلِ کلاسِ حروفِ فارسی بود → «صدای محیط،» تشخیص داده نمی‌شد. کلاسِ حروف فقط حرف شد.
2. اعراب («بدونِ») نرمال نمی‌شد → «بدونِ صدا» نادیده گرفته می‌شد.
3. `window_light` پیش از رویدادِ روشن‌شدن «روشن» بود (default=1 در interpreter) → رویدادِ صریحِ شروعِ خاموش.
4. «صدایِ در» بدونِ رویدادِ باز شدنِ در ثبت می‌شد → صدا مستلزمِ رویدادِ تصویری شد.
5. پیوستگی، حالتِ لحظه‌ایِ `window_lit` را «تغییرِ هویتِ سوژه» می‌دانست.

## تست
`tests/test_video_intelligence_v25_6_0.py` — ۷۳ تست (۱۶ تای آن‌ها JS را در Node واقعاً اجرا و بازرسی می‌کنند؛ بدونِ Node skip).
`tests/test_video_engine_v25_5_10.py` — ۴۰ تستِ قدیمی همچنان سبز. کلِ مجموعه: ۴ فایلِ قدیمیِ نامرتبط (nervous_system/native_model/context_effect)
دقیقاً همان شکست‌ها را روی zipِ اصلیِ دریافتی هم دارند (با shimِ آفلاین) → رگرسیونی از این تغییر نیست.

## محدودیت‌هایِ صادقانه (ادعایِ بیش‌ازِ این ممنوع)
- **درکِ معنایی هنوز واژگان‌محور است، نه LLM.** قرارداد (`VideoIntent`) آماده است تا مدل پشتِ آن بنشیند، ولی مدل وصل نشده.
- **کیفیتِ بصری را «چشمی» ندیده‌ام.** probe شمارشِ فراخوانیِ drawerها، مختصاتِ شخصیت، zoom، flash و صداهایِ فعال‌شده را می‌سنجد، نه پیکسل را.
- **روی Pydroid/اندروید اجرا نشده.** Node آنجا نیست؛ همان اعتبارسنجیِ ایستا فعال است و `render_probe.executed=false` گزارش می‌شود. FPS واقعیِ دستگاه اندازه‌گیری نشده (فقط کاهشِ خودکارِ کیفیت در JS پیاده شده).
- روایت: `speechSynthesis` اگر صدایِ فارسی نداشت، فقط زیرنویس (و در HUD اعلام می‌شود).
- صدا فقط بعد از اولین لمس (سیاستِ مرورگر). خروجیِ MP4/WebM، AssetProvider واقعی، backendِ SVG/Native: فقط interface، پیاده نشده.
- موضوع‌هایِ بی‌drawer (ماشین/پرنده/کشتی/گل/اژدها) → `UNSUPPORTED` + placeholder، نه ادعایِ ساخت.
- «فردِ واقعیِ مشخص» → `UNSUPPORTED` (ساخته نمی‌شود)، ولی سؤالِ شفاف‌سازیِ تعاملی پیاده نشده (`needs_clarification` عمداً None است).
- مدتِ یک پروژه حداکثر ۶۰ ثانیه، ۶ صحنه.
