# PHASE 1 — Behavioral Influence Report — v25.5.5

سطحِ B ی سند: **اثرِ رفتاری** — `Module → Output → Consumer → Decision → Final Response`.
(سطحِ A، «اتصالِ فنی»، در `audit/dependency_report.json` است.)

روش: برایِ هر ماژولِ FUNCTIONAL در `module_status.md`، نقطه‌یِ دقیقِ
کدی که خروجی‌اش تصمیم/route/state را عوض می‌کند مشخص شده.

| ماژول | نقطه‌یِ اثر (فایل:سطر تقریبی) | چه چیزی را عوض می‌کند |
|---|---|---|
| normalizer | conversation_engine.py:127-128 | `None` زودهنگام (fallback به مسیرِ قدیمی) اگر ورودی خالی شود |
| emotion_analyzer | conversation_engine.py:153-155 | `mixed_emotion` وارد continuity_score می‌شود |
| topic_tracker | response_critic.py (`relation`) | پرچمِ `topic_break_risk` → کاهشِ score → می‌تواند `below_critic_threshold` را هم اضافه کند |
| continuity_analyzer | intent_arbitrator.py (پارامترِ `continuity_score`) | رویِ انتخابِ نامزدِ برنده اثر می‌گذارد |
| intent_candidates | intent_arbitrator.py | مجموعه‌یِ نامزدهایِ ورودیِ داوری |
| ambiguity_manager | conversation_engine.py:181-190 | نامزدِ جدید اضافه می‌کند + `state_updates` مستقیماً روی ContextSnapshot نوشته می‌شود |
| intent_arbitrator | conversation_engine.py:192-193 | خودِ `RoutingDecision` اولیه را می‌سازد |
| action_gate | conversation_engine.py:195 | می‌تواند route/`blocked_tools` را عوض کند |
| response_critic | conversation_engine.py:202 | می‌تواند `decision` را (رد یا اصلاح) عوض کند + `critic_flags` |
| response_planner | conversation_engine.py:200 | **هیچ نقطه‌یِ اثری ندارد** — مقدارِ بازگشتی دور ریخته می‌شود (ORPHAN) |
| nervous_system.pattern_bridge (v25.5.6) | conversation_engine.py (داخلِ `_observe_nervous_system`) | **هیچ نقطه‌یِ اثری ندارد** — خروجی فقط در `pattern_context["engine"]` ذخیره می‌شود؛ اثباتِ اینکه واقعاً چیزی تولید می‌کند (نه اینکه رویِ تصمیم اثر دارد) در آزمایشِ A/B زیر است |
| nervous_system.coordinator (جدید) | conversation_engine.py (بعد از سطرِ لاگ) | **هیچ نقطه‌یِ اثری ندارد** — فقط در حافظه ذخیره می‌شود (ORPHAN، طبقِ طرحِ SHADOW) |

## آزمونِ A/B v25.5.6 (طبقِ درخواستِ صریحِ امیر)

سناریوی A (`تست: test_ab_experiment_produces_different_pattern_context`):
پیامِ فعلی = «یه جوک بگو»، بدونِ تاریخچه.

سناریوی B: پیامِ فعلی = «چقدر بی‌مزه 😂»، تاریخچه = `["یه جوک بگو"]`.

نتیجه‌یِ واقعیِ اجراشده (نه شبیه‌سازی‌شده):

```
engine_A.signature = "general|neutral|conversation|statement||unknown"
engine_B.signature = "general|neutral|conversation|statement|چقدر|unknown"
engine_B.topics     = ["چقدر", "بگو چقدر"]   (در A خالی است)
```

**صادقانه:** `sentiment_direction` بینِ A و B هر دو «stable» ماندند --
چون «بی‌مزه» در فرهنگِ لغتِ `EMOTION_CUES` موجودِ Engine (که این نسخه
تغییرش نداد) واژه‌یِ احساسیِ شناخته‌شده‌ای نیست. یعنی تفاوتِ A/B از طریقِ
`topics`/`signature` اثبات شد، نه از طریقِ `sentiment_direction` --
یک محدودیتِ واقعیِ فرهنگِ لغتِ Engine که اینجا صادقانه ثبت می‌شود، نه
پنهان.

## آزمونِ Controlled Context Effect (v25.5.7)

سؤالِ متفاوت از آزمونِ A/B بالا: «حتی اگر `pattern_context` واقعاً
متفاوت باشد، آیا این تفاوت اصلاً *قابلیتِ* اثرگذاری رویِ خروجیِ یک مدلِ
زبانی را دارد؟» -- این سؤالی است که آزمونِ A/B بالا (که فقط خودِ
`pattern_context` را می‌سنجید، نه اثرش را) جواب نمی‌دهد.

روش: همان context (FULL) در برابرِ نسخه‌یِ `REDUCED` (`pattern_context["engine"]=None`،
هیچ فیلدِ دیگری تغییر نکرده)، هر دو از طریقِ یک تزریقِ متنیِ کوتاه به
`system_prompt` وارد `LlamaCppModelAdapter.chat` می‌شوند -- با `seed`/`temperature`/
`max_new_tokens`/`history`/`user_text` کاملاً یکسان بینِ دو تماس (تنها
متغیرِ آزمایش: حضور یا غیابِ بلوکِ context).

نتیجه (با یک fake adapter در این sandbox -- نگاه کنید به
`NERVOUS_SYSTEM_NOTES_v25_5_7.md` برایِ محدودیتِ اجرایِ رسمی رویِ Local
LLMِ واقعی): وقتی adapter واقعاً به بلوکِ context حساس بود، تفاوت
اندازه‌گیری و `OBSERVED` ثبت شد؛ وقتی حساس نبود، `INCONCLUSIVE` --
دقیقاً رفتارِ موردِ انتظار. `semantic_difference` در هر دو حالت
`"NOT_PROVEN"` ماند -- این آزمایش هرگز ادعایِ فهمِ معنایی نمی‌کند.

## آزمونِ عملیِ «اگر خروجی را حذف کنم؟»

- اگر `response_planner.plan(...)` کاملاً کامنت شود → رفتار عوض نمی‌شود (تأییدِ ORPHAN).
- اگر `nervous_system` کاملاً حذف شود (یا `TRX_NERVOUS_SYSTEM_ENABLED` هرگز `1` نشود) → رفتار عوض نمی‌شود؛ این دقیقاً همان چیزی است که `tests/test_nervous_system_v25_5_5.py::test_shadow_mode_never_changes_final_decision` با اجرایِ واقعیِ pipeline (با/بدونِ فلگ) و مقایسه‌یِ بایت‌به‌بایتِ خروجی تأیید می‌کند.
- اگر `response_critic.review(...)` کاملاً حذف شود → `decision`/`critic_flags` تغییر می‌کند (تأییدِ FUNCTIONAL).
