# -*- coding: utf-8 -*-
"""
نقطه‌ی ورودِ رابطِ گرافیکیِ TRX AI (نسخه‌ی PySide6).

اجرا:
    python gui_main.py

نکته: PySide6 عمداً به بوت‌استرپِ خودکارِ `dependencies.py` اضافه نشده
(همان چیزی که با اجرایِ `python main.py` نصب می‌شود)، چون یک پکیجِ
حجیم است و فقط کسانی که از GUI استفاده می‌کنند به آن نیاز دارند؛
کاربرانِ خطِ‌فرمان (Termux و مشابه) نباید مجبور به دانلودش شوند.
"""

from __future__ import annotations

import os
import subprocess
import sys


def _ensure_project_root_on_path() -> None:
    """
    اطمینان از این‌که پوشه‌ی ریشه‌ی پروژه (همان‌جایی که پوشه‌ی trx_ai/
    قرار دارد) در sys.path هست، پیش از وارد کردنِ هر ماژولِ trx_ai.

    چرا لازم است: توضیحِ کامل در main.py._ensure_project_root_on_path.
    خلاصه: بعضی اجراکننده‌ها (مثلِ Pydroid3 روی اندروید که فایل را با
    exec() اجرا می‌کند) پوشه‌ی محتویِ اسکریپت را خودکار به sys.path
    اضافه نمی‌کنند و بدونِ این تابع همین خطا رخ می‌دهد:
        ModuleNotFoundError: No module named 'trx_ai.dependencies';
        'trx_ai' is not a package
    """
    candidates = []
    file_path = globals().get("__file__")
    if file_path:
        candidates.append(os.path.dirname(os.path.abspath(file_path)))
    if sys.argv and sys.argv[0]:
        candidates.append(os.path.dirname(os.path.abspath(sys.argv[0])))
    candidates.append(os.getcwd())

    for base in candidates:
        if base and os.path.isdir(os.path.join(base, "trx_ai")) and base not in sys.path:
            sys.path.insert(0, base)
            return


_ensure_project_root_on_path()

from trx_ai.dependencies import ensure_required_packages  # noqa: E402  (باید بعد از بوت‌استرپِ مسیر باشد)

# پکیج‌های اصلیِ برنامه (همان‌هایی که ترمینال هم نیاز دارد)
ensure_required_packages()

try:
    import PySide6  # noqa: F401
except ImportError:
    print("📦 PySide6 (کتابخانه‌ی رابطِ گرافیکی) نصب نیست؛ در حال نصب...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "PySide6>=6.6"])
        print("✅ PySide6 نصب شد.")
    except Exception as e:  # noqa: BLE001
        print(f"❌ نصبِ خودکارِ PySide6 ناموفق بود: {e}")
        print("   دستی نصب کنید: pip install PySide6")
        sys.exit(1)

from trx_ai.gui_app import run  # noqa: E402  (باید بعد از اطمینان از نصبِ PySide6 باشد)

if __name__ == "__main__":
    run()
