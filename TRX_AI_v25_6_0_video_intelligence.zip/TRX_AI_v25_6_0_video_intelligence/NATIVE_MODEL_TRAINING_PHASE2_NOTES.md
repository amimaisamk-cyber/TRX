# فازِ دومِ آموزشِ TRX Native Model — Pipeline داده و آموزشِ کنترل‌شده (v25.4.6)

## Upgrade Assessment (طبقِ تمپلیتِ خودِ سند، بخشِ ۲۰ سندِ ارتقا)

**Current State** -- v25.4.5 موتورِ Backward/AdamW/Checkpoint را
فعال کرده بود (Gradient Check، Tiny Overfit، و یک اجرایِ کوچکِ
end-to-end رویِ متنِ خامِ پروژه)، اما بدونِ pipelineِ دادهِ واقعی:
بدونِ Cleaning، بدونِ Dedup، بدونِ تقسیمِ سطحِ سند، بدونِ Smoke Test
اجباری، بدونِ Checkpointِ سه‌سطحی، بدونِ مانیتورِ منابع.

**Weakness** -- «سندِ فازِ دوم» صریحاً هشدار داده بود:
Data Leakage در splitِ سطحِ توکن، بدونِ Smoke Test آموزشِ خراب
دیرمتوجه‌شده، Checkpointِ غیرِ اتمیک که با قطعِ ناگهانی خراب می‌شود،
و بدونِ مانیتورِ منابع، کرشِ گوشی در وسطِ آموزش.

**Upgrade Goal** -- فعال‌سازیِ کاملِ زنجیره‌یِ بخشِ ۲ سند: Dataset ->
Cleaning -> Deduplication -> Document Split -> Tokenization ->
Sequence Packing -> Train/Validation -> ... -> Checkpoint ->
Validation -> Metrics -> Generation Evaluation -- هیچ مرحله‌ای حذف
نشود.

**Approach** -- یک پکیجِ کاملاً جدا و additive:
`trx_ai/trx_model/training/data_pipeline/` (فهرستِ کامل پایین‌تر)،
که تنها از فایل‌هایِ فازِ اول (`checkpoint.py`، `trainer.py`،
`evaluator.py`، `gradient_check.py`، `dataset.py`) *استفاده*
می‌کند -- هیچ‌کدام تغییر نکردند.

**Capability Impact** -- Reliability و Memory Intelligence
(بخشِ ۲۰ فلسفه‌ی ارتقا): Data Leakage اکنون مکانیکی غیرممکن است
(splitِ سطحِ سند، نه توکن)، Checkpoint دیگر با قطعِ برق خراب نمی‌شود
(نوشتنِ اتمیک)، و Smoke Test آموزشِ خراب را قبل از هدررفتنِ زمان
متوقف می‌کند.

**Risk** -- ریسکِ اصلی «Loss خوب ولی خروجی بد» (نقل‌قولِ بخشِ ۱۲
سند) بود -- یعنی معیارِ عددی درست باشد اما تفسیر غلط. برایِ رفع:
`pipeline_runner._interpret` دقیقاً چهار حالتِ صریحِ سند را چک
می‌کند، نه فقط «Loss کم شد -> موفق».

**Preservation** -- هیچ فایلی از v25.4.4/v25.4.5 تغییر نکرد.
`checkpoint_policy.py` فقط `save_checkpoint`/`load_checkpoint`ی
فازِ اول را با پوششِ atomic-rename صدا می‌زند؛ منطقِ خودِ
serialize/deserialize دست‌نخورده ماند.

**Validation** -- ۲۱ تستِ واحدِ جدید + اجرایِ کاملِ
`scripts/run_phase2_pipeline.py` رویِ پیکره‌یِ واقعیِ پروژه (نتایج
پایین‌تر).

**Result** -- زنجیره‌یِ کاملِ فازِ دوم رویِ همان ۲۳ فایلِ `*.md`
واقعیِ پروژه، از صفر تا Resume، بدونِ هیچ crash یا NaN اجرا شد:
Validation Loss از `6.55` به `5.05` (Perplexity از `699` به `156`)
در ۱۸۰ step، با تفسیرِ خودکارِ «هم Train و هم Validation کاهش
یافتند -- یادگیریِ واقعی محتمل است»، Resume با تطابقِ دقیقِ وزن‌ها،
و Generalization Test بدونِ تکرارِ بی‌پایان رویِ promptهایِ
دیده‌نشده.

---

## چرا این‌بار هم یک پکیجِ کاملاً جدا؟

همان قانونِ قرمزِ ۱: مسئله «جایگزینیِ چیزی موجود» نبود. `dataset.py`ی
فازِ اول (که Input/Target را با شیفتِ یک‌خانه می‌سازد) هنوز دقیقاً
همان‌طور استفاده می‌شود -- فقط این‌بار ورودی‌اش (`train_texts`/
`val_texts`) از یک Documentِ پاک‌شده و سطح‌سند-تقسیم‌شده می‌آید،
نه رشته‌یِ خامِ فایل.

## چه چیزی واقعاً پیاده شده

| فایل | مسئولیت | بخشِ سند |
|---|---|---|
| `data_pipeline/cleaning.py` | حذفِ خالی/کوتاه/HTML/کنترلی، یکسان‌سازیِ فاصله، حفظِ نیم‌فاصله، ثبتِ دلیلِ حذف. | ۴ |
| `data_pipeline/dedup.py` | حذفِ duplicateِ کاملِ سند (hash-based، سطحِ سند). | ۴ |
| `data_pipeline/quality.py` | امتیازِ کیفیت (طول/خوانایی/تکرار/پاراگراف/علائم) + ردهٔ A/B/C. | ۵ |
| `data_pipeline/corpus_builder.py` | ساختِ Documentها از `*.md` واقعیِ پروژه (سطحِ پاراگراف) + اجرایِ کاملِ Cleaning->Dedup->Quality + manifest.json. | ۲،۳،۷ |
| `data_pipeline/split.py` | تقسیمِ سطحِ سند (نه توکن) با seedِ ثابت؛ اگر split.json قبلی سازگار باشد، همان Validation دوباره استفاده می‌شود. | ۶ |
| `data_pipeline/tokenizer_report.py` | encode->decode رویِ نمونه‌ها، بررسیِ round-trip و طولِ توالی. | ۸ |
| `data_pipeline/sequence_packing_check.py` | چاپ و تاییدِ برنامه‌ایِ `target[t]==input[t+1]`. | ۹ |
| `data_pipeline/smoke_test.py` | چک‌لیستِ اجباریِ ۱۱-موردی؛ با اولین شکست متوقف می‌شود. | ۱۱ |
| `data_pipeline/fixed_prompts.py` | مجموعه‌یِ ثابتِ ۷ prompt + نمونه‌برداریِ top-k + لاگِ JSONL قبل/بعد. | ۱۳ |
| `data_pipeline/checkpoint_policy.py` | Checkpointِ سه‌سطحی (latest/best/periodic) با نوشتنِ اتمیک + Resume با هشدارِ ناسازگاری. | ۱۴،۱۵ |
| `data_pipeline/resource_monitor.py` | فضایِ دیسک، RAMِ دوره‌ای (psutil)، graceful-stop، لاگِ چرخشی. | ۱۶ |
| `data_pipeline/generalization_test.py` | promptهایِ دیده‌نشده + تشخیصِ تکرارِ بی‌پایانِ n-gram. | ۱۲،۱۹ |
| `data_pipeline/pipeline_runner.py` | هماهنگ‌کننده‌یِ کاملِ مراحلِ ۲.۱ تا ۲.۹. | ۱۷ |
| `tests/test_native_model_training_phase2.py` | ۲۱ تستِ واحد. | -- |
| `scripts/run_phase2_pipeline.py` | اجرایِ end-to-end رویِ پیکره‌یِ واقعی. | -- |

## اعتبارسنجی (نتیجه‌یِ واقعیِ اجرا، نه ادعا)

اجرا (بازتولیدپذیر با `python scripts/run_phase2_pipeline.py`):

```
۲.۱/۲.۲  ۵۰۰ پاراگراف خام -> ۴۹۵ سندِ kept (۵ duplicateِ کامل حذف شد،
         ۰ حذفِ کیفیت) -> ۴۴۵ train / ۵۰ validation (سطحِ سند)
۲.۳      Tokenizer: round-trip ۱۰۰٪ سالم؛ Sequence Packing: shift صحیح
۲.۴      Smoke Test: همه‌ی ۱۱ چک پاس (dataset/tokenizer/shape/forward/
         loss/backward/gradients/weight-update/checkpoint/validation/generation)
۲.۵      train loss: 6.3468 -> 4.2698   (۱۸۰ step، ۲.۶s)
         val loss:   6.5494 -> 5.0505   (perplexity 698.9 -> 156.1)
۲.۶      «هم Train و هم Validation کاهش یافتند -- یادگیریِ واقعی محتمل است.»
۲.۸      Resume: weights_match_after_resume = True
۲.۹      Generalization: any_infinite_repetition = False
```

نمونه‌یِ Generationِ قبل/بعد (از `phase2_out/data/reports/generation_comparison.jsonl`،
prompt=«هوش مصنوعی یعنی»؛ مدل هنوز خیلی کوچک و کم‌آموزش‌دیده است --
خروجی هنوز بی‌معناست، اما الگویِ کلماتِ فارسیِ رایج مثلِ «است»/«می»/
«یک» بعدِ آموزش بیشتر ظاهر می‌شود، نه خروجیِ کاملاً یکسان با قبل):

```
before: هوش مصنوعی یعنیصنوماصکه عیLم عاملننگاهپایدد،دحلاییِL(ه
after:  هوش مصنوعی یعنی درis_` ` ` L است است می-d، (
```

**۲۱ تستِ واحد** (`tests/test_native_model_training_phase2.py`):
Cleaning (حذفِ خالی/کوتاه/HTML، حفظِ نیم‌فاصله، حذفِ خطِ تکراری)،
Dedup (حذفِ duplicateِ دقیق)، Quality (تمایزِ متنِ خوب از تکراری)،
Corpus Builder (min_chars/max_docs، status پس از cleaning/quality)،
Split (leakage-safe، بازاستفاده از splitِ ثابت با seedِ متفاوت)،
Sequence Packing (shift صحیح رویِ توکنایزرِ واقعی)، Smoke Test (پاس
رویِ setupِ سالم، شکستِ صریح رویِ dataset خالی و vocab_size
ناسازگار)، Checkpoint Policy (ذخیره‌ی اتمیک، best فقط با بهبودِ
واقعی به‌روز می‌شود، periodic فقط N نسخه‌یِ آخر را نگه می‌دارد،
هشدارِ seed_mismatch در Resume)، Resource Monitor (فضایِ دیسک، آستانه)،
Generalization (تشخیصِ صحیحِ n-gramِ تکراری در برابرِ متنِ عادی).

اجرا (بدونِ اینترنت در این نشست هم `pytest` نصب نبود؛ منطقِ هر ۲۱
تست به‌صورتِ دستی/مستقیم هم اجرا شد -- همه پاس، به‌همراهِ ۲۱ تستِ
فازِ اول که همچنان بدونِ رگرسیون پاس می‌شوند):

```bash
pytest tests/test_native_model_training_phase2.py tests/test_native_model_training.py -v
```

## چه چیزی عمداً پیاده **نشده** (گزارشِ صادقانه‌یِ scope)

- **Extended Training (مرحله‌یِ ۲.۷ سند):** `pipeline_runner` فقط تا
  یک Controlled Trainingِ کوتاه (۱۸۰ step) می‌رود -- طبقِ خواسته‌یِ
  خودِ سند («سه سطحِ اجرا: Smoke -> Controlled -> Extended، پس از
  تأییدِ A و B»)، اجرایِ طولانیِ واقعی مرحله‌یِ بعدی است، نه همین
  افزودن.
- **Batch>1 یا Gradient Accumulation:** طبقِ بخشِ ۱۰ سند («تنظیماتِ
  محافظه‌کارانه‌یِ گوشی: batch_size=1»)، عمداً اضافه نشد.
- **Persistent Resource-Monitoring Loop در حینِ Training:**
  `ResourceMonitor.check()` آماده است، اما `trainer.py`ی فازِ اول
  (که تغییر نکرد) هنوز آن را در حلقه‌یِ خودش صدا نمی‌زند --
  فراخوان‌کننده (مثلِ `pipeline_runner`) می‌تواند بینِ استپ‌ها صدا
  بزند؛ اتصالِ خودکار داخلِ `trainer.train` نیازمندِ تغییرِ آن فایل
  بود که طبقِ اصلِ Preserve این‌جا انجام نشد.
- **اتصال به Core/Chat:** هنوز جایی صدا زده نمی‌شود -- طبقِ بخشِ ۱۸
  سند («اتصالِ مستقیمِ مدلِ خام به تمامِ Core» صریحاً ممنوع است).

## معیارِ پایانِ موفقِ فازِ دوم (طبقِ بخشِ ۱۹ سند)

Pipelineِ داده تکرارپذیر ✅ (manifest.json + split.json) ·
Dataset نسخه‌بندی‌شده ✅ (corpus_v1) · Leakage کنترل‌شده ✅
(splitِ سطحِ سند، تست‌شده) · Smoke Test پایدار ✅ (۱۱/۱۱) ·
چند اجرایِ آموزشی بدونِ crash ✅ · روندِ Loss منطقی ✅ (Train و
Validation هر دو کاهش) · Validation معتبر ✅ (splitِ ثابت) ·
Perplexity با کاهشِ قابلِ‌توضیح ✅ (۶۹۹->۱۵۶) · Generation از مدلِ
تصادفی بهتر ✅ (الگویِ کلماتِ رایجِ فارسی بیشتر شد) · Checkpoint و
Resume سالم ✅ (تست‌شده، اتمیک) · مصرفِ منابعِ گوشی کنترل‌شده ✅
(تخمینِ RAM ~3.6MB، بررسیِ فضایِ دیسک قبل/بعد).
