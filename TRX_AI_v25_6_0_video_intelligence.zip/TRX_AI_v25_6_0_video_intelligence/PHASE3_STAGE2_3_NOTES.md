# فاز ۳ — مرحله‌های ۲ و ۳: neural_adapter + inference_service

**نسخه:** v25.4.8
**سند مرجع:** `TRX_AI_Phase3_Native_Neural_Cognitive_Layer_Complete_Design.txt` (نسخه‌ی طراحی P3.0)
**مرحله:** ۲ و ۳ از ۱۰ (بخشِ ۱۹ سند)

## Current State (وضعیتِ فعلی)

`v25.4.7` فقط `schemas.py` + `config.py` + `feature_builder.py` را
ساخته بود -- سه فایلِ خالص، بدونِ I/O، بدونِ importی از `trx_model`.
هیچ اتصالِ واقعی به مدلِ عصبی وجود نداشت؛ `Phase3Config` می‌توانست
ساخته شود ولی هیچ چیزی برایِ «فعال‌کردن»ِ آن وجود نداشت.

## Problem (مشکل)

طبقِ متنِ صریحِ برنامه‌ی مرحله‌ایِ سند (بخشِ ۱۹)، دو قدمِ بعدی این‌ها
بودند:

- مرحله ۲: «اتصال Neural Adapter به trx_model / فقط inference
  آزمایشی / تست load/unload / تست سازگاری tokenizer/model»
- مرحله ۳: «ساخت Inference Service / timeout / resource guard /
  fallback / telemetry»

بدونِ این دو، فاز ۳ صرفاً یک قراردادِ داده بود، نه یک لایه‌ای که
واقعاً بتواند (در حالتِ Shadow/Advisoریِ آینده) inference اجرا کند.

## Root Cause (علتِ اصلی)

این «مشکل» نه یک باگ که یک شکافِ برنامه‌ریزی‌شده بود: سندِ خودِ پروژه
عمداً مرحله‌ی ۱ را بدونِ اتصال طراحی کرده بود تا ریسکِ صفر باشد.
علتِ اصلیِ نیاز به این دو مرحله صرفاً پیشرویِ طبیعیِ همان برنامه است.

## Solution (راه‌حل)

**مرحله‌ی ۲ -- `neural_adapter.py`:**
تنها نقطه‌ی تماس با `trx_ai/trx_model`. `TRXNativeModelAdapter`ی که در
`v25.4.5` ساخته شده بود را پشتِ یک state machine (`UNLOADED -> LOADED
-> ERROR`) می‌پیچد:
- `load()` هیچ‌وقت exception خام پرتاب نمی‌کند -- همیشه `LoadResult`.
- `unload()` ارجاع‌ها را آزاد می‌کند و `gc.collect()` می‌زند.
- `check_compatibility()` صریحاً `vocab_size` مدل و توکنایزر را
  مقایسه می‌کند.
- `trial_generate()` فقط یک تولیدِ متنِ خام است -- **بدونِ**
  `NeuralAdvice` (که نیازمندِ `task_heads.py`ی هنوز‌نساخته است).
- checkpoint اختیاری با یک لودرِ سبکِ فقط-وزن (بدونِ نیاز به `AdamW`ی
  جعلی که `training/checkpoint.load_checkpoint` برایِ Resume آموزش
  اجباری می‌کند).

**مرحله‌ی ۳ -- `inference_service.py` + سه فایلِ کمکی:**
- `latency_guard.py`: `run_with_timeout()` (ThreadPoolExecutor تک-نخی)
  و `check_ram_budget()` (RSS از `psutil`، fail-open اگر نصب نباشد).
- `fallback.py`: `FallbackReason` enum + توضیحِ فارسی.
- `telemetry.py`: `TelemetryLog` بافرِ محدود، هم‌الگو با
  `core_engine/trace.py`.
- `inference_service.py`: `Phase3InferenceService.run_trial()` --
  مسیرِ واحد: بررسیِ فعال‌بودن -> RAM -> بارگذاری -> timeout -> ثبتِ
  تله‌متری. همیشه `InferenceOutcome`، هیچ‌وقت exception.

## Risk (ریسک)

- **ریسکِ رگرسیون برایِ رفتارِ زنده‌ی TRX: صفر.** هیچ فایلِ موجودی
  (`core.py`، `intelligence.py`، `trx_ai/conversation/*`،
  `trx_ai/trx_model/*` موجود) تغییر نکرد؛ فقط دو فایلِ مستنداتیِ
  (`README.md`، `trx_ai/__init__.py` برایِ نسخه) دست خورد.
- **ریسکِ واقعیِ باقی‌مانده:** خودِ `run_with_timeout` -- چون CPython
  نمی‌تواند Thread را از بیرون بکشد، یک forward pass که واقعاً گیر
  کند، نخِ زمینه‌اش تا پایانِ طبیعی به اجرا ادامه می‌دهد (فقط نتیجه‌اش
  مصرف نمی‌شود). این محدودیت در docstring خودِ `latency_guard.py`
  صادقانه مستند شده -- به همین دلیل `check_ram_budget` هم قبل از هر
  inference اجرا می‌شود (تایم‌اوت به‌تنهایی مانعِ تجمعِ چند نخِ سنگین
  نمی‌شود).

## Preservation (چه چیزی حفظ شد)

- عدمِ اتصال به Core: `trx_ai.phase3` هنوز هیچ importی به
  `trx_ai.core_engine`/`trx_ai.intelligence`/`trx_ai.conversation.*`
  (به‌جز خواندنِ نوعِ `ContextSnapshot` که از مرحله‌ی ۱ بود) ندارد.
- کلِ زنجیره‌ی `TRXNativeModelAdapter -> trx_model` که در `v25.4.5`
  ساخته و اثبات شده بود، بدونِ تغییر مصرف شد (نه بازنویسی).
- الگویِ `Phase3Config` (frozen، env-driven، پیش‌فرض امن) از مرحله‌ی ۱
  بدونِ تغییر مصرف شد.

## Validation (اعتبارسنجی)

```
$ python3 -m unittest discover -s trx_ai/phase3/tests -p "test_phase3*" -v
...
Ran 56 tests in 0.584s

OK
```

بررسیِ جداگانه‌ی مسیرهایِ اصلی (اجرایِ دستی، نه فقط unittest):
- `load()` روی توکنایزرِ پیش‌فرض: موفق، `param_count=443520`.
- `unload()` سپس `trial_generate()`: `NeuralAdapterNotLoadedError`.
- `Phase3InferenceService` با کانفیگِ پیش‌فرض (`enabled=False`):
  fallback فوری، `fallback_reason=DISABLED`، بدونِ لمسِ آداپتور.
- کانفیگِ `enabled=True, mode=SHADOW`: `run_trial` موفق، خروجیِ متنی
  (بی‌معنی -- چون وزن‌ها آموزش‌ندیده‌اند، دقیقاً طبقِ همان صداقتِ
  `model.py`)، `model_version`/`tokenizer_version` پر شده.
- `max_ram_mb` بسیار کوچک: `fallback_reason=RAM_LIMIT`.
- `TRX_PHASE3_CHECKPOINT_PATH` به مسیرِ نامعتبر: `fallback_reason=LOAD_FAILED`.
- `timeout_ms=0.001`: `fallback_reason=TIMEOUT`، `timed_out=True`.

## چیزی که این نسخه *نیست*

- بدونِ `task_heads.py` -- هیچ پیش‌بینیِ topic/emotion/relation/
  response-mode ساختاریافته‌ای وجود ندارد؛ `trial_generate` فقط یک
  رشته‌ی خام برمی‌گرداند.
- بدونِ `fusion_engine.py`/`policy_bridge.py`/`draft_generator.py` --
  هیچ `NeuralAdvice`/`FusionDecision` واقعی ساخته نمی‌شود.
- بدونِ `advice_validator.py`/`confidence.py`/`versioning.py` کامل --
  `model_version`/`tokenizer_version` فعلاً هش‌هایِ سبکِ داخلِ
  `neural_adapter.py` هستند، نه یک ماژولِ versioning مستقل (که بخشِ
  سازگاریِ checkpoint را هم باید پوشش دهد -- خارج از محدوده‌ی صریحِ
  مرحله‌ی ۲/۳).
- بدونِ هیچ تغییری در `core.py`، `intelligence.py`، یا
  `trx_ai/conversation/*` -- صفر ریسکِ رگرسیون برایِ رفتارِ زنده‌ی فعلی.

## گامِ بعدی (مرحله‌ی ۴ سند)

طبقِ بخشِ ۱۹: «Shadow Mode / ثبتِ مقایسه‌ی نمادین-عصبی / ساختِ
dataset ارزیابیِ مکالمه». این نیازمندِ اتصالِ واقعی (فقط خواندنی) به
`trx_ai.conversation` برایِ گرفتنِ `ContextSnapshot` زنده است -- اولین
باری که فاز ۳ به یک مسیرِ اجرایِ واقعیِ TRX (نه فقط تستِ ایزوله) وصل
می‌شود. باید جداگانه و با تأییدِ صریح شروع شود.
