# v25.6.0 — Video Intelligence: ارتقایِ موتورِ ویدیو (Semantic Planner، Scene Graph، Audio واقعی، Validator+Repair)

جزئیات و محدودیت‌هایِ صادقانه: `audit/VIDEO_INTELLIGENCE_v25_6_0.md`.

- `trx_ai/video/semantic_planner/` (جدید): `VideoIntent` + `Requirement`؛ تطبیقِ مرزدار، نفی، ترتیبِ رویداد.
- `scene_graph.py`, `timeline_engine.py`, `environment_library.py`, `object_library.py`, `style_system.py`,
  `audio_planner.py`, `scene_planner.py`, `project.py` (چندصحنه‌ای)، `renderers/` (backend abstraction + HTMLCanvasRenderer).
- `semantic_validator.py`, `repair.py`, `resource_guard.py`, `pipeline.py`, `explain.py`, `render_probe.py` (+ `tools/render_probe.js`).
- تغییرِ افزایشیِ فایل‌هایِ موجود: `scene_schema` (فیلدهایِ پیش‌فرض‌دار)، `motion_planner`/`camera_planner` (توابعِ جدید)،
  `session_manager` (slot `project`)، `patch_engine` (سرعتِ حرکت در Timeline)، `runtime_manager` (v2 با fallback)، `tool_router` (افزودنِ خلاصهٔ کاربر).
- Kill-switch: `TRX_VIDEO_ENGINE=legacy`. هیچ کدِ legacy حذف نشد.
- ۷۳ تستِ جدید + ۴۰ تستِ قدیمیِ ویدیو سبز.

---

# v25.5.10 — رفعِ باگ: Therapy Companion بازخوردِ «تکراری شدی» را نادیده می‌گرفت

جزئیاتِ کامل: `audit/THERAPY_REPETITION_FEEDBACK_v25_5_10.md`.

خلاصه: یک سندِ تحلیلیِ جداگانه چند مشکلِ مستقل در رفتارِ مکالمه‌ایِ TRX
شناسایی کرد؛ طبقِ انضباطِ «یک concern در هر نوبت»، فقط یکی رفع شد --
Therapy Companion وقتی کاربر صریحاً می‌گفت «این حرف‌ها رو دقیقاً به
همین ترتیب قبلاً ازت شنیدم»، این را پردازش نمی‌کرد و با یک بازتابِ
کلیشه‌ایِ دیگر جواب می‌داد. دو ریشه: (۱) `responses.pick()` از قبل
پارامترِ ضدِ تکرارِ `last_used` داشت اما `engine.py` هرگز آن را پاس
نمی‌داد؛ (۲) `emotions.detect()` هیچ برچسبی برایِ «بازخورد دربارهٔ
رفتارِ خودِ TRX» نداشت. هر دو رفع شد: `emotions.is_repetition_feedback()`
جدید (با نکته‌یِ ایمنیِ صریح دربارهٔ فعلِ اول‌شخص در برابرِ دوم‌شخص، تا
اشاره‌یِ کاربر به شخصِ سوم به‌غلط تشخیص داده نشود)، استخرِ پاسخِ جدیدِ
`REPETITION_ACKNOWLEDGMENT`، و اتصالِ واقعیِ `session.last_reflection`/
`last_question` به فراخوانی‌هایِ `pick()`.

تست: ۱۱ تستِ جدید (`tests/test_therapy_repetition_feedback_v25_5_10.py`)
+ ۱۲ تستِ قبلیِ `test_therapy_companion.py` -- جمعاً ۲۳/۲۳ Pass، صفر
رگرسیون. تغییرات کاملاً محدود به `trx_ai/medical/therapy/`.

سه یافته‌یِ دیگرِ همان سند (نبودِ Conversation Controller واحد، شکستِ
زنجیره‌یِ ارجاعِ ضمنی به پاسخِ قبلی، نادیده‌گرفتنِ contextِ کاملِ
مکالمه توسطِ موتورِ پزشکی) عمداً باز ماندند -- جزئیات در همان audit
doc.

---

# v25.5.4 — رفعِ دو ایرادِ معماریِ واقعی که در بررسیِ خارجیِ v25.5.3 پیدا شد

یک بررسیِ دقیقِ خارجی (رویِ خودِ ZIP، نه فقط توضیح) دو ایرادِ درست و
مشخص پیدا کرد که هر دو تأیید و رفع شدند:

۱) **نشتِ interface:** ``conversational_bridge.py`` مستقیماً به
   ``adapter.chat(...)`` وابسته بود، درحالی‌که ``ModelInterface`` فقط
   ``generate()`` را قرارداد کرده بود -- یعنی یک Adapterِ آینده که
   فقط ``ModelInterface`` را پیاده می‌کرد بی‌سروصدا می‌شکست. رفع: یک
   ``ConversationalModelInterface(ModelInterface)`` جدید با متدِ
   انتزاعیِ ``chat`` در ``trx_model/interfaces.py``؛
   ``LlamaCppModelAdapter`` حالا صریحاً همین را پیاده می‌کند، و
   ``conversational_bridge`` قبل از فراخوانی ``isinstance`` چک
   می‌کند (نه فرضِ ضمنی).

۲) **تاریخچه‌ی گفتگو خالی می‌ماند:** ``tool_router.py`` قبلاً
   ``try_generate_reply(resolved_text)`` را بدونِ تاریخچه صدا
   می‌زد -- یعنی مدلِ محلی مکالمه را چندنوبتی نمی‌دید. رفع:
   ``conversational_bridge.build_history_from_db(db)`` تاریخچه‌ی
   *واقعی* را از همون جدولِ ``history``یِ موجود
   (``DatabaseManager.get_recent_history``) به شکلِ جفت‌هایِ
   ``(role, content)`` زمانی-مرتب می‌سازد؛ ``tool_router.py`` حالا
   ``db=ai.db`` را پاس می‌دهد.

تست: ۵ تستِ جدید اضافه شد (جمعاً ۱۶ تست در
``test_local_llm_integration.py`` + ``test_feedback_correction_not_fuzzy_capped.py``،
همه Pass).

**آنچه بررسیِ خارجی هم درست گفت و هنوز باز است (عمداً، طبقِ همون
گزارش):** LLMِ محلی هنوز *موتورِ اصلیِ* فهمِ مکالمه نیست -- هنوز فقط
آخرین لایه‌ی fallback است (بعدِ SmallTalk/Wikipedia/DuckDuckGo/
local_empathy/user_state). تبدیلِ واقعیِ معماری به «LLM لایه‌ی فهم،
ابزارها زیرِ کنترلش» یک تصمیمِ بزرگ‌تر و جداست که هنوز گرفته نشده.

# v25.5.3 — اتصالِ اختیاریِ یک مدلِ زبانیِ واقعی و محلی (Model Adapter، بخشِ ۱۱ سند)

جزئیاتِ کامل: `LOCAL_LLM_INTEGRATION_NOTES.md`.

خلاصه: `trx_ai/trx_model/llama_cpp_adapter.py` یک پیاده‌سازیِ جدیدِ
`ModelInterface` است رویِ `llama-cpp-python` (اجرایِ محلیِ فایل‌هایِ
GGUF -- بدونِ اینترنت، بدونِ APIِ خارجی). `conversational_bridge.py`
این را با یک کلیدِ خاموش/روشن (پیش‌فرض خاموش) به مسیرِ fallbackِ
عمومیِ `core_engine/tool_router.py` وصل می‌کند -- دقیقاً جایی که قبلاً
boilerplateِ ثابتِ «من TRX AI هستم. سؤال خود را دقیق‌تر مطرح کنید»
تولید می‌شد. هر خطا (کتابخانه نصب نیست، فایلِ مدل نیست، خروجیِ
غیرمنتظره) بی‌صدا `None` برمی‌گرداند تا مسیرِ قدیمی دقیقاً بدونِ تغییر
اجرا شود -- هیچ رفتارِ موجودی حذف نشده، این‌ها فقط یک مسیرِ بهتر جلوی
مسیرِ قدیمی هستند.

تست: `tests/test_local_llm_integration.py` (۸ تست، با stubِ
تزریق‌شده به‌جایِ نصبِ واقعیِ llama.cpp -- منطقِ خودمان تست شده، نه
خودِ کتابخانه). محدودیت: بدونِ end-to-endِ واقعی با یه مدلِ واقعی
(نبودِ اینترنت در این sandbox)؛ کیفیتِ مکالمه فقط بعدِ نصبِ واقعی رویِ
سیستمِ کاربر قابلِ قضاوت است.

# v25.5.2 — رفعِ باگ: سقفِ «فقط فازی» تصحیحِ صریحِ کاربر (یادگیریِ نیت) را هم سقف می‌زد

جزئیاتِ کامل: `BUGFIX_v25_5_2_FEEDBACK_FUZZY_CAP.md`.

خلاصه: بعدِ اینکه کاربر یک تشخیصِ اشتباه را تصحیح می‌کرد («نه منظورم
این نبود» → «یاد گرفتم که ... یعنی X»)، دفعه‌ی بعدِ همان پیام دقیقاً
همان تشخیصِ غلطِ قبلی تکرار می‌شد؛ یعنی «یادگیری» عملاً بی‌اثر بود.
علتش: `intent_candidates.py` یک سقفِ ایمنی برایِ تطبیق‌هایِ *فازیِ*
بدونِ کلیدواژه‌ی دقیق داشت («اما»≈«دما»)، اما این سقف بینِ فازیِ
تصادفی و تصحیحِ صریحِ کاربر تمایز قائل نمی‌شد و امتیازِ ۰.۹۹ی که
`nlu/scorer.py` بعدِ تصحیح می‌داد را به‌زور ۰.۳ می‌کرد. رفع: یک
`MatchHit(matcher="feedback")` از `nlu/feedback.py` تا
`intent_candidates.py` ردیابی می‌شود تا این دو حالت از هم تفکیک شوند؛
سقفِ اصلی برایِ فازیِ واقعی دست‌نخورده ماند (تستِ رگرسیونِ «اما
واقعاً خوشحالم» هنوز Pass است).

تست: `tests/test_feedback_correction_not_fuzzy_capped.py` (۳ تست؛
روی v25.5.1 دو موردش Fail می‌شد، روی این نسخه هر سه Pass).

# v25.4.8 — فاز ۳، مرحله‌های ۲ و ۳: neural_adapter + inference_service (timeout/RAM guard/fallback/telemetry)

خواسته: ادامه‌ی برنامه‌ی ده‌مرحله‌ایِ سندِ «TRX Native Neural Cognitive
Layer — Phase 3» (P3.0، بخشِ ۱۹) از جایی که `v25.4.7` (مرحله‌ی ۱)
متوقف شده بود. این نسخه دقیقاً **مرحله‌های ۲ و ۳** را پیاده می‌کند --
نه یک قدم جلوتر (بدونِ `task_heads.py`، `fusion_engine.py`،
`policy_bridge.py`، `draft_generator.py` -- همه‌یِ این‌ها مراحلِ ۴ به
بعدِ سند هستند):

> مرحله ۲: اتصالِ Neural Adapter به `trx_model` / فقط inference
> آزمایشی / تستِ load/unload / تستِ سازگاریِ tokenizer/model
>
> مرحله ۳: ساختِ Inference Service / timeout / resource guard /
> fallback / تله‌متری

**تغییرات (همه فایلِ تازه؛ هیچ فایلِ موجودی تغییر نکرد جز `README.md`
و `trx_ai/__init__.py` برایِ بامپِ نسخه):**

- `trx_ai/phase3/neural_adapter.py` (مرحله‌ی ۲): تنها نقطه‌ی تماس با
  `trx_model` -- `load()`/`unload()` (هیچ‌وقت exception خام؛ همیشه
  `LoadResult`)، `check_compatibility()` (تستِ صریحِ سازگاریِ
  tokenizer/model)، `trial_generate()` (inference آزمایشیِ خام --
  **بدونِ** ساختِ `NeuralAdvice`، چون `task_heads.py` هنوز نیست).
  بارگذاریِ checkpoint اختیاری (`TRX_PHASE3_CHECKPOINT_PATH`) با یک
  لودرِ سبکِ فقط-وزن (بدونِ نیاز به `AdamW` جعلی -- برخلافِ
  `training/checkpoint.load_checkpoint` که برایِ Resume آموزش
  طراحی شده)؛ عدم‌تطابقِ `vocab_size` صریحاً رد می‌شود.
- `trx_ai/phase3/latency_guard.py` (مرحله‌ی ۳): `run_with_timeout()`
  (اجرا در یک ThreadPoolExecutor تک-نخی؛ نکته‌ی صادقانه‌ی مستندشده:
  CPython نمی‌تواند یک Thread را از بیرون بکشد، پس در تایم‌اوت فقط
  کنترل فوراً پس داده می‌شود، نه اینکه نخِ زمینه واقعاً کشته شود) و
  `check_ram_budget()` (بررسیِ RSS با `psutil` -- طبقِ همان الگویِ
  `dependencies.PSUTIL_AVAILABLE` که در سراسرِ پروژه استفاده شده؛ اگر
  psutil نصب نباشد، `measured=False` و مانعِ inference نمی‌شود).
- `trx_ai/phase3/fallback.py` (مرحله‌ی ۳): `FallbackReason` enum
  (`disabled`/`not_loaded`/`load_failed`/`ram_limit`/`timeout`/
  `exception`) + `describe()` برایِ توضیحِ فارسیِ خوانا در لاگ/تله‌متری.
- `trx_ai/phase3/telemetry.py` (مرحله‌ی ۳): `TelemetryLog` -- بافرِ
  محدودِ درون‌حافظه‌ای، هم‌الگو با `core_engine/trace.py`
  (`TraceRecorder`/`TraceLog`)؛ ثبتِ latency/RAM/success/timeout/
  fallback_reason/error برایِ هر inference، به‌اضافه‌ی `summary()`.
- `trx_ai/phase3/inference_service.py` (مرحله‌ی ۳): `Phase3InferenceService.run_trial()`
  -- مسیرِ واحدِ orchestration: بررسیِ فعال‌بودن (اصلِ ۹ سند) -> بررسیِ
  RAM (بخشِ ۲۱) -> اطمینان از بارگذاریِ آداپتور -> اجرا زیرِ timeout ->
  ثبتِ تله‌متری. همیشه `InferenceOutcome` برمی‌گرداند، هیچ‌وقت raise
  نمی‌کند (اصلِ غیرقابلِ‌مذاکره‌ی ۴ سند: «خرابیِ مدل نباید مکالمه را
  متوقف کند»)، و با `TRX_PHASE3_ENABLED=false`/`mode=disabled` بلافاصله
  fallback می‌کند بدونِ لمسِ `trx_model` (اصلِ ۹).
- `trx_ai/phase3/tests/test_phase3_stage2_neural_adapter.py` و
  `test_phase3_stage3_inference_service.py`: ۳۰ تستِ جدید (`unittest`
  استاندارد -- همان دلیلِ نبودِ `pytest` در sandbox). پوشش: چرخه‌ی
  load/unload/reload، رد صریحِ checkpoint با vocab_size ناهم‌خوان،
  `NeuralAdapterNotLoadedError` روی آداپتورِ بارگذاری‌نشده، مسیرهایِ
  disabled/RAM/timeout/load_failed/موفقیت در `Phase3InferenceService`،
  و رفتارِ `TelemetryLog` (bounded، summary). جمعاً با ۲۶ تستِ مرحله‌ی
  ۱: **۵۶ تستِ فاز ۳، همه پاس.**
- بامپِ نسخه به `25.4.8`. جزئیاتِ کامل در `PHASE3_STAGE2_3_NOTES.md`.

**اعتبارسنجی:**
```
python3 -m unittest discover -s trx_ai/phase3/tests -p "test_phase3*" -v
```
۵۶ تست، همه پاس. صفر تغییر در هر فایلِ موجودِ دیگر (بررسیِ دستی --
هیچ چیزی جز `README.md`/`trx_ai/__init__.py` لمس نشد)؛ لایه همچنان به
`core.py`/`intelligence.py`/`trx_ai.conversation` وصل نیست، پس صفر
ریسکِ رگرسیون برایِ رفتارِ زنده‌ی فعلیِ TRX.

---

# v25.4.7 — فاز ۳، مرحله‌ی ۱: schemas + config + feature_builder (`trx_ai/phase3/`)

خواسته: سندِ «TRX Native Neural Cognitive Layer — Phase 3» (P3.0) --
اتصالِ کنترل‌شده‌ی مدلِ عصبیِ بومی به گفتگویِ زنده، طبقِ برنامه‌ی
ده‌مرحله‌ایِ خودِ سند (بخشِ ۱۹). این نسخه فقط **مرحله‌ی ۱** را
پیاده می‌کند: «ساختِ schemas / ساختِ config / ساختِ feature builder /
بدونِ اتصالِ واقعی به Core». هیچ inference، هیچ `neural_adapter.py`،
هیچ اتصال به `trx_model` یا `core.py`/`intelligence.py` در این نسخه
وجود ندارد -- عمداً، طبقِ همان بخشِ ۱۹ سند و اصلِ غیرقابلِ‌مذاکره‌ی ۳
(«Core نباید به مدل وابستگیِ سخت داشته باشد»).

**تغییرات (همه فایلِ تازه؛ هیچ فایلِ موجودی تغییر نکرد جز `README.md`
و `trx_ai/__init__.py` برایِ بامپِ نسخه):**

- `trx_ai/phase3/schemas.py`: `NeuralAdvice` (بخشِ ۷ سند)،
  `FusionDecision` (بخشِ ۸)، `NeuralInputFeatures` (قراردادِ ورودیِ
  آینده‌ی `neural_adapter.py`)، enumهایِ `DiscourseRelation` (بخشِ
  ۵.۲ -- با نگاشتِ مستندشده به `conversation.schemas.TopicRelation`
  موجود)، `ResponseMode` (بخشِ ۵.۶)، `DecisionSource` (بخشِ ۸).
- `trx_ai/phase3/config.py`: `Phase3Config` (frozen dataclass) +
  `get_config()` -- کاملاً env-driven، دقیقاً همان الگویِ
  `trx_ai/conversation/config.py`. کلیدِ حیاتی: پیش‌فرض همیشه
  `enabled=False` / `mode=DISABLED` است (نه `True` مثلِ
  `conversation/config.py`، چون آنجا سامانه از قبل تکمیل و تأیید
  شده بود -- اینجا `neural_adapter.py` هنوز اصلاً وجود ندارد). مودِ
  نامعتبر یا `ENABLED=false` هرگز crash نمی‌کند، همیشه به `DISABLED`
  برمی‌گردد. شش حالتِ بخشِ ۱۱ سند (`disabled` تا
  `controlled_production`) + وظایفِ قابلِ‌تفکیکِ بخشِ ۵ (`ALL_TASKS`).
- `trx_ai/phase3/feature_builder.py`: `build_features()` -- تابعِ
  خالص (بدونِ I/O/state)، `ContextSnapshot` موجودِ
  `trx_ai.conversation.schemas` را می‌گیرد (نه اینکه دوباره بسازد --
  طبقِ اصلِ غیرقابلِ‌مذاکره‌ی سند «فاز ۳ نباید Context Manager مستقل و
  رقیب بسازد») و تاریخچه را هم با سقفِ تعدادِ پیام و هم سقفِ کاراکتر
  محدود می‌کند (`max_history_messages`/`max_history_chars`)، دقیقاً
  طبقِ مسئولیتِ صریحِ سند: «جلوگیری از ارسالِ تاریخچه‌ی بی‌نهایت».
- `trx_ai/phase3/tests/test_phase3_foundation.py`: ۲۶ تستِ واحد
  (`unittest` استاندارد -- `pytest` در sandbox نصب نیست، نگاه کن به
  `working-notes`). پوشش: پیش‌فرضِ امنِ config، مودِ نامعتبر crash
  نمی‌کند، override با متغیرِ محیطی، اعتبارسنجیِ بازه‌ها، تطبیقِ
  enumها با بخش‌هایِ ۵.۲/۵.۶ سند، truncationِ تاریخچه هم با تعداد و
  هم با کاراکتر، پذیرشِ هم `str` و هم `MessageRecord`.
- بامپِ نسخه به `25.4.7`. جزئیاتِ کامل در
  `PHASE3_FOUNDATION_NOTES.md`.

**اعتبارسنجی:** `python3 -m unittest trx_ai.phase3.tests.test_phase3_foundation -v`
→ ۲۶/۲۶ پاس. `import trx_ai.phase3` مستقل از زنجیره‌ی
`aiohttp`-محورِ `trx_ai.conversation.conversation_engine` است (تأییدشده
با importِ جداگانه) -- یعنی صفر وابستگیِ جدید. هیچ فایلِ موجودِ دیگری
لمس نشد؛ ریسکِ رگرسیون صفر است چون هیچ نقطه‌ی ورودیِ موجود (`core.py`،
`turn_processor.py`، `conversation_engine.process`) این پکیج را
import نمی‌کند.

---

# v25.4.6 — فازِ دومِ آموزش: Pipelineِ داده + Smoke Test + Checkpointِ سه‌سطحی (`trx_ai/trx_model/training/data_pipeline/`)

خواسته: سندِ «فازِ دومِ آموزشِ Native Model» -- v25.4.5 موتورِ
Backward/AdamW را فعال کرده بود اما بدونِ pipelineِ دادهِ واقعی
(Cleaning/Dedup/Split سطحِ سند)، بدونِ Smoke Test اجباری، و بدونِ
Checkpointِ اتمیک. این نسخه زنجیره‌یِ کاملِ بخشِ ۲ سند را فعال
می‌کند.

**تغییرات (همه فایلِ تازه؛ هیچ فایلِ v25.4.4/v25.4.5 تغییر نکرد):**

- `trx_ai/trx_model/training/data_pipeline/cleaning.py`: حذفِ خالی/
  کوتاه/HTML/کنترلی + حفظِ نیم‌فاصله + ثبتِ دلیلِ حذف.
- `.../dedup.py`: حذفِ duplicateِ کاملِ سند.
- `.../quality.py`: امتیازِ کیفیت + ردهٔ A/B/C.
- `.../corpus_builder.py`: Corpus v1 از پیکره‌ی واقعیِ پروژه +
  manifest.json.
- `.../split.py`: تقسیمِ سطحِ سند (نه توکن) با Validationِ ثابت.
- `.../tokenizer_report.py` + `.../sequence_packing_check.py`:
  بررسیِ round-trip و شیفتِ target.
- `.../smoke_test.py`: چک‌لیستِ اجباریِ ۱۱-موردی با توقفِ فوری.
- `.../fixed_prompts.py`: مجموعه‌یِ ثابتِ Generation + top-k + لاگِ
  JSONL.
- `.../checkpoint_policy.py`: latest/best/periodic با نوشتنِ اتمیک
  + Resume با هشدارِ ناسازگاری.
- `.../resource_monitor.py`: فضایِ دیسک/RAM/graceful-stop/لاگِ
  چرخشی.
- `.../generalization_test.py`: promptِ دیده‌نشده + تشخیصِ تکرارِ
  بی‌پایان.
- `.../pipeline_runner.py`: هماهنگ‌کننده‌ی مراحلِ ۲.۱ تا ۲.۹.
- `tests/test_native_model_training_phase2.py`: ۲۱ تستِ واحد.
- `scripts/run_phase2_pipeline.py`: اجرایِ end-to-end.
- بامپِ نسخه به `25.4.6`. جزئیاتِ کامل در
  `NATIVE_MODEL_TRAINING_PHASE2_NOTES.md`.

**اعتبارسنجی:** رویِ همان ۲۳ فایلِ `*.md` واقعیِ پروژه: ۵۰۰ پاراگراف
خام -> ۴۹۵ سندِ kept (۵ duplicate حذف) -> ۴۴۵ train/۵۰ validation
(سطحِ سند). Smoke Test: ۱۱/۱۱ پاس. Controlled Training (۱۸۰ step):
train loss ۶.۳۵->۴.۲۷، val loss ۶.۵۵->۵.۰۵ (perplexity ۶۹۹->۱۵۶).
تفسیرِ خودکار: «هم Train و هم Validation کاهش یافتند». Resume:
تطابقِ دقیقِ وزن‌ها. Generalization: بدونِ تکرارِ بی‌پایان. ۲۱ تستِ
جدید + ۲۱ تستِ فازِ اول همه پاس (بدونِ رگرسیون).

---

# v25.4.5 — فعال‌سازیِ چرخه‌ی آموزشِ TRX Native Model (`trx_ai/trx_model/training/`)

خواسته: سندِ «فعال‌سازیِ کاملِ بخشِ عصبیِ TRX Native Model» -- مدلِ
v25.4.4 معماریِ Transformer داشت اما وزن‌هایش تصادفی بودند (هیچ
loss/backward/optimizer). این نسخه چرخه‌ی کاملِ
`Forward->Loss->Backward->Gradients->AdamW->Validation->Checkpoint`
را فعال می‌کند.

**تغییرات (همه فایلِ تازه؛ هیچ فایلِ موجودی تغییر نکرد):**

- `trx_ai/trx_model/training/autograd_cache.py`: `forward_with_cache`
  (بازسازیِ additive Forward + Cache) و `build_param_map`.
- `trx_ai/trx_model/training/losses.py`: Softmax پایدار + Causal
  Cross Entropy + `dLogits`.
- `trx_ai/trx_model/training/backward.py`: Backward تحلیلیِ کامل
  (RMSNorm، SwiGLU، RoPE، Attention، Residual، Embedding Scatter-Add
  + ترکیبِ دو مسیرِ Weight Tying).
- `trx_ai/trx_model/training/optim.py`: Gradient Clipping + AdamW.
- `trx_ai/trx_model/training/dataset.py`: Dataset Builder (Input/
  Target shift-by-one، Train/Val split).
- `trx_ai/trx_model/training/checkpoint.py`: Checkpoint کامل (وزن +
  AdamW state + epoch/step + config + seed) با Resume واقعی.
- `trx_ai/trx_model/training/gradient_check.py`: مقایسه‌ی گرادیانِ
  تحلیلی/عددی.
- `trx_ai/trx_model/training/evaluator.py`: Validation Loss/
  Perplexity/نمونه.
- `trx_ai/trx_model/training/resource_guard.py`: تخمینِ RAM قبل از
  آموزش رویِ گوشی.
- `trx_ai/trx_model/training/trainer.py`: حلقه‌ی کاملِ آموزش.
- `tests/test_native_model_training.py`: ۲۱ تستِ واحد (ده موردِ
  اجباریِ سند + Gradient Check + Tiny Overfit + Resume).
- `scripts/prove_training_cycle.py`: اثباتِ end-to-end رویِ پیکره‌ی
  واقعیِ پروژه.
- بامپِ نسخه به `25.4.5`. جزئیاتِ کامل در
  `NATIVE_MODEL_TRAINING_NOTES.md`.

**اعتبارسنجی:** Gradient Check رویِ همه‌ی پارامترها (max relative
error ۹.۹۰e-۷، تحمل ۱e-۴). Tiny Overfit: Loss از ۳.۰۲ به ۰.۰۰۱۷.
Real-Corpus end-to-end (همان ۲۳ فایلِ `*.md` که توکنایزرِ v25.4.4 هم
ازش استفاده کرد): Validation Loss از ۶.۸۱ به ۵.۲۰ (Perplexity از ۹۰۴
به ۱۸۲) در ۱۲۰ step. بدونِ اینترنت در این نشست، `pytest` نصب نبود؛
منطقِ هر ۲۱ تست به‌صورتِ دستی/مستقیم هم اجرا شد -- همه پاس. هیچ
فایلِ v25.4.4 تغییر نکرد؛ `forward_with_cache` عدداً با
`model.forward` مطابقت دارد (`atol=1e-10`).

---

# v25.4.4 — زیرساختِ مدلِ بومیِ TRX (`trx_ai/trx_model/`)

خواسته: سندِ معماریِ TRX (بخش‌هایِ ۱۱-۱۳) مسیرِ «متن -> Tokenizer ->
Embedding -> Transformer Core -> پیش‌بینیِ توکن -> متن» را به‌عنوانِ
«مدلِ اختصاصیِ TRX» تعریف کرده بود -- یک Model Adapterِ مستقل، قابلِ
آموزشِ بعدی، بدونِ جایگزین‌کردنِ چیزی موجود.

**تغییرات (همه‌ فایلِ تازه؛ هیچ فایلِ موجودی تغییر نکرد):**

- `trx_ai/trx_model/tokenizer.py`: `ByteLevelBPETokenizer` -- BPE
  سطحِ بایت، lossless برایِ هر متنِ UTF-8.
- `trx_ai/trx_model/transformer_core.py`: `RMSNorm`، RoPE
  (`precompute_rope`/`apply_rope`)، `CausalSelfAttention`،
  `SwiGLUFeedForward`، `TransformerBlock`.
- `trx_ai/trx_model/model.py`: `TRXModelConfig`/`TRXNativeModel`
  (forward/generate/save_weights/load_weights).
- `trx_ai/trx_model/interfaces.py`: `ModelInterface` (ABC).
- `trx_ai/trx_model/model_adapter.py`: `TRXNativeModelAdapter`.
- `scripts/train_native_tokenizer.py`: آموزشِ توکنایزرِ پیش‌فرض رویِ
  پیکره‌ی خودِ پروژه (۲۲ فایلِ `*.md`، بدونِ اینترنت) -> خروجی در
  `trx_ai/trx_model/data/tokenizer.json`.
- `tests/test_native_model.py`: ۲۰ تستِ واحد (round-trip، قطعیتِ
  آموزش/ساخت، علّیتِ ماسکِ توجه، حفظِ نُرم توسطِ RoPE، ذخیره/بارگذاریِ
  وزن، قراردادِ `ModelInterface`).
- بامپِ نسخه به `25.4.4`. جزئیاتِ کامل در `NATIVE_MODEL_NOTES.md`.

**اعتبارسنجی:** بدونِ اینترنت در این نشست، `pytest` نصب نبود؛ منطقِ
هر ۲۰ تست به‌صورتِ دستی/مستقیم (بدونِ فریمورک) هم اجرا شد -- همه پاس.
توکنایزر واقعاً رویِ پیکره‌ی پروژه آموزش دید (نه دادهٔ ساختگی) و
round-trip رویِ نمونه تأیید شد. import کاملِ `trx_ai` بدونِ خطا و
بدونِ تغییرِ رفتار بررسی شد.

**عمداً وصل نشده:** `TRXNativeModelAdapter` به `core.py`/
`intelligence.py` هیچ اتصالی ندارد -- این نسخه فقط زیرساخت است.

---

# v25.4.3 — وایرینگِ واقعیِ گیتِ ابهام («بپرس، حدس نزن»)

خواسته: یک Auditِ کاملِ codebase (۲۳۱ فایلِ پایتون) نشان داد
``trx_ai/nlu/disambiguator.py`` -- با اینکه کاملاً پیاده‌سازی و حتی
تست شده بود -- طبقِ اعترافِ صریحِ خودِ فایل «به هیچ UI/core.py وصل
نمی‌شد» (grep روی کلِ پروژه فقط خودِ ماژول و تستِ خودش را نشان داد).
یعنی دقیقاً همان دسته‌ی «Defined but Disconnected» که سندِ ممیزیِ
کاربر (بخشِ «Intent & Routing Forensics») صریحاً برایِ تست خواسته بود.

**تغییرات:**

- `trx_ai/nlu/disambiguator.py`: تابعِ تازه‌ی `match_clarification_reply`
  -- تفسیرِ پاسخِ کاربر به سؤالِ ابهام (نیمه‌ای که قبلاً نبود).
- `trx_ai/core.py`: فیلدِ `self._pending_disambiguation` (هم‌الگو با
  `_pending_correction` موجود).
- `trx_ai/core_engine/tool_router.py`: بعدِ امتیازدهیِ ابزارها، اگر
  دو نامزد نزدیک بودند + IntentEngine خودش مطمئن نبود + امتیازِ مطلق
  کافی بود (آستانه‌ی تازه‌ی `MIN_AMBIGUITY_SCORE` برایِ جلوگیری از
  over-triggering روی نویز) → سؤالِ کوتاه پرسیده می‌شود، اجرا به
  تعویق می‌افتد. نیت‌هایِ حساس (`medical`/`emotional_support`/
  `project_analysis`) صریحاً معاف‌اند.
- `trx_ai/core_engine/turn_processor.py`: پیامِ بعدیِ کاربر یا مستقیم
  match می‌شود، یا (اگر نامشخص بود) با متنِ اصلی ترکیب و به تشخیصِ
  کاملِ نیت سپرده می‌شود -- هیچ‌وقت حدسِ اجباری.
- `tests/test_ambiguity_disambiguation_wiring.py` (تازه، ۷ تستِ
  end-to-endِ رویِ خودِ `TRXEnterpriseAI`) + ۵ تستِ تازه در
  `tests/test_nlu_disambiguation_and_multi_intent.py`.
- بامپِ نسخه به `25.4.3`. جزئیاتِ کامل در
  `AMBIGUITY_GATE_WIRING_NOTES.md`.

**اعتبارسنجی:** بدونِ اینترنت در این نشست (مثلِ چند نشستِ قبلی) --
دو stubِ کمینه برایِ `aiohttp`/`rich` ساختم تا واقعاً بتوانم
`TRXEnterpriseAI` را instantiate و end-to-end تست کنم (نه فقط توابعِ
مجزا). هر ۱۲ تستِ تازه با فراخوانیِ مستقیم پاس شدند؛ هر ۲۰ فایلِ
تستِ موجودِ پروژه بدونِ خطای import لود شدند. اجرایِ کاملِ
`pytest tests/ -q` با وابستگی‌هایِ واقعی هنوز تأیید نشده.

**محدودیتِ آگاهانه:** تطبیقِ پاسخ فقط لغوی/صریح است، نه معنایی --
جزئیات در `AMBIGUITY_GATE_WIRING_NOTES.md`.


# v25.4.2 — تکمیلِ لایه‌ی مشاهده‌پذیری برایِ نوبتِ عکس/فایل

خواسته: طبقِ سندِ ارتقایِ نسلِ بعد (بخشِ ۱۳: «هر درخواست باید شناسه‌ی
trace داشته باشد») و طبقِ Auditِ سخت‌گیرانه‌ای که کاربر داد (بخشِ ۱:
«توهمِ پیشرفت»). این تحویل شاملِ ``trx_ai/core_engine/trace.py`` بود
(``TurnTrace``/``TraceRecorder``/``TraceLog``) که از قبل به‌طورِ کامل
به مسیرِ اصلیِ چت (``TurnProcessor.process_turn``) وصل شده بود -- اما
بدونِ CHANGELOG/notes/بامپِ نسخه، و مهم‌تر: بررسیِ سراسریِ پروژه
(``grep -rn "current_trace"``) نشان داد ``process_image_turn`` و
``process_file_turn`` (نوبت‌هایِ عکس/فایل) هیچ‌وقت trace نمی‌ساختند.
یعنی دستورِ «ردیابی» بعدِ آپلودِ عکس/فایل، رکوردِ نوبتِ متنیِ *قبلی*
را نشان می‌داد -- observabilityِ ادعاشده، نه واقعی.

**تغییرات:**

- `trx_ai/core_engine/turn_processor.py`: ``process_image_turn`` و
  ``process_file_turn`` حالا در ابتدایِ خودشان ``TraceRecorder`` می‌سازند
  (همان الگویِ ``process_turn``). شاخه‌هایِ زودبازگشت (خطایِ اعتبارسنجی،
  خطایِ بهبودِ کیفیت) خودشان ``.mark(error=..., selected_route=...)``
  و ``ai.trace_log.push(...)`` را صدا می‌زنند؛ شاخه‌هایی که به
  ``finalize`` می‌رسند (OCR/بهبودِ کیفیتِ موفق/توصیف/خوانشِ فایل) از
  همان مکانیزمِ موجودِ ``finalize`` بهره می‌برند -- بدونِ هیچ تغییری در
  خودِ ``finalize`` یا ``trace.py``.
- `tests/test_observability_trace.py` (تازه): ۱۲ تست -- ۸ تستِ رفتارِ
  پایه‌ایِ ``TurnTrace``/``TraceRecorder``/``TraceLog``، و ۴ تستِ قفلِ
  دقیقِ همین نقص (نوبتِ عکس/فایلِ نامعتبر حالا trace واقعی می‌سازد،
  ``ai.current_trace`` بعدش پاک می‌شود، و trace نوبت‌هایِ متوالی به هم
  نشت نمی‌کند).
- بامپِ نسخه به `25.4.2` (`trx_ai/__init__.py`). جزئیاتِ کاملِ
  Upgrade Assessment در `OBSERVABILITY_UPGRADE_NOTES.md`.

**اعتبارسنجی:** هر ۲۲ تستِ قبلیِ `test_cognition_core.py` بدونِ تغییر
پاس شدند؛ هر ۱۲ تستِ تازه با فراخوانیِ مستقیمِ تابع پاس شدند؛ کامپایلِ
کلِ پکیج بررسی شد. اجرایِ کاملِ `pytest` (با `aiohttp`/`rich` واقعی)
هنوز تأیید نشده -- محیطِ این نشست دسترسیِ شبکه‌ای برایِ نصبِ آن‌ها
نداشت.

**محدودیتِ آگاهانه:** `TraceLog` هنوز کاملاً درون‌حافظه‌ای است (بدونِ
persistenceِ رویِ دیسک) -- انتخابی عمدی برایِ اجرایِ بدونِ I/O اضافه
روی Android/Pydroid. جزئیات در `OBSERVABILITY_UPGRADE_NOTES.md`.


# v25.4.1 — اتصالِ واقعیِ Communication Profile (رفعِ Dead Code، نه Feature)

خواسته: یک تغییرِ قبلی (بدونِ CHANGELOG/notes) دو تابعِ `reply_hints`/
`communication_profile` را به `response_strategy.py` اضافه کرده بود،
اما طبقِ Auditِ سخت‌گیرانه‌ای که کاربر داد (بخشِ ۱: «توهمِ پیشرفت»)
مشخص شد **هیچ فایلِ دیگری این دو تابع را صدا نمی‌زد** -- کدِ مُرده،
دقیقاً همان الگویی که در ارتقایِ Context Core (v25.4.0) با
`ReasoningEngine.assess`/`context` هم پیدا شده بود.

**تغییرات (اتصالِ واقعی، نه حذف):**

- `response_strategy.py`: `STRATEGY_REPLY_HINTS` از رشته‌یِ تکی به
  `tuple` چند‌نسخه‌ای تغییر کرد (نسخه‌ی اول عیناً همان متنِ قبلی --
  بدونِ رگرسیون برایِ `tool_router.py` که `reply_hint` مفرد را صدا
  می‌زند). `communication_profile` به همه‌یِ راهبردهایِ `STRATEGIES`
  گسترش یافت (قبلاً فقط ۴ تا از ۱۰ راهبرد پوشش داشتند).
- `agent/cognition/response.py`: `ResponseEngine` حالا واقعاً:
  - با `_pick_hint` بینِ نسخه‌هایِ hint بر اساسِ `turn_count`ِ واقعیِ
    Understanding می‌چرخد (که خودش محصولِ ارتقایِ Context Core است --
    قبل از آن همیشه صفر بود، پس این چرخش بی‌معنا می‌ماند).
  - با `_shorten_body` بدنه‌ی نتیجه‌ی ابزارها را کوتاه می‌کند وقتی
    `communication_profile(...)["length"] == "short"` (مثلاً کاربرِ
    خسته/کلافه) -- روی مرزِ پاراگراف/فاصله، نه وسطِ کلمه.
- `tests/test_cognition_core.py`: ۵ تستِ تازه که دقیقاً این دو رفتار
  را قفل می‌کنند، به‌علاوه‌یِ یک تستِ backward-compat برایِ `reply_hint`
  و یک تستِ «مسیرِ خنثی دست‌نخورده می‌ماند».

**اعتبارسنجی:** هر ۲۲ تستِ `test_cognition_core.py` (۱۷ قبلی + ۵ تازه)
با فراخوانیِ مستقیمِ توابع پاس شدند (`pytest`/`aiohttp` در این محیط
بدونِ شبکه نصب‌شدنی نبودند). کامپایلِ کلِ پکیج بررسی شد.

**محدودیتِ آگاهانه:** `_shorten_body` یک سقفِ ثابت (۴۲۰ نویسه) دارد،
نه یک بودجه‌بندیِ پویا بر اساسِ طولِ واقعیِ صفحه‌نمایشِ کاربر --
ارتقایِ بعدی می‌تواند این را به `Context`/دستگاه وصل کند.


# v25.4.0 — اتصالِ واقعیِ Context به حافظه (Core Upgrade، نه Feature)

خواسته: طبقِ سندِ «TRX_AI Upgrade Philosophy» که کاربر داد -- اول
بخش‌هایِ بنیادیِ موجود تقویت شوند، نه اضافه‌کردنِ قابلیتِ تازه. بررسیِ
`trx_ai/agent/cognition/` نشان داد Context دقیقاً همان نقصِ شناخته‌شده‌ی
`ARCHITECTURE.md` را داشت -- اما عمیق‌تر از آن‌چه سند می‌گفت: نه فقط
«فقط entity_stack»، بلکه ``ContextEngine.build`` هیچ‌وقت واقعاً به
``ai.memory.get_relevant_memory``/``get_context``/``current_topic``
سر نمی‌زد (با اینکه این متدها از قبل وجود دارند)، و از آن بدتر --
خودِ ``ReasoningEngine.assess`` پارامترِ ``context`` را می‌گرفت اما
هیچ‌جایِ بدنه‌ی تابع آن را نمی‌خواند؛ یعنی «لایه‌ی Context» ساخته
می‌شد و بعد دور ریخته می‌شد. تنها فراخوانِ واقعیِ ``CognitionCore``
(``AgentBridge.handle_task``، مسیرِ «عامل:») هم هیچ‌وقت ``topic``/
``turn_count``/``previous_failures`` را نمی‌داد و هیچ‌وقت
``ai.memory.resolve_pronoun`` را روی هدف صدا نمی‌زد (برخلافِ مسیرِ
اصلیِ چت در ``tool_router.py`` که این کار را می‌کند).

**تغییرات (Preserve → Improve → Extend، بدونِ Feature تازه):**

- `trx_ai/agent/cognition/context.py`: ``ContextEngine.build`` حالا
  پارامترِ ``query`` می‌گیرد و -- best-effort، کاملاً بی‌صدا در نبودِ
  ``ai`` (بدونِ رگرسیون برایِ فراخوان‌هایِ قدیمیِ بدونِ آرگومان) --
  ``active_topic`` را از ``ai.memory.current_topic``،
  ``recent_history_text`` را از ``ai.memory.get_context(...)``
  (سقفِ ۸۰۰ نویسه، طبقِ فلسفه‌یِ Context Budgeting)، و
  ``long_term_hint`` را از ``ai.memory.get_relevant_memory(query)``
  پُر می‌کند.
- `trx_ai/agent/cognition/__init__.py`: ``CognitionCore.run`` هدف را
  به‌عنوانِ ``query`` به ``ContextEngine.build`` می‌دهد.
- `trx_ai/core_engine/agent_bridge.py`: ``AgentBridge.handle_task``
  حالا (۱) ``ai.memory.resolve_pronoun`` را روی هدف اجرا می‌کند --
  دقیقاً همان تابعِ آزمایش‌شده‌ای که مسیرِ اصلیِ چت از قبل استفاده
  می‌کند -- تا «عامل: قیمتش رو حساب کن» بعدِ یک سؤالِ قبلی به Entityِ
  درست وصل شود، و (۲) ``topic``/``turn_count``/``previous_failures``
  را (از ``ai.memory``/``ai.user_state_memory.recent_failures()``،
  همان الگویِ ``tool_router.py``) به ``CognitionCore.run`` می‌دهد.
- `trx_ai/agent/cognition/reasoning.py`: ``ReasoningEngine.assess``
  حالا واقعاً ``context`` را می‌خواند -- ``rationale`` هر شاخه با
  موضوعِ فعال/تعدادِ شکست‌هایِ اخیر/وجودِ سرنخِ حافظه غنی می‌شود.
  عمداً *فقط* rationale (نه منطقِ انتخابِ ابزار) تغییر کرده -- ریسکِ
  رفتاریِ صفر، همه‌ی ۱۴ تستِ قبلیِ `test_cognition_core.py` بدونِ
  تغییر پاس می‌شوند.
- `tests/test_cognition_core.py`: ۳ تستِ تازه که این دو نقص را قفل
  می‌کنند (وگرنه در آینده به‌راحتی دوباره رگرسیون می‌کنند).

**اعتبارسنجی:** ``pytest``/``aiohttp`` در محیطِ توسعه‌ی این نشست
نصب‌شدنی نبودند (بدونِ دسترسیِ شبکه)، پس همه‌یِ ۱۷ تستِ
`test_cognition_core.py` مستقیماً با فراخوانیِ تابع (بدونِ‌ pytest)
اجرا و پاس شدند؛ کامپایلِ همه‌یِ فایل‌هایِ تغییریافته هم بررسی شد.
اجرایِ کاملِ `pytest` روی کل پروژه (شاملِ فایل‌هایی مثلِ
`test_agent_loop.py` که به fixtureهایِ pytest نیاز دارند) هنوز تأیید
نشده -- در محیطی با ``requirements-dev.txt`` نصب‌شده باید اجرا شود.

**محدودیتِ آگاهانه:** بخشِ ۵ی ReasoningEngine (شاخه‌یِ پیش‌فرضِ
NEVER_USE_WEB_BY_DEFAULT) عمداً تغییرِ رفتاری نگرفت -- چون
``CognitionReflector``/Replan-with-web (از ``v25.3.0``) از قبل دقیقاً
همین سناریو (شکستِ تکراری) را در سطحِ بالاتر پوشش می‌دهد؛ اضافه‌کردنِ
یک مسیرِ دومِ escape در Reasoning هم‌زمان با آن، پیچیدگیِ غیرضروری
بود (بخشِ ۱۸، سؤالِ ۴ سندِ ارتقا). ``ContextEngine`` هنوز به
``Scratchpad``/نتایجِ ابزارهایِ *همین اجرا* هم وصل است (بدونِ تغییر)،
ولی به تاریخچه‌ی کاملِ چندنوبتیِ *پیش از* شروعِ هدفِ عامل هنوز محدود
به ۶ پیامِ آخر است -- ارتقایِ بعدی می‌تواند این سقف را قابلِ‌تنظیم کند.


# v25.3.1 — رفعِ باگِ Web-First در مسیرِ اصلیِ گفتگو (نه Agent Loop)

خواسته/گزارش: کاربر نشان داد که پیامِ صرفاً احساسیِ «خیلی خسته شدم»
(بدونِ هیچ پیشوندِ «عامل:») به‌جایِ پاسخِ هم‌دلانه، به DuckDuckGo
فرستاده شد. این نشان داد که رفعِ Web-First در `v25.3.0` فقط مسیرِ
Agent Loop (پشتِ پیشوندِ «عامل:») را پوشش می‌داد -- مسیرِ اصلیِ چت
(اکثریتِ قریب‌به‌اتفاقِ پیام‌ها) یک باگِ کاملاً جداگانه داشت.

**ریشه‌ی باگ** (در `core.py`، بخشِ «پاسخِ عمومی»): `wiki_answer` فقط
وقتی `looks_like_question` باشد امتحان می‌شد، اما بلوکِ DuckDuckGoی
بعدش (`else: ...`) هیچ چکی رویِ `looks_like_question` نداشت -- یعنی
هر پیامی که نه SmallTalk بود نه شکلِ یک پرسش داشت (مثلِ یک جمله‌ی
صرفاً احساسی)، وقتی `wiki_answer` خالی می‌ماند (چون اصلاً امتحان نشده
بود)، بی‌قیدوشرط به DuckDuckGo فرستاده می‌شد.

**اصلاح:** بلوکِ فراخوانیِ DuckDuckGo حالا خودش هم داخلِ
`if looks_like_question:` قرار گرفت -- دقیقاً همان اصلِ
NEVER_USE_WEB_BY_DEFAULTِ سندِ Cognition Core Upgrade، این‌بار در
مسیرِ اصلیِ چت. با این اصلاح، «خیلی خسته شدم» حالا به‌جایِ DuckDuckGo،
از طریقِ زنجیره‌ی موجودِ `local_empathetic_reply` → `user_state`
Engine → `response_strategy` یک پاسخِ هم‌دلانه (`«می‌فهمم. اگه دوست
داری می‌تونیم یه کم مکث کنیم و بعد ادامه بدیم.»`) می‌گیرد -- بدونِ
هیچ تماسِ شبکه‌ای.

**محدودیتِ آگاهانه:** این یک اصلاحِ نقطه‌ای/surgical است، نه
یکپارچه‌سازیِ کاملِ `ReasoningEngine` (از `v25.3.0`) با مسیرِ اصلیِ
چت. یکپارچه‌سازیِ کامل (استفاده از همان `ReasoningEngine` برایِ *هر*
پیام، نه فقط اهدافِ پشتِ «عامل:») یک فازِ بزرگ‌ترِ جداگانه است.



# v25.3.0 — Cognition Core Upgrade (AI Core > Agent > Tools)

خواسته: یک لایه‌یِ مرکزیِ جدید بالایِ Agent Loop موجود تا TRX «یک AI که
در صورتِ نیاز از Web استفاده می‌کند» باشد، نه «یک مرورگرِ هوشمند» --
اصلِ بنیادی: AI CORE > AGENT > TOOLS، نه WEB > AGENT > ANSWER.

جزئیاتِ کامل در `COGNITION_CORE_NOTES.md`. خلاصه:

- `trx_ai/agent/cognition/` (پکیجِ جدید، هشت ماژول): `state.py`
  (`CognitionState`/`CognitionStateTracker`، ۱۱ حالتِ قابلِ‌دیباگ)،
  `understanding.py` (سوار بر `IntentEngine`/`understanding.py`
  موجود + طبقه‌بندیِ نوعِ درخواست)، `context.py` (`ContextEngine`،
  ترکیبِ Scratchpad + موضوعِ فعال)، `reasoning.py`
  (`ReasoningEngine` -- پیاده‌سازیِ `NEVER_USE_WEB_BY_DEFAULT`: Web
  فقط برایِ نیازِ صریح/زنده مجاز است، نه پیش‌فرض)، `planning.py`
  (`PlanningEngine` -- تجزیه‌ی اهدافِ چندمرحله‌ای)، `decision.py`
  (`AgentController` -- اجرایِ هر گام رویِ `AgentLoop` موجود، با
  تزریقِ پیشنهادِ Reasoning از طریقِ همان قلابِ `llm_decide`ی
  `planner.py`)، `reflection.py` (`CognitionReflector` -- بررسیِ
  واقعیِ نتیجه + یک‌بار Replan-با-Web وقتی نبودِ Web علتِ شکست بود)،
  `response.py` (`ResponseEngine` -- پاسخِ طبیعی).
- `CognitionCore` (در `__init__.py`): هماهنگ‌کننده‌ی نهایی، خروجی‌اش
  دقیقاً همان `AgentTrace` قبلی است.
- `core.py`: `_handle_agent_task` حالا `CognitionCore` را به‌جایِ
  مستقیماً `AgentLoop` صدا می‌زند -- تنها یک نقطه‌ی تغییر، بقیه‌ی
  مسیر (نمایشِ trace، ثبتِ تاریخچه) دست‌نخورده.
- `tests/test_cognition_core.py` (تست‌هایِ جدید، آفلاین): مثال‌هایِ
  رفتاریِ TEST1/TEST2/TEST5/TEST6 سندِ ارتقا + تستِ صریحِ «بدونِ Web»
  (بخشِ ۲۱ سند).

**محدودیت‌هایِ آگاهانه:** بنچمارکِ رسمیِ ۳۰-موردیِ بخشِ ۱۹ سند نوشته
نشد؛ `ContextEngine` هنوز به تاریخچه‌ی کاملِ مکالمه/حافظه‌ی بلندمدت
وصل نیست (فقط `entity_stack`)؛ `Replan` فقط برایِ حالتِ خاصِ «نبودِ
Web» است، نه عمومی. جزئیاتِ کامل و جدولِ Definition-of-Done در
`COGNITION_CORE_NOTES.md`.



# v25.2.0 — مکانیزمِ تصمیم‌گیریِ خودمختار (Autonomous Agent Loop)

خواسته: یک حلقه‌ی عامل که هوش مصنوعی بتواند خودش ابزارها (وب، بینایی،
پایگاه‌دانش، ماشین‌حساب، فایل، ...) را به‌صورتِ زنجیره‌ای برایِ حل‌کردنِ
یک مسئله صدا بزند، بدونِ اینکه کاربر تک‌تکِ مراحل را دستی فرمان دهد --
حرفه‌ای و ماژولار، با ماژول‌هایِ تخصصیِ جدا.

جزئیاتِ کامل در `AGENT_LOOP_NOTES.md`. خلاصه:

- `trx_ai/agent/` (پکیجِ جدید، هفت ماژول): `types.py` (dataclass/Enum
  مشترک)، `tool_registry.py` (`AgentTool`/`ToolRegistry` +
  `build_default_registry()` -- آداپتورِ نازک رویِ موتورهایِ *موجودِ*
  `tools.py`/`vision.py`/`database.py`/`tasks.py`، بدونِ بازنویسیِ
  منطقِ ابزار)، `planner.py` (`HeuristicPlanner` کاملاً محلی +
  قلابِ اختیاریِ `llm_decide` برایِ یک LLM آینده)، `guardrails.py`
  (`LoopGuard`: سقفِ گام/زمان/تکرارِ عینی/allow-list)، `memory.py`
  (`Scratchpad` -- حافظه‌ی کاریِ فقط‌طولِ‌یک‌اجرا، جدا از
  `MemoryEngine`)، `reflection.py` (`StepReflector`، سوار بر
  `intelligence.ReflectionEngine` موجود)، `loop.py` (`AgentLoop`:
  هماهنگ‌کننده‌ی plan→act→guard→observe→reflect).
- `core.py`: پیشوندِ فعال‌سازیِ جدیدِ `عامل: <هدف>` (یا `/agent `) در
  `_process_turn`، کنارِ بقیه‌ی دستورهایِ پیشوندیِ موجود -- بدونِ
  تغییرِ هیچ مسیرِ مسیریابیِ قبلی. متدهایِ جدید:
  `_extract_agent_goal`، `_get_agent_registry` (lazy، نیازمندِ
  `self.session`)، `_handle_agent_task` (اجرایِ `AgentLoop` + نمایشِ
  trace + ثبتِ تاریخچه از طریقِ همانِ `_finalize` موجود).
  `_process_image_turn`: یک خطِ افزوده (`self._last_image_path`) تا
  ابزارِ `vision`یِ عامل بداند رویِ کدام عکسِ همین جلسه کار کند.
- `tests/test_agent_loop.py` (تست‌هایِ جدید، آفلاین/بدونِ شبکه با
  ابزارهایِ stub): امتیازدهی/رتبه‌بندیِ ابزار، `run_safe` (هیچ استثنایی
  از ابزار بیرون نمی‌رود)، هر چهار نوعِ گاردریل جداگانه،
  `Scratchpad`، و شش سناریویِ سرتاسریِ `AgentLoop` (تک‌ابزاره،
  زنجیره‌یِ چندابزاره، توقفِ بودجه، بقا پس از خطایِ ابزار، هدفِ خالی،
  عدمِ تطابقِ ابزار).

**محدودیت‌هایِ آگاهانه:** `HeuristicPlanner` کاملاً کلیدواژه‌ای است (نه
LLM-driven) -- دقیقاً به همان فلسفه‌یِ «بدونِ نیاز به کلید» که در
README هست؛ قلابِ `llm_decide` برایِ ارتقایِ بعدی از قبل در طراحیِ
`planner.py` جا گذاشته شده. جزئیاتِ کامل در `AGENT_LOOP_NOTES.md`.


# v25.1.0 — قابلیتِ سراسریِ تصویر (ارسال/دیدن/OCR/بهبودِ کیفیت)

## دیدن/خواندنِ عکس در کلِ پروژه (نه فقط بخشِ پزشکی)

خواسته: امکانِ ارسالِ عکس در چت + سه ابزارِ مجزا رویِ آن (خواندنِ
محتوا، جداکردنِ متن، بالابردنِ کیفیت) — به‌شکلِ ابزارهایِ واقعی در کد،
نه یک ترفندِ یک‌باره.

- `trx_ai/vision.py` (جدید): `ImageEngine` با چهار متدِ مستقل:
  - `save_incoming` — اعتبارسنجیِ نوع/حجم (سقف ۱۵ مگابایت) + ذخیره‌ی امن.
  - `describe` — «ابزارِ خواندنِ تصویر»: پرسیدن از Gemini Vision (متن+عکس
    روی همان endpointِ `generateContent` که `llm_engine.py` از قبل
    برایِ گفتگویِ متنی استفاده می‌کرد؛ هیچ endpoint/کلیدِ جدایی لازم
    نبود).
  - `read_text` — «ابزارِ جداکردنِ متن» (OCR): اول Gemini Vision (دقیق‌تر
    برایِ عکسِ واقعی/کج)، اگر نبود به `pytesseract` محلی سقوط می‌کند
    (اختیاری -- نگاه کنید به `dependencies.OCR_AVAILABLE`)، اگر آن هم
    نبود صادقانه می‌گوید هیچ‌کدام در دسترس نیست.
  - `enhance_quality` — «ابزارِ زیادکردنِ کیفیت»: کاملاً محلی و بدونِ
    اینترنت (PIL: بزرگ‌نماییِ Lanczos + Unsharp Mask + کنتراست)؛
    ابرِرزولوشنِ AI نیست، فقط بهترینِ پردازشِ کلاسیکِ ممکن بدونِ
    وابستگیِ سنگین/GPU.
- `llm_engine.py`: متدِ جدیدِ `LLMEngine.generate_with_image()` (متن+عکس
  در یک درخواست)؛ منطقِ retry/backoفف بینِ آن و `generate()` قدیمی به
  یک متدِ مشترک (`_call_generate_content`) رفاکتور شد تا دوباره‌نویسی
  نشود.
- `core.py`: `_process_image_turn()` — همتایِ `_process_turn` برایِ
  عکس؛ کپشنِ همراهِ عکس تعیین می‌کند کدام ابزار اجرا شود («متن...» →
  OCR، «کیفیت...» → بهبود، وگرنه توصیف/پاسخ به سؤال).
- `ui.py` / `gui_ui_engine.py`: متدِ `show_image()` به هر دو (ترمینال
  فقط مسیرِ فایل را چاپ می‌کند؛ رابطِ وب رویدادِ `image` می‌فرستد).
- `webserver.py`: نوعِ پیامِ جدیدِ `"image"` رویِ WebSocket (Base64)،
  مسیرِ استاتیکِ `/files/` برایِ نمایشِ عکس‌ها، افزایشِ سقفِ حجمِ پیام.
- `web_assets.py`: دکمه‌ی 📷، پیش‌نمایشِ فوریِ عکسِ کاربر، رندرِ حبابِ
  عکسِ پاسخ.

**محدودیت‌هایِ آگاهانه:**
- فقط رابطِ وب سیم‌کشی شد (طبقِ درخواستِ صریحِ کاربر)؛ GUI/CLI هنوز
  راهِ ارسالِ عکس ندارند، هرچند `core.py`/`vision.py` مستقل از رابط‌اند
  و افزودنش بعداً کارِ کمی می‌برد.
- عکس مستقیم Base64 در بدنه‌ی JSON فرستاده می‌شود (نه Files APIِ گوگل)
  — برایِ عکسِ معمولیِ موبایل مناسب است، نه فایل‌هایِ خیلی حجیم.
- تست شد (بدونِ نیاز به شبکه‌ی واقعی، با mockِ پاسخِ Gemini + یک
  Tesseract-OCR واقعاً نصب‌شده روی محیطِ توسعه): ذخیره/اعتبارسنجی،
  بزرگ‌نماییِ واقعیِ ۲برابر، تشخیصِ نیت از کپشن، ساختِ payloadِ
  چندرسانه‌ای، و هر سه مسیرِ fallbackِ OCR (Gemini موفق /Gemini
  ناموفق+OCR محلی موفق /هیچ‌کدام نصب نیست).

---



- Added `runtime_intelligence.py` as a dependency-free runtime control layer.
- Added input normalization and duplicate-request detection.
- Added bounded context construction for memory + conversation patterns + history.
- Added lightweight response quality gating.
- Added retry/backoff for transient Gemini HTTP/network failures.
- Removed the API-key placeholder from `main.py`; secrets stay outside source code.
- Added `tests/test_runtime_intelligence.py`.

## امنیت: رمزنگاریِ در سطحِ ذخیره‌سازی برایِ داده‌هایِ حساس (v24.2 → v24.3)

بازبینیِ کدِ موجود نشان داد یک شکافِ واقعی وجود دارد: دفترچه‌ی سلامت،
برنامه‌ی دارویی، حقایقِ شخصیِ حافظه (`memory_correction`) و کلِ جدولِ
`profile` همیشه به‌صورتِ کاملاً خام (plaintext) در فایلِ SQLite روی
دیسک ذخیره می‌شدند — درحالی‌که پروژه از قبل یک ماژولِ رمزنگاریِ حرفه‌ای
(`text_crypto.py`، Fernet + PBKDF2) داشت که فقط به‌صورتِ یک دستورِ
دستی («این متن را رمزنگاری کن») در دسترس بود، نه رویِ خودِ دیتابیس.

طبقِ انتخابِ کاربر (سادگی به قیمتِ کاهشِ امنیت در برابرِ سرقتِ کاملِ
دستگاه، اما محافظت در برابرِ نشتِ تصادفی/بکاپِ ابری/بازرسیِ سطحی):

- یک کلیدِ اصلیِ تصادفی خودکار ساخته و در فایلِ جداگانه‌ای (پیش‌فرض:
  `trx_ai_db.key`، با مجوزِ ۰۶۰۰ در یونیکس) ذخیره می‌شود — نه از رویِ
  رمزِ عبورِ کاربر، چون قرار است بدونِ پرسیدن هربار کار کند.
- `DatabaseManager.get_profile` / `set_profile` / `get_profile_by_prefix`
  اکنون به‌طور شفاف مقدارها را رمزنگاری/رمزگشایی می‌کنند؛ چون همه‌ی
  قابلیت‌های جدید (دفترچه‌ی سلامت، برنامه‌ی دارویی، تصحیحِ حافظه) از
  همین سه تابع استفاده می‌کنند، این یک نقطه‌ی تغییر همه را پوشش می‌دهد.
- **سازگاریِ عقب‌رو:** ردیف‌هایِ قدیمیِ رمزنشده هنوز قابلِ‌خواندن‌اند؛
  با اولین بازنویسیِ همان کلید، خودکار رمز می‌شوند (مهاجرتِ تنبل/lazy).
- **در دسترسِ محدود:** اگر `cryptography` نصب نباشد یا ساختِ فایلِ کلید
  ناموفق باشد، دیتابیس دقیقاً مثلِ قبل (بدونِ رمزنگاری، با یک هشدارِ
  روشن در لاگ) کار می‌کند — هیچ رفتاری نمی‌شکند.
- **محدودیتِ آگاهانه:** جدولِ `history` (گفتگوهایِ خام) و `expenses`
  رمزنگاری نشدند، چون کوئری‌زدن رویِ ستون‌هایِ رمزشده (جستجویِ متنی،
  فیلترِ مبلغ) بدونِ طراحیِ اضافی می‌شکند؛ این می‌تواند یک ارتقایِ جداگانه
  باشد.
- تست شد: مقدارِ رمزشده در فایلِ خامِ دیتابیس اصلاً پیدا نمی‌شود (بررسیِ
  مستقیمِ بایت‌ها)، رمزگشاییِ بعدِ ری‌استارت درست کار می‌کند، ردیفِ
  قدیمیِ رمزنشده هنوز خوانده می‌شود، و بدونِ نصبِ `cryptography` برنامه
  بدونِ خطا (فقط بدونِ رمزنگاری) اجرا می‌شود.
- `.gitignore` اضافه شد تا فایلِ کلید (`*.key`) و دیتابیس (`*.db`) هرگز
  به‌اشتباه در گیت/اشتراک‌گذاری قرار نگیرند.

## ارتقاءِ عملکردی: هسته‌ی ++C برای تشخیصِ نیت (v24.1 → v24.2)

طبقِ درخواستِ صریح («فقط هسته‌ای که فشار روشه به ++C تبدیل شه، بقیه
پایتون بمونه»)، پیش از هر تغییری واقعاً اندازه‌گیری شد که کدام بخش
زیرِ فشار است — نه حدس زده شد. نتیجه: `IntentEngine.detect_intent`
(اجرا روی **هر پیامِ ورودی**، بدونِ استثنا) به‌طور میانگین ۶۵۰
میکروثانیه طول می‌کشید، چون تا ۱۵۶ کلیدواژه در ۲۱ نیت را بدونِ cache
و با ساختِ regex تازه برایِ هر کلیدواژه بررسی می‌کرد.

- افزوده شد: `trx_ai/native/intent_native.cpp` — بازنویسیِ همان حلقه
  به ++C (مستقیم با CPython C API، بدونِ نیاز به نصبِ pybind11).
- `intelligence.py` اکنون اگر ماژولِ کامپایل‌شده پیدا شود از آن
  استفاده می‌کند، وگرنه بی‌صدا به نسخه‌ی پایتونیِ قبلی برمی‌گردد — هیچ
  رفتاری برایِ کاربر عوض نمی‌شود، فقط سریع‌تر می‌شود.
- **نتیجه‌ی اندازه‌گیری‌شده:** ~۶۵۰ → ~۴۶ میکروثانیه به ازای هر پیام
  (~۱۴ برابر سریع‌تر برایِ این بخش).
- **صحت:** هر ۲۹ موردِ `tests/test_intent_engine.py` + یک fuzz-testِ
  ۶۵٬۲۰۸ جفتِ (متن، کلیدواژه) خروجیِ کاملاً یکسان با نسخه‌ی پایتونیِ
  قبلی می‌دهند (شاملِ یک اشکالِ ظریفِ محاسبه‌ی پنجره‌ی نفی بر حسبِ
  بایت به‌جایِ کاراکتر که در همین فرایند پیدا و اصلاح شد).
- ساخت اختیاری است؛ راهنما در `trx_ai/native/README.md`.

## ارتقاءِ هوشمند (v24 → v24.1): فعال‌سازیِ دو قابلیتِ نیمه‌کاره + تنظیمِ دقتِ تشخیصِ پزشکی

نسخه‌ای که آپلود شد («memory_corrected») دو ماژول/متد داشت که نوشته
شده بودند اما **هیچ‌جایِ برنامه صدا زده نمی‌شدند** — یعنی عملاً بی‌اثر
بودند. این ارتقا آن‌ها را واقعاً به مسیرِ اجرا وصل کرد:

- **`memory_correction.py` (قبلاً کاملاً استفاده‌نشده):** به یک موتورِ
  واقعی تبدیل شد که در `MemoryEngine` (`memory_store.py`) سیم‌کشی شده:
  - خاطرات/حقایق اکنون در دیتابیسِ کاربر پایدار می‌مانند (قبلاً فقط
    در RAM بودند و با هر اجرایِ تازه از بین می‌رفتند).
  - **تشخیصِ تضاد:** اگر کاربر یک حقیقتِ متناقض با حقیقتِ قبلی بگوید
    (مثلاً تغییرِ اسم یا پروژه‌ی فعلی)، نسخه‌ی قدیمی به‌طور خودکار
    «منسوخ» می‌شود و دیگر در پاسخ‌های بعدی همراهِ نسخه‌ی جدید و
    گیج‌کننده ظاهر نمی‌شود (پیش‌تر هر دو برایِ همیشه با هم برمی‌گشتند).
  - `MemoryEngine.get_relevant_memory` اکنون فقط حقایقِ فعلاً معتبر را
    برمی‌گرداند، نه هر حقیقتی که تا به‌حال گفته شده.
- **`adaptive_questionnaire` / `confidence_questions_needed` در
  `medical.py` (قبلاً تعریف‌شده اما هرگز صدا زده نمی‌شد):** اکنون در
  `handle_medical_query_online` وصل شده‌اند؛ وقتی گفتگویِ بله/خیرِ
  محلی به نتیجه‌ی روشنی نرسد، به‌جایِ سکوت، چند سؤالِ ساختاریافته
  (سن، مدت، شدت، سابقه) هم به کاربر پیشنهاد می‌شود.
- **دقتِ تشخیصِ پزشکی بالاتر رفت:** سقفِ سؤال‌هایِ پیگیریِ بله/خیر از
  ۴ به ۷ و آستانه‌ی اطمینانِ لازم برایِ توقفِ زودهنگام از ٪۶۵ به ٪۸۰
  افزایش یافت — موتور ترجیح می‌دهد چند سؤالِ بیشتر بپرسد تا با
  اطمینانِ بالاتری جواب بدهد.

## سختگیریِ امنیتی پس از ممیزیِ کد (بدون تغییر در قابلیت‌هایِ مستند)

- **`webserver.py`**: یک توکنِ اختیاری (`TRX_WEB_TOKEN`) اضافه شد.
  پیش‌فرض (بدونِ تنظیمِ آن) دقیقاً رفتارِ قبلی حفظ شده. اما اگر میزبان
  غیرِ‌لوکال باشد (`TRX_WEB_HOST=0.0.0.0`) و توکنی هم تنظیم نشده باشد،
  یک توکنِ موقت به‌صورتِ خودکار ساخته و در کنسول/لاگ نمایش داده می‌شود —
  قبلاً در این حالت هر کسِ دیگری رویِ همان شبکه بدونِ هیچ محدودیتی وصل
  می‌شد.
- **`security.py`**: تابعِ جدیدِ `restricted_builtins()` — یک نسخه‌ی
  محدودشده از builtins که در `interpreter.py` و `plugins.py` به‌جایِ
  `__builtins__` کاملِ پایتون به exec() تزریق می‌شود. `find_dangerous_pattern`
  اکنون همچنین دسترسی به هر attributeِ dunder (`__class__`,
  `__subclasses__`, `__globals__`, ...) را مسدود می‌کند — مسیرِ
  شناخته‌شده‌ی دورزدنِ sandboxهایِ لیست‌سیاه-محور که قبلاً پوشش داده
  نشده بود. `eval`/`exec`/`compile` (که کلیدواژه‌هایِ مستندِ زبان
  هستند: ارزیابی/اجرا/کامپایل) حذف نشده‌اند، فقط Wrap شده‌اند تا محتوایِ
  رشته‌ای‌شان در لحظه‌ی اجرا هم از همان بررسی رد شود.
- **`requirements.txt`**: پین‌هایِ بازِ `>=` به `~=` (compatible release)
  تغییر کردند تا یک نسخه‌ی جدیدِ اصلی/breaking به‌طورِ خاموش نصب نشود،
  بدونِ آنکه انعطافِ لازم برایِ پیداکردنِ wheel رویِ اندروید/Termux از
  بین برود.

## نسخه‌ی v20.22 — رفعِ باگِ «قفل‌شدنِ دکمه‌ی ارسال» در رابطِ وبِ جدید

خودِ کاربر یک رابطِ کاربریِ وبِ کاملاً جدید (`webserver.py` +
`web_assets.py`) اضافه کرد — معماریِ هوشمندانه‌ای: aiohttp (که از قبل
CORE پروژه است) به‌جایِ PySide6، پس دیگر نیازی به AsyncBridge/سیگنالِ
Qt نیست و رویِ Pydroid3/اندروید هم بدونِ هیچ وابستگیِ گرافیکیِ جدید کار
می‌کند. `GuiUIEngine` عیناً (بدونِ تغییر) قرض گرفته شده، پس هیچ باگی که
در مسیریابیِ core.py رفع شده دوباره ظاهر نمی‌شود — دقیقاً همان فلسفه‌ای
که خودِ پروژه قبلاً برایِ gui_app.py هم داشت.

### باگِ پیدا‌شده و رفع‌شده
دکمه‌ی ارسال در رابطِ وب فقط با دیدنِ رویدادهایِ خاص
(`message`/`emergency`/`followup`/`stream_end`) دوباره فعال می‌شد.
دستورهایی که فقط از طریقِ `self.ui.console.print(...)` خروجی می‌دهند —
دقیقاً «آمار»، «داشبورد»، و «تاریخچه» که خودِ همان سه میانبرِ نوارِ
پایین‌اند، به‌علاوه‌ی «در مخفی» — فقط یک رویدادِ `raw` تولید می‌کنند.
نتیجه: با یک کلیکِ ساده رویِ «📊 آمار»، دکمه‌ی ارسال برایِ همیشه
غیرفعال می‌ماند (تا رفرشِ صفحه) — همان کلاسِ باگی که در gui_app.py
(v20.18/v20.19) دو بار پیدا و رفع شده بود، اینجا به شکلِ دیگری دوباره
ظاهر شده بود.

راه‌حل: به‌جایِ حدس‌زدن از رویِ نوعِ رویداد، سرور حالا همیشه (چه نوبت
موفق تمام شود چه با خطا) یک رویدادِ صریحِ `turn_end` می‌فرستد؛ کلاینت
فقط با دیدنِ همین یک رویداد دکمه را دوباره فعال می‌کند.

### دو رگرسیونِ کناری که هنگامِ ردیابیِ همین باگ پیدا شدند
- **رِیسِ init**: اگر دو کلاینت تقریباً هم‌زمان وصل می‌شدند، هردو ممکن
  بود از رویِ چکِ `if not app["initialized"]` رد شوند و `init_for_gui`
  را دوبار و هم‌زمان اجرا کنند (مثلاً دو `aiohttp.ClientSession` ساخته
  می‌شد). با `asyncio.Lock` رفع شد.
- **رِیسِ نوبت‌ها**: هیچ‌چیزِ سمتِ سرور جلویِ اجرایِ هم‌زمانِ دو
  `_process_turn` روی همان `app_core`ی مشترک را نمی‌گرفت (فقط سمتِ
  کلاینت دکمه غیرفعال می‌شد، که یک کلاینتِ دیگر/تبِ دیگر را نمی‌گیرد —
  این رابط عمداً چندکاربره طراحی شده). با یک `asyncio.Lock` دیگر که
  نوبت‌ها را در کلِ سرور صف می‌کند، رفع شد.

## نسخه‌ی v20.21 — تکمیلِ بازطراحیِ GUI + رفعِ رگرسیونِ دو باگِ قبلی

بازطراحیِ ظاهریِ GUI (تمِ رنگی، حباب‌هایِ گفتگو، هدر، نوارِ میانبرها،
رفعِ بید‌ای/RTL) قبلِ این نسخه توسطِ خودِ کاربر انجام شده بود — کارِ
خوبی بود. مشکل: این بازطراحی رویِ نسخه‌ای انجام شده بود که هنوز دو
رفعِ باگِ بعدی (v20.19، v20.20) را نداشت، پس هردو دوباره برگشته بودند:

### رگرسیون‌هایی که برگردانده شدند
- **صفحه‌ی سفید هنگامِ باز شدن (v20.19)**: `__init__` دوباره پیش از
  `window.show()` با `.result(timeout=30)` نخِ GUI را بلاک می‌کرد.
  دوباره اصلاح شد: `__init__` سریع برمی‌گردد، `init_for_gui` و
  گفتگویِ نام با `QTimer.singleShot(0, ...)` به بعد از نمایشِ پنجره
  موکول شدند (سیگنالِ جدیدِ `_init_finished` برایِ برگشتِ امن به نخِ
  GUI).
- **کرش هنگامِ بستنِ پنجره حینِ کار (v20.20)**: پرچمِ `self._closing`
  دوباره اضافه شد و در `_on_turn_finished`، `_on_init_finished`، و
  `_drain_events` چک می‌شود.

### پرداخت‌هایِ جدید رویِ همان بازطراحی
- دکمه‌هایِ میانبر هم مثلِ ورودی/دکمه‌ی ارسال، تا پایانِ آماده‌سازیِ
  اولیه غیرفعال می‌مانند (قبلاً هیچ‌کدام غیرفعال نمی‌شدند، یعنی می‌شد
  قبل از تمام‌شدنِ init_for_gui رویِ یک میانبر کلیک کرد).
- یک حبابِ خوش‌آمدگوییِ اولیه، بعدِ اتمامِ موفقِ راه‌اندازی.
- دکمه‌ی 🗑️ برایِ پاک‌کردنِ صفحه‌ی گفتگو (فقط نمایش؛ حافظه‌ی TRX AI
  دست‌نخورده می‌ماند).
- فوکسِ خودکارِ ورودی بعدِ هر پاسخ، تا کاربر مجبور نباشد دوباره رویِ
  کادر کلیک کند.
- Tooltip رویِ دکمه‌ی ارسال، چک‌باکسِ صوتی، و دکمه‌هایِ میانبر.

## نسخه‌ی v20.18 — رفعِ باگِ «فقط یک پیام در GUI»

باگ: توی رابطِ گرافیکی (PySide6)، بعد از فرستادنِ اولین پیام، دکمه‌ی
«ارسال» برای همیشه غیرفعال می‌ماند.

علتِ ریشه‌ای: `_send_text` بعدِ فرستادنِ پیام، `send_btn` را غیرفعال
می‌کرد و قرار بود وقتی پاسخ آماده شد (روی نخِ پس‌زمینه‌ی asyncio که
`AsyncBridge` اجرا می‌کند)، با `QTimer.singleShot(0, ...)` دوباره
فعالش کند. مشکل: `QTimer.singleShot` برایِ شلیک‌شدن به یک حلقه‌ی
رویدادِ Qt رویِ همان نخی که صدایش می‌زند نیاز دارد؛ نخِ پس‌زمینه‌ی
asyncio هیچ حلقه‌ی رویدادِ Qt‌ای اجرا نمی‌کند (فقط حلقه‌ی asyncio خودش
را دارد)، پس آن تایمر هیچ‌وقت واقعاً شلیک نمی‌شد و `send_btn` تا ابد
غیرفعال می‌ماند — یعنی دقیقاً همان چیزی که «بیشتر از یک پیام نمی‌شود
فرستاد» احساس می‌شد (زدنِ Enter هنوز کار می‌کرد چون `_on_send` وضعیتِ
دکمه را چک نمی‌کند، ولی خودِ دکمه برای همیشه خاموش می‌ماند و
واکنش‌پذیریِ UI به‌هم می‌ریخت).

راه‌حل: به‌جایِ `QTimer.singleShot` از یک نخِ خارجی، یک `Signal` Qt
اضافه شد (`ChatWindow._turn_finished`). وقتی امضاکننده (نخِ asyncio) و
گیرنده (نخِ GUI) فرق دارند، Qt به‌طورِ خودکار اتصال را `QueuedConnection`
می‌کند — یعنی تحویلِ فراخوانی به نخِ درست، تضمین‌شده و مستندشده، نه یک
تایمر که ممکن است هیچ‌وقت شلیک نکند.

## نسخه‌ی v20.17 — آدیتِ کامل + نسخه‌بندیِ Backup + سطح‌بندیِ وابستگی‌ها + مجوزِ پلاگین

نتیجه‌ی یک دورِ کاملِ خودآدیت (سه راندِ بررسی→نمره→نیاز→ایده روی
core.py، interpreter.py، security.py، plugins.py، database.py،
dependencies.py، memory_store.py):

### باگ‌های رفع‌شده
- **مفسر فارسی**: تورفتگی بر اساسِ فاصله‌هایِ واقعیِ کاربر بازطراحی شد
  (قبلاً فقط با «:» عمق زیاد می‌شد و کدِ بعدِ یک بلاک برایِ همیشه داخلِ
  همان بلاک می‌ماند). کامنت (`#`) هم که قبلاً اصلاً پشتیبانی نمی‌شد و
  خطِ کد را می‌ترکاند، حالا درست حذف می‌شود (با احترام به `#` داخلِ رشته).
  اصلاحِ خودکارِ «تورفتگیِ فراموش‌شده» هم که به‌خاطرِ فرضِ اشتباه درباره‌ی
  شماره‌خطِ Python 3.10+ کار نمی‌کرد، درست شد.
- **exec sandbox**: `__import__(...)`، `importlib.import_module(...)`،
  `open(...)`، و ماژول‌هایِ شبکه‌ایِ استاندارد (`urllib`، `http`،
  `ftplib`، `smtplib`) که قبلاً هیچ‌کدام مسدود نبودند، الان مسدودند.
- **Path Traversal پلاگین**: نامِ پلاگین (`../escape`) دیگر نمی‌تواند
  از پوشه‌ی `plugins/` بیرون بزند.
- **Backup/Restore**: `history` که export می‌شد ولی هیچ‌وقت import
  نمی‌شد، الان درست بازمی‌گردد؛ `overwrite=True` واقعاً جایگزین می‌کند
  (قبلاً فقط اضافه می‌کرد، حتی وقتی کاربر صریحاً overwrite خواسته بود).
- **دستورِ «بازیابی»** که این باگِ overwrite را از مسیرِ تعاملی هم
  فعال می‌کرد، اصلاح شد.
- **تبدیلِ دما**: «۱۰۰ سانتیگراد به فارنهایت» (بدونِ کلمه‌ی «درجه»)
  که قبلاً «واحد شناخته نشد» می‌داد، درست شد.
- **edge_tts**: نبودنِ این پکیجِ اختیاری دیگر باعثِ شکستِ کاملِ
  `import trx_ai.core` نمی‌شود.
- **BMI**: تشخیصِ نادرستِ وزن/قد وقتی هر دو کلیدواژه بینِ دو عدد قرار
  می‌گرفتند (رفع‌شده در نسخه‌ی قبلی، اینجا فقط یادآوری).

### قابلیت‌های جدید
- **نسخه‌بندیِ فرمتِ Backup**: هر فایلِ پشتیبان الان `trx_backup_version`
  دارد. فایلِ پشتیبانِ از نسخه‌ای جدیدتر از چیزی که این کد می‌فهمد،
  به‌جایِ نیم‌وارد‌شدنِ بی‌سروصدا، با پیامِ روشن رد می‌شود. جایی هم برایِ
  migrateهایِ نسخه‌هایِ بعدی آماده شده (`DatabaseManager._migrate_backup_data`).
- **سطح‌بندیِ رسمیِ وابستگی‌ها**: `dependencies.py` الان سه سطحِ
  `CORE_MODULES` (rich/aiohttp/bs4 — بدونشان TRX AI اصلاً بالا نمی‌آید)،
  `OPTIONAL_MODULES` (edge_tts/cryptography/psutil/...) و
  `EXPERIMENTAL_MODULES` (chromadb/sentence-transformers، عمداً
  auto-install نمی‌شوند) دارد، با پیام‌هایِ 🔴/🟡 متفاوت.
- **تأییدِ صریح قبل از «بازیابی»**: چون overwrite=True داده‌های فعلی
  را جایگزین می‌کند، الان اول جدیدترین فایلِ پشتیبان را معرفی می‌کند و
  منتظرِ «بله» می‌ماند؛ هر چیزِ دیگری = لغو، هیچ داده‌ای دست نمی‌خورد.
- **مجوزِ پلاگین**: پلاگین‌ها الان می‌توانند `permissions` اعلام کنند
  (`math`/`random`/`text`). درخواستِ مجوزهایِ `network`/`filesystem`/
  `shell`/`database` که این نسخه اصلاً نمی‌تواند اعطا کند، همان لحظه‌ی
  نصب رد می‌شود (نه اینکه بعداً موقعِ اجرا با خطایِ گنگ متوقف شود).

### تست
- `tests/test_interpreter.py` جدید: ۱۴ موردِ تورفتگی (if/for/while
  dedent، تودرتو، وگرنه، بلوکِ خالی، فاصله‌هایِ متفاوت، tab، خطِ خالی،
  کامنت) — همه پاس.
- همه‌ی رگرسیون‌هایِ نسخه‌های قبلی (BMI، تبدیلِ واحد، خرج، کار،
  عددبه‌حروف) دوباره تأیید شدند.

## نسخه‌ی v20.16 — رفعِ باگِ BMI

باگ: تشخیصِ وزن/قد فقط الگویِ «وزن ۷۰» (عدد بلافاصله بعد از کلمه، فقط
با فاصله) را می‌فهمید. جمله‌هایِ طبیعیِ رایج مثلِ «۷۰ کیلو وزن دارم»
(عدد قبل از کلمه) یا «وزنم: ۷۰» (علامتِ نگارشی بینِ کلمه و عدد) اصلاً
تشخیص داده نمی‌شدند. جایگزین شد با یک الگویِ «نزدیک‌ترین عدد به
کلیدواژه» که مستقلِ از ترتیب/نگارش کار می‌کند. یک بررسیِ منطقیِ اضافه
هم اضافه شد (وزن/قدِ نامعقول رد می‌شود، نه محاسبه‌ی گمراه‌کننده).

## نسخه‌ی v20.15 — رفعِ کاملِ رندرِ GUI روی اندروید

باگِ گزارش‌شده (جعبه‌های خالی/تُهی به‌جایِ جدول‌ها روی Pydroid3): علتِ
واقعی، کاراکترهایِ کادرکشیِ یونیکدِ rich (═ ║ ╔ ╗ ╭ ╮ ┏ ┓ و...) بود که
در فونتِ دستگاه گلیف نداشتند. به‌جایِ وابسته‌بودن به فونتِ نصب‌شده،
`GuiUIEngine.print()` اکنون این کاراکترها را بعد از رندر به معادلِ
ASCII (+, -, |, =) تبدیل می‌کند — تضمینِ نمایشِ درست روی هر فونتی، هر
دستگاهی. پوششِ کامل: سبک‌هایِ ROUNDED, DOUBLE_EDGE, HEAVY, و خطِ Rule.

## نسخه‌ی v20.14 — ۵ قابلیتِ کاربردیِ جدید

### ۱. پشتیبان‌گیری/بازیابیِ کامل (`backup_data`/`restore_data`)
«پشتیبان‌گیری کن» کلِ پروفایل/دانش/کارها/خرج‌ها/تاریخچه را به یک فایلِ
JSONِ برچسب‌زمان‌دار در `backups/` می‌نویسد؛ «بازیابی کن» جدیدترین
فایل را پیدا و بازمی‌گرداند (`DatabaseManager.export_all_data` /
`import_all_data`).

### ۲. مدیریتِ خرج‌ها (`expenses.py`)
«خرج کردم ۵۰ هزار تومان برای نهار» → ثبت با تشخیصِ خودکارِ مبلغ
(هزار/میلیون تومان) و دسته (غذا/حمل‌ونقل/خرید/قبض/سرگرمی/سلامت).
«خلاصه‌ی خرج‌هام» → گزارشِ ۳۰ روزِ اخیر بر اساسِ دسته با درصد.

### ۳. تبدیلِ واحد (`health_utils.UnitConverter`)
طول (متر/کیلومتر/مایل/فوت/اینچ)، وزن (کیلوگرم/گرم/پوند/اونس)، دما
(سانتیگراد/فارنهایت/کلوین) — «۱۰ کیلومتر به مایل».

### ۴. تولیدِ رمزِ عبورِ امن (`health_utils.PasswordGenerator`)
با ماژولِ `secrets` (نه `random` — تصادفیِ رمزنگارانه)، تضمینِ حداقل
یک حرفِ بزرگ/کوچک/عدد/نماد.

### ۵. محاسبه‌ی BMI (`health_utils.HealthCalculator`)
فرمولِ استانداردِ عمومی (نه تشخیصِ پزشکی، به‌صراحت در خروجی قید شده).

همه‌ی موارد با تستِ end-to-end روی یک دیتابیسِ SQLite واقعی (نه فقط
mock) تأیید شدند، از جمله چرخه‌ی کاملِ export→import بینِ دو دیتابیسِ
جدا.

## نسخه‌ی v20.13 — رابطِ گرافیکی (PySide6) + تکمیلِ سیستمِ کارها/یادآوری

### ۱. خروج از ترمینال: رابطِ گرافیکیِ واقعی
یک پنجره‌ی چتِ RTL با PySide6 (Qt) اضافه شد — نه بازنویسیِ منطق، بلکه
یک لایه‌ی نمایشیِ جدید روی همان موتورِ تست‌شده:

- **چرا Qt؟** چون رندرِ متنِ فارسی/عربی (شکل‌دهیِ حروف + راست‌به‌چپ) را
  به‌صورتِ بومی و درست انجام می‌دهد — دقیقاً همان مشکلی که در ترمینال
  با hazm/arabic-reshaper/python-bidi حل نشد (و نهایتاً غیرفعال شد)،
  اینجا از اساس وجود ندارد.
- **صفر تغییر در منطقِ کسب‌وکار:** `medical.py`، `tools.py`،
  `intelligence.py`، `tasks.py`، `memory_store.py`، `interpreter.py`،
  `security.py` — همه دست‌نخورده‌اند. مسیریابیِ پیام‌ها با استخراجِ
  `_process_turn` از `start_loop` به یک متدِ مشترک تبدیل شد که هم
  ترمینال هم GUI از همان استفاده می‌کنند (نه دو نسخه‌ی جداگانه که
  ممکن است با هم واگرا شوند).
- **معماری:** `GuiUIEngine` (در `gui_ui_engine.py`) دقیقاً همان رابطِ
  عمومیِ `UIEngine` ترمینالی را پیاده می‌کند؛ core.py با تزریقِ این
  کلاس به‌جایِ `UIEngine`، بدونِ هیچ تغییری برایِ GUI هم کار می‌کند.
  حتی `self.ui.console.print(Panel(...))`/`print(table)` هم با یک
  Console داخلیِ rich (روی یک بافرِ متنی به‌جایِ ترمینال) به متنِ ساده
  تبدیل و درست رندر می‌شوند.
- **Threading:** حلقه‌ی asyncio (که `TRXEnterpriseAI` روی آن اجرا
  می‌شود) در یک نخِ پس‌زمینه است؛ پنجره‌ی Qt در نخِ اصلی. ارتباط با
  `asyncio.run_coroutine_threadsafe` (GUI→asyncio) و یک صفِ رویدادِ
  thread-safe که هر ۸۰ میلی‌ثانیه خوانده می‌شود (asyncio→GUI).
- **ورودیِ تعاملی:** `async_input()` ترمینالی (که مستقیم `input()`
  صدا می‌زد) به یک تابعِ تزریق‌پذیر (`self._input_fn`) تبدیل شد؛ در
  GUI این تابع هرگز بلاک نمی‌کند (انتخابِ صدا از یک چک‌باکس خوانده
  می‌شود، نه یک پرامپتِ مسدودکننده).
- اجرا: `python gui_main.py` (PySide6 در صورتِ نبود، خودکار نصب می‌شود).

### محدودیتِ شناخته‌شده و صادقانه
مدِ REPL چندخطیِ «مفسر کدِ فارسی» فعلاً فقط در نسخه‌ی ترمینالی کار
می‌کند؛ در GUI به‌جایِ فریز کردن، پیامِ توضیحی می‌دهد. همچنین: من در
این محیط PySide6/صفحه‌نمایش در دسترس ندارم، پس نتوانستم پنجره را
واقعاً باز/دیداری تست کنم — منطقِ غیرِ‌Qt (`GuiUIEngine`، تبدیلِ
ارقام، صفِ رویداد) با تست‌های واحد تأیید شده، اما رفتارِ بصریِ
ویجت‌ها را باید خودتان روی سیستمِ واقعی بررسی کنید. اگر مشکلی دیدید،
بگویید تا رفع شود.

### ۲. تکمیلِ سیستمِ کارها/یادآوری (از قابلیتِ قبلی)
`TaskManager` که در تعاملِ قبلی ساخته شده بود ولی به `core.py` وصل
نشده بود، اکنون کامل شد: نیت‌های `task_add`/`task_list`/`task_done`/
`task_delete` به `STRUCTURAL_COMMANDS` و `_execute_route` اضافه
شدند، و یادآوریِ خودکارِ کارهایِ سررسیدرسیده در ابتدایِ هر نوبت
(`_process_turn`) بررسی می‌شود — هم در ترمینال هم در GUI.

## نسخه‌ی v20.12 — چندزبانگی + داشبورد توسعه‌دهنده

### ۱. چندزبانگی: «با هر زبان سرچ شود، با همان زبان جواب بده»
`LanguageEngine` جدید در `tools.py`: زبانِ ورودی را تشخیص می‌دهد (اگر
از قبل فارسی باشد، کاملاً محلی و بدونِ تماسِ شبکه‌ای — چون اکثریتِ
قطعیِ پیام‌ها فارسی‌اند)؛ برای هر زبانِ دیگر، ورودی را به فارسی ترجمه
می‌کند تا موتورهای داخلی (که همه روی کلیدواژه‌های فارسی کار می‌کنند)
بتوانند پردازشش کنند، و پاسخِ نهایی را قبل از نمایش دوباره به همان
زبانِ اصلیِ کاربر برمی‌گرداند. اگر شبکه نبود یا ترجمه شکست خورد، بی‌صدا
به حالتِ فارسیِ فعلی برمی‌گردد (هیچ‌وقت برنامه را کرش نمی‌دهد).
محدودیتِ شناخته‌شده: این ترجمه فقط پاسخ‌های نهایی (`_present`) را
پوشش می‌دهد، نه پیام‌های اورژانسی/سؤالِ پیگیریِ پزشکی که مستقیم چاپ
می‌شوند — این‌ها فعلاً فقط فارسی‌اند.

### ۲. داشبورد توسعه‌دهنده (دستورِ «داشبورد»)
برخلافِ کنسولِ محرمانه‌ی قبلی («درِ مخفی»، که همچنان هست)، این یک
دستورِ رسمی و در راهنما دیده می‌شود: مصرفِ RAM/CPU (با psutil)، آمارِ
زمانِ پاسخ (میانگین/آخرین/p95 از ۱۰۰ درخواستِ اخیر)، تعدادِ کلِ
درخواست‌ها، Cache hit، و جدولِ آخرین خطاها. تا پیش از این، `self.stats["errors"]`
مقداردهی می‌شد ولی هرگز افزایش نمی‌یافت (همیشه ۰ بود)؛ اکنون هر خطا
هم در آمار و هم در یک لاگِ چرخشی برای همین داشبورد ثبت می‌شود.

## نسخه‌ی v20.11 — ممیزیِ پایداری: ۶ باگِ واقعیِ تازه‌کشف‌شده رفع شد

این نسخه حاصلِ یک ممیزیِ کاملِ کدهاست (نه فقط رفعِ موارد گزارش‌شده)؛
هر مورد با یک تستِ واقعی که قبل از رفع شکست می‌خورد و بعدش پاس می‌شود
تأیید شده است.

### ۱. 🔴 حلقه‌ی بی‌پایان کلِ برنامه را فریز می‌کرد
`interpreter.py` (مفسر فارسی) و `plugins.py` (اجرای پلاگین) کدِ کاربر
را با `exec()` بدونِ هیچ محدودیتِ زمانی اجرا می‌کردند. یک اشتباهِ
سهوی مثلِ «تاوقتی درست:» بدونِ break کلِ برنامه را برای همیشه فریز
می‌کرد. یک ماژولِ امنیتیِ مشترکِ جدید (`security.py`) اضافه شد که با
`signal.alarm` بعد از ۵ ثانیه اجرا را با خطای قابل‌مدیریت قطع می‌کند.

### ۲. 🔴 اجرای پلاگین اصلاً محافظت نمی‌شد (حتی بعد از تلاشِ اول)
در تلاشِ اول برای اضافه‌کردنِ تایم‌اوت به `execute_plugin`، فراخوانیِ
واقعیِ تابعِ پلاگین (`run(input_data)`) بیرون از بلاکِ تایم‌اوت مانده
بود — یعنی `exec()` محافظت می‌شد ولی خودِ اجرای منطقِ پلاگین نه. با
تست مستقیم (پلاگینی با حلقه‌ی بی‌پایان) کشف و در همین نسخه رفع شد.

### ۳. 🟠 یک مقدارِ خرابِ حافظه، بارگذاریِ همه‌چیزِ بعدش را متوقف می‌کرد
`MemoryEngine._load_long_term_memory` همه‌ی بخش‌ها (پروژه‌ها/علایق/
حقایق/خلاصه/اهداف) را در یک try مشترک بارگذاری می‌کرد. اگر مثلاً یک
مقدارِ «علاقه» در دیتابیس غیرعددی می‌شد، `int(value)` خطا می‌داد و
بارگذاریِ حقایق/خلاصه/اهدافِ کاربر که بعدش می‌آمدند اصلاً اجرا
نمی‌شد. اکنون هر بخش try/except جداگانه دارد.

### ۴. 🔴 استخراجِ نامِ شهر برای آب‌وهوا اساساً خراب بود
`city = text.replace("هوا", "")` روی «هوای تهران چطوره» (رایج‌ترین
جمله‌ی ممکن) به‌جای «تهران»، رشته‌ی «ی تهران چطوره» تولید می‌کرد؛ چون
«هوا» زیررشته‌ی «هوای» است و «چطوره» هم حذف نمی‌شد. یعنی قابلیتِ
آب‌وهوا عملاً برای متداول‌ترین ورودی هرگز درست کار نکرده بود. یک متدِ
استخراجِ جدید (`_extract_city_name`) نوشته شد که پیشوندها/پسوندهای
پرسشی را درست حذف می‌کند.

### ۵. 🟡 نامِ شهر در URL آب‌وهوا encode نمی‌شد
`WeatherEngine.get_weather` مستقیماً `city` را داخلِ URL می‌گذاشت؛
برای شهرهای چندکلمه‌ای (fallback به انگلیسی) این یک URL نامعتبر
می‌ساخت. با `urllib.parse.quote` رفع شد.

### ۶. 🟡 چند `except` بی‌صدا بدونِ لاگ
یک مورد در `memory_store.py` (`delete_document`) پیدا و برای هم‌سو
شدن با استانداردِ لاگ‌گیریِ بقیه‌ی پروژه اصلاح شد.

**همه‌ی موارد بالا با اجرای واقعی (نه فقط خواندنِ کد) پیدا و با یک
تستِ خودکار که سناریوی باگ را دقیقاً بازتولید می‌کند، تأیید شدند.**

## نسخه‌ی v20.10 — رفع ۴ باگِ گزارش‌شده (پایداری، جوک، حافظه، جستجو)

### ۱. غیرفعال‌سازیِ کاملِ hazm/arabic-reshaper/python-bidi
این سه کتابخانه در محیطِ اجرای واقعی (Termux/اندروید) نصب/ایمپورت
نمی‌شدند و در هر اجرای برنامه خطا چاپ می‌کردند. کدشان در `ui.py` و
`dependencies.py` کامل کامنت شد (نه فقط try/except؛ اصلاً تلاش نمی‌شود
import/نصب شوند)؛ `persiantools` چون خطا نداشت فعال ماند. `reshape_fa`
اکنون متن را بدون تغییر برمی‌گرداند.

### ۲. قابلیتِ جوک/لطیفه اضافه شد
`JokeEngine` در `intelligence.py` با ۱۰ جوکِ تمیز و خانوادگی + نیتِ
جدیدِ `joke` (کلیدواژه/regex برای «جوک بگو»، «لطیفه بگو»، «بخندونم»
و...). در `core.py` وصل شد؛ هر بار جوکِ متفاوتی می‌گوید (پرهیز از
تکرارِ فوریِ همان جوک) و از کش معاف است.

### ۳. «یادت هست/یادته/یادت میاد» به STRUCTURAL_COMMANDS اضافه شد
قبلاً این عبارت فقط یک کلیدواژه‌ی امتیازی بود که گاهی در رقابت با
نیت‌های دیگر (مثلاً وقتی جمله «اسمم چیه» هم داشت) می‌باخت. اکنون
به‌عنوان یک دستورِ ساختاریِ لنگرشده، همیشه با اطمینانِ ۰.۹۸ به
memory_query هدایت می‌شود.

### ۴. تصحیح Headers جستجوی وب
`WebSearchEngine.HEADERS` و `MedicalWebSearchEngine.HEADERS` قبلاً فقط
User-Agent داشتند؛ برخی سایت‌ها (به‌خصوص DuckDuckGo) درخواستِ بدونِ
Accept/Accept-Language را مسدود یا rate-limit می‌کنند. هدرها کامل‌تر و
User-Agent به یک نسخه‌ی به‌روزِ Chrome به‌روزرسانی شد.
**این تغییر توسط من تست نشد** (نیازمندِ دسترسیِ شبکه‌ی زنده به همان
سایت‌هاست) — لطفاً پس از نصب «سرچ کن هوش مصنوعی» را امتحان کنید و اگر
باز هم کار نکرد، پیامِ خطای دقیق را بفرستید.

## سوابقِ نسخه‌های پیشین (v20.0 تا v20.9)
شاملِ: تشخیصِ پزشکیِ گفتگومحور (سؤال‌های بله/خیر)، بازطراحیِ رابط
کاربری، مجموعه‌ی تستِ خودکار (`tests/`)، مستندسازیِ معماری
(`ARCHITECTURE.md`)، آنالیزگرِ کدِ مبتنی‌بر ast با امتیازِ کیفیت،
کنسولِ محرمانه‌ی توسعه‌دهنده (فعال با «درِ مخفی»)، گسترشِ پایگاه‌داده‌ی
بیماری‌ها از ۷ به ۱۵ مورد، و اصلاحِ مسیریابیِ سؤالاتِ «چیست/کیست/کجاست».
جزئیاتِ کامل هرکدام پیش‌تر در تعاملات ارائه شده است.

## نسخه‌ی v20.7 — صدا (Microsoft Neural TTS) + ظاهر زنده‌تر + کتابخانه‌های فارسیِ بیشتر

### ۱. تبدیل متن به گفتار روی هر پاسخ
تابع `_handle_voice_option` از قبل در کد وجود داشت اما هیچ‌جا صدا زده
نمی‌شد (کدِ مرده). اکنون:

- یک نقطه‌ی واحد به نام `_present()` اضافه شد که هر پاسخِ «نهاییِ»
  دستیار (نه سؤال پیگیریِ پزشکی، نه پیام اورژانسی، نه خروجیِ مفسر کد)
  را نمایش می‌دهد و بلافاصله بعدش می‌پرسد: «۱=مرد، ۲=زن، Enter=رد کردن».
- موتور صدا همان `edge-tts` قبلی است که عمداً حفظ شد، چون این کتابخانه
  خودش رابطی برای سرویس Text-to-Speech نورالِ **مایکروسافت (Edge/Azure
  Neural Voices)** است — یعنی درخواستِ «ترجیحاً از مایکروسافت استفاده
  کن» از قبل با همین زیرساخت برآورده می‌شود؛ فقط لازم بود واقعاً
  فراخوانی شود.
- پاسخ کاربر به رقم فارسی هم (۱/۲) کار می‌کند، چون قبل از بررسی از
  `ui.f2e()` رد می‌شود.
- برای پیام‌های اورژانسی، سؤال‌های پیگیریِ بله/خیر و خروجیِ اجرای کد،
  عمداً این پیشنهاد نمایش داده نمی‌شود (اذیت‌کننده/نامناسب است).

### ۲. ظاهر رابط کاربری: زنده‌تر و شبیه یک دستیار واقعی
- هر پاسخ اکنون با یک برچسبِ کوچکِ «● TRX AI» و ساعت، درست بالای پنلِ
  پاسخ نمایش داده می‌شود (شبیه حبابِ پیام در یک اپ چت واقعی).
- بنر ابتدایی یک نشانگر «● online» گرفت.
- پرامپت صدا با آیکن/رنگ‌بندیِ یکدست به‌جای یک خط ساده‌ی متنی.

### ۳. کتابخانه‌های فارسیِ بیشتر
- **hazm** برای نرمال‌سازیِ متن فارسی (یکسان‌سازی حروف عربی/فارسی،
  نیم‌فاصله‌ها، فاصله‌های اضافه) — پیش از شکل‌دهیِ نمایشی اجرا می‌شود
  تا حتی ورودیِ ناپاکیزه‌ی کاربر هم یکدست دیده شود.
- **persiantools** برای تقویم شمسی و تبدیل ارقام فارسی/انگلیسی، به‌جای
  پیاده‌سازیِ دستیِ قبلی (که همچنان به‌عنوان نسخه‌ی پشتیبان/fallback در
  صورت نبودِ این کتابخانه نگه داشته شده است).
- هر دو در `dependencies.py` طبق همان الگوی نصب خودکارِ بقیه‌ی
  پکیج‌ها اضافه شدند؛ نبودشان برنامه را متوقف نمی‌کند، فقط ظرافتِ
  نمایش کمی کمتر می‌شود.

## نسخه‌ی v20.6 — تشخیص پزشکیِ گفتگومحور + بازطراحیِ کامل رابط کاربری

### ۱. موتور پزشکی: گفتگوی تعاملیِ بله/خیر
تا پیش از این، `analyze_symptoms` فقط یک‌بار روی متن اولیه اجرا می‌شد و
هرچه دستگیرش می‌شد همان تشخیص نهایی بود؛ اگر چند بیماری امتیاز نزدیک به
هم می‌گرفتند، هیچ راهی برای تفکیک آن‌ها وجود نداشت. اکنون:

- `medical.py` علائم را استخراج و بیماری‌های کاندید را رتبه‌بندی می‌کند
  (`_extract_symptoms` / `_rank_diseases`، هر دو از منطق قبلی جدا شدند
  تا در گفتگوی چندمرحله‌ای هم قابل استفاده‌ی مجدد باشند).
- اگر تشخیص از همان ابتدا قاطع نبود (بدون یک کاندیدِ روشن یا فاصله‌ی
  امتیازِ کافی بین رتبه‌ی اول و دوم)، یک «علامتِ تفکیک‌کننده» انتخاب و
  به‌صورت سؤال بله/خیر پرسیده می‌شود — مثلاً «آیا سرفه خشک هم دارید؟».
- پاسخ کاربر (بله/خیر/آره/ندارم/...) پارس می‌شود، امتیازها دوباره
  محاسبه می‌شوند و در صورت نیاز سؤال بعدی (مثلاً «سردرد») پرسیده می‌شود؛
  حداکثر تا ۴ سؤال، یا تا رسیدن به یک تشخیص قاطع.
- `core.py` اکنون هر ورودیِ بعدی از کاربر را ابتدا بررسی می‌کند که آیا
  گفتگوی پزشکیِ فعالی برایش وجود دارد (`has_active_dialogue`)؛ اگر بله،
  آن ورودی مستقیماً به‌عنوان پاسخِ بله/خیر تفسیر می‌شود، نه اینکه دوباره
  وارد تشخیص نیت شود.
- بررسی علائم هشدار فوریتی (`_check_emergency_redflags`) در هر مرحله
  از گفتگو هم فعال می‌ماند: اگر کاربر وسط پاسخ‌دادن چیزی مثل «قفسه
  سینه‌ام درد می‌کند» بنویسد، بلافاصله گفتگو قطع و راهنمای اورژانسی
  نمایش داده می‌شود.

### ۲. رابط کاربری: بازطراحیِ کامل (`ui.py`)
فایل `ui.py` که پیش‌تر وارد می‌شد اما در تحویل قبلی موجود نبود، این‌بار
از صفر و با الهام از فضای گفتگوی Claude بازنویسی شد:

- پنل‌های تمیز و کم‌شلوغ با یک لهجه‌ی رنگیِ گرمِ واحد، به‌جای رنگ‌های
  پراکنده‌ی قبلی.
- `animated_print` اکنون پاسخ را به‌صورت تدریجی (شبیه استریم‌شدن) نمایش
  می‌دهد، نه یک‌باره.
- سؤال پیگیریِ پزشکی (`show_followup_question`) از پاسخ نهایی
  (`animated_print`) و از پیام اورژانسی (`show_emergency`) از نظر
  بصری کاملاً متمایز است.
- **زبان:** تمام برچسب‌ها، عنوان‌ها، راهنما و پیام‌های ثابتِ رابط
  کاربری (در `ui.py` و بخش‌های نمایشیِ `core.py`) به انگلیسی بازنویسی
  شدند. تنها چیزی که فارسی می‌ماند، محتوای واقعیِ گفتگوست: آنچه خودِ
  کاربر تایپ می‌کند، و پاسخ‌های موتورهایی مثل پزشکی که پایگاه‌دانششان
  ذاتاً فارسی است (ترجمه‌ی کامل آن پایگاه‌دانش، کار جداگانه و بسیار
  بزرگ‌تری است و در این تغییر انجام نشده).
- **رفع مشکل نمایش فارسی در ترمینال:** برای اینکه همین محتوای فارسی
  (ورودی کاربر که echo می‌شود، پاسخ‌های پزشکی، تاریخ شمسی و...) در
  ترمینال (به‌خصوص Termux/اندروید) به‌صورت حروف ناپیوسته و بی‌ترتیب
  دیده نشود، دو کتابخانه‌ی `arabic-reshaper` و `python-bidi` اضافه شدند
  (`requirements.txt` و `dependencies.py`) و تابع `reshape_fa()` پیش
  از هر چاپِ متنِ فارسی روی آن اجرا می‌شود. اگر این دو کتابخانه نصب
  نباشند، برنامه از کار نمی‌افتد؛ فقط متن بدون شکل‌دهی (خام) چاپ می‌شود.
- تاریخ شمسی اکنون با یک تبدیل میلادی→شمسیِ داخلی (بدون وابستگی
  جدید) محاسبه می‌شود.

## نسخه‌ی v20.5 — فاز ۱۲: رفع باگ‌های واقعیِ مفسر فارسی

### باگ ۱: بلاک‌ها هرگز به‌طور طبیعی بسته نمی‌شدند
`PersianPythonInterpreter.translate` تورفتگی را فقط با یک شمارنده مدیریت
می‌کرد که تنها با خطِ صریحِ «وگرنه» کم می‌شد. یعنی بعد از هر تابع/if/حلقه،
**تمام خطوطِ باقی‌مانده‌ی اسکریپت** برای همیشه همان‌قدر تورفته می‌ماندند.
مثال واقعی که با تست پیدا شد:
```
تابع جمع(a, b):
    برگردان a + b

چاپ(جمع(2,3))
```
قبل: `چاپ(جمع(2,3))` به‌اشتباه داخلِ بدنه‌ی تابع (بعد از return، یعنی کدِ
مرده) قرار می‌گرفت و هرگز اجرا نمی‌شد. بعد: با یک پشته‌ی تورفتگی که بعد
از دستورهای پایان‌دهنده‌ی بلاک (`برگردان`/`توقف`/`ادامه`/`عبور`) یا یک
خط خالی، یک سطح دِنت می‌کند، این خط درست در سطحِ اصلی قرار می‌گیرد و
خروجی `5` چاپ می‌شود.

### باگ ۲: ناهم‌ترازیِ شماره‌خط در اصلاحِ خودکار
خطوطِ خالی به‌کلی از کدِ ترجمه‌شده حذف می‌شدند، اما `smart_execute` برای
اصلاحِ خودکار مستقیماً به اندیسِ خطوطِ اسکریپتِ اصلی (با خطوط خالی) رجوع
می‌کند. اگر اسکریپت خط خالی داشت، شماره‌خطِ گزارش‌شده توسط خطای پایتون
(روی کدِ بدونِ خط خالی) با اندیسِ واقعی در اسکریپتِ اصلی یکی نبود و
اصلاحِ خودکار می‌توانست خطِ اشتباهی را عوض کند. رفع شد: خطوط خالی اکنون
در کدِ ترجمه‌شده هم به‌عنوان خطِ خالی حفظ می‌شوند تا تناظرِ خط‌به‌خط
همیشه برقرار بماند.

### تست (۵ سناریوی واقعی، همه موفق)
```
✅ تابع + فراخوانیِ سطحِ بالا بعد از خط خالی   → خروجی درست: 5
✅ حلقه‌ی برای/تعداد                            → 0 1 2 3 4
✅ اگر/وگرنه                                    → «بزرگ»
✅ if تودرتو داخل تابع + کد بعد از تابع          → True
✅ اصلاحِ خودکارِ «:» فراموش‌شده با خط خالی قبل از خطا → خطِ درست اصلاح شد
```

### محدودیتِ شناخته‌شده (صادقانه اعلام می‌شود)
این هنوز یک تجزیه‌گرِ واقعیِ مبتنی بر تورفتگی نیست؛ برای بلاک‌هایی با
چند دستورِ متوالی که با «وگرنه»/return/خط‌خالی از هم جدا نمی‌شوند (مثلاً
تابعی با دو خطِ کد پشتِ سرِ هم بدون فاصله)، نتیجه هنوز می‌تواند نادرست
باشد. توصیه: بین بلاک‌های مجزا یک خطِ خالی بگذارید یا از تورفتگیِ واقعی
استفاده کنید.



## نسخه‌ی v20.4 — فاز ۸ (Tool Scorer) و فاز ۹ (Context) + یک باگ حیاتی

### 🔴 مهم‌ترین باگِ پیداشده در این دور: هر پیامِ عادی وارد ماشین‌حساب می‌شد
`ToolScorer.score_tools` وقتی هیچ ابزاری هیچ نشانه‌ای نداشت (یعنی امتیاز
همه صفر بود — دقیقاً حالتِ یک پیام معمولیِ گفت‌وگو)، باز هم با
`max(scores, key=...)` یک «برنده» انتخاب می‌کرد. چون دیکشنری ابزارها با
`calculator` شروع می‌شود، این یعنی جملاتی مثل «ممنون بابت راهنمایی» یا
«داستان کوتاه برام بنویس» با قطعیت ۱۰۰٪ وارد **ماشین‌حساب** می‌شدند.
این احتمالاً بزرگ‌ترین دلیلِ «هیچی درست باز نمی‌شه» بود. با تست واقعی
تأیید و رفع شد:
```
قبل:  «ممنون بابت راهنمایی»       => tool: calculator ❌
بعد:  «ممنون بابت راهنمایی»       => tool: general     ✅
```

### 🔴 باگِ دوم: بیشترِ تعامل‌ها اصلاً ذخیره نمی‌شدند
`core.py._execute_route` فقط ۴ شاخه (پزشکی، تحلیل پروژه، حافظه آفلاین،
پاسخ عمومی) را در انتها `_finalize` می‌کرد. یعنی ماشین‌حساب، مترجم،
لغت‌نامه، جستجوی وب، آب‌وهوا، ارز، پروفایل، ساعت، یادگیری و ذخیره‌ی
حافظه — که اکثریتِ واقعیِ تعاملات‌اند — هرگز به تاریخچه یا حافظه‌ی
کوتاه‌مدت اضافه نمی‌شدند. این را با یک نقطه‌ی finalize یکپارچه در پایانِ
مسیر (برای همه‌ی شاخه‌هایی که زودتر return نکرده‌اند) رفع کردیم.

### فاز ۸ — Tool Scorer
- `context` که قبلاً همیشه `None` فرستاده می‌شد (یعنی کد مرده)، اکنون
  واقعاً شمارشِ استفاده‌ی اخیر از هر ابزار در همین نشست است
  (`self.tool_usage_history`).
- Context فقط زمانی اثر می‌گذارد که ابزار از قبل حداقل کمی شواهدِ واقعی
  داشته باشد (وگرنه می‌توانست برای پیامی کاملاً بی‌ربط هم یک ابزارِ
  پراستفاده را به‌اشتباه «برنده» کند).
- برای تساویِ چند ابزار با امتیازِ برابر، اکنون یک اولویتِ صریح استفاده
  می‌شود (نه ترتیبِ دلبخواهیِ دیکشنری).

### فاز ۹ — Context (ارجاعِ ضمایر)
- `entity_stack` که قرار بود حافظه‌ی موضوعات باشد، در عمل **هرگز پر
  نمی‌شد** چون هیچ‌جای `core.py` به `add_message` پارامتر `topic`
  داده نمی‌شد.
- متد جدید `MemoryEngine.extract_topic_entity()` موضوع را از جملاتی مثل
  «RTX4090 چیه؟» استخراج می‌کند و اکنون در `_finalize` صدا زده می‌شود.
- اشکالِ محاوره‌ایِ ضمایر («اون»، «اینو»، «اونو»، «همون») که در نسخه‌ی
  قبلی اصلاً پوشش داده نمی‌شدند، اضافه شدند.
- تست دقیقاً طبق مثالِ خودِ نقشه‌راه:
```
کاربر: RTX4090 چیه؟          →  Entity ثبت‌شده: RTX4090
کاربر: اون چقدره؟            →  resolve_pronoun => "RTX4090 اون چقدره؟"
```

### درباره‌ی فازهای باقی‌مانده
فازهای ۱۰ (Reflection پیشرفته‌تر)، ۱۲ (Interpreter)، ۱۳–۱۵ (Logging/
Exception/Config استاندارد)، و ۱۶–۲۰ (Benchmark/Profiling/Performance/
Docs/Unit Test رسمی) هنوز باقی مانده‌اند. با همین روش — پیدا کردن باگِ
واقعی با تست، نه ادعای کلی — می‌شود در تعامل‌های بعدی ادامه داد.



## نسخه‌ی v20.3 — رفع باگ‌های واقعیِ تشخیص نیت (با تست مستند)

نسخه‌ی قبلی (v20.2) موتور امتیازدهی را بازنویسی کرد، اما چند کلیدواژه‌ی
بیش‌ازحد عمومی از کد قدیم باقی مانده بود که همچنان باعث تشخیص‌های غلط
می‌شد. این نسخه با نوشتن مجموعه‌ای از جملات واقعی و اجرای واقعیِ
`IntentEngine.detect_intent` روی آن‌ها، مشکلات را یکی‌یکی پیدا و رفع کرد
(نتیجه‌ی تست‌ها در پایین آمده).

### باگ‌های پیدا و رفع‌شده
1. **`persian_interpreter` تقریباً هر جمله‌ای را می‌قاپید.** کلیدواژه‌های
   «اگر »، «برای »، «تابع » حذف شدند — این‌ها از رایج‌ترین کلمات فارسی‌اند
   و در جملاتی مثل «برای تولدش چی بخرم؟» یا «اگر بارون بیاد...» هیچ
   ربطی به اجرای کد نداشتند، اما با اطمینان ۹۹٪ به این نیت می‌رفتند.
   اکنون فقط با نحو واقعیِ فراخوانی («چاپ(»/«بگو(») فعال می‌شود.
2. **پرسیدن نام، با تنظیمِ نام قاطی می‌شد.** «اسم من چیه؟» به‌اشتباه
   به‌عنوان دستورِ *تنظیمِ* نام («profile_update») تشخیص داده می‌شد، نه
   *پرسیدنِ* نام («profile_query»)، چون هر دو الگو با «اسم من» شروع
   می‌شدند و ترتیب بررسی اشتباه بود. ترتیب اصلاح شد و الگوی تنظیمِ نام
   اکنون صراحتاً حالت پرسشی را کنار می‌گذارد.
3. **تطبیقِ کلیدواژه‌های چندکلمه‌ای مرز کلمه را رعایت نمی‌کرد.** «یاد
   بگیر» به‌اشتباه داخل «یاد بگیرم» (در جمله‌ی «چطور برنامه‌نویسی یاد
   بگیرم») هم تطبیق پیدا می‌کرد و آن را به یک دستورِ ذخیره‌سازی تبدیل
   می‌کرد. اکنون مرز کلمه برای عبارات چندکلمه‌ای هم چک می‌شود (به‌جز
   کلیدواژه‌های شبه‌کد که عمداً با «(» تمام می‌شوند).
4. **`workflow` با کلمات ربط معمولی («بعد»، «سپس») فعال می‌شد.** «بعد از
   غذا چیکار کنم خوبه؟» (یک سؤال سلامت) به‌غلط «workflow» تشخیص داده
   می‌شد. این کلمات حذف و به عبارات صریحِ چندمرحله‌ای محدود شدند.
5. **`planning` و `code_analyzer` هر دو روی کلمه‌ی «برنامه» رقابت
   می‌کردند** (چون «برنامه» هم یعنی «نرم‌افزار» هم یعنی «برنامه‌ریزی»)؛
   `planning` اکنون فقط به «برنامه‌ریزی» (ترکیبِ کامل) واکنش نشان می‌دهد.
6. **نیتِ `medical` دو بار برای کلمات یکسان امتیاز می‌گرفت** (هم از
   کلیدواژه، هم از یک regex تکراری روی همان کلمات)، که امتیاز آن را
   به‌طور مصنوعی نسبت به بقیه‌ی نیت‌ها بالا می‌برد. regex تکراری حذف شد.

### نتیجه‌ی تست (۱۹ جمله‌ی نماینده، صفر شکست)
```
✅ اسم من چیه؟                       => profile_query
✅ نام من چیه؟                       => profile_query
✅ اسمم چیه                          => profile_query
✅ نام من علی است                    => profile_update
✅ برای تولد دوستم چی بخرم خوبه       => general   (قبلاً: persian_interpreter ۹۹٪)
✅ اگر بارون بیاد چیکار کنم           => general   (قبلاً: persian_interpreter ۹۹٪)
✅ بعد از غذا چیکار کنم خوبه          => general   (قبلاً: workflow ۹۶٪)
✅ چطور برنامه‌نویسی یاد بگیرم        => code_analyzer (قبلاً: self_learning)
✅ یادت باشه فردا جلسه دارم           => self_learning
✅ یه برنامه پایتون برام بنویس        => code_analyzer
✅ تحلیل پروژه ./trx_ai              => project_analysis
✅ سردرد شدید دارم و تهوع هم دارم     => medical
✅ سلام حالت چطوره                   => general
✅ شخصیت فنی                         => personality_change
✅ چاپ(سلام دنیا)                    => persian_interpreter
✅ قیمت دلار الان چنده               => currency
✅ ترجمه کن hello                    => translator
✅ راجع به هوش مصنوعی برام بگو       => general
✅ ممنون بابت راهنمایی               => general
```

### درباره‌ی نقشه‌راه ۲۰ فازی پیشنهادی
یک نقشه‌راهِ جامع (پایدارسازی → استانداردسازی → حذف تکرار → معماری →
بازنویسی NLU → تست → پزشکی → Tool Scorer → Context → Reflection →
Memory → Interpreter → Logging → Exception → Config → Benchmark →
Profiling → Performance → Documentation → Unit Test) دریافت شد. این کار
واقعی و درست است، اما یک بازنویسی چندهفته‌ای با مجموعه‌ی تست real است،
نه چیزی که بشود در یک پاسخ «کامل» ادعا کرد. آنچه در این نسخه واقعاً و
با تست مستند انجام شد: بخشی از فاز ۵ (کشف و رفع باگ‌های واقعیِ تشخیص
نیت) و بخشی از فاز ۱۱ (اصلاح رتبه‌بندی حافظه، در نسخه‌ی v20.2). فازهای
استانداردسازی سراسری، معماریِ لایه‌ای رسمی، و مجموعه‌ی تست خودکار برای
تمام نیت‌ها هنوز باقی مانده‌اند و برای انجامِ درست (نه سرسری) به
تعامل‌های بعدی و تمرکز روی فایل‌های مشخص نیاز دارند.



## نسخه‌ی v20.2 — ارتقاء تشخیص نیت، موتور پزشکی و رابط کاربری

این نسخه سه ضعف اصلیِ گزارش‌شده را هدف قرار داده: **تشخیص نیت نادرست/
آزاردهنده**، **عدم اتصال واقعی موتور پزشکی به منابع پزشکی معتبر**، و
**رابط کاربری ضعیف**. تمام تغییرات افزایشی هستند و امضای متدهای عمومیِ
`IntentEngine.detect_intent`, `ToolScorer.score_tools`,
`MedicalAIEngine.*`, `UIEngine.*` بدون تغییر باقی مانده‌اند.

### تشخیص نیت (`intelligence.py`)
- موتور قبلی یک زنجیره‌ی `if کلمه in متن` بود که روی اولین تطابق متوقف
  می‌شد و جدولِ وزن‌دارِ `INTENT_PATTERNS` را اصلاً استفاده نمی‌کرد؛ در
  نتیجه کلمات عمومی مثل «حالت» (در «حالت چطوره؟») یا «شخصیت» (در هر
  جمله‌ای که این کلمه در آن بود) با قطعیتِ ۱۰۰٪ به‌عنوان دستور سیستمی
  تشخیص داده می‌شدند.
- اکنون **همه‌ی نیت‌ها امتیازدهی می‌شوند** (نه فقط اولین تطابق)، با
  تطبیقِ مبتنی بر مرز کلمه (نه substring آزاد)، تشخیص نفی نزدیک کلیدواژه
  («تب ندارم» ≠ «تب دارم»)، و اطمینانی که از فاصله‌ی امتیاز برنده تا
  نفر دوم محاسبه می‌شود (نه یک عدد ثابت).
- دستورات ساختاری (تغییر شخصیت، یادگیری، پروفایل، ...) با regexِ
  لنگرشده بازنویسی شدند تا دیگر با جملات معمولی تداخل نداشته باشند.
- `ToolScorer` اکنون کلیدواژه‌هایش را از همان `INTENT_PATTERNS` می‌خواند
  (به‌جای یک جدول کپی‌شده‌ی دوم) تا تشخیص نیت و امتیازدهی ابزار هرگز از
  هم واگرا نشوند.

### موتور پزشکی (`medical.py`, `tools.py`)
- **لایه‌ی ایمنیِ اورژانسی جدید:** فهرستی از «علائم هشدار» (درد قفسه
  سینه، تنگی نفس شدید، بی‌هوشی، افتادگی صورت/سکته، تشنج، خونریزی شدید،
  مسمومیت و…) اکنون در همان ابتدای هر پردازش پزشکی — پیش از هر تحلیل
  یا تماس شبکه‌ای — بررسی می‌شود. نسخه‌ی قبلی فقط با کلمات صریح «کمک
  اولیه»/«اورژانس» وارد مسیر فوریتی می‌شد؛ جمله‌ای مثل «قفسه سینه‌ام
  درد می‌کنه و نفسم بالا نمیاد» از این مسیر رد می‌شد و مثل یک سؤال
  عادی پاسخ داده می‌شد.
- **اتصال واقعی به منبع پزشکیِ معتبر:** کلاس جدید
  `MedicalWebSearchEngine` در `tools.py` به **MedlinePlus** (سرویس وب
  رسمی و رایگانِ کتابخانه‌ی ملی پزشکی آمریکا، NLM/NIH) وصل می‌شود —
  نه صرفاً یک اسکرِیپِ عمومیِ DuckDuckGo. چون MedlinePlus فقط انگلیسی
  است، پرسش فارسی از طریق مترجم داخلی به انگلیسی و پاسخ به فارسی
  برگردانده می‌شود؛ نتیجه با ذکر منبع نمایش داده می‌شود.
- ترتیب اولویت منابع آنلاین اکنون: MedlinePlus (تخصصی پزشکی) →
  ویکی‌پدیای فارسی → جستجوی عمومی وب — به‌جای پرش مستقیم به جستجوی عمومی.
- درخواست‌های شبکه‌ای به MedlinePlus با retry/backoff و کشِ کوتاه‌مدتِ
  درون‌حافظه‌ای (۳۰ دقیقه) پیاده‌سازی شدند تا هم پایدارتر باشند و هم
  فشار کمتری به سرویس بیرونی وارد کنند.
- سلب‌مسئولیت‌های پزشکیِ قبلی (که از ابتدا خوب طراحی شده بودند) بدون
  تغییر حفظ شدند.

### رابط کاربری (`ui.py`, `core.py`)
- باگ بصری اصلاح شد: پاسخ‌ها با نشانه‌های Markdown خام (`**پررنگ**`،
  فهرست‌های `•`) داخل `Panel` چاپ می‌شدند و Rich این نشانه‌ها را تفسیر
  نمی‌کرد؛ کاربر ستاره‌های خام را می‌دید. اکنون از `rich.markdown.Markdown`
  استفاده می‌شود تا پررنگ/فهرست/عنوان واقعاً درست نمایش داده شوند.
- پنل اختصاصیِ `show_emergency` اضافه شد: پاسخ‌های اورژانسیِ پزشکی با
  قاب ضخیم و برجسته (متفاوت از پاسخ‌های معمولی) نمایش داده می‌شوند تا
  در نگاه اول از بقیه‌ی خروجی متمایز باشند.
- متد `show_error` برای نمایش یکدست خطاها اضافه شد.
- بنر نسخه اکنون به‌جای عدد ثابتِ کدشده، از `__version__` پکیج می‌خواند.


هدف این ارتقاء، **حفظ کامل و دقیق تمام قابلیت‌های موجود** بود. تغییرات
زیر صرفاً معماری، امنیت و قابلیت‌مشاهده (observability) را بهبود
می‌دهند و هیچ منطق کسب‌وکاری/رفتاری حذف یا جایگزین نشده است.

## ۱. معماری

- فایل تک‌پارچه‌ی ۳۷۳۲ خطی به ۱۴ ماژول مجزا در پکیج `trx_ai/` تقسیم شد
  (نگاه کنید به بخش «ساختار پروژه» در README.md).
- هر ۲۶ کلاس اصلی (`DatabaseManager`, `MemoryEngine`, `MedicalAIEngine`,
  `IntentEngine`, ... ) و ۴ دیتاکلاس (`Message`, `ToolScore`, `Workflow`,
  `Plugin`) عیناً با همان کد منتقل شدند؛ فقط `import`های لازم برای هر
  ماژول اضافه شد.
- نقطه‌ی ورود اجرا (`if __name__ == "__main__"`) از هسته‌ی برنامه جدا
  و به `main.py` منتقل شد (الگوی متداول در پکیج‌های حرفه‌ای پایتون).

## ۲. لاگ‌گیری (observability)

- ماژول جدید `logging_config.py`: لاگ چرخشی (rotating) در `logs/trx_ai.log`
  + هشدار/خطا در کنسول.
- در نقاط حساس (پایگاه‌داده، ChromaDB، شبکه، پلاگین‌ها، حلقه‌ی اصلی)
  علاوه بر پیام فارسیِ قبلی که به کاربر نمایش داده می‌شد، اکنون جزئیات
  کامل خطا (traceback) هم در فایل لاگ ثبت می‌شود. پیش‌تر این اطلاعات با
  `print()` چاپ و سپس برای همیشه گم می‌شد.

## ۳. مدیریت وابستگی‌ها

- نصب خودکار پکیج‌ها از یک حلقه‌ی سراسری در بالای فایل، به تابع صریح
  `ensure_required_packages()` در `dependencies.py` منتقل شد که فقط
  یک‌بار در `main.py` فراخوانی می‌شود.
- رفتار پیش‌فرض (نصب خودکار در صورت نبود پکیج) **دقیقاً حفظ شده**؛ فقط
  اکنون با `TRX_AUTO_INSTALL=0` قابل غیرفعال‌سازی است.
- فایل `requirements.txt` برای نصب دستی/تولیدی اضافه شد.

## ۴. پیکربندی

- مسیرهای پوشه (`ai_voices`, `plugins`, `files`, `temp`) اکنون از طریق
  متغیرهای محیطی هم قابل بازنویسی هستند؛ مقدار پیش‌فرض بدون تغییر است.

## ۵. پاک‌سازی جزئی (بدون تأثیر بر رفتار)

- `import` بلااستفاده‌ی `from enum import Enum` که در هیچ‌کجای کد اصلی
  استفاده نمی‌شد، حذف شد.
- پرچم `PSUTIL_AVAILABLE`، مانند نسخه‌ی اصلی، محاسبه می‌شود اما در کد
  اصلی هم استفاده‌ای نداشت؛ برای شفافیت در `README.md` ذکر شده است.

## ۶. مستندسازی

- هر ماژول یک docstring سطح‌ماژول توضیح‌دهنده‌ی مسئولیتش دریافت کرد.
- نکات امنیتی مربوط به `exec()` (در مفسر فارسی و سیستم پلاگین) که در
  نسخه‌ی اصلی مستند نشده بود، اکنون به‌صراحت در docstring مربوطه و در
  README.md توضیح داده شده است.

## آنچه تغییر *نکرده*

- تمام کلیدواژه‌های فارسی، شخصیت‌ها، الگوهای تشخیص نیت، پایگاه‌داده‌ی
  دانش پزشکی، منطق امتیازدهی ابزارها، مفسر فارسی و سیستم پلاگین.
- ماشین‌حساب امن مبتنی بر `ast` (بدون تغییر — از ابتدا هم صحیح بود).
- ساختار جداول SQLite و طرح داده‌ها.
- متن پیام‌های فارسی نمایش‌داده‌شده به کاربر.

## v20.22 Conversation Patterns v4
- Expanded built-in conversational seed corpus to 140+ broad examples across everyday life, emotions, relationships, learning, coding, AI, planning, creativity, games, electronics, science, media, food, travel, money, health and meta-conversation.
- Increased learned multi-turn pattern capacity to 320 and per-user utterance-pattern capacity to 1000.
- Increased conversation analysis window to 14 turns.
- Improved lexical/topic matching for Persian morphology and added broader domain cues.
- Expanded relevant-pattern retrieval from 4 to 6 patterns and recent learned utterance context from 8 to 12.
- Built-in corpus is seeded once per database and never treated as user facts.

## v20.22 Conversation Patterns v4 — Broad Conversation Corpus
- Built-in baseline expanded to 173 conversational patterns, including 149 single-turn examples plus 24 multi-turn mini-conversations.
- Added domains: relationships, learning, AI, coding, electronics, science, games, entertainment, daily organization, money, food, travel, health, motivation, storytelling and meta-conversation.
- Learned patterns are now kept separate from the generic built-in corpus, so real user experience is not accidentally merged into a generic seed.
- Topic matching improved for Persian word forms and direct learned-topic matches.
- Retrieval now considers up to 6 relevant patterns, with learned experience preferred over generic baseline when sufficiently relevant.


## TRX AI v21.1 Human Conversation Upgrade
- بهبود حالت مکالمه انسانی: بازتاب احساس، کاهش پاسخ‌های کلیشه‌ای، سوال ادامه‌دهنده طبیعی و حفظ زمینه گفتگو.


## v21.2
- Medical precision upgrade: adaptive questions, risk-first analysis, improved symptom reasoning.

## Memory Correction Upgrade
- Added confidence-based memory correction.
- Added conflict handling and memory expiry rules.
- Reduced accidental conversion of assumptions into permanent memories.

## v25 — بزرگ‌شدنِ چشمگیرِ پایگاه‌دانشِ پزشکی

طبقِ درخواست: پایگاه‌دانشِ `MedicalAIEngine` تقریباً دو برابر شد.

- **بیماری‌ها: از ۱۵ به ۲۹.** موارد جدید: کم‌خونیِ فقرِ آهن، کم‌کاری و
  پرکاریِ تیروئید، سنگِ کلیه، نقرس، کلسترولِ بالا، بواسیر، اگزما، کهیر،
  زونا، سرگیجه‌ی وضعیتیِ خوش‌خیم (BPPV)، بی‌خوابی، یبوستِ مزمن، واریس.
  هر ورودی دقیقاً با همان ساختارِ ۷بخشیِ موجود (علائم، شدت، مدت، درمان،
  پیشگیری، علائمِ هشدار، زمانِ مراجعه) نوشته شد -- نه یک قالبِ جدید.
- **داروها: از ۸ به ۱۵.** موارد جدید هم‌راستا با بیماری‌هایِ تازه:
  لووتیروکسین، متی‌مازول، آلوپورینول، لوراتادین، آسیکلوویر، آتورواستاتین،
  مکملِ آهن.
- `symptom_to_condition` (که خودکار از رویِ `disease_db` ساخته می‌شود)
  اکنون ۱۵۳ ورودیِ علامت↔بیماری دارد (قبلاً حدودِ ۸۰).
- اعتبارسنجی شد: هر ۲۹ بیماری و هر ۱۵ دارو دقیقاً همان کلیدهایِ
  موردنیازِ کدِ موجود (`treatment`, `warning_signs`, `dosage`, ...) را
  دارند -- هیچ‌کدام چیزی کم ندارند که باعثِ کرش در زمانِ اجرا شود.
- بدونِ تغییر در الگوریتمِ استخراجِ علائم (`_extract_symptoms`): محدودیتِ
  شناخته‌شده‌ی آن (تطبیقِ نسبتاً دقیقِ عبارت، نه NLP معنایی) از قبل روی
  ۱۵ بیماریِ اول هم بود؛ موردهایِ جدید دقیقاً همان قراردادِ نوشتاریِ
  موجود را رعایت کردند تا رفتارشان با بقیه یکسان باشد.
- لایه‌هایِ ایمنی (اورژانسِ جسمی + خطِ حمایتِ روانی) کاملاً مستقل از این
  گسترش‌اند و دست‌نخورده باقی ماندند -- تست شد.

## v24 — رفعِ باگِ سکوت‌آمیزِ Backup/Restore پس از رمزنگاریِ در سطحِ ذخیره‌سازی

بعد از اضافه‌شدنِ رمزنگاریِ در سطحِ ذخیره‌سازیِ جدولِ `profile`
(`text_crypto.py` + `database.py`)، قابلیتِ پشتیبان‌گیری/بازیابی که از
قبل وجود داشت **بدونِ توجه شکسته بود**: خودِ ویژگی جدید بود اما تست
نمی‌شد که آیا با قابلیتِ قدیمی‌ترِ backup هم‌خوان است یا نه.

- **باگِ اصلی:** `export_all_data` مقدارهایِ `profile` را همان‌طور که
  در دیتابیس نشسته بودند (یعنی رمزشده با کلیدِ محلیِ همان دستگاه) صادر
  می‌کرد. چون فایلِ کلید هرگز داخلِ فایلِ Backup قرار نمی‌گیرد،
  بازیابیِ همان Backup روی دستگاه/نصبِ دیگری — دقیقاً هدفِ اصلیِ
  قابلیتِ backup/restore — کلیدِ متفاوتی می‌ساخت و `get_profile` پس از
  بازیابی به‌جایِ خطایِ روشن، بی‌سروصدا متنِ رمزشده‌ی خام (garbage) را
  به‌عنوانِ دفترچه‌ی سلامت/دارو/حقایقِ شخصیِ کاربر برمی‌گرداند.
- **باگِ دوم (پنهان‌کننده‌ی اولی در تست‌ها):** مسیرِ پیش‌فرضِ فایلِ کلید
  (`_get_or_create_master_key`) به `db_path` وابسته نبود — یک مسیرِ
  ثابتِ سراسری بود. در نتیجه دو نمونه‌ی `DatabaseManager` با دو فایلِ
  دیتابیسِ کاملاً متفاوت (دقیقاً سناریویِ تستِ backup/restore) به‌صورتِ
  تصادفی یک کلید را به اشتراک می‌گذاشتند و این باگ را در تستِ موجود
  (`test_backup_and_restore_round_trip`) پنهان می‌کرد.

### تغییرات
- `text_crypto._get_or_create_master_key` اکنون `db_path` می‌گیرد و
  به‌صورتِ پیش‌فرض کلید را کنارِ همان فایلِ دیتابیس (`<db_path>.key`)
  ذخیره می‌کند — نه یک فایلِ سراسریِ ثابت (`TRX_DB_KEY_PATH` همچنان
  اولویت دارد).
- `export_all_data` اکنون profile را پیش از خروجی رمزگشایی می‌کند (خودِ
  فایلِ JSON خروجی، مثلِ قبل، حاویِ داده‌ی خصوصیِ کاربر است و باید امن
  نگه داشته شود، اما دیگر به کلیدِ محلی وابسته نیست).
- `import_all_data` مقدارِ رمزگشایی‌شده را با کلیدِ دستگاهِ مقصد دوباره
  رمزنگاری می‌کند، دقیقاً مثلِ `set_profile`.
- نسخه‌ی فرمتِ Backup به ۲ افزایش یافت؛ Backupهایِ قدیمیِ نسخه‌ی ۱ اگر
  روی همان دستگاه بازیابی شوند مثلِ قبل کار می‌کنند، و اگر روی دستگاهِ
  دیگری بازیابی شوند، دیگر بی‌سروصدا garbage تولید نمی‌شود — هشدارِ
  روشن در لاگ ثبت می‌شود.

## v24 — جداسازیِ افکارِ خودکشی/خودآسیبی از اورژانسِ جسمی + رفعِ خلأِ مسیریابی

لایه‌ی ایمنیِ اورژانسیِ `medical.py` (که در v20.2 اضافه شد) «خودکشی» و
«اقدام به خودکشی» را داخلِ همان `EMERGENCY_REDFLAGS` جسمی گذاشته بود؛
یعنی برایِ کسی که افکارِ خودکشی دارد، دقیقاً همان پیامِ کمک‌های اولیه‌ی
فیزیکی («CPR شروع کنید»، «چیزی نخورانید») نمایش داده می‌شد — که نه‌فقط
بی‌ربط بلکه در این وضعیت می‌تواند آسیب‌زا/گیج‌کننده باشد و به‌جایِ آن
خطِ حمایتِ روانی معرفی نمی‌شد.

خلأِ عمیق‌تر: هیچ‌کدام از کلیدواژه‌های خودکشی/خودآسیبی در جدولِ نیتِ
`medical` (در `intelligence.py`) نبودند. یعنی پیامی مثلِ «دیگه میخوام
بمیرم» یا «به فکر خودکشی افتادم» — بدونِ هیچ کلیدواژه‌ی جسمیِ همراه —
اصلاً به‌عنوانِ نیتِ پزشکی تشخیص داده نمی‌شد، وارد مسیرِ گفتگوی عمومی
می‌شد و هرگز به هیچ‌کدام از لایه‌های ایمنیِ `MedicalAIEngine` نمی‌رسید.

### تغییرات
- کلیدواژه‌های خودکشی/خودآسیبی از `EMERGENCY_REDFLAGS` جدا شدند و یک
  دسته‌ی مستقل (`SELF_HARM_REDFLAGS`) و یک پاسخِ مستقل و همدلانه
  (`_check_self_harm_redflags`) ساخته شد که به‌جایِ راهنمایِ فیزیکی، به
  خطِ اورژانسِ اجتماعیِ بهزیستی (۱۲۳ و ۱۴۸۰) ارجاع می‌دهد و تأکید می‌کند
  تنها نمانید.
- تابعِ جدیدِ `_check_any_redflags` هر دو دسته را با یک فراخوانی بررسی
  می‌کند؛ هر چهار نقطه‌ی فراخوانیِ قبلی (`start_symptom_check`،
  `answer_symptom_check`، `handle_medical_query` و مسیرِ آنلاین) اکنون
  از همین تابعِ ترکیبی استفاده می‌کنند.
- کلیدواژه‌های «خودکشی»، «خودآزاری»، «خودزنی»، «میخوام بمیرم»، «دیگه
  نمیخوام زندگی کنم» و مشابه به جدولِ نیتِ `medical` در `intelligence.py`
  اضافه شدند تا این پیام‌ها — حتی بدونِ کلیدواژه‌ی جسمیِ همراه — واقعاً
  به موتورِ پزشکی (و لایه‌ی ایمنیِ آن) مسیریابی شوند.

## v24 — پاسخِ همدلانه‌ی واقعاً آفلاین (نه فقط گزارشِ درصدی)

خلأِ عمیق‌تری که موردِ قبلی (`mood_report`) کاملاً پوشش نمی‌داد: تشخیصِ
احساس (`emotional_support_mode`/`emotion_profile`) از قبل وجود داشت،
اما فقط وقتی *واقعاً* روی پاسخِ نهایی اثر می‌گذاشت که Gemini در دسترس
بود (کلیدِ API + اینترنت). سیستم‌پرامپتِ Gemini صراحتاً می‌گفت «اگر
کاربر درد دل می‌کند، فقط همدل باش»، ولی این دستورالعمل فقط داخلِ
Gemini اجرا می‌شد. وقتی Gemini در دسترس نبود (خیلی رایج -- بدونِ کلید
یا بدونِ اینترنت روی گوشی)، حتی برایِ «امروز خیلی ناراحتم و دلم گرفته»
دقیقاً همان پیامِ عمومیِ رباتی نمایش داده می‌شد: «سؤال خود را دقیق‌تر
مطرح کنید یا از دستورات راهنما استفاده کنید» -- یعنی فهمِ احساس هیچ
اثرِ واقعی‌ای نداشت مگر با اینترنت.

### تغییرات
- `ConversationPatternEngine.local_empathetic_reply` اضافه شد: بر پایه‌ی
  همان تشخیصِ احساسِ موجود، یک پاسخِ همدلانه و متنوع (نه یک جمله‌ی
  ثابتِ تکراری) کاملاً آفلاین می‌سازد -- برایِ ناراحتی، عصبانیت،
  نگرانی، قدردانی، سردرگمی، خوشحالی/هیجان و جشن. برایِ پیام‌هایِ غیرِحسی
  (فنی، دستوری، پرسشِ دانشی) `None` برمی‌گرداند تا مسیرِ عادی
  (وب/ویکی/Gemini) دست‌نخورده بماند.
- در `core.py`، `except LLMUnavailableError` (نقطه‌ای که Gemini نبود/
  شکست خورد) حالا اول این پاسخِ همدلانه را امتحان می‌کند؛ فقط اگر پیام
  اصلاً حسی نبود، به الگویِ عمومیِ قبلی سقوط می‌کند.
- به‌عنوانِ محافظِ جانبی: پیام‌هایِ حسی که تصادفاً یک کلمه‌ی پرسشی هم
  دارند (مثلاً «چرا هیچکس منو نمی‌فهمه؟») دیگر به لایه‌ی جست‌وجویِ
  ویکی‌پدیا فرستاده نمی‌شوند -- قبلاً ممکن بود یک نتیجه‌ی نامرتبطِ
  دانشنامه‌ای به‌جایِ پاسخِ همدلانه نمایش داده شود.

`ConversationPatternEngine` از قبل هر پیامِ کاربر را با احساس/نوع/نیاز
برچسب می‌زد (`emotion_profile`, `_conversation_type`, ...)، اما این
اطلاعات فقط *داخلی* مصرف می‌شد (تصمیمِ لحن/راهبردِ پاسخ) و هرگز به
خودِ کاربر نشان داده نمی‌شد.

- متدهایِ جدید `mood_report`/`format_mood_report` روی N پیامِ اخیرِ
  کاربر (که از قبل در دیتابیس، نه فقط حافظه‌ی نشست، ذخیره می‌شوند)
  تجمیع می‌کنند و درصدِ هر نوعِ گفتگو (پرسش/جواب، درد دل، جشن/خوشحالی،
  فنی، برنامه‌ریزی، ...) و هر احساس (ناراحتی، خوشحالی، عصبانیت، نگرانی،
  قدردانی، ...) را برمی‌گردانند.
- دستورِ جدید «تحلیل احساسی» / «حال و هوای گفتگو چطوره» (در
  `intelligence.py`، به‌عنوانِ فرمانِ ساختاریِ لنگرشده، نه حدسِ آماری)
  این گزارش را با پنلِ رنگیِ خودش نمایش می‌دهد؛ در «راهنما» هم اضافه
  شد تا قابلِ کشف باشد.
- هشدارِ صریح در انتهایِ گزارش: این یک تخمینِ لغویِ ساده است (بر پایه‌ی
  کلیدواژه)، نه ابزارِ تشخیصِ روان‌شناختی -- تا برداشتِ نادرست از دقتِ
  آن ایجاد نشود.

## v24 — افزودنِ ردیابیِ نسخه‌ی schema به دیتابیس

طبق موردِ «مدیریتِ نسخه‌ی دیتابیس» در AUDIT_REPORT.md: `_init_db` هیچ
جدولِ نسخه‌ای نداشت (فقط `CREATE TABLE IF NOT EXISTS` پخش‌شده)، پس هیچ
نقطه‌ی مرکزی برایِ تشخیصِ «این دیتابیس قدیمی است و باید migrate شود»
وجود نداشت.

- جدولِ `schema_meta (key, value)` و ثابتِ `DatabaseManager.SCHEMA_VERSION`
  اضافه شد.
- `_ensure_schema_version` بعد از `_init_db` نسخه‌ی ذخیره‌شده را می‌خواند
  و اگر با `SCHEMA_VERSION` فرق داشت (یا اصلاً وجود نداشت)، آن را ثبت
  می‌کند؛ محلِ افزودنِ migrationهای واقعی (مثلاً `ALTER TABLE ... ADD
  COLUMN ...`) هم به‌صراحت با کامنت مشخص شده تا وقتی ستون/جدولِ جدیدی
  لازم شد، مسیر آماده باشد -- بدونِ اینکه نصب‌های موجودِ کاربران بشکند.

# v25.4.9 — فاز ۳، مرحله ۴: Shadow Mode / evaluation dataset

- افزوده شد: `trx_ai/phase3/shadow.py` برای اتصال read-only به Context مکالمه.
- افزوده شد: `trx_ai/phase3/evaluation_dataset.py` برای ثبت نمونه‌های Shadow در JSONL.
- `conversation_engine.py` فقط یک hook اختیاری و fail-soft دارد؛ با config پیش‌فرض هیچ اثر جدیدی ندارد.
- Neural output در این مرحله فقط به‌صورت raw ثبت می‌شود؛ هیچ agreement ساختاری جعلی تولید نمی‌شود چون `task_heads.py` هنوز ساخته نشده است.
- تست‌های Phase 3: **59/59 پاس**.

# v25.5.0 — Persepolis Foundation (مرحله ۱ از معماری تخت‌جمشید/خورشید/ماه)

- سند جدید `TRX_AI_Persepolis_Solar_Lunar_Complete_Blueprint.txt` دریافت و مرحله ۰ (mapping کامل با ساختار واقعی) انجام شد: بخش بزرگی از «Solar Processing» از قبل در `trx_ai/conversation/` وجود دارد؛ Lunar Runtime، governance رسمی و Event Bus کاملاً جدید بودند.
- افزوده شد: `trx_ai/civilization/foundation/` — `contracts.py` (DomainManifest, HealthStatus/HealthReport, EventEnvelope)، `errors.py`، `health.py` (HealthRegistry، fail-soft)، `events.py` (EventBus سبک، bounded، fail-soft).
- افزوده شد: `trx_ai/civilization/domains/registry.py` — `DomainRegistry` + `build_default_registry()` که Domainهای واقعی موجود (conversation, nlu, medical, phase3, core_engine, tools, memory_store) را توصیف می‌کند، بدون import کردنِ خودِ آن پکیج‌ها.
- **بدون تغییر رفتار:** هیچ فایل موجودی تغییر نکرد؛ `trx_ai/civilization` در `trx_ai/__init__.py` هم wire نشده — کاملاً افزودنی و opt-in، مثل الگوی phase3.
- ۲۲ تست جدید در `tests/test_civilization_foundation.py`؛ جزئیات کامل در `PERSEPOLIS_FOUNDATION_NOTES.md`.
- Solar Runtime، Lunar Runtime و Resource Controller عمداً در این مرحله ساخته نشدند (مراحل بعدی).

# v25.5.1 — رفعِ باگِ بحرانی: حلقه‌ی بازخوردِ حافظه در پاسخِ عمومیِ محلی

- **گزارشِ امیر:** بعد از چند نوبت، پاسخ‌هایِ فال‌بکِ محلی (وقتی نه smalltalk نه ویکی‌پدیا/DuckDuckGo نتیجه‌ای دارند) به‌جایِ پاسخِ ساده، دامپِ خامِ حافظه‌ی داخلی (شاملِ timestampهای بریده‌شده) نشان می‌دادند.
- **ریشه‌یِ علت:** `ToolRouter._general_answer` در `trx_ai/core_engine/tool_router.py`، متنِ داخلیِ `context` (شاملِ پیام‌هایِ قبلیِ AI) را مستقیماً در پاسخِ کاربر درج می‌کرد. چون این پاسخ بلافاصله با `ai._finalize` دوباره در حافظه ذخیره می‌شد، هر نوبتِ بعدی همان دامپ را دوباره در خودش تو‌درتو می‌کرد.
- **رفع:** حذفِ همان دو خطِ تزریقِ context به answer. `context` هنوز برایِ `ReflectionEngine.check` (بررسیِ داخلیِ کیفیت) استفاده می‌شود -- فقط دیگر به کاربر نمایش داده نمی‌شود.
- **تست:** ۳ تستِ رگرسیونِ جدید در `tests/test_general_fallback_memory_leak_regression.py`؛ با اجرا روی نسخه‌ی قبل از رفع، هر سه Failed بودند (اثباتِ اینکه تست واقعاً باگ را تشخیص می‌دهد)؛ روی نسخه‌ی رفع‌شده هر سه Pass شدند.
- صفر تغییرِ دیگر: `diff -rq` نسبت به v25.5.0 فقط سه فایل را نشان می‌دهد: `trx_ai/__init__.py` (نسخه)، `trx_ai/core_engine/tool_router.py` (رفعِ باگ)، و فایلِ تستِ جدید.

# v25.5.5 — Nervous System Coordinator (PHASE 1 + PHASE 2 از سندِ v25.5.5)

سند: `TRX_AI_v25_5_5_Nervous_System_Engineering_Plan.txt`. این نسخه فقط
PHASE 1 (Reality Audit) و PHASE 2 (Coordinator، مرحله‌یِ SHADOW) را
تحویل می‌دهد — فازهایِ ۳ تا ۸ عمداً برایِ نسخه‌هایِ بعدی ماندند.

- **PHASE 1 — Reality Audit:** `audit/module_status.md` + `behavioral_report.md`
  + دو فایلِ JSON؛ با خواندنِ واقعیِ `conversation_engine.py` (نه حدس).
  کشفِ صریح: `response_planner` از قبل ORPHAN بود (خروجی‌اش دور ریخته
  می‌شود) — تا امروز جایی ثبت نشده بود.
- **PHASE 2 — Coordinator:** بستهٔ کاملاً جدیدِ `trx_ai/nervous_system/`
  (`context_schema.py`: `UnifiedConversationContext`؛ `coordinator.py`:
  `NervousSystemCoordinator` با بافرِ محدودِ LRU؛ `influence_audit.py`:
  خوداظهاریِ Runtime + کمکِ تست؛ `config.py`: پرچمِ
  `TRX_NERVOUS_SYSTEM_ENABLED`، پیش‌فرض **خاموش**).
- اتصال: یک hook تنها در `conversation_engine.process` — دقیقاً
  هم‌الگو با `_observe_phase3_shadow` موجود (fail-soft، lazy import،
  بعد از تصمیمِ نهایی، هیچ اثری روی مقدارِ بازگشتی ندارد).
- **بدون تغییر رفتار:** `core.py`، هیچ ماژولِ قدیمی، Video Engine، Vector
  Memory و Local LLM دست‌نخورده ماندند. `diff -rq` نسبت به v25.5.4 فقط
  یک فایلِ موجود را نشان می‌دهد (`conversation_engine.py`، افزودنِ محض).
- **وضعیتِ صادقانه:** این Coordinator عمداً هنوز **ORPHAN** است — هیچ
  مصرف‌کننده‌ای (Local LLM/Tool Gate) به آن وصل نیست. معیارِ نهاییِ خودِ
  سند («اگر خروجیِ عصبی را عوض کنیم، پاسخ عوض می‌شود؟») در این نسخه
  **هنوز نه** — به‌صراحت در `NERVOUS_SYSTEM_NOTES_v25_5_5.md` ثبت شده.
- تست: `tests/test_nervous_system_v25_5_5.py` (end-to-end رویِ
  `conversation_engine.process` واقعی، عدمِ تخریب، fail-soft، بافرِ
  محدود). محدودیتِ sandboxِ این جلسه (بدونِ شبکه، `pytest`/`aiohttp`
  نصب‌نشده) اجازه‌یِ اجرایِ واقعیِ pytest را نداد — به‌جایش یک harness
  مستقلِ stdlib نوشته و اجرا شد (۲۶/۲۷ Pass — جزئیات در یادداشتِ ارتقا).
  **نیاز به تأییدِ اجرایِ pytest واقعی توسطِ امیر.**

# v25.5.6 — Pattern Bridge: اتصالِ ConversationPatternEngine (زیرمجموعه‌یِ stateless)

نسخه‌یِ عمداً کوچک، طبقِ توافقِ صریح: فقط
`ConversationPatternEngine → pattern_context → NervousSystemCoordinator →
UnifiedConversationContext → SHADOW`. نه Local LLM، نه Final Decision، نه
Tool Router.

- **`trx_ai/nervous_system/pattern_bridge.py` (جدید):** خروجیِ واقعیِ
  `ConversationPatternEngine.build_pattern` (زیرمجموعه‌یِ stateless، بدونِ
  DB) را می‌گیرد و خلاصه می‌کند (بدونِ بردارهایِ عددیِ خام). fail-soft کامل.
- `NervousSystemCoordinator.build_context` یک پارامترِ جدید
  (`pattern_engine_context`) گرفت؛ `pattern_context["engine"]` و
  `pattern_context["long_term_pattern_wired"]` حالا واقعی‌اند، نه همیشه `None`/`False`.
- تنها فایلِ لمس‌شده‌ی خارج از `nervous_system/`: `conversation_engine.py`
  (چند خط داخلِ `_observe_nervous_system` -- همان الگویِ fail-soft/lazy-import).
- **آزمایشِ A/B (طبقِ درخواستِ صریحِ امیر):** سناریویِ «یه جوک بگو» در
  برابرِ «یه جوک بگو + چقدر بی‌مزه 😂» -- واقعاً دو `pattern_context`
  متفاوت ساخت (تفاوت در `topics`/`signature`؛ `sentiment_direction` به
  دلیلِ محدودیتِ فرهنگِ لغتِ Engine فرقی نکرد -- صادقانه در
  `audit/behavioral_report.md` ثبت شده).
- **این‌بار، برخلافِ v25.5.5، تست‌های واقعی روی کدِ واقعی اجرا شدند** (با
  stubهایِ یک‌بارمصرفِ محلی برایِ `aiohttp`/`pytest`، که در تحویل نیستند):
  `tests/test_nervous_system_v25_5_6.py` → ۸/۸ Pass،
  `tests/test_nervous_system_v25_5_5.py` → ۷/۷ Pass (بدونِ رگرسیون).
- چک‌لیستِ قبولیِ امیر (Pattern Engine فراخوانی شد / pattern_context تولید
  شد / Coordinator دریافت کرد / UnifiedContext نگه داشت / A/B متفاوت شد /
  crash نکرد / Final Decision عوض نشد) -- همه ✓، جزئیات در
  `NERVOUS_SYSTEM_NOTES_v25_5_6.md`.
- آزمایشِ C (حذفِ عمدیِ context و مقایسه‌یِ پاسخِ نهایی) عمداً اینجا نیست --
  برایِ v25.5.7، وقتی Coordinator از SHADOW خارج شود.

# v25.5.7 — Controlled Context Effect Experiment (ADVISORY/SHADOW کامل)

طبقِ scopeِ قفل‌شده‌ی امیر («v25.5.7 — CONTROLLED CONTEXT EFFECT
EXPERIMENT»، چهار تصمیم). هدف: سنجیدنِ اینکه آیا حذفِ `pattern_context`
واقعاً خروجیِ Local LLM را عوض می‌کند -- بدونِ صفر اثر رویِ production.

- **`trx_ai/nervous_system/experiments/context_effect_experiment.py` (جدید):**
  برایِ هر سناریو، یک `UnifiedConversationContext` واقعی می‌سازد و یک
  نسخه‌ی `REDUCED` (فقط `pattern_context["engine"]=None`، `dataclasses.replace`)،
  هر دو را با `seed`/`temperature`/`history`/`user_text` کاملاً یکسان
  (فقط `system_prompt` فرق می‌کند) به Local LLM می‌دهد، و گزارشِ
  `exact_match`/`similarity`/`length_delta`/`behavioral_difference`
  می‌سازد. `semantic_difference` همیشه `"NOT_PROVEN"` است.
- **`scripts/run_context_effect_experiment.py` (جدید):** تنها راهِ اجرا --
  یک ابزارِ دستی، خارج از هر مسیرِ زنده.
- **تغییراتِ افزودنیِ کوچک (dependency اجتناب‌ناپذیر طبقِ توافق):**
  `interfaces.py`/`llama_cpp_adapter.py` یک `seed: Optional[int] = None`
  گرفتند (فقط وقتی صریحاً داده شود اثر دارد -- صفر تغییر برایِ مسیرِ
  تولیدِ فعلی)؛ `conversational_bridge.py` یک `get_adapter()` عمومیِ
  جدید گرفت. **`core.py` دست نخورد.**
- تست: `tests/test_context_effect_experiment_v25_5_7.py` → ۱۲/۱۲ Pass
  (با fake adapter، اجرایِ واقعیِ کد -- نه mock رویِ منطقِ خودمان).
  رگرسیون: v25.5.5 (۷/۷) + v25.5.6 (۸/۸) + `test_local_llm_integration.py`
  موجود (۱۳/۱۳) -- همه دوباره اجرا، **جمعاً ۴۰ تست، صفر شکست.**
- **صادقانه:** این sandbox فایلِ GGUF/`llama-cpp-python`ی واقعی ندارد؛
  نتیجه‌یِ PASS با یک fake adapter اثبات شد (یعنی خودِ مکانیزمِ آزمایش
  درست کار می‌کند)، نه رویِ مدلِ واقعیِ امیر. اجرایِ رسمی
  (`python scripts/run_context_effect_experiment.py --json`) رویِ
  محیطِ خودِ امیر هنوز باقی است.

**اصلاحیه‌ی بعد از بازبینیِ امیر (همین نسخه):** امیر با اجرایِ مستقلِ
۴۰ تست (`40 passed`) و خودِ اسکریپت (نتیجه‌یِ صادقانه‌یِ
`SKIPPED_NO_MODEL` رویِ محیطِ بدونِ مدلِ خودش) v25.5.7 را تأیید کرد؛ یک
نکته‌ی دقیقِ مستندسازی هم پیدا کرد: کامنتِ «بدونِ ردِ پا» نادرست بود --
`conversation_engine.process` واقعاً یک خطِ لاگ می‌نویسد و context در
بافرِ Coordinator می‌ماند. عبارتِ درست «No production behavioral
effect» است، نه «No side effect». در `context_effect_experiment.py`
اصلاح شد (فقط docstring/کامنت، صفر تغییرِ منطق).

# v25.5.8 — رفعِ باگ: «همراهِ روان‌شناختیِ جعلی» (Emotional Support Misroute)

طبقِ گزارشِ واقعیِ امیر (ترنسکریپتِ یک گفتگویِ کامل): پیام‌هایِ بی‌ربط
مثلِ «چیزی نمیخوام بدونم😂»، «واقعا رد دادی»، «ول کن خدا وکیلی»،
«کاری نیست» زیرِ برچسبِ «💙 همراهِ روان‌شناختی» یک متنِ ثابتِ «تغذیه
متعادل/خوابِ کافی/...» می‌گرفتند -- سه پیامِ متفاوت، سه پاسخِ یکسان --
که در همان ترنسکریپت باعثِ کلافگیِ آشکارِ کاربر شد.

**ریشه:** NLUِ بیرونی (`trx_ai/nlu/intents/psychology.py`) نیتِ
`emotional_support` را با `semantic_enabled=True` تشخیص می‌دهد (حتی
بدونِ کلیدواژه‌ی تحت‌اللفظی)، اما موتورِ پزشکی
(`handle_medical_query_online`) فقط کلیدواژه‌ای چک می‌کند و در نبودِ
تطابق به `health_advice()` (متنِ ثابت) سقوط می‌کند --
`tool_router.py` از این سقوط بی‌خبر بود و همیشه برچسبِ همدلانه را
نشان می‌داد.

**اصلاح (کاملاً افزودنی):**
- `handle_medical_query_online` حالا هر خروجی را با `"source": "therapy"`
  یا `"source": "general_advice"` برچسب می‌زند.
- `format_medical_response_online` (مسیرِ شخصیتِ «دکتر کامل») این کلید
  را دیگر گم نمی‌کند.
- `tool_router.py`: وقتی `source != "therapy"`، به‌جایِ برچسبِ «همراهِ
  روان‌شناختی» + متنِ ثابتِ پزشکی، یک پاسخِ کوتاهِ خنثیِ محاوره‌ای («💬
  مکالمه») نشان داده می‌شود.
- سه فایلِ موجود تغییر کردند (`online.py`, `care.py`, `tool_router.py`)
  -- هرکدام فقط چند خط.
- تست: `tests/test_emotional_support_misroute_v25_5_8.py` -- بازتولیدِ
  دقیقِ هر ۴ پیامِ گزارش‌شده + عدمِ رگرسیون در پیام‌هایِ واقعاً احساسی/
  ادامه‌ی جلسه/جسمی/اورژانسی/شخصیتِ دکتر. **۲۸/۲۸ Pass** رویِ کدِ
  واقعی. رگرسیون: `test_therapy_companion.py` (۱۲)،
  `test_medical_safety_regression.py` + `test_medical_modular_architecture.py`
  (۱۳) -- همه Pass.
- **باگِ دومِ گزارش‌شده (ارجاعِ ضمیر به موضوعِ قدیمی -- «این چرت پرتا»)
  عمداً در این نسخه رفع نشد** -- مستند شد به‌عنوانِ یک concern جداگانه
  در `audit/EMOTIONAL_SUPPORT_MISROUTE_v25_5_8.md`.

# v25.5.9 — رفعِ باگ: عدمِ تشخیصِ «چه کار خاصی بلدی» (SmallTalkEngine)

از همان ترنسکریپتِ واقعیِ v25.5.8: پیامِ «چه کار خاصی بلدی» (و تایپویِ
«چه کار خاصی بلدی ی») به‌جایِ فهرستِ قابلیت‌ها، به boilerplateِ عمومیِ
«🤖 من TRX AI هستم...» سقوط می‌کرد -- درحالی‌که «چیکار بلدی»، چند خط
بالاتر در همان گفتگو، درست پاسخ گرفته بود.

**ریشه:** الگویِ regexِ دسته‌ی `capability` در
`trx_ai/nlu/smalltalk_registry.py` فقط شکلِ جمعِ ثابتِ «کارهایی» را
می‌گرفت -- هیچ کلمه‌ی میانی (اینجا: صفتِ «خاصی») یا شکلِ مفرد را
نمی‌پذیرفت؛ `fuzzy_enabled=False` هم بود، پس هیچ لایه‌ی نجاتی نداشت.

**اصلاح:** الگو گسترش یافت تا حداکثر ۲ کلمه‌ی دلخواه بینِ «چه کار» و
«بلدی» را بپذیرد -- فقط یک رشته‌ی regex در یک فایل تغییر کرد.

**تست:** `tests/test_smalltalk_capability_v25_5_9.py` -- بازتولیدِ
دقیقِ هر دو پیامِ گزارش‌شده + عدمِ رگرسیون در عبارتِ قبلاً کارکن + عدمِ
false-positive رویِ جملاتِ بی‌ربط. **۱۳/۱۳ Pass** رویِ کدِ واقعی.

**دو مشکلِ دیگرِ همان ترنسکریپت هنوز باز مانده‌اند (مستند در
`audit/SMALLTALK_CAPABILITY_MISS_v25_5_9.md`):** (ب) نبودِ دسته‌ای
برایِ بیانِ حالِ خوبِ خودِ کاربر («امروز حالم خوبه») -- یک گپِ کامل، نه
یک باگ؛ (ج) false-positiveِ دسته‌یِ «farewell» رویِ پیامِ «تو اینجوری
قاطی نکن...» -- این یکی محتمل است از لایه‌ی fuzzy/semantic بیاید که
این sandbox (بدونِ `sentence-transformers`) نمی‌تواند مشاهده/تست کند؛
رفعِ مسئولانه‌اش نیازمندِ اجرایِ واقعی رویِ محیطِ خودِ امیر است.
