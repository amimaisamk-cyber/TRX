from trx_ai.medical import MedicalAIEngine, MedicalRequest

e = MedicalAIEngine()
checks = [
    "تب و سردرد دارم",
    "درد قفسه سینه ندارم",
    "نمی‌تونم نفس بکشم",
    "اطلاعات داروی استامینوفن",
    "تداخل استامینوفن و ایبوپروفن",
]
for text in checks:
    r = e.handle_request(MedicalRequest(text))
    print(text, "=>", r.intent, r.status, "emergency=", r.emergency)
