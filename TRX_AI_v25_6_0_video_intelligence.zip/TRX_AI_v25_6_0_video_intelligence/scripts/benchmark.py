# -*- coding: utf-8 -*-
"""
اسکریپت سبکِ Benchmark برای اندازه‌گیریِ کارایی (Performance) بخش‌های
پرکاربردِ برنامه، بدون نیاز به شبکه یا دیتابیس.

اجرا:
    python scripts/benchmark.py

خروجی: میانگین/میانه‌ی زمانِ اجرا (میلی‌ثانیه) برای:
    - IntentEngine.detect_intent  (روی مجموعه‌ای متنوع از جمله‌ها)
    - MedicalAIEngine._extract_symptoms + _rank_diseases
    - MedicalAIEngine.start_symptom_check → answer_symptom_check (یک گفتگوی کامل)

این اسکریپت جایگزینِ پروفایل‌کردنِ دقیقِ cProfile نیست؛ هدفش این است که
با یک اجرای سریع، رگرسیونِ آشکارِ کارایی (مثلاً کند شدنِ ۱۰ برابریِ
detect_intent بعد از یک تغییر) زود دیده شود.
"""

from __future__ import annotations

import os
import statistics
import sys
import time

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)


def _time_it(fn, iterations: int = 200):
    samples = []
    for _ in range(iterations):
        start = time.perf_counter()
        fn()
        samples.append((time.perf_counter() - start) * 1000)  # میلی‌ثانیه
    return {
        "میانگین_ms": round(statistics.mean(samples), 4),
        "میانه_ms": round(statistics.median(samples), 4),
        "بیشینه_ms": round(max(samples), 4),
    }


def benchmark_intent_engine():
    from trx_ai.intelligence import IntentEngine

    corpus = [
        "۵ بعلاوه ۳ چقدر میشه",
        "این جمله رو به انگلیسی ترجمه کن",
        "معنی کلمه‌ی سلام چیه",
        "سردرد و تب و سرفه خشک دارم",
        "هوای تهران چطوره امروز",
        "قیمت دلار و طلا چنده",
        "یاد بگیر: من قهوه دوست دارم",
        "این یک جمله‌ی کاملاً معمولی و طولانی‌تر است که هیچ نیتِ خاصی ندارد و باید general تشخیص داده شود",
    ]

    def run():
        for text in corpus:
            IntentEngine.detect_intent(text, None, None)

    return _time_it(run, iterations=100)


def benchmark_medical_extraction():
    from trx_ai.medical import MedicalAIEngine

    engine = MedicalAIEngine()
    text = "من تب، سردرد، سرفه خشک و گلودرد دارم و بدنم هم درد می‌کند"

    def run():
        extracted = engine._extract_symptoms(text)
        engine._rank_diseases(extracted)

    return _time_it(run, iterations=200)


def benchmark_full_dialogue_turn():
    from trx_ai.medical import MedicalAIEngine

    def run():
        engine = MedicalAIEngine()
        result = engine.start_symptom_check("bench", "تب و سردرد دارم")
        turns = 0
        while not result.get("done", True) and turns < 5:
            result = engine.answer_symptom_check("bench", "خیر")
            turns += 1

    return _time_it(run, iterations=50)


def main():
    print("=" * 60)
    print("TRX AI — Benchmark کارایی")
    print("=" * 60)

    print("\n[1] IntentEngine.detect_intent (روی ۸ جمله، در هر تکرار)")
    for k, v in benchmark_intent_engine().items():
        print(f"    {k}: {v}")

    try:
        print("\n[2] MedicalAIEngine._extract_symptoms + _rank_diseases")
        for k, v in benchmark_medical_extraction().items():
            print(f"    {k}: {v}")

        print("\n[3] یک گفتگوی کاملِ تشخیصِ پزشکی (شروع تا پایان)")
        for k, v in benchmark_full_dialogue_turn().items():
            print(f"    {k}: {v}")
    except ImportError as e:
        print(f"\n[2/3] رد شد (وابستگیِ اختیاری نصب نیست: {e})")

    print("\n" + "=" * 60)
    print("نکته: این اعداد یک خط‌مبنا (baseline) هستند، نه معیار مطلق؛ برای")
    print("مقایسه‌ی قبل/بعدِ یک تغییر روی همین ماشین اجرا کنید.")


if __name__ == "__main__":
    main()
