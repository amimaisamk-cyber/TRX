# -*- coding: utf-8 -*-
"""
scripts/run_phase2_pipeline.py -- اجرایِ کاملِ مراحلِ ۲.۱ تا ۲.۹ سندِ
فازِ دومِ آموزشِ Native Model، رویِ پیکره‌ی واقعیِ پروژه (همان
فایل‌هایِ ``*.md`` ریشه).

خروجی در ``phase2_out/`` (قابلِ تغییر با ``--output-dir``):

    phase2_out/data/corpus_v1/manifest.json    -- بخشِ ۲۰: corpus manifest
    phase2_out/data/corpus_v1/split.json       -- تقسیمِ ثابتِ سطحِ سند
    phase2_out/data/reports/tokenizer_report.txt
    phase2_out/data/reports/generation_comparison.jsonl
    phase2_out/data/reports/phase2_result.json -- گزارشِ کاملِ همه‌ی مراحل
    phase2_out/checkpoints/{latest,best,periodic}/

اجرا::

    python scripts/run_phase2_pipeline.py
"""

from __future__ import annotations

import argparse
import json
import os
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from trx_ai.trx_model.training.data_pipeline.pipeline_runner import run_phase2_pipeline  # noqa: E402
from trx_ai.trx_model.training.data_pipeline.smoke_test import SmokeTestFailure  # noqa: E402

DEFAULT_TOKENIZER_PATH = os.path.join(ROOT_DIR, "trx_ai", "trx_model", "data", "tokenizer.json")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default=os.path.join(ROOT_DIR, "phase2_out"))
    parser.add_argument("--seq-len", type=int, default=64)
    parser.add_argument("--steps", type=int, default=60, help="تعدادِ دنباله‌هایِ زیرمجموعه برایِ Controlled Training")
    parser.add_argument("--epochs", type=int, default=3)
    args = parser.parse_args()

    try:
        result = run_phase2_pipeline(
            root_dir=ROOT_DIR,
            output_dir=args.output_dir,
            tokenizer_path=DEFAULT_TOKENIZER_PATH,
            seq_len=args.seq_len,
            training_steps_subset=args.steps,
            training_epochs=args.epochs,
        )
    except SmokeTestFailure as e:
        print(f"❌ Smoke Test شکست خورد -- آموزش متوقف شد: {e}")
        raise SystemExit(1)

    print("۲.۱/۲.۲ Corpus + Split:")
    print(f"   {result.stage_2_1_corpus}")
    print(f"   {result.stage_2_2_split}")
    print("۲.۳ Tokenizer:", result.stage_2_3_tokenizer)
    print("۲.۴ Smoke Test: همه‌ی", len(result.stage_2_4_smoke_test["passed_checks"]), "چک پاس شد.")
    print("۲.۵ Training:")
    t = result.stage_2_5_training
    print(f"   train loss {t['train_loss_first']:.4f} -> {t['train_loss_last']:.4f}  ({t['n_steps']} step در {t['train_time_seconds']:.1f}s)")
    print(f"   val loss   {t['val_loss_before']:.4f} -> {t['val_loss_after']:.4f}  (perplexity {t['perplexity_before']:.1f} -> {t['perplexity_after']:.1f})")
    print("۲.۶ تحلیل:", result.stage_2_6_analysis["interpretation"])
    print("۲.۸ Resume: weights_match =", result.stage_2_8_resume["weights_match_after_resume"])
    print("۲.۹ Generalization: any_infinite_repetition =", result.stage_2_9_generalization["any_infinite_repetition"])
    print()
    print(f"گزارشِ کامل: {os.path.join(args.output_dir, 'data', 'reports', 'phase2_result.json')}")


if __name__ == "__main__":
    main()
