# -*- coding: utf-8 -*-
"""
scripts/train_native_tokenizer.py -- آموزشِ توکنایزرِ پیش‌فرضِ
trx_ai.trx_model رویِ پیکره‌یِ خودِ پروژه (تمامِ فایل‌هایِ ``*.md``
در ریشه‌ی پروژه: مستنداتِ فارسی/انگلیسیِ واقعی، بدونِ نیاز به
اینترنت یا دیتاستِ بیرونی).

اجرا:

    python scripts/train_native_tokenizer.py [--vocab-size 900]

خروجی در ``trx_ai/trx_model/data/tokenizer.json`` نوشته می‌شود (همان
مسیری که ``TRXNativeModelAdapter.from_default_tokenizer`` می‌خواند).
"""

from __future__ import annotations

import argparse
import glob
import os
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from trx_ai.trx_model.tokenizer import ByteLevelBPETokenizer  # noqa: E402


def load_corpus(root_dir: str) -> list[str]:
    texts = []
    for path in sorted(glob.glob(os.path.join(root_dir, "*.md"))):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            texts.append(f.read())
    return texts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--vocab-size", type=int, default=900)
    parser.add_argument("--min-frequency", type=int, default=2)
    parser.add_argument(
        "--out",
        default=os.path.join(ROOT_DIR, "trx_ai", "trx_model", "data", "tokenizer.json"),
    )
    args = parser.parse_args()

    corpus = load_corpus(ROOT_DIR)
    if not corpus:
        raise SystemExit(f"هیچ فایلِ *.md در {ROOT_DIR} پیدا نشد -- پیکره خالی است.")
    total_chars = sum(len(t) for t in corpus)
    print(f"[۱/۲] پیکره: {len(corpus)} فایل، {total_chars:,} کاراکتر")

    tokenizer = ByteLevelBPETokenizer()
    tokenizer.train(corpus, vocab_size=args.vocab_size, min_frequency=args.min_frequency)
    print(
        f"[۲/۲] آموزش کامل شد: {len(tokenizer.merges)} merge، "
        f"vocab_size نهایی = {tokenizer.vocab_size} (شاملِ {len(tokenizer.special_tokens)} توکنِ ویژه)"
    )

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    tokenizer.save(args.out)
    print(f"ذخیره شد: {args.out}")

    # اعتبارسنجیِ سریعِ round-trip رویِ خودِ پیکره (نه فقط دعوی).
    sample = corpus[0][:500]
    ids = tokenizer.encode(sample)
    restored = tokenizer.decode(ids)
    ok = restored == sample
    print(f"بررسیِ round-trip روی نمونه: {'✅ موفق' if ok else '❌ ناموفق'}")
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
