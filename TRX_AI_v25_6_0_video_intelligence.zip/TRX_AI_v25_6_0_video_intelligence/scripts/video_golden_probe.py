# -*- coding: utf-8 -*-
"""اجرایِ سناریوهایِ طلاییِ ویدیو با render probe (نیازمندِ Node برایِ بخشِ probe). python scripts/video_golden_probe.py"""
import sys, json; sys.path.insert(0,'.')
from trx_ai.video import pipeline, render_probe
from trx_ai.video import semantic_validator as sv
PROMPTS = [
 "یک صحنه بارانی شبانه بساز که دوربین آرام به سمت یک خانه قدیمی نزدیک شود و صدای باران شنیده شود.",
 "یک ویدیوی ۳۰ ثانیه‌ای از جنگل مه‌آلود بساز با صدای باد و بدون موسیقی",
 "باران شروع شود و سپس متوقف شود، با رعد و برق",
 "تغییر نور از روز به شب در یک روستا با پنجره روشن",
 "شخصیت از چپ به راست راه برود و دوربین او را دنبال کند، صدای قدم هم داشته باشد",
 "یک داستان سه‌صحنه‌ای از یک خانه در شب بارانی",
 "تخت جمشید هنگام غروب، آموزشی با روایت فارسی",
 "چرخه آب را آموزشی نشان بده با روایت",
 "Make a futuristic city at night, neon style, camera dolly in, music",
 "یه ویدیو زیر آب بساز بدون صدا",
 "یک اژدها بساز که روی کوه پرواز کند",
 "یک ویدیو بساز",
 "در خانه باز شود با صدای در، شب",
 "یک صحنه کویر عمودی 9:16 کارتونی",
 "انتقال بین دو صحنه در جنگل",
]
for p in PROMPTS:
    b = pipeline.build_video(p, probe=True)
    st = {k: sum(r.status==k for r in b.results) for k in ("PASS","FAIL","UNSUPPORTED")}
    pr = b.report["render_probe"]
    print(f"{b.status:8} {st} rounds={len(b.repairs)} probe_err={pr.get('errors') or pr.get('runtime_error')} bytes={b.report['html_bytes']} cost={b.report['resource']['cost']} | {p[:48]}")
    for r in b.results:
        if r.status != "PASS": print("     ", r.id, r.kind, r.expected, r.status, r.evidence, r.reason)
    for k in ("structure_errors","continuity_errors"):
        if b.report[k]: print("     ", k, b.report[k][:3])
    if not b.report["sync"]["ok"]==b.report["sync"]["checks"]: print("      SYNC", b.report["sync"])
