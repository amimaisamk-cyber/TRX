# -*- coding: utf-8 -*-
"""
شبیه‌سازیِ یک نشستِ کاربریِ واقعی روی موتورهایِ واقعیِ TRX -- نه رویِ
پوسته‌ی کاملِ ترمینال/GUI (که نیاز به rich console/edge-tts/SQLiteِ
واقعی دارد و در این sandbox آفلاین قابلِ نصب نیست)، بلکه مستقیماً روی
لایه‌هایی که واقعاً «هوشمندی» را تعیین می‌کنند:

  - trx_ai.nlu.scorer.detect / score_tools   -> تشخیصِ نیت + انتخابِ ابزار
  - trx_ai.memory_store.MemoryEngine         -> حافظه/ضمیر/موضوع
  - trx_ai.medical.MedicalAIEngine           -> گفتگویِ چندمرحله‌ایِ پزشکی

این یعنی زمان‌بندی‌هایِ این اسکریپت معادلِ سرعتِ واقعیِ اپ نصب‌شده روی
گوشیِ کاربر *نیست* (شبکه/TTS/GUI رندر نمی‌شوند)، ولی درستیِ منطقِ
routing/memory/dialogue را با کدِ واقعی -- نه شبیه‌سازی -- می‌سنجد.
"""
from __future__ import annotations

import sys
import time

sys.path.insert(0, ".")

from trx_ai.nlu.scorer import detect, score_tools  # noqa: E402
from trx_ai.memory_store import MemoryEngine  # noqa: E402
from trx_ai.eval._fakedb import FakeProfileDB  # noqa: E402
from trx_ai.medical import MedicalAIEngine  # noqa: E402


def route(text: str):
    t0 = time.perf_counter()
    result = detect(text)
    tool, _scores, _conf = score_tools(text, result.intent, result.confidence)
    dt = (time.perf_counter() - t0) * 1000
    return result.intent, tool, dt


def finalize_turn(mem, query, response):
    """معادلِ دقیقِ core_engine/turn_processor.finalize (فقط بخشِ حافظه)."""
    topic = mem.extract_topic_entity(query)
    mem.add_message("user", query, topic=topic)
    mem.add_message("assistant", response)
    return topic


def main():
    mem = MemoryEngine(FakeProfileDB())
    engine = MedicalAIEngine()
    session_key = "ux-probe"

    log = []

    def step(label, fn):
        t0 = time.perf_counter()
        out = fn()
        dt = (time.perf_counter() - t0) * 1000
        log.append((label, dt))
        print(f"[{dt:6.2f}ms] {label}")
        print(f"          -> {out}\n")
        return out

    print("=== ۱. اولین پیام (خوش‌آمد) ===")
    intent0, tool0, _ = step("سلام", lambda: route("سلام"))
    finalize_turn(mem, "سلام", "سلام! چطور می‌تونم کمکتون کنم؟")

    print("=== ۲. شروعِ یک موضوع (برایِ تستِ حافظه) ===")
    q1 = "RTX4090 چیه؟"
    a1 = "RTX4090 یک کارتِ گرافیکِ نسل ۴۰ انویدیاست."
    step("RTX4090 چیه؟ (route)", lambda: route(q1))
    finalize_turn(mem, q1, a1)  # دقیقاً معادلِ finalize -- topic اینجا خودکار «RTX4090» می‌شود

    print("=== ۳. سؤالِ پیگیری با ضمیر (تستِ واقعیِ حافظه) ===")
    q2 = "قیمتش چقدره؟"
    resolved, ref_entity = step("resolve_pronoun('قیمتش چقدره؟')", lambda: mem.resolve_pronoun(q2))
    memory_ok_1 = (ref_entity == "RTX4090")
    finalize_turn(mem, q2, "قیمتش حدوداً بین ۳۰ تا ۴۰ میلیون تومانه.")

    print("=== ۴. تغییرِ ناگهانیِ موضوع (پزشکی) ===")
    q3 = "راستی، از دیروز سردرد دارم"
    intent, tool, dt = step(q3, lambda: route(q3))
    dialogue_result = step(
        "start_symptom_check",
        lambda: engine.start_symptom_check(session_key, "از دیروز سردرد دارم"),
    )
    # finalize واقعی اینجا هم صدا زده می‌شود -- حتی برایِ پیامِ پزشکی --
    # ولی extract_topic_entity فقط الگوهایِ «X چیه/کیه/که بود» را
    # می‌شناسد؛ «از دیروز سردرد دارم» با هیچ‌کدام تطبیق نمی‌خورد، پس
    # topic اینجا None می‌ماند و current_topic هنوز رویِ RTX4090 است.
    topic_after_medical = finalize_turn(mem, q3, dialogue_result["message"])

    print("=== ۵. سؤالِ مبهم/نامفهوم وسطِ گفتگویِ پزشکی ===")
    ambiguous_result = step(
        "answer_symptom_check('نمیدونم والا')",
        lambda: engine.answer_symptom_check(session_key, "نمیدونم والا"),
    )
    dialogue_advanced_on_unclear = (
        engine._dialogues.get(session_key, {}).get("turns", 0) > 0
    )
    finalize_turn(mem, "نمیدونم والا", ambiguous_result["message"])

    print("=== ۶. پاسخِ واقعی بعدِ ابهام ===")
    ans_result = step(
        "answer_symptom_check('از دو روز پیش، متوسط')",
        lambda: engine.answer_symptom_check(session_key, "از دو روز پیش، متوسط"),
    )
    finalize_turn(mem, "از دو روز پیش، متوسط", ans_result["message"])

    print("=== ۷. جمله‌یِ «دردِ دل» (باگِ گزارش‌شده، حالا فیکس‌شده) ===")
    q7 = "می‌خوام یکم درد دل کنم"
    intent2, tool2, dt2 = step(q7, lambda: route(q7))
    venting_ok = (tool2 == "emotional_support")
    finalize_turn(mem, q7, "البته، در خدمتم. بگید چی شده.")

    print("=== ۸. ورودیِ عمداً بی‌معنی/خراب ===")
    q8 = "asdkjhqwe ۱۲۳ ??"
    intent3, tool3, dt3 = step(q8, lambda: route(q8))
    garbage_handled_gracefully = (tool3 == "general")
    finalize_turn(mem, q8, "متوجهِ منظورتون نشدم؛ می‌شه دقیق‌تر بگید؟")

    print("=== ۹. بازگشت به موضوعِ اول، خیلی بعدتر (حافظه‌یِ میان‌مدت) ===")
    q9 = "بین این و اون یکی که گفتی کدوم بهتره؟"
    resolved2, ref_entity2 = step("resolve_pronoun (بعدِ تغییرِ موضوع)", lambda: mem.resolve_pronoun(q9))
    # این دقیقاً همان چیزی است که در اپِ واقعی هم اتفاق می‌افتد -- نه
    # مصنوعِ ناقص‌بودنِ این پروب: چون هیچ‌کدام از پیام‌هایِ پزشکی/دردِدل/
    # بی‌معنیِ بینابین با الگوهایِ extract_topic_entity تطبیق نخورد،
    # current_topic هنوز از مرحله‌یِ ۲ (RTX4090) است.

    print("=== ۱۰. تشخیصِ نیتِ اورژانسی (باید فوراً و بدونِ سؤال قطعی باشد) ===")
    urgency = step("درد شدید قفسه سینه دارم و نفسم بالا نمیاد", lambda: engine.assess_urgency(
        "درد شدید قفسه سینه دارم و نفسم بالا نمیاد"
    ))

    total_ms = sum(dt for _, dt in log)
    print("\n" + "=" * 60)
    print("خلاصه:")
    print(f"  حافظه (پیگیریِ فوری با ضمیر) درست بود: {memory_ok_1}  (ref_entity={ref_entity!r})")
    print(f"  موضوعِ حافظه بعدِ گفتگویِ پزشکی: {topic_after_medical!r} (current_topic هنوز: {mem.current_topic!r})")
    print(f"  گفتگویِ پزشکی رویِ پاسخِ نامفهوم پیشرفت نکرد: {not dialogue_advanced_on_unclear}")
    print(f"  «دردِ دل» درست به emotional_support رفت: {venting_ok}  (tool={tool2!r})")
    print(f"  ورودیِ بی‌معنی بدونِ کرش مدیریت شد: {garbage_handled_gracefully}  (tool={tool3!r})")
    print(f"  پرسشِ ضمیریِ دیرهنگام (گامِ ۹) هنوز به RTX4090 وصل شد: {ref_entity2 == 'RTX4090'}  (باید False باشد؛ نشانه‌یِ نقصِ واقعی)")
    print(f"  مجموعِ زمانِ محاسبه‌ایِ همه‌ی مراحل: {total_ms:.2f}ms (فقط منطقِ استدلال، بدونِ شبکه/GUI/TTS)")


if __name__ == "__main__":
    main()
