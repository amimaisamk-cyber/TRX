# -*- coding: utf-8 -*-
"""
run_context_effect_experiment.py -- اجرایِ *دستیِ* آزمایشِ کنترل‌شده‌ی
v25.5.7 (نگاه کنید به
``trx_ai/nervous_system/experiments/context_effect_experiment.py``).

این اسکریپت جزوِ هیچ مسیرِ زنده/تولیدی نیست -- فقط یک ابزارِ مهندسی
است که امیر خودش دستی اجرا می‌کند تا گزارشِ Behavioral Diff را ببیند.

پیش‌نیاز: ``TRX_LOCAL_LLM_MODEL_PATH`` باید به یک فایلِ GGUFِ واقعی
اشاره کند و ``llama-cpp-python`` نصب باشد (نگاه کنید به
``LOCAL_LLM_INTEGRATION_NOTES.md``). بدونِ این دو، اسکریپت با
``overall_result: SKIPPED_NO_MODEL`` (نه خطا) تمام می‌شود.

اجرا:

    python scripts/run_context_effect_experiment.py
    python scripts/run_context_effect_experiment.py --temperature 0.2 --seed 7
"""

from __future__ import annotations

import argparse
import json
import sys

sys.path.insert(0, ".")

from trx_ai.nervous_system.experiments import run_experiment  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--max-new-tokens", type=int, default=200)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--json", action="store_true", help="خروجی را به‌جایِ متنِ خوانا، JSON چاپ کن"
    )
    args = parser.parse_args()

    report = run_experiment(
        temperature=args.temperature,
        max_new_tokens=args.max_new_tokens,
        seed=args.seed,
    )

    if args.json:
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
        return 0

    print(f"=== Controlled Context Effect Experiment (v25.5.7) ===")
    print(f"overall_result: {report.overall_result}")
    print(f"generation_config: {report.generation_config}")
    print()
    for s in report.scenarios:
        print(f"--- {s.scenario_name} [{s.status}] ---")
        if s.status != "OK":
            print(f"  error: {s.error}")
            print()
            continue
        print(f"  FULL    : {s.full_response}")
        print(f"  REDUCED : {s.reduced_response}")
        print(
            f"  exact_match={s.exact_match}  similarity={s.similarity}  "
            f"length_delta={s.length_delta}"
        )
        print(
            f"  behavioral_difference={s.behavioral_difference}  "
            f"semantic_difference={s.semantic_difference}"
        )
        print()
    print("--- notes ---")
    for n in report.notes:
        print(f"  - {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
