# -*- coding: utf-8 -*-
"""
scripts/prove_training_cycle.py -- اثباتِ عملیِ این‌که «چرخه‌یِ
آموزشِ TRX Native Model واقعاً کار می‌کند» (بخشِ سی‌وسومِ سند: معیارِ
واقعیِ موفقیت)، رویِ همان پیکره‌یِ واقعیِ پروژه که
``scripts/train_native_tokenizer.py`` ازش استفاده کرده (بدونِ
اینترنت/دیتاستِ بیرونی).

این اسکریپت به‌ترتیبِ بخشِ سی‌ویکمِ سند اجرا می‌کند:

    ۱. بارگذاریِ توکنایزرِ آموزش‌دیده‌یِ پیش‌فرض (900 واژه).
    ۲. ساختِ توالی‌هایِ Input/Target از تمامِ فایل‌هایِ ``*.md`` ریشه.
    ۳. Gradient Check (تحلیلی در برابرِ عددی) قبل از هر آموزشی.
    ۴. اندازه‌گیریِ Loss/Perplexity/نمونه‌یِ تولیدی -- قبل.
    ۵. چند epoch آموزشِ واقعی (forward_with_cache -> loss -> backward
       -> clip -> AdamW.step) رویِ یک زیرمجموعه‌یِ کوچک.
    ۶. اندازه‌گیریِ دوباره -- بعد -- و مقایسه.

اجرا::

    python scripts/prove_training_cycle.py
"""

from __future__ import annotations

import glob
import os
import sys
import time

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from trx_ai.trx_model.model import TRXModelConfig, TRXNativeModel  # noqa: E402
from trx_ai.trx_model.tokenizer import ByteLevelBPETokenizer  # noqa: E402
from trx_ai.trx_model.training.dataset import build_sequences, train_val_split  # noqa: E402
from trx_ai.trx_model.training.evaluator import evaluate, generate_sample  # noqa: E402
from trx_ai.trx_model.training.gradient_check import format_report, run_gradient_check  # noqa: E402
from trx_ai.trx_model.training.resource_guard import estimate_resources  # noqa: E402
from trx_ai.trx_model.training.trainer import TrainingConfig, train  # noqa: E402

DEFAULT_TOKENIZER_PATH = os.path.join(ROOT_DIR, "trx_ai", "trx_model", "data", "tokenizer.json")


def load_corpus(root_dir: str) -> list[str]:
    texts = []
    for path in sorted(glob.glob(os.path.join(root_dir, "*.md"))):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            texts.append(f.read())
    return texts


def main() -> None:
    print("۱) بارگذاریِ توکنایزرِ پیش‌فرض...")
    tokenizer = ByteLevelBPETokenizer.load(DEFAULT_TOKENIZER_PATH)
    print(f"   vocab_size = {tokenizer.vocab_size}")

    print("۲) ساختِ Dataset از پیکره‌یِ واقعیِ پروژه (*.md ریشه)...")
    texts = load_corpus(ROOT_DIR)
    seq_len = 64
    sequences = build_sequences(tokenizer, texts, seq_len=seq_len)
    train_seqs, val_seqs = train_val_split(sequences, val_fraction=0.1, seed=0)
    print(f"   {len(texts)} سند -> {len(sequences)} دنباله ({len(train_seqs)} train / {len(val_seqs)} val)")

    config = TRXModelConfig(vocab_size=tokenizer.vocab_size, d_model=64, n_layers=2, n_heads=4, d_ff=128, max_seq_len=seq_len, seed=42)
    model = TRXNativeModel(config)
    est = estimate_resources(config, seq_len)
    print(f"   تخمینِ RAM: ~{est.total_estimated_mb:.1f}MB برایِ {est.param_count:,} پارامتر")

    print("۳) Gradient Check (تحلیلی در برابرِ عددی)...")
    gc_result = run_gradient_check(model, train_seqs[0].input_ids, train_seqs[0].target_ids, tolerance=1e-4, seed=0)
    print(format_report(gc_result))
    if not gc_result.passed:
        raise SystemExit("Gradient Check رد شد -- آموزش رویِ Backward نامعتبر خطرناک است؛ متوقف شد.")

    print("۴) اندازه‌گیریِ قبل از آموزش...")
    before = evaluate(model, val_seqs)
    sample_before = generate_sample(model, tokenizer, "TRX_AI", max_new_tokens=15, seed=0)
    print(f"   val loss={before.average_loss:.4f}  ppl={before.perplexity:.2f}")
    print(f"   نمونه: {sample_before!r}")

    print("۵) آموزشِ کوتاهِ واقعی (زیرمجموعه‌ی کوچک -- اثبات، نه pretraining کامل)...")
    t0 = time.time()
    small_train = train_seqs[:40]
    training_config = TrainingConfig(learning_rate=3e-3, epochs=3, seed=1, max_grad_norm=1.0)
    losses: list[float] = []
    report = train(model, small_train, val_seqs, training_config, tokenizer=tokenizer, on_step=lambda r: losses.append(r.loss))
    print(f"   {len(losses)} step در {time.time()-t0:.1f}s -- loss[0]={losses[0]:.4f} -> loss[-1]={losses[-1]:.4f}")
    print(f"   Validation Loss در هر epoch: {[f'{v:.4f}' for v in report.validation_losses]}")

    print("۶) اندازه‌گیریِ بعد از آموزش...")
    after = evaluate(model, val_seqs)
    sample_after = generate_sample(model, tokenizer, "TRX_AI", max_new_tokens=15, seed=0)
    print(f"   val loss={after.average_loss:.4f}  ppl={after.perplexity:.2f}")
    print(f"   نمونه: {sample_after!r}")

    print()
    print("=" * 50)
    print(f"Validation Loss:  {before.average_loss:.4f} -> {after.average_loss:.4f}  "
          f"({'کاهش یافت ✅' if after.average_loss < before.average_loss else 'کاهش نیافت ❌'})")
    print(f"Perplexity:       {before.perplexity:.2f} -> {after.perplexity:.2f}")
    print("=" * 50)


if __name__ == "__main__":
    main()
