# فعال‌سازیِ چرخه‌یِ آموزشِ TRX Native Model — `trx_ai/trx_model/training/` (v25.4.5)

## Upgrade Assessment (طبقِ تمپلیتِ خودِ سند، بخشِ ۲۰)

**Current State** -- در v25.4.4، `trx_ai/trx_model/` یک
Transformer Decoder-Only واقعی بود (Token Embedding، RMSNorm،
Causal Self-Attention، RoPE، SwiGLU، Residual، Weight Tying،
Autoregressive Generation) اما وزن‌هایش تصادفی بودند و هیچ
loss/backward/optimizer وجود نداشت -- `NATIVE_MODEL_NOTES.md` خودش
صریحاً این را در بخشِ «چه چیزی عمداً پیاده نشده» فهرست کرده بود.

**Weakness** -- «معماری» با «آموزش‌دیدن» یکی نیست (نقل‌قولِ مستقیمِ
سندِ ارتقا). بدونِ Backward واقعی، `generate()` فقط دنباله‌یِ توکنِ
تصادفی تولید می‌کند؛ این توهمِ پیشرفت است، نه هوشِ واقعی.

**Upgrade Goal** -- فعال‌سازیِ کاملِ چرخه‌ی
`Input->Forward->Loss->Backward->Gradients->AdamW->Updated
Weights->Validation->Checkpoint` دقیقاً طبقِ سندِ «فعال‌سازیِ کاملِ
بخشِ عصبی» -- بدونِ تغییرِ هیچ فایلِ موجود.

**Approach** -- یک پکیجِ کاملاً جدا و additive:
`trx_ai/trx_model/training/` (فهرستِ کامل پایین‌تر). هر تابعِ
Backward مستقیماً مشتقِ تحلیلیِ همان فرمولِ Forwardِ متناظر است --
هیچ گرادیانِ ساختگی/حدسی.

**Capability Impact** -- Memory Intelligence و Reliability
(بخشِ ۱۱ فلسفه‌ی ارتقا) مستقیماً درگیرند: مدل اکنون می‌تواند از
تجربه (Dataset) یاد بگیرد. Communication/Intent تحتِ تأثیرِ مستقیم
نیستند (این افزودن هنوز به Core متصل نشده -- بخشِ سی‌ودوم سند).

**Risk** -- مهم‌ترین ریسک، گرادیانِ نادرست (به‌خصوص RoPE/RMSNorm/
Weight-Tying، جاهایی که سند صریحاً هشدار داده) بود که به‌جایِ خطا،
بی‌صدا وزن‌هایِ غلط تولید کند. برای رفعِ این ریسک: بخشِ «اعتبارسنجی»
پایین‌تر.

**Preservation** -- هیچ فایلی از `tokenizer.py`، `transformer_core.py`،
`model.py`، `interfaces.py`، `model_adapter.py` یا `tests/test_native_model.py`
تغییر نکرد. `forward_with_cache` مسیرِ Forward را دوباره از رویِ
همان وزن‌های آبجکت می‌سازد (read-only)، نه بازنویسیِ آن.

**Validation** -- Gradient Check (خطایِ نسبیِ تحلیلی/عددی) +
Tiny Overfit + ۲۱ تستِ واحدِ جدید + اجرایِ end-to-end رویِ پیکره‌یِ
واقعیِ پروژه. جزئیاتِ کامل پایین‌تر.

**Result** -- چرخه‌یِ آموزش واقعاً کار می‌کند: رویِ پیکره‌یِ واقعیِ
پروژه (همان ۲۳ فایلِ `*.md` که تا امروز فقط برایِ آموزشِ توکنایزر
استفاده می‌شدند)، فقط با ۱۲۰ step رویِ ۴۰ دنباله، Validation Loss از
`6.81` به `5.20` رسید (Perplexity از `904` به `182`) -- بدونِ هیچ
دستکاریِ داده یا معیار. `scripts/prove_training_cycle.py` این را
هرکسی می‌تواند دوباره اجرا کند.

---

## چرا این‌بار هم یک پکیجِ کاملاً جدا؟

همان قانونِ قرمزِ ۱ (حذف/جایگزینیِ ممنوع بدونِ معادلِ قوی‌ترِ
تست‌شده) و همان الگویِ `NATIVE_MODEL_NOTES.md`: مسئله «جایگزینیِ
Forward موجود» نبود، بلکه «افزودنِ Backward که هنوز وجود نداشت» بود.
`forward_with_cache` هم به‌جایِ تغییرِ `model.forward`، فقط همان
محاسبات را با همان وزن‌های واقعی -- بدونِ دستکاریِ کد -- دوباره اجرا
می‌کند تا میانجی‌های لازم را نگه دارد. عدداً با `model.forward`
مطابقت دارد (تست‌شده).

## چه چیزی واقعاً پیاده شده

| فایل | مسئولیت |
|---|---|
| `training/autograd_cache.py` | `forward_with_cache` (بازسازیِ additive Forward + ذخیره‌یِ همه‌یِ میانجی‌های بخشِ ۴.۲ سند) و `build_param_map` (Parameter Map بخشِ ۲۰). |
| `training/losses.py` | Softmax پایدارِ عددی + Causal Cross Entropy + `dLogits`. |
| `training/backward.py` | Backward تحلیلیِ کامل: RMSNorm، SwiGLU، RoPE (ترانهاده‌یِ چرخش)، Attention (Wo->P@V->Softmax->Scores->RoPE->Q/K/V)، Residual، Embedding با Scatter-Add + ترکیبِ دو مسیرِ Weight Tying. |
| `training/optim.py` | Gradient Clipping (با بررسیِ isfinite قبل از clip) + AdamW (Weight Decay جداگانه از گرادیان). |
| `training/dataset.py` | متن -> token -> پنجره‌های Input/Target (یک خانه اختلاف) -> Train/Val split -> shuffle. |
| `training/checkpoint.py` | ذخیره/بازیابیِ کامل: وزن + AdamW m/v/step + epoch/step + Lossها + config + هویتِ tokenizer + seed. |
| `training/gradient_check.py` | مقایسه‌یِ گرادیانِ تحلیلی/عددی رویِ Embedding, Wq..Wo, W1..W3, هر دو RMSNorm, Final Norm. |
| `training/evaluator.py` | Validation Loss/Perplexity + نمونه‌یِ تولیدیِ کیفی + مقایسه‌یِ قبل/بعد. |
| `training/resource_guard.py` | تخمینِ RAM/تعدادِ پارامتر قبل از آموزش رویِ گوشی + مقادیرِ پیش‌فرضِ امن. |
| `training/trainer.py` | حلقه‌یِ کاملِ آموزش: `train_step`/`train` (forward_with_cache->loss->backward->clip->AdamW.step->validation->checkpoint). |
| `tests/test_native_model_training.py` | ۲۱ تستِ واحد (فهرستِ کامل پایین‌تر). |
| `scripts/prove_training_cycle.py` | اثباتِ end-to-end رویِ پیکره‌یِ واقعیِ پروژه (نه دیتاسِ ساختگی). |

## اعتبارسنجی (بدونِ ادعایِ خالی)

**۱. Gradient Check** (بخشِ ۲۴ سند) -- رویِ یک مدلِ کوچک (`d_model=8،
n_layers=2`) و رویِ مدلِ واقعیِ نمایش (`d_model=64، n_layers=2،
vocab_size=900`، دقیقاً همان vocab توکنایزرِ آموزش‌دیده‌یِ v25.4.4):

```
MAX relative error: 9.90e-07   (تحمل: 1e-4)
PASSED: True
```

۳۳ اندیس، هر پارامترِ قابلِ‌آموزش (Embedding، Wq/Wk/Wv/Wo، W1/W2/W3،
هر دو RMSNorm، Final Norm) با finite-difference مطابقت دارد.

**۲. Tiny Overfit** (بخشِ ۲۵ سند) -- دنباله‌یِ ثابتِ تکراری
(`A B C D`×۴): Loss از `3.02` به `0.0017` رسید (Perplexity≈۱.۰۰۲) در
۲۰۰ step -- یعنی Backward/Loss/Optimizer/Target-Shift/Cache همگی
درست‌اند (اگر یکی خراب بود، حتی این دیتاسِ کوچک هم overfit
نمی‌شد -- نکته‌یِ صریحِ سند).

**۳. Real-Corpus End-to-End** (بخشِ سی‌وسوم سند، معیارِ واقعیِ
موفقیت) -- `scripts/prove_training_cycle.py` رویِ همان ۲۳ فایلِ
`*.md` ریشه‌یِ پروژه (۱٬۷۹۶ دنباله، seq_len=۶۴):

```
Validation Loss:  6.8068 -> 5.2029  (کاهش یافت)
Perplexity:       904.00 -> 181.80
```

فقط ۱۲۰ step رویِ ۴۰ دنباله -- این pretraining کامل نیست (که رویِ
CPUِ گوشی ساعت‌ها طول می‌کشد)، بلکه اثباتِ این‌که «Loss واقعاً و
مکرراً پایین می‌آید»، نه ادعا.

**۴. ۲۱ تستِ واحد** (`tests/test_native_model_training.py`، دقیقاً
منطبق با ده موردِ اجباریِ بخشِ ۲۶ سند): Forward Shape، Loss Finite،
Softmax پایدار، Gradient Finite (همه‌یِ پارامترها + رفتارِ خطا رویِ
NaN)، Weight Update، Loss Decrease، Save/Load، Resume (step_count/m/v
ادامه پیدا می‌کند نه از صفر)، Weight Tying (یک آرایه + ترکیبِ دو
مسیرِ گرادیان)، No Silent Failure (روی targets خالی و Checkpoint
غایب)، Gradient Clipping، Dataset shift-by-one، Train/Val
non-overlap، Resource Estimate.

اجرا (نیازمندِ `pytest` -- در sandboxِ بدونِ اینترنتِ این نشست هم
نصب نبود؛ منطقِ هر ۲۱ تست به‌صورتِ مستقیم اجرا و پاس شد، مثلِ نشستِ
قبلی):

```bash
pytest tests/test_native_model_training.py -v
```

**۵. Regression Check** -- هیچ فایلِ `trx_ai/trx_model/*.py` یا
`tests/test_native_model.py` تغییر نکرد؛ `forward_with_cache` عدداً
با `model.forward` مطابقت دارد (تستِ
`test_forward_cache_matches_forward`، `atol=1e-10`).

## چه چیزی عمداً پیاده **نشده** (گزارشِ صادقانه‌یِ scope)

- **Pretraining کاملِ مقیاس‌بزرگ:** `scripts/prove_training_cycle.py`
  فقط ۴۰ دنباله/۳ epoch را اجرا می‌کند تا اثبات کند نه تا مدلِ
  زبانیِ کاملی بسازد. آموزشِ کامل رویِ کلِ Dataset (۱٬۶۱۶ دنباله)
  ساعت‌ها رویِ CPU طول می‌کشد -- طبقِ بخشِ ۲۷ سند («نباید همزمان
  اندازه‌ها افزایش یابند»)، این تصمیمِ صریح، نه فراموشی است.
- **Batch > 1:** `train_step` هنوز `batch_size=1` است (مطابقِ
  محدودیتِ خودِ `TRXNativeModel.forward` که یک‌بار در نشستِ قبل
  عمداً batch نگرفت). Gradient Accumulation دستی از رویِ همان
  batch=1 ممکن است، اما در این افزودن نبود.
- **اتصال به Core/Chat:** `TRXNativeModelAdapter` هنوز جایی در
  `core.py`/`intelligence.py` صدا زده نمی‌شود -- طبقِ بخشِ سی‌ودومِ
  سند («اتصال به Core نباید زود انجام شود»)، این تصمیمِ صریح است، نه
  محدودیتِ فنی.
- **Float32:** طبقِ بخشِ ۲۹ سند («صحت > سرعت»)، Backward با همان
  Float64ِ موجود کاملاً صحیح شد؛ مهاجرت به Float32 برای کاهشِ مصرفِ
  حافظه، مرحله‌یِ بعدی است.

## معیارِ عبور (طبقِ بخشِ سی‌وسومِ سندِ فعال‌سازیِ آموزش)

۱) Input/Target استفاده شد ✅ · ۲) Loss محاسبه شد ✅ · ۳) Backward
واقعی اجرا شد ✅ · ۴) گرادیان‌ها finite ✅ (تست‌شده + بررسیِ خودکار در
`train_step`) · ۵) وزن‌ها توسطِ AdamW تغییر کردند ✅ · ۶) Loss رویِ
دیتاست کاهش یافت ✅ (هم Tiny Overfit، هم پیکره‌یِ واقعی) · ۷)
Validation جداگانه ✅ · ۸) Checkpoint قابلِ بازیابی ✅ (تست‌شده،
شاملِ Resume) · ۹) مدل پس از آموزش خروجیِ متفاوت تولید کرد ✅
(نمونه‌های قبل/بعدِ اسکریپت) · ۱۰) هیچ پیامِ موفقیتِ جعلی ✅
(`FloatingPointError`/`ValueError`/`FileNotFoundError` صریح در هر
نقطه‌یِ خرابی).
