# Persepolis Foundation — مرحله ۱ از معماری تخت‌جمشید/خورشید/ماه

**نسخه:** v25.5.0
**سند مرجع:** `TRX_AI_Persepolis_Solar_Lunar_Complete_Blueprint.txt` (بندهای ۱، ۱-هـ، ۱۵)
**محدوده:** فقط Persepolis Foundation. Solar Runtime، Lunar Runtime و Resource Controller در این مرحله ساخته **نشدند** — عمداً.

## مرحله ۰ — Mapping (پیش‌نیاز اجباری طبق خودِ سند)

قبل از نوشتن هر کدی، ساختار واقعیِ زیپِ `v25_4_9_phase3_stage4_controlled` با مفاهیم سند تطبیق داده شد:

| مفهوم سند | معادل واقعی | نتیجه |
|---|---|---|
| Solar Processing (Normalizer→...→Action Gate) | `trx_ai/conversation/` (normalizer, context_manager, emotion_analyzer, topic_tracker, continuity_analyzer, intent_candidates, intent_arbitrator, action_gate, response_planner, response_critic) | تقریباً کامل از قبل وجود دارد |
| TRX Supervisor | `core.py` (`TRXEnterpriseAI`) + `core_engine/` (turn_processor, tool_router, agent_bridge, trace) | معادل کارکردی موجود است |
| Native Neural Advisory | `trx_ai/phase3/` (Shadow Mode، v25.4.9) | از قبل هم‌راستا با بند ۱۰ سند در حال پیشرفت است |
| **Lunar Runtime** | هیچ‌کجا | **gap واقعی** |
| **Persepolis governance رسمی (manifest/policy مستقل هر Domain)** | هیچ‌کجا | **gap واقعی** |
| **Event Bus سبک** | هیچ‌کجا | **gap واقعی** (پیش‌نیاز مشترک Solar و Lunar) |
| **Health registry رسمی** | هیچ‌کجا (فقط `health_metrics.py`/`health_utils.py` پراکنده و موضوعاً متفاوت — مربوط به سلامتِ کاربر، نه سلامتِ سیستم) | **gap واقعی** |

نتیجه: بخش بزرگی از «خورشید» از قبل واقعی و تست‌شده است. کاری که واقعاً جدید و لازم است، Persepolis Foundation (قرارداد مشترک) و بعد Lunar است — نه بازنویسیِ Conversation Intelligence.

## Current State

قبل از این ارتقا، هیچ قراردادِ رسمیِ مشترکی برای «Domain manifest»، «health status» یا «event» بین بخش‌های TRX وجود نداشت. هر بخش (medical، phase3، conversation) به‌صورت مستقل و بدون یک زبانِ مشترک ساخته شده بود.

## Problem

بدون یک قراردادِ پایه‌ی مشترک، ساختنِ Solar Resource Controller یا Lunar Runtime در مراحل بعدی باعث می‌شد هرکدام قراردادِ خودشان را اختراع کنند — دقیقاً همان خطرِ بند ۳ سندِ ممیزیِ بحرانی («Core باید مرکز واقعی سیستم شود»، اینجا در سطحِ معماریِ جدید).

## Root Cause

سندِ تخت‌جمشید یک معماریِ چندلایه (Foundation → Solar → Lunar → Governance) پیشنهاد می‌کند، اما پروژه تا امروز چنین لایه‌ای نداشت.

## Solution

پکیجِ کاملاً افزودنیِ `trx_ai/civilization/foundation/` و `trx_ai/civilization/domains/` ساخته شد:

- `foundation/contracts.py` — `DomainManifest`، `HealthStatus`/`HealthReport`، `EventEnvelope` (فقط dataclass/Enum، بدون رفتار).
- `foundation/errors.py` — سلسله‌مراتبِ کوچکِ خطا.
- `foundation/health.py` — `HealthRegistry`: **fail-soft** (اگر یک health check exception بیندازد یا مقدارِ نادرست برگرداند، UNKNOWN برمی‌گرداند، هرگز کل را نمی‌شکند) + `aggregate_status`.
- `foundation/events.py` — `EventBus`: in-process، **bounded** (deque با `maxlen`، پیش‌فرض ۵۰۰)، **fail-soft** برای subscriberها (استثنای یک handler بقیه را متوقف نمی‌کند و publish را نمی‌شکند).
- `domains/registry.py` — `DomainRegistry` + `build_default_registry()`: توصیفِ اعلانیِ Domainهای واقعیِ موجود (conversation، nlu، medical، phase3، core_engine، tools، memory_store) طبق نتیجه‌ی mapping بالا — **بدون import کردنِ خودِ آن پکیج‌ها**، پس حتی اگر یکی از آن‌ها import شکسته داشته باشد، ساختِ registry شکست نمی‌خورد.

**بدون تغییر رفتار:** هیچ فایلِ موجودِ دیگری در `trx_ai/` تغییر نکرد (اثباتش: `diff -rq` بینِ زیپِ ورودی و خروجی، بجز پکیجِ جدید و یک فایلِ تستِ جدید، هیچ تفاوتی ندارد). `trx_ai/civilization` در `trx_ai/__init__.py` هم import نشده — یعنی حتی import شدنِ خودِ پکیجِ اصلی هم به این کد وصل نیست؛ کاملاً opt-in است، دقیقاً مثلِ الگویِ `phase3` در مرحله‌ی ۱.

## Risk

- **ریسکِ اصلی همان «توهمِ پیشرفت» بود:** ساختنِ یک لایه‌ی جدید بدون رفتارِ واقعی. برای مهارِ آن: این مرحله عمداً به Solar/Lunar Runtime واقعی متصل نشد؛ فقط زیرساختِ لازم برایِ آن‌ها ساخته شد، و همین در کد و مستندات صادقانه اعلام شده (نه ادعایِ کامل بودنِ Solar/Lunar).
- ریسکِ فنی: صفر برای کدِ موجود، چون هیچ فایلِ موجودی import یا تغییر نکرد؛ حتی اگر `trx_ai/civilization` بعداً حذف شود، هیچ‌جایِ دیگری نمی‌شکند.

## Preservation

همه‌ی رفتارِ موجود (v25.4.9، ۵۹/۵۹ تستِ Phase3، همه‌ی Domainهای پزشکی/ابزار/گفتگو) دست‌نخورده باقی ماند — چون هیچ فایلِ موجودی لمس نشد.

## Validation

- ۲۲ تستِ جدید در `tests/test_civilization_foundation.py` (contracts، health registry fail-soft، event bus bounded+fail-soft، domain registry، و یک تستِ ایستا با AST که تضمین می‌کند این پکیج واقعاً هیچ importِ استاتیکی از `trx_ai.core`/`trx_ai.intelligence`/`trx_ai.conversation` ندارد).
- **محدودیتِ صادقانه:** در این محیطِ ساخت، دسترسیِ شبکه بسته بود، پس `pytest` قابلِ نصب نبود. تست‌ها را با یک harnessِ معادل و بدون‌وابستگی (فقط stdlib) اجرا کردم — همه‌ی ۲۲ assertion پاس شدند — و همچنین با `ast.parse` سینتکسِ هر فایل را تأیید کردم. توصیه: `pytest tests/test_civilization_foundation.py -q` را خودتان هم روی دستگاهِ واقعی اجرا کنید تا با pytest واقعی هم تأیید شود (فایلِ تست دقیقاً با API pytest نوشته شده، نه فقط harness من).
- `diff -rq` بینِ زیپِ ورودی و خروجی (به‌جز پکیجِ جدید و یک فایلِ تست) تأیید کرد صفر فایلِ موجود تغییر کرده.

## Result

TRX اکنون یک زبانِ مشترکِ آزمایش‌شده برای Domain manifest، health، و event دارد که Solar Resource Controller و Lunar Runtime (مراحلِ بعدی) رویِ همین بنا خواهند شد — بدونِ اینکه هیچ رفتارِ فعلی تغییر کرده باشد.

## گامِ پیشنهادیِ بعدی (تصمیمِ نهایی با امیر)

با این پایه، دو مسیرِ منطقی برای جلسه‌ی بعد:
1. **Solar Resource Controller** (SOLAR_FULL/BALANCED/LOW/SAFE) — روی `HealthRegistry`/`EventBus` همین مرحله سوار می‌شود، و واقعاً چیزِ جدیدی اضافه می‌کند (نه فقط بازنویسیِ Conversation Intelligenceِ موجود).
2. **Lunar Runtime اسکلتِ اولیه** (`collect_events` روی همین `EventBus`، بدونِ تغییرِ مستقیمِ چیزی) — چون Foundation لازم برایش الان آماده است.
