# -*- coding: utf-8 -*-
"""
ابزارهای عمومی سیستم: تشابه متن، ماشین‌حساب امن (بر پایه‌ی AST)،
مترجم، جستجوی وب/ویکی‌پدیا، آب‌وهوا، مدیریت فایل و تحلیل کد.

نکته‌ی امنیتی: CalculatorEngine از ابتدا با ast.parse پیاده‌سازی شده
(نه eval()) و هیچ تغییری در منطق آن داده نشده؛ همین رویکرد به‌عنوان
الگوی صحیح ارزیابی امن عبارات در این پروژه حفظ شده است.
"""

from __future__ import annotations

import ast
import asyncio
import operator
import os
import re
import urllib.parse
from datetime import datetime

import aiohttp
from bs4 import BeautifulSoup

from .dependencies import DOCX_AVAILABLE, EXCEL_AVAILABLE, PDF_AVAILABLE, PIL_AVAILABLE
from .logging_config import get_logger

logger = get_logger(__name__)

if DOCX_AVAILABLE:
    from docx import Document
if EXCEL_AVAILABLE:
    from openpyxl import load_workbook
if PIL_AVAILABLE:
    from PIL import Image
if PDF_AVAILABLE:
    import pdfplumber

class TextSimilarityEngine:
    @staticmethod
    def levenshtein_distance(s1, s2):
        if len(s1) < len(s2):
            return TextSimilarityEngine.levenshtein_distance(s2, s1)
        if len(s2) == 0:
            return len(s1)
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                current_row.append(min(previous_row[j + 1] + 1,
                                       current_row[j] + 1,
                                       previous_row[j] + (c1 != c2)))
            previous_row = current_row
        return previous_row[-1]

    @staticmethod
    def calculate_similarity(w1, w2):
        w1, w2 = w1.strip().lower(), w2.strip().lower()
        max_len = max(len(w1), len(w2))
        if max_len == 0:
            return 1.0
        return 1.0 - (TextSimilarityEngine.levenshtein_distance(w1, w2) / max_len)

class CalculatorEngine:
    _operators = {
        ast.Add: operator.add, ast.Sub: operator.sub,
        ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.USub: operator.neg
    }

    @classmethod
    def _eval_node(cls, node):
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        elif isinstance(node, ast.Num):
            return node.n
        elif isinstance(node, ast.BinOp):
            op_type = type(node.op)
            if op_type not in cls._operators:
                raise ValueError(f"عملگر غیرمجاز: {op_type}")
            left = cls._eval_node(node.left)
            right = cls._eval_node(node.right)
            if op_type == ast.Div and right == 0:
                raise ZeroDivisionError("تقسیم بر صفر مجاز نیست!")
            return cls._operators[op_type](left, right)
        elif isinstance(node, ast.UnaryOp):
            op_type = type(node.op)
            if op_type not in cls._operators:
                raise ValueError(f"عملگر یکانی غیرمجاز: {op_type}")
            return cls._operators[op_type](cls._eval_node(node.operand))
        else:
            raise TypeError(f"نوع گره غیرمجاز: {type(node)}")

    @classmethod
    def safe_eval(cls, expr, formatter_func):
        clean_expr = (expr
                      .replace("ضربدر", "*").replace("تقسیم بر", "/")
                      .replace("منهای", "-").replace("بعلاوه", "+"))
        clean_expr = "".join(c for c in clean_expr if c in "0123456789+-*/().^ ")
        clean_expr = clean_expr.replace("^", "**").strip()
        if not clean_expr:
            return "❌ فرمول ریاضی معتبری یافت نشد. مثال: (2 + 3) * 5"
        try:
            tree = ast.parse(clean_expr, mode='eval')
            result = cls._eval_node(tree.body)
            if isinstance(result, float) and result.is_integer():
                result = int(result)
            return f"🔢 حاصل محاسبات:\n\n{formatter_func(result)}"
        except ZeroDivisionError as e:
            return f"🚨 خطای ریاضی: {e}"
        except (TypeError, ValueError) as e:
            return f"🚨 [گارد امنیتی]: {e}"
        except Exception as e:
            return f"❌ خطا: {str(e)}"

class TranslatorEngine:
    @staticmethod
    async def get_translation(session, text, mode="auto"):
        if not text.strip():
            return "❌ متنی وارد نشده."
        base_url = "https://translate.googleapis.com/translate_a/single"
        if mode == "auto":
            is_eng = all(ord(c) < 128 for c in text.replace(" ", ""))
            sl, tl = ("en", "fa") if is_eng else ("fa", "en")
        elif mode == "fa2en":
            sl, tl = "fa", "en"
        else:
            sl, tl = "en", "fa"
        params = {"client": "gtx", "sl": sl, "tl": tl, "dt": "t", "q": text}
        try:
            async with session.get(base_url, params=params,
                                   timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status == 200:
                    data = await resp.json(content_type=None)
                    translated = "".join([p[0] for p in data[0] if p and p[0]])
                    return f"🔀 ترجمه ({sl}→{tl}):\n\n{translated}" if translated else "❌ ترجمه‌ای دریافت نشد."
                return f"❌ سرویس ترجمه: کد {resp.status}"
        except asyncio.TimeoutError:
            return "❌ زمان اتصال به پایان رسید."
        except Exception as e:
            return f"❌ خطای شبکه: {type(e).__name__}"

class LanguageEngine:
    """
    تشخیصِ زبانِ ورودی + ترجمه‌ی رفت‌وبرگشتی به فارسی، برای اینکه
    دستیار به هر زبانی که کاربر بپرسد، به همان زبان جواب بدهد.

    چرا این‌طور طراحی شده: تقریباً کلِ منطقِ داخلیِ برنامه (تشخیصِ نیت،
    پایگاه‌دانشِ پزشکی، آنالیزگرِ کد) صرفاً روی کلیدواژه‌ها و محتوای
    فارسی کار می‌کند. به‌جای بازنویسیِ همه‌چیز برای هر زبان (که عملاً
    غیرممکن است)، این کلاس ورودیِ غیرفارسی را قبل از پردازش به فارسی
    ترجمه می‌کند و پاسخِ نهایی را دوباره به زبانِ اصلیِ کاربر برمی‌گرداند
    — دقیقاً همان چیزی که خواسته شده: «با هر زبان سرچ شود، با همان
    زبان جواب بده».

    اگر شبکه در دسترس نباشد یا تشخیص/ترجمه شکست بخورد، هرگز برنامه را
    متوقف نمی‌کند؛ فقط ساکت به حالتِ فارسی برمی‌گردد (تجربه‌ی فعلی).
    """

    _TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single"
    _FA_CHAR_RANGE = re.compile(r'[\u0600-\u06FF]')

    @classmethod
    async def detect_language(cls, session, text: str) -> str:
        """
        کدِ زبانِ ورودی را برمی‌گرداند (مثلاً "fa"، "en"، "ar"، "fr").
        اگر متن عمدتاً از حروفِ فارسی/عربی تشکیل شده، بدونِ درخواستِ
        شبکه مستقیماً "fa" برمی‌گردد (سریع‌تر و برای رایج‌ترین حالت
        اصلاً نیازی به تماسِ شبکه‌ای نیست).
        """
        if not text or not text.strip():
            return "fa"
        # اگر بیشترِ کاراکترها فارسی/عربی‌اند، همان‌جا فارسی فرض کن
        letters = [c for c in text if c.isalpha()]
        if letters:
            fa_ratio = sum(1 for c in letters if cls._FA_CHAR_RANGE.match(c)) / len(letters)
            if fa_ratio > 0.5:
                return "fa"
        try:
            params = {"client": "gtx", "sl": "auto", "tl": "fa", "dt": "t", "q": text[:500]}
            async with session.get(cls._TRANSLATE_URL, params=params,
                                   timeout=aiohttp.ClientTimeout(total=6)) as resp:
                if resp.status != 200:
                    return "fa"
                data = await resp.json(content_type=None)
                detected = data[2] if len(data) > 2 and isinstance(data[2], str) else None
                return detected or "fa"
        except Exception as e:
            logger.debug("تشخیصِ زبان ناموفق بود؛ فرضِ فارسی: %s", e)
            return "fa"

    @classmethod
    async def translate_text(cls, session, text: str, source: str, target: str) -> str:
        """
        متن را از `source` به `target` ترجمه می‌کند. اگر source==target
        یا متن خالی باشد، بدونِ تماسِ شبکه‌ای همان متن برمی‌گردد. در
        صورتِ خطا، متنِ اصلی (بدونِ ترجمه) برگردانده می‌شود — بهتر است
        کاربر پاسخِ فارسی ببیند تا هیچ‌چیز نبیند.
        """
        if not text or not text.strip() or source == target:
            return text
        try:
            params = {"client": "gtx", "sl": source, "tl": target, "dt": "t", "q": text}
            async with session.get(cls._TRANSLATE_URL, params=params,
                                   timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status != 200:
                    return text
                data = await resp.json(content_type=None)
                translated = "".join(p[0] for p in data[0] if p and p[0])
                return translated or text
        except Exception as e:
            logger.debug("ترجمه ناموفق بود؛ متنِ اصلی برگردانده شد: %s", e)
            return text


class WebSearchEngine:
    # نکته: قبلاً فقط User-Agent فرستاده می‌شد؛ برخی سایت‌ها (به‌خصوص
    # DuckDuckGo) درخواست‌های بدونِ Accept/Accept-Language را مسدود یا
    # rate-limit می‌کنند چون شبیهِ ربات به نظر می‌رسند. هدرهای زیر یک
    # مرورگرِ واقعی را کامل‌تر شبیه‌سازی می‌کنند.
    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7",
        "Connection": "keep-alive",
    }

    @staticmethod
    async def get_wikipedia(session, query):
        url = f"https://fa.wikipedia.org/wiki/{urllib.parse.quote(query)}"
        try:
            async with session.get(url, headers=WebSearchEngine.HEADERS,
                                   timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status == 200:
                    soup = BeautifulSoup(await resp.text(), "html.parser")
                    body = soup.find(id="mw-content-text")
                    if body:
                        paragraphs = body.find_all("p")
                        valid = [p.get_text().strip() for p in paragraphs if len(p.get_text().strip()) > 40]
                        return "\n\n".join(valid[:3]) if valid else None
                return None
        except asyncio.TimeoutError:
            return "📡 ویکی‌پدیا در دسترس نیست."
        except aiohttp.ClientConnectorError:
            return "🌐 اینترنت قطع است."
        except Exception:
            return None

    @staticmethod
    async def search_duckduckgo(session, query):
        url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
        try:
            async with session.get(url, headers=WebSearchEngine.HEADERS,
                                   timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status == 200:
                    soup = BeautifulSoup(await resp.text(), "html.parser")
                    results = (soup.find_all("a", class_="result__snippet") or
                               soup.find_all("div", class_="result__body"))
                    snippets = []
                    for res in results:
                        t = res.get_text().strip()
                        if 60 < len(t) < 400 and not t.startswith("http"):
                            snippets.append(t)
                            if len(snippets) >= 3:
                                break
                    return "🌐 یافته‌های جستجو:\n\n" + "\n\n".join(snippets) if snippets else None
        except Exception:
            return None

    @staticmethod
    async def get_vajehyab(session, word):
        clean = word.replace("معنی کلمه", "").replace("معنی", "").strip()
        if not clean:
            return "❌ کلمه‌ای وارد نشده."
        url = f"https://www.vajehyab.com/?q={urllib.parse.quote(clean)}"
        try:
            async with session.get(url, headers=WebSearchEngine.HEADERS,
                                   timeout=aiohttp.ClientTimeout(total=8)) as resp:
                if resp.status == 200:
                    soup = BeautifulSoup(await resp.text(), "html.parser")
                    meanings = []
                    for sel in ["p.text", "div.result", "li", "p"]:
                        items = soup.select(sel)
                        for item in items:
                            t = item.get_text().strip()
                            if 20 < len(t) < 600:
                                meanings.append(t)
                                if len(meanings) >= 3:
                                    break
                        if meanings:
                            break
                    return f"📖 معنی '{clean}':\n\n" + "\n".join(meanings) if meanings else f"⚠️ '{clean}' یافت نشد."
        except Exception as e:
            return f"🌐 خطا: {type(e).__name__}"

class MedicalWebSearchEngine:
    """
    اتصال موتور پزشکی به منابع معتبر آنلاین.

    برخلاف WebSearchEngine (که برای جستجوی عمومی وب/ویکی‌پدیا است)، این
    کلاس مشخصاً به یک پایگاه‌داده‌ی پزشکیِ رسمی وصل می‌شود:

      • MedlinePlus — سرویس وب رسمی و رایگانِ «کتابخانه‌ی ملی پزشکی
        آمریکا» (NLM/NIH) که نیازی به کلید API ندارد و برای اطلاعات
        عمومیِ بیماری/دارو طراحی شده (نه تشخیص یا تجویز).
        مستندات: https://medlineplus.gov/webservices.html

    چون MedlinePlus فقط انگلیسی است، برای پرسش‌های فارسی از مترجم
    داخلی (TranslatorEngine) برای پل‌زدن استفاده می‌شود: پرسش به
    انگلیسی ترجمه می‌شود، از MedlinePlus خلاصه گرفته می‌شود، سپس خلاصه
    به فارسی برگردانده می‌شود. اگر هر مرحله شکست بخورد، به‌جای خطا،
    None برگردانده می‌شود تا لایه‌ی بالاتر بتواند منابع دیگر (ویکی‌پدیا/
    جستجوی عمومی) را امتحان کند.
    """

    MEDLINEPLUS_URL = "https://wsearch.nlm.nih.gov/ws/query"
    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7",
    }

    # کش کوتاه‌مدت درون‌حافظه‌ای برای پرهیز از درخواست‌های تکراری به
    # سرویس‌های خارجی (مستقل از CacheManager عمومی برنامه تا این ماژول
    # به‌تنهایی هم قابل استفاده/تست باشد).
    _cache: dict = {}
    _CACHE_TTL = 1800  # ۳۰ دقیقه

    @classmethod
    def _cache_get(cls, key):
        entry = cls._cache.get(key)
        if not entry:
            return None
        value, ts = entry
        if datetime.now().timestamp() - ts > cls._CACHE_TTL:
            cls._cache.pop(key, None)
            return None
        return value

    @classmethod
    def _cache_set(cls, key, value):
        if len(cls._cache) > 300:
            cls._cache.pop(next(iter(cls._cache)), None)
        cls._cache[key] = (value, datetime.now().timestamp())

    @staticmethod
    def _strip_html(fragment: str) -> str:
        return BeautifulSoup(fragment or "", "html.parser").get_text().strip()

    @classmethod
    async def _fetch_with_retry(cls, session, url, params, attempts=2, timeout=8):
        last_exc = None
        for attempt in range(attempts):
            try:
                async with session.get(url, params=params, headers=cls.HEADERS,
                                        timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                    if resp.status == 200:
                        return await resp.text()
                    last_exc = RuntimeError(f"HTTP {resp.status}")
            except (asyncio.TimeoutError, aiohttp.ClientError) as e:
                last_exc = e
                await asyncio.sleep(0.4 * (attempt + 1))
        if last_exc:
            logger.warning("MedlinePlus fetch failed after retries: %s", last_exc)
        return None

    @classmethod
    async def query_medlineplus(cls, session, term_en: str, max_results: int = 2):
        """
        پرسش مستقیم (انگلیسی) از MedlinePlus. خروجی: لیست دیکشنری‌های
        {'title': ..., 'snippet': ..., 'url': ...} یا None.
        """
        if not term_en or not term_en.strip():
            return None
        cache_key = f"mlp:{term_en.strip().lower()}"
        cached = cls._cache_get(cache_key)
        if cached is not None:
            return cached

        params = {"db": "healthTopics", "term": term_en.strip(), "rettype": "brief"}
        xml_text = await cls._fetch_with_retry(session, cls.MEDLINEPLUS_URL, params)
        if not xml_text:
            return None
        try:
            soup = BeautifulSoup(xml_text, "html.parser")
            documents = soup.find_all("document")
            results = []
            for doc in documents[:max_results]:
                title_tag = doc.find("content", attrs={"name": "title"})
                snippet_tag = doc.find("content", attrs={"name": "FullSummary"}) or \
                    doc.find("content", attrs={"name": "snippet"})
                title = cls._strip_html(title_tag.get_text()) if title_tag else ""
                snippet = cls._strip_html(snippet_tag.get_text()) if snippet_tag else ""
                url = doc.get("url", "")
                if title or snippet:
                    results.append({"title": title, "snippet": snippet[:600], "url": url})
            cls._cache_set(cache_key, results or None)
            return results or None
        except Exception as e:
            logger.warning("MedlinePlus parse error: %s", e)
            return None

    @classmethod
    async def get_medical_summary_fa(cls, session, query_fa: str, translator=None):
        """
        نسخه‌ی «فارسی به فارسی»: پرسش فارسی → ترجمه به انگلیسی →
        MedlinePlus → ترجمه‌ی خلاصه به فارسی. اگر مترجم در دسترس نباشد
        یا هرکدام از مراحل شکست بخورد، None برمی‌گردد (نه خطا) تا لایه‌ی
        بالاتر بتواند منبع دیگری را امتحان کند.
        """
        translator = translator or TranslatorEngine
        try:
            translated = await translator.get_translation(session, query_fa, mode="fa2en")
            if not translated or translated.startswith("❌"):
                return None
            term_en = translated.split(":", 1)[-1].strip()
            term_en = re.sub(r'^\s*🔀[^:]*:\s*', '', term_en).strip()
            if not term_en:
                return None
        except Exception as e:
            logger.warning("Medical query translation to English failed: %s", e)
            return None

        results = await cls.query_medlineplus(session, term_en)
        if not results:
            return None

        combined_en = "\n".join(f"{r['title']}: {r['snippet']}" for r in results if r.get("snippet"))
        if not combined_en.strip():
            return None

        try:
            translated_back = await translator.get_translation(session, combined_en, mode="en2fa")
            if translated_back and not translated_back.startswith("❌"):
                body = translated_back.split(":", 1)[-1].strip()
                sources = ", ".join(r["url"] for r in results if r.get("url"))[:250]
                footer = f"\n\n(منبع: MedlinePlus – کتابخانه‌ی ملی پزشکی آمریکا. {sources})" if sources else \
                    "\n\n(منبع: MedlinePlus – کتابخانه‌ی ملی پزشکی آمریکا)"
                return body + footer
        except Exception as e:
            logger.warning("Medical summary translation back to Persian failed: %s", e)
        return None


class WeatherEngine:
    @staticmethod
    async def get_weather(session, city):
        try:
            # نکته: قبلاً نام شهر بدونِ URL-encode مستقیم داخلِ URL می‌رفت؛
            # برای شهرهای چندکلمه‌ای (مثلاً «New York») این یک URL نامعتبر
            # می‌ساخت و درخواست بی‌سروصدا شکست می‌خورد.
            encoded_city = urllib.parse.quote(city.strip())
            url = f"https://wttr.in/{encoded_city}?format=%C+%t"
            async with session.get(url, timeout=8) as response:
                if response.status == 200:
                    data = await response.text()
                    return f"☁️ آب و هوای {city}: {data.strip()}"
                else:
                    return f"❌ خطا در دریافت آب و هوا (کد {response.status})"
        except Exception as e:
            return f"❌ خطا: {type(e).__name__}"

class FileValidationError(ValueError):
    """ورودیِ نامعتبر برایِ آپلودِ فایل -- پیامش مستقیم قابلِ‌نمایش به کاربر است."""


class FileManager:
    """مدیریت فایل‌های مختلف"""

    # پسوندهایی که «بخوان» و آپلودِ فایل در رابطِ وب هردو پشتیبانی
    # می‌کنند -- باید با شاخه‌های ``read_file`` زیر هماهنگ بماند.
    ALLOWED_UPLOAD_EXTENSIONS = {
        ".pdf", ".docx", ".doc", ".xlsx", ".xls",
        ".txt", ".py", ".json", ".csv", ".html", ".css", ".js", ".md",
        ".jpg", ".jpeg", ".png", ".gif", ".bmp",
    }
    MAX_UPLOAD_BYTES = 20 * 1024 * 1024  # ۲۰ مگابایت -- سقفِ منطقی برایِ اسناد/اکسل
    MAX_CONTENT_CHARS = 8000  # جلوگیری از سیل‌شدنِ چت با یک PDF چندصدصفحه‌ای

    @staticmethod
    def save_incoming(raw_bytes: bytes, original_filename: str, files_dir: str) -> str:
        """اعتبارسنجی + ذخیره‌ی امنِ فایلِ آپلودشده (برایِ رابطِ وب).

        در صورتِ نامعتبربودن، ``FileValidationError`` با پیامِ فارسیِ
        قابلِ‌نمایش می‌اندازد. خروجی: مسیرِ کاملِ فایلِ ذخیره‌شده رویِ دیسک.
        """
        import uuid

        if not raw_bytes:
            raise FileValidationError("❌ فایل خالی بود.")
        if len(raw_bytes) > FileManager.MAX_UPLOAD_BYTES:
            mb = FileManager.MAX_UPLOAD_BYTES // (1024 * 1024)
            raise FileValidationError(f"❌ حجمِ فایل بیش از حدِ مجاز است (حداکثر {mb} مگابایت).")

        ext = os.path.splitext(original_filename or "")[1].lower()
        if ext not in FileManager.ALLOWED_UPLOAD_EXTENSIONS:
            allowed = "، ".join(sorted(FileManager.ALLOWED_UPLOAD_EXTENSIONS))
            raise FileValidationError(f"❌ فرمتِ «{ext or 'نامشخص'}» پشتیبانی نمی‌شود. فرمت‌هایِ مجاز: {allowed}")

        os.makedirs(files_dir, exist_ok=True)
        safe_name = f"{uuid.uuid4().hex}{ext}"
        path = os.path.join(files_dir, safe_name)
        with open(path, "wb") as f:
            f.write(raw_bytes)
        return path

    @staticmethod
    def read_file(filepath):
        """خواندن فایل بر اساس پسوند"""
        if not os.path.exists(filepath):
            return f"❌ فایل {filepath} یافت نشد"
        
        ext = os.path.splitext(filepath)[1].lower()
        
        try:
            if ext == '.pdf' and PDF_AVAILABLE:
                with pdfplumber.open(filepath) as pdf:
                    text = ""
                    for page in pdf.pages:
                        text += page.extract_text() or ""
                return FileManager._present_content("📄 محتویات فایل PDF", text)
            
            elif ext in ['.docx', '.doc'] and DOCX_AVAILABLE:
                doc = Document(filepath)
                text = "\n".join([p.text for p in doc.paragraphs])
                return FileManager._present_content("📄 محتویات فایل Word", text)
            
            elif ext in ['.xlsx', '.xls'] and EXCEL_AVAILABLE:
                wb = load_workbook(filepath, data_only=True)
                text = ""
                for sheet in wb.worksheets:
                    text += f"\n--- {sheet.title} ---\n"
                    for row in sheet.iter_rows(values_only=True):
                        text += " | ".join(str(cell) if cell is not None else "" for cell in row) + "\n"
                return FileManager._present_content("📊 محتویات فایل Excel", text)
            
            elif ext in ['.txt', '.py', '.json', '.csv', '.html', '.css', '.js', '.md']:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                return FileManager._present_content(f"📄 محتویات فایل {ext}", content)
            
            elif ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp'] and PIL_AVAILABLE:
                img = Image.open(filepath)
                info = f"🖼️ تصویر: {os.path.basename(filepath)}\n"
                info += f"   ابعاد: {img.width}×{img.height}\n"
                info += f"   فرمت: {img.format}\n"
                info += f"   حالت: {img.mode}\n"
                return info
            
            else:
                return f"⚠️ فرمت فایل {ext} پشتیبانی نمی‌شود"
                
        except Exception as e:
            return f"❌ خطا در خواندن فایل: {str(e)}"

    @staticmethod
    def _present_content(header: str, text: str) -> str:
        """کوتاه‌کردنِ متنِ استخراج‌شده اگر خیلی بلند باشد (تا چت با یک
        فایلِ چندصدصفحه‌ای سیل نشود)، با ذکرِ صریحِ این‌که بریده شده."""
        text = text or ""
        if len(text) > FileManager.MAX_CONTENT_CHARS:
            shown = text[:FileManager.MAX_CONTENT_CHARS]
            remaining = len(text) - FileManager.MAX_CONTENT_CHARS
            return (
                f"{header}:\n\n{shown}\n\n"
                f"…(✂️ {remaining:,} کاراکترِ دیگر بریده شد؛ فایل کامل رویِ دیسک موجود است)"
            )
        return f"{header}:\n\n{text}" if text.strip() else f"{header}: (فایل متنی خالی بود یا متنی استخراج نشد)"
    
    @staticmethod
    def save_file(content, filepath):
        """ذخیره فایل"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return f"✅ فایل {filepath} ذخیره شد"
        except Exception as e:
            return f"❌ خطا در ذخیره فایل: {str(e)}"
    
    @staticmethod
    def list_files(directory="files"):
        """لیست فایل‌های دایرکتوری"""
        if not os.path.exists(directory):
            return "❌ دایرکتوری وجود ندارد"
        
        files = []
        for f in os.listdir(directory):
            filepath = os.path.join(directory, f)
            if os.path.isfile(filepath):
                size = os.path.getsize(filepath)
                modified = datetime.fromtimestamp(os.path.getmtime(filepath)).strftime("%Y-%m-%d %H:%M")
                files.append({
                    "name": f,
                    "size": size,
                    "size_str": f"{size/1024:.1f} KB" if size < 1024*1024 else f"{size/(1024*1024):.1f} MB",
                    "modified": modified
                })
        
        if not files:
            return "📂 دایرکتوری خالی است"
        
        result = "📂 فایل‌ها:\n"
        for f in sorted(files, key=lambda x: x['name']):
            result += f"  • {f['name']} ({f['size_str']}) - {f['modified']}\n"
        return result

class CodeIntelligence:
    """
    تحلیل‌گرِ کد — بر پایه‌ی `ast` واقعیِ پایتون (نه regex روی خط‌به‌خط).

    چرا ast؟ چون regex نمی‌تواند ساختار واقعیِ کد را بفهمد (تو در توییِ
    بلاک‌ها، مرزِ دقیقِ یک تابع، آرگومان‌های پیش‌فرض و...)، در حالی که
    `ast.parse` همان چیزی را می‌بیند که مفسر پایتون می‌بیند — بدون اینکه
    کد واقعاً اجرا (exec/eval) شود، پس کاملاً امن است.

    خروجی یک گزارشِ ساختاریافته با «امتیاز کیفیت» (شبیه به سبکِ گزارشِ
    تشخیصیِ موتور پزشکی) است: خلاصه، مشکلاتِ امنیتی، مشکلاتِ ساختاری،
    پیشنهادها و آمار.
    """

    # ----- الگوهای امنیتیِ پرخطر که باید همیشه با هشدارِ جدی مشخص شوند -----
    _DANGEROUS_CALLS = {
        "eval": "اجرای کدِ دلخواه از رشته — می‌تواند مسیرِ نفوذ باشد",
        "exec": "اجرای کدِ دلخواه از رشته — می‌تواند مسیرِ نفوذ باشد",
        "os.system": "اجرای دستورِ شل بدون کنترلِ ورودی خطرناک است",
        "subprocess.call": "اگر shell=True باشد، خطرِ Command Injection دارد",
        "subprocess.Popen": "اگر shell=True باشد، خطرِ Command Injection دارد",
        "pickle.loads": "Unpickling از منبعِ نامعتبر می‌تواند کدِ دلخواه اجرا کند",
        "pickle.load": "Unpickling از منبعِ نامعتبر می‌تواند کدِ دلخواه اجرا کند",
        "yaml.load": "بدونِ Loader=yaml.SafeLoader می‌تواند کدِ دلخواه اجرا کند",
        "__import__": "وارد‌کردنِ دینامیکِ ماژول از ورودیِ کاربر خطرناک است",
    }

    _CODE_FENCE_RE = re.compile(r"```(?:python|py)?\s*\n?(.*?)```", re.DOTALL | re.IGNORECASE)
    _COMMAND_PREFIX_RE = re.compile(
        r"^.*?(کد|برنامه)\s*(زیر|این)?\s*(رو|را)?\s*(تحلیل|بررسی|اصلاح|دیباگ)\s*کن\s*[:：]?\s*",
        re.DOTALL,
    )

    @classmethod
    def _extract_code(cls, raw_text: str) -> str:
        """
        متنِ خامِ ورودی (که ممکن است شاملِ یک جمله‌ی فارسیِ محاوره‌ای قبل
        از کد باشد، مثلِ «این کد رو تحلیل کن: ...») را به کدِ خالص تبدیل
        می‌کند:
        ۱) اگر داخل بلاکِ ```...``` باشد، فقط همان بخش را برمی‌دارد.
        ۲) وگرنه، پیشوندهای فرمانیِ رایج فارسی را حذف می‌کند.
        این گام مهم است چون بدونش، هر پیشِ‌درآمدِ فارسی باعثِ خطای
        سینتکسِ کاذب می‌شد (مثل «این کد رو تحلیل کن:» که خودش پایتونِ
        معتبر نیست).
        """
        fence_match = cls._CODE_FENCE_RE.search(raw_text)
        if fence_match:
            return fence_match.group(1).strip("\n")
        stripped = cls._COMMAND_PREFIX_RE.sub("", raw_text, count=1)
        return stripped.strip()

    @staticmethod
    def _dotted_call_name(node: ast.AST) -> str:
        """نامِ کاملِ یک فراخوانی مثلِ os.system(...) را به‌صورت 'os.system' برمی‌گرداند."""
        parts = []
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, ast.Name):
            parts.append(node.id)
        return ".".join(reversed(parts))

    @classmethod
    def _cyclomatic_complexity(cls, fn_node) -> int:
        """
        تقریبِ پیچیدگیِ سیکلوماتیک: از ۱ شروع می‌شود و برای هر نقطه‌ی
        تصمیم‌گیری (if/for/while/except/and/or/comprehension) یکی
        اضافه می‌شود. عددِ بالا یعنی تابع مسیرهای زیادی دارد و تست/فهمش
        سخت‌تر است.
        """
        complexity = 1
        for node in ast.walk(fn_node):
            if isinstance(node, (ast.If, ast.For, ast.While, ast.ExceptHandler,
                                  ast.With, ast.Assert)):
                complexity += 1
            elif isinstance(node, ast.BoolOp):
                complexity += len(node.values) - 1
            elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
                complexity += 1
        return complexity

    @staticmethod
    def _max_nesting_depth(fn_node) -> int:
        """عمقِ بیشینه‌ی تو‌در‌توییِ بلاک‌ها (if/for/while/try) داخلِ یک تابع."""
        nesting_nodes = (ast.If, ast.For, ast.While, ast.Try, ast.With)

        def depth(node, current=0):
            best = current
            for child in ast.iter_child_nodes(node):
                child_depth = depth(child, current + 1) if isinstance(child, nesting_nodes) else depth(child, current)
                best = max(best, child_depth)
            return best

        return depth(fn_node)

    @classmethod
    def analyze_and_fix(cls, code_snippet: str, language: str = "python") -> str:
        if not code_snippet or not code_snippet.strip():
            return "❌ هیچ کدی ارسال نشده."

        if language != "python":
            return "ℹ️ آنالیزگرِ پیشرفته فعلاً فقط از پایتون پشتیبانی می‌کند."

        code = cls._extract_code(code_snippet)
        if not code:
            return "❌ کدی برای تحلیل استخراج نشد. کد را داخل ``` ``` قرار دهید تا مطمئن باشیم."

        # ---------- گام ۱: بررسیِ سینتکس ----------
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            bad_line = code.split("\n")[e.lineno - 1] if e.lineno and e.lineno <= len(code.split("\n")) else ""
            report = "📝 **گزارش آنالیزِ کد** — امتیاز کیفیت: **۰/۱۰۰** 🔴\n\n"
            report += f"🔴 **خطای سینتکس در خط {e.lineno}:** {e.msg}\n"
            if bad_line.strip():
                report += f"   `{bad_line.strip()}`\n"
            if e.msg and "expected ':'" in e.msg and bad_line:
                report += f"\n🛠️ **پیشنهاد:** احتمالاً یک `:` در انتهای این خط جا افتاده:\n"
                report += f"   قبل: `{bad_line.rstrip()}`\n   بعد: `{bad_line.rstrip()}:`"
            return report

        # ---------- گام ۲: پیمایشِ درخت و جمع‌آوریِ آمار/مشکلات ----------
        security_issues = []
        structural_issues = []
        style_notes = []
        functions_info = []
        classes_info = []

        top_level_docstring = ast.get_docstring(tree) is not None

        for node in ast.walk(tree):
            # --- فراخوانی‌های خطرناک ---
            if isinstance(node, ast.Call):
                name = cls._dotted_call_name(node.func)
                if name in cls._DANGEROUS_CALLS:
                    security_issues.append(
                        f"🔴 خط {node.lineno}: استفاده از `{name}(...)` — {cls._DANGEROUS_CALLS[name]}"
                    )

            # --- except بدون نوع (bare except) ---
            if isinstance(node, ast.ExceptHandler) and node.type is None:
                structural_issues.append(f"🟠 خط {node.lineno}: `except:` بدون مشخص‌کردنِ نوعِ خطا (خطاهای غیرمنتظره را هم می‌بلعد)")

            # --- آرگومانِ پیش‌فرضِ قابلِ‌تغییر (mutable default) ---
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for default in node.args.defaults + node.args.kw_defaults:
                    if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                        structural_issues.append(
                            f"🟠 خط {node.lineno}: تابع `{node.name}` آرگومانِ پیش‌فرضِ قابل‌تغییر دارد "
                            f"(list/dict/set) — بینِ فراخوانی‌های مختلف به‌اشتراک گذاشته می‌شود"
                        )

                arg_count = len(node.args.args)
                if arg_count > 6:
                    style_notes.append(f"💡 خط {node.lineno}: تابع `{node.name}` با {arg_count} آرگومان — شاید بهتر باشد در یک دیتاکلاس/دیکشنری جمع شوند")

                complexity = cls._cyclomatic_complexity(node)
                nesting = cls._max_nesting_depth(node)
                fn_lines = (node.end_lineno - node.lineno + 1) if hasattr(node, "end_lineno") and node.end_lineno else None
                has_doc = ast.get_docstring(node) is not None
                is_public = not node.name.startswith("_")

                functions_info.append({
                    "name": node.name, "line": node.lineno, "complexity": complexity,
                    "nesting": nesting, "length": fn_lines, "has_doc": has_doc, "public": is_public,
                })

                if complexity >= 10:
                    structural_issues.append(f"🟠 خط {node.lineno}: تابع `{node.name}` پیچیدگیِ سیکلوماتیکِ {complexity} دارد — تقسیم‌کردنش به چند تابعِ کوچک‌تر توصیه می‌شود")
                if nesting >= 4:
                    structural_issues.append(f"🟠 خط {node.lineno}: تابع `{node.name}` تا عمقِ {nesting} تو‌در‌تو شده — خوانایی را کم می‌کند")
                if fn_lines and fn_lines > 50:
                    style_notes.append(f"💡 خط {node.lineno}: تابع `{node.name}` حدود {fn_lines} خط است — تابع‌های کوتاه‌تر تست/نگهداری‌شان راحت‌تر است")
                if is_public and not has_doc:
                    style_notes.append(f"💡 خط {node.lineno}: تابعِ عمومیِ `{node.name}` بدونِ docstring")
                if not node.name.islower() and not node.name.startswith("_"):
                    style_notes.append(f"💡 PEP8: نامِ تابع `{node.name}` در خط {node.lineno} → پیشنهاد: snake_case")

            # --- کلاس‌ها ---
            if isinstance(node, ast.ClassDef):
                method_count = sum(1 for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
                has_doc = ast.get_docstring(node) is not None
                classes_info.append({"name": node.name, "line": node.lineno, "methods": method_count, "has_doc": has_doc})
                if not node.name[0].isupper():
                    style_notes.append(f"💡 PEP8: نامِ کلاس `{node.name}` در خط {node.lineno} → پیشنهاد: CamelCase")
                if not has_doc:
                    style_notes.append(f"💡 خط {node.lineno}: کلاسِ `{node.name}` بدونِ docstring")

            # --- global داخل تابع (اثرِ جانبیِ پنهان) ---
            if isinstance(node, ast.Global):
                structural_issues.append(f"🟠 خط {node.lineno}: استفاده از `global` — تغییرِ حالت از بیرونِ محدوده‌ی تابع، ردیابیِ باگ را سخت‌تر می‌کند")

        # --- کامنت‌های TODO/FIXME (این‌ها در ast نیستند، از متنِ خام می‌خوانیم) ---
        for idx, line in enumerate(code.split("\n"), 1):
            if re.search(r"#\s*(TODO|FIXME|XXX)", line, re.IGNORECASE):
                style_notes.append(f"📌 خط {idx}: یادداشتِ باقی‌مانده ({line.strip()})")

        # ---------- گام ۳: امتیازدهیِ کیفیت (۰ تا ۱۰۰) ----------
        score = 100
        score -= 25 * len(security_issues)
        score -= 8 * len(structural_issues)
        score -= 2 * len(style_notes)
        score = max(0, min(100, score))

        if score >= 90:
            verdict = "🟢 عالی"
        elif score >= 70:
            verdict = "🟡 قابلِ قبول، جای بهبود دارد"
        elif score >= 40:
            verdict = "🟠 نیاز به بازبینی"
        else:
            verdict = "🔴 نیازمندِ اصلاحِ جدی"

        # ---------- گام ۴: ساختِ گزارش ----------
        report = f"📝 **گزارش آنالیزِ کد** — امتیاز کیفیت: **{score}/۱۰۰** ({verdict})\n"

        if security_issues:
            report += "\n🛡️ **مشکلاتِ امنیتی:**\n" + "\n".join(f"  {x}" for x in security_issues)
        if structural_issues:
            report += "\n\n⚙️ **مشکلاتِ ساختاری:**\n" + "\n".join(f"  {x}" for x in structural_issues)
        if style_notes:
            report += "\n\n💡 **پیشنهادها:**\n" + "\n".join(f"  {x}" for x in style_notes[:12])
            if len(style_notes) > 12:
                report += f"\n  … و {len(style_notes) - 12} پیشنهادِ دیگر"
        if not security_issues and not structural_issues and not style_notes:
            report += "\n✅ هیچ مشکلِ قابل‌توجهی پیدا نشد."

        if functions_info or classes_info:
            report += "\n\n📊 **آمار:**\n"
            report += f"  • توابع: {len(functions_info)}"
            if functions_info:
                avg_complexity = sum(f["complexity"] for f in functions_info) / len(functions_info)
                report += f" (میانگین پیچیدگی: {avg_complexity:.1f})"
            report += f"\n  • کلاس‌ها: {len(classes_info)}\n"
            report += f"  • خطوطِ کد: {len(code.splitlines())}"
            if not top_level_docstring:
                report += "\n  • 💡 فایل/بلاک docstring در سطحِ ماژول ندارد"

        return report

    @staticmethod
    def analyze_project(directory: str) -> str:
        """
        تحلیلِ کلِ پروژه (بر پایه‌ی ast، نه regex): برای هر فایلِ .py،
        تعدادِ توابع/کلاس‌ها را با ast می‌شمارد و «داغ‌ترین» فایل‌ها
        (پیچیده‌ترین/بزرگ‌ترین) را مشخص می‌کند.
        """
        if not os.path.exists(directory):
            return "❌ دایرکتوری وجود ندارد"

        total_lines = 0
        total_functions = 0
        total_classes = 0
        total_complexity = 0
        file_stats = []
        syntax_error_files = []

        for root, _dirs, filenames in os.walk(directory):
            for filename in filenames:
                if not filename.endswith(".py"):
                    continue
                filepath = os.path.join(root, filename)
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        content = f.read()
                except OSError as e:
                    logger.debug("خواندنِ فایل ناموفق بود: %s (%s)", filepath, e)
                    continue

                lines = len(content.split("\n"))
                total_lines += lines

                try:
                    tree = ast.parse(content)
                except SyntaxError:
                    syntax_error_files.append(filename)
                    file_stats.append({"name": filename, "lines": lines, "functions": 0, "classes": 0, "complexity": 0})
                    continue

                functions = sum(1 for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
                classes = sum(1 for n in ast.walk(tree) if isinstance(n, ast.ClassDef))
                complexity = sum(
                    CodeIntelligence._cyclomatic_complexity(n)
                    for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                )
                total_functions += functions
                total_classes += classes
                total_complexity += complexity
                file_stats.append({
                    "name": filename, "lines": lines, "functions": functions,
                    "classes": classes, "complexity": complexity,
                })

        if not file_stats:
            return "📊 هیچ فایلِ .py در این دایرکتوری پیدا نشد."

        report = "📊 **گزارش تحلیل پروژه**\n\n"
        report += f"📁 تعداد فایل‌ها: {len(file_stats)}\n"
        report += f"📝 تعداد کل خطوط: {total_lines}\n"
        report += f"📌 تعداد توابع: {total_functions}\n"
        report += f"📌 تعداد کلاس‌ها: {total_classes}\n"
        if total_functions:
            report += f"🧮 میانگین پیچیدگیِ هر تابع: {total_complexity / total_functions:.1f}\n"
        if syntax_error_files:
            report += f"🔴 فایل‌های دارایِ خطای سینتکس: {', '.join(syntax_error_files)}\n"

        hottest = sorted(file_stats, key=lambda s: s.get("complexity", 0), reverse=True)[:5]
        if hottest and hottest[0].get("complexity", 0) > 0:
            report += "\n🔥 **داغ‌ترین فایل‌ها (بیشترین پیچیدگی):**\n"
            for s in hottest:
                if s.get("complexity", 0) <= 0:
                    continue
                report += f"  • {s['name']}: پیچیدگیِ {s['complexity']} | {s['lines']} خط | {s['functions']} تابع | {s['classes']} کلاس\n"

        report += "\n📄 **جزئیاتِ همه‌ی فایل‌ها:**\n"
        for stat in sorted(file_stats, key=lambda x: x["name"]):
            report += f"  • {stat['name']}: {stat['lines']} خط | {stat['functions']} تابع | {stat['classes']} کلاس\n"

        return report
