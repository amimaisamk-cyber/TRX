from ..redflags import (
    SELF_HARM_REDFLAGS, EMERGENCY_REDFLAGS,
    check_self_harm_redflags, check_emergency_redflags, check_any_redflags,
)

def detect(text):
    return check_any_redflags(text)

def detect_structured(text):
    return {
        "self_harm": check_self_harm_redflags(text),
        "emergency": check_emergency_redflags(text),
    }
