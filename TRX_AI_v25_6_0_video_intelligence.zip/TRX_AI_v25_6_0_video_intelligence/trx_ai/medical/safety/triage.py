# -*- coding: utf-8 -*-
"""
طبقه‌بندیِ فوریت (triage) بر پایه‌ی شواهدِ ساختاریافته -- **نه** یک تشخیصِ
جدید. این ماژول از داده‌هایی که موتورِ تشخیص از قبل استخراج کرده
(شدت/شروع/مدت از diagnosis.extractor، شدتِ بیماریِ کاندید و علائمِ
هشدار از disease_db) استفاده می‌کند تا بگوید «چقدر زود باید به پزشک
مراجعه کرد» -- که سؤالی جدا از «چه بیماری‌ای محتمل است» است.

فوریتِ واقعی (EMERGENCY) همیشه پیش از این ماژول، توسطِ
`safety.redflags` (که مبتنی بر عبارات صریحِ خطرناک است) بررسی می‌شود؛
این‌جا فقط سطوحِ میان‌ردهِ «امروز / طیِ چند روز / مراقبتِ خانگی»
مشخص می‌شود.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional


class UrgencyLevel(str, Enum):
    URGENT_TODAY = "URGENT_TODAY"        # مراجعه همین امروز/طی چند ساعت آینده
    SOON_FEW_DAYS = "SOON_FEW_DAYS"      # مراجعه طی ۱ تا ۳ روز آینده
    SELF_CARE = "SELF_CARE"              # مراقبتِ خانگی در حال حاضر کافی است
    UNKNOWN = "UNKNOWN"                  # شواهدِ کافی برای اظهار نظر وجود ندارد


_URGENCY_TEXT = {
    UrgencyLevel.URGENT_TODAY: "🕐 توصیه می‌شود همین امروز (ترجیحاً طی چند ساعت آینده) به پزشک مراجعه کنید.",
    UrgencyLevel.SOON_FEW_DAYS: "📅 توصیه می‌شود طی ۱ تا ۳ روز آینده، در صورت عدم بهبود، به پزشک مراجعه کنید.",
    UrgencyLevel.SELF_CARE: "🏠 در حال حاضر مراقبتِ خانگی معمولاً کافی است؛ در صورت تشدیدِ علائم یا عدمِ بهبود طیِ چند روز، به پزشک مراجعه کنید.",
    UrgencyLevel.UNKNOWN: "❔ شواهدِ کافی برای اظهار نظر درباره‌ی فوریتِ مراجعه وجود ندارد؛ در صورتِ نگرانی، با پزشک مشورت کنید.",
}


def urgency_message(level: str) -> str:
    try:
        return _URGENCY_TEXT[UrgencyLevel(level)]
    except ValueError:
        return _URGENCY_TEXT[UrgencyLevel.UNKNOWN]


def assess_urgency(
    ranked: List[Dict[str, Any]],
    extraction: Dict[str, Any],
    disease_db: Dict[str, Any],
) -> Dict[str, Any]:
    """
    سطحِ فوریتِ مراجعه را بر اساس سه نوع شواهدِ مستقل تعیین می‌کند:

    1. شدت/شروعِ گزارش‌شده توسطِ خودِ کاربر (extraction["severity"|"onset"])
       -- از diagnosis.extractor می‌آید، بدون نیاز به تحلیلِ اضافه.
    2. هم‌پوشانیِ علائمِ گزارش‌شده با «علائمِ هشدارِ» بیماریِ کاندیدِ اول
       در disease_db (warning_signs) -- یعنی همان علامتی که کاربر گفته،
       در پایگاه‌داده هم به‌عنوانِ نشانه‌ی نیازِ به مراجعه‌ی فوری علامت خورده.
    3. شدتِ ذاتیِ بیماریِ کاندیدِ اول (disease_db[...]["severity"]).

    خروجی صرفاً یک برچسبِ فوریت + دلیل است، نه تشخیص یا توصیه‌ی درمانی.
    """
    severity = (extraction or {}).get("severity")
    onset = (extraction or {}).get("onset")

    warning_hit = False
    disease_severity_flag = False
    top_disease = None
    if ranked:
        top = ranked[0]
        top_disease = top.get("disease")
        info = disease_db.get(top_disease, {}) or {}
        warning_signs = {str(w).lower() for w in info.get("warning_signs", [])}
        matched = {str(m).lower() for m in top.get("matched_symptoms", [])}
        warning_hit = bool(warning_signs & matched)
        disease_severity_flag = str(info.get("severity", "")).strip() in {
            "بالا", "شدید", "زیاد", "high", "severe",
        }

    rationale: List[str] = []
    if severity:
        rationale.append(f"شدتِ گزارش‌شده توسطِ کاربر: {severity}")
    if onset:
        rationale.append(f"نوعِ شروعِ علائم: {'ناگهانی' if onset == 'sudden' else 'تدریجی'}")
    if warning_hit:
        rationale.append(f"علامتِ گزارش‌شده با یکی از علائمِ هشدارِ «{top_disease}» هم‌پوشانی دارد")
    if disease_severity_flag:
        rationale.append(f"شدتِ ذاتیِ بیماریِ کاندید («{top_disease}») بالا ثبت شده است")

    if severity == "severe" or onset == "sudden" or warning_hit or disease_severity_flag:
        level = UrgencyLevel.URGENT_TODAY
    elif severity == "moderate":
        level = UrgencyLevel.SOON_FEW_DAYS
    elif not ranked:
        level = UrgencyLevel.UNKNOWN
    else:
        level = UrgencyLevel.SELF_CARE

    return {
        "level": level.value,
        "message": urgency_message(level.value),
        "rationale": rationale,
    }
