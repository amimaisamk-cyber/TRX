import re
from ..models.symptom import SymptomState

_NEGATIONS = ("ندارم", "ندارد", "نداشتم", "نداشته", "نیست", "نیستم", "بدون", "نه", "نمی", "نمیدارم", "نمی‌", "فاقد")

# باگِ قبلی: چک با `in` ساده (زیررشته‌ی خام) بود، پس «نه» (به‌معنیِ نه/نفی)
# داخلِ *هر* کلمه‌ای که تصادفاً به «...نه» ختم می‌شود هم می‌ماچید --
# مثلِ «می‌کنه»، «خونه» -- که در فارسیِ محاوره‌ای فوق‌العاده رایج‌اند.
# نتیجه: جملاتِ کاملاً مثبتِ خیلی معمولی («خونه‌ام سردرد دارم»، «درد
# می‌کنه») به‌اشتباه ABSENT/منفی تشخیص داده می‌شدند -- یکی از دلایلِ
# واقعیِ حسِ «نمی‌فهمه». راه‌حل: مرزِ کلمه (\b) برایِ هر عبارتِ نفی،
# به‌جایِ زیررشته‌ی بی‌مرز.
_NEGATION_PATTERNS = [re.compile(r"\b" + re.escape(n) + r"\b") for n in _NEGATIONS]


def is_negated(text: str, term: str, window: int = 45) -> bool:
    t, needle = text.lower(), term.lower()
    for m in re.finditer(re.escape(needle), t):
        left = t[max(0, m.start()-window):m.start()]
        right = t[m.end():m.end()+16]
        if any(p.search(left) for p in _NEGATION_PATTERNS) or any(p.search(right) for p in _NEGATION_PATTERNS):
            return True
    return False

def symptom_state(text: str, term: str) -> SymptomState:
    if not text or not term or term.lower() not in text.lower():
        return SymptomState.UNKNOWN
    return SymptomState.ABSENT if is_negated(text, term) else SymptomState.PRESENT
