DISCLAIMER = "این اطلاعات برای پشتیبانی تصمیم‌گیری عمومی است و جایگزین تشخیص یا درمان پزشک نیست."

def safe_policy(emergency=False, evidence_sufficient=False):
    return {
        "emergency": bool(emergency),
        "allow_diagnostic_claim": bool(evidence_sufficient) and not emergency,
        "require_disclaimer": True,
    }
