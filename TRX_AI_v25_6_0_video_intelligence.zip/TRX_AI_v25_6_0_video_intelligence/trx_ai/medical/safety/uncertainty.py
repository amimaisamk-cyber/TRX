def evidence_level(score: float, candidate_count: int = 0) -> str:
    if score >= 0.80 and candidate_count <= 2:
        return "HIGH EVIDENCE"
    if score >= 0.55:
        return "MODERATE EVIDENCE"
    if score > 0:
        return "LOW EVIDENCE"
    return "INSUFFICIENT EVIDENCE"

def uncertainty_label(top_score: float, gap: float, minimum: float = .80, minimum_gap: float = .20) -> str:
    if top_score <= 0:
        return "INSUFFICIENT EVIDENCE"
    if top_score >= minimum and gap >= minimum_gap:
        return "HIGH EVIDENCE"
    if top_score >= .55:
        return "MODERATE EVIDENCE"
    return "LOW EVIDENCE"
