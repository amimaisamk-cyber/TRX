from dataclasses import dataclass

@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    code: str = "OK"
    message: str = ""
    sanitized: str = ""

def validate_text(text, max_chars=12000):
    if text is None or not isinstance(text, str):
        return False, "INVALID_INPUT"
    text = " ".join(text.strip().split())
    if not text:
        return False, "EMPTY_INPUT"
    if len(text) > max_chars:
        return False, "INPUT_TOO_LONG"
    return True, None

def validate_request(text, max_chars=12000):
    ok, code = validate_text(text, max_chars)
    return ValidationResult(ok, code or "OK", "", " ".join(text.strip().split()) if isinstance(text, str) else "")
