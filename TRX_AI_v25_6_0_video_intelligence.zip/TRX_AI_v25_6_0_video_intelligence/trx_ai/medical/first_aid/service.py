class FirstAidService:
    def __init__(self, guides): self.guides=guides
    def advice(self, text):
        t=text.lower().strip()
        for key,val in self.guides.items():
            if key in t or t in key: return val
        return "🆘 در وضعیت فوری با خدمات اورژانسی تماس بگیرید، فرد را در وضعیت امن نگه دارید و از دادن دارو/غذا بدون راهنمایی حرفه‌ای خودداری کنید."
