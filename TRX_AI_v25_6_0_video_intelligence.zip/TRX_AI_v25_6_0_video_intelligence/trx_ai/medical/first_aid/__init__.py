from .service import FirstAidService
