from dataclasses import dataclass, field
from typing import Dict

@dataclass(frozen=True)
class MedicalConfig:
    medical_version: str = "2.1"
    schema_version: str = "1.1"
    max_followup_questions: int = 7
    confidence_gap: float = 0.20
    confidence_min: float = 0.80
    online_timeout_seconds: float = 8.0
    cache_ttl_seconds: int = 3600
    max_candidates: int = 5
    max_input_chars: int = 12000
    ranking_weights: Dict[str, float] = field(default_factory=lambda: {
        "positive": 0.55,
        "specificity": 0.20,
        "context": 0.10,
        "duration": 0.05,
        "severity": 0.05,
        "contradiction": 0.20,
        "missing_critical": 0.10,
    })
    enable_online: bool = True
    # اتصال به RxNorm/openFDA برای اطلاعاتِ رسمیِ دارو + بررسیِ آنلاینِ
    # تداخلِ دارویی (پایگاه‌داده‌ی محلی فقط چند ده دارو/تداخل دارد).
    enable_drug_apis: bool = True
    enable_rag: bool = False
    enable_adaptive_dialogue: bool = True
    enable_medication: bool = True
    enable_first_aid: bool = True
    enable_advanced_ranking: bool = True
    strict_safety: bool = True
