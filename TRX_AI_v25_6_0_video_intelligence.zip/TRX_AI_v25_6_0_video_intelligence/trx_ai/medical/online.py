# -*- coding: utf-8 -*-
"""
نسخه‌ی متصل‌به‌اینترنتِ پردازشِ درخواستِ پزشکی: وقتی پایگاه‌داده‌ی محلیِ
`care.py` (چند بیماری/دارو) پاسخِ کافی ندارد، از MedlinePlus، ویکی‌پدیای
فارسی و در نهایت جستجوی عمومیِ وب برای تکمیلِ اطلاعات کمک می‌گیرد.

توابعِ این ماژول `engine` (نمونه‌ی `MedicalAIEngine` از care.py) را به‌عنوان
اولین آرگومان می‌گیرند تا به قابلیت‌های محلی (کمک‌های اولیه، گفتگوی
تشخیصی، اطلاعات دارو/بیماری) دسترسی داشته باشند -- بدون اینکه منطق را
دوباره اینجا بنویسیم.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional

from ..tools import MedicalWebSearchEngine, WebSearchEngine
from ..logging_config import get_logger
from . import formatting
from .redflags import check_any_redflags
from .router import EMOTIONAL_SUPPORT_KEYWORDS
from .knowledge.drug_sources import gather_drug_evidence
from .knowledge.interaction_online import check_many_online
from .entities import extract_drug_name, extract_disease_name

logger = get_logger(__name__)


async def fetch_drug_online_info(drug_name: str, session) -> Optional[str]:
    """
    اطلاعاتِ رسمیِ دارو از RxNorm/openFDA؛ برایِ داروهایی که در
    پایگاه‌داده‌ی محلیِ محدود (`data/medications.py`، فقط چند ده دارو)
    نیستند -- که اکثریتِ داروهایِ موجود در بازار همین‌طورند.

    اگر هیچ‌کدام از این دو جواب ندهند (دارویِ خیلی کمیاب/ناشناخته یا
    قطعیِ اینترنت)، به‌جایِ خالی برگرداندن، به `fetch_online_medical_info`
    (MedlinePlus → ویکی‌پدیا → جستجویِ عمومی) سقوط می‌کند تا حداقل یک
    توضیحِ دانشنامه‌ای عمومی به کاربر داده شود.
    """
    if session is None:
        return None
    try:
        evidence_list = await gather_drug_evidence(session, drug_name)
    except Exception as e:  # noqa: BLE001
        logger.warning("gather_drug_evidence failed: %s", e)
        evidence_list = []

    if evidence_list:
        parts = [f"🏥 **از {e.source}:**\n\n{e.content}" for e in evidence_list]
        return "\n\n---\n\n".join(parts)

    return await fetch_online_medical_info(f"داروی {drug_name}", session)


async def fetch_online_medical_info(query: str, session) -> Optional[str]:
    """
    جستجوی اطلاعات سلامت عمومی (نه دوز دقیق دارو) از منابع آنلاین؛
    فقط برای تکمیل دانشِ محدودِ پایگاه‌داده‌ی محلی، نه به‌عنوان جایگزین
    تشخیص پزشک.

    ترتیب اولویت منابع (هرکدام شکست خورد، بعدی امتحان می‌شود):
      ۱. MedlinePlus — پایگاه‌داده‌ی رسمی پزشکیِ کتابخانه‌ی ملی پزشکی
         آمریکا (NLM/NIH)؛ منبعی معتبر و تخصصاً پزشکی.
      ۲. ویکی‌پدیای فارسی — برای اطلاعات دانشنامه‌ایِ عمومی‌تر.
      ۳. جستجوی عمومی وب (DuckDuckGo) — آخرین راه‌حل.
    """
    if session is None:
        return None
    clean_query = re.sub(r'(چیست|کیست|؟)', '', query).strip()
    if not clean_query:
        return None
    try:
        medline = await MedicalWebSearchEngine.get_medical_summary_fa(session, clean_query)
        if medline:
            return f"🏥 **از MedlinePlus (منبع رسمی پزشکی):**\n\n{medline}"
    except Exception as e:
        logger.warning("MedlinePlus lookup failed, falling back: %s", e)

    try:
        wiki = await WebSearchEngine.get_wikipedia(session, clean_query)
        if wiki and not wiki.startswith(("📡", "🌐")):
            return f"📚 **از ویکی‌پدیای فارسی:**\n\n{wiki}"
        web = await WebSearchEngine.search_duckduckgo(session, clean_query)
        if web:
            return web
    except Exception as e:
        logger.warning("Fallback medical web lookup failed: %s", e)
        return None
    return None


async def handle_medical_query_online(engine, text: str, session, session_key: str = "default") -> Dict:
    """
    نسخه‌ی متصل به اینترنت `engine.handle_medical_query`.

    پایگاه‌داده‌ی محلی این موتور فقط چند بیماری و چند دارو را می‌شناسد؛
    برای هر علامت/دارو/بیماری‌ای که در آن نیست، این متد به‌جای «یافت
    نشد»، از ویکی‌پدیای فارسی و جستجوی وب برای دادن یک خلاصه‌ی اطلاعاتیِ
    عمومی کمک می‌گیرد. تشخیص محلیِ باکیفیت هرگز نادیده گرفته نمی‌شود؛
    وب فقط زمانی صدا زده می‌شود که دانش محلی ناکافی یا کم‌اطمینان باشد.

    خروجی یک دیکشنری {"done": bool, "message": str, ...} است: اگر
    «done» نادرست باشد، یعنی این یک سؤال پیگیریِ بله/خیر است و پاسخ
    بعدیِ کاربر باید به `engine.answer_symptom_check` فرستاده شود (این
    کار را core.py با کمک `has_active_dialogue` انجام می‌دهد).
    """
    # ۰. بررسی فوریتی («قرمز») — همیشه اول، حتی پیش از هر تلاش شبکه‌ای
    emergency = check_any_redflags(text)
    if emergency:
        return {"done": True, "emergency": True, "message": emergency}

    # ۰.۵ ادامه‌ی جلسه‌ی فعالِ همراهِ روان‌شناختی -- تا یک گفتگویِ «درد دل»
    # که کلیدواژه‌ی احساسیِ صریح ندارد (مثلاً پیامِ دوم به بعد) هم به همین
    # موتور برسد، نه به شاخه‌های دیگرِ زیر (که برایِ آن مناسب نیستند).
    if engine.therapy.has_active_session(session_key) and not engine.therapy.looks_like_unrelated_command(text):
        result = engine.therapy.respond(session_key, text)
        return {"done": True, "message": result["message"], "emergency": result.get("emergency", False), "source": "therapy"}

    text_lower = text.lower().strip()

    # ۱. کمک‌های اولیه (همیشه محلی و فوری - نیازی به وب نیست)
    first_aid_keywords = ["کمک اولیه", "اورژانس", "تصادف", "خونریزی", "سوختگی", "شکستگی",
                          "غرق", "مسمومیت", "سکته", "تشنج", "فوریت", "بحران"]
    if any(kw in text_lower for kw in first_aid_keywords):
        return {"done": True, "message": engine.first_aid_advice(text)}

    # ۲. تحلیل علائم — تعاملی: در صورت ابهام، سؤال پیگیری بله/خیر می‌پرسد
    symptom_keywords = ["علائم", "درد", "تب", "سرفه", "گلودرد", "تنگی نفس", "سردرد",
                        "تهوع", "سرگیجه", "خستگی", "اسهال", "یبوست", "تپش قلب"]
    if any(kw in text_lower for kw in symptom_keywords) or "بیمار" in text_lower:
        dialogue_result = engine.start_symptom_check(session_key, text)
        if not dialogue_result["done"]:
            return dialogue_result
        local_msg = dialogue_result["message"]
        if dialogue_result.get("emergency"):
            return dialogue_result
        # قبلاً اینجا فقط با جستجویِ رشته‌ای در متنِ پیام («یافت نشد» و...)
        # تشخیص می‌داد که آیا سراغِ اینترنت هم برویم -- یعنی اگر پایگاه‌داده‌ی
        # محلیِ کوچک (۳۰-۴۰ بیماری) *هر* جوابی می‌داد (even یک تطبیقِ ضعیف
        # با شواهدِ کم)، اینترنت اصلاً صدا زده نمی‌شد. حالا معیار «sufficient»
        # (همان آستانه‌ی امتیاز/فاصله‌ی decisive که در dialogue/manager.py هم
        # استفاده می‌شود) است: تا وقتی نتیجه‌ی محلی واقعاً قطعی نباشد، منابعِ
        # آنلاین هم -- علاوه بر محلی، نه به‌جایش -- بررسی می‌شوند.
        sufficient = dialogue_result.get("sufficient", True)
        if not sufficient:
            questionnaire = ""
            if formatting.confidence_questions_needed(text):
                questionnaire = f"\n\n{formatting.adaptive_questionnaire(text)}"
            online_info = await fetch_online_medical_info(text, session)
            if online_info:
                local_label = (
                    "🏠 **نزدیک‌ترین تطبیقِ پایگاه‌دانشِ محلی (شواهد محدود):**\n\n" + local_msg
                    if dialogue_result.get("status") == "diagnosis"
                    else local_msg
                )
                return {
                    "done": True,
                    "message": (
                        f"{local_label}\n\n"
                        f"🌐 **اطلاعاتِ تکمیلی از منابعِ آنلاین (دانشنامه‌ی خیلی بزرگ‌تر):**\n\n{online_info}"
                        f"{questionnaire}\n\n"
                        f"⚠️ این بخش خلاصه‌ی نتایجِ جستجویِ وب است، نه تشخیصِ قطعی؛ "
                        f"برای تشخیصِ دقیق حتماً به پزشک مراجعه کنید."
                    ),
                }
            if questionnaire:
                return {"done": True, "message": f"{local_msg}{questionnaire}"}
        return {"done": True, "message": local_msg}

    # ۳. تداخلِ دارویی — باید پیش از «اطلاعاتِ دارو»یِ عمومی بررسی شود
    #    چون کلیدواژه‌ی «تداخل» با کلیدواژه‌های دارو هم‌پوشانی دارد و
    #    ساختارِ جمله («X و Y») با regexِ «اطلاعاتِ دارو» تطبیق نمی‌خورد.
    if "تداخل" in text_lower:
        cleaned = re.sub(r'^.*?تداخل(?:\s*دارویی)?\s*', '', text, flags=re.I).strip()
        names = [n.strip() for n in re.split(r'\s*(?:,|،|\sو\s|\sبا\s)\s*', cleaned) if n.strip()]
        if len(names) < 2:
            return {
                "done": True,
                "message": (
                    "💊 برایِ بررسیِ تداخلِ دارویی، نامِ حداقل دو دارو را مشخص کنید.\n"
                    "مثال: «تداخل دارویی وارفارین و ایبوپروفن»"
                ),
            }
        local_results = engine.check_drug_interactions(names)
        online_note = ""
        if engine.config.enable_drug_apis:
            try:
                online_result = await check_many_online(session, names)
                if online_result["checked_online"] and online_result["results"]:
                    # ادغام: نتایجِ آنلاین اضافه می‌شوند؛ اگر برایِ همان
                    # زوجِ دارو، محلی «UNKNOWN» بوده، نتیجه‌ی آنلاین
                    # جایگزینش می‌شود (چون آنلاین اطلاعاتِ دقیق‌تری دارد)،
                    # وگرنه هر دو نگه داشته می‌شوند تا کاربر ببیند.
                    online_pairs = {frozenset({r["drug_a"].lower(), r["drug_b"].lower()}) for r in online_result["results"]}
                    local_results = [
                        r for r in local_results
                        if not (r["severity"] == "UNKNOWN" and frozenset({r["drug_a"].lower(), r["drug_b"].lower()}) in online_pairs)
                    ]
                    local_results = online_result["results"] + local_results
                online_note = online_result["note"]
            except Exception as e:  # noqa: BLE001
                logger.warning("Online interaction check failed: %s", e)
                online_note = "⚠️ بررسیِ آنلاینِ تداخل ممکن نشد؛ فقط نتیجه‌یِ محلی نمایش داده شد."
        from .response import interaction_report
        return {"done": True, "message": interaction_report(names, local_results, online_note=online_note)}

    # ۴. اطلاعات دارو
    drug_keywords = ["دارو", "قرص", "شربت", "آمپول", "دوز", "مصرف"]
    if any(kw in text_lower for kw in drug_keywords):
        # قبلاً اینجا یک regex جداگانه بود که «آمپول» را نمی‌شناخت و
        # کاراکترهایِ مجازِ نامِ دارو با نسخه‌ی care.py فرق داشت -- یعنی
        # همان جمله بسته به مسیرِ ورودی (این‌جا در برابرِ handle_request)
        # می‌توانست نامِ دارویِ متفاوتی استخراج کند. حالا هر دو از همان
        # extract_drug_name واحد در entities.py استفاده می‌کنند.
        drug_name = extract_drug_name(text)
        if drug_name:
            result = engine.get_medication_info(drug_name)
            if result["status"] in ("found", "found_similar"):
                info = result["info"]
                drug = result["drug"]
                response = f"💊 **اطلاعات داروی '{drug}':**\n\n"
                response += f"**کاربرد:** {info['use']}\n"
                response += f"**دوز مصرف:** {info['dosage']}\n"
                response += f"**عوارض جانبی:** {', '.join(info['side_effects'])}\n"
                response += f"**توصیه:** {info['caution']}"
                return {"done": True, "message": response}
            # این دارو در پایگاه‌داده‌ی محلیِ محدود (~۸ دارو) نیست — سراغِ
            # پایگاه‌هایِ رسمیِ RxNorm/openFDA می‌رویم (خیلی بزرگ‌تر و
            # به‌روزترند)، و اگر آن‌ها هم چیزی نداشتند، دانشنامه‌ی عمومی.
            online_info = await fetch_drug_online_info(drug_name, session)
            if online_info:
                return {
                    "done": True,
                    "message": (
                        f"❌ داروی «{drug_name}» در پایگاه‌داده‌ی محلی موجود نیست.\n\n"
                        f"{online_info}\n\n"
                        f"⚠️ دوز دقیق، تداخلات و نحوه‌ی مصرف را حتماً از پزشک یا داروساز "
                        f"بپرسید؛ این خلاصه جایگزین نسخه‌ی پزشک نیست."
                    ),
                }
            return {"done": True, "message": result.get("message", f"❌ اطلاعاتی برای داروی '{drug_name}' یافت نشد.")}

        return {
            "done": True,
            "message": (
                "💊 **برای دریافت اطلاعات دارو، نام دارو را مشخص کنید.**\n\n"
                "مثال:\n- اطلاعات داروی استامینوفن\n- دوز مصرف ایبوپروفن\n"
                "- تداخل دارویی آموکسی سیلین و متفورمین"
            ),
        }

    # ۵. اطلاعات بیماری
    disease_keywords = ["بیماری", "نشانه", "درمان", "پیشگیری"]
    if any(kw in text_lower for kw in disease_keywords):
        disease_name = extract_disease_name(text)
        if disease_name:
            result = engine.get_disease_info(disease_name)
            if result["status"] in ("found", "found_similar"):
                info = result["info"]
                disease = result["disease"]
                response = f"📋 **اطلاعات بیماری '{disease}':**\n\n"
                response += f"**علائم:** {', '.join(info['symptoms'])}\n\n"
                response += "**درمان:**\n" + "\n".join(f"   • {t}" for t in info["treatment"])
                response += "\n\n**پیشگیری:**\n" + "\n".join(f"   • {p}" for p in info["prevention"])
                if info["warning_signs"]:
                    response += f"\n\n**علائم هشدار:** {', '.join(info['warning_signs'])}\n"
                response += f"\n**زمان مراجعه به پزشک:** {info['when_to_see_doctor']}"
                return {"done": True, "message": response}
            # این بیماری در پایگاه‌داده‌ی محلیِ محدود (~۷ بیماری) نیست
            online_info = await fetch_online_medical_info(f"بیماری {disease_name}", session)
            if online_info:
                return {
                    "done": True,
                    "message": (
                        f"📋 «{disease_name}» در پایگاه‌داده‌ی محلی موجود نیست.\n\n"
                        f"🌐 **اطلاعات کلی یافت‌شده از وب:**\n\n{online_info}\n\n"
                        f"⚠️ این خلاصه‌ی وب است و جایگزین معاینه و تشخیص پزشک نیست."
                    ),
                }
            return {"done": True, "message": result.get("message", f"❌ اطلاعاتی برای بیماری '{disease_name}' یافت نشد.")}

    # ۶. همراهِ روان‌شناختی — پریشانیِ هیجانی/تنهایی/استرس *بدونِ* هیچ‌کدام
    #    از کلیدواژه‌هایِ جسمیِ بالا (که همیشه اولویتِ بالاتری دارند، دقیقاً
    #    همان ترتیبی که MedicalRouter.route هم رعایت می‌کند). فقط اینجا،
    #    بعد از رد شدن از همه‌ی مسیرهایِ جسمی، بررسی می‌شود.
    if any(kw in text_lower for kw in EMOTIONAL_SUPPORT_KEYWORDS):
        result = engine.therapy.respond(session_key, text)
        return {
            "done": True,
            "message": result["message"],
            "emergency": result.get("emergency", False),
            "source": "therapy",
        }

    # ۷. مشاوره‌ی سلامت عمومی
    # v25.5.8: این نقطه فقط وقتی می‌رسد که هیچ‌کدام از شاخه‌های جسمی/دارویی
    # بالا و هیچ‌کدام از EMOTIONAL_SUPPORT_KEYWORDSِ تحت‌اللفظی مطابقت
    # نداشته باشند. "source" عمداً "therapy" نیست -- تا مصرف‌کننده (مثلاً
    # tool_router._route_emotional_support) بتواند تشخیص بدهد این پاسخ
    # هرگز واقعاً توسطِ موتورِ همراهِ روان‌شناختی ساخته نشده، حتی اگر NLUِ
    # بیرونی (که semantic هم هست، نه فقط کلیدواژه‌ای) این پیام را
    # emotional_support برچسب زده باشد. نگاه کنید به
    # audit/EMOTIONAL_SUPPORT_MISROUTE_v25_5_8.md برایِ ریشه‌ی این عدمِ
    # تطابق.
    return {"done": True, "message": engine.health_advice(text), "source": "general_advice"}
