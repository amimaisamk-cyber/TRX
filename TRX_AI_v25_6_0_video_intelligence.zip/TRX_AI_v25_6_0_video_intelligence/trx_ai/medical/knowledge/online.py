from .evidence import Evidence

class OnlineProvider:
    async def search(self,query,session):
        # Import تنبل (نه در سطحِ ماژول) تا از importِ دوری جلوگیری شود:
        # trx_ai.medical.online حالا خودش به trx_ai.medical.knowledge.*
        # وابسته است (برایِ RxNorm/openFDA)، پس این ماژول نباید در زمانِ
        # بارگذاری به آن وابسته باشد -- فقط در زمانِ فراخوانیِ واقعی.
        from .. import online as legacy_online
        text=await legacy_online.fetch_online_medical_info(query,session)
        if not text: return []
        return [Evidence(source="online medical provider",title=query,content=text,source_type="online")]
