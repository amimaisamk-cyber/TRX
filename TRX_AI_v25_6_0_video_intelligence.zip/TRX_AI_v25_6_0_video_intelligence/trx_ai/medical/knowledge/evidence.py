from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass(frozen=True)
class Evidence:
    source: str
    title: str = ""
    content: Any = None
    source_type: str = "local"
    url: str|None = None
    reliability: float|None = None
    metadata: Dict[str,Any] = field(default_factory=dict)

class EvidenceSet(list):
    def top(self,n=5): return self[:n]
