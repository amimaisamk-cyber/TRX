from .sources import source
from .evidence import Evidence

class LocalKnowledge:
    def __init__(self,disease_db,medication_db,health_topics,first_aid):
        self.diseases=disease_db; self.medications=medication_db; self.health_topics=health_topics; self.first_aid=first_aid
    def disease(self,name):
        n=name.strip().lower()
        for k,v in self.diseases.items():
            if n==k.lower() or n in k.lower() or k.lower() in n: return k,v
        return None,None
    def evidence_for_disease(self,name):
        k,v=self.disease(name)
        return [] if not k else [Evidence(source="TRX AI local medical data",title=k,content=v,source_type="local",reliability=.75)]
