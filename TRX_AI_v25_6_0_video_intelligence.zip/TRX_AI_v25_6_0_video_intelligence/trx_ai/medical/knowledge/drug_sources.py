# -*- coding: utf-8 -*-
"""
اتصال به پایگاه‌های‌دادهٔ رسمیِ آنلاینِ دارو -- برایِ زمانی که دارو در
`data/medications.py` (پایگاه‌داده‌ی محلیِ محدود، فقط چند ده دارو) پیدا
نشود. جا دادنِ همه‌ی داروهایِ دنیا در کد ممکن نیست؛ به‌جایش این ماژول
مستقیماً از دو منبعِ رسمی و بدونِ نیاز به کلیدِ API می‌پرسد:

    • RxNorm / RxNav -- کتابخانه‌ی ملیِ پزشکیِ آمریکا (NLM):
      نرمال‌سازیِ نامِ دارو (تشخیصِ نامِ ژنریک/تجاری) + شناسه‌ی استانداردِ
      RxCUI که برایِ بررسیِ تداخلِ دارویی هم لازم است.
      https://lhncbc.nlm.nih.gov/RxNav/APIs/

    • openFDA -- سازمانِ غذا و دارویِ آمریکا (FDA):
      برچسبِ رسمیِ دارو (کاربرد، دوز، عوارض، هشدارها) -- عیناً همان
      متنی که در بروشورِ رسمیِ دارو منتشر شده، نه تفسیر یا حدسِ ما.
      https://open.fda.gov/apis/drug/label/

هر دو تابع در صورتِ شکست (نبودِ اینترنت، دارو پیدا نشد، پاسخِ نامعتبر)
None برمی‌گردانند -- هرگز Exception پرتاب نمی‌کنند -- تا لایه‌ی بالاتر
(`online.py`) بتواند به‌جایِ کرش، منبعِ بعدی (MedlinePlus/ویکی‌پدیا) را
امتحان کند.
"""

from __future__ import annotations

import asyncio
from typing import List, Optional

import aiohttp

from .evidence import Evidence
from ...logging_config import get_logger
from ...tools import TranslatorEngine

logger = get_logger(__name__)

RXNAV_BASE = "https://rxnav.nlm.nih.gov/REST"
OPENFDA_BASE = "https://api.fda.gov/drug/label.json"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TRX-Medical/1.0",
    "Accept": "application/json",
}

_FIELD_LABELS_FA = {
    "indications_and_usage": "کاربرد (برچسبِ رسمی)",
    "dosage_and_administration": "دوز و نحوه‌ی مصرف (برچسبِ رسمی)",
    "warnings": "هشدارها",
    "adverse_reactions": "عوارضِ جانبیِ گزارش‌شده",
    "contraindications": "موارد منعِ مصرف",
    "drug_interactions": "تداخل‌هایِ ذکرشده در برچسبِ رسمی",
}


async def _get_json(session: aiohttp.ClientSession, url: str, params: dict = None,
                     attempts: int = 2, timeout: int = 8) -> Optional[dict]:
    if session is None:
        return None
    last_exc = None
    for attempt in range(attempts):
        try:
            async with session.get(url, params=params, headers=_HEADERS,
                                    timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                if resp.status == 200:
                    return await resp.json(content_type=None)
                last_exc = RuntimeError(f"HTTP {resp.status}")
        except (asyncio.TimeoutError, aiohttp.ClientError, ValueError) as e:
            last_exc = e
            await asyncio.sleep(0.4 * (attempt + 1))
    if last_exc:
        logger.warning("خطای دریافت از منبعِ دارویی (%s): %s", url, last_exc)
    return None


async def translate_drug_name_to_en(session: aiohttp.ClientSession, name_fa: str) -> Optional[str]:
    """
    پلِ فارسی→انگلیسی: RxNorm/openFDA فقط نامِ انگلیسیِ دارو را می‌فهمند.
    اگر نامِ ورودی از قبل لاتین باشد (بیشترِ نام‌هایِ دارو در فارسی
    همین‌طورند)، مترجم معمولاً همان را برمی‌گرداند؛ در هر صورت شکستِ
    ترجمه باعثِ None می‌شود نه Exception.
    """
    try:
        translated = await TranslatorEngine.get_translation(session, name_fa, mode="fa2en")
        if not translated or translated.startswith("❌"):
            return name_fa  # شاید خودِ ورودی از قبل لاتین بوده؛ همان را امتحان کن
        term = translated.split(":", 1)[-1].strip()
        return term or name_fa
    except Exception as e:  # noqa: BLE001 - مرزِ شبکه، هر خطایی باید بی‌صدا fallback کند
        logger.warning("ترجمه‌ی نامِ دارو به انگلیسی شکست خورد: %s", e)
        return name_fa


class RxNormConnector:
    """نرمال‌سازیِ نامِ دارو + شناسه‌ی RxCUI (پیش‌نیازِ بررسیِ تداخلِ آنلاین)."""

    @staticmethod
    async def find_rxcui(session: aiohttp.ClientSession, drug_name_en: str) -> Optional[str]:
        data = await _get_json(session, f"{RXNAV_BASE}/rxcui.json", {"name": drug_name_en})
        if not data:
            return None
        ids = data.get("idGroup", {}).get("rxnormId")
        return ids[0] if ids else None

    @classmethod
    async def get_evidence(cls, session: aiohttp.ClientSession, drug_name_fa: str) -> Optional[Evidence]:
        term_en = await translate_drug_name_to_en(session, drug_name_fa)
        if not term_en:
            return None
        rxcui = await cls.find_rxcui(session, term_en)
        if not rxcui:
            return None
        props = await _get_json(session, f"{RXNAV_BASE}/rxcui/{rxcui}/properties.json")
        std_name = (props or {}).get("properties", {}).get("name") or term_en
        content = f"نامِ استانداردِ RxNorm: {std_name} (شناسه‌ی RxCUI: {rxcui})"
        return Evidence(
            source="RxNorm (NLM)", title=std_name, content=content,
            source_type="online", url=f"https://rxnav.nlm.nih.gov/REST/rxcui/{rxcui}",
            reliability=0.75, metadata={"rxcui": rxcui},
        )


class OpenFDAConnector:
    """برچسبِ رسمیِ FDA -- بدونِ تفسیر، عیناً همان متنِ رسمیِ دارو."""

    @classmethod
    async def get_evidence(cls, session: aiohttp.ClientSession, drug_name_fa: str,
                            fields: List[str] = None) -> Optional[Evidence]:
        term_en = await translate_drug_name_to_en(session, drug_name_fa)
        if not term_en:
            return None
        fields = fields or ["indications_and_usage", "dosage_and_administration", "warnings", "adverse_reactions"]
        params = {
            "search": f'openfda.generic_name:"{term_en}" OR openfda.brand_name:"{term_en}"',
            "limit": 1,
        }
        data = await _get_json(session, OPENFDA_BASE, params)
        if not data or not data.get("results"):
            return None
        record = data["results"][0]
        parts = []
        for field in fields:
            value = record.get(field)
            if value:
                text = value[0] if isinstance(value, list) else str(value)
                parts.append(f"**{_FIELD_LABELS_FA.get(field, field)}:** {text[:500]}")
        if not parts:
            return None
        brand = record.get("openfda", {}).get("brand_name") or [term_en]
        content = "\n\n".join(parts)
        return Evidence(
            source="openFDA (سازمانِ غذا و دارویِ آمریکا)", title=brand[0] if brand else term_en,
            content=content, source_type="online",
            url="https://open.fda.gov/apis/drug/label/", reliability=0.85,
        )


async def gather_drug_evidence(session: aiohttp.ClientSession, drug_name_fa: str) -> List[Evidence]:
    """
    از RxNorm و openFDA هم‌زمان می‌پرسد (asyncio.gather چون مستقل‌اند و
    منتظرِ هم ماندن فقط تأخیر اضافه می‌کند) و فقط پاسخ‌هایِ موفق را
    برمی‌گرداند.
    """
    tasks = [
        OpenFDAConnector.get_evidence(session, drug_name_fa),
        RxNormConnector.get_evidence(session, drug_name_fa),
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    evidence = []
    for r in results:
        if isinstance(r, Evidence):
            evidence.append(r)
        elif isinstance(r, Exception):
            logger.warning("یکی از منابعِ آنلاینِ دارو با خطا مواجه شد: %s", r)
    return evidence
