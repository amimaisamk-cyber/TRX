from datetime import datetime, timezone

def source(title, source_type="local", url=None, reliability=None):
    return {"title":title,"type":source_type,"url":url,
            "retrieved_at":datetime.now(timezone.utc).isoformat(),"reliability":reliability}
