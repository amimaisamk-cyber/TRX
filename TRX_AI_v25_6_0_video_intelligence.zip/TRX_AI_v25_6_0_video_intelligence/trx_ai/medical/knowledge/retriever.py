class KnowledgeRetriever:
    def __init__(self,local,online=None,enable_online=False): self.local=local; self.online=online; self.enable_online=enable_online
    def retrieve_disease(self,name): return self.local.evidence_for_disease(name)
    async def retrieve_online(self,query,session):
        if not self.enable_online or self.online is None: return []
        return await self.online.search(query,session)
