# -*- coding: utf-8 -*-
"""
بررسیِ آنلاینِ تداخلِ دارویی از طریقِ RxNav (کتابخانه‌ی ملیِ پزشکیِ
آمریکا -- NLM)، برایِ تکمیلِ `medication/interactions.py` که فقط یک
فهرستِ محلیِ محدود دارد.

خروجیِ `check_many_online` عمداً همان شکلِ دیکشنریِ
`InteractionService.check_pair` را دارد (drug_a, drug_b, severity,
severity_label, note) به‌علاوه‌یِ یک کلیدِ `source` -- تا بتوان نتیجه‌ی
این‌جا را مستقیماً با نتیجه‌ی محلی ادغام کرد و از همان
`response.interaction_report` برایِ نمایش استفاده کرد.

نگاشتِ شدت: RxNav شدت را با متنِ آزادِ انگلیسی توضیح می‌دهد (نه یک enum
ثابت)، پس اینجا یک حدسِ محافظه‌کارانه بر اساسِ کلیدواژه می‌زنیم -- اگر
کلیدواژه‌ی شناخته‌شده‌ای نبود، severity="UNKNOWN" می‌ماند (نه یک حدسِ
پیش‌فرضِ خوش‌بینانه) تا کاربر گمراه نشود.
"""

from __future__ import annotations

from typing import List

import aiohttp

from .drug_sources import RxNormConnector, translate_drug_name_to_en, _get_json, RXNAV_BASE
from ...logging_config import get_logger

logger = get_logger(__name__)

_SEVERITY_KEYWORDS = [
    ("SEVERE", ["contraindicat", "serious", "severe", "avoid combination", "major"]),
    ("MODERATE", ["moderate", "monitor", "caution"]),
    ("MILD", ["minor", "mild"]),
]


def _map_severity(description: str) -> str:
    low = (description or "").lower()
    for level, keywords in _SEVERITY_KEYWORDS:
        if any(kw in low for kw in keywords):
            return level
    return "UNKNOWN"


_SEVERITY_LABELS_FA = {"SEVERE": "شدید", "MODERATE": "متوسط", "MILD": "خفیف", "UNKNOWN": "نامشخص"}


async def check_many_online(session: aiohttp.ClientSession, drug_names_fa: List[str]) -> dict:
    """
    خروجی: {"results": [...], "checked_online": bool, "note": str}.
    اگر شبکه در دسترس نبود یا کمتر از دو RxCUI معتبر پیدا شد،
    checked_online=False برمی‌گردد (نه خطا) تا لایه‌ی بالاتر بتواند فقط
    به نتیجه‌ی محلی بسنده کند.
    """
    if session is None or len(drug_names_fa) < 2:
        return {"results": [], "checked_online": False, "note": ""}

    en_names, rxcuis = [], []
    for name in drug_names_fa:
        en = await translate_drug_name_to_en(session, name)
        en_names.append(en or name)
    for en in en_names:
        rxcuis.append(await RxNormConnector.find_rxcui(session, en))

    valid_pairs = [(name, en, rx) for name, en, rx in zip(drug_names_fa, en_names, rxcuis) if rx]
    if len(valid_pairs) < 2:
        return {
            "results": [], "checked_online": False,
            "note": "⚠️ بررسیِ آنلاینِ RxNav ممکن نشد (نامِ دارو شناسایی نشد یا اینترنت در دسترس نبود).",
        }

    valid_rxcuis = [rx for _, _, rx in valid_pairs]
    data = await _get_json(session, f"{RXNAV_BASE}/interaction/list.json", {"rxcuis": "+".join(valid_rxcuis)})
    if not data:
        return {
            "results": [], "checked_online": False,
            "note": "⚠️ بررسیِ آنلاینِ RxNav ممکن نشد؛ فقط نتیجه‌یِ پایگاه‌دانشِ محلی نمایش داده می‌شود.",
        }

    results = []
    try:
        for group in data.get("fullInteractionTypeGroup", []):
            for itype in group.get("fullInteractionType", []):
                names = [c.get("minConceptItem", {}).get("name", "?") for c in itype.get("minConcept", [])]
                drug_a, drug_b = (names[0], names[1]) if len(names) >= 2 else (names[0] if names else "?", "?")
                for pair in itype.get("interactionPair", []):
                    description = pair.get("description", "")
                    severity = _map_severity(description)
                    results.append({
                        "drug_a": drug_a, "drug_b": drug_b,
                        "severity": severity, "severity_label": _SEVERITY_LABELS_FA[severity],
                        "note": description or "تداخل توسطِ RxNav گزارش شده، بدونِ توضیحِ تکمیلی.",
                        "source": "RxNav (NLM) -- آنلاین",
                    })
    except (KeyError, TypeError, IndexError) as e:
        logger.warning("خطا در تجزیه‌ی پاسخِ تداخلِ RxNav: %s", e)
        return {
            "results": [], "checked_online": False,
            "note": "⚠️ پاسخِ RxNav قابلِ تجزیه نبود؛ فقط نتیجه‌یِ پایگاه‌دانشِ محلی نمایش داده می‌شود.",
        }

    if not results:
        return {
            "results": [], "checked_online": True,
            "note": "✅ در بررسیِ آنلاینِ RxNav، تداخلِ شناخته‌شده‌ای بینِ این داروها ثبت نشده.",
        }
    return {"results": results, "checked_online": True, "note": "بررسیِ آنلاینِ RxNav (NLM) انجام شد."}
