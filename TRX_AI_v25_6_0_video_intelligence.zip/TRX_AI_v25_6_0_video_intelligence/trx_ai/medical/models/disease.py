from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass(frozen=True)
class Disease:
    id: str
    name: str
    symptoms: List[str]
    warning_signs: List[str] = field(default_factory=list)
    duration: str = ""
    severity: str = ""
    sources: List[Dict[str, Any]] = field(default_factory=list)
