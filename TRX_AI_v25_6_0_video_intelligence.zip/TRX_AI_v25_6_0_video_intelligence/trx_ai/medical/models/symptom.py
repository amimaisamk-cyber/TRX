from dataclasses import dataclass
from enum import Enum
from typing import Optional

class SymptomState(str, Enum):
    PRESENT = "PRESENT"
    ABSENT = "ABSENT"
    UNKNOWN = "UNKNOWN"

@dataclass(frozen=True)
class Symptom:
    id: str
    canonical_name: str
    state: SymptomState = SymptomState.PRESENT
    confidence: float = 1.0
    severity: Optional[str] = None
    duration: Optional[str] = None
    onset: Optional[str] = None
    frequency: Optional[str] = None
    context: Optional[str] = None
    evidence_span: Optional[str] = None
