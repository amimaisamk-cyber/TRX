from dataclasses import dataclass, field
from typing import Any, Dict

@dataclass
class MedicalRequest:
    """Stable boundary object for all medical requests."""
    text: str
    session_id: str = "default"
    context: Dict[str, Any] = field(default_factory=dict)
    options: Dict[str, Any] = field(default_factory=dict)

    def normalized_text(self) -> str:
        return " ".join((self.text or "").split())
