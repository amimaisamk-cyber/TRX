from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass(frozen=True)
class Medication:
    id: str
    name: str
    indications: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    interactions: List[str] = field(default_factory=list)
    sources: List[Dict[str, Any]] = field(default_factory=list)
