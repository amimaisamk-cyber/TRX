from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class MedicalResponse:
    status: str = "ok"
    intent: str = "GENERAL_MEDICAL"
    answer: str = ""
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    uncertainty: str = "UNKNOWN"
    requires_followup: bool = False
    emergency: bool = False
    data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "intent": self.intent,
            "answer": self.answer,
            "evidence": list(self.evidence),
            "warnings": list(self.warnings),
            "uncertainty": self.uncertainty,
            "requires_followup": self.requires_followup,
            "emergency": self.emergency,
            **self.data,
        }
