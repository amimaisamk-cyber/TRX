from ..formatting import format_response
class ResponseRenderer:
    def render(self,message,personality="دکتر کامل",online=False): return format_response(message,personality,online)
