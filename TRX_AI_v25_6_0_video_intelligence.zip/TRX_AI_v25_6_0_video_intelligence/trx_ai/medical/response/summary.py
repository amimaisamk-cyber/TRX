# -*- coding: utf-8 -*-
"""
تولیدِ «خلاصه‌ی مراجعه به پزشک»: یک متنِ ساختاریافته و قابلِ کپی/چاپ که
همه‌یِ چیزی را که سامانه از گفتگو استخراج کرده -- علائمِ حاضر/غایب،
شدت، شروع، مدت، کاندیدهایِ رتبه‌بندی‌شده با سطحِ شواهد، و سطحِ فوریتِ
پیشنهادی -- در یک‌جا جمع می‌کند تا بیمار بتواند آن را عیناً به پزشک
نشان دهد یا برایِ خودش نگه دارد.

این خلاصه یک تشخیص یا نسخه نیست؛ فقط بازآراییِ شفافِ همان اطلاعاتی
است که کاربر و موتورِ تشخیص در طولِ گفتگو تولید کرده‌اند.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def generate_visit_summary(
    extraction: Dict[str, Any],
    ranked: List[Dict[str, Any]],
    urgency: Optional[Dict[str, Any]] = None,
    max_candidates: int = 3,
) -> str:
    lines: List[str] = [
        "📝 **خلاصه برای مراجعه به پزشک**",
        f"🕒 تاریخِ تنظیم (UTC): {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}",
    ]

    # extraction به‌شکلِ خروجیِ diagnosis.extractor.extract(...) است؛ فهرستِ
    # آبجکت‌های Symptom زیرِ کلیدِ "symptoms" قرار دارد (نه "symptom_objects"
    # -- آن کلید فقط در دیکشنریِ بیرونیِ DiagnosticEngine.analyze وجود دارد).
    symptom_objects = (extraction or {}).get("symptoms") or []
    present = [s.canonical_name for s in symptom_objects if getattr(s.state, "value", s.state) == "PRESENT"]
    absent = [s.canonical_name for s in symptom_objects if getattr(s.state, "value", s.state) == "ABSENT"]

    lines.append("")
    lines.append("**علائمِ گزارش‌شده:** " + ("، ".join(present) if present else "-"))
    if absent:
        lines.append("**علائمِ رد‌شده (کاربر صراحتاً نداشتنِ آن را ذکر کرده):** " + "، ".join(absent))

    detail_bits = []
    if (extraction or {}).get("severity"):
        detail_bits.append(f"شدت: {extraction['severity']}")
    if (extraction or {}).get("duration"):
        detail_bits.append(f"مدت: {extraction['duration']}")
    if (extraction or {}).get("onset"):
        onset_fa = "ناگهانی" if extraction["onset"] == "sudden" else "تدریجی"
        detail_bits.append(f"نوعِ شروع: {onset_fa}")
    if detail_bits:
        lines.append("**جزئیاتِ گزارش‌شده:** " + " | ".join(detail_bits))

    if ranked:
        lines.append("")
        lines.append("**کاندیدهایِ احتمالیِ سامانه (فقط جهتِ اطلاع، نه تشخیصِ قطعی):**")
        for r in ranked[:max_candidates]:
            evidence = r.get("evidence_level", "-")
            matched = "، ".join(r.get("matched_symptoms", []) or [])
            lines.append(f"   • {r['disease']} — سطحِ شواهد: {evidence}" + (f" (علائمِ منطبق: {matched})" if matched else ""))

    lines.append("")
    lines.append("**بررسیِ علائمِ هشدارِ فوریتی:** انجام شد؛ در زمانِ این گفتگو موردِ فوریتی شناسایی نشد.")

    if urgency:
        lines.append(f"**سطحِ فوریتِ پیشنهادیِ سامانه:** {urgency.get('message', urgency.get('level', '-'))}")

    lines.append("")
    lines.append("⚠️ این خلاصه صرفاً برای تسهیلِ گفتگویِ شما با پزشک تهیه شده و جایگزینِ تشخیص، نسخه یا معاینه نیست.")

    return "\n".join(lines)
