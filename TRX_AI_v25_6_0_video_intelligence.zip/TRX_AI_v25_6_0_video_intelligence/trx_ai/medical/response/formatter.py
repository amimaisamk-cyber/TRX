def diagnostic_message(ranked, symptoms, disease_db, uncertainty=None, urgency=None):
    if not ranked:
        msg = "⚠️ شواهد کافی برای یک نتیجه مشخص وجود ندارد. لطفاً علائم، مدت و شدت آن‌ها را دقیق‌تر توضیح دهید."
        if urgency and urgency.get("message"):
            msg += f"\n\n{urgency['message']}"
        return msg
    top=ranked[0]
    parts=[f"🔎 **کاندید اصلی:** {top['disease']}",
           f"📊 **امتیاز تطابق علائم:** {top['score']:.2f}",
           f"🧭 **سطح شواهد:** {uncertainty or top.get('evidence_level','UNKNOWN')}",
           f"📋 **علائم شناسایی‌شده:** {', '.join(symptoms) if symptoms else '-'}"]
    if top.get("matched_symptoms"): parts.append(f"✅ **علائم تطبیق‌یافته:** {', '.join(top['matched_symptoms'])}")
    if urgency and urgency.get("message"):
        parts.append(urgency["message"])
    parts += ["⚠️ امتیاز تطابق، احتمال واقعی بیماری نیست و تشخیص قطعی محسوب نمی‌شود.",
              "🩺 برای تشخیص قطعی و تصمیم درمانی، ارزیابی پزشک لازم است."]
    return "\n\n".join(parts)

def interaction_report(names, results, online_note: str = ""):
    """
    گزارشِ بررسیِ تداخلِ داروییِ چند-دارویی (n>=2)؛ `results` می‌تواند
    ترکیبی از خروجیِ `InteractionService.check_many` (محلی) و
    `knowledge.interaction_online.check_many_online` (RxNav) باشد --
    هر آیتم می‌تواند کلیدِ اختیاریِ `source` داشته باشد؛ اگر نبود،
    پیش‌فرض «پایگاه‌دانشِ محلی» نمایش داده می‌شود.
    """
    header = f"💊 **بررسیِ تداخلِ دارویی برایِ:** {'، '.join(n.strip() for n in names)}"
    if not results:
        tail = f"\n\n{online_note}" if online_note else ""
        return header + "\n\nهیچ زوجِ دارویی برایِ بررسی یافت نشد یا تداخلِ ثبت‌شده‌ای پیدا نشد." + tail
    lines = [header, ""]
    severity_icon = {"SEVERE": "🔴", "MODERATE": "🟠", "MILD": "🟡", "NONE": "🟢", "UNKNOWN": "⚪"}
    for r in results:
        icon = severity_icon.get(r["severity"], "⚪")
        source_tag = f" [{r['source']}]" if r.get("source") else ""
        lines.append(f"{icon} **{r['drug_a']} + {r['drug_b']}** — شدت: {r['severity_label']}{source_tag}")
        lines.append(f"   {r['note']}")
    lines.append("")
    if online_note:
        lines.append(online_note)
    lines.append("⚠️ این بررسی بر اساسِ پایگاه‌دانشِ محلی و/یا RxNav (NLM) است و جایگزینِ بررسیِ کاملِ داروساز/پزشک با در نظر گرفتنِ دوز، سابقه‌ی پزشکی و سایرِ داروها نیست.")
    return "\n".join(lines)


def medication_message(drug,info):
    # Deliberately avoids turning a local data row into individualized prescribing.
    return (f"💊 **اطلاعات عمومی {drug}:**\n\n**کاربرد:** {info.get('use','-')}\n"
            f"**عوارض گزارش‌شده در داده محلی:** {', '.join(info.get('side_effects',[])) or '-'}\n"
            f"**احتیاط:** {info.get('caution','-')}\n\n"
            "⚠️ دوز و تغییر درمان باید بر اساس سن، بیماری‌های زمینه‌ای، بارداری، سایر داروها و نظر پزشک/داروساز تعیین شود.")
