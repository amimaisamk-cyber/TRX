from dataclasses import dataclass, field
from datetime import datetime, timezone
@dataclass
class DialogueState:
    session_id: str
    symptoms: set = field(default_factory=set)
    answers: dict = field(default_factory=dict)
    candidates: list = field(default_factory=list)
    asked_questions: set = field(default_factory=set)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    turns: int = 0
    original_text: str = ""
    last_symptom: str|None = None
    # سؤالِ باز (چه‌مدت/چه‌شدت) فقط وقتی لازم است که کاربر خودش این‌ها
    # را نگفته باشد؛ هدف این نیست که همیشه یک سؤالِ اضافه تحمیل شود.
    awaiting_context: bool = False
    context_asked: bool = False
    # چند بار پشتِ‌سرِهم به سؤالِ زمینه (مدت/شدت) پاسخِ نامفهوم/امتناع
    # داده شده. برایِ جلوگیری از حلقه‌یِ بی‌پایانِ «دوباره بپرس» وقتی
    # کاربر واقعاً نمی‌خواهد یا نمی‌تواند دقیق بگوید (نگاه کنید به
    # manager.answer: بعد از یک بار تکرار، بدونِ این اطلاعات ادامه
    # می‌دهیم به‌جایِ گیرکردنِ گفتگو).
    context_reprompt_count: int = 0
