def next_question(state, disease_db):
    pool=state.candidates[:4]; counts={}
    asked=state.symptoms | set(state.answers)
    for d in pool:
        for s in disease_db[d].get('symptoms',[]):
            s=s.lower()
            if s not in asked: counts[s]=counts.get(s,0)+1
    if not counts: return None
    total=max(1,len(pool))
    return max(counts, key=lambda s:(-abs(counts[s]-total/2), counts[s]))
