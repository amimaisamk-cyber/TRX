# -*- coding: utf-8 -*-
"""
اعتبارسنجیِ پاسخِ کاربر به سؤالِ بازِ زمینه (CONTEXT_QUESTION: مدت/شدت).

باگِ قبلی: در manager.answer()، وقتی st.awaiting_context برابر True بود،
*هر* متنِ ورودی -- بدونِ هیچ بررسی‌ای -- به‌عنوانِ پاسخِ معتبر پذیرفته
می‌شد، turns افزایش می‌یافت و گفتگو یک قدم جلو می‌رفت. حتی متن‌هایی مثلِ
«نمیدونم والا» یا یک کاراکترِ تصادفی. این یعنی موتور نمی‌توانست بینِ
«پاسخِ واقعی» و «عدمِ پاسخ» تفاوت بگذارد -- دقیقاً همان نقصی که در
حالتِ بله/خیر (_parse_yes_no) از قبل درست مدیریت می‌شد.

این ماژول همان سطح از دقت را برایِ مرحله‌یِ سؤالِ باز اضافه می‌کند،
بدونِ اضافه‌کردنِ یک مدلِ NLU جدید: از همان extractor موجود (که مدت/
شدت/شروع را تشخیص می‌دهد) به‌عنوانِ منبعِ حقیقت استفاده می‌کند، و فقط
وقتی متن هیچ سیگنالی نداشت، سراغِ الگوهایِ صریحِ «امتناع/ندانستن» می‌رود.

سه دسته:
  valid   -> متن سیگنالِ قابل‌استفاده دارد (مدت/شدت/شروع یا علامتِ جدید).
  refused -> کاربر صریحاً گفته نمی‌داند/مهم نیست/فرقی نمی‌کند.
  unclear -> نه سیگنال دارد و نه یک الگوی امتناعِ شناخته‌شده -- مثلِ
             متنِ خیلی کوتاه، بی‌ربط، یا نامفهوم.

هر دو حالتِ refused و unclear باعثِ «سؤالِ دوباره بدونِ پیشرفتِ state»
می‌شوند؛ تفکیک‌شان فقط برایِ انتخابِ پیامِ مناسب‌تر است.
"""
from __future__ import annotations

import re

from ..diagnosis.extractor import extract

# الگوهایِ رایجِ «نمی‌دانم/امتناع» به فارسیِ محاوره‌ای. برایِ مقاومت در
# برابرِ نیم‌فاصله/فاصله/بدونِ‌فاصله، مقایسه پس از حذفِ همه‌یِ فاصله‌ها و
# نیم‌فاصله‌ها انجام می‌شود (مثلاً «نمی دونم»، «نمی‌دونم» و «نمیدونم»
# باید هر سه یک چیز شناخته شوند).
_REFUSAL_PHRASES = [
    "نمیدونم", "نمیدانم", "نمی دونم", "نمی دانم",
    "نمیدونمشوالا", "چیزیندارمبگم", "چیبگم",
    "مشخصنیست", "معلومنیست", "فرقینمیکنه", "فرقینداره",
    "مهمنیست", "هرچی", "هرچیزی", "فرقنداره",
]


def _squash(text: str) -> str:
    """حذفِ فاصله و نیم‌فاصله برایِ مقایسه‌یِ سطحیِ عبارت‌های امتناع."""
    return text.replace(" ", "").replace("\u200c", "")


def _looks_like_refusal(text: str) -> bool:
    squashed = _squash(text)
    return any(phrase in squashed for phrase in _REFUSAL_PHRASES)


def classify_context_answer(text: str) -> tuple[str, dict]:
    """
    پاسخِ کاربر به CONTEXT_QUESTION را دسته‌بندی می‌کند.

    برمی‌گرداند: (status, extraction) که status یکی از
    "valid" / "refused" / "unclear" است و extraction خروجیِ همان
    extract() است (تا caller مجبور به فراخوانیِ دوباره‌اش نباشد).
    """
    text = (text or "").strip()
    extraction = extract(text)

    has_signal = bool(
        extraction.get("severity")
        or extraction.get("duration")
        or extraction.get("onset")
        or extraction.get("symptoms")
    )
    if has_signal:
        return "valid", extraction

    if not text:
        return "unclear", extraction

    if _looks_like_refusal(text):
        return "refused", extraction

    # متنی با حداکثر دو کلمه که نه سیگنالِ پزشکی دارد و نه الگویِ
    # امتناعِ شناخته‌شده -- مثلِ «هان؟»، «اهم»، یک حرفِ تنها -- را هم
    # نامفهوم در نظر می‌گیریم، چون چیزی برایِ استفاده در آن نیست.
    if len(text.split()) <= 2:
        return "unclear", extraction

    return "valid", extraction
