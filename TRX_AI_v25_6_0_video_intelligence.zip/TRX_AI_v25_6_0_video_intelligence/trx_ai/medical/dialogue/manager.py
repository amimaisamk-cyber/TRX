from .state import DialogueState
from .strategy import next_question
from .questions import (
    yes_no, CONTEXT_QUESTION,
    CONTEXT_UNCLEAR_REPROMPT, CONTEXT_REFUSAL_REPROMPT,
)
from .context_validator import classify_context_answer
from ..diagnosis.confidence import assess
from ..safety.redflags import detect

class DialogueManager:
    MAX_FOLLOWUP_QUESTIONS=7; CONFIDENCE_GAP=0.20; CONFIDENCE_MIN=0.80
    _YES={"بله","بلی","آره","اره","آری","دارم","هست","مثبت"}; _NO={"خیر","نه","نخیر","ندارم","نیست","منفی"}
    def __init__(self, diagnostic, config=None):
        self.diagnostic=diagnostic; self.config=config; self._states={}
        self.MAX_FOLLOWUP_QUESTIONS=getattr(config,"max_followup_questions",7) if config else 7
        # قبلاً این دو، ثابت‌های کلاسیِ مرده بودند: هیچ‌جا خوانده نمی‌شدند
        # (خودِ _decisive عدد را مستقیم و به‌اشتباه هارد-کد کرده بود) و
        # حتی مقیاسشان هم اشتباه بود (۸۰.۰/۳۲.۰ روی مقیاسِ ۰ تا ۱۰۰، در
        # حالی‌که امتیازِ واقعی بین ۰ و ۱ است). حالا از همان config واحدِ
        # پروژه (مقیاسِ ۰ تا ۱) پر می‌شوند تا اگر جایی خوانده شوند هم
        # درست باشند.
        self.CONFIDENCE_MIN=getattr(config,"confidence_min",0.80) if config else 0.80
        self.CONFIDENCE_GAP=getattr(config,"confidence_gap",0.20) if config else 0.20
    @property
    def _dialogues(self):
        return {k:{"confirmed":v.symptoms,"denied":{x for x,a in v.answers.items() if a is False},"candidates":v.candidates,"turns":v.turns,"original_text":v.original_text,"last_symptom":v.last_symptom} for k,v in self._states.items()}
    def has_active_dialogue(self,k): return k in self._states
    def cancel_dialogue(self,k): self._states.pop(k,None)
    def _parse_yes_no(self,text):
        t=text.strip().lower().strip("!.،,؟?")
        if t in self._NO or t.startswith(("نه","خیر","ندار","نیست","منفی")): return False
        if t in self._YES or t.startswith(("بله","بلی","آره","اره","دارم","هست")): return True
        return None
    def extract_symptoms(self,text): return self.diagnostic.analyze(text)["symptoms"]
    def rank_diseases(self,symptoms): return self.diagnostic.rank(symptoms)
    def _decisive(self,r):
        # باگِ قبلی: اگر فقط یک کاندید match می‌شد (len(r)==1)، بدونِ
        # توجه به امتیازش، بی‌قیدوشرط «قطعی» فرض می‌شد -- یعنی حتی یک
        # تطبیقِ ضعیف با شواهدِ کم هم باعثِ پایانِ زودهنگامِ گفتگو می‌شد.
        # علاوه‌براین، برایِ حالتِ چندکاندیدی از OR استفاده شده بود
        # (score>=۰.۸۰ *یا* gap>=۰.۲۰)، در حالی‌که یک gap زیاد با
        # امتیازِ خیلی پایین (مثلاً ۰.۲۵ در برابرِ ۰.۰۳) اصلاً شواهدِ
        # کافی نیست.
        # به‌جایِ نگه‌داشتنِ دو پیاده‌سازیِ موازیِ «قطعی‌بودن» که ممکن است
        # با گذرِ زمان از هم واگرا شوند، همینجا از assess() -- همان
        # منبعِ حقیقتی که diagnosis/engine.py هم برایِ confidence.sufficient
        # استفاده می‌کند -- استفاده می‌شود: AND درست (هم امتیازِ بالا، هم
        # فاصله‌یِ کافی با گزینه‌یِ بعدی)، و برایِ تک‌کاندید هم امتیاز باید
        # واقعاً بالا باشد.
        if not r: return False
        return assess(r, self.CONFIDENCE_MIN, self.CONFIDENCE_GAP)["sufficient"]
    def _finish(self,st,ranked,generate_response):
        original=st.original_text; symptoms=sorted(st.symptoms); self.cancel_dialogue(st.session_id)
        result=generate_response(ranked,symptoms,original)
        # قبلاً اینجا فقط result["message"] برمی‌گشت -- یعنی caller (مثلاً
        # online.py) هیچ راهی نداشت بفهمد نتیجه‌ی محلی واقعاً «قطعی» بوده
        # یا فقط بهترین‌چیزیِ ممکن از یک پایگاه‌داده‌ی کوچک. حالا کلِ
        # دیکشنری (شاملِ confidence/uncertainty/status) برمی‌گردد تا
        # تصمیمِ «آیا سراغِ اینترنت هم برویم؟» بر اساسِ داده باشد، نه
        # جستجویِ رشته‌ای در متنِ پیام.
        result["done"]=True
        return result
    def _ask_next_or_finish(self,st,ranked,generate_response):
        if st.turns>=self.MAX_FOLLOWUP_QUESTIONS or self._decisive(ranked):
            return self._finish(st,ranked,generate_response)
        q=next_question(st,self.diagnostic.disease_db)
        if not q:
            return self._finish(st,ranked,generate_response)
        st.last_symptom=q; st.asked_questions.add(q); self._states[st.session_id]=st
        return {"done":False,"message":yes_no(q,st.turns)}
    def start(self,k,text,generate_response):
        if detect(text): self.cancel_dialogue(k); return {"done":True,"emergency":True,"message":detect(text)}
        d=self.diagnostic.analyze(text); extracted=d["symptoms"]; ranked=d["ranked"]
        if not extracted:return {"done":True,"message":"❌ علائم مشخصی در متن شما شناسایی نشد. لطفاً علائم را با جزئیات بیشتر شرح دهید."}
        if not ranked or self._decisive(ranked):
            result=generate_response(ranked,extracted,text); result["done"]=True; return result
        st=DialogueState(k,set(extracted),{},[x["disease"] for x in ranked],set(),original_text=text)
        # قبلاً اینجا مستقیم می‌رفت سراغِ سؤالِ بله/خیرِ تفکیکی. حالا اگر
        # کاربر خودش مدت/شدت را نگفته بود (extraction.severity/duration
        # هر دو خالی)، اول یک سؤالِ باز می‌پرسیم -- دقیقاً همان چیزی که
        # نبودش باعثِ حسِ «کم‌سؤال» می‌شد.
        extraction=d.get("extraction") or {}
        if not (extraction.get("severity") or extraction.get("duration")):
            st.awaiting_context=True
            self._states[k]=st
            return {"done":False,"message":CONTEXT_QUESTION}
        st.context_asked=True
        self._states[k]=st
        return self._ask_next_or_finish(st,ranked,generate_response)
    def answer(self,k,text,generate_response):
        st=self._states.get(k)
        if not st:return {"done":True,"message":"⚠️ در حال حاضر پرسش پزشکی فعالی وجود ندارد."}
        emergency=detect(text)
        if emergency:self.cancel_dialogue(k);return {"done":True,"emergency":True,"message":emergency}
        if st.awaiting_context:
            # قبلاً اینجا هر متنی -- حتی «نمیدونم والا» -- بدونِ بررسی
            # به‌عنوانِ پاسخِ معتبر پذیرفته می‌شد و state جلو می‌رفت.
            # حالا اول طبقه‌بندی می‌شود: فقط پاسخِ واقعاً حاویِ اطلاعات
            # (مدت/شدت/شروع/علامتِ جدید) باعثِ پیشرفتِ گفتگو می‌شود؛
            # نامفهوم/امتناع باعثِ تکرارِ سؤال می‌شوند، بدونِ افزایشِ
            # turns و بدونِ تغییرِ awaiting_context -- دقیقاً هم‌سطح با
            # رفتاری که _parse_yes_no برایِ پاسخ‌هایِ مبهمِ بله/خیر دارد.
            status, _extraction = classify_context_answer(text)
            if status in ("refused", "unclear"):
                st.context_reprompt_count += 1
                if st.context_reprompt_count <= 1:
                    # یک بار دیگر با توضیحِ بیشتر می‌پرسیم -- شاید کاربر
                    # فقط منظورِ سؤال را نگرفته بود.
                    message = CONTEXT_REFUSAL_REPROMPT if status == "refused" else CONTEXT_UNCLEAR_REPROMPT
                    return {"done": False, "message": message}
                # دومین پاسخِ نامفهوم/امتناع پشتِ‌سرِهم: به‌جایِ حلقه‌یِ
                # بی‌پایانِ «دوباره بپرس»، بدونِ این اطلاعات ادامه
                # می‌دهیم. مدت/شدت نامشخص می‌مانند (extract روی متنِ
                # اصلی همچنان اجرا خواهد شد)، ولی گفتگو دیگر گیر نمی‌کند.
                st.awaiting_context = False; st.context_asked = True
                st.turns += 1
                ranked = self.diagnostic.rank(st.symptoms) or []
                st.candidates = [x["disease"] for x in ranked] or st.candidates
                return self._ask_next_or_finish(st, ranked, generate_response)
            # پاسخِ آزادِ کاربر (مثلاً «از دو روز پیش، متوسط») به متنِ اصلی
            # افزوده می‌شود تا extract() در تولیدِ پاسخِ نهایی دوباره روی
            # آن اجرا شود و مدت/شدت را واقعاً به‌کار بگیرد -- بدونِ نیاز
            # به تغییرِ منطقِ امتیازدهی یا مدل‌ها.
            st.awaiting_context=False; st.context_asked=True
            st.original_text=(st.original_text+" "+text).strip()
            st.turns+=1
            ranked=self.diagnostic.rank(st.symptoms) or []
            st.candidates=[x["disease"] for x in ranked] or st.candidates
            return self._ask_next_or_finish(st,ranked,generate_response)
        p=self._parse_yes_no(text)
        if p is None:return {"done":False,"message":yes_no(st.last_symptom,st.turns)}
        st.answers[st.last_symptom]=p; st.turns+=1
        if p: st.symptoms.add(st.last_symptom)
        ranked=self.diagnostic.rank(st.symptoms); st.candidates=[x["disease"] for x in ranked] or st.candidates
        return self._ask_next_or_finish(st,ranked,generate_response)
