from ..safety.uncertainty import evidence_level

def _norm(v): return str(v or "").strip().lower()

def rank(extracted_symptoms, disease_db, symptom_to_condition, weights=None):
    weights=weights or {"positive":.55,"specificity":.20,"context":.10,"duration":.05,"severity":.05,"contradiction":.20,"missing_critical":.10}
    present={_norm(s) for s in extracted_symptoms if _norm(s)}
    scores=[]
    for disease, info in disease_db.items():
        ds={_norm(s) for s in info.get("symptoms",[])}
        matched=sorted(ds & present)
        if not matched: continue
        positive=len(matched)/max(1,len(ds))
        specificity=len(matched)/max(1,len(present))
        contradiction=0.0
        missing_critical=0.0
        warning={_norm(x) for x in info.get("warning_signs",[])}
        # A warning sign that is explicitly absent is not a positive finding.
        absent=present-set(present)  # placeholder for forward-compatible state-aware callers
        critical_missing=len(warning & absent)
        score=(weights["positive"]*positive + weights["specificity"]*specificity
               - weights["contradiction"]*contradiction - weights["missing_critical"]*missing_critical)
        score=max(0.0,min(1.0,score))
        scores.append({"disease":disease,"score":round(score,4),"match_score":round(score,4),
                       "matched_symptoms":matched,"missing_critical_evidence":[],
                       "percent":round(score*100,2),
                       "severity":info.get("severity",""),"duration":info.get("duration",""),
                       "evidence_level":evidence_level(score,0)})
    scores.sort(key=lambda x:(x["score"],len(x["matched_symptoms"])),reverse=True)
    for i,item in enumerate(scores): item["evidence_level"]=evidence_level(item["score"],len(scores))
    return scores
