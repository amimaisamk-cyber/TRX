from .extractor import extract
from .ranking import rank
from .confidence import assess
from .evidence import build_evidence

class DiagnosticEngine:
    def __init__(self,disease_db,symptom_to_condition,config=None):
        self.disease_db=disease_db; self.symptom_to_condition=symptom_to_condition; self.config=config
    def analyze(self,text):
        data=extract(text)
        present=[s.canonical_name.lower() for s in data["symptoms"] if s.state.value=="PRESENT"]
        ranked=self.rank(present)
        conf=assess(ranked, getattr(self.config,"confidence_min",.80), getattr(self.config,"confidence_gap",.20))
        evidence=[build_evidence(x["disease"],x["matched_symptoms"],x.get("missing_critical_evidence")) for x in ranked[:getattr(self.config,"max_candidates",5)]]
        return {"extraction":data,"symptoms":present,"symptom_objects":data["symptoms"],"ranked":ranked[:getattr(self.config,"max_candidates",5)],"confidence":conf,"evidence":evidence}
    def rank(self,symptoms):
        return rank(symptoms,self.disease_db,self.symptom_to_condition,getattr(self.config,"ranking_weights",None))
