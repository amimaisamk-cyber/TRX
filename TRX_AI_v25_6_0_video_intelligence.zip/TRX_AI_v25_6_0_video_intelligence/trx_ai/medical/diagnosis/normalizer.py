import re
from typing import Dict, List
from ..models.symptom import Symptom, SymptomState
from ..safety.negation import symptom_state

ALIASES: Dict[str, List[str]] = {
    "FEVER":["تب بالا","تب","دمای بدن"], "HEADACHE":["سردرد","درد سر","سرم درد","سرم درد می کنه","میگرن","سنگینی سر"],
    "COUGH":["سرفه خلط دار","سرفه خلط‌دار","سرفه خشک","سرفه"], "SORE_THROAT":["گلودرد","درد گلو"],
    "SHORTNESS_OF_BREATH":["تنگی نفس شدید","تنگی نفس","سختی تنفس","نفس تنگی","نفس کم میارم"],
    "NAUSEA":["حالت تهوع","تهوع"], "DIZZINESS":["سرگیجه","منگی","سبکی سر"],
    "FATIGUE":["خستگی","ضعف","بی حالی","بی‌حالی"], "DIARRHEA":["اسهال","شکم روش","مدفوع آبکی"],
    "CONSTIPATION":["یبوست","سخت مدفوع"], "CHEST_PAIN":["درد قفسه سینه","درد قفسه‌سینه","درد سینه","فشار سینه"],
    "PALPITATIONS":["تپش قلب","طپش","ضربان قلب"],
    "RUNNY_NOSE":["آبریزش بینی"], "NASAL_CONGESTION":["گرفتگی بینی"], "SNEEZING":["عطسه"],
    "VOMITING":["استفراغ","بالا آوردن"], "ABDOMINAL_PAIN":["درد شکم","دل درد","درد معده"],
    # --- گسترشِ واژگانِ علائم (پاسخ به این که تشخیص خیلی چیزا رو نمی‌فهمید) ---
    # چند مورد (تکرر/سوزش ادرار، خونریزی بینی، درد گوش، لرز) عیناً با
    # رشته‌ی متناظرشان در disease_db یکی‌ست، پس هم شناسایی می‌شوند هم روی
    # امتیازدهی اثر می‌گذارند؛ بقیه حداقل از خطایِ «علائم شناسایی نشد»
    # جلوگیری می‌کنند حتی اگر روی امتیازِ یک بیماریِ خاص اثر نگذارند.
    "EAR_PAIN":["درد گوش","گوش درد","گوشم درد میکنه"],
    "URINARY_FREQUENCY":["تکرر ادرار","تکررِ ادرار","زیاد دستشویی میرم"],
    "DYSURIA":["سوزش ادرار","سوزشِ ادرار","سوزش هنگام ادرار"],
    "NOSEBLEED":["خونریزی بینی","خون‌ریزی بینی","خون از دماغ"],
    "CHILLS":["لرز","لرز میکنم"],
    "ITCHING":["خارش شدید","خارش پوست","خارش"],
    "SKIN_RASH":["کهیر","بثورات پوستی","بثوراتِ پوستی","جوش پوستی","دانه روی پوست"],
    "JOINT_PAIN":["درد مفاصل","درد مفصل","مفصلم درد میکنه"],
    "BACK_PAIN":["درد کمر","کمر درد","کمرم درد میکنه"],
    "TOOTH_PAIN":["درد دندان","دندان درد","دندونم درد میکنه"],
    "INSOMNIA":["بی خوابی","بی‌خوابی","خوابم نمیبره","نمی‌تونم بخوابم"],
    "SWELLING":["تورم","ورم کرده","ورم"],
    "EYE_REDNESS":["قرمزی چشم","چشمم قرمزه"],
    "SKIN_DRYNESS":["خشکی پوست","خشکیِ پوست","پوستم خشک شده"],
}
CANONICAL_TO_LEGACY={
    "FEVER":"تب","HEADACHE":"سردرد","COUGH":"سرفه","SORE_THROAT":"گلودرد","SHORTNESS_OF_BREATH":"تنگی نفس",
    "NAUSEA":"تهوع","DIZZINESS":"سرگیجه","FATIGUE":"خستگی","DIARRHEA":"اسهال","CONSTIPATION":"یبوست",
    "CHEST_PAIN":"درد قفسه سینه","PALPITATIONS":"تپش قلب","RUNNY_NOSE":"آبریزش بینی","NASAL_CONGESTION":"گرفتگی بینی",
    "SNEEZING":"عطسه","VOMITING":"استفراغ","ABDOMINAL_PAIN":"درد شکم",
    "EAR_PAIN":"درد گوش","URINARY_FREQUENCY":"تکرر ادرار","DYSURIA":"سوزش ادرار","NOSEBLEED":"خونریزی بینی",
    "CHILLS":"لرز","ITCHING":"خارش","SKIN_RASH":"کهیر","JOINT_PAIN":"درد مفاصل","BACK_PAIN":"درد کمر",
    "TOOTH_PAIN":"درد دندان","INSOMNIA":"بی خوابی","SWELLING":"تورم","EYE_REDNESS":"قرمزی چشم",
    "SKIN_DRYNESS":"خشکی پوست",
}

def normalize(text: str) -> List[Symptom]:
    text=(text or "").lower()
    out=[]
    for sid, aliases in ALIASES.items():
        matched=None
        for alias in sorted(aliases, key=len, reverse=True):
            if alias.lower() in text:
                matched=alias; break
        if matched:
            state=symptom_state(text, matched)
            confidence=1.0 if len(matched)>3 else .9
            out.append(Symptom(sid,CANONICAL_TO_LEGACY[sid],state,confidence,evidence_span=matched))
    return out
