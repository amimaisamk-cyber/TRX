import re
from .normalizer import normalize

def extract(text: str):
    text=text or ""
    symptoms=normalize(text)
    severity=None
    if re.search(r"خیلی\s+شدید|بسیار\s+شدید|شدید|وحشتناک", text): severity="severe"
    elif re.search(r"متوسط", text): severity="moderate"
    elif re.search(r"خفیف|کم", text): severity="mild"
    duration=None
    m=re.search(r"(?:حدود|از|به مدت)?\s*(\d+)\s*(روز|روزها|ساعت|هفته|ماه|دقیقه)",text)
    if m: duration=f"{m.group(1)} {m.group(2)}"
    onset="sudden" if re.search(r"ناگهانی|یکدفعه|یک‌دفعه",text) else ("gradual" if re.search(r"تدریجی|کم‌کم|کم کم",text) else None)
    for s in symptoms:
        object.__setattr__(s,"severity",severity)
        object.__setattr__(s,"duration",duration)
        object.__setattr__(s,"onset",onset)
    return {"symptoms":symptoms,"severity":severity,"duration":duration,"onset":onset,"raw_text":text}
