from ..safety.uncertainty import uncertainty_label

def assess(ranked, minimum=.80, minimum_gap=.20):
    if not ranked:
        return {"level":"INSUFFICIENT EVIDENCE","score":0.0,"sufficient":False,"gap":0.0}
    top=float(ranked[0]["score"])
    gap=top-float(ranked[1]["score"]) if len(ranked)>1 else top
    sufficient=top>=minimum and gap>=minimum_gap
    return {"level":uncertainty_label(top,gap,minimum,minimum_gap),"score":top,"sufficient":sufficient,"gap":gap}
