def build_evidence(disease, matched, missing=None, source=None, source_type="local"):
    return {
        "type":"diagnostic_match","disease":disease,"matched_symptoms":list(matched),
        "missing_critical_evidence":list(missing or []),
        "source":source or "TRX AI local medical data","source_type":source_type,
    }
