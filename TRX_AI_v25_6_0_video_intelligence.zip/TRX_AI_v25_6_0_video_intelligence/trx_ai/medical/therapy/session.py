# -*- coding: utf-8 -*-
"""
وضعیتِ هر جلسه‌ی گفتگویِ همراهِ روان‌شناختی -- کاملاً درون‌حافظه‌ای
(مثلِ DialogueManager._dialogues برایِ گفتگویِ تشخیصِ علائم)، چون این
پروژه یک سرورِ تک‌کاربره/تک‌پردازشیِ شخصی است، نه یک سرویسِ چندکاربره‌ی
توزیع‌شده.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# بعد از این مدت بی‌فعالیتی (ثانیه)، جلسه دیگر «فعال» حساب نمی‌شود --
# یعنی پیام‌هایِ بعدیِ کاربر بدونِ کلیدواژه‌ی صریح دوباره به این ماژول
# وصل نمی‌شوند (تا یک گفتگویِ رهاشده تا ابد قفلِ مکالمه نماند).
SESSION_TIMEOUT_SECONDS = 30 * 60

# بعد از این تعداد نوبتِ متوالیِ *بدونِ* هیچ نشانه‌ی پریشانی (یعنی
# emotion == "neutral" هر بار)، جلسه به‌طور طبیعی خاتمه می‌یابد -- تا
# یک گفتگویِ عادی که تصادفاً یک‌بار با کلیدواژه‌ی احساسی شروع شده، برایِ
# همیشه در حالتِ «همراهِ روان‌شناختی» گیر نکند.
NEUTRAL_TURNS_TO_EXIT = 3


@dataclass
class TherapySession:
    session_id: str
    turn_count: int = 0
    consecutive_neutral: int = 0
    emotion_history: List[str] = field(default_factory=list)
    stage: str = "opening"  # opening -> exploring -> deepening
    crisis_shown: bool = False
    last_activity: float = field(default_factory=time.time)
    active: bool = True
    turns_since_referral: int = 0
    # آخرین الگویِ استفاده‌شده در هر لایه‌ی پاسخ -- تا responses.pick()
    # بتواند از تکرارِ فوریِ همان جمله در نوبتِ بعدی جلوگیری کند
    # (پارامترِ last_used از قبل در pick() وجود داشت اما تا این نسخه
    # هیچ‌جا واقعاً پاس داده نمی‌شد).
    last_reflection: Optional[str] = None
    last_question: Optional[str] = None

    def record_turn(self, emotion: str) -> None:
        self.turn_count += 1
        self.last_activity = time.time()
        self.emotion_history.append(emotion)
        self.emotion_history = self.emotion_history[-20:]
        self.turns_since_referral += 1
        if emotion == "neutral":
            self.consecutive_neutral += 1
        else:
            self.consecutive_neutral = 0
        if self.turn_count >= 7:
            self.stage = "deepening"
        elif self.turn_count >= 3:
            self.stage = "exploring"
        else:
            self.stage = "opening"

    def sustained_distress(self, min_turns: int = 4) -> bool:
        """آیا در چند نوبتِ اخیر (نه فقط همین پیام) پریشانیِ مداوم دیده شده؟
        برایِ تصمیمِ «آیا الان زمانِ خوبیه که پیشنهادِ مشاوره بدیم» استفاده می‌شود --
        نه بلافاصله در همان اولین پیامِ ناراحت‌کننده."""
        if len(self.emotion_history) < min_turns:
            return False
        recent = self.emotion_history[-min_turns:]
        distress = {"sad", "anxious", "lonely", "angry", "overwhelmed"}
        return sum(1 for e in recent if e in distress) >= min_turns - 1

    def is_expired(self) -> bool:
        return (time.time() - self.last_activity) > SESSION_TIMEOUT_SECONDS

    def is_effectively_active(self) -> bool:
        return (
            self.active
            and not self.is_expired()
            and self.consecutive_neutral < NEUTRAL_TURNS_TO_EXIT
        )


class TherapySessionManager:
    def __init__(self) -> None:
        self._sessions: Dict[str, TherapySession] = {}

    def get(self, session_id: str) -> TherapySession:
        s = self._sessions.get(session_id)
        if s is None or s.is_expired():
            s = TherapySession(session_id=session_id)
            self._sessions[session_id] = s
        return s

    def has_active(self, session_id: str) -> bool:
        s = self._sessions.get(session_id)
        return bool(s and s.is_effectively_active())

    def end(self, session_id: str) -> None:
        s = self._sessions.get(session_id)
        if s:
            s.active = False

    def get_if_exists(self, session_id: str) -> Optional[TherapySession]:
        return self._sessions.get(session_id)
