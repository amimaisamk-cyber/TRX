# -*- coding: utf-8 -*-
"""
TherapyCompanionEngine -- ماژولِ «همراهِ روان‌شناختی» در بخشِ پزشکی.

فلسفه‌ی طراحی (مهم -- لطفاً قبل از تغییر این فایل بخوانید):
    1. این یک درمانگرِ واقعی نیست و هرگز نباید وانمود کند که هست. هیچ‌جا
       تشخیصِ بالینی (مثلِ «شما افسردگی دارید») نمی‌دهد -- فقط بازتاب،
       اعتبارسنجی و همراهی می‌کند (سبکِ active listening).
    2. ایمنی همیشه اولویتِ اول است: هر پیام، حتی وسطِ یک جلسه‌ی همراهیِ
       عادی، از فیلترِ خودآسیبی/اورژانسِ فیزیکی رد می‌شود -- نه فقط در
       اولین پیام. به همین دلیل این چک اینجا هم تکرار می‌شود، نه فقط در
       online.py: مسیرِ «ادامه‌ی جلسه‌ی فعال» در core.py مستقیماً این
       تابع را صدا می‌زند و از لایه‌ی چکِ اورژانسیِ online.py رد نمی‌شود.
    3. هدف کمک به کاربر برایِ «بیرون‌ریختنِ تدریجیِ حرف» است، نه حل‌کردنِ
       فوریِ مشکل و نه بمباردمانِ او با سؤال. به همین دلیل لحن همیشه
       آرام و کم‌فشار است.
    4. پیشنهادِ مراجعه به متخصص فقط گاه‌به‌گاه و بعد از پریشانیِ *مداوم*
       مطرح می‌شود (نه در هر پیام) -- طبقِ session.sustained_distress().
"""

from __future__ import annotations

from typing import Optional

from ..redflags import check_emergency_redflags, check_self_harm_redflags
from . import emotions, responses
from .resources import CRISIS_MESSAGE_FA, CRISIS_REMINDER_FA, PROFESSIONAL_SUGGESTION_FA
from .session import TherapySessionManager

# نوبت‌هایی که باید بینِ دو پیشنهادِ مراجعه‌ی متخصص فاصله باشد -- تا
# پیامِ ثابت هر پیام تکرار نشود و آزاردهنده/رباتی به‌نظر نرسد.
REFERRAL_COOLDOWN_TURNS = 6


class TherapyCompanionEngine:
    def __init__(self) -> None:
        self.sessions = TherapySessionManager()

    # ------------------------------------------------------------------
    def has_active_session(self, session_id: str) -> bool:
        return self.sessions.has_active(session_id)

    def end_session(self, session_id: str) -> None:
        self.sessions.end(session_id)

    @staticmethod
    def looks_like_unrelated_command(text: str) -> bool:
        """اگر پیام واضحاً به یک قابلیتِ کاملاً دیگر اشاره دارد (ساعت،
        آب‌وهوا، محاسبه، ترجمه، ارز، جستجو، ...)، نباید جلسه‌ی همراهیِ
        فعال آن را ربوده و جوابِ نامربوط بدهد -- بگذار مسیریابیِ عادیِ
        نیت آن را پردازش کند. این فقط برایِ مسیرِ «ادامه‌ی جلسه‌ی فعال»ِ
        core.py استفاده می‌شود، نه برایِ تشخیصِ اولیه‌ی ورود به جلسه."""
        t = (text or "").lower().strip()
        if not t:
            return False
        hard_exit_markers = (
            "ساعت چنده", "ساعت چند", "آب و هوا", "آب‌وهوا", "هوای",
            "محاسبه", "چند میشه", "ترجمه کن", "دلار", "قیمت ارز",
            "سرچ کن", "جستجو کن", "یادآوری", "آلارم", "تایمر",
            "فایل بساز", "کد بنویس", "پاورپوینت", "اکسل",
        )
        return any(m in t for m in hard_exit_markers)

    # ------------------------------------------------------------------
    def respond(self, session_id: str, text: str) -> dict:
        session = self.sessions.get(session_id)

        # ۱. ایمنی همیشه اول -- مستقل از هر مرحله‌ی دیگرِ جلسه.
        self_harm_msg = check_self_harm_redflags(text)
        if self_harm_msg:
            session.record_turn("crisis")
            message = CRISIS_MESSAGE_FA if not session.crisis_shown else CRISIS_REMINDER_FA
            session.crisis_shown = True
            return {"status": "crisis", "message": message, "emergency": True, "stage": session.stage}

        physical_msg = check_emergency_redflags(text)
        if physical_msg:
            # این دیگر حوزه‌ی این ماژول نیست -- یک فوریتِ جسمی است.
            # همان پیامِ استانداردِ ایمنیِ پروژه (redflags.py) را برمی‌گردانیم
            # تا هیچ‌جا دو پیامِ متفاوت برایِ یک وضعیتِ اورژانسی وجود نداشته باشد.
            return {"status": "emergency", "message": physical_msg, "emergency": True, "stage": session.stage}

        # ۲. درخواستِ صریحِ پایانِ گفتگو
        if emotions.wants_to_end(text):
            self.end_session(session_id)
            closing = responses.pick(responses.CLOSING_MESSAGES)
            return {"status": "ok", "message": closing, "emergency": False, "stage": session.stage}

        # ۳. بازخوردِ صریحِ کاربر درباره‌ی تکراری‌بودنِ خودِ پاسخ‌ها -- باید
        # قبل از جریانِ عادیِ بازتاب/سؤال چک شود، وگرنه دقیقاً با یک
        # الگویِ کلیشه‌ایِ دیگر جواب داده می‌شود (مصداقِ همان شکایت).
        if emotions.is_repetition_feedback(text):
            session.record_turn("neutral")
            message = responses.pick(responses.REPETITION_ACKNOWLEDGMENT, session.last_reflection)
            session.last_reflection = message
            return {"status": "ok", "message": message, "emergency": False, "stage": session.stage}

        # ۴. تشخیصِ سبکِ احساس (فقط برایِ انتخابِ لحن، نه تشخیصِ بالینی)
        emotion = emotions.detect(text)
        session.record_turn(emotion)

        message = self._build_companion_reply(session, emotion)
        return {"status": "ok", "message": message, "emergency": False, "stage": session.stage}

    # ------------------------------------------------------------------
    def _build_companion_reply(self, session, emotion: str) -> str:
        reflection_pool = responses.REFLECTION_BY_EMOTION.get(emotion, responses.REFLECTION_BY_EMOTION["neutral"])
        reflection = responses.pick(reflection_pool, session.last_reflection)
        session.last_reflection = reflection

        parts = [reflection]

        if emotions.is_distress(emotion):
            parts.append(responses.pick(responses.VALIDATION))

        if emotion != "relief":
            question_pool = responses.OPEN_QUESTIONS_BY_STAGE.get(session.stage, responses.OPEN_QUESTIONS_BY_STAGE["opening"])
            question = responses.pick(question_pool, session.last_question)
            session.last_question = question
            parts.append(question)

        message = " ".join(parts)

        # تکنیکِ آرام‌سازیِ کوتاه فقط برایِ اضطراب/فشارِ شدید، و نه در هر پیام
        if emotion in {"anxious", "overwhelmed"} and session.turn_count % 3 == 0:
            message += responses.GROUNDING_TECHNIQUE

        # پیشنهادِ مراجعه‌ی تخصصی -- فقط گاه‌به‌گاه، بعد از پریشانیِ مداوم
        if (
            session.sustained_distress()
            and session.turns_since_referral >= REFERRAL_COOLDOWN_TURNS
        ):
            message += PROFESSIONAL_SUGGESTION_FA
            session.turns_since_referral = 0

        return message
