# -*- coding: utf-8 -*-
"""Medical application orchestrator; business logic lives in services."""
from __future__ import annotations
import re
from typing import Optional
from .config import MedicalConfig
from .router import MedicalRouter, Intent
from .safety.redflags import check_any_redflags, check_self_harm_redflags, check_emergency_redflags
from .safety.validator import validate_request
from .diagnosis.engine import DiagnosticEngine
from .dialogue import DialogueManager
from .medication import MedicationService, InteractionService
from .first_aid import FirstAidService
from .response import diagnostic_message, medication_message, generate_visit_summary, interaction_report
from . import formatting, online
from .knowledge import LocalKnowledge, KnowledgeRetriever, OnlineProvider
from .models import MedicalRequest, MedicalResponse
from .entities import extract_drug_name, extract_disease_name
from .safety.triage import assess_urgency
from .therapy import TherapyCompanionEngine
from .data.diseases import DISEASE_DB
from .data.medications import MEDICATION_DB
from .data.first_aid import FIRST_AID_GUIDES
from .data.health_topics import HEALTH_TOPICS

class MedicalAIEngine:
    """Stable public facade + thin orchestration layer."""
    SELF_HARM_REDFLAGS = __import__('trx_ai.medical.redflags', fromlist=['SELF_HARM_REDFLAGS']).SELF_HARM_REDFLAGS
    EMERGENCY_REDFLAGS = __import__('trx_ai.medical.redflags', fromlist=['EMERGENCY_REDFLAGS']).EMERGENCY_REDFLAGS
    # این دو (CONFIDENCE_GAP/CONFIDENCE_MIN) قبلاً روی MedicalAIEngine هم
    # اعداد مرده و با مقیاسِ اشتباه بودند (۲۰.۰/۸۰.۰ به‌جایِ ۰.۲۰/۰.۸۰)
    # و هیچ‌کجا خوانده نمی‌شدند. حالا مستقیم به self.config وصل شده‌اند
    # (نگاه کنید به __init__) تا مقدارِ واقعیِ در حالِ استفاده را نشان
    # دهند، نه یک ثابتِ کلاسیِ بی‌ربط.
    MAX_FOLLOWUP_QUESTIONS=7
    def __init__(self, config: Optional[MedicalConfig]=None):
        self.config=config or MedicalConfig()
        self.CONFIDENCE_MIN=self.config.confidence_min
        self.CONFIDENCE_GAP=self.config.confidence_gap
        self.disease_db=DISEASE_DB; self.medication_db=MEDICATION_DB
        self.symptom_to_condition={}
        for d,info in self.disease_db.items():
            for s in info.get('symptoms',[]): self.symptom_to_condition.setdefault(s.lower(),[]).append(d)
        self.router=MedicalRouter()
        self.diagnostics=DiagnosticEngine(self.disease_db,self.symptom_to_condition,self.config)
        self.dialogue=DialogueManager(self.diagnostics, self.config)
        self.medications=MedicationService(self.medication_db)
        self.interactions=InteractionService()
        self.first_aid=FirstAidService(FIRST_AID_GUIDES)
        self.therapy=TherapyCompanionEngine()
        self.knowledge=LocalKnowledge(DISEASE_DB,MEDICATION_DB,HEALTH_TOPICS,FIRST_AID_GUIDES)
        self.knowledge_retriever=KnowledgeRetriever(self.knowledge,OnlineProvider(),self.config.enable_online)
    @property
    def _dialogues(self): return self.dialogue._dialogues
    def _check_self_harm_redflags(self,text): return check_self_harm_redflags(text)
    def _check_emergency_redflags(self,text): return check_emergency_redflags(text)
    def _check_any_redflags(self,text): return check_any_redflags(text)
    def _parse_yes_no(self,text): return self.dialogue._parse_yes_no(text)
    def _extract_symptoms(self,text): return self.dialogue.extract_symptoms(text)
    def _rank_diseases(self,symptoms): return self.dialogue.rank_diseases(symptoms)
    def _generate_diagnostic_response(self,ranked_diseases,extracted_symptoms,original_text):
        if not ranked_diseases:
            urgency=assess_urgency([], {}, self.disease_db)
            msg="⚠️ شواهد کافی برای یک نتیجه مشخص وجود ندارد. لطفاً علائم، مدت و شدت را دقیق‌تر شرح دهید."
            if urgency.get("message"): msg += f"\n\n{urgency['message']}"
            return {"status":"unknown","sufficient":False,"message":msg,"symptoms_identified":extracted_symptoms,"urgency":urgency,"recommendation":"مراجعه به پزشک"}
        analysis=self.diagnostics.analyze(original_text)
        conf=analysis["confidence"]
        urgency=assess_urgency(ranked_diseases, analysis.get("extraction",{}), self.disease_db)
        msg=diagnostic_message(ranked_diseases,extracted_symptoms,self.disease_db,conf["level"],urgency=urgency)
        top=ranked_diseases[0]; info=self.disease_db[top['disease']]
        return {"status":"diagnosis","top_diagnosis":top['disease'],"confidence":conf["score"],"sufficient":conf["sufficient"],"match_score":top['score'],"uncertainty":conf["level"],"urgency":urgency,"message":msg,"symptoms_identified":extracted_symptoms,"ranked_diseases":ranked_diseases,"evidence":analysis["evidence"],"treatment":info.get('treatment',[]),"prevention":info.get('prevention',[]),"warning_signs":info.get('warning_signs',[]),"when_to_see_doctor":info.get('when_to_see_doctor',''),"recommendation":"مراجعه به پزشک برای ارزیابی قطعی"}
    def assess_urgency(self,text):
        """
        سطحِ فوریتِ مراجعه (امروز/طیِ چند روز/مراقبتِ خانگی) را بدونِ
        شروعِ گفتگویِ چندمرحله‌ای برمی‌گرداند -- برایِ نمایشِ سریع، مثلاً
        در کنارِ یک شاخصِ بصریِ رنگی در رابطِ کاربری.
        """
        emergency=self._check_any_redflags(text)
        if emergency:
            return {"level":"EMERGENCY","message":emergency,"rationale":["علامتِ هشدارِ فوریتی در متن شناسایی شد"]}
        analysis=self.diagnostics.analyze(text)
        return assess_urgency(analysis["ranked"], analysis.get("extraction",{}), self.disease_db)
    def analyze_symptoms(self,text):
        valid=validate_request(text,self.config.max_input_chars)
        if not valid.valid:return {"status":"error","error":valid.code,"message":"ورودی پزشکی معتبر نیست."}
        d=self.diagnostics.analyze(valid.sanitized)
        return self._generate_diagnostic_response(d['ranked'],d['symptoms'],valid.sanitized)
    def has_active_dialogue(self,k): return self.dialogue.has_active_dialogue(k)
    def cancel_dialogue(self,k): self.dialogue.cancel_dialogue(k)
    def start_symptom_check(self,k,text): return self.dialogue.start(k,text,self._generate_diagnostic_response)
    def answer_symptom_check(self,k,text): return self.dialogue.answer(k,text,self._generate_diagnostic_response)
    def get_medication_info(self,name): return self.medications.info(name)
    def get_disease_info(self,name): return self.knowledge.disease(name) if False else self._legacy_disease_info(name)
    def _legacy_disease_info(self,name):
        n=name.strip().lower()
        for k,info in self.disease_db.items():
            if n==k.lower(): return {"status":"found","disease":k,"info":info,"symptoms":info.get('symptoms',[]),"treatment":info.get('treatment',[]),"prevention":info.get('prevention',[]),"warning_signs":info.get('warning_signs',[]),"when_to_see_doctor":info.get('when_to_see_doctor','')}
        for k,info in self.disease_db.items():
            if n in k.lower() or k.lower() in n: return {"status":"found_similar","disease":k,"info":info,"suggested":name}
        return {"status":"not_found","message":f"❌ اطلاعاتی برای بیماری '{name}' یافت نشد."}
    def check_drug_interaction(self,a,b): return self.interactions.check(a,b)
    def check_drug_interactions(self,names):
        """
        بررسیِ تداخلِ داروییِ یک فهرستِ دلخواه از داروها (نه فقط دو تا)؛
        همه‌یِ زوج‌ها بررسی و از شدیدترین به خفیف‌ترین مرتب می‌شوند.
        """
        return self.interactions.check_many(names)
    def generate_visit_summary(self,text):
        """
        خلاصه‌یِ آماده برایِ نشان‌دادن به پزشک: علائمِ حاضر/غایب، شدت/شروع/
        مدت، کاندیدهایِ سامانه با سطحِ شواهد، و سطحِ فوریتِ پیشنهادی --
        همگی از همان تحلیلی که برایِ analyze_symptoms انجام می‌شود.
        """
        emergency=self._check_any_redflags(text)
        if emergency:
            return emergency
        analysis=self.diagnostics.analyze(text)
        urgency=assess_urgency(analysis["ranked"], analysis.get("extraction",{}), self.disease_db)
        return generate_visit_summary(analysis.get("extraction",{}), analysis["ranked"], urgency)
    def first_aid_advice(self,text): return self.first_aid.advice(text)
    def health_advice(self,question):
        q=question.lower().strip()
        for topic,val in HEALTH_TOPICS.items():
            if topic.lower() in q:return val
        return "💚 **توصیه‌های کلی سلامت:**\n\n• تغذیه متعادل\n• فعالیت بدنی منظم\n• خواب کافی\n• مدیریت استرس\n• معاینات منظم پزشکی\n\n⚠️ برای مشاوره تخصصی به پزشک مراجعه کنید."
    def handle_request(self, request: MedicalRequest) -> MedicalResponse:
        valid=validate_request(request.text,self.config.max_input_chars)
        if not valid.valid:return MedicalResponse(status="error",intent=Intent.GENERAL_MEDICAL.value,answer="ورودی پزشکی معتبر نیست.",warnings=[valid.code])
        text=valid.sanitized; emergency=self._check_any_redflags(text)
        if emergency:return MedicalResponse(status="emergency",intent=Intent.EMERGENCY.value,answer=emergency,warnings=["RED_FLAG"],emergency=True)
        # ادامه‌ی جلسه‌ی فعالِ همراهِ روان‌شناختی: دقیقاً همان دلیلِ core.py
        # (نگاه کنید به توضیحِ آنجا) -- بدونِ این خط، این facade هر پیام
        # را از نو با MedicalRouter مسیریابی می‌کرد و پیامِ دومِ یک گفتگویِ
        # «درد دل» (که معمولاً دیگر کلیدواژه‌ی احساسی ندارد) به پاسخِ
        # عمومیِ سلامت سقوط می‌کرد، نه ادامه‌ی همراهی.
        if self.therapy.has_active_session(request.session_id) and not self.therapy.looks_like_unrelated_command(text):
            r=self.therapy.respond(request.session_id, text)
            return MedicalResponse(status=r["status"],intent=Intent.EMOTIONAL_SUPPORT.value,answer=r["message"],emergency=r.get("emergency",False))
        intent=self.router.route(text)
        if intent==Intent.SYMPTOM_ANALYSIS.value:
            r=self.analyze_symptoms(text); return MedicalResponse(status=r.get("status","ok"),intent=intent,answer=r.get("message", ""),evidence=r.get("evidence",[]),uncertainty=r.get("uncertainty","UNKNOWN"),requires_followup=r.get("uncertainty") not in ("HIGH EVIDENCE",),data={k:v for k,v in r.items() if k not in ("message","evidence")})
        if intent==Intent.FIRST_AID.value:return MedicalResponse(intent=intent,answer=self.first_aid_advice(text))
        if intent==Intent.EMOTIONAL_SUPPORT.value:
            r=self.therapy.respond(request.session_id, text)
            return MedicalResponse(status=r["status"],intent=intent,answer=r["message"],emergency=r.get("emergency",False))
        if intent==Intent.MEDICATION_INFORMATION.value:
            # قبلاً اینجا و در online.py هرکدام یک regex مستقلِ کمی‌متفاوت
            # داشتند (یکی «آمپول» را نمی‌شناخت). حالا هر دو مسیر از همان
            # extract_drug_name واحد در entities.py استفاده می‌کنند.
            drug_name = extract_drug_name(text)
            if not drug_name:return MedicalResponse(intent=intent,answer="💊 لطفاً نام دارو را مشخص کنید.")
            r=self.get_medication_info(drug_name)
            ans=medication_message(r['drug'],r['info']) if r['status'] in ('found','found_similar') else r['message']
            return MedicalResponse(intent=intent,answer=ans,data=r)
        if intent==Intent.DRUG_INTERACTION.value:
            names=re.split(r'\s+(?:و|با)\s+',re.sub(r'^.*?تداخل(?: دارویی)?\s*','',text,flags=re.I).strip())
            names=[n for n in names if n.strip()]
            if len(names)<2:
                return MedicalResponse(intent=intent,answer="💊 نامِ حداقل دو دارو را برای بررسیِ تداخل مشخص کنید (مثال: «تداخل استامینوفن و ایبوپروفن و وارفارین»).")
            results=self.check_drug_interactions(names)
            return MedicalResponse(intent=intent,answer=interaction_report(names,results),data={"interactions":results})
        if intent==Intent.HEALTH_INFORMATION.value:
            disease_name = extract_disease_name(text)
            if disease_name:
                r=self.get_disease_info(disease_name)
                if r['status']!='not_found':
                    i=r['info']; return MedicalResponse(intent=intent,answer=f"📋 **{r['disease']}**\n\n**علائم:** {', '.join(i.get('symptoms',[]))}\n\n**زمان مراجعه:** {i.get('when_to_see_doctor','-')}",evidence=[e.__dict__ if hasattr(e,"__dict__") else e for e in self.knowledge_retriever.retrieve_disease(r['disease'])])
            return MedicalResponse(intent=intent,answer=self.health_advice(text))
        return MedicalResponse(intent=intent,answer=self.health_advice(text))
    def handle_medical_query(self,text): return self.handle_request(MedicalRequest(text)).answer
    async def _fetch_online_medical_info(self,query,session): return await online.fetch_online_medical_info(query,session)
    async def handle_medical_query_online(self,text,session,session_key='default'): return await online.handle_medical_query_online(self,text,session,session_key)
    async def format_medical_response_online(self,text,session,personality='دکتر کامل',session_key='default'):
        r=await self.handle_medical_query_online(text,session,session_key)
        if not r.get('done',True) or r.get('emergency'): return r
        # v25.5.8: کلیدِ "source" باید از r به خروجیِ نهایی هم منتقل شود --
        # وگرنه با شخصیتِ «دکتر کامل»، tool_router دیگر نمی‌توانست تشخیص
        # بدهد پاسخ واقعاً از موتورِ همراهیِ روان‌شناختی آمده یا فقط
        # health_advideِ عمومی بوده (همان باگِ اصلی، فقط از یک مسیرِ دیگر).
        return {"done":True,"message":formatting.format_response(r['message'],personality,online=True),"source":r.get("source")}
    def adaptive_questionnaire(self,text): return formatting.adaptive_questionnaire(text)
    def confidence_questions_needed(self,text): return formatting.confidence_questions_needed(text)
    def format_medical_response(self,text,personality='دکتر کامل'): return formatting.format_response(self.handle_medical_query(text),personality)
