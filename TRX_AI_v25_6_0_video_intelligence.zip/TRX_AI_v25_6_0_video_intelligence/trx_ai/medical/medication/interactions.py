# -*- coding: utf-8 -*-
"""
سرویسِ بررسیِ تداخلِ دارویی -- نسخه‌یِ ارتقایافته:

- داده از `data/interactions.py` می‌آید (نه هاردکد در همین فایل)، تا
  افزودنِ تداخلِ جدید فقط یک تغییرِ داده باشد، نه تغییرِ منطق.
- علاوه‌بر `check(a, b)`ِ قدیمی (که یک رشته برمی‌گرداند و برایِ
  سازگاریِ عقب‌رو حفظ شده)، حالا `check_pair` (خروجیِ ساختاریافته با
  سطحِ شدت) و `check_many([...])` (بررسیِ همه‌یِ زوج‌هایِ یک فهرستِ
  دلخواه از داروها، مرتب‌شده از شدیدترین به خفیف‌ترین) هم اضافه شده.
"""

from __future__ import annotations

import re
from typing import Dict, List

from ..data.interactions import DRUG_INTERACTIONS, SEVERITY_LABELS, SEVERITY_ORDER


def _norm(name: str) -> str:
    return re.sub(r"[\u200c\s]+", " ", (name or "").strip().lower())


class InteractionService:
    def __init__(self):
        self._index: Dict[frozenset, Dict[str, str]] = {
            frozenset(_norm(x) for x in pair): info for pair, info in DRUG_INTERACTIONS.items()
        }

    def check_pair(self, a: str, b: str) -> Dict[str, str]:
        """
        بررسیِ ساختاریافته‌یِ یک زوجِ دارو. همیشه یک نتیجه برمی‌گرداند --
        حتی اگر چیزی در پایگاه‌داده یافت نشود (severity="UNKNOWN")، چون
        نبودِ رکورد در پایگاه‌دادهِ محلیِ محدود به‌معنایِ «تداخل ندارد»
        نیست و باید صریحاً همین‌طور به کاربر گفته شود.
        """
        key = frozenset({_norm(a), _norm(b)})
        info = self._index.get(key)
        if info is None:
            return {
                "drug_a": a, "drug_b": b, "severity": "UNKNOWN",
                "severity_label": "نامشخص",
                "note": "تداخلِ مشخصی در پایگاه‌دادهِ محلی برایِ این دو دارو ثبت نشده؛ این نتیجه نبودِ تداخل را تضمین نمی‌کند.",
            }
        return {
            "drug_a": a, "drug_b": b,
            "severity": info["severity"],
            "severity_label": SEVERITY_LABELS.get(info["severity"], info["severity"]),
            "note": info["note"],
        }

    def check(self, a: str, b: str) -> str:
        """سازگاریِ عقب‌رو: همان امضایِ قدیمی، خروجیِ رشته‌ای شاملِ برچسبِ شدت."""
        r = self.check_pair(a, b)
        if r["severity"] == "UNKNOWN":
            return r["note"]
        return f"⚠️ شدتِ تداخل: {r['severity_label']}\n{r['note']}"

    def check_many(self, names: List[str]) -> List[Dict[str, str]]:
        """
        بررسیِ زوجیِ همه‌یِ داروهایِ فهرست‌شده (برایِ n>=2 دارو، نه فقط دو
        تا). نتیجه بر اساسِ شدت مرتب می‌شود (شدیدترین تداخل اول) تا در
        فهرستِ داروهای زیاد، مهم‌ترین هشدار از قلم نیفتد.
        """
        names = [n.strip() for n in (names or []) if n and n.strip()]
        seen_names, unique_names = set(), []
        for n in names:
            k = _norm(n)
            if k not in seen_names:
                seen_names.add(k)
                unique_names.append(n)

        results, seen_pairs = [], set()
        for i in range(len(unique_names)):
            for j in range(i + 1, len(unique_names)):
                key = frozenset({_norm(unique_names[i]), _norm(unique_names[j])})
                if key in seen_pairs:
                    continue
                seen_pairs.add(key)
                results.append(self.check_pair(unique_names[i], unique_names[j]))

        results.sort(key=lambda r: SEVERITY_ORDER.get(r["severity"], -1), reverse=True)
        return results
