import re
class MedicationService:
    def __init__(self, db): self.db=db
    @staticmethod
    def _norm(name): return re.sub(r"[\u200c\s]+"," ",(name or "").strip().lower())
    def info(self,name):
        n=self._norm(name)
        if n in {self._norm(k): k for k in self.db}:
            k=next(k for k in self.db if self._norm(k)==n); return {"status":"found","drug":k,"info":self.db[k],"source":"TRX AI local medication data"}
        for k,v in self.db.items():
            if n in self._norm(k) or self._norm(k) in n:
                return {"status":"found_similar","drug":k,"info":v,"suggested":name,"source":"TRX AI local medication data"}
        return {"status":"not_found","message":f"❌ اطلاعاتی برای داروی '{name}' یافت نشد."}
