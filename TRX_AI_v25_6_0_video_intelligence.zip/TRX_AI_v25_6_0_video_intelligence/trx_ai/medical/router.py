from enum import Enum
import re

class Intent(str, Enum):
    SYMPTOM_ANALYSIS="SYMPTOM_ANALYSIS"
    HEALTH_INFORMATION="HEALTH_INFORMATION"
    MEDICATION_INFORMATION="MEDICATION_INFORMATION"
    DRUG_INTERACTION="DRUG_INTERACTION"
    FIRST_AID="FIRST_AID"
    PREVENTION="PREVENTION"
    GENERAL_MEDICAL="GENERAL_MEDICAL"
    EMERGENCY="EMERGENCY"
    # همراهِ روان‌شناختی: پریشانیِ هیجانی/تنهایی/استرس *بدونِ* علامتِ
    # خودآسیبی صریح (آن حالت جداگانه و همیشه زودتر با EMERGENCY توسطِ
    # check_any_redflags گرفته می‌شود -- نگاه کنید به redflags.py).
    EMOTIONAL_SUPPORT="EMOTIONAL_SUPPORT"

# کلیدواژه‌هایی که نشان‌دهنده‌ی نیازِ همراهیِ روان‌شناختی‌اند، نه یک
# علامتِ جسمی. عمداً از کلیدواژه‌هایِ SYMPTOM_ANALYSIS (که بالاتر بررسی
# می‌شوند) جدا نگه داشته شده تا وقتی کسی «سردرد دارم» می‌گوید همچنان به
# مسیرِ تشخیصِ علائم برود، نه اینجا.
EMOTIONAL_SUPPORT_KEYWORDS = (
    "ناراحتم", "غمگینم", "دلم گرفته", "دلشکسته", "افسرده", "دپرس",
    "استرس دارم", "استرس", "اضطراب دارم", "اضطراب", "نگرانم", "دلشوره دارم", "دلشوره",
    "تنهام", "احساس تنهایی", "کسی رو ندارم",
    "عصبانی‌ام", "حرصم گرفته",
    "دیگه نمی‌تونم", "طاقت ندارم", "خسته‌ام از همه چی",
    "می‌خوام حرف بزنم", "درد دل کنم", "دلم یه همدم می‌خواد",
)

class MedicalRouter:
    """Intent-only router. It never diagnoses."""
    def route(self, text, emergency=False):
        if emergency: return Intent.EMERGENCY.value
        t=(text or "").lower()
        if any(x in t for x in ("کمک اولیه","سوختگی","شکستگی","غرق","مسمومیت","تشنج","خونریزی شدید")):
            return Intent.FIRST_AID.value
        if "تداخل" in t or re.search(r"(?:دارو|قرص).*(?:با|و).*(?:دارو|قرص)", t):
            return Intent.DRUG_INTERACTION.value
        if any(x in t for x in ("دارو","قرص","شربت","آمپول","دوز")):
            return Intent.MEDICATION_INFORMATION.value
        if any(x in t for x in ("پیشگیری","واکسن","سبک زندگی")):
            return Intent.PREVENTION.value
        if any(x in t for x in ("علائم","درد","تب","سرفه","گلودرد","تنگی نفس","سردرد","تهوع","سرگیجه","خستگی","اسهال","یبوست","تپش قلب","بیمار","حالم")):
            return Intent.SYMPTOM_ANALYSIS.value
        if any(x in t for x in ("بیماری","درمان","نشانه","چیست","اطلاعات","علت")):
            return Intent.HEALTH_INFORMATION.value
        if any(x in t for x in EMOTIONAL_SUPPORT_KEYWORDS):
            return Intent.EMOTIONAL_SUPPORT.value
        return Intent.GENERAL_MEDICAL.value
