# -*- coding: utf-8 -*-
"""
embedding_backend.py -- بارگذاریِ تنبل و **مشترکِ** مدلِ تعبیه‌سازیِ محلی.

قبلاً سه جایِ مختلفِ کد (``memory_store.VectorDatabase``،
``nlu/matchers/semantic.py``، و از این پس ``conversation_patterns.py``)
هرکدام قرار بود مدلِ ``sentence-transformers`` را جداگانه لود کنند --
یعنی سه‌بار مصرفِ حافظه و سه‌برابر زمانِ startup برایِ دقیقاً یک مدلِ
یکسان. این ماژول تنها نقطه‌یِ بارگذاری است؛ بقیه فقط از اینجا صدا
می‌زنند (همان اصلِ «یک منبعِ حقیقت» که در ``nlu/registry.py`` هم دنبال
شده).

کاملاً محلی و اختیاری: اگر ``sentence-transformers`` نصب نباشد،
``get_model()``/``encode()`` بی‌صدا ``None`` برمی‌گردانند و هر بخشی که
از این ماژول استفاده می‌کند باید (و در این پروژه می‌کند) به رفتارِ
قبلیِ خودش سقوط کند -- بدونِ اینترنت یا کلیدِ API در زمانِ اجرا.
"""

from __future__ import annotations

import base64

try:
    from .dependencies import SENTENCE_TRANSFORMER_AVAILABLE
except ImportError:  # pragma: no cover
    SENTENCE_TRANSFORMER_AVAILABLE = False

# مدلِ چندزبانه‌یِ سبک -- همان انتخابِ قبلیِ memory_store.py، عمداً
# دست‌نخورده نگه داشته شده تا کشِ محلیِ هاگینگ‌فیس (اگر از قبل دانلود
# شده) بینِ هر سه مصرف‌کننده مشترک بماند.
MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"

_model = None
_load_attempted = False


def get_model():
    """بارگذاریِ تنبل و یک‌باره‌یِ مدل برایِ کلِ برنامه. در نبودِ پکیج یا خطا: None."""
    global _model, _load_attempted
    if _load_attempted:
        return _model
    _load_attempted = True
    if not SENTENCE_TRANSFORMER_AVAILABLE:
        return None
    try:
        from sentence_transformers import SentenceTransformer

        _model = SentenceTransformer(MODEL_NAME)
    except Exception:  # pragma: no cover -- خطایِ لود نباید کلِ برنامه را بترکاند
        _model = None
    return _model


def is_available() -> bool:
    return get_model() is not None


def encode(texts):
    """
    ``texts``: یک رشته یا لیستی از رشته‌ها.
    خروجی: بردار/ماتریسِ numpy، یا ``None`` اگر مدل در دسترس نباشد یا
    ورودی خالی باشد.
    """
    model = get_model()
    if model is None:
        return None
    single = isinstance(texts, str)
    payload = [texts] if single else list(texts)
    payload = [t for t in payload if t and t.strip()]
    if not payload:
        return None
    import numpy as np

    vecs = np.asarray(model.encode(payload, convert_to_numpy=True))
    return vecs[0] if single else vecs


def cosine_sim(vec, matrix):
    """شباهتِ کسینوسیِ یک بردار ``(d,)`` با ماتریسِ ``(n, d)`` -> ``(n,)``."""
    import numpy as np

    v = vec / (np.linalg.norm(vec) + 1e-9)
    m = matrix / (np.linalg.norm(matrix, axis=1, keepdims=True) + 1e-9)
    return m @ v


def vector_to_str(vec) -> str:
    """فشرده‌سازیِ بردار برایِ ذخیره در دیتابیس/JSON (base64 از float32)."""
    import numpy as np

    return base64.b64encode(np.asarray(vec, dtype=np.float32).tobytes()).decode("ascii")


def str_to_vector(s: str):
    """معکوسِ ``vector_to_str``. ورودیِ نامعتبر -> ``None`` (بدونِ ترکاندنِ فراخوان)."""
    import numpy as np

    try:
        return np.frombuffer(base64.b64decode(s.encode("ascii")), dtype=np.float32)
    except Exception:
        return None
