# -*- coding: utf-8 -*-
"""
رمزنگاری/رمزگشاییِ متن با رمزِ عبور — قابلیتِ امنیتیِ که در درخواستِ
قبلی («فایل‌های مهم را رمزنگاری کند») وعده داده شده بود.

روش: Fernet (از کتابخانه‌ی cryptography؛ AES-128 در حالتِ CBC + HMAC
برای احراز اصالت) با کلیدی که از رمزِ عبورِ کاربر توسط PBKDF2-HMAC-SHA256
(۴۸۰٬۰۰۰ تکرار، طبقِ توصیه‌ی OWASP ۲۰۲۳) مشتق می‌شود.

نکته‌ی مهم: نمکِ (salt) تصادفی در ابتدای خروجیِ base64 ذخیره می‌شود تا
رمزگشایی با همان رمزِ عبور ممکن باشد؛ اگر cryptography نصب نباشد، این
قابلیت با پیامِ روشن غیرفعال می‌شود (نه کرش).
"""

from __future__ import annotations

import base64
import os
from typing import Optional

from .logging_config import get_logger

logger = get_logger(__name__)

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    logger.warning("cryptography نصب نیست؛ قابلیتِ رمزنگاریِ متن غیرفعال است.")

_SALT_SIZE = 16
_PBKDF2_ITERATIONS = 480_000


def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=_PBKDF2_ITERATIONS)
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def encrypt_text(plaintext: str, password: str) -> str:
    """
    متن را با رمزِ عبورِ داده‌شده رمزنگاری و به‌صورتِ یک رشته‌ی base64ِ
    قابلِ کپی‌کردن برمی‌گرداند (شاملِ salt، پس نیازی به ذخیره‌ی جداگانه
    نیست).
    """
    if not CRYPTO_AVAILABLE:
        raise RuntimeError("cryptography نصب نیست. نصب کنید: pip install cryptography")
    salt = os.urandom(_SALT_SIZE)
    key = _derive_key(password, salt)
    token = Fernet(key).encrypt(plaintext.encode("utf-8"))
    return base64.urlsafe_b64encode(salt + token).decode("ascii")


def decrypt_text(blob_b64: str, password: str) -> str:
    """
    خروجیِ encrypt_text را با همان رمزِ عبور رمزگشایی می‌کند. اگر رمزِ
    عبور اشتباه باشد یا متن دستکاری شده باشد، ValueError می‌دهد (نه
    یک متنِ اشتباهِ خاموش).
    """
    if not CRYPTO_AVAILABLE:
        raise RuntimeError("cryptography نصب نیست. نصب کنید: pip install cryptography")
    try:
        raw = base64.urlsafe_b64decode(blob_b64.encode("ascii"))
    except Exception as e:
        raise ValueError("متنِ رمزشده معتبر نیست (فرمتِ base64 اشتباه است).") from e

    salt, token = raw[:_SALT_SIZE], raw[_SALT_SIZE:]
    key = _derive_key(password, salt)
    try:
        plaintext = Fernet(key).decrypt(token)
    except InvalidToken as e:
        raise ValueError("رمزِ عبور اشتباه است یا متن دستکاری شده.") from e
    return plaintext.decode("utf-8")


def format_encrypt_response(plaintext: str, password: str) -> str:
    if not CRYPTO_AVAILABLE:
        return "❌ قابلیتِ رمزنگاری نصب نیست. نصب کنید: pip install cryptography"
    if not plaintext.strip():
        return "❌ متنی برای رمزنگاری داده نشد."
    if not password:
        return "❌ رمزِ عبور مشخص نشد."
    blob = encrypt_text(plaintext, password)
    return (
        f"🔒 متنِ رمزشده:\n`{blob}`\n\n"
        f"⚠️ این رمزِ عبور را جایی امن نگه دار — بدونش، رمزگشایی هرگز ممکن نیست."
    )


def format_decrypt_response(blob: str, password: str) -> str:
    if not CRYPTO_AVAILABLE:
        return "❌ قابلیتِ رمزنگاری نصب نیست. نصب کنید: pip install cryptography"
    if not blob.strip():
        return "❌ متنِ رمزشده‌ای داده نشد."
    try:
        plaintext = decrypt_text(blob.strip(), password)
        return f"🔓 متنِ اصلی:\n{plaintext}"
    except ValueError as e:
        return f"❌ {e}"


# ===========================================================================
#   رمزنگاریِ در سطحِ ذخیره‌سازی (encryption-at-rest) برایِ جدولِ profile
# ---------------------------------------------------------------------------
# تا پیش از این، توابعِ بالا فقط یک ابزارِ دستی بودند («این متن را با این
# رمزِ عبور رمزنگاری کن») و هرگز روی خودِ دیتابیسِ برنامه اعمال نمی‌شدند؛
# یعنی دفترچه‌ی سلامت، برنامه‌ی دارویی، حقایقِ شخصی (memory_correction) و
# بقیه‌ی جدولِ `profile` همیشه به‌صورتِ خام روی دیسک می‌نشستند.
#
# اینجا یک کلیدِ اصلیِ تصادفی (نه از رویِ رمزِ عبورِ کاربر، چون طبقِ
# انتخابِ کاربر قرار است خودکار و یک‌بار ذخیره شود، نه هر بار پرسیده
# شود) ساخته و در یک فایلِ جداگانه با مجوزِ محدود (0600 در سیستم‌عاملِ
# یونیکسی) نگه داشته می‌شود. `database.py` این کلید را می‌گیرد و مقدارِ
# ستونِ value را پیش از نوشتن رمزنگاری و پس از خواندن رمزگشایی می‌کند.
#
# ⚠️ محدودیتِ صادقانه: چون کلید کنارِ همان دستگاه ذخیره می‌شود، این روش
# در برابرِ کسی که کاملاً به فایل‌سیستمِ دستگاه دسترسی پیدا کند (هر دو
# فایل را بردارد) محافظت نمی‌کند؛ آنچه واقعاً متوقف می‌کند: خواندنِ
# تصادفی/غیرعمدیِ فایلِ دیتابیس (مثلاً در یک بکاپِ ابری، یک اشتراک‌گذاریِ
# اشتباهی، یا بازرسیِ سطحیِ فایل) — نه یک مهاجمِ مصمم با دسترسیِ کامل.
# ===========================================================================

_DB_KEY_FILE_ENV = "TRX_DB_KEY_PATH"
_DB_KEY_DEFAULT_PATH = "trx_ai_db.key"
_ENC_PREFIX = "enc:"  # نشانه‌ی مقادیرِ رمزشده، برای تشخیص از دادهٔ قدیمیِ خام


def _get_or_create_master_key(db_path: Optional[str] = None) -> Optional[bytes]:
    """کلیدِ اصلیِ (base64، مناسبِ Fernet) رمزنگاریِ در سطحِ ذخیره‌سازی را
    برمی‌گرداند؛ اگر وجود نداشته باشد، یک کلیدِ تصادفیِ تازه می‌سازد و با
    مجوزِ محدود ذخیره می‌کند. اگر cryptography نصب نباشد، None برمی‌گرداند
    (یعنی دیتابیس بدونِ رمزنگاری، مثلِ قبل، کار می‌کند).

    مسیرِ فایلِ کلید: اگر `TRX_DB_KEY_PATH` تنظیم شده باشد همان استفاده
    می‌شود؛ وگرنه اگر `db_path` داده شده باشد، کلید کنارِ همان فایلِ
    دیتابیس (`<db_path>.key`) ذخیره می‌شود تا هر دیتابیس کلیدِ خودش را
    داشته باشد (نه یک فایلِ کلیدِ سراسری و ثابت که همه‌ی نمونه‌های
    DatabaseManager -- حتی برایِ دیتابیس‌های کاملاً متفاوت -- را با هم
    شریک می‌کرد). فقط وقتی db_path هم داده نشود، مسیرِ ثابتِ قدیمی به‌عنوانِ
    آخرین راهِ‌حل استفاده می‌شود."""
    if not CRYPTO_AVAILABLE:
        return None
    env_path = os.environ.get(_DB_KEY_FILE_ENV)
    if env_path:
        path = env_path
    elif db_path:
        path = f"{db_path}.key"
    else:
        path = _DB_KEY_DEFAULT_PATH
    try:
        if os.path.exists(path):
            with open(path, "rb") as f:
                key = f.read().strip()
            if key:
                return key
        key = Fernet.generate_key()
        with open(path, "wb") as f:
            f.write(key)
        try:
            os.chmod(path, 0o600)  # فقط مالکِ فایل بتواند بخواند/بنویسد (در ویندوز نادیده گرفته می‌شود)
        except OSError as e:
            logger.debug("chmod روی فایلِ کلید شکست خورد (احتمالاً ویندوز/سیستم‌فایلِ ناسازگار): %s", e)
        logger.info("کلیدِ اصلیِ رمزنگاریِ دیتابیس تازه ساخته شد: %s", path)
        return key
    except OSError as e:
        logger.warning("ساخت/خواندنِ فایلِ کلیدِ دیتابیس ناموفق بود؛ دیتابیس رمزنگاری نمی‌شود: %s", e)
        return None


def encrypt_at_rest(plaintext: str, key: bytes) -> str:
    """رمزنگاریِ یک مقدار با کلیدِ اصلیِ دیتابیس (نه رمزِ عبورِ کاربر).
    خروجی با پیشوندِ «enc:» علامت‌گذاری می‌شود تا از داده‌ی قدیمیِ خام
    قابلِ‌تشخیص باشد."""
    token = Fernet(key).encrypt(plaintext.encode("utf-8"))
    return _ENC_PREFIX + token.decode("ascii")


def decrypt_at_rest(value: str, key: bytes) -> str:
    """اگر مقدار با «enc:» شروع شود رمزگشایی می‌کند؛ وگرنه همان‌طور که
    هست برمی‌گرداند (سازگاری با ردیف‌هایِ قدیمیِ رمزنشده‌ی پیش از این
    ارتقا — مهاجرت به‌صورتِ تنبل/lazy انجام می‌شود: با اولین بازنویسیِ
    همان کلید، رمزنگاری می‌شود)."""
    if not value.startswith(_ENC_PREFIX):
        return value
    try:
        plaintext = Fernet(key).decrypt(value[len(_ENC_PREFIX):].encode("ascii"))
        return plaintext.decode("utf-8")
    except InvalidToken:
        logger.warning("رمزگشاییِ یک مقدارِ دیتابیس ناموفق بود (کلید عوض شده؟)؛ مقدارِ خام برگردانده می‌شود.")
        return value

