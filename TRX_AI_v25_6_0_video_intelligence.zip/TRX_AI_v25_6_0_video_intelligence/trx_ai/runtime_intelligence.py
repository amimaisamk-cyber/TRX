# -*- coding: utf-8 -*-
"""TRX AI v25 — لایه‌ی Runtime Intelligence.

این ماژول یک لایه‌ی سبک و بدون وابستگی خارجی بین هسته و موتورهای مختلف
اضافه می‌کند: نرمال‌سازی ورودی، محدودیت context، تشخیص تکرار، و کنترل
کیفیت پاسخ. هدف این است که حتی وقتی API یا حافظه‌ی برداری در دسترس نیست،
رفتار سیستم پایدار و قابل پیش‌بینی بماند.
"""

from __future__ import annotations

import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Iterable, Optional


_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


def normalize_user_text(text: str, max_chars: int = 12000) -> str:
    """نرمال‌سازی امن و سبکِ متن بدون تغییر معنی."""
    if text is None:
        return ""
    text = str(text).translate(_FA_DIGITS).translate(_AR_DIGITS)
    text = text.replace("\u200c", "‌")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()[:max_chars]


def compact_text(text: str, max_chars: int) -> str:
    text = (text or "").strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 40].rstrip() + "\n…[context trimmed]"


@dataclass(frozen=True)
class RuntimeDecision:
    normalized: str
    duplicate: bool
    too_large: bool


class RuntimeIntelligence:
    """کنترل‌کننده‌ی سبک برای پایداری و کیفیت runtime."""

    def __init__(
        self,
        *,
        max_input_chars: int = 12000,
        history_items: int = 10,
        repeat_window_seconds: int = 20,
    ):
        self.max_input_chars = max_input_chars
        self.repeat_window_seconds = repeat_window_seconds
        self._recent = deque(maxlen=history_items)

    def inspect(self, text: str) -> RuntimeDecision:
        raw = "" if text is None else str(text)
        normalized = normalize_user_text(raw, self.max_input_chars)
        now = time.monotonic()
        # حذف موارد قدیمی
        while self._recent and now - self._recent[0][0] > self.repeat_window_seconds:
            self._recent.popleft()
        duplicate = bool(normalized) and any(item[1] == normalized for item in self._recent)
        if normalized:
            self._recent.append((now, normalized))
        return RuntimeDecision(
            normalized=normalized,
            duplicate=duplicate,
            too_large=len(raw) > self.max_input_chars,
        )

    @staticmethod
    def build_context(
        history: Iterable[object],
        memory_context: str = "",
        pattern_context: str = "",
        *,
        max_chars: int = 7000,
    ) -> str:
        """ساخت context فشرده؛ پاسخ‌های طولانی قدیمی کل پنجره را نمی‌بلعند."""
        parts = []
        if memory_context:
            parts.append("حافظه مرتبط:\n" + compact_text(memory_context, 2200))
        if pattern_context:
            parts.append("الگوی گفتگو:\n" + compact_text(pattern_context, 1800))

        history_lines = []
        for item in history:
            role = getattr(item, "role", "")
            content = compact_text(getattr(item, "content", ""), 900)
            if content:
                label = "کاربر" if role == "user" else "دستیار"
                history_lines.append(f"{label}: {content}")
        if history_lines:
            parts.append("تاریخچه اخیر:\n" + "\n".join(history_lines[-6:]))

        return compact_text("\n\n".join(parts), max_chars)

    @staticmethod
    def quality_check(answer: Optional[str], query: str) -> dict:
        """گیت ساده‌ی کیفیت؛ جایگزین داوری معنایی مدل نیست."""
        text = (answer or "").strip()
        issues = []
        if not text:
            issues.append("empty")
        if len(text) < 2:
            issues.append("too_short")
        if query and text == query.strip():
            issues.append("echo")
        if len(text) > 30000:
            issues.append("too_long")
        return {"ok": not issues, "issues": issues}
