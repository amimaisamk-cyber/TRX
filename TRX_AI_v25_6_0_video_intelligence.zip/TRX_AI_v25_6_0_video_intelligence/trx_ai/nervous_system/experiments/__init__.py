# -*- coding: utf-8 -*-
"""
Nervous System Experiments -- v25.5.7.

این زیرپکیج هیچ‌جا از ``conversation_engine.process`` یا هر مسیرِ
تولیدِ واقعی صدا زده نمی‌شود -- فقط یک ابزارِ *دستیِ* مهندسی است
(اجرا از طریقِ ``scripts/run_context_effect_experiment.py``) برایِ
سنجیدنِ اینکه آیا ``pattern_context`` واقعاً خروجیِ Local LLM را عوض
می‌کند یا نه. نگاه کنید به ``context_effect_experiment.py`` برایِ
جزئیاتِ کامل و خطِ قرمزهایِ توافق‌شده.
"""

from .context_effect_experiment import (
    ExperimentReport,
    ExperimentScenario,
    ScenarioResult,
    DEFAULT_SCENARIOS,
    run_experiment,
)

__all__ = [
    "ExperimentReport",
    "ExperimentScenario",
    "ScenarioResult",
    "DEFAULT_SCENARIOS",
    "run_experiment",
]
