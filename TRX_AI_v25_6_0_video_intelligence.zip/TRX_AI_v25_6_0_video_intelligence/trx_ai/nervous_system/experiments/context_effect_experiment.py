# -*- coding: utf-8 -*-
"""
Controlled Context Effect Experiment -- v25.5.7.

سندِ این نسخه دقیقاً پیامِ امیر است (چهار تصمیمِ قفل‌شده). خلاصه:

    Same Input, Same History, Same Model, Same Generation Config, Same Seed
        ├── pattern_context = REAL   → FULL    → Local LLM → Response A
        └── pattern_context = None   → REDUCED → Local LLM → Response B
    مقایسه‌ی A/B → Experimental Behavioral Diff Report

## خطوطِ قرمزِ توافق‌شده (رعایت‌شده در این فایل)

- **ADVISORY = کاملاً SHADOW.** هیچ‌کدام از ``full_response``/
  ``reduced_response`` وارد ``RoutingDecision`` یا پاسخِ نهاییِ کاربر
  نمی‌شوند. این ماژول هیچ‌جا از مسیرِ زنده (``conversation_engine.process``
  در تولید، یا ``core.py``) صدا زده نمی‌شود -- فقط یک اسکریپتِ دستی
  (``scripts/run_context_effect_experiment.py``) آن را اجرا می‌کند.
- **REDUCED دقیقاً همان FULL با یک تغییر.** ``ctx_reduced`` با
  ``dataclasses.replace`` از رویِ همان ``ctx_full`` واقعی ساخته می‌شود --
  فقط ``pattern_context["engine"]`` را ``None`` می‌کند؛ هیچ فیلدِ دیگری
  دست نمی‌خورد.
- **معیارِ عددی از قبل مشخص است**، نه بعد از دیدنِ نتیجه:
  ``exact_match``، ``similarity`` (نسبتِ ``difflib.SequenceMatcher``)،
  ``length_delta``. آستانه‌یِ «تفاوتِ رفتاری» (``_SIMILARITY_OBSERVED_THRESHOLD``)
  هم همین‌جا، پیش از اجرایِ هر آزمایشی، ثابت شده.
- **``semantic_difference`` همیشه ``"NOT_PROVEN"`` است.** این آزمایش
  هرگز ادعا نمی‌کند که TRX «معنیِ» یک الگو را فهمیده -- فقط اینکه
  خروجیِ متن عوض شده یا نه. تفکیکِ این دو دقیقاً همان چیزی است که امیر
  در بازبینیِ v25.5.6 خواست.
- **``core.py`` دست نخورد.** تنها فایل‌هایِ *موجودِ* تغییریافته:
  ``trx_model/interfaces.py`` و ``trx_model/llama_cpp_adapter.py``
  (فقط افزودنِ یک پارامترِ اختیاریِ ``seed``، پیش‌فرض ``None`` = دقیقاً
  رفتارِ قبلی) و ``trx_model/conversational_bridge.py`` (یک تابعِ
  عمومیِ جدید، ``get_adapter()``، بدونِ تغییرِ منطقِ موجود).
- **نمونه‌ها محدود و دستی‌اند** (``DEFAULT_SCENARIOS`` -- همان سه
  سناریویِ خودِ امیر)، نه اجرا رویِ مکالماتِ واقعیِ کاربر.
"""

from __future__ import annotations

import dataclasses
import difflib
import re
from typing import Optional

from ...conversation import conversation_engine, state_tracker
from .. import config as ns_config
from ..context_schema import UnifiedConversationContext
from ..coordinator import get_coordinator

_SIMILARITY_OBSERVED_THRESHOLD = 0.95

_BASE_SYSTEM_PROMPT = (
    "تو TRX AI هستی، یک دستیارِ هوشمندِ فارسی‌زبان. همیشه فقط و فقط به "
    "فارسیِ روان و طبیعی جواب بده. کوتاه، صادق و مفید باش."
)

_CONVERSATION_ID_PREFIX = "nervous_system_experiment"


@dataclasses.dataclass(frozen=True)
class ExperimentScenario:
    name: str
    recent_messages: tuple[str, ...]
    current_message: str


# دقیقاً سه سناریویی که خودِ امیر مشخص کرد.
DEFAULT_SCENARIOS: tuple[ExperimentScenario, ...] = (
    ExperimentScenario("joke_feedback", ("یه جوک بگو",), "چقدر بی‌مزه 😂"),
    ExperimentScenario("good_mood", ("حالم خیلی خوبه امروز",), "امروز واقعاً انرژی دارم"),
    ExperimentScenario("give_up", ("نمی‌دونم چی کار کنم",), "ولش کن، خودم یه کاری پیدا می‌کنم"),
)


@dataclasses.dataclass(frozen=True)
class ScenarioResult:
    scenario_name: str
    status: str  # "OK" | "ERROR" | "NO_CONTEXT"
    full_response: Optional[str] = None
    reduced_response: Optional[str] = None
    full_pattern_engine: Optional[dict] = None
    exact_match: Optional[bool] = None
    similarity: Optional[float] = None
    length_delta: Optional[int] = None
    behavioral_difference: Optional[str] = None  # "OBSERVED" | "NOT_OBSERVED"
    semantic_difference: Optional[str] = None  # always "NOT_PROVEN" when set
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


@dataclasses.dataclass(frozen=True)
class ExperimentReport:
    overall_result: str  # "PASS" | "INCONCLUSIVE" | "SKIPPED_NO_MODEL"
    scenarios: tuple[ScenarioResult, ...]
    generation_config: dict
    notes: tuple[str, ...]

    def to_dict(self) -> dict:
        return {
            "overall_result": self.overall_result,
            "scenarios": [s.to_dict() for s in self.scenarios],
            "generation_config": dict(self.generation_config),
            "notes": list(self.notes),
        }


def _normalize_for_diff(text: Optional[str]) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())


def _diff(full_text: str, reduced_text: str) -> dict:
    na, nb = _normalize_for_diff(full_text), _normalize_for_diff(reduced_text)
    exact = na == nb
    similarity = round(difflib.SequenceMatcher(None, na, nb).ratio(), 4)
    length_delta = abs(len(full_text or "") - len(reduced_text or ""))
    observed = (not exact) and similarity < _SIMILARITY_OBSERVED_THRESHOLD
    return {
        "exact_match": exact,
        "similarity": similarity,
        "length_delta": length_delta,
        "behavioral_difference": "OBSERVED" if observed else "NOT_OBSERVED",
        # هرگز چیزی جز این رشته -- نگاه کنید به توضیحِ بالایِ فایل.
        "semantic_difference": "NOT_PROVEN",
    }


def _format_pattern_block(engine: dict) -> str:
    """تبدیلِ خروجیِ pattern_bridge به یک خطِ متنیِ کوتاه برایِ system prompt.

    هیچ منطقِ جدیدی اضافه نمی‌کند -- فقط همان فیلدهایی که v25.5.6 از
    قبل تولید کرده بود (نوع/احساس/نیاز/کنش/آرک/جهتِ احساس/راهبرد) را
    به یک جمله‌یِ خوانا برایِ مدل تبدیل می‌کند.
    """
    parts = [
        f"نوع={engine.get('type')}",
        f"احساس={engine.get('emotion')}",
        f"نیاز={engine.get('need')}",
        f"کنش={engine.get('dialogue_act')}",
        f"روندِ گفتگو={engine.get('arc')}",
        f"جهتِ احساس={engine.get('sentiment_direction')}",
    ]
    strategy = engine.get("strategy")
    line = "[زمینه‌یِ مکالمه: " + "، ".join(parts) + "]"
    if strategy:
        line += f" راهبردِ پیشنهادی: {strategy}"
    return line


def _build_prompt_variant(ctx: UnifiedConversationContext, *, include_pattern: bool):
    """``(system_prompt, user_text, history)`` -- فقط ``system_prompt`` بینِ
    FULL/REDUCED فرق می‌کند؛ ``user_text``/``history`` همیشه یکسان‌اند
    (طبقِ خطِ قرمزِ «هیچ حذفِ دیگری انجام نمی‌دهیم»)."""

    history = [("user", m) for m in ctx.recent_history]
    system_prompt = _BASE_SYSTEM_PROMPT
    engine = ctx.pattern_context.get("engine") if include_pattern else None
    if engine:
        system_prompt = system_prompt + "\n" + _format_pattern_block(engine)
    return system_prompt, ctx.current_message, history


def _build_unified_context(scenario: ExperimentScenario) -> Optional[UnifiedConversationContext]:
    """FULL context واقعی را از طریقِ همان مسیرِ تولید (v25.5.5/۶) می‌سازد.

    فقط ``NervousSystemCoordinator`` را موقتاً (و امن) روشن می‌کند تا
    ``conversation_engine.process`` واقعاً یک ``UnifiedConversationContext``
    بسازد و ذخیره کند؛ در پایان فلگ را دقیقاً به همان مقدارِ قبلی
    برمی‌گرداند.

    **اصلاحِ دقیقِ عبارت (طبقِ بازبینیِ امیر، v25.5.7):** این یعنی
    ``No production behavioral effect`` -- یعنی هیچ تأثیری رویِ
    ``RoutingDecision``/پاسخِ نهاییِ تولید نمی‌گذارد -- **نه**
    ``No side effect``. صدازدنِ واقعیِ ``conversation_engine.process``
    عوارضِ جانبیِ واقعی دارد که این تابع پاک نمی‌کند:

    - ``conversation_logger.log_turn_decision`` یک خطِ لاگ واقعی
      می‌نویسد (فقط برایِ مشاهده/دیباگ، نه چیزی که خروجیِ تولید را
      عوض کند).
    - ``NervousSystemCoordinator`` خودِ این context را در بافرِ
      محدودِ درون‌حافظه‌اش نگه می‌دارد (تا اخراجِ LRU طبیعی).

    ``state_tracker.reset_snapshot`` فقط ContextSnapshotِ این
    conversation_id را پاک می‌کند -- نه این دو عارضه‌ی دیگر را.
    """
    conversation_id = f"{_CONVERSATION_ID_PREFIX}:{scenario.name}"
    state_tracker.reset_snapshot(conversation_id)
    previous_flag = ns_config.NERVOUS_SYSTEM_ENABLED
    ns_config.NERVOUS_SYSTEM_ENABLED = True
    try:
        conversation_engine.process(
            scenario.current_message,
            conversation_id=conversation_id,
            recent_messages=list(scenario.recent_messages),
        )
    finally:
        ns_config.NERVOUS_SYSTEM_ENABLED = previous_flag

    ctx_full = get_coordinator().get_latest(conversation_id)
    # ContextSnapshotِ این conversation_id را پاک می‌کند -- ولی خطِ لاگِ
    # already-written و کپیِ نگه‌داشته‌شده در Coordinator را حذف نمی‌کند
    # (نگاه کنید به docstring بالا: No production behavioral effect،
    # نه No side effect).
    state_tracker.reset_snapshot(conversation_id)
    return ctx_full


def run_experiment(
    scenarios: Optional[tuple[ExperimentScenario, ...]] = None,
    *,
    temperature: float = 0.0,
    max_new_tokens: int = 200,
    seed: int = 42,
) -> ExperimentReport:
    """اجرایِ کاملِ آزمایش -- fail-soft در سطحِ هر سناریو (یک سناریویِ
    خراب بقیه را متوقف نمی‌کند)، اما هرگز چیزی را در مسیرِ زنده اجرا
    نمی‌کند.
    """
    scenarios = scenarios or DEFAULT_SCENARIOS
    generation_config = {
        "temperature": temperature,
        "max_new_tokens": max_new_tokens,
        "seed": seed,
        "similarity_observed_threshold": _SIMILARITY_OBSERVED_THRESHOLD,
    }

    from ...trx_model import conversational_bridge

    adapter = conversational_bridge.get_adapter()
    if adapter is None:
        return ExperimentReport(
            overall_result="SKIPPED_NO_MODEL",
            scenarios=(),
            generation_config=generation_config,
            notes=(
                "Local LLM در دسترس نیست (llama-cpp-python نصب نیست یا "
                "TRX_LOCAL_LLM_MODEL_PATH تنظیم نشده) -- آزمایش اجرا نشد. "
                "این SKIPPED_NO_MODEL است، نه شکستِ آزمایش.",
            ),
        )

    results: list[ScenarioResult] = []
    for scenario in scenarios:
        try:
            ctx_full = _build_unified_context(scenario)
            if ctx_full is None:
                results.append(
                    ScenarioResult(
                        scenario_name=scenario.name,
                        status="NO_CONTEXT",
                        error="UnifiedConversationContext ساخته نشد (conversation_engine.process شکست خورد)",
                    )
                )
                continue

            ctx_reduced = dataclasses.replace(
                ctx_full,
                pattern_context={
                    **ctx_full.pattern_context,
                    "engine": None,
                    "long_term_pattern_wired": False,
                },
            )

            sp_full, ut_full, hist_full = _build_prompt_variant(ctx_full, include_pattern=True)
            sp_red, ut_red, hist_red = _build_prompt_variant(ctx_reduced, include_pattern=False)
            assert ut_full == ut_red and hist_full == hist_red, (
                "خطِ قرمز نقض شد: user_text/history باید بینِ FULL و REDUCED یکسان بمانند"
            )

            full_reply = adapter.chat(
                system_prompt=sp_full, user_text=ut_full, history=hist_full,
                max_new_tokens=max_new_tokens, temperature=temperature, seed=seed,
            )
            reduced_reply = adapter.chat(
                system_prompt=sp_red, user_text=ut_red, history=hist_red,
                max_new_tokens=max_new_tokens, temperature=temperature, seed=seed,
            )

            diff = _diff(full_reply, reduced_reply)
            results.append(
                ScenarioResult(
                    scenario_name=scenario.name,
                    status="OK",
                    full_response=full_reply,
                    reduced_response=reduced_reply,
                    full_pattern_engine=ctx_full.pattern_context.get("engine"),
                    **diff,
                )
            )
        except Exception as exc:  # noqa: BLE001 - یک سناریوی خراب بقیه را نمی‌شکند
            results.append(ScenarioResult(scenario_name=scenario.name, status="ERROR", error=str(exc)))

    ok_results = [r for r in results if r.status == "OK"]
    if any(r.behavioral_difference == "OBSERVED" for r in ok_results):
        overall = "PASS"
    elif ok_results:
        overall = "INCONCLUSIVE"
    else:
        overall = "SKIPPED_NO_MODEL" if not results else "INCONCLUSIVE"

    notes = (
        "PASS یعنی حداقل یک سناریو تفاوتِ قابلِ‌اندازه‌گیری نشان داد؛ "
        "به‌هیچ‌وجه یعنی TRX «معنیِ» الگو را فهمیده -- برایِ آن ادعا به "
        "یک آزمایشِ جداگانه (اثرِ رفتاریِ چندنوبتی) نیاز است.",
        "هیچ‌کدام از full_response/reduced_response وارد RoutingDecision "
        "یا پاسخِ نهاییِ تولید نشدند -- این آزمایش کاملاً SHADOW/ADVISORY است.",
    )
    return ExperimentReport(
        overall_result=overall, scenarios=tuple(results),
        generation_config=generation_config, notes=notes,
    )
