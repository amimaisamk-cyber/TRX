# -*- coding: utf-8 -*-
"""
``NervousSystemCoordinator`` -- بخشِ PHASE 2 سندِ v25.5.5.

طبقِ سند: «Coordinator فقط خروجی‌ها را جمع و استاندارد می‌کند» و «هیچ
ماژولِ موجود حذف یا ادغام نشود». این فایل هیچ تحلیلِ جدیدی انجام
نمی‌دهد -- فقط شیءهایِ از قبل محاسبه‌شده در
``conversation_engine.process`` (ContextSnapshot، EmotionReading،
IntentCandidate*، RoutingDecision، ...) را می‌گیرد و یک
``UnifiedConversationContext`` می‌سازد.

اصلِ پایداری (بخشِ «قانونِ عدمِ تخریب» سند): ``build_context`` هرگز
استثنا به بیرون پرتاب نمی‌کند. هر خطا بلعیده می‌شود و ``None``
برمی‌گردد -- دقیقاً هم‌الگو با ``conversation_engine._observe_phase3_shadow``.

وضعیتِ فعلی: **SHADOW**. ``record()`` فقط داخلِ حافظه ذخیره می‌کند؛ هیچ
فراخوانی‌ای در مسیرِ تصمیم‌گیری (``intent_arbitrator``/``action_gate``)
مقدارِ این کلاس را نمی‌خواند. اتصالِ واقعی (Local LLM مصرف‌کننده‌یِ
``UnifiedConversationContext`` باشد) طبقِ PHASE 3 سند، در نسخه‌یِ بعدی
انجام می‌شود.
"""

from __future__ import annotations

import threading
from collections import OrderedDict, deque
from typing import Deque, Iterable, Optional

from ..logging_config import get_logger
from . import config
from .context_schema import UnifiedConversationContext

logger = get_logger(__name__)

# فهرستِ ماژول‌هایِ واقعاً مصرف‌شده برایِ ساختِ هر UnifiedConversationContext --
# طبقِ زنجیره‌یِ ثابتِ ``conversation_engine.process`` (نگاه کنید به
# audit/module_status.md برایِ جزئیاتِ هر ردیف).
_SOURCE_MODULES: tuple[str, ...] = (
    "normalizer",
    "context_manager",
    "state_tracker",
    "emotion_analyzer",
    "topic_tracker",
    "continuity_analyzer",
    "intent_candidates",
    "ambiguity_manager",
    "intent_arbitrator",
    "action_gate",
    "response_critic",
    # v25.5.6 -- زیرمجموعه‌یِ stateless (نگاه کنید به pattern_bridge.py).
    "conversation_patterns.ConversationPatternEngine.build_pattern",
)


def _truncate(text: str, max_chars: int) -> str:
    text = text or ""
    if len(text) <= max_chars:
        return text
    return text[: max(0, max_chars - 1)] + "…"


class NervousSystemCoordinator:
    """جمع‌کننده‌ی fail-soft خروجیِ ماژول‌هایِ عصبی -- بدونِ تصمیم‌گیری."""

    def __init__(
        self,
        *,
        history_maxlen: int | None = None,
        max_conversations: int | None = None,
    ) -> None:
        self._history_maxlen = history_maxlen or config.CONTEXT_HISTORY_MAXLEN
        self._max_conversations = max_conversations or config.MAX_TRACKED_CONVERSATIONS
        self._lock = threading.Lock()
        # OrderedDict برایِ eviction به‌شیوه‌ی LRU وقتی تعدادِ
        # گفتگوهایِ ردیابی‌شده از سقف رد شود -- جلوگیری از نشتِ حافظه.
        self._by_conversation: "OrderedDict[str, Deque[UnifiedConversationContext]]" = OrderedDict()

    # ------------------------------------------------------------------
    #  ساخت (بدونِ ذخیره)
    # ------------------------------------------------------------------
    def build_context(
        self,
        *,
        conversation_id: str,
        raw_text: str,
        recent_messages: Iterable[str] | None,
        snapshot,  # ContextSnapshot (بعدِ به‌روزرسانیِ همین نوبت)
        emotion,  # EmotionReading
        relation,  # TopicRelation
        continuity_score: float,
        candidates,  # tuple[IntentCandidate, ...]
        decision,  # RoutingDecision (نهایی، بعدِ critic)
        critic_flags: Iterable[str] = (),
        long_term_snippets=None,  # tuple[ContextFragment, ...] یا None
        turn_latency_ms: float = 0.0,
        pattern_engine_context: dict | None = None,  # v25.5.6 -- خروجیِ pattern_bridge.build_pattern_context
    ) -> Optional[UnifiedConversationContext]:
        try:
            top_candidates = tuple(
                (c.name, round(float(c.score), 3)) for c in (candidates or ())
            )
            critic_flags_t = tuple(critic_flags or ())

            requires_tool = bool(getattr(decision, "route", None) == "tool")
            tool_hint = decision.selected_intent if requires_tool else None

            detected_feedback = bool(
                getattr(decision, "selected_intent", None) == "feedback"
                or any(name == "feedback" for name, _ in top_candidates)
            )

            memory_fragments = tuple(
                _truncate(getattr(frag, "text", ""), config.MEMORY_FRAGMENT_MAX_CHARS)
                for frag in (long_term_snippets or ())
                if getattr(frag, "text", None)
            )

            user_state = {
                "active_topic": getattr(snapshot, "active_topic", None),
                "conversation_mode": getattr(snapshot, "conversation_mode", "casual"),
                "user_goal": getattr(snapshot, "user_goal", None),
                "unanswered_question": getattr(snapshot, "unanswered_question", None),
                "frustration_score": getattr(snapshot, "frustration_score", 0.0),
                "ambiguity_streak": getattr(snapshot, "ambiguity_streak", 0),
                "corrected_topic_locked": getattr(snapshot, "corrected_topic_locked", False),
            }

            emotional_state = {
                "emotion": getattr(emotion, "emotion", "neutral"),
                "intensity": getattr(emotion, "intensity", 0.0),
                "previous_emotion": getattr(emotion, "previous_emotion", None),
                "mixed_emotion": getattr(emotion, "mixed_emotion", False),
                "known_cause": getattr(emotion, "known_cause", None),
            }

            pattern_context = {
                "continuity_score": continuity_score,
                "candidates": top_candidates,
                "critic_flags": critic_flags_t,
                # v25.5.6: خروجیِ واقعیِ ConversationPatternEngine.build_pattern
                # (زیرمجموعه‌یِ stateless -- نگاه کنید به pattern_bridge.py).
                # None اگر متن خیلی کوتاه بود یا موتور شکست خورد (fail-soft).
                "engine": pattern_engine_context,
                # تاریخچه‌یِ چندنشستیِ DB-backed (mood_report، فرکانسِ امضا
                # در طولِ زمان) هنوز وصل نیست -- گپِ باقی‌مانده‌یِ صادقانه؛
                # نگاه کنید به audit/module_status.md.
                "long_term_pattern_wired": pattern_engine_context is not None,
            }

            ctx = UnifiedConversationContext(
                conversation_id=conversation_id,
                current_message=raw_text or "",
                recent_history=tuple(recent_messages or ()),
                intent=getattr(decision, "selected_intent", "unknown"),
                intent_confidence=float(getattr(decision, "confidence", 0.0)),
                user_state=user_state,
                emotional_state=emotional_state,
                conversation_type=getattr(snapshot, "conversation_mode", "casual"),
                relation_to_previous=getattr(relation, "value", str(relation)),
                detected_feedback=detected_feedback,
                memory_context=memory_fragments,
                pattern_context=pattern_context,
                requires_tool=requires_tool,
                tool_hint=tool_hint,
                confidence=float(getattr(decision, "confidence", 0.0)),
                source_modules=_SOURCE_MODULES,
                turn_latency_ms=float(turn_latency_ms),
            )
            return ctx
        except Exception as exc:  # noqa: BLE001 - قانونِ عدمِ تخریب
            logger.debug("NervousSystemCoordinator.build_context شکست خورد: %s", exc)
            return None

    # ------------------------------------------------------------------
    #  ذخیره + دسترسی (برایِ مصرف‌کننده‌یِ آینده -- PHASE 3)
    # ------------------------------------------------------------------
    def record(self, ctx: Optional[UnifiedConversationContext]) -> None:
        if ctx is None:
            return
        try:
            with self._lock:
                bucket = self._by_conversation.get(ctx.conversation_id)
                if bucket is None:
                    bucket = deque(maxlen=self._history_maxlen)
                    self._by_conversation[ctx.conversation_id] = bucket
                else:
                    # move_to_end برایِ رفتارِ LRU
                    self._by_conversation.move_to_end(ctx.conversation_id)
                bucket.append(ctx)

                while len(self._by_conversation) > self._max_conversations:
                    self._by_conversation.popitem(last=False)
        except Exception as exc:  # noqa: BLE001 - قانونِ عدمِ تخریب
            logger.debug("NervousSystemCoordinator.record شکست خورد: %s", exc)

    def get_latest(self, conversation_id: str) -> Optional[UnifiedConversationContext]:
        with self._lock:
            bucket = self._by_conversation.get(conversation_id)
            if not bucket:
                return None
            return bucket[-1]

    def get_history(self, conversation_id: str) -> tuple[UnifiedConversationContext, ...]:
        with self._lock:
            bucket = self._by_conversation.get(conversation_id)
            return tuple(bucket) if bucket else ()

    def tracked_conversation_count(self) -> int:
        with self._lock:
            return len(self._by_conversation)


# ----------------------------------------------------------------------
#  Singleton -- هم‌الگو با ``phase3.shadow.get_shadow_runner``
# ----------------------------------------------------------------------
_coordinator_lock = threading.Lock()
_coordinator_instance: Optional[NervousSystemCoordinator] = None


def get_coordinator() -> NervousSystemCoordinator:
    global _coordinator_instance
    if _coordinator_instance is None:
        with _coordinator_lock:
            if _coordinator_instance is None:
                _coordinator_instance = NervousSystemCoordinator()
    return _coordinator_instance
