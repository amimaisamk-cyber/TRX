# -*- coding: utf-8 -*-
"""
Pattern Bridge -- v25.5.6، بستنِ گپِ صریحاً مستندشده در
``audit/module_status.md`` (v25.5.5): «``ConversationPatternEngine``
هنوز به Coordinator وصل نیست».

این فایل ``ConversationPatternEngine`` را دوباره پیاده‌سازی نمی‌کند --
فقط زیرمجموعه‌یِ **stateless** آن (``build_pattern`` -- یک
``@classmethod`` که فقط رویِ ``turns`` کار می‌کند، بدونِ نیاز به DB/
``self``) را صدا می‌زند. طبقِ خودِ کامنتِ کد در
``trx_ai/conversation_patterns.py`` (بالایِ ``build_pattern``):
«build_pattern عمداً یک متدِ stateless می‌ماند».

## چرا فقط بخشِ stateless، نه کلِ Engine؟

نمونه‌یِ *واقعیِ* production (``ai.conversation_patterns``، یک
``ConversationPatternEngine(db)``) در سطحِ اپلیکیشن (``core.py``) ساخته
می‌شود، نه در ``conversation_engine.process()``. اتصالِ کاملِ آن
(``observe``, ``mood_report``, ``relevant`` -- که به DB نیاز دارند)
یعنی عبورِ یک شیءِ جدید از لایه‌هایِ بالاتر تا اینجا -- یک تغییرِ بزرگ‌تر
که با هدفِ صریحِ v25.5.6 («این نسخه را کوچک نگه دار») در تضاد است.

بخشِ stateless دقیقاً همان چیزی است که v25.5.6 لازم دارد: طبقه‌بندیِ
واقعیِ Engine (نوع/احساس/نیاز/کنش/آرک/جهتِ احساس/امضا) رویِ همین چند
نوبتِ اخیر -- بدونِ نیاز به حافظه‌یِ بلندمدت یا DB.

## گپِ باقی‌مانده (صادقانه، نه پنهان)

تاریخچه‌یِ چندنشستی (``mood_report``، فرکانسِ امضا در طولِ زمان،
utterance patterns ذخیره‌شده در DB) هنوز وصل نیست. نگاه کنید به
``audit/module_status.md`` ردیفِ به‌روزشده‌یِ v25.5.6.
"""

from __future__ import annotations

from typing import Iterable, Optional

from ..conversation_patterns import ConversationPatternEngine
from ..logging_config import get_logger
from . import config

logger = get_logger(__name__)

# فیلدهایی از خروجیِ build_pattern که وارد pattern_context می‌شوند --
# عمداً بدونِ ``emb``/``context_emb`` (بردارهایِ عددیِ خام -- طبقِ اصلِ
# Memory سندِ Critical Audit: «Memory زیاد = هوشمندی بیشتر نیست»، اینجا
# هم فقط برچسب‌هایِ خوانا نگه داشته می‌شوند، نه دیتایِ عددیِ سنگین).
_SUMMARY_KEYS = (
    "type",
    "emotion",
    "dialogue_act",
    "need",
    "arc",
    "sentiment_direction",
    "negation",
    "signature",
    "confidence",
    "strategy",
)

_MAX_TOPICS = 6
_MAX_SIGNALS = 3


def _summarize(pattern: dict) -> dict:
    summary = {k: pattern.get(k) for k in _SUMMARY_KEYS}
    summary["topics"] = list(pattern.get("topics") or ())[:_MAX_TOPICS]
    summary["signals"] = [
        s[: config.MEMORY_FRAGMENT_MAX_CHARS] for s in (pattern.get("signals") or ())[-_MAX_SIGNALS:]
    ]
    return summary


def build_pattern_context(
    current_message: str,
    recent_messages: Iterable[str] | None = None,
    *,
    turns: list[dict] | None = None,
) -> Optional[dict]:
    """خلاصه‌یِ واقعیِ ``ConversationPatternEngine.build_pattern`` -- fail-soft.

    دو حالت:

    - ``turns`` داده نشده (مسیرِ واقعیِ فعلیِ ``conversation_engine.process``):
      ``recent_messages`` (که طبقِ خودِ
      ``ConversationPatternEngine._recent_context_text`` همیشه فقط
      گفته‌هایِ *کاربر* است -- نگاه کنید به کامنتِ آن تابع) + پیامِ فعلی،
      همه با role="user" ساخته می‌شوند.
    - ``turns`` صریحاً داده شده (برایِ آزمایش/مصرف‌کننده‌ای که تاریخچه‌یِ
      نقش‌دار -- user/assistant -- را از قبل دارد): همان استفاده می‌شود.

    هرگز استثنا بیرون نمی‌دهد -- در خطا یا نبودِ داده‌یِ کافی، ``None``.
    """
    try:
        if turns is None:
            built_turns: list[dict] = [
                {"role": "user", "content": m} for m in (recent_messages or ())
            ]
            built_turns.append({"role": "user", "content": current_message})
        else:
            built_turns = list(turns)

        pattern = ConversationPatternEngine.build_pattern(built_turns, source="local")
        if not pattern:
            return None
        return _summarize(pattern)
    except Exception as exc:  # noqa: BLE001 - قانونِ عدمِ تخریب v25.5.5/۶
        logger.debug("Pattern Bridge شکست خورد: %s", exc)
        return None
