# -*- coding: utf-8 -*-
"""
``UnifiedConversationContext`` -- قراردادِ خروجیِ Nervous System
Coordinator (بخشِ PHASE 2 سندِ v25.5.5).

این دیتاکلاس صرفاً *شکلِ داده* است -- درست مثلِ الگویِ
``trx_ai/conversation/schemas.py`` -- و هیچ منطقی ندارد. فیلدهایش
دقیقاً همان فهرستِ حداقلیِ سند هستند (بخشِ «UnifiedConversationContext
باید حداقل شامل...»)، به‌علاوه‌یِ چند فیلدِ ردیابی/اشکال‌زدایی
(``built_at``, ``turn_latency_ms``) که خودِ سند هم به‌عنوانِ بخشی از
اصلِ «پایداری/قابلِ‌ارزیابی‌بودن» در جاهایِ دیگر (مثلاً PHASE 6:
Behavioral Benchmark) لازم می‌داند.

نکته‌یِ مهم: این کلاس *جایگزینِ* ``ContextSnapshot`` /
``EmotionReading`` / ``RoutingDecision`` موجود در
``trx_ai/conversation/schemas.py`` نیست -- طبقِ نکته‌یِ صریحِ سند:
«Coordinator نباید خودش جایگزینِ ماژول‌هایِ تخصصی شود؛ فقط
Mediator/Coordinator است.» ``UnifiedConversationContext`` فقط یک
نمایِ خلاصه و استانداردشده از همان خروجی‌هایِ موجود است.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass(frozen=True)
class UnifiedConversationContext:
    """برشِ استانداردشده‌ی یک نوبتِ مکالمه -- خروجیِ Coordinator.

    فیلدها دقیقاً هم‌نامِ فهرستِ سندِ v25.5.5 هستند تا نگاشت بینِ سند و
    کد بدونِ ابهام باشد.
    """

    # --- هویتِ نوبت ---
    conversation_id: str = "default"
    current_message: str = ""
    recent_history: tuple[str, ...] = ()

    # --- نیت ---
    intent: str = "unknown"
    intent_confidence: float = 0.0

    # --- وضعیتِ کاربر/احساس ---
    # user_state: خلاصه‌یِ ساختاریِ ContextSnapshot (موضوعِ فعال، حالتِ
    # مکالمه، هدفِ کاربر، frustration_score، ambiguity_streak، ...).
    user_state: dict = field(default_factory=dict)
    # emotional_state: خلاصه‌یِ EmotionReading (احساس، شدت، علتِ شناخته‌شده، ...).
    emotional_state: dict = field(default_factory=dict)

    conversation_type: str = "casual"
    relation_to_previous: str = "unrelated"
    detected_feedback: bool = False

    # --- Memory / Pattern ---
    # memory_context: فقط متنِ کوتاه‌شده‌یِ قطعاتِ حافظه‌یِ بلندمدتِ
    # مرتبط (نه دامپِ خام -- طبقِ اصلِ Memory سندِ Critical Audit).
    memory_context: tuple[str, ...] = ()
    # pattern_context: خلاصه‌یِ سیگنال‌هایِ الگو/پیوستگیِ همین نوبت
    # (continuity_score، نامزدهایِ intent، و از v25.5.6: ``engine`` --
    # خلاصه‌یِ واقعیِ ConversationPatternEngine.build_pattern، زیرمجموعه‌یِ
    # stateless آن -- نگاه کنید به pattern_bridge.py). تاریخچه‌یِ
    # چندنشستیِ DB-backed (mood_report و مانند آن) هنوز وصل نیست --
    # نگاه کنید به audit/module_status.md، ردیفِ conversation_patterns.
    pattern_context: dict = field(default_factory=dict)

    # --- ابزار ---
    requires_tool: bool = False
    tool_hint: str | None = None

    # --- اطمینانِ کلی و ردیابی ---
    confidence: float = 0.0
    source_modules: tuple[str, ...] = ()
    built_at: float = field(default_factory=time.time)
    turn_latency_ms: float = 0.0

    def to_dict(self) -> dict:
        """نمایِ ساده برایِ لاگ/سریال‌سازی (بدونِ افشایِ داده‌یِ اضافی)."""

        return {
            "conversation_id": self.conversation_id,
            "current_message": self.current_message,
            "recent_history": list(self.recent_history),
            "intent": self.intent,
            "intent_confidence": self.intent_confidence,
            "user_state": dict(self.user_state),
            "emotional_state": dict(self.emotional_state),
            "conversation_type": self.conversation_type,
            "relation_to_previous": self.relation_to_previous,
            "detected_feedback": self.detected_feedback,
            "memory_context": list(self.memory_context),
            "pattern_context": dict(self.pattern_context),
            "requires_tool": self.requires_tool,
            "tool_hint": self.tool_hint,
            "confidence": self.confidence,
            "source_modules": list(self.source_modules),
            "built_at": self.built_at,
            "turn_latency_ms": self.turn_latency_ms,
        }
