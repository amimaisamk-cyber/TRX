# -*- coding: utf-8 -*-
"""
Runtime Influence Audit -- بخشِ PHASE 1 سندِ v25.5.5.

سندِ v25.5.5 آزمایشِ اصلی را این‌طور تعریف می‌کند:

    «اگر خروجی این ماژول را حذف کنم، رفتار TRX تغییر می‌کند؟»

    FUNCTIONAL  -- خروجی واقعاً روی تصمیم/پاسخ نهایی اثر دارد.
    DECORATIVE  -- خروجی خوانده می‌شود اما عملاً تصمیم را تغییر نمی‌دهد.
    ORPHAN      -- خروجی تولید می‌شود ولی مصرف‌کننده‌ی مؤثری ندارد.

این فایل دو چیز می‌دهد:

1. ``classify_coordinator_influence()`` -- یک خوداظهاریِ صادقانه‌ی
   Runtime دربابِ خودِ Nervous System Coordinator: در نسخه‌ی فعلی
   (SHADOW)، هیچ مسیرِ تصمیم‌گیری‌ای (``intent_arbitrator``,
   ``action_gate``, ``ToolRouter``) مقدارِ ``UnifiedConversationContext``
   را نمی‌خواند -- پس این خودِ طبقه‌بندیِ سند («ORPHAN») است، نه یک ادعایِ
   «متصل شد» که واقعیت نداشته باشد. این تابع دقیقاً همان چیزی را
   برمی‌گرداند که audit/module_status.md مستند کرده -- تا کد و سند
   هرگز از هم جدا نیفتند.

2. ``assert_non_interference()`` -- ابزارِ کمکیِ تست: می‌گیرد یک
   RoutingDecision که *بدونِ* Coordinator ساخته شده و یکی که *با*
   Coordinator (کلیدِ محیطی روشن) ساخته شده، و تأیید می‌کند کاملاً
   یکسان‌اند. این همان معیارِ ایمنیِ مرحله‌ی SHADOW است: تا وقتی
   مصرف‌کننده‌ای وصل نشده، خروجیِ نهایی نباید حتی یک بیت تغییر کند.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class InfluenceReport:
    module: str
    status: str  # "LIVE" | "STUB" | "PLANNED"
    influence: str  # "FUNCTIONAL" | "DECORATIVE" | "ORPHAN"
    reason: str


def classify_coordinator_influence() -> InfluenceReport:
    """خوداظهاریِ صادقانه‌ی وضعیتِ فعلی -- نگاه کنید به docstring بالا."""

    return InfluenceReport(
        module="nervous_system.coordinator",
        status="LIVE",
        influence="ORPHAN",
        reason=(
            "UnifiedConversationContext ساخته و ذخیره می‌شود، اما هیچ "
            "مسیرِ تصمیم‌گیری‌ای (intent_arbitrator/action_gate/ToolRouter/"
            "Local LLM) هنوز آن را نمی‌خواند. طبقِ PHASE 8 سند، این دقیقاً "
            "مرحله‌یِ SHADOW است -- ORPHAN بودن در این مرحله انتظار می‌رود، "
            "نه یک نقص. اتصالِ واقعی (تبدیل به FUNCTIONAL) در PHASE 3 "
            "(Local LLM) انجام می‌شود."
        ),
    )


def classify_pattern_engine_wiring() -> InfluenceReport:
    """خوداظهاریِ صادقانه‌ی وضعیتِ اتصالِ ConversationPatternEngine (v25.5.6).

    نه ORPHAN کامل (خروجیِ واقعیِ ``build_pattern`` حالا در
    ``pattern_context["engine"]`` ذخیره می‌شود -- نگاه کنید به
    ``pattern_bridge.py``)، و نه FUNCTIONAL کامل (هنوز هیچ تصمیمی را
    عوض نمی‌کند، و تاریخچه‌یِ DB-backad چندنشستی وصل نیست).
    """

    return InfluenceReport(
        module="nervous_system.pattern_bridge",
        status="LIVE",
        influence="ORPHAN",
        reason=(
            "خروجیِ واقعیِ ConversationPatternEngine.build_pattern (زیرمجموعه‌یِ "
            "stateless) در UnifiedConversationContext.pattern_context['engine'] "
            "ذخیره می‌شود، اما مثلِ خودِ Coordinator، هنوز هیچ مصرف‌کننده‌ای "
            "(تصمیم‌گیری/پاسخ) آن را نمی‌خواند -- SHADOW. علاوه‌بر‌این، بخشِ "
            "DB-backed (mood_report، تاریخچه‌یِ چندنشستی) هنوز وصل نیست -- "
            "فقط زیرمجموعه‌یِ stateless. نگاه کنید به audit/module_status.md."
        ),
    )


def assert_non_interference(decision_without_coordinator, decision_with_coordinator) -> bool:
    """``True`` فقط اگر دو تصمیم از هر نظر یکسان باشند (route/intent/confidence).

    استفاده در تست: نشان می‌دهد فعال‌کردنِ Coordinator (حتی وقتی
    ``TRX_NERVOUS_SYSTEM_ENABLED=1``) هیچ تأثیری رویِ ``RoutingDecision``
    نهایی نمی‌گذارد -- دقیقاً طبقِ «قانونِ عدمِ تخریب» سند.
    """

    if decision_without_coordinator is None or decision_with_coordinator is None:
        return decision_without_coordinator == decision_with_coordinator
    return (
        decision_without_coordinator.route == decision_with_coordinator.route
        and decision_without_coordinator.selected_intent == decision_with_coordinator.selected_intent
        and decision_without_coordinator.confidence == decision_with_coordinator.confidence
        and decision_without_coordinator.raw_text == decision_with_coordinator.raw_text
    )
