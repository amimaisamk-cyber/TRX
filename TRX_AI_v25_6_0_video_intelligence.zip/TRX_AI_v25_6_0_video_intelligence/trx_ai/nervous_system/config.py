# -*- coding: utf-8 -*-
"""
تنظیماتِ Nervous System Coordinator -- هم‌الگو با
``trx_ai/conversation/config.py`` و ``trx_ai/phase3/config.py`` (پرچمِ
محیطی برایِ روشن/خاموش‌کردن، بدونِ تغییرِ کد).

طبقِ «قانونِ عدمِ تخریب» سندِ v25.5.5:
    - پیش‌فرض خاموش است (SHADOW اختیاری، نه اجباری).
    - نبودِ NumPy/llama.cpp نباید این پکیج را بترکاند -- این پکیج اصلاً
      به آن‌ها وابسته نیست (فقط dataclass + deque، بدونِ وابستگیِ جدید).
"""

from __future__ import annotations

import os


def _env_bool(name: str, default: bool) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _env_int(name: str, default: int) -> int:
    val = os.environ.get(name)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        return default


# کلیدِ اصلی -- طبقِ Phase 8 سند («مرحله‌یِ A: SHADOW»)، پیش‌فرض False
# است: Coordinator تا وقتی صریحاً روشن نشود، حتی برایِ observation هم
# اجرا نمی‌شود؛ صفر سربارِ اضافی رویِ مسیرِ پیش‌فرض.
NERVOUS_SYSTEM_ENABLED = _env_bool("TRX_NERVOUS_SYSTEM_ENABLED", False)

# چند UnifiedConversationContext آخر، به ازایِ هر conversation_id، در
# حافظه نگه داشته شود (بافرِ محدود -- هم‌الگو با phase3/telemetry.py).
CONTEXT_HISTORY_MAXLEN = _env_int("TRX_NERVOUS_SYSTEM_HISTORY_MAXLEN", 20)

# سقفِ تعدادِ گفتگوهایِ هم‌زمانی که Coordinator تاریخچه برایشان نگه
# می‌دارد -- جلوگیری از رشدِ بی‌سقفِ حافظه در سرویسِ درازمدت.
MAX_TRACKED_CONVERSATIONS = _env_int("TRX_NERVOUS_SYSTEM_MAX_CONVERSATIONS", 500)

# طولِ حداکثریِ هر قطعه‌یِ memory_context (کاراکتر) -- طبقِ اصلِ Memory
# سندِ Critical Audit: «Memory زیاد = هوشمندی بیشتر نیست»؛ اینجا هم فقط
# متنِ کوتاه و مرتبط نگه داشته می‌شود، نه دامپِ خام.
MEMORY_FRAGMENT_MAX_CHARS = _env_int("TRX_NERVOUS_SYSTEM_MEMORY_FRAGMENT_CHARS", 200)
