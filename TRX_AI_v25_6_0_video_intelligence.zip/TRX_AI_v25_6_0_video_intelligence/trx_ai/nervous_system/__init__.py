# -*- coding: utf-8 -*-
"""
Nervous System Coordinator -- v25.5.5.

طبقِ سندِ ``TRX_AI_v25_5_5_Nervous_System_Engineering_Plan.txt``: این
پکیج ماژول‌هایِ عصبیِ موجود (``trx_ai/conversation/*``) را حذف یا ادغام
نمی‌کند؛ فقط خروجیِ آن‌ها را که در ``conversation_engine.process`` از
قبل تولید می‌شود، جمع و استاندارد می‌کند (``UnifiedConversationContext``).

وضعیتِ این نسخه: **SHADOW** (مرحله‌یِ A از «Safe Rollout» -- بخشِ ۸ سند).
یعنی Coordinator خروجی می‌سازد، اما مسیرِ فعلیِ تصمیم‌گیری
(``intent_arbitrator`` + ``action_gate`` + ``response_critic``) هنوز و
بدونِ هیچ تغییری تصمیمِ نهایی را می‌گیرد. هیچ مصرف‌کننده‌ای (نه
Local LLM، نه Tool Gate) هنوز به خروجیِ این پکیج وصل نیست -- طبقِ
سندِ فاز ۳ که هنوز شروع نشده.

پیشِ‌شرطِ فعال‌سازی: ``TRX_NERVOUS_SYSTEM_ENABLED=1`` (پیش‌فرض خاموش).
حتی وقتی روشن است، هر خطا در این پکیج بی‌صدا بلعیده می‌شود -- طبقِ
«قانونِ عدمِ تخریب» سند: نبودِ این پکیج یا خطا در آن هرگز نباید نوبتِ
مکالمه را بترکاند.
"""

from .context_schema import UnifiedConversationContext
from .coordinator import NervousSystemCoordinator, get_coordinator

__all__ = [
    "UnifiedConversationContext",
    "NervousSystemCoordinator",
    "get_coordinator",
]
