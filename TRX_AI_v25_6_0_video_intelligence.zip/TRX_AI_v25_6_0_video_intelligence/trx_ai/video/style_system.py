# -*- coding: utf-8 -*-
"""
Style System (بخشِ ۲۶): داده‌محور؛ سبک روی نور، دوربین، حرکت، رنگ، هندسه،
تایپوگرافی و *صدا* اثر می‌گذارد -- نه فقط یک کلاسِ CSS.
"""

from __future__ import annotations

from typing import Any

STYLES: dict[str, dict[str, Any]] = {
    "cinematic":   {"light_mul": 1.0,  "contrast": 1.15, "saturation": 1.0,  "cam_speed": 1.0, "cam_shake": 0.0,  "motion_mul": 0.9,
                    "outline": False, "round": 0.3, "font": "Tahoma", "audio_vol": 1.0, "vignette": 0.6, "grain": 0.04, "letterbox": True},
    "realistic":   {"light_mul": 1.0,  "contrast": 1.05, "saturation": 0.9,  "cam_speed": 1.0, "cam_shake": 0.01, "motion_mul": 1.0,
                    "outline": False, "round": 0.2, "font": "Tahoma", "audio_vol": 1.0, "vignette": 0.4, "grain": 0.02, "letterbox": False},
    "cartoon":     {"light_mul": 1.2,  "contrast": 1.0,  "saturation": 1.5,  "cam_speed": 1.2, "cam_shake": 0.0,  "motion_mul": 1.25,
                    "outline": True,  "round": 0.9, "font": "Comic Sans MS, Tahoma", "audio_vol": 1.0, "vignette": 0.1, "grain": 0.0, "letterbox": False},
    "minimal":     {"light_mul": 1.1,  "contrast": 0.9,  "saturation": 0.35, "cam_speed": 0.8, "cam_shake": 0.0,  "motion_mul": 0.8,
                    "outline": False, "round": 0.5, "font": "Tahoma", "audio_vol": 0.7, "vignette": 0.0, "grain": 0.0, "letterbox": False},
    "neon":        {"light_mul": 0.8,  "contrast": 1.3,  "saturation": 1.7,  "cam_speed": 1.1, "cam_shake": 0.0,  "motion_mul": 1.1,
                    "outline": True,  "round": 0.2, "font": "Tahoma", "audio_vol": 1.0, "vignette": 0.7, "grain": 0.0, "letterbox": True},
    "documentary": {"light_mul": 1.0,  "contrast": 1.0,  "saturation": 0.85, "cam_speed": 0.9, "cam_shake": 0.02, "motion_mul": 0.95,
                    "outline": False, "round": 0.2, "font": "Tahoma", "audio_vol": 0.9, "vignette": 0.2, "grain": 0.03, "letterbox": False},
    "educational": {"light_mul": 1.15, "contrast": 1.0,  "saturation": 1.1,  "cam_speed": 0.7, "cam_shake": 0.0,  "motion_mul": 0.8,
                    "outline": True,  "round": 0.6, "font": "Tahoma", "audio_vol": 0.8, "vignette": 0.0, "grain": 0.0, "letterbox": False},
    "historical":  {"light_mul": 0.95, "contrast": 1.1,  "saturation": 0.75, "cam_speed": 0.8, "cam_shake": 0.0,  "motion_mul": 0.75,
                    "outline": False, "round": 0.1, "font": "Tahoma", "audio_vol": 0.9, "vignette": 0.5, "grain": 0.05, "letterbox": True},
}


def style_profile(name: str | None) -> dict[str, Any]:
    n = name if name in STYLES else "cinematic"
    return {"name": n, **STYLES[n]}


def apply_style(scene, name: str | None) -> dict[str, Any]:
    """سبک را *واقعاً* روی lighting/camera/objects/graph/audio اعمال می‌کند و پروفایل را برمی‌گرداند.
    idempotent نیست عمداً: فقط یک بار پس از برنامه‌ریزیِ پایه صدا زده شود."""
    prof = style_profile(name)
    scene.style = prof["name"]
    scene.style_profile = prof["name"]
    scene.lighting.intensity = round(max(0.05, min(1.0, scene.lighting.intensity * prof["light_mul"])), 3)
    scene.camera.intensity = round(min(1.0, scene.camera.intensity * prof["cam_speed"]), 3)
    scene.camera.shake = round(max(scene.camera.shake, prof["cam_shake"]), 3)
    for o in scene.objects:
        if o.motion != "static":
            o.velocity = round(o.velocity * prof["motion_mul"], 3)
    scene.graph["style"] = prof
    for ev in scene.audio.events:
        ev["volume"] = round(min(1.0, ev["volume"] * prof["audio_vol"]), 3)
    return prof
