# -*- coding: utf-8 -*-
"""
Motion Planner -- بخشِ ۷ سندِ طراحی.

تبدیلِ نامِ کلی/مبهمِ یک حرکت (مثلاً "حرکت آرام مو") به مجموعه‌ای از
پارامترهای دقیق (دامنه، سرعت، تأخیر، جهت، easing, loop). این ماژول هیچ
HTML/CSS تولید نمی‌کند -- فقط دیکشنری/دیتاکلاسِ ObjectSpec را کامل می‌کند؛
تولیدِ کدِ واقعی در ``html_generator.py`` انجام می‌شود (بخشِ ۳ سندِ طراحی:
جداییِ Motion Planner از Generator).
"""

from __future__ import annotations

from .scene_schema import ObjectSpec

# هر پیش‌فرض: (velocity, easing, loop, blur_px_hint)
_MOTION_PRESETS: dict[str, tuple[float, str, bool, float]] = {
    "static": (0.0, "linear", False, 0.0),
    "slow_float": (0.35, "ease-in-out", True, 0.0),
    "rise": (0.6, "ease-out", True, 0.0),
    "sway": (0.4, "ease-in-out", True, 0.0),
    "drift": (0.25, "linear", True, 0.4),
    "pulse": (0.5, "ease-in-out", True, 0.0),
    # v25.6.0: حرکت‌هایِ معنادار (قبلاً ناشناخته → به static سقوط می‌کردند)
    "walk": (0.5, "ease-in-out", False, 0.0),
    "fall": (1.0, "linear", True, 0.0),
}

# ضریبِ سرعتِ نسبی بر اساسِ حسِ کلیِ صحنه -- بخشِ ۵.۵ (حسِ صحنه).
_MOOD_SPEED_MULTIPLIER = {
    "calm": 0.8,
    "mysterious": 0.7,
    "epic": 1.1,
    "scientific": 1.0,
    "dreamy": 0.6,
    "dark": 0.75,
    "joyful": 1.2,
    "cinematic": 0.9,
}


def plan_object_motion(obj: ObjectSpec, mood: str = "calm") -> ObjectSpec:
    """پارامترهای حرکتیِ یک شیء را بر اساسِ ``obj.motion`` و حسِ کلیِ صحنه
    تکمیل می‌کند و همان شیء (به‌روزشده) را برمی‌گرداند.
    """
    velocity, easing, loop, blur_hint = _MOTION_PRESETS.get(obj.motion, _MOTION_PRESETS["static"])
    speed_mul = _MOOD_SPEED_MULTIPLIER.get(mood, 1.0)

    obj.velocity = round(velocity * speed_mul, 3)
    obj.easing = easing
    obj.loop = loop
    if obj.blur_px == 0.0:
        obj.blur_px = blur_hint
    return obj


def plan_all(objects: list[ObjectSpec], mood: str = "calm") -> list[ObjectSpec]:
    # تأخیرِ لایه‌ای (delay) بینِ اشیای مشابه تا حرکت‌ها هم‌زمان و مصنوعی
    # به نظر نرسند -- دقیقاً درخواستِ صریحِ بخشِ ۷ («تأخیر بین لایه‌ها: متفاوت»).
    delay_step = 0.0
    for obj in objects:
        plan_object_motion(obj, mood=mood)
        if obj.motion != "static":
            obj.delay_s = round(delay_step, 2)
            delay_step += 0.35
    return objects


# ----------------------------------------------------------------------
#   Motion Graph (بخشِ ۱۰ سندِ ارتقا): مفهومِ حرکت، نه صرفاً move(x,y)
# ----------------------------------------------------------------------
from dataclasses import dataclass, asdict  # noqa: E402


@dataclass
class MotionProfile:
    kind: str
    speed: float                # واحدِ صحنه/ثانیه
    acceleration: str           # ease_in_out | ease_out | linear | settle | anticipate
    anticipation_s: float       # مکثِ آماده‌سازی قبل از حرکت
    follow_through_s: float     # ادامهٔ نرمِ بعد از توقف
    loop: bool = False
    pause_s: float = 0.0
    path: str = "line"          # line | arc
    sync_with: str = ""         # مثلاً «footsteps»

    def to_dict(self) -> dict:
        return asdict(self)


_SPEED_WORD = {"slow": 0.6, "normal": 1.0, "fast": 1.6}


def plan_motion_profile(kind: str, speed_word: str = "normal", mood: str = "calm") -> MotionProfile:
    mul = _SPEED_WORD.get(speed_word, 1.0) * _MOOD_SPEED_MULTIPLIER.get(mood, 1.0)
    if kind == "walk":
        return MotionProfile("walk", round(0.11 * mul, 4), "ease_in_out", 0.35, 0.45, sync_with="footsteps")
    if kind == "door_open":
        return MotionProfile("door_open", 1.0, "settle", 0.15, 0.3, sync_with="door")
    return MotionProfile(kind, round(0.1 * mul, 4), "ease_in_out", 0.0, 0.0)
