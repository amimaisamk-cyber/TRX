# -*- coding: utf-8 -*-
"""
Semantic extractor: متنِ خام → ``VideoIntent`` (بخشِ ۴ و ۲۳ سندِ ارتقا).

تفاوت با ``request_normalizer`` قدیمی (که دست‌نخورده می‌ماند):
  * تطبیقِ مرزدار (نه substring) + نفی («بدونِ موسیقی»)؛
  * ترتیبِ رویدادها (سپس/بعد/then) حفظ می‌شود؛
  * هر مقدارِ *صریح* با شاهدِ متنی ثبت می‌شود (``explicit``)، پیش‌فرض‌ها جدا؛
  * ابهام ثبت می‌شود (``uncertainty``) و فقط ابهامِ شدید سؤال می‌خواهد.
"""

from __future__ import annotations

import re

from ...nlu.normalizer import normalize as _nlu_normalize
from . import lexicon as L
from .intent import VideoIntent, EventIntent, Uncertainty

MAX_TOTAL_DURATION = 60.0
MIN_TOTAL_DURATION = 2.0

_IDENTITY_RE = re.compile(
    r"دیپ\s*فیک|deepfake|چهره\s*(?:ی|‌ی)?\s*(?:واقعی|دقیق)|"
    r"دقیقا\s+(?:شبیه|عین)\s+(?:آقای|خانم|دکتر)?\s*\S+|"
    r"(?:ویدیو|ویدئو|تصویر)ی?\s+که\s+دقیقا\s+.{0,25}(?:فرد|شخص|آدم)|"
    r"exactly\s+(?:like|resembl\w+)\s+(?:a\s+)?(?:real\s+)?(?:person|\w+\s+\w+)|real\s+person'?s?\s+face")

_LTR_RE = re.compile(r"از\s+چپ\s+به\s+راست|left\s+to\s+right|چپ\s*(?:→|->)\s*راست")
_RTL_RE = re.compile(r"از\s+راست\s+به\s+چپ|right\s+to\s+left")
_TRANS_RE = re.compile(
    r"(?:از\s+)?(روز|شب|غروب|صبح|سپیده\s+دم|day|night|sunset|dawn)\s*(?:به|تا|to|into)\s+(روز|شب|غروب|صبح|سپیده\s+دم|day|night|sunset|dawn)")
_TOD_CANON = {"روز": "day", "صبح": "day", "شب": "night", "غروب": "sunset", "سپیده دم": "dawn",
              "day": "day", "night": "night", "sunset": "sunset", "dawn": "dawn"}
_STOP_RE = re.compile(r"متوقف|قطع\s+(?:شود|بشه|شه)|بند\s+(?:بیاید|بیاد)|تمام\s+شو|stops?|stopped|ends?|ceases?")
_START_RE = re.compile(r"شروع|آغاز|starts?|begins?|begin")
_DOOR_RE = re.compile(r"در\s+(?:\S+\s+){0,2}?باز\s+(?:شود|بشه|شه|می\s*شود)|در\s+باز\s+(?:شود|بشه)|باز\s+شدنِ?\s+در|door\s+(?:opens|open)|opens?\s+(?:the\s+)?door")
_STORY_RE = re.compile(r"داستان|story")

_FA_CH = re.compile(r"[\u0600-\u06FF]")
_LAT_CH = re.compile(r"[A-Za-z]")


def _lang(text: str) -> str:
    fa, en = len(_FA_CH.findall(text)), len(_LAT_CH.findall(text))
    if fa and en and min(fa, en) / max(fa, en) > 0.25:
        return "mixed"
    return "en" if en > fa else "fa"


def _first(hits, prefer=None):
    return hits[0] if hits else None


def _ev_kind_positions(norm: str, kind_tables) -> list[tuple[int, str, str]]:
    out = []
    for kind, rx in kind_tables:
        for m in rx.finditer(norm):
            out.append((m.start(), kind, m.group(0)))
    return out


def understand(raw_text: str) -> VideoIntent:
    """تبدیلِ متنِ خام به VideoIntent. هرگز raise نمی‌کند."""
    raw = raw_text or ""
    norm = L.prepare(_nlu_normalize(raw))
    it = VideoIntent(raw_text=raw, language=_lang(raw))

    # ---- seed ----
    m = L.SEED_RE.search(norm)
    if m:
        it.seed = int(m.group(1))
        it.explicit["seed"] = m.group(0)

    # ---- هویت/فرد واقعی: سیاست، نه قابلیتِ تولید ----
    mi = _IDENTITY_RE.search(norm)
    if mi:
        it.constraints.append("identity_unsupported")
        it.explicit["constraint"] = mi.group(0)
        it.uncertainty.append(Uncertainty(
            "identity", "درخواستِ نمایشِ فردِ واقعیِ مشخص؛ موتور فقط شخصیتِ عمومی/انتزاعی می‌سازد.", "high"))

    # ---- مدت / fps / نسبتِ تصویر ----
    for dm in L.DURATION_RE.finditer(norm):
        val = L.number_from_word(dm.group(1))
        if val:
            secs = val * (60 if dm.group(2).startswith(("دقیقه", "min")) else 1)
            clamped = max(MIN_TOTAL_DURATION, min(MAX_TOTAL_DURATION, secs))
            if clamped != secs:
                it.uncertainty.append(Uncertainty("duration", f"مدتِ {secs:g}s به {clamped:g}s محدود شد (سقفِ موبایل).", "low"))
            it.duration = float(clamped)
            it.explicit["duration"] = dm.group(0)
            break
    mf = L.FPS_RE.search(norm)
    if mf:
        it.fps = int(mf.group(1))
        it.explicit["fps"] = mf.group(0)
    for rx, val in L.ASPECTS:
        ma = rx.search(norm)
        if ma:
            it.aspect_ratio = val
            it.explicit["aspect_ratio"] = ma.group(0)
            break

    # ---- محیط (اولویت = ترتیبِ جدول؛ بقیه location) ----
    env_hits = L.scan(norm, L.ENVIRONMENTS)
    if env_hits:
        order = list(L.ENVIRONMENTS)
        env_hits_sorted = sorted(env_hits, key=lambda h: order.index(h.key))
        it.environment = env_hits_sorted[0].key
        it.explicit["environment"] = env_hits_sorted[0].surface
        others = {h.key for h in env_hits_sorted[1:] if h.key != it.environment}
        if others:
            it.location = sorted(others)[0]
        if it.environment == "room" and "laboratory" in {h.key for h in env_hits}:
            it.environment = "laboratory"

    # ---- زمان ----
    mt = _TRANS_RE.search(norm)
    if mt:
        a, b = _TOD_CANON[re.sub(r"\s+", " ", mt.group(1))], _TOD_CANON[re.sub(r"\s+", " ", mt.group(2))]
        if a != b:
            it.time_transition = (a, b)
            it.time_of_day = a
            it.explicit["time_transition"] = mt.group(0)
    if it.time_transition is None:
        th = [h for h in L.scan(norm, L.TIMES) if not L.is_negated(norm, h.start, h.end)]
        # «روز» در «چرخه‌ی آب روز» و … نادر؛ «شب» داخلِ «شبیه» با مرز رد می‌شود.
        if th:
            it.time_of_day = th[0].key
            it.explicit["time_of_day"] = th[0].surface
            distinct = {h.key for h in th}
            if len(distinct) > 1:
                it.uncertainty.append(Uncertainty(
                    "time_of_day", f"چند زمانِ روز بدونِ انتقال ذکر شد ({', '.join(sorted(distinct))})؛ اولی انتخاب شد.", "low"))

    # ---- آب‌وهوا ----
    wh = [h for h in L.scan(norm, L.WEATHERS) if not L.is_negated(norm, h.start, h.end)]
    # «صدای باران» فقط درخواستِ صداست، نه الزاماً بصری؛ اما باران بدونِ تصویر
    # بی‌معنی است، پس weather هم ثبت می‌شود (audio جدا هم ثبت می‌شود).
    if wh:
        it.weather = wh[0].key
        it.explicit["weather"] = wh[0].surface

    # ---- سبک/حس ----
    sh = L.scan(norm, L.STYLES)
    if sh:
        it.style = sh[0].key
        it.explicit["style"] = sh[0].surface
    mh = L.scan(norm, L.MOODS)
    if mh:
        it.mood = mh[0].key
        it.explicit["mood"] = mh[0].surface

    # ---- سوژه ----
    sj = [h for h in L.scan(norm, L.SUBJECTS) if not L.is_negated(norm, h.start, h.end)]
    # «ماه» با مرزِ دقیق؛ «روی شیشه»/… سوژه نیستند.
    if sj:
        it.subject = sj[0].key
        it.explicit["subject"] = sj[0].surface

    # ---- دوربین ----
    cam: dict = {}
    mv = L.scan(norm, L.CAMERA_MOVES)
    if mv:
        cam["move"] = mv[0].key
        it.explicit["camera"] = mv[0].surface
        near = norm[max(0, mv[0].start - 24):mv[0].end + 24]
        if any(w in near for w in L.SPEED_SLOW):
            cam["speed"] = "slow"
        elif any(w in near for w in L.SPEED_FAST):
            cam["speed"] = "fast"
    shots = L.scan(norm, L.CAMERA_SHOTS)
    if shots:
        cam["shot"] = shots[0].key
        it.explicit.setdefault("camera", shots[0].surface)
    if cam:
        it.camera = cam

    # ---- صدا ----
    audio: dict = {"ambience": [], "sfx": [], "music": None, "silent": False}
    sil = L.scan(norm, {"s": L.SILENT})
    if sil:
        audio["silent"] = True
        it.explicit["silence"] = sil[0].surface
        it.constraints.append("no:audio")
    for h in L.scan(norm, L.AMBIENCE):
        if not L.is_negated(norm, h.start, h.end):
            audio["ambience"].append(h.key)
            it.explicit.setdefault("audio:" + h.key, h.surface)
    amb_generic = L.scan(norm, {"g": L.AMBIENT_GENERIC})
    if amb_generic and not audio["ambience"]:
        audio["ambience"].append("auto")
        it.explicit["audio:auto"] = amb_generic[0].surface
    for h in L.scan(norm, L.SFX):
        if not L.is_negated(norm, h.start, h.end):
            if h.key not in audio["sfx"]:
                audio["sfx"].append(h.key)
            it.explicit.setdefault("audio:" + h.key, h.surface)
    for h in L.scan(norm, {"m": L.MUSIC}):
        if L.is_negated(norm, h.start, h.end):
            audio["music"] = False
            it.constraints.append("no:music")
            it.explicit["music"] = "no:" + h.surface
        elif audio["music"] is None:
            audio["music"] = True
            it.explicit["music"] = h.surface
    it.audio = audio

    # ---- روایت/گفتار ----
    nh = L.scan(norm, {"n": L.NARRATION})
    if nh and not L.is_negated(norm, nh[0].start, nh[0].end):
        q = L.QUOTE_RE.search(raw)
        it.narration = q.group(1).strip() if q else ""      # متنِ خالی = تولیدِ خودکار در planner
        it.explicit["narration"] = nh[0].surface
    qd = [q.group(1).strip() for q in L.QUOTE_RE.finditer(raw)]
    if qd and it.narration is None and re.search(r"بگو|می\s*گوید|says?|dialogue|دیالوگ", norm):
        it.dialogue = qd

    # ---- نور ----
    for h in L.scan(norm, L.LIGHTING):
        if not L.is_negated(norm, h.start, h.end) and h.key not in it.lighting:
            it.lighting.append(h.key)
            it.explicit.setdefault("lighting", h.surface)

    # ---- حرکت ----
    motions: list[dict] = []
    direction = "ltr" if _LTR_RE.search(norm) else ("rtl" if _RTL_RE.search(norm) else None)
    if direction:
        who = it.subject if it.subject == "character" else "character"
        motions.append({"subject": who, "kind": "walk", "direction": direction,
                        "speed": "slow" if any(w in norm for w in L.SPEED_SLOW) else "normal"})
        it.explicit["motion"] = (_LTR_RE.search(norm) or _RTL_RE.search(norm)).group(0)
        if it.subject is None:
            it.subject = "character"
            it.explicit["subject"] = "character(implied-by-motion)"
    it.motion = motions
    if cam.get("move") == "follow" and it.subject is None:
        it.subject = "character"

    # ---- رویدادها به ترتیبِ ظهور ----
    evs: list[tuple[int, str, str]] = []
    rain_hit = next((h for h in L.scan(norm, {"rain": L.WEATHERS["rain"]})), None)
    if it.weather == "rain" and rain_hit:
        sentence_win = norm[rain_hit.start:rain_hit.start + 60]
        has_start, has_stop = bool(_START_RE.search(sentence_win)), bool(_STOP_RE.search(sentence_win))
        if has_start:
            evs.append((rain_hit.start, "rain_start", sentence_win))
        if has_stop:
            ms = _STOP_RE.search(sentence_win)
            evs.append((rain_hit.start + ms.start(), "rain_stop", ms.group(0)))
    for h in L.scan(norm, {"thunder": L.SFX["thunder"]}):
        if not L.is_negated(norm, h.start, h.end):
            evs.append((h.start, "thunder", h.surface))
            break
    md = _DOOR_RE.search(norm)
    if md:
        evs.append((md.start(), "door_open", md.group(0)))
        if "door" not in audio["sfx"]:
            audio["sfx"].append("door")
    if "door" in audio["sfx"] and not any(k == "door_open" for _, k, _ in evs):
        # «صدایِ در» بدونِ باز شدنِ دیدنیِ در ناهم‌خوان است؛ صدا مستلزمِ رویدادِ تصویری است.
        dh = next(h for h in L.scan(norm, L.SFX) if h.key == "door")
        evs.append((dh.start, "door_open", dh.surface))
    if it.time_transition:
        evs.append((mt.start(), "time_transition", mt.group(0)))
    if motions:
        pos = (_LTR_RE.search(norm) or _RTL_RE.search(norm)).start()
        evs.append((pos, "character_move", motions[0]["direction"]))
        if "footsteps" in audio["sfx"] or True:
            pass
    evs.sort(key=lambda e: e[0])
    it.events = [EventIntent(order=i, kind=k, text=t) for i, (_, k, t) in enumerate(evs)]

    # ---- چندصحنه‌ای / داستان ----
    n = 1
    ms = L.SCENE_COUNT_RE.search(norm)
    if ms:
        tok = next(g for g in ms.groups() if g)
        n = {"دو": 2, "سه": 3, "چهار": 4, "پنج": 5, "two": 2, "three": 3, "four": 4, "five": 5}.get(tok) or int(tok)
        it.explicit["multi_scene"] = ms.group(0)
    elif _STORY_RE.search(norm):
        n = 3
        it.explicit["multi_scene"] = "story(default 3)"
        it.uncertainty.append(Uncertainty("scene_count", "«داستان» بدونِ تعداد؛ ۳ صحنه فرض شد.", "low"))
    it.scene_count = max(1, min(6, n))

    it.educational = bool(it.style == "educational" or it.environment == "water_cycle"
                          or re.search(r"آموزش|educational|tutorial|explain", norm))
    it.historical = bool(it.environment == "ancient_persia" or it.style == "historical")

    # ---- اطمینان: نسبتِ حوزه‌هایِ شناخته‌شده؛ ابهامِ کم برایِ درخواستِ خالی ----
    known = len([k for k in it.explicit if k not in ("seed", "fps")])
    it.confidence = round(min(0.95, 0.25 + 0.12 * known), 2) if known else 0.2
    if not known:
        it.uncertainty.append(Uncertainty("all", "هیچ عنصرِ مشخصی استخراج نشد؛ پیش‌فرض‌هایِ امن به‌کار رفت.", "low"))
    return it


def needs_clarification(intent: VideoIntent) -> str | None:
    """دروازهٔ ابهام (بخشِ ۲۳): فقط ابهامی که نتیجه را شدیداً عوض می‌کند سؤال می‌خواهد.
    درخواستِ ناقص-ولی-قابلِ‌حدس («یک ویدیوی جنگل»، «۳۰ ثانیه») هرگز سؤال نمی‌خواهد."""
    return None   # سیاستِ هویت در خروجی گزارش می‌شود، نه مسدودسازیِ ساخت؛ نگاه کنید به pipeline.
