# -*- coding: utf-8 -*-
"""
واژگانِ داده‌محورِ درکِ معنایی (فارسی + انگلیسی) -- بخشِ ۴ سندِ ارتقا.

این فایل *فقط داده + ماشینِ تطبیقِ مرزدار* است. تفاوتِ کلیدی با
``request_normalizer`` قدیمی: تطبیق بر پایهٔ مرزِ کلمه است (نه substringِ
خام)، پس «شبیه» به‌اشتباه «شب» و «ماهی» به‌اشتباه «ماه» تشخیص داده
نمی‌شود، و نفی («بدونِ موسیقی») صریحاً تشخیص داده می‌شود.

یادداشتِ صادقانه: این لایه هنوز واژگان‌محور است (نه مدلِ زبانی)، اما
خروجی‌اش ساختارمند، دارای شاهدِ متنی و دارای ردیابیِ نفی/ترتیب است؛ لایه‌ی
مدل می‌تواند بعداً پشتِ همین قرارداد (``VideoIntent``) جایگزین شود.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache

_FA = "\u0621-\u064A\u067E\u0686\u0698\u06A9\u06AF\u06CC\u06BE\u06C0"   # فقط حروف (نه «،» و ارقام)
_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")

# پسوندهایِ مجاز فقط برایِ سطحِ بلند (>۳ حرف)؛ کلماتِ کوتاه (شب/ماه/باد)
# فقط با مرزِ دقیق تطبیق می‌شوند تا «ماهی»/«بادکنک» اشتباه نشوند.
_FA_SUFFIX = r"(?:ها|های|ی|ای|ه|ا|ان|رو|را|ش|شو|م|ت)?"


@dataclass(frozen=True)
class Hit:
    start: int
    end: int
    key: str
    surface: str

    @property
    def span(self) -> tuple[int, int]:
        return self.start, self.end


_DIACRITICS = re.compile("[\u064B-\u065F\u0670\u0640]")   # اعراب/تنوین/کشیده: «بدونِ» ≡ «بدون»


def prepare(text: str) -> str:
    """ارقام را یکدست و اعراب/کشیده را حذف می‌کند (بقیهٔ نرمال‌سازی با nlu.normalizer است)."""
    return _DIACRITICS.sub("", (text or "").translate(_FA_DIGITS))


@lru_cache(maxsize=2048)
def _compile(surface: str) -> re.Pattern[str]:
    esc = re.escape(surface).replace(r"\ ", r"\s+")
    if surface.isascii():
        return re.compile(rf"(?<![a-z0-9]){esc}(?:s|es|ing|ed)?(?![a-z0-9])")
    suffix = _FA_SUFFIX if len(surface.replace(" ", "")) > 3 else ""
    return re.compile(rf"(?<![{_FA}]){esc}{suffix}(?![{_FA}])")


def scan(text: str, table: dict[str, tuple[str, ...]]) -> list[Hit]:
    """همهٔ تطبیق‌هایِ یک جدول؛ در هم‌پوشانی، تطبیقِ بلندتر برنده است."""
    raw: list[Hit] = []
    for key, surfaces in table.items():
        for s in surfaces:
            for m in _compile(s).finditer(text):
                raw.append(Hit(m.start(), m.end(), key, s))
    raw.sort(key=lambda h: (-(h.end - h.start), h.start))
    chosen: list[Hit] = []
    for h in raw:
        if not any(h.start < c.end and c.start < h.end for c in chosen):
            chosen.append(h)
    chosen.sort(key=lambda h: h.start)
    return chosen


_NEG_BEFORE = re.compile(
    rf"(?<![{_FA}a-z])(?:بدون|بی|without|no|remove|نه)\s*(?:هیچ\s*(?:گونه\s*)?|any\s+)?$")
_NEG_AFTER = re.compile(
    r"^\s*(?:رو|را)?\s*(?:نباشه|نباشد|نداشته\s*باشه|نداشته\s*باشد|نمی\s*خوام|نمی\s*خواهم|"
    r"not\s+needed|is\s+not\s+needed|not\s+wanted)")


def is_negated(text: str, start: int, end: int) -> bool:
    """آیا تطبیقِ [start,end) در متن نفی شده است؟ («بدونِ X» / «X نباشد»)."""
    before = text[max(0, start - 18):start]
    after = text[end:end + 22]
    return bool(_NEG_BEFORE.search(before) or _NEG_AFTER.search(after))


# ----------------------------------------------------------------------
#                               جدول‌ها
# ----------------------------------------------------------------------

SUBJECTS: dict[str, tuple[str, ...]] = {
    "house": ("خانه", "خونه", "کلبه", "house", "cabin", "cottage"),
    "character": ("شخصیت", "آدم", "انسان", "مرد", "زن", "پسر", "دختر", "کاراکتر",
                  "character", "person", "man", "woman", "boy", "girl", "human"),
    "tree": ("درخت", "tree"),
    "moon": ("ماه", "moon"),
    "sun": ("خورشید", "sun"),
    "object": ("شیء", "شی", "جسم", "object", "item"),
    # موضوع‌هایِ شناخته‌شده‌ای که هنوز drawer ندارند -- عمداً فهرست می‌شوند تا
    # در نبودِ رندر «UNSUPPORTED» ثبت شوند، نه اینکه بی‌صدا حذف شوند.
    "car": ("ماشین", "خودرو", "car"),
    "bird": ("پرنده", "bird"),
    "ship": ("کشتی", "قایق", "ship", "boat"),
    "flower": ("گل", "flower"),
    "dragon": ("اژدها", "dragon"),
}

ENVIRONMENTS: dict[str, tuple[str, ...]] = {
    "water_cycle": ("چرخه آب", "چرخه ی آب", "water cycle"),
    "ancient_persia": ("تخت جمشید", "پرسپولیس", "هخامنشی", "ایران باستان",
                       "persepolis", "ancient persia"),
    "futuristic_city": ("آینده نگر", "آینده‌نگر", "futuristic", "cyberpunk", "شهر آینده"),
    "underwater": ("زیر آب", "زیرآب", "underwater", "اقیانوس", "دریا", "ocean"),
    "forest": ("جنگل", "forest", "woods"),
    "city": ("شهر", "city", "downtown", "برج"),
    "desert": ("کویر", "بیابان", "desert"),
    "mountain": ("کوهستان", "کوه", "mountain"),
    "laboratory": ("آزمایشگاه", "لابراتوار", "laboratory", "lab"),
    "room": ("اتاق", "room"),
    "village": ("روستا", "village"),
    "street": ("خیابان", "street"),
    "space": ("فضا", "کهکشان", "space", "galaxy"),
    "rain_on_window": ("روی شیشه", "پشت شیشه", "پنجره بارانی", "rainy window"),
}

TIMES: dict[str, tuple[str, ...]] = {
    "night": ("شب", "شبانه", "نیمه شب", "night", "midnight", "nighttime"),
    "sunset": ("غروب", "sunset", "دم غروب"),
    "dawn": ("سپیده دم", "طلوع", "صبح زود", "dawn", "sunrise"),
    "day": ("روز", "روزانه", "ظهر", "day", "daytime", "midday", "صبح"),
    "dusk": ("گرگ و میش", "dusk", "twilight"),
}

WEATHERS: dict[str, tuple[str, ...]] = {
    "rain": ("باران", "بارون", "بارانی", "بارونی", "rain", "rainy", "raining"),
    "snow": ("برف", "برفی", "snow", "snowy"),
    "fog": ("مه", "مه آلود", "مه‌آلود", "fog", "foggy", "mist", "misty"),
}

STYLES: dict[str, tuple[str, ...]] = {
    "cartoon": ("کارتونی", "کارتون", "cartoon"),
    "minimal": ("مینیمال", "minimal", "minimalist"),
    "realistic": ("واقع گرایانه", "واقع‌گرایانه", "واقعی", "realistic"),
    "educational": ("آموزشی", "educational"),
    "historical": ("تاریخی", "historical"),
    "neon": ("نئونی", "نئون", "neon"),
    "documentary": ("مستند", "documentary"),
    "cinematic": ("سینمایی", "cinematic"),
}

MOODS: dict[str, tuple[str, ...]] = {
    "mysterious": ("رازآلود", "مرموز", "mysterious", "eerie"),
    "epic": ("حماسی", "باشکوه", "epic"),
    "dreamy": ("رویایی", "رؤیایی", "خیال انگیز", "dreamy"),
    "dark": ("تاریک", "تیره", "dark", "gloomy"),
    "joyful": ("شاد", "پرانرژی", "joyful", "cheerful"),
    "scientific": ("علمی", "scientific"),
    "calm": ("آرامش بخش", "آرامش‌بخش", "peaceful", "calm", "serene"),
}

CAMERA_SHOTS: dict[str, tuple[str, ...]] = {
    "close_up": ("نمای نزدیک", "کلوزآپ", "کلوز آپ", "close up", "close-up", "closeup"),
    "wide": ("نمای باز", "نمای دور", "wide shot", "wide angle"),
    "establishing": ("نمای معرف", "establishing shot"),
    "over_shoulder": ("over the shoulder", "over-shoulder", "روی شانه"),
    "pov": ("pov", "دید اول شخص"),
}

# حرکتِ دوربین: عبارت‌هایِ فعلی، نه اسمِ صرف («نزدیک» به‌تنهایی حرکت نیست).
CAMERA_MOVES: dict[str, tuple[str, ...]] = {
    "follow": ("دنبال کند", "دنبال کن", "دنبالش کند", "تعقیب کند", "follow", "tracks", "tracking"),
    "dolly_in": ("نزدیک شود", "نزدیک شو", "نزدیک بشه", "نزدیک بشود", "نزدیک می شود",
                 "نزدیک میشه", "dolly in", "push in", "move closer", "zoom in", "approach",
                 "زوم کند", "زوم کن"),
    "dolly_out": ("دور شود", "دور شو", "دور بشه", "عقب برود", "عقب بره", "dolly out",
                  "pull back", "pull out", "zoom out"),
    "orbit": ("دور آن بچرخد", "دورش بچرخد", "بچرخد دور", "orbit", "orbits", "circle around"),
    "pan": ("پن کند", "پن کن", "چرخش دوربین", "pan left", "pan right", "pans", "pan"),
    "tilt": ("تیلت", "tilt"),
    "crane": ("کرین", "crane"),
    "reveal": ("ریویل", "reveal"),
}

SPEED_SLOW = ("آرام", "آروم", "آهسته", "ملایم", "slow", "slowly", "gently", "smoothly")
SPEED_FAST = ("سریع", "تند", "fast", "quickly", "rapid")

AMBIENCE: dict[str, tuple[str, ...]] = {
    "rain": ("صدای باران", "صدای بارون", "rain sound", "sound of rain", "rain ambience"),
    "wind": ("صدای باد", "wind sound", "sound of wind", "howling wind"),
    "underwater": ("صدای زیر آب", "صدای خفه", "underwater sound"),
    "city": ("صدای شهر", "city ambience", "city sounds"),
    "forest": ("صدای جنگل", "forest ambience", "forest sounds"),
}
AMBIENT_GENERIC = ("صدای محیط", "صدای محیطی", "ambient sound", "ambient sounds",
                   "environment sound", "ambience")

SFX: dict[str, tuple[str, ...]] = {
    "thunder": ("صدای رعد", "رعد و برق", "رعد", "صاعقه", "thunder"),
    "footsteps": ("صدای قدم", "صدای پا", "footsteps", "footstep"),
    "door": ("صدای در", "door sound", "door creak"),
    "impact": ("صدای برخورد", "impact sound"),
}

MUSIC = ("موسیقی", "آهنگ", "music", "soundtrack")
SILENT = ("بدون صدا", "بی صدا", "بی‌صدا", "بیصدا", "silent", "no sound", "without sound", "mute", "muted")
NARRATION = ("روایت", "راوی", "گوینده", "narration", "narrate", "narrator", "voiceover", "voice over")

LIGHTING: dict[str, tuple[str, ...]] = {
    "window_light": ("نور پنجره", "پنجره روشن", "window light", "lit window", "پنجره‌ی روشن"),
    "moonlight": ("نور ماه", "مهتاب", "moonlight"),
    "warm_light": ("نور گرم", "warm light"),
    "low_light": ("نور کم", "کم نور", "low light", "dim light"),
    "neon_light": ("نور نئون", "neon light"),
}

ASPECTS = (
    (re.compile(r"(?<!\d)16\s*[:x×]\s*9(?!\d)"), "16:9"),
    (re.compile(r"(?<!\d)9\s*[:x×]\s*16(?!\d)"), "9:16"),
    (re.compile(r"(?<!\d)1\s*[:x×]\s*1(?!\d)"), "1:1"),
    (re.compile(r"(?<![a-z])(?:vertical|portrait)(?![a-z])|عمودی|استوری|ریلز"), "9:16"),
    (re.compile(r"(?<![a-z])square(?![a-z])|مربعی|مربع"), "1:1"),
    (re.compile(r"(?<![a-z])(?:horizontal|landscape)(?![a-z])|افقی"), "16:9"),
)

_WORD_NUM = {"یک": 1, "دو": 2, "سه": 3, "چهار": 4, "پنج": 5, "شش": 6, "هفت": 7, "هشت": 8,
             "نه": 9, "ده": 10, "پانزده": 15, "بیست": 20, "سی": 30, "چهل": 40, "پنجاه": 50, "شصت": 60}
_EN_NUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
           "eight": 8, "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20, "thirty": 30}

DURATION_RE = re.compile(
    rf"(\d+(?:\.\d+)?|[{_FA}]+|[a-z]+)\s*(ثانیه|دقیقه|seconds?|secs?|minutes?|mins?)")
FPS_RE = re.compile(r"(\d{2,3})\s*(?:fps|فریم)")
SEED_RE = re.compile(r"(?:seed|بذر)\s*[:=]?\s*(\d+)")
QUOTE_RE = re.compile(r"[«\"“]([^»\"”]{3,400})[»\"”]")

SCENE_COUNT_RE = re.compile(
    rf"(?<![{_FA}])(دو|سه|چهار|پنج)\s*[- ]?\s*صحنه(?:‌?ای)?|(two|three|four|five)[- ]scene|"
    r"(\d)\s*(?:scenes|صحنه)")

CLAUSE_SPLIT = re.compile(r"[،,.؛;\n]|(?<![{fa}])(?:سپس|بعد|بعدش|بعدا|آن‌گاه|then|after that|afterwards)(?![{fa}])"
                          .format(fa=_FA))


def number_from_word(tok: str) -> float | None:
    tok = tok.strip()
    if re.fullmatch(r"\d+(?:\.\d+)?", tok):
        return float(tok)
    return float(_WORD_NUM.get(tok) or _EN_NUM.get(tok) or 0) or None
