# -*- coding: utf-8 -*-
"""Requirement Traceability (بخشِ ۱۹): فقط خواسته‌هایِ *صریحِ* کاربر ID می‌گیرند."""

from __future__ import annotations

from .intent import VideoIntent, Requirement


def extract_requirements(it: VideoIntent) -> list[Requirement]:
    reqs: list[Requirement] = []

    def add(kind: str, expected: str, evidence: str = "", negated: bool = False, **params):
        reqs.append(Requirement(id=f"REQ-{len(reqs) + 1:03d}", kind=kind, expected=str(expected),
                                evidence_text=evidence, params=params, negated=negated))

    ex = it.explicit
    if "subject" in ex and it.subject:
        add("subject", it.subject, ex["subject"])
    if "environment" in ex and it.environment:
        add("environment", it.environment, ex["environment"])
    if "weather" in ex and it.weather:
        add("weather", it.weather, ex["weather"])
    if it.time_transition:
        add("time_of_day", f"{it.time_transition[0]}->{it.time_transition[1]}", ex.get("time_transition", ""),
            transition=True)
    elif "time_of_day" in ex and it.time_of_day:
        add("time_of_day", it.time_of_day, ex["time_of_day"])
    if it.camera.get("move"):
        add("camera", it.camera["move"], ex.get("camera", ""), speed=it.camera.get("speed"),
            target_required=True)
    if it.camera.get("shot"):
        add("camera", "shot:" + it.camera["shot"], ex.get("camera", ""))
    for m in it.motion:
        add("motion", f"{m['kind']}:{m['direction']}", ex.get("motion", ""), subject=m["subject"])
    for lt in it.lighting:
        add("lighting", lt, ex.get("lighting", ""))
    a = it.audio or {}
    if a.get("silent"):
        add("silence", "no_audio", ex.get("silence", ""))
    else:
        for src in a.get("ambience", []):
            add("audio", src, ex.get("audio:" + src, ""), audio_type="ambience")
        for src in a.get("sfx", []):
            add("audio", src, ex.get("audio:" + src, ""), audio_type="sfx")
    if a.get("music") is True and not a.get("silent"):
        add("music", "music", ex.get("music", ""))
    if a.get("music") is False:
        add("music", "no_music", ex.get("music", ""), negated=True)
    if it.narration is not None:
        add("narration", "narration", ex.get("narration", ""))
    for e in it.events:
        add("event", e.kind, e.text, order=e.order)
    if "style" in ex and it.style:
        add("style", it.style, ex["style"])
    if "duration" in ex and it.duration:
        add("duration", f"{it.duration:g}", ex["duration"])
    if "aspect_ratio" in ex and it.aspect_ratio:
        add("aspect_ratio", it.aspect_ratio, ex["aspect_ratio"])
    if it.scene_count > 1:
        add("multi_scene", str(it.scene_count), ex.get("multi_scene", ""))
    for c in it.constraints:
        if c == "identity_unsupported":
            add("constraint", c, ex.get("constraint", ""))
    return reqs
