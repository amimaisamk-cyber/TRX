# -*- coding: utf-8 -*-
"""
VideoIntent -- قراردادِ دادهٔ لایهٔ درکِ معنایی (بخشِ ۴ سندِ ارتقا).

هیچ planner بعدی نباید متنِ خامِ کاربر را دوباره تفسیر کند؛ همهٔ آنچه
لازم است در همین ساختار است. این فایل عمداً بدونِ منطقِ NLU است (فقط شکلِ
داده) تا مثلِ ``scene_schema.py`` مستقل و قابلِ تست بماند.

اصلِ کلیدی: هر فیلد دو حالتِ «صریحاً گفته شده» و «پیش‌فرض» دارد. فقط
موارد صریح به Requirement تبدیل می‌شوند (traceability)؛ پیش‌فرض‌ها هرگز
به‌عنوانِ خواستهٔ کاربر ادعا نمی‌شوند.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

# انواعِ requirement -- تنها فهرستِ مجازِ kind در کلِ خط‌لوله.
REQ_KINDS = (
    "subject", "environment", "weather", "time_of_day", "camera", "motion",
    "lighting", "audio", "silence", "narration", "music", "event", "style",
    "duration", "aspect_ratio", "multi_scene", "constraint",
)


@dataclass
class Uncertainty:
    field: str
    reason: str
    severity: str = "low"      # low | high  (high => ممکن است نیازِ به clarification)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class EventIntent:
    order: int                 # ترتیبِ ظهور در جمله (۰-پایه)
    kind: str                  # rain_start | rain_stop | thunder | lightning | time_transition | character_move | door_open | footsteps | scene_transition
    text: str                  # تکه‌ی متنِ مبدأ (شاهد)
    params: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class VideoIntent:
    raw_text: str
    language: str = "fa"                       # fa | en | mixed
    subject: str | None = None                 # house | character | tree | moon | object | ...
    environment: str | None = None
    location: str | None = None
    time_of_day: str | None = None             # dawn | day | sunset | dusk | night
    time_transition: tuple[str, str] | None = None   # ("day","night")
    weather: str | None = None                 # rain | snow | fog | clear
    style: str | None = None
    mood: str | None = None
    camera: dict[str, Any] = field(default_factory=dict)      # {move,target,speed,shot}
    motion: list[dict[str, Any]] = field(default_factory=list)  # [{subject,kind,direction,speed}]
    lighting: list[str] = field(default_factory=list)          # ["window_light", ...]
    audio: dict[str, Any] = field(default_factory=dict)        # {ambience:[..], sfx:[..], music:bool|None, silent:bool}
    narration: str | None = None
    dialogue: list[str] = field(default_factory=list)
    duration: float | None = None
    aspect_ratio: str | None = None
    fps: int | None = None
    scene_count: int = 1
    events: list[EventIntent] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)       # مثلاً "no:music"
    uncertainty: list[Uncertainty] = field(default_factory=list)
    confidence: float = 0.0
    # فیلد → تکه‌ی متنِ مبدأ؛ فقط مواردِ صریحاً بیان‌شده اینجا هستند.
    explicit: dict[str, str] = field(default_factory=dict)
    educational: bool = False
    historical: bool = False
    seed: int = 0

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["events"] = [e.to_dict() for e in self.events]
        d["uncertainty"] = [u.to_dict() for u in self.uncertainty]
        return d

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "VideoIntent":
        """بازسازیِ intent از JSON (برایِ patch/repair پس از restart). کلیدهایِ ناشناخته نادیده گرفته می‌شوند."""
        d = dict(d)
        fields = set(VideoIntent.__dataclass_fields__)
        d = {k: v for k, v in d.items() if k in fields}
        d["events"] = [EventIntent(**{k: v for k, v in e.items() if k in EventIntent.__dataclass_fields__})
                       for e in d.get("events", [])]
        d["uncertainty"] = [Uncertainty(**u) for u in d.get("uncertainty", [])]
        tt = d.get("time_transition")
        d["time_transition"] = tuple(tt) if tt else None
        return VideoIntent(**d)

    def semantic_key(self) -> str:
        """کلیدِ کش/seed بر پایهٔ *معنا* نه متنِ خام -- بخشِ ۳۱ (cache
        نباید تغییرِ prompt را نادیده بگیرد)."""
        import json
        d = self.to_dict()
        d.pop("raw_text", None)
        d.pop("explicit", None)   # شاهدهای متنی معنا نیستند
        return json.dumps(d, sort_keys=True, ensure_ascii=False, default=str)


@dataclass
class Requirement:
    """یک خواستهٔ قابلِ‌ردیابیِ کاربر (بخشِ ۱۹): REQ-001 subject=house ..."""

    id: str
    kind: str
    expected: str              # مقدارِ مورد انتظار (متنی، پایدار)
    evidence_text: str = ""    # تکه‌ی متنِ کاربر که این را ایجاد کرد
    params: dict[str, Any] = field(default_factory=dict)
    negated: bool = False      # «بدونِ موسیقی»: یعنی *نبودنِ* آن الزام است

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
