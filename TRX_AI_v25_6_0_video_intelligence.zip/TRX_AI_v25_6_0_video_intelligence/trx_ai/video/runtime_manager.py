# -*- coding: utf-8 -*-
"""
Runtime Manager -- بخش‌های ۲۲ و ۲۳ سندِ طراحی.

این تنها فایلی از ``trx_ai/video/`` است که ``core_engine/tool_router.py``
مستقیماً صدا می‌زند. طبقِ بخشِ ۲۲ («Core فقط باید درخواست را route کند،
ماژول را فراخوانی کند، نتیجه را بگیرد، خطا را مدیریت کند») -- core.py و
tool_router.py هیچ جزئیاتِ HTML/CSS/JS یا Scene Specification را
نمی‌بینند.

قراردادِ ورودی/خروجی دقیقاً بخشِ ۲۳ سندِ طراحی است.

محدودیت‌های صادقانه (باید در هر گزارشی ذکر شوند -- هیچ ادعایِ اضافه‌ای
اینجا وجود ندارد):
    - صدایِ محیطیِ underwater/rain/wind با Web Audio API واقعاً سنتز و
      پخش می‌شود (بدونِ فایل/دانلود)، اما به‌خاطرِ سیاستِ autoplayِ
      مرورگرها فقط بعد از اولین لمسِ کاربر شروع می‌شود. انواعِ دیگرِ صدا
      (مثلاً «موسیقی») هنوز سنتز نمی‌شوند -- فقط برچسب نمایش داده می‌شود.
    - ورودیِ تصویرِ مرجع (بخشِ ۳۴) و حلقه‌ی تکرارشونده‌ی ارزیابیِ کیفیت
      بر اساسِ رندرِ واقعی (بخش‌های ۳۳ تا ۴۲) در این نسخه پیاده نشده‌اند --
      نیازمندِ زیرساختِ رندر/ارزیابیِ بصری (مثلاً هدلس‌براوزر) هستند که در
      محیطِ Pydroid/Android بدونِ وابستگیِ سنگین عملی نیست.
    - چندصحنه‌ای/Storyboard (بخشِ ۲۶) و خروجیِ MP4/WebM (بخشِ ۲) پیاده
      نشده‌اند -- طبقِ خودِ سند این‌ها فازِ ۵ و ۶ هستند.
    - «فقط داخلِ TRX نمایش داده شود» (بخشِ ۱۶) در سطحِ sandboxِ iframe
      (بدونِ allow-same-origin/allow-top-navigation) پیاده شده، نه در
      سطحِ سیستم‌عامل -- دقیقاً همان محدودیتی که خودِ سند در پایانِ بخشِ ۱۶
      صریحاً اعتراف می‌کند.
"""

from __future__ import annotations

import os
import time

from ..logging_config import get_logger
from . import request_normalizer, scene_builder, html_generator, validator, fallback_renderer
from . import patch_engine, help_text, pipeline, explain
from .session_manager import get_default_store

logger = get_logger(__name__)

DEFAULT_QUALITY = "medium"


def _engine_mode() -> str:
    """TRX_VIDEO_ENGINE=legacy موتورِ قدیمی را اجباری می‌کند (kill-switch)؛ پیش‌فرض v2 با fallback به legacy."""
    return os.environ.get("TRX_VIDEO_ENGINE", "v2").strip().lower()


def _v2_success(session_id, store, build, mode, start, applied_patch_label=None) -> dict:
    project = build.project
    scene = project.scenes[0]
    html_path = _write_html(project.scenes[0].scene_id, build.html)
    store.save(session_id, scene, html_path, project)
    elapsed_ms = int((time.time() - start) * 1000)
    counts = {s: sum(r.status == s for r in build.results) for s in ("PASS", "FAIL", "UNSUPPORTED")}
    return {
        "status": "success", "scene_id": scene.scene_id, "html_path": html_path, "duration": project.total,
        "viewer_target": "trx_internal_viewer", "autoplay": True, "mode": mode, "applied_patch": applied_patch_label,
        "user_summary": explain.user_summary(build),
        "diagnostics": {
            "validation": "passed", "engine": "v2", "quality": scene.quality, "environment": scene.environment,
            "mood": scene.mood, "generation_ms": elapsed_ms, "spec_errors": [], "scenes": len(project.scenes),
            "build_status": build.status, "requirements": counts, "repair_rounds": len(build.repairs),
            "degradations": [d.to_dict() for d in build.degradations], "stage_ms": build.stage_ms,
            "quality_report": build.report,
        },
    }


def _files_dir() -> str:
    try:
        from ..config import OS_FILES_DIR
        d = os.path.join(OS_FILES_DIR, "video_scenes")
    except ImportError:
        d = os.path.join("files", "video_scenes")
    os.makedirs(d, exist_ok=True)
    return d


def _write_html(scene_id: str, html: str) -> str:
    path = os.path.join(_files_dir(), f"{scene_id}.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path


def _generate_and_validate(scene, attempt_label: str) -> tuple[str, dict]:
    html = html_generator.generate_html(scene)
    report = validator.validate_html(html)
    logger.info("[video] validation(%s) scene=%s passed=%s issues=%s",
                attempt_label, scene.scene_id, report["passed"], report["issues"])
    return html, report


def handle_video_request(session_id: str, intent: str, raw_text: str) -> dict:
    """قراردادِ ورودی/خروجیِ بخشِ ۲۳ -- برگرداندنِ دیکشنری، هرگز raise نمی‌کند.

    این تابع sync و بدونِ I/O شبکه‌ای است (فقط CPU سبک + نوشتنِ فایلِ
    محلی)، پس نیازی به async ندارد -- در ``tool_router.py`` (که async
    است) بدونِ مشکل صدا زده می‌شود.
    """
    start = time.time()
    logger.info("[video] request_received session=%s intent=%s text=%.80s", session_id, intent, raw_text)
    store = get_default_store()
    existing = store.get(session_id)

    try:
        normalized = request_normalizer.normalize_request(raw_text)
        patch_op = patch_engine.detect_patch_operation(request_normalizer.normalize_text(raw_text))

        mode = "create"
        applied_patch_label = None
        gen_cue = request_normalizer.has_generation_cue(raw_text)

        if intent == "video_help":
            return {"status": "help", "message": help_text.help_message()}

        if gen_cue or (existing is None and intent == "video_generation"):
            # ساختِ صحنه‌ی جدید -- صراحتِ «بساز + ویدیو» بر هر حدسِ «اصلاح» غلبه دارد.
            if _engine_mode() != "legacy":
                try:
                    build = pipeline.build_video(raw_text, quality=None)
                    return _v2_success(session_id, store, build, "create", start)
                except Exception:  # noqa: BLE001 -- fail-open: خطایِ v2 → مسیرِ legacyِ دست‌نخورده
                    logger.exception("[video] v2 pipeline شکست خورد؛ fallback به legacy")
            scene = scene_builder.build_scene(normalized, quality=DEFAULT_QUALITY)
            mode = "create"
        elif existing is not None and patch_op:
            scene = existing.scene
            applied_patch_label = patch_engine.describe_operation(patch_op)
            mode = "patch"
            if getattr(existing, "project", None) is not None:
                try:
                    for sc in existing.project.scenes:
                        patch_engine.apply_patch(sc, patch_op)
                    html2, results2, report2 = pipeline.rebuild_after_patch(existing.project)
                    p2 = existing.project
                    path2 = _write_html(p2.scenes[0].scene_id, html2)
                    store.save(session_id, p2.scenes[0], path2, p2)
                    return {"status": "success", "scene_id": p2.scenes[0].scene_id, "html_path": path2,
                            "duration": p2.total, "viewer_target": "trx_internal_viewer", "autoplay": True,
                            "mode": "patch", "applied_patch": applied_patch_label,
                            "diagnostics": {"validation": "passed", "engine": "v2", "quality": p2.scenes[0].quality,
                                            "environment": p2.scenes[0].environment, "mood": p2.scenes[0].mood,
                                            "generation_ms": int((time.time() - start) * 1000), "spec_errors": [],
                                            "requirements": {s: sum(r.status == s for r in results2) for s in ("PASS", "FAIL", "UNSUPPORTED")},
                                            "quality_report": report2}}
                except Exception:  # noqa: BLE001
                    logger.exception("[video] v2 patch شکست خورد؛ بازگشت به legacy روی صحنهٔ اول")
            patch_engine.apply_patch(scene, patch_op)
        elif existing is None:
            # هیچ صحنه‌ای برایِ اصلاح نیست و جمله هم درخواستِ ساخت نیست
            # (مثلاً «نور خونه رو روشن کن») -- ساختنِ صحنه‌ی بی‌ربط غلط است؛
            # به‌جایش راهنمایی با مثال می‌دهیم.
            logger.info("[video] edit بدونِ صحنه‌ی فعال -- ارائه‌ی راهنما")
            return {
                "status": "needs_clarification",
                "message": help_text.no_scene_message(),
                "diagnostics": {"reason": "video_edit_scene_without_active_session"},
            }
        else:
            # صحنه هست ولی این تغییر را نمی‌شناسیم. بازسازیِ تصادفی (که
            # محیط را به «اتاق» برمی‌گرداند) مخرب است؛ صادقانه فهرستِ
            # تغییرهایِ ممکن را نشان می‌دهیم.
            return {
                "status": "needs_clarification",
                "message": help_text.unsupported_edit_message(),
                "diagnostics": {"reason": "unsupported_edit"},
            }

        errors = scene.validate()
        if errors:
            logger.warning("[video] scene_spec invalid: %s", errors)
            # اسپکِ نامعتبر -- به‌جایِ رد کردنِ کاملِ درخواست، به مقادیرِ
            # امن‌تر برمی‌گردیم (کیفیتِ متوسط، مدتِ پیش‌فرض) به‌جایِ crash.
            scene.quality = DEFAULT_QUALITY
            scene.duration = max(2.0, min(20.0, scene.duration))

        html, report = _generate_and_validate(scene, "first")
        if not report["passed"]:
            # تلاشِ دوم: کیفیت را پایین می‌آوریم (اغلبِ خرابی‌ها از حجمِ
            # زیاد/ذراتِ زیاد است) -- بخشِ ۱۸: «AI فقط بخشِ خراب را اصلاح کند».
            scene.quality = "low"
            html, report = _generate_and_validate(scene, "retry_low_quality")

        if not report["passed"]:
            html = fallback_renderer.render_fallback(
                scene.scene_id, "; ".join(report["issues"])[:200], duration=min(scene.duration, 4.0)
            )
            report = {"passed": True, "issues": [], "fallback_used": True}
        else:
            report["fallback_used"] = False

        html_path = _write_html(scene.scene_id, html)
        store.save(session_id, scene, html_path)

        elapsed_ms = int((time.time() - start) * 1000)
        logger.info("[video] scene_ready id=%s mode=%s ms=%d", scene.scene_id, mode, elapsed_ms)

        return {
            "status": "success",
            "scene_id": scene.scene_id,
            "html_path": html_path,
            "duration": scene.duration,
            "viewer_target": "trx_internal_viewer",
            "autoplay": True,
            "mode": mode,
            "applied_patch": applied_patch_label,
            "diagnostics": {
                "validation": "passed" if not report.get("fallback_used") else "fallback_used",
                "quality": scene.quality,
                "environment": normalized.get("environment"),
                "mood": scene.mood,
                "generation_ms": elapsed_ms,
                "spec_errors": errors,
            },
        }

    except Exception as exc:  # noqa: BLE001 -- این مرزِ خطا هرگز نباید کلِ core را کرش کند
        logger.exception("[video] unhandled error while generating scene")
        return {
            "status": "error",
            "error_type": "generation_failed",
            "message": str(exc),
            "recoverable": True,
            "fallback_available": False,
        }
