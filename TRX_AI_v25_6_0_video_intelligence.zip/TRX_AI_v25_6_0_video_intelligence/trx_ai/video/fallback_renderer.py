# -*- coding: utf-8 -*-
"""
Fallback Renderer -- بخشِ ۱۸ سندِ طراحی («در صورتِ شکست، نسخه‌ی ساده‌تر
تولید شود») + فلسفه‌ی کلیِ پروژه («بدونِ API/در صورتِ خطا، کرش نکند»).

این تابع کاملاً مستقل از html_generator.py است -- یک تمپلیتِ ثابت و
دستی که هیچ‌وقت validator را رد نمی‌کند، چون هرگز تغییر نمی‌کند. اگر
تولیدِ صحنه‌ی اصلی دو بار پشتِ سرِ هم شکست خورد، این نسخه تحویل داده
می‌شود تا کاربر با یک خطایِ خام یا صفحه‌ی سفید مواجه نشود.
"""

from __future__ import annotations

import html as _html


def render_fallback(scene_id: str, reason: str, duration: float = 4.0) -> str:
    safe_reason = _html.escape(reason)[:200]
    return f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>TRX Scene {scene_id} (fallback)</title>
<style>
  html, body {{ margin:0; padding:0; height:100%; background:#101014; color:#ddd;
                font-family: Tahoma, sans-serif; display:flex; align-items:center;
                justify-content:center; text-align:center; }}
  #scene-root {{ opacity:0; transition:opacity .8s ease-in-out; padding:24px; max-width:80vw; }}
  #dot {{ width:14px; height:14px; border-radius:50%; background:#5fd6e8; margin:0 auto 14px;
          animation: pulse 1.6s ease-in-out infinite; }}
  @keyframes pulse {{ 0%,100% {{ opacity:.4; transform:scale(1);}} 50%{{opacity:1; transform:scale(1.4);}} }}
</style>
</head>
<body>
  <div id="scene-root">
    <div id="dot"></div>
    <div>ساختِ صحنه‌ی کامل ممکن نشد؛ این یک نسخه‌ی جایگزینِ ساده و ایمن است.</div>
    <div style="font-size:12px;opacity:.6;margin-top:8px;">دلیل: {safe_reason}</div>
  </div>
<script>
"use strict";
document.getElementById("scene-root").style.opacity = "1";
setTimeout(function () {{
  document.getElementById("scene-root").style.opacity = "0.5";
}}, {int(duration * 1000)});
requestAnimationFrame(function(){{}});
</script>
</body>
</html>
"""
