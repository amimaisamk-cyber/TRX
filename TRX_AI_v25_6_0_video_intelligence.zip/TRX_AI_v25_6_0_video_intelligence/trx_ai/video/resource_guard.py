# -*- coding: utf-8 -*-
"""
Resource Guard (بخش‌هایِ ۲۷ تا ۳۱ سندِ ارتقا): بودجهٔ منبع، degradation اولویت‌دار، لغو/timeout، cache.

اصلِ degradation: ابتدا جزئیاتِ *فرعی* کم می‌شوند؛ سوژه، حرکتِ درخواستی، نورِ درخواستی،
صدایِ صریح، روایت و رویدادهایِ درخواست‌شده هرگز حذف نمی‌شوند. هر کاهش ثبت و به کاربر گزارش می‌شود.
"""

from __future__ import annotations

import copy
import hashlib
import os
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, asdict
from typing import Any

from . import scene_planner as sp

# cost = pix * (1 + decor*0.04 + particles*0.01 + nodes*0.1)  ، pix = (w*h)/(640*360)
PROFILES: dict[str, dict[str, Any]] = {
    "low":    {"max_cost": 5.0,  "max_ram_mb": 60,  "min_long_side": 480},
    "medium": {"max_cost": 11.0, "max_ram_mb": 140, "min_long_side": 480},
    "high":   {"max_cost": 26.0, "max_ram_mb": 320, "min_long_side": 640},
}


def choose_profile(requested: str | None = None) -> str:
    p = requested or os.environ.get("TRX_VIDEO_PROFILE", "medium")
    return p if p in PROFILES else "medium"


class VideoCancelled(RuntimeError):
    pass


class VideoTimeout(RuntimeError):
    pass


class CancelToken:
    """لغوِ همکارانه + مهلتِ زمانی؛ pipeline بینِ مرحله‌ها ``check()`` می‌زند (بخشِ ۲۹)."""

    def __init__(self, timeout_s: float | None = None):
        self._ev = threading.Event()
        self._deadline = (time.monotonic() + timeout_s) if timeout_s else None

    def cancel(self) -> None:
        self._ev.set()

    @property
    def cancelled(self) -> bool:
        return self._ev.is_set()

    def check(self, stage: str = "") -> None:
        if self._ev.is_set():
            raise VideoCancelled(f"لغو شد (مرحله: {stage})")
        if self._deadline is not None and time.monotonic() > self._deadline:
            raise VideoTimeout(f"مهلتِ زمانی تمام شد (مرحله: {stage})")


@dataclass
class Degradation:
    step: str
    detail: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _scene_stats(scene) -> dict[str, float]:
    rs = scene.render_scale or {"w": 960, "h": 540}
    pix = (rs["w"] * rs["h"]) / (640 * 360)
    env = next((n for n in scene.graph.get("nodes", []) if n["id"] == "env"), None)
    wx = next((n for n in scene.graph.get("nodes", []) if n["id"] == "weather"), None)
    decor = len(env["visual_properties"]["decor"]) if env else 0
    particles = wx["visual_properties"]["count"] if wx else 0
    nodes = len(scene.graph.get("nodes", []))
    cost = pix * (1 + decor * 0.04 + particles * 0.01 + nodes * 0.1)
    ram = rs["w"] * rs["h"] * 4 * 3 / 1e6 + decor * 0.02 + len(scene.audio.events) * 0.05
    return {"pix": pix, "decor": decor, "particles": particles, "nodes": nodes, "cost": cost, "ram_mb": ram}


def estimate(project) -> dict[str, Any]:
    st = [_scene_stats(s) for s in project.scenes]
    return {"cost": round(max(x["cost"] for x in st), 2), "ram_mb": round(max(x["ram_mb"] for x in st), 1),
            "decor": sum(x["decor"] for x in st), "particles_max": max(x["particles"] for x in st),
            "audio_events": sum(len(s.audio.events) for s in project.scenes),
            "timeline_events": sum(len(s.timeline) for s in project.scenes), "scenes": len(project.scenes)}


def _over(project, budget) -> bool:
    e = estimate(project)
    return e["cost"] > budget["max_cost"] or e["ram_mb"] > budget["max_ram_mb"]


def degrade(project, profile: str) -> list[Degradation]:
    """تا رسیدن به بودجه، به ترتیبِ اولویت کاهش می‌دهد. خروجی: فهرستِ کاهش‌ها (خالی = بدونِ تغییر)."""
    budget = PROFILES[profile]
    out: list[Degradation] = []
    if not _over(project, budget):
        return out
    # 1) decorِ لایهٔ far (کم‌اهمیت‌ترین)
    for sc in project.scenes:
        g = sp.load_graph(sc)
        env = g.get("env")
        if env:
            dec = env.visual_properties["decor"]
            keep = [d for i, d in enumerate(dec) if d["layer"] != "far" or i % 2 == 0]
            if len(keep) < len(dec):
                env.visual_properties["decor"] = keep
                sp.save_graph(sc, g)
                out.append(Degradation("reduce_far_decor", f"{sc.scene_id}: {len(dec)}→{len(keep)}", "بودجهٔ رندر"))
    if not _over(project, budget):
        return out
    # 2) ذراتِ آب‌وهوا
    for sc in project.scenes:
        g = sp.load_graph(sc)
        w = g.get("weather")
        if w and w.visual_properties["count"] > 40:
            old = w.visual_properties["count"]
            w.visual_properties["count"] = max(40, int(old * 0.5))
            sp.save_graph(sc, g)
            out.append(Degradation("reduce_particles", f"{sc.scene_id}: {old}→{w.visual_properties['count']}", "بودجهٔ رندر"))
    # 3) رزولوشنِ داخلی (تدریجی تا کفِ پروفایل)
    while _over(project, budget):
        changed = False
        for sc in project.scenes:
            rs = sc.render_scale
            if rs and max(rs["w"], rs["h"]) * 0.85 >= budget["min_long_side"]:
                sc.render_scale = {"w": int(rs["w"] * 0.85), "h": int(rs["h"] * 0.85)}
                changed = True
        if not changed:
            break
        out.append(Degradation("reduce_render_scale", "×0.85", "بودجهٔ رندر"))
    # 4) صداهایِ *پیش‌فرض* (نه صریح): قدم‌هایِ خودکار و ambienceِ پیش‌فرض
    if _over(project, budget):
        for sc in project.scenes:
            before = len(sc.audio.events)
            sc.audio.events = [e for e in sc.audio.events if not e.get("default")]
            if len(sc.audio.events) < before:
                out.append(Degradation("drop_default_audio", f"{sc.scene_id}: {before - len(sc.audio.events)} event", "بودجهٔ منبع"))
    return out


class PlanCache:
    """LRU برایِ *برنامه* (نه HTML). کلید = معنا + پروفایل، پس تغییرِ prompt هرگز نادیده نمی‌ماند (بخشِ ۳۱)."""

    def __init__(self, size: int = 16):
        self._d: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._size, self.hits, self.misses = size, 0, 0
        self._lock = threading.Lock()

    @staticmethod
    def key(semantic_key: str, profile: str) -> str:
        return hashlib.sha1(f"{profile}|{semantic_key}".encode("utf-8")).hexdigest()

    def get(self, key: str) -> dict[str, Any] | None:
        with self._lock:
            v = self._d.get(key)
            if v is None:
                self.misses += 1
                return None
            self._d.move_to_end(key)
            self.hits += 1
            return copy.deepcopy(v)

    def put(self, key: str, value: dict[str, Any]) -> None:
        with self._lock:
            self._d[key] = copy.deepcopy(value)
            self._d.move_to_end(key)
            while len(self._d) > self._size:
                self._d.popitem(last=False)


DEFAULT_CACHE = PlanCache()
