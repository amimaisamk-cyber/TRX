# -*- coding: utf-8 -*-
"""
Scene Session Manager -- بخشِ ۲۰ سندِ طراحی.

هر نشست (session_id -- همان چیزی که در core.py با ``ai.session_mgr.active_session``
شناخته می‌شود) آخرین SceneSpec و مسیرِ آخرین HTML را نگه می‌دارد تا
درخواست‌هایِ بعدی («دوربین را نزدیک‌تر کن») بتوانند رویِ همان صحنه اصلاح
انجام دهند، نه یک صحنه‌ی کاملاً تازه.

پیاده‌سازیِ v1: نگهداریِ در حافظه (dict) + ذخیره‌ی اختیاریِ روی دیسک
(JSON) تا با ری‌استارتِ برنامه (که در Android/Pydroid محتمل است) کاملاً
از دست نرود. این هنوز «حافظه‌ی کوتاه‌مدتِ نشست» است، نه یک دیتابیسِ کامل
-- فراتر از آن (چندکاربره/چندصحنه‌ای) در بخشِ ۲۶ آمده و در این نسخه
پیاده نشده.
"""

from __future__ import annotations

import json
import os
import threading
from typing import Optional

from .scene_schema import SceneSpec

_LOCK = threading.Lock()


class SceneSession:
    __slots__ = ("session_id", "scene", "html_path", "last_patch", "project")

    def __init__(self, session_id: str, scene: SceneSpec, html_path: str, project=None):
        self.session_id = session_id
        self.scene = scene
        self.html_path = html_path
        self.last_patch: dict | None = None
        # v25.6.0: پروژهٔ چندصحنه‌ایِ موتورِ v2؛ None برایِ صحنه‌هایِ legacy (سازگارِ عقب‌رو).
        self.project = project


class SceneSessionStore:
    """نگهداریِ درون‌حافظه‌ایِ آخرین صحنه‌ی هر نشست + persist اختیاری."""

    def __init__(self, persist_path: Optional[str] = None):
        self._sessions: dict[str, SceneSession] = {}
        self._persist_path = persist_path
        if persist_path:
            self._load()

    def get(self, session_id: str) -> SceneSession | None:
        with _LOCK:
            return self._sessions.get(session_id)

    def save(self, session_id: str, scene: SceneSpec, html_path: str, project=None) -> None:
        with _LOCK:
            self._sessions[session_id] = SceneSession(session_id, scene, html_path, project)
            self._persist()

    def clear(self, session_id: str) -> None:
        with _LOCK:
            self._sessions.pop(session_id, None)
            self._persist()

    def _persist(self) -> None:
        if not self._persist_path:
            return
        try:
            data = {
                sid: {"scene": s.scene.to_dict(), "html_path": s.html_path,
                      **({"project": s.project.to_dict()} if s.project is not None else {})}
                for sid, s in self._sessions.items()
            }
            os.makedirs(os.path.dirname(self._persist_path) or ".", exist_ok=True)
            with open(self._persist_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except OSError:
            # عمداً بی‌صدا -- شکستِ persist نباید تولیدِ صحنه را متوقف کند
            # (فلسفه‌ی fallback عمومیِ پروژه).
            pass

    def _load(self) -> None:
        try:
            if not os.path.exists(self._persist_path):
                return
            with open(self._persist_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for sid, entry in data.items():
                scene = SceneSpec.from_dict(entry["scene"])
                project = None
                if entry.get("project"):
                    from .project import VideoProject
                    project = VideoProject.from_dict(entry["project"])
                    scene = project.scenes[0]       # هویتِ واحد: session.scene همان صحنهٔ اولِ پروژه است
                self._sessions[sid] = SceneSession(sid, scene, entry.get("html_path", ""), project)
        except (OSError, json.JSONDecodeError, KeyError, TypeError):
            # فایلِ خراب/قدیمی نباید کلِ برنامه را کرش کند.
            self._sessions = {}


# نمونه‌ی singleton برایِ استفاده‌ی مستقیم در runtime_manager -- مسیرِ
# ذخیره‌سازی از خودِ config پروژه (OS_FILES_DIR) گرفته می‌شود تا با بقیه‌ی
# فایل‌های تولیدی هماهنگ باشد؛ این importِ دیرهنگام (lazy) عمداً است تا
# این ماژول بدونِ core.py هم قابلِ تست باشد.
_default_store: SceneSessionStore | None = None


def get_default_store() -> SceneSessionStore:
    global _default_store
    if _default_store is None:
        try:
            from ..config import OS_FILES_DIR
            persist_path = os.path.join(OS_FILES_DIR, "video_scenes", "_sessions.json")
        except ImportError:
            persist_path = None
        _default_store = SceneSessionStore(persist_path=persist_path)
    return _default_store
