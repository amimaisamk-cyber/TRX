# -*- coding: utf-8 -*-
"""
Patch Engine -- بخشِ ۲۱ سندِ طراحی.

مسئولیت: فهمیدنِ اینکه یک جمله‌ی کوتاهِ کاربر («فقط نور را کم کن»،
«دوربین را نزدیک‌تر کن»، «همین را شب کن»، «آهسته‌ترش کن») کدام بخشِ
SceneSpecِ موجود را باید تغییر دهد -- بدونِ فهمِ مجددِ کلِ صحنه.

صداقتِ فنی: این پیاده‌سازی *واقعاً* SceneSpec را patch می‌کند (شیءِ
Python را در‌جا تغییر می‌دهد)، اما تولیدِ HTMLِ نهایی همچنان با فراخوانیِ
کاملِ ``html_generator.generate_html`` روی SceneSpecِ patch‌شده انجام
می‌شود -- چون Generator فعلی قالب‌محور و بسیار سریع (میلی‌ثانیه، بدونِ
API) است، بازتولیدِ کاملِ HTML از رویِ یک Spec که فقط یک فیلد در آن
عوض شده، نه پرهزینه است و نه خطرناک. آنچه بخشِ ۲۱ واقعاً می‌خواهد
جلوگیری کند -- یعنی «فهمِ دوبارهٔ کاملِ نیتِ کاربر / بازسازیِ صحنه از
صفر» -- همینجا رخ نمی‌دهد: Understanding دوباره اجرا نمی‌شود، فقط یک
تابعِ کوچکِ patch رویِ Specِ ذخیره‌شده.
"""

from __future__ import annotations

from .scene_schema import SceneSpec
from . import camera_planner, lighting_planner

# هر ورودی: (کلیدواژه‌ها, تابعِ اعمال)
_PATCH_RULES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("نور را کم", "نور رو کم", "کم‌نورتر", "کم نورتر"), "dim_light"),
    (("نور را زیاد", "نور رو زیاد", "روشن‌تر", "روشن تر"), "brighten_light"),
    (("تاریک‌تر", "تاریک تر", "شب کن", "شبش کن", "همین را شب کن", "همین رو شب کن", "همینو شب کن"), "darken_mood"),
    (("دوربین را نزدیک", "دوربین رو نزدیک", "نزدیک‌تر کن", "نزدیک تر کن"), "camera_closer"),
    (("دوربین را دور", "دوربین رو دور", "دورتر کن"), "camera_farther"),
    (("آهسته‌تر", "آهسته تر", "کندتر"), "slow_down"),
    (("سریع‌تر", "تندتر"), "speed_up"),
    (("مه را کم", "مه رو کم", "کم‌مه‌تر"), "reduce_fog"),
)


def detect_patch_operation(text: str) -> str | None:
    for keywords, op in _PATCH_RULES:
        for kw in keywords:
            if kw in text:
                return op
    return None


def _scale_motion_events(scene: SceneSpec, factor: float) -> None:
    """صحنه‌هایِ v2: سرعتِ حرکتِ شخصیت در Timeline است (نه velocity) -- مدتِ بازه را مقیاس می‌کنیم،
    در محدودهٔ صحنه. صدایِ قدم‌ها بعد از patch توسطِ pipeline.rebuild_after_patch هم‌گام می‌شود."""
    for e in scene.timeline:
        if e.event == "motion" and e.duration > 0:
            e.duration = round(max(0.5, min(scene.duration - e.time - 0.2, e.duration * factor)), 3)


def apply_patch(scene: SceneSpec, operation: str) -> SceneSpec:
    """Spec را در‌جا تغییر می‌دهد و همان را برمی‌گرداند."""
    if operation == "dim_light":
        lighting_planner.apply_edit(scene.lighting, dimmer=True)
    elif operation == "brighten_light":
        lighting_planner.apply_edit(scene.lighting, brighter=True)
    elif operation == "darken_mood":
        lighting_planner.apply_edit(scene.lighting, darker_mood=True)
        scene.mood = "dark"
        scene.color_mood = "dark"
    elif operation == "camera_closer":
        camera_planner.apply_edit(scene.camera, closer=True)
    elif operation == "camera_farther":
        camera_planner.apply_edit(scene.camera, farther=True)
    elif operation == "slow_down":
        for obj in scene.objects:
            obj.velocity = round(max(0.05, obj.velocity * 0.7), 3)
        _scale_motion_events(scene, 1 / 0.7)
    elif operation == "speed_up":
        for obj in scene.objects:
            obj.velocity = round(min(3.0, obj.velocity * 1.4), 3)
        _scale_motion_events(scene, 1 / 1.4)
    elif operation == "reduce_fog":
        scene.lighting.fog = False
    return scene


_OP_LABELS = {
    "dim_light": "نور کم شد",
    "brighten_light": "نور زیاد شد",
    "darken_mood": "حسِ صحنه تاریک‌تر شد",
    "camera_closer": "دوربین نزدیک‌تر شد",
    "camera_farther": "دوربین دورتر شد",
    "slow_down": "حرکت‌ها آهسته‌تر شدند",
    "speed_up": "حرکت‌ها سریع‌تر شدند",
    "reduce_fog": "مه کم شد",
}


def describe_operation(operation: str) -> str:
    return _OP_LABELS.get(operation, operation)
