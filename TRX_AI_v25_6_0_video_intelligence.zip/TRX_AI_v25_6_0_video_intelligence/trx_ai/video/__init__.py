# -*- coding: utf-8 -*-
"""
TRX HTML Video / Scene Engine -- پیاده‌سازیِ فازِ ۱ (+ بخشی از فازِ ۲) از
سندِ طراحیِ «TRX HTML Video Engine Upgrade Design».

نقطه‌ی ورودِ عمومی همان چیزی‌ست که ``core_engine/tool_router.py`` استفاده
می‌کند: ``runtime_manager.handle_video_request``.

فایل‌های این پکیج (نگاه کنید به بخشِ ۲۲ سندِ طراحی برایِ نقشه‌ی کاملِ
پیشنهادی -- این‌ها زیرمجموعه‌ی پیاده‌سازی‌شده‌ی همان نقشه‌اند):
    scene_schema.py        داده‌ی صحنه (SceneSpec)
    request_normalizer.py  فهمِ درخواستِ خام
    scene_builder.py       ساختِ SceneSpec از رویِ درخواست
    motion_planner.py      حرکتِ هر شیء
    camera_planner.py      دوربینِ مجازی
    lighting_planner.py    نور/مه/تراکمِ ذرات
    html_generator.py      تولیدِ HTML/CSS/JSِ خودکفا
    validator.py           اعتبارسنجیِ ایمنی/ساختار
    fallback_renderer.py   نسخه‌ی امنِ جایگزین در صورتِ شکست
    session_manager.py     حافظه‌ی صحنه‌ی هر نشست
    patch_engine.py        اصلاحِ موضعی به‌جایِ بازسازیِ کامل
    runtime_manager.py     هماهنگ‌کننده‌ی نهایی (قراردادِ Core)

پیاده‌نشده در این نسخه (به‌صراحت، نه به‌صورتِ ادعایِ پنهان): تحلیلِ
تصویرِ مرجع، حلقه‌ی خودارزیابِ کیفیت با رندرِ واقعی، چندصحنه‌ای/Storyboard،
خروجیِ MP4/WebM. صدا: underwater/rain/wind با Web Audio سنتز و پخش
می‌شوند (بعد از اولین لمسِ کاربر)؛ سایرِ انواعِ صدا (موسیقی و ...) هنوز
سنتز نمی‌شوند و فقط برچسب دارند.
"""

from .runtime_manager import handle_video_request

__all__ = ["handle_video_request"]
