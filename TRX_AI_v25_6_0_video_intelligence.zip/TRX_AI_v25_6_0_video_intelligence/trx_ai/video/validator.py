# -*- coding: utf-8 -*-
"""
Code Safety Validator -- بخش‌های ۱۷ و ۱۸ سندِ طراحی.

این ماژول قبل از رساندنِ HTMLِ تولیدشده به نمایشگر، آن را از نظرِ ایمنی و
سلامتِ ساختاری بررسی می‌کند. چون در معماریِ v1، ``html_generator.py`` خودش
یک قالبِ ثابت و کنترل‌شده است (نه تولیدِ آزادِ یک LLM)، این اعتبارسنجی هم
مثلِ یک «شبکه‌ی ایمنیِ دوم» عمل می‌کند: اگر روزی Generator عوض شود یا یک
مسیرِ داده‌محورِ ناخواسته کدِ ناایمن تولید کند، همین‌جا گرفته می‌شود.

خروجی: دیکشنریِ ``{"passed": bool, "issues": [...]}`` -- دقیقاً همان شکلی
که بخشِ ۲۹ (سیستمِ تستِ خودکار) و بخشِ ۳۰ (دیاگنوستیک) انتظار دارند.
"""

from __future__ import annotations

import re

MAX_HTML_BYTES = 300_000
MAX_PARTICLE_COUNT_HINT = 80  # فقط برایِ هشدار، سقفِ واقعی در html_generator اعمال می‌شود.

_FORBIDDEN_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"\beval\s*\(", "استفاده از eval() ممنوع است."),
    (r"new\s+Function\s*\(", "استفاده از Function constructor ممنوع است."),
    (r"\bfetch\s*\(", "درخواستِ شبکه‌ای (fetch) در صحنه‌ی داخلی مجاز نیست."),
    (r"XMLHttpRequest", "XMLHttpRequest مجاز نیست."),
    (r"window\.open\s*\(", "window.open مجاز نیست."),
    (r"document\.write\s*\(", "document.write مجاز نیست (خطرِ تزریق)."),
    (r"<iframe", "iframe داخلِ صحنه مجاز نیست."),
    (r'<script[^>]+src=["\']https?://', "بارگذاریِ اسکریپتِ خارجی مجاز نیست."),
    (r'href=["\']https?://', "لینکِ خارجی در صحنه مجاز نیست."),
    (r"postMessage\s*\(", "استفاده از postMessage در این نسخه مجاز نیست."),
    (r"localStorage|sessionStorage|indexedDB", "دسترسی به ذخیره‌سازیِ مرورگر در این ماژول لازم/مجاز نیست."),
)

_REQUIRED_MARKERS: tuple[tuple[str, str], ...] = (
    ("<!DOCTYPE html>", "برچسبِ DOCTYPE وجود ندارد."),
    ("<body>", "تگِ body وجود ندارد."),
    ('id="scene-root"', "عنصرِ scene-root (ریشه‌ی صحنه) وجود ندارد."),
    ("requestAnimationFrame", "حلقه‌ی انیمیشن (requestAnimationFrame) پیدا نشد."),
    ('name="viewport"', "متاتگِ viewport برایِ سازگاریِ موبایل وجود ندارد."),
)


def validate_html(html: str) -> dict:
    issues: list[str] = []

    size = len(html.encode("utf-8"))
    if size > MAX_HTML_BYTES:
        issues.append(f"حجمِ HTML ({size} بایت) از سقفِ مجاز ({MAX_HTML_BYTES}) بیشتر است.")

    for pattern, message in _FORBIDDEN_PATTERNS:
        if re.search(pattern, html, flags=re.IGNORECASE):
            issues.append(message)

    for marker, message in _REQUIRED_MARKERS:
        if marker not in html:
            issues.append(message)

    # بررسیِ سطحی/تقریبیِ بسته‌بودنِ تگ‌های اصلی (نه یک HTML parser کامل --
    # هدف گرفتنِ خطاهایِ فاحش است، نه اعتبارسنجیِ کاملِ استاندارد).
    for tag in ("html", "head", "body"):
        if html.count(f"<{tag}") != html.count(f"</{tag}>"):
            issues.append(f"تگِ <{tag}> به‌نظر بسته نشده است.")

    return {"passed": len(issues) == 0, "issues": issues, "size_bytes": size}
