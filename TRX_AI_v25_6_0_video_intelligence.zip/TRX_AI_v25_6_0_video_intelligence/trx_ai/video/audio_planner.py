# -*- coding: utf-8 -*-
"""
Audio Planner (بخش‌های ۱۳ تا ۱۶ سندِ ارتقا).

Audio Plan → Synth recipe → Timeline → WebAudio playback → Sync validation.
هیچ eventِ صدایی «فقط برایِ schema» وجود ندارد: هر source ای که اینجا برنامه‌ریزی
می‌شود یا در ``SYNTH_RECIPES`` (و مرجعِ JS همان‌ها) پیاده شده، یا صراحتاً
``unavailable:<reason>`` ثبت می‌شود -- هرگز silent success.
"""

from __future__ import annotations

from typing import Any

from .scene_schema import AudioSpec
from . import timeline_engine as tl

# منبعِ حقیقتِ recipeهایِ سنتز؛ renderer باید برایِ هرکدام پیاده‌سازیِ JS داشته باشد (تستِ قراردادی).
SYNTH_RECIPES: dict[str, str] = {
    "rain": "ambience", "wind": "ambience", "underwater": "ambience", "city": "ambience", "forest": "ambience",
    "thunder": "sfx", "footstep": "sfx", "door": "sfx",
    "ambient_pad": "music", "tts": "narration",
}
_SOURCE_ALIAS = {"footsteps": "footstep"}
SYNC_TOLERANCE_S = 1.0          # بیشینهٔ فاصلهٔ مجازِ صدا و رویدادِ تصویری
THUNDER_DELAY_S = 0.35          # نور سریع‌تر از صدا؛ تاخیرِ ثابتِ قابلِ‌تست
_FA_WPS = 2.3                   # کلمه/ثانیه (تخمینِ روایتِ فارسی)
_EN_WPS = 2.8

REQUIRED_EVENT_FIELDS = ("id", "type", "source", "start", "duration", "volume", "loop",
                         "fade_in", "fade_out", "spatial_hint", "trigger")

_ENV_TO_AMBIENCE = {"forest": "forest", "city": "city", "futuristic_city": "city", "street": "city",
                    "underwater": "underwater", "desert": "wind", "mountain": "wind"}


def _ev(eid: str, typ: str, source: str, start: float, duration: float, volume: float, *, loop: bool = False,
        fade_in: float = 0.0, fade_out: float = 0.0, spatial: str = "center", trigger: str = "timeline",
        default: bool = False) -> dict[str, Any]:
    return {"id": eid, "type": typ, "source": source, "start": round(max(0.0, start), 3),
            "duration": round(max(0.05, duration), 3), "volume": round(volume, 3), "loop": loop,
            "fade_in": round(fade_in, 3), "fade_out": round(fade_out, 3), "spatial_hint": spatial,
            "trigger": trigger, "default": default, "synth": source}


def estimate_narration_seconds(text: str, lang: str = "fa") -> float:
    words = max(1, len(text.split()))
    return words / (_FA_WPS if lang != "en" else _EN_WPS)


def weather_span(scene, weather: str = "rain") -> tuple[float, float] | None:
    """بازهٔ واقعیِ فعال‌بودنِ آب‌وهوا از روی Timeline (نه حدس)."""
    evs = tl.events_for(scene.timeline, target="weather", prop="intensity")
    if not evs:
        return None
    D = scene.duration
    samples = [i * D / 200 for i in range(201)]
    on = [t for t in samples if tl.value_at(scene.timeline, "weather", "intensity", t) > 0.05]
    if not on:
        return None
    return (on[0], on[-1] + D / 200)


def auto_narration_text(scene, lang: str = "fa") -> str:
    env = scene.environment or "forest"
    if lang == "en":
        t = {"night": "at night", "sunset": "at sunset", "dawn": "at dawn", "day": "by day", "dusk": "at dusk"}.get(scene.time_of_day, "")
        w = {"rain": " in the rain", "snow": " in the snow", "fog": " in the fog"}.get(scene.weather, "")
        return f"This scene shows {env.replace('_', ' ')} {t}{w}."
    envs = {"forest": "جنگل", "city": "شهر", "futuristic_city": "شهری آینده‌نگر", "desert": "کویر", "mountain": "کوهستان",
            "underwater": "زیر آب", "room": "یک اتاق", "laboratory": "آزمایشگاه", "village": "روستا", "street": "خیابان",
            "space": "فضا", "ancient_persia": "تخت جمشید", "water_cycle": "چرخهٔ آب", "sky": "آسمان",
            "night_sky": "آسمانِ شب", "rain_on_window": "پشتِ پنجره"}
    tod = {"night": "شب", "sunset": "هنگامِ غروب", "dawn": "سپیده‌دم", "day": "روز", "dusk": "گرگ‌ومیش"}.get(scene.time_of_day, "")
    w = {"rain": "در باران", "snow": "در برف", "fog": "در مه"}.get(scene.weather, "")
    return " ".join(x for x in (f"این صحنه {envs.get(env, 'یک مکان')} را", tod, w, "نشان می‌دهد.") if x)


def plan_audio(scene, intent, *, allow_auto_music: bool = False, mood: str = "calm") -> AudioSpec:
    """AudioSpec کاملِ صحنه را از intent + timeline می‌سازد (scene.timeline باید از قبل پر باشد)."""
    D = scene.duration
    a = intent.audio or {}
    spec = AudioSpec()
    events: list[dict[str, Any]] = []
    status: dict[str, str] = {}

    if a.get("silent"):
        spec.explicit_silence = True
        spec.ambient = "none"
        spec.events = []
        spec.status = {"all": "silent_by_request"}
        return spec

    wspan = weather_span(scene, scene.weather) if scene.weather in ("rain", "snow") else None
    explicit_sources: list[str] = []
    amb = list(a.get("ambience", []))
    if "auto" in amb:
        amb.remove("auto")
        derived = "rain" if (scene.weather == "rain") else _ENV_TO_AMBIENCE.get(scene.environment, "wind")
        amb.append(derived)
    for src in amb:
        explicit_sources.append(src)
        if src == "rain" and wspan:
            s, e = wspan
            events.append(_ev(f"aud_{src}", "ambience", "rain", s, max(0.5, e - s), 0.5, loop=True, fade_in=0.8,
                              fade_out=1.0, spatial="wide", trigger="weather:rain"))
        else:
            events.append(_ev(f"aud_{src}", "ambience", src, 0.0, D, 0.45, loop=True, fade_in=0.8, fade_out=1.0, spatial="wide"))

    # رعد: هر flash → رعدِ با تأخیر
    flashes = [e for e in scene.timeline if e.event == "flash"]
    # قاعدهٔ طراحی: flash بدونِ رعد ناهماهنگ است؛ پس هر flash همیشه با رعدِ هم‌گام جفت می‌شود.
    for i, fl in enumerate(flashes):
        events.append(_ev(f"aud_thunder_{i + 1}", "sfx", "thunder", fl.time + THUNDER_DELAY_S,
                          min(2.8, max(0.5, D - fl.time - THUNDER_DELAY_S)), 0.9, fade_out=1.2,
                          spatial="wide", trigger=f"event:{fl.id}"))
    if flashes:
        explicit_sources.append("thunder")

    # قدم‌ها: هم‌گام با بازهٔ حرکتِ شخصیت
    moves = [e for e in scene.timeline if e.event == "motion" and e.property == "pos_x"]
    want_steps = "footsteps" in a.get("sfx", []) or bool(moves)
    if moves and want_steps:
        m = moves[0]
        step = 0.55
        t, n = m.time + 0.35, 0            # بعد از anticipation
        while t < m.time + m.duration - 0.2 and n < 48:
            n += 1
            events.append(_ev(f"aud_step_{n}", "sfx", "footstep", t, 0.14, 0.32, spatial="center",
                              trigger=f"motion:{m.target}", default="footsteps" not in a.get("sfx", [])))
            t += step
    # در
    for e in scene.timeline:
        if e.event == "door_open":
            events.append(_ev(f"aud_door_{e.id}", "sfx", "door", e.time, 0.8, 0.6, fade_out=0.3, spatial="center", trigger=f"event:{e.id}"))

    # صدایِ پیش‌فرضِ ملایم فقط اگر کاربر هیچ صدایی نخواسته و نفیِ کلی هم نشده
    if not events and not a.get("silent") and not (a.get("sfx") or a.get("ambience")):
        d_src = "rain" if (scene.weather == "rain" and wspan) else _ENV_TO_AMBIENCE.get(scene.environment)
        if d_src == "rain" and wspan:
            events.append(_ev("aud_default_rain", "ambience", "rain", wspan[0], max(0.5, wspan[1] - wspan[0]), 0.22, loop=True,
                              fade_in=1.0, fade_out=1.0, spatial="wide", trigger="weather:rain", default=True))
        elif d_src:
            events.append(_ev(f"aud_default_{d_src}", "ambience", d_src, 0.0, D, 0.18, loop=True, fade_in=1.0, fade_out=1.0,
                              spatial="wide", default=True))

    # موسیقی: فقط با درخواست یا policy
    if a.get("music") is True or (allow_auto_music and a.get("music") is None):
        events.append(_ev("aud_music", "music", "ambient_pad", 0.0, D, 0.28, loop=True, fade_in=1.5, fade_out=2.0,
                          spatial="wide", trigger="mood:" + mood))
        spec.music = "ambient_pad"

    # روایت
    if intent.narration is not None and scene.graph.get("plan", {}).get("index", 0) == 0:
        lang = "en" if intent.language == "en" else "fa"
        text = intent.narration or auto_narration_text(scene, lang)
        start = 0.6
        avail = max(1.0, D - start - 0.6)
        dur = estimate_narration_seconds(text, lang)
        if dur > avail:
            words = text.split()
            keep = max(3, int(avail * (_FA_WPS if lang == "fa" else _EN_WPS)))
            text = " ".join(words[:keep])
            dur = estimate_narration_seconds(text, lang)
        spec.narration = {"text": text, "start": round(start, 3), "duration": round(min(dur, avail), 3), "lang": lang,
                          "auto_text": not bool(intent.narration)}
        events.append(_ev("aud_narration", "narration", "tts", start, min(dur, avail), 0.9, spatial="center", trigger="timeline"))

    # وضعیتِ هر source -- بدونِ silent success
    for e in events:
        src = e["source"]
        status[src] = "procedural" if src in SYNTH_RECIPES else "unavailable:no_synth_recipe"
    if "tts" in status:
        status["tts"] = "tts_if_runtime_supports_else_subtitles"
    spec.events = events
    spec.status = status
    primary = next((e["source"] for e in events if e["type"] == "ambience"), None)
    spec.ambient = primary if primary in ("underwater", "rain", "wind") else (primary or "none")
    spec.volume = 0.35
    return spec


def subtitle_labels(narration: dict[str, Any]) -> list[dict[str, Any]]:
    """زیرنویسِ اختیاری، زمان‌بندی‌شده بر اساسِ همان تخمینِ روایت."""
    words = narration["text"].split()
    chunks = [words[i:i + 7] for i in range(0, len(words), 7)] or [[]]
    per = narration["duration"] / len(chunks)
    out = []
    for i, c in enumerate(chunks):
        out.append({"text": " ".join(c), "x": 0.5, "y": 0.9, "start": round(narration["start"] + i * per, 3),
                    "duration": round(per, 3), "role": "subtitle"})
    return out


def validate_events(events: list[dict[str, Any]], total: float) -> list[str]:
    errs: list[str] = []
    ids = set()
    for e in events:
        miss = [f for f in REQUIRED_EVENT_FIELDS if f not in e]
        if miss:
            errs.append(f"{e.get('id', '?')}: فیلدهایِ ناقص {miss}")
            continue
        if e["id"] in ids:
            errs.append(f"audio id تکراری: {e['id']}")
        ids.add(e["id"])
        if not 0 <= e["volume"] <= 1:
            errs.append(f"{e['id']}: volume خارج از بازه")
        if e["start"] < 0 or e["start"] > total + 1e-6:
            errs.append(f"{e['id']}: start خارج از بازه ({e['start']})")
        if e["start"] + e["duration"] > total + 1.5 and not e["loop"]:
            errs.append(f"{e['id']}: بعد از پایانِ صحنه تمام می‌شود")
        if e["type"] not in ("ambience", "sfx", "music", "narration", "voice", "dialogue", "ui"):
            errs.append(f"{e['id']}: type نامعتبر")
    return errs


def sync_report(scene) -> list[dict[str, Any]]:
    """اعتبارسنجیِ همگامیِ صدا-تصویر (بخشِ ۱۴) با شاهد؛ برایِ validator و تست."""
    out: list[dict[str, Any]] = []
    flashes = [e for e in scene.timeline if e.event == "flash"]
    for e in scene.audio.events:
        if e["source"] == "thunder":
            d = min((e["start"] - f.time for f in flashes if e["start"] >= f.time - 1e-6), default=None)
            ok = d is not None and d <= SYNC_TOLERANCE_S
            out.append({"name": f"{e['id']}~flash", "ok": ok, "evidence": f"delay={d}"})
    wspan = weather_span(scene, "rain")
    for e in scene.audio.events:
        if e["source"] == "rain" and e.get("trigger", "").startswith("weather") and wspan:
            ok = abs(e["start"] - wspan[0]) <= SYNC_TOLERANCE_S and abs((e["start"] + e["duration"]) - wspan[1]) <= SYNC_TOLERANCE_S
            out.append({"name": f"{e['id']}~rain_visual", "ok": ok, "evidence": f"audio=({e['start']},{e['start']+e['duration']}) visual={wspan}"})
    moves = [m for m in scene.timeline if m.event == "motion" and m.property == "pos_x"]
    for e in scene.audio.events:
        if e["source"] == "footstep" and moves:
            m = moves[0]
            ok = m.time - 1e-6 <= e["start"] <= m.time + m.duration + 1e-6
            out.append({"name": f"{e['id']}~motion", "ok": ok, "evidence": f"t={e['start']} span=({m.time},{m.time+m.duration})"})
    for e in scene.audio.events:
        if e["source"] == "door":
            d = min((abs(e["start"] - x.time) for x in scene.timeline if x.event == "door_open"), default=None)
            out.append({"name": f"{e['id']}~door", "ok": d is not None and d <= 0.6, "evidence": f"delta={d}"})
    return out
