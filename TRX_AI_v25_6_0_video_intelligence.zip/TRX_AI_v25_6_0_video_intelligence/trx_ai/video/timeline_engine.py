# -*- coding: utf-8 -*-
"""
Timeline Engine (بخشِ ۱۷ سندِ ارتقا): منبعِ حقیقتِ زمانیِ مشترکِ تصویر و صدا.

رویدادها می‌توانند *مطلق* (at) یا *نسبی/وابسته* (after + offset) تعریف شوند؛
``resolve`` وابستگی‌ها را (توپولوژیک، با تشخیصِ حلقه) به زمانِ مطلق تبدیل می‌کند.
هیچ منطقِ NLU/HTML اینجا نیست.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .scene_schema import TimelineEvent


class TimelineError(ValueError):
    pass


@dataclass
class Planned:
    id: str
    event: str
    at: float | None = None
    after: str | None = None
    offset: float = 0.0
    duration: float = 0.0
    target: str | None = None
    property: str | None = None
    value: Any = None
    to: Any = None
    easing: str = "linear"


def resolve(planned: list[Planned], total: float) -> list[TimelineEvent]:
    """زمانِ مطلقِ همهٔ رویدادها را حل می‌کند و به ترتیبِ زمان برمی‌گرداند."""
    by_id = {p.id: p for p in planned}
    if len(by_id) != len(planned):
        raise TimelineError("id تکراری در timeline")
    times: dict[str, float] = {}
    state: dict[str, int] = {}

    def solve(pid: str) -> float:
        if pid in times:
            return times[pid]
        if state.get(pid) == 1:
            raise TimelineError(f"وابستگیِ حلقوی در timeline ({pid})")
        state[pid] = 1
        p = by_id[pid]
        if p.at is not None:
            t = p.at
        elif p.after:
            if p.after not in by_id:
                raise TimelineError(f"{pid} به رویدادِ ناموجود وابسته است ({p.after})")
            dep = by_id[p.after]
            t = solve(p.after) + dep.duration * 0 + p.offset
        else:
            t = 0.0
        times[pid] = t
        state[pid] = 2
        return t

    out = []
    for p in planned:
        t = round(max(0.0, min(total, solve(p.id))), 3)
        out.append(TimelineEvent(time=t, event=p.event, id=p.id, target=p.target, property=p.property,
                                 value=p.value, to=p.to, easing=p.easing,
                                 depends_on=[p.after] if p.after else [], duration=round(p.duration, 3)))
    out.sort(key=lambda e: (e.time, e.id))
    return out


def validate(events: list[TimelineEvent], total: float) -> list[str]:
    errs: list[str] = []
    ids = {e.id for e in events if e.id}
    times = {e.id: e.time for e in events if e.id}
    for e in events:
        if e.time < -1e-6 or e.time > total + 1e-6:
            errs.append(f"رویداد {e.id or e.event} خارج از بازهٔ زمانی ({e.time})")
        if e.duration < 0:
            errs.append(f"duration منفی: {e.id or e.event}")
        for d in e.depends_on:
            if d not in ids:
                errs.append(f"{e.id}: وابستگیِ ناموجود ({d})")
            elif times[d] > e.time + 1e-6:
                errs.append(f"{e.id}: قبل از وابستگیِ خود ({d}) رخ می‌دهد")
    return errs


def events_for(events: list[TimelineEvent], *, target: str | None = None,
               prop: str | None = None, event: str | None = None) -> list[TimelineEvent]:
    return [e for e in events
            if (target is None or e.target == target)
            and (prop is None or e.property == prop)
            and (event is None or e.event == event)]


def value_at(events: list[TimelineEvent], target: str, prop: str, t: float, default: float = 0.0) -> float:
    """همان نیمه‌ی عددیِ interpreterِ JS -- برایِ اعتبارسنجیِ معناییِ بدونِ رندر."""
    val = default
    for e in sorted(events_for(events, target=target, prop=prop), key=lambda x: x.time):
        if t + 1e-9 < e.time:
            continue
        if e.to is not None and e.duration > 0:
            f = max(0.0, min(1.0, (t - e.time) / e.duration))
            a = float(e.value if e.value is not None else val)
            val = a + (float(e.to) - a) * f
        else:
            v = e.to if e.to is not None else e.value
            if v is not None:
                val = float(v)
    return val
