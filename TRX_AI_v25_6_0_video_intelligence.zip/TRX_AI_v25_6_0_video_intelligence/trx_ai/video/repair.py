# -*- coding: utf-8 -*-
"""
Targeted Repair Loop (بخش‌هایِ ۲۰ و ۲۱ سندِ ارتقا).

«فقط بخشِ خراب اصلاح شود»: برای هر requirementِ FAIL فقط ``ensure_*`` هایِ مربوط (همان
بلوک‌هایِ ساختِ planner) دوباره اجرا می‌شوند؛ کلِ صحنه از نو ساخته نمی‌شود. UNSUPPORTED
هرگز «ترمیم» نمی‌شود (ترمیمِ دروغین ممنوع است).
"""

from __future__ import annotations

from typing import Any

from . import scene_planner as sp
from .semantic_planner.intent import VideoIntent
from .semantic_validator import ReqResult, FAIL
from . import style_system

# kind → ensure_*هایِ لازم (به‌ترتیب). rebuild_timeline و rebuild_audio همیشه آخر می‌آیند.
_PLAN = {
    "weather": ["weather", "storm"],
    "time_of_day": ["sky", "window_light", "lighting"],
    "camera": ["camera"],
    "subject": ["subject", "window_light", "camera"],
    "environment": ["environment"],
    "motion": ["character", "camera"],
    "event": ["storm", "door", "weather", "character"],
    "lighting": ["window_light", "lighting"],
    "audio": ["storm"],
    "silence": [], "music": [], "narration": [],
    "style": [],
}


def _sync_fields_from_intent(scene, intent: VideoIntent) -> None:
    """حالتِ مطلوبِ intent را به فیلدهایِ صحنه برمی‌گرداند (تا ensure_* از مقدارِ خرابِ فعلی ارث نبرد)."""
    scene.weather = intent.weather if intent.weather in ("rain", "snow", "fog") else "none"
    scene.environment = sp.default_environment(intent)
    p = sp.plan_of(scene)
    if p.get("index", 0) == 0 or not intent.time_transition:
        tod = intent.time_transition[0] if intent.time_transition else (intent.time_of_day or scene.time_of_day)
        p["tod"] = {"from": tod, "to": intent.time_transition[1] if intent.time_transition and p.get("n_scenes", 1) == 1 else None}
        scene.time_of_day = tod


def repair_scene(scene, intent: VideoIntent, kinds: set[str]) -> list[str]:
    ctx = sp.ctx_from_scene(scene, intent)
    _sync_fields_from_intent(scene, intent)
    actions: list[str] = []
    done: set[str] = set()
    for k in sorted(kinds):
        for step in _PLAN.get(k, []):
            if step in done:
                continue
            done.add(step)
            getattr(sp, f"ensure_{step}")(scene, ctx)
            actions.append(f"ensure_{step}")
    sp.rebuild_relations(scene)
    sp.rebuild_timeline(scene, ctx)
    sp.rebuild_audio(scene, ctx)
    actions += ["rebuild_timeline", "rebuild_audio"]
    if "style" in kinds or kinds:
        # سبک روی نورِ *جدید* دوباره اعمال می‌شود؛ ensure_lighting نورِ پایه را بازسازی می‌کند.
        if "lighting" in done or "sky" in done:
            style_system.apply_style(scene, scene.style)
            actions.append("apply_style")
    return actions


def repair(project, intent: VideoIntent, failures: list[ReqResult]) -> list[dict[str, Any]]:
    kinds = {f.kind for f in failures if f.status == FAIL}
    if not kinds:
        return []
    log = []
    for sc in project.scenes:
        acts = repair_scene(sc, intent, kinds)
        log.append({"scene": sc.scene_id, "kinds": sorted(kinds), "actions": acts})
    return log
