# -*- coding: utf-8 -*-
"""بخشِ اولِ runtimeِ JS: ابزارها، timeline، پالت‌ها، دوربین. (رشتهٔ خام، بدونِ f-string)"""

JS_CORE = r'''
"use strict";
var PROJECT = __PROJECT_JSON__;
(function () {
  var canvas = document.getElementById("stage");
  var c = canvas.getContext("2d");
  var W = PROJECT.render.w, H = PROJECT.render.h;
  canvas.width = W; canvas.height = H;
  var scenes = PROJECT.scenes, starts = PROJECT.starts, TOTAL = PROJECT.total;
  var STATS = {};
  var LOWFX = false;
  function mark(k, n) { STATS[k] = (STATS[k] || 0) + (n === undefined ? 1 : n); }
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function mulberry(seed) {
    var a = (seed | 0) + 0x9E3779B9;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  var EASE = {
    linear: function (x) { return x; },
    ease_in_out: function (x) { return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2; },
    ease_out: function (x) { return 1 - Math.pow(1 - x, 2); },
    ease_in: function (x) { return x * x; },
    settle: function (x) { var s = 1.4; var y = x - 1; return 1 + y * y * ((s + 1) * y + s); },
    anticipate: function (x) { return x < 0.15 ? -0.1 * (x / 0.15) : -0.1 + 1.1 * ((x - 0.15) / 0.85); }
  };
  function ease(name, x) { return (EASE[name] || EASE.linear)(clamp(x, 0, 1)); }

  // ---------- Timeline: منبعِ حقیقتِ زمانی ----------
  var IDX = scenes.map(function (sc) {
    var m = {};
    (sc.timeline || []).forEach(function (e) {
      if (!e.target || !e.property) return;
      var k = e.target + "|" + e.property;
      (m[k] = m[k] || []).push(e);
    });
    Object.keys(m).forEach(function (k) { m[k].sort(function (a, b) { return a.time - b.time; }); });
    return m;
  });
  function propAt(si, target, prop, t, def) {
    var list = IDX[si][target + "|" + prop];
    var val = def;
    if (!list) return val;
    for (var i = 0; i < list.length; i++) {
      var e = list[i];
      if (t < e.time) continue;
      var to = (e.to === undefined ? null : e.to);
      if (to !== null && e.duration > 0) {
        var f = ease(e.easing || "linear", (t - e.time) / e.duration);
        var a = (typeof e.value === "number") ? e.value : val;
        val = a + (to - a) * f;
      } else {
        var v = (to !== null) ? to : e.value;
        if (typeof v === "number") val = v;
      }
    }
    return val;
  }
  function flashAt(sc, t) {
    var a = 0;
    (sc.timeline || []).forEach(function (e) {
      if (e.event !== "flash") return;
      var dt = t - e.time;
      if (dt < 0 || dt > 0.9) return;
      var v = Math.exp(-dt * 7);
      if (dt > 0.22 && dt < 0.36) v = Math.max(v, 0.55 * (1 - (dt - 0.22) / 0.14));
      a = Math.max(a, v);
    });
    return a;
  }
  function objVel(sc, id) {
    for (var i = 0; i < sc.objects.length; i++) if (sc.objects[i].id === id) return sc.objects[i].velocity;
    return 1;
  }

  // ---------- پالتِ زمانِ روز ----------
  var PAL = {
    dawn:   {top: [70, 90, 140],  bot: [250, 170, 120], amb: 0.7,  star: 0.2, sunA: 1,   moonA: 0,   sx: 0.15, sy: 0.58},
    day:    {top: [70, 140, 220], bot: [190, 225, 250], amb: 1.0,  star: 0,   sunA: 1,   moonA: 0,   sx: 0.62, sy: 0.16},
    sunset: {top: [60, 60, 120],  bot: [250, 130, 70],  amb: 0.72, star: 0.1, sunA: 1,   moonA: 0,   sx: 0.84, sy: 0.56},
    dusk:   {top: [25, 30, 70],   bot: [110, 80, 120],  amb: 0.45, star: 0.5, sunA: 0.1, moonA: 0.4, sx: 0.9,  sy: 0.7},
    night:  {top: [4, 8, 24],     bot: [18, 28, 58],    amb: 0.24, star: 1,   sunA: 0,   moonA: 1,   sx: 0.7,  sy: 0.2}
  };
  function mixArr(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]; }
  function palBlend(a, b, f) {
    var A = PAL[a] || PAL.day, B = PAL[b] || A;
    return {top: mixArr(A.top, B.top, f), bot: mixArr(A.bot, B.bot, f), amb: lerp(A.amb, B.amb, f),
            star: lerp(A.star, B.star, f), sunA: lerp(A.sunA, B.sunA, f), moonA: lerp(A.moonA, B.moonA, f),
            sx: lerp(A.sx, B.sx, f), sy: lerp(A.sy, B.sy, f)};
  }
  function rgb(a, k) { k = k === undefined ? 1 : k; return "rgb(" + Math.round(clamp(a[0] * k, 0, 255)) + "," + Math.round(clamp(a[1] * k, 0, 255)) + "," + Math.round(clamp(a[2] * k, 0, 255)) + ")"; }
  function hsl(h, s, l, a) { return "hsla(" + Math.round(h * 360) + "," + Math.round(s) + "%," + Math.round(clamp(l, 0, 100)) + "%," + (a === undefined ? 1 : a) + ")"; }
  function nodeMap(sc) { var m = {}; sc.graph.nodes.forEach(function (n) { m[n.id] = n; }); return m; }
  function nodeXY(si, sc, n, t) {
    var x = propAt(si, n.id, "pos_x", t, n.transform.x);
    var y = propAt(si, n.id, "pos_y", t, n.transform.y);
    return [x, y];
  }
  var STYLE = function (sc) { return (sc.graph.style) || {}; };

  // ---------- دوربینِ هدف‌محور ----------
  function cameraFor(si, sc, t, nm) {
    var cam = sc.camera, prog = clamp(t / sc.duration, 0, 1);
    var e = ease(cam.easing || "linear", prog);
    var z = lerp(cam.zoom_start, cam.zoom_end, e);
    var fx = 0.5, fy = 0.5;
    var tn = cam.target ? nm[cam.target] : null;
    var txy = tn && tn.id !== "env" ? nodeXY(si, sc, tn, t) : [cam.origin_x, cam.origin_y];
    var ty = txy[1] - ((tn && tn.visual_properties && tn.visual_properties.h) ? tn.visual_properties.h * 0.5 : 0.08);
    if (cam.move === "follow") { fx = txy[0]; fy = ty; }
    else if (cam.move === "pan") { fx = 0.5 + (cam.pan_x || 0) * (e - 0.5); }
    else if (cam.move === "orbit") { fx = 0.5 + (cam.pan_x || 0) * Math.sin(prog * 6.2832); fy = 0.5 + 0.02 * Math.cos(prog * 6.2832); }
    else if (cam.target && z > 1.001) {
      var w = clamp((z - 1) / Math.max(0.05, Math.max(cam.zoom_start, cam.zoom_end) - 1), 0, 1);
      fx = lerp(0.5, txy[0], w); fy = lerp(0.5, ty, w);
    }
    var sh = cam.shake ? Math.sin(t * 37) * cam.shake * 0.004 : 0;
    var lo = 0.5 / z;
    fx = clamp(fx + sh, lo, 1 - lo); fy = clamp(fy + sh, lo, 1 - lo);
    return {z: z, fx: fx, fy: fy};
  }
'''
