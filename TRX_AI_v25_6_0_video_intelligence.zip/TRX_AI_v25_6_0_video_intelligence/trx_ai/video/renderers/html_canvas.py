# -*- coding: utf-8 -*-
"""
HTMLCanvasRenderer: اولین پیاده‌سازیِ ``VideoRenderer`` (بخشِ ۳۲).

خروجی یک فایلِ HTMLِ خودکفا (بدونِ شبکه/eval/iframe) است؛ تمامِ منطقِ JS در
``js_core/js_draw/js_scene/js_loop`` است و قالبِ زیر فقط پوسته + HUD.
"""

from __future__ import annotations

import html as _html
import json
import re

from .base import VideoRenderer
from .js_core import JS_CORE
from .js_draw import JS_DRAW
from .js_scene import JS_SCENE
from .js_loop import JS_LOOP
from ..object_library import KNOWN_KINDS
from ..audio_planner import SYNTH_RECIPES

MAX_HTML_BYTES = 300_000
WEATHER_KINDS = ("rain", "snow", "fog")
_JS = JS_CORE + JS_DRAW + JS_SCENE + JS_LOOP

_SHELL = r'''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>__TITLE__</title>
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #000; font-family: Tahoma, sans-serif; }
  #scene-root { position: relative; width: 100%; height: calc(100% - 46px); display: flex; align-items: center; justify-content: center;
                background: #000; opacity: 0; transition: opacity 0.6s ease-in-out; }
  #stage { max-width: 100%; max-height: 100%; width: auto; height: auto; background: #000; }
  #hud { position: absolute; left: 0; right: 0; bottom: 0; height: 46px; padding: 6px 12px; display: flex; align-items: center; gap: 10px;
         direction: ltr; background: #0b0b10; font-size: 13px; color: #eee; z-index: 20; }
  #hud button { background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.25); color: #fff; border-radius: 8px; padding: 5px 10px; font-size: 14px; }
  #seek { flex: 1; min-width: 40px; }
  #timeLabel { min-width: 84px; text-align: center; font-variant-numeric: tabular-nums; }
  #audioTag, #qualityTag { opacity: 0.7; font-size: 11px; max-width: 28vw; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
  #audioUnlock { position: absolute; inset: 0; z-index: 30; display: none; align-items: center; justify-content: center; background: rgba(0,0,0,0.35); color: #fff; font-size: 14px; }
  #audioUnlock span { background: rgba(0,0,0,0.6); border: 1px solid rgba(255,255,255,0.3); border-radius: 10px; padding: 10px 16px; }
</style>
</head>
<body>
<div id="scene-root">
  <canvas id="stage"></canvas>
  <div id="audioUnlock"><span>🔈 برای پخشِ صدا لمس کنید</span></div>
</div>
<div id="hud">
  <button id="btnPlayPause">⏸</button>
  <button id="btnReset">↻</button>
  <span id="timeLabel">00:00 / 00:00</span>
  <input id="seek" type="range" min="0" max="1000" value="0">
  <button id="btnMute">🔈</button>
  <span id="audioTag"></span>
  <span id="qualityTag"></span>
</div>
<script>
__JS__
</script>
</body>
</html>
'''


def _json_for_script(obj) -> str:
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    return s.replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def supported_drawer_kinds() -> tuple[str, ...]:
    """kindهایی که JSِ این renderer واقعاً ``function draw_<kind>`` برایشان دارد (از روی متنِ JS، نه فهرستِ دستی)."""
    return tuple(sorted(set(re.findall(r"function draw_([a-z_]+)\(", _JS))))


class HTMLCanvasRenderer(VideoRenderer):
    name = "html_canvas"

    def supported_kinds(self) -> tuple[str, ...]:
        return supported_drawer_kinds()

    def supported_sources(self) -> tuple[str, ...]:
        return tuple(SYNTH_RECIPES)

    def render(self, project) -> str:
        pd = project.to_render_dict()
        page = _SHELL.replace("__TITLE__", _html.escape(f"TRX Video {project.project_id}")) \
                     .replace("__JS__", _JS.replace("__PROJECT_JSON__", _json_for_script(pd)))
        if len(page.encode("utf-8")) > MAX_HTML_BYTES:
            raise ValueError(f"HTML تولیدشده از سقفِ مجاز ({MAX_HTML_BYTES} بایت) بزرگ‌تر است.")
        return page
