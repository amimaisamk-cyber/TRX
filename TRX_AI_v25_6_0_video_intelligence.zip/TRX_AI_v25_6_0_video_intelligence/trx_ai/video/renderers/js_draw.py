# -*- coding: utf-8 -*-
"""بخشِ دومِ runtimeِ JS: drawerهایِ شیء/محیط/آب‌وهوا/نور. نامِ drawerها ``draw_<kind>`` است و
تستِ قراردادی آن‌ها را با ``object_library.KNOWN_KINDS`` و kindهایِ آب‌وهوا تطبیق می‌دهد."""

JS_DRAW = r'''
  // ---------- drawerهایِ سوژه ----------
  function draw_house(c, n, st) {
    var a = n.visual_properties, x = n.transform.x * W, yb = n.transform.y * H, w = a.w * W, h = a.h * H;
    var wall = hsl(a.hue, 26 - a.wear * 14, 60 - a.wear * 22), roofc = hsl((a.hue + 0.05) % 1, 32, 32 - a.wear * 10);
    c.fillStyle = wall; c.fillRect(x - w / 2, yb - h, w, h);
    c.fillStyle = roofc; c.beginPath();
    if (a.roof === "flat") { c.rect(x - w / 2 - 4, yb - h - h * 0.08, w + 8, h * 0.1); }
    else if (a.roof === "hip") { c.moveTo(x - w / 2 - 6, yb - h); c.lineTo(x - w * 0.3, yb - h - h * 0.4); c.lineTo(x + w * 0.3, yb - h - h * 0.4); c.lineTo(x + w / 2 + 6, yb - h); }
    else { c.moveTo(x - w / 2 - 6, yb - h); c.lineTo(x, yb - h - h * 0.55); c.lineTo(x + w / 2 + 6, yb - h); }
    c.closePath(); c.fill();
    if (a.chimney) { c.fillStyle = hsl(0.05, 20, 28); c.fillRect(x + w * 0.22, yb - h - h * 0.5, w * 0.07, h * 0.3); }
    var dw = w * 0.2, dh = h * 0.55, door = propAt(st.si, n.id, "door", st.t, a.door_open || 0);
    c.fillStyle = door > 0.05 ? "rgb(24,16,10)" : hsl(0.07, 35, 26);
    c.fillRect(x - dw / 2, yb - dh, dw, dh);
    if (door > 0.05) { c.fillStyle = hsl(0.07, 35, 30); c.fillRect(x - dw / 2, yb - dh, dw * (1 - 0.85 * clamp(door, 0, 1)), dh); }
    var wl = a.window_lit ? propAt(st.si, "window_light", "intensity", st.t, 1) : 0;
    var nwin = a.windows || 2;
    for (var i = 0; i < nwin; i++) {
      var wx = x - w / 2 + w * (0.18 + 0.64 * (nwin === 1 ? 0.5 : i / (nwin - 1)));
      if (Math.abs(wx - x) < dw) continue;
      var ww = w * 0.14, wh = h * 0.22, wy = yb - h * 0.72;
      c.fillStyle = wl > 0.02 ? "rgba(255," + Math.round(200 + 40 * wl) + "," + Math.round(120 + 40 * wl) + "," + (0.35 + 0.65 * wl) + ")" : "rgba(20,30,45,0.85)";
      c.fillRect(wx - ww / 2, wy, ww, wh);
      c.strokeStyle = "rgba(0,0,0,0.5)"; c.lineWidth = 2; c.strokeRect(wx - ww / 2, wy, ww, wh);
    }
    var r = mulberry((a.hue * 1000) | 0);
    c.strokeStyle = "rgba(0,0,0," + (0.15 + a.wear * 0.3) + ")"; c.lineWidth = 1;
    for (var k = 0; k < Math.round(a.wear * 10); k++) {
      var sx = x - w / 2 + r() * w, sy = yb - h + r() * h * 0.6;
      c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + (r() - 0.5) * 14, sy + r() * 18); c.stroke();
    }
    mark("house");
  }
  function draw_character(c, n, st) {
    var a = n.visual_properties, xy = nodeXY(st.si, st.sc, n, st.t), x = xy[0] * W, yb = xy[1] * H, hh = a.h * H;
    var xp = propAt(st.si, n.id, "pos_x", Math.max(0, st.t - 0.12), n.transform.x) * W;
    var moving = Math.abs(x - xp) > 0.15 ? 1 : 0, dir = (x - xp) > 0.15 ? 1 : (a.facing || 1);
    if (x - xp < -0.15) dir = -1;
    var ph = st.t * 7 * (a.gait || 1), sw = Math.sin(ph) * 0.55 * moving;
    c.save(); c.translate(x, yb); c.scale(dir, 1);
    var bodyc = hsl(a.hue, 45, 42), skin = hsl(0.08, 45, 65);
    var hip = -hh * 0.42, sho = -hh * 0.78;
    c.strokeStyle = "rgb(30,30,40)"; c.lineCap = "round"; c.lineWidth = Math.max(4, hh * 0.07);
    c.beginPath(); c.moveTo(0, hip); c.lineTo(Math.sin(sw) * hh * 0.25, 0); c.stroke();
    c.beginPath(); c.moveTo(0, hip); c.lineTo(-Math.sin(sw) * hh * 0.25, 0); c.stroke();
    c.fillStyle = bodyc; c.beginPath(); c.moveTo(-hh * 0.11, sho); c.lineTo(hh * 0.11, sho); c.lineTo(hh * 0.08, hip); c.lineTo(-hh * 0.08, hip); c.closePath(); c.fill();
    c.strokeStyle = bodyc; c.lineWidth = Math.max(3, hh * 0.05);
    c.beginPath(); c.moveTo(0, sho + hh * 0.03); c.lineTo(-Math.sin(sw) * hh * 0.2, sho + hh * 0.26); c.stroke();
    c.beginPath(); c.moveTo(0, sho + hh * 0.03); c.lineTo(Math.sin(sw) * hh * 0.2, sho + hh * 0.26); c.stroke();
    c.fillStyle = skin; c.beginPath(); c.arc(0, sho - hh * 0.09, hh * 0.085, 0, 6.2832); c.fill();
    c.fillStyle = a.hair === "long" ? "rgb(40,28,20)" : "rgb(30,22,16)";
    c.beginPath(); c.arc(0, sho - hh * 0.11, hh * 0.088, 3.14, 6.2832); c.fill();
    if (a.hair === "long") c.fillRect(-hh * 0.088, sho - hh * 0.11, hh * 0.05, hh * 0.14);
    c.restore();
    mark("char_x", Math.round(x));      // شاهدِ بازرسی: مختصاتِ واقعیِ کشیده‌شده
    mark("character");
  }
  function draw_tree(c, n, st) {
    var a = n.visual_properties, x = n.transform.x * W, yb = n.transform.y * H, h = a.h * H, cr = h * 0.42 * a.crown;
    c.fillStyle = hsl(0.07, 35, 22); c.fillRect(x - h * 0.04, yb - h * 0.5, h * 0.08, h * 0.5);
    for (var i = 0; i < 3; i++) { c.fillStyle = hsl(0.3 + a.hue * 0.06, 45, 26 + i * 4); c.beginPath(); c.arc(x + (i - 1) * cr * 0.5 + a.lean * W * 0.2, yb - h * 0.6 - i * cr * 0.25, cr * (1 - i * 0.12), 0, 6.2832); c.fill(); }
    mark("tree");
  }
  function draw_moon(c, n, st) {
    var a = n.visual_properties, x = n.transform.x * W, y = n.transform.y * H, r = a.r * H * 1.6;
    var g = c.createRadialGradient(x, y, r * 0.5, x, y, r * 3); g.addColorStop(0, "rgba(220,230,255," + 0.35 * a.glow + ")"); g.addColorStop(1, "rgba(220,230,255,0)");
    c.fillStyle = g; c.fillRect(x - r * 3, y - r * 3, r * 6, r * 6);
    c.fillStyle = "rgb(235,238,250)"; c.beginPath(); c.arc(x, y, r, 0, 6.2832); c.fill();
    c.fillStyle = "rgba(180,185,205,0.5)"; c.beginPath(); c.arc(x - r * 0.3, y - r * 0.1, r * 0.22, 0, 6.2832); c.fill();
    mark("moon");
  }
  function draw_sun(c, n, st) {
    var a = n.visual_properties, x = n.transform.x * W, y = n.transform.y * H, r = a.r * H * 1.6;
    var g = c.createRadialGradient(x, y, r * 0.4, x, y, r * 3.4); g.addColorStop(0, "rgba(255,230,150," + 0.55 * a.glow + ")"); g.addColorStop(1, "rgba(255,200,100,0)");
    c.fillStyle = g; c.fillRect(x - r * 3.4, y - r * 3.4, r * 6.8, r * 6.8);
    c.fillStyle = "rgb(255,236,170)"; c.beginPath(); c.arc(x, y, r, 0, 6.2832); c.fill();
    mark("sun");
  }
  function draw_object(c, n, st) {
    var a = n.visual_properties, x = n.transform.x * W, yb = n.transform.y * H, w = a.w * W, h = a.h * H;
    c.fillStyle = hsl(a.hue, 40, 50); c.beginPath();
    if (c.roundRect) c.roundRect(x - w / 2, yb - h, w, h, 10); else c.rect(x - w / 2, yb - h, w, h);
    c.fill(); c.strokeStyle = "rgba(0,0,0,0.35)"; c.lineWidth = 2; c.stroke();
    mark("object");
  }
  // ---------- آب‌وهوا ----------
  function dropsFor(sc, n) {
    if (!sc.__drops) {
      var r = mulberry(n.visual_properties.seed | 0), arr = [];
      for (var i = 0; i < 400; i++) arr.push([r(), r(), 0.7 + r() * 0.8, 10 + r() * 16]);
      sc.__drops = arr;
    }
    return sc.__drops;
  }
  function draw_rain(c, n, st) {
    var I = st.rain; if (I <= 0.01) return;
    var cnt = Math.floor(n.visual_properties.count * I * (LOWFX ? 0.5 : 1)), d = dropsFor(st.sc, n), v = objVel(st.sc, "weather");
    c.strokeStyle = "rgba(190,210,235," + (0.25 + 0.3 * I) + ")"; c.lineWidth = 1.3; c.beginPath();
    for (var i = 0; i < cnt && i < d.length; i++) {
      var p = d[i], y = ((p[1] + st.t * p[2] * v * 0.9) % 1.15) - 0.05, x = (p[0] + y * n.visual_properties.slant) % 1;
      c.moveTo(x * W, y * H); c.lineTo(x * W - 3, y * H + p[3]);
    }
    c.stroke();
    mark("rain", cnt);
  }
  function draw_snow(c, n, st) {
    var I = st.rain; if (I <= 0.01) return;
    var cnt = Math.floor(n.visual_properties.count * I * (LOWFX ? 0.5 : 1)), d = dropsFor(st.sc, n), v = objVel(st.sc, "weather");
    c.fillStyle = "rgba(255,255,255,0.85)";
    for (var i = 0; i < cnt && i < d.length; i++) {
      var p = d[i], y = ((p[1] + st.t * p[2] * v * 0.12) % 1.1) - 0.05, x = (p[0] + Math.sin(st.t + i) * 0.01) % 1;
      c.beginPath(); c.arc(x * W, y * H, 1.5 + p[2], 0, 6.2832); c.fill();
    }
    mark("snow", cnt);
  }
  function draw_fog(c, n, st) {
    var I = Math.max(st.rain, 0.0001);
    for (var i = 0; i < 3; i++) {
      var y = H * (0.5 + 0.12 * i) + Math.sin(st.t * 0.3 + i) * 10, g = c.createLinearGradient(0, y - H * 0.2, 0, y + H * 0.2);
      g.addColorStop(0, "rgba(220,225,235,0)"); g.addColorStop(0.5, "rgba(220,225,235," + 0.16 * I + ")"); g.addColorStop(1, "rgba(220,225,235,0)");
      c.fillStyle = g; c.fillRect(0, y - H * 0.2, W, H * 0.4);
    }
    mark("fog");
  }
  function draw_window_light(c, n, st) {
    var I = propAt(st.si, "window_light", "intensity", st.t, 1); if (I <= 0.01) return;
    var x = n.transform.x * W, y = n.transform.y * H, r = n.visual_properties.radius * H * (1 + 0.03 * Math.sin(st.t * 9));
    var g = c.createRadialGradient(x, y, 2, x, y, r * 2.4);
    g.addColorStop(0, "rgba(255,215,150," + (0.55 * I) + ")"); g.addColorStop(1, "rgba(255,190,110,0)");
    c.fillStyle = g; c.fillRect(x - r * 2.4, y - r * 2.4, r * 4.8, r * 4.8);
    mark("window_light");
  }
  var DRAWERS = {house: draw_house, character: draw_character, tree: draw_tree, moon: draw_moon, sun: draw_sun,
                 object: draw_object, rain: draw_rain, snow: draw_snow, fog: draw_fog, light_source: draw_window_light};

  // ---------- دکورِ محیط (پارامتری، بذردار) ----------
  function ridgeY(it, xf) {
    var pts = it.pts, p = xf * (pts.length - 1), i = Math.floor(p), f = p - i;
    return lerp(pts[i], pts[Math.min(pts.length - 1, i + 1)], f);
  }
  function decor(c, it, st) {
    var x = it.x * W, y = it.y * H, w = (it.w || 0) * W, h = (it.h || 0) * H, pal = st.pal;
    var haze = it.layer === "far" ? 0.45 : (it.layer === "mid" ? 0.15 : 0);
    function tone(col) { return rgb(mixArr(col, pal.bot, haze), 1); }
    switch (it.k) {
      case "ridge": {
        var col = st.env.ground === "sand" ? [190 - it.tone * 30, 150 - it.tone * 20, 95] : (st.env.name === "ancient_persia" ? [140, 120, 100] : [70 + it.tone * 30, 90 + it.tone * 25, 85]);
        c.fillStyle = tone(col); c.beginPath(); c.moveTo(0, H);
        for (var i = 0; i <= 28; i++) { var xf = i / 28; c.lineTo(xf * W, y - ridgeY(it, xf) * H); }
        c.lineTo(W, H); c.closePath(); c.fill();
        if (it.snow) { c.fillStyle = "rgba(245,248,255,0.85)"; for (var j = 1; j < it.pts.length - 1; j++) { if (it.pts[j] > it.pts[j - 1] && it.pts[j] > it.pts[j + 1] && it.pts[j] > 0.6 * 0.36) { var px = j / (it.pts.length - 1) * W, py = y - it.pts[j] * H; c.beginPath(); c.moveTo(px - 22, py + 26); c.lineTo(px, py); c.lineTo(px + 22, py + 26); c.closePath(); c.fill(); } } }
        break; }
      case "tree": {
        var sw = Math.sin(st.t * 0.8 + it.x * 9) * 0.012;
        c.fillStyle = tone([60, 42, 28]); c.fillRect(x - w * 0.07, y - h * 0.45, w * 0.14, h * 0.45);
        c.fillStyle = tone([30 + it.tone * 25, 80 + it.tone * 40, 40 + it.tone * 20]);
        c.beginPath(); c.moveTo(x - w / 2 + it.lean * W, y - h * 0.3);
        c.quadraticCurveTo(x + sw * W, y - h * 1.25, x + w / 2 + it.lean * W, y - h * 0.3); c.closePath(); c.fill();
        c.beginPath(); c.moveTo(x - w * 0.38, y - h * 0.55); c.lineTo(x + sw * W, y - h); c.lineTo(x + w * 0.38, y - h * 0.55); c.closePath(); c.fill();
        break; }
      case "building": {
        var bw = w, bh = h, r = mulberry((it.x * 10000) | 0);
        c.fillStyle = tone(it.neon ? [25 + it.tone * 20, 25, 55 + it.tone * 30] : [80 + it.tone * 50, 82 + it.tone * 40, 95 + it.tone * 30]);
        if (it.style === "house") { c.fillRect(x - bw / 2, y - bh, bw, bh); c.fillStyle = tone([110, 60, 50]); c.beginPath(); c.moveTo(x - bw / 2 - 3, y - bh); c.lineTo(x, y - bh - bh * 0.5); c.lineTo(x + bw / 2 + 3, y - bh); c.closePath(); c.fill(); }
        else c.fillRect(x - bw / 2, y - bh, bw, bh);
        if (it.antenna) { c.fillRect(x - 1, y - bh - 18, 2, 18); }
        var rows = Math.max(2, Math.floor(bh / (H * 0.035))), cols = it.windows || 4, lit = st.night || it.lit;
        for (var ry = 0; ry < rows; ry++) for (var cx = 0; cx < cols; cx++) {
          var on = r() < 0.5 && it.lit, wxp = x - bw / 2 + bw * (0.12 + 0.76 * cx / Math.max(1, cols - 1)), wyp = y - bh + bh * (0.08 + 0.84 * ry / rows);
          c.fillStyle = (on && st.pal.amb < 0.6) ? (it.neon ? "rgba(120,220,255,0.9)" : "rgba(255,220,140,0.9)") : "rgba(30,40,60,0.55)";
          c.fillRect(wxp - 2, wyp, 4, Math.max(3, bh / rows * 0.4));
        }
        if (it.neon) { c.strokeStyle = "rgba(255,80,200,0.6)"; c.lineWidth = 2; c.strokeRect(x - bw / 2, y - bh, bw, bh); }
        break; }
      case "column": {
        c.fillStyle = tone([196 - it.wear * 50, 182 - it.wear * 50, 160 - it.wear * 45]);
        var top = y - h; c.fillRect(x - w / 2, top, w, h);
        if (it.broken) { c.fillStyle = tone([170, 155, 135]); c.beginPath(); c.moveTo(x - w / 2, top); c.lineTo(x - w * 0.15, top - 6); c.lineTo(x + w * 0.1, top + 3); c.lineTo(x + w / 2, top - 4); c.lineTo(x + w / 2, top + 6); c.lineTo(x - w / 2, top + 6); c.closePath(); c.fill(); }
        else { c.fillRect(x - w * 0.8, top - 7, w * 1.6, 9); c.fillRect(x - w * 0.6, top - 14, w * 1.2, 8); }
        c.fillRect(x - w * 0.75, y - 6, w * 1.5, 8);
        c.strokeStyle = "rgba(0,0,0,0.18)"; c.lineWidth = 1;
        for (var f = 1; f < 4; f++) { c.beginPath(); c.moveTo(x - w / 2 + w * f / 4, top + 8); c.lineTo(x - w / 2 + w * f / 4, y - 6); c.stroke(); }
        break; }
      case "stair": c.fillStyle = tone([150 + it.tone * 40, 138 + it.tone * 35, 118 + it.tone * 30]); c.fillRect(x - w / 2, y, w, h); break;
      case "relief": {
        c.fillStyle = tone([176, 160, 138]); c.fillRect(x - w / 2, y, w, h);
        c.fillStyle = "rgba(60,48,36,0.45)";
        for (var pn = 0; pn < it.panels; pn++) { var rx = x - w / 2 + w * (pn + 0.5) / it.panels; c.fillRect(rx - 4, y + h * 0.15, 8, h * 0.7); c.beginPath(); c.arc(rx, y + h * 0.15, 5, 0, 6.2832); c.fill(); }
        break; }
      case "lamp": c.fillStyle = "rgb(40,40,48)"; c.fillRect(x - 2, y - h, 4, h); c.fillStyle = st.pal.amb < 0.6 ? "rgb(255,225,150)" : "rgb(90,90,100)"; c.beginPath(); c.arc(x, y - h, 7, 0, 6.2832); c.fill(); break;
      case "rock": c.fillStyle = tone([110 + it.tone * 30, 100 + it.tone * 25, 90]); c.beginPath(); c.ellipse(x, y, w / 2, h, 0, 3.14, 6.2832); c.fill(); break;
      case "kelp": {
        c.strokeStyle = tone([30, 110 + it.tone * 40, 70]); c.lineWidth = Math.max(3, w); c.beginPath(); c.moveTo(x, y);
        for (var s = 1; s <= 8; s++) c.lineTo(x + Math.sin(st.t * 0.9 + it.phase + s * 0.6) * 10 * s / 3, y - h * s / 8);
        c.stroke(); break; }
      case "fish": { var fx = ((it.x + st.t * it.speed) % 1.2 - 0.1) * W; c.fillStyle = hsl(it.tone * 0.15 + 0.03, 70, 55); c.beginPath(); c.ellipse(fx, y, w / 2, w / 4, 0, 0, 6.2832); c.fill(); c.beginPath(); c.moveTo(fx - w / 2, y); c.lineTo(fx - w * 0.8, y - w * 0.25); c.lineTo(fx - w * 0.8, y + w * 0.25); c.closePath(); c.fill(); break; }
      case "window": {
        c.fillStyle = "rgb(30,26,24)"; c.fillRect(x - w / 2 - 8, y - 8, w + 16, h + 16);
        var gg = c.createLinearGradient(0, y, 0, y + h); gg.addColorStop(0, rgb(pal.top)); gg.addColorStop(1, rgb(pal.bot));
        c.fillStyle = gg; c.fillRect(x - w / 2, y, w, h);
        c.strokeStyle = "rgb(30,26,24)"; c.lineWidth = 4; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + h); c.moveTo(x - w / 2, y + h / 2); c.lineTo(x + w / 2, y + h / 2); c.stroke();
        break; }
      case "table": c.fillStyle = "rgb(84,58,38)"; c.fillRect(x - w / 2, y, w, 8); c.fillRect(x - w / 2 + 6, y, 6, h); c.fillRect(x + w / 2 - 12, y, 6, h); break;
      case "bench": c.fillStyle = "rgb(150,154,160)"; c.fillRect(x - w / 2, y, w, 10); c.fillRect(x - w / 2 + 4, y, 8, h); c.fillRect(x + w / 2 - 12, y, 8, h); break;
      case "flask": {
        c.strokeStyle = "rgba(220,235,255,0.8)"; c.lineWidth = 2; c.beginPath(); c.moveTo(x - h * 0.15, y - h); c.lineTo(x - h * 0.15, y - h * 0.6); c.lineTo(x - h * 0.45, y); c.lineTo(x + h * 0.45, y); c.lineTo(x + h * 0.15, y - h * 0.6); c.lineTo(x + h * 0.15, y - h); c.stroke();
        c.fillStyle = hsl(it.tone, 70, 55, 0.75); c.beginPath(); c.moveTo(x - h * 0.4, y - h * 0.1 * it.fill); c.lineTo(x - h * 0.45, y); c.lineTo(x + h * 0.45, y); c.lineTo(x + h * 0.4, y - h * 0.1 * it.fill); c.closePath(); c.fill(); break; }
      case "planet": {
        var pr = w * 0.5; c.fillStyle = hsl(it.tone, 45, 45); c.beginPath(); c.arc(x, y, pr, 0, 6.2832); c.fill();
        if (it.ring) { c.strokeStyle = "rgba(230,220,200,0.6)"; c.lineWidth = 3; c.beginPath(); c.ellipse(x, y, pr * 1.6, pr * 0.35, -0.3, 0, 6.2832); c.stroke(); } break; }
      case "cloud": {
        c.fillStyle = "rgba(" + Math.round(235 - st.dark * 120) + "," + Math.round(238 - st.dark * 120) + "," + Math.round(245 - st.dark * 110) + ",0.92)";
        var cw = w * W, ox = Math.sin(st.t * 0.15 + it.x * 5) * 14;
        for (var q = 0; q < 4; q++) { c.beginPath(); c.ellipse(x + ox + (q - 1.5) * cw * 0.22, y + (q % 2) * 6, cw * 0.2, cw * 0.11, 0, 0, 6.2832); c.fill(); }
        break; }
      case "arrow": {
        var y2 = it.to_y * H, dash = (st.t * 40) % 20; c.strokeStyle = it.tone < 0.3 ? "rgba(255,170,80,0.95)" : (it.tone > 0.8 ? "rgba(120,190,255,0.95)" : "rgba(120,220,170,0.95)");
        c.lineWidth = 4; c.setLineDash([12, 8]); c.lineDashOffset = -dash; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y2); c.stroke(); c.setLineDash([]);
        var dirn = y2 > y ? 1 : -1; c.beginPath(); c.moveTo(x - 9, y2 - dirn * 14); c.lineTo(x, y2); c.lineTo(x + 9, y2 - dirn * 14); c.stroke();
        break; }
      case "sea": {
        var sg = c.createLinearGradient(0, y, 0, H); sg.addColorStop(0, "rgb(40,120,180)"); sg.addColorStop(1, "rgb(10,50,100)");
        c.fillStyle = sg; c.fillRect(0, y, W, H - y); c.strokeStyle = "rgba(255,255,255,0.35)"; c.lineWidth = 2;
        for (var wv = 0; wv < 4; wv++) { c.beginPath(); for (var xx = 0; xx <= W; xx += 20) { var yy = y + 18 + wv * 26 + Math.sin(xx * 0.02 + st.t * 1.2 + wv) * 4; if (xx === 0) c.moveTo(xx, yy); else c.lineTo(xx, yy); } c.stroke(); }
        break; }
    }
    mark("decor:" + it.k);
  }
'''
