# -*- coding: utf-8 -*-
"""بخشِ سومِ runtimeِ JS: مونتاجِ لایه‌ها (۰ تا ۸)، برچسب/زیرنویس، صدا (WebAudio)، حلقهٔ اجرا."""

JS_SCENE = r'''
  // ---------- مونتاجِ لایه‌ها: 0 Background .. 8 Text ----------
  var GROUND = {grass: [58, 112, 58], sand: [204, 172, 112], stone: [138, 128, 112], snow: [226, 235, 246],
                street: [66, 68, 78], floor: [92, 70, 55], water: [28, 86, 140]};
  function envAmb(env, pal) {
    if (env.name === "underwater") return 0.85;
    if (env.name === "space") return 0.35;
    if (!env.has_sky) return Math.max(0.45, pal.amb);
    return pal.amb;
  }
  function drawBackdrop(c, sc, env, st) {
    var pal = st.pal;
    if (env.name === "underwater") {
      var g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "rgb(20,110,150)"); g.addColorStop(1, "rgb(3,24,48)");
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      for (var i = 0; i < 5; i++) { var sx = (i + 0.5) / 5 * W + Math.sin(st.t * 0.4 + i) * 30; c.fillStyle = "rgba(180,240,255,0.06)"; c.beginPath(); c.moveTo(sx - 20, 0); c.lineTo(sx + 20, 0); c.lineTo(sx + 90, H); c.lineTo(sx - 60, H); c.closePath(); c.fill(); }
      var r = mulberry(env.seed | 0); c.fillStyle = "rgba(255,255,255,0.6)";
      for (var b = 0; b < (LOWFX ? 10 : 22); b++) { var bx = r() * W, by = H - ((st.t * (30 + r() * 40) + r() * H) % (H + 20)); c.beginPath(); c.arc(bx + Math.sin(st.t + b) * 6, by, 2 + r() * 3, 0, 6.2832); c.fill(); }
      mark("backdrop:underwater"); return;
    }
    if (env.name === "space") { c.fillStyle = "rgb(3,4,14)"; c.fillRect(0, 0, W, H); drawStars(c, env, 1, st); mark("backdrop:space"); return; }
    if (!env.has_sky) {
      var wg = c.createLinearGradient(0, 0, 0, H * env.horizon); wg.addColorStop(0, "rgb(68,62,66)"); wg.addColorStop(1, "rgb(104,94,92)");
      c.fillStyle = wg; c.fillRect(0, 0, W, H); mark("backdrop:indoor"); return;
    }
    var sg = c.createLinearGradient(0, 0, 0, H * 0.85); sg.addColorStop(0, rgb(pal.top)); sg.addColorStop(1, rgb(pal.bot));
    c.fillStyle = sg; c.fillRect(0, 0, W, H);
    if (pal.star > 0.02) drawStars(c, env, pal.star * (1 - st.rain * 0.8), st);
    if (pal.sunA > 0.02) {
      var sx = pal.sx * W, sy = pal.sy * H, a = pal.sunA * (1 - st.rain * 0.75), gg = c.createRadialGradient(sx, sy, 4, sx, sy, H * 0.3);
      gg.addColorStop(0, "rgba(255,235,170," + 0.7 * a + ")"); gg.addColorStop(1, "rgba(255,200,120,0)"); c.fillStyle = gg; c.fillRect(0, 0, W, H);
      c.fillStyle = "rgba(255,244,200," + a + ")"; c.beginPath(); c.arc(sx, sy, H * 0.035, 0, 6.2832); c.fill(); mark("celestial:sun");
    }
    if (pal.moonA > 0.02 && !st.hasMoonSubject) {
      var mx = (PAL.night.sx) * W, my = PAL.night.sy * H, ma = pal.moonA * (1 - st.rain * 0.7);
      c.fillStyle = "rgba(235,238,250," + ma + ")"; c.beginPath(); c.arc(mx, my, H * 0.032, 0, 6.2832); c.fill(); mark("celestial:moon");
    }
    mark("backdrop:sky");
  }
  function drawStars(c, env, a, st) {
    var r = mulberry((env.seed | 0) + 5), n = LOWFX ? 60 : (env.name === "space" ? 260 : 140);
    for (var i = 0; i < n; i++) {
      var x = r() * W, y = r() * H * (env.name === "space" ? 1 : 0.6), tw = 0.6 + 0.4 * Math.sin(st.t * 2 + i);
      c.fillStyle = "rgba(255,255,255," + (a * tw * (0.3 + 0.7 * r())) + ")"; c.fillRect(x, y, 1.6, 1.6);
    }
    mark("stars", n);
  }
  function drawGround(c, env, st) {
    var col = GROUND[env.ground]; if (!col || env.name === "underwater") return;
    var y = env.horizon * H, g = c.createLinearGradient(0, y, 0, H);
    g.addColorStop(0, rgb(mixArr(col, st.pal.bot, 0.35))); g.addColorStop(1, rgb(col, 0.8));
    c.fillStyle = g; c.fillRect(0, y, W, H - y);
    if (st.rain > 0.2 && env.ground !== "water") { var sh = c.createLinearGradient(0, y, 0, H); sh.addColorStop(0, "rgba(200,215,240," + 0.22 * st.rain + ")"); sh.addColorStop(1, "rgba(200,215,240,0)"); c.fillStyle = sh; c.fillRect(0, y, W, H - y); mark("wet_ground"); }
    mark("ground");
  }
  function drawLabels(c, sc, ts) {
    (sc.labels || []).forEach(function (lb) {
      if (ts < lb.start || ts > lb.start + lb.duration) return;
      var a = Math.min(1, (ts - lb.start) / 0.4, (lb.start + lb.duration - ts) / 0.4);
      var fs = lb.role === "subtitle" ? Math.round(H * 0.045) : Math.round(H * 0.04);
      c.font = "bold " + fs + "px " + ((sc.graph.style && sc.graph.style.font) || "Tahoma");
      c.textAlign = "center"; c.textBaseline = "middle";
      try { c.direction = /[\u0600-\u06FF]/.test(lb.text) ? "rtl" : "ltr"; } catch (e) {}
      var tw = c.measureText(lb.text).width + 28, x = lb.x * W, y = lb.y * H;
      c.globalAlpha = clamp(a, 0, 1) * 0.92; c.fillStyle = "rgba(0,0,0,0.6)"; c.fillRect(x - tw / 2, y - fs * 0.85, tw, fs * 1.7);
      c.fillStyle = lb.role === "disclaimer" ? "rgb(255,215,140)" : "rgb(255,255,255)"; c.fillText(lb.text, x, y);
      c.globalAlpha = 1; mark("label:" + lb.role);
    });
  }
  function drawScene(si, ts, alpha) {
    var sc = scenes[si], nm = nodeMap(sc), env = nm.env.visual_properties, sky = nm.sky.visual_properties;
    var f = propAt(si, "sky", "time_blend", ts, 0), pal = palBlend(sky.from, sky.to, f);
    var rainNode = nm.weather, rain = rainNode ? propAt(si, "weather", "intensity", ts, 0) : 0;
    var L = sc.lighting, amb = envAmb(env, pal);
    if (rainNode && rainNode.visual_properties.kind !== "fog") { pal.top = mixArr(pal.top, [90, 95, 105], 0.35 * rain); pal.bot = mixArr(pal.bot, [110, 115, 125], 0.35 * rain); }
    var dark = clamp((1 - amb) * 0.55 + (0.5 - L.intensity) * 0.45 + rain * 0.08, 0, 0.82);
    var st = {si: si, sc: sc, t: ts, pal: pal, env: env, rain: rain, dark: dark, night: amb < 0.5,
              hasMoonSubject: !!(nm.subject && nm.subject.type === "moon")};
    var cm = cameraFor(si, sc, ts, nm);
    c.save(); c.globalAlpha = alpha;
    c.translate(W / 2, H / 2); c.scale(cm.z, cm.z); c.translate(-cm.fx * W, -cm.fy * H);
    mark("cam_zoom_x1000", Math.round(cm.z * 1000));
    drawBackdrop(c, sc, env, st);                                 // layer 0
    var decors = env.decor || [];
    drawGround(c, env, st);                                       // layer 1
    ["far", "mid"].forEach(function (ly) { decors.filter(function (d) { return d.layer === ly; }).sort(function (a, b) { return (a.y || 0) - (b.y || 0); }).forEach(function (d) { decor(c, d, st); }); });
    var nodes = sc.graph.nodes.filter(function (n) { return n.semantic_role === "subject" || n.semantic_role === "secondary"; });
    nodes.sort(function (a, b) { return nodeXY(si, sc, a, ts)[1] - nodeXY(si, sc, b, ts)[1]; });
    nodes.forEach(function (n) { var d = DRAWERS[n.type]; if (d) d(c, n, st); });        // layers 2-3
    decors.filter(function (d) { return d.layer === "fore"; }).forEach(function (d) { decor(c, d, st); });   // layer 4
    if (rainNode && DRAWERS[rainNode.visual_properties.kind]) DRAWERS[rainNode.visual_properties.kind](c, rainNode, st);  // layer 5
    if (L.fog && !rainNode) draw_fog(c, {}, {t: ts, rain: 0.6});
    c.fillStyle = "rgba(6,10,28," + dark + ")"; c.fillRect(cm.fx * W - W, cm.fy * H - H, W * 2, H * 2);   // layer 6: lighting
    var savedOp = c.globalCompositeOperation; c.globalCompositeOperation = "lighter";
    if (nm.window_light && DRAWERS.light_source) DRAWERS.light_source(c, nm.window_light, st);
    c.globalCompositeOperation = savedOp;
    c.restore();
    c.save(); c.globalAlpha = alpha;                              // layer 7: camera/film effects
    var sp = sc.graph.style || {}, vg = (sp.vignette === undefined ? 0.4 : sp.vignette) * (L.vignette ? 1 : 0);
    if (vg > 0) { var vgr = c.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.85); vgr.addColorStop(0, "rgba(0,0,0,0)"); vgr.addColorStop(1, "rgba(0,0,0," + vg + ")"); c.fillStyle = vgr; c.fillRect(0, 0, W, H); mark("vignette"); }
    var fl = flashAt(sc, ts); if (fl > 0.01) { c.fillStyle = "rgba(235,240,255," + 0.75 * fl + ")"; c.fillRect(0, 0, W, H); mark("flash"); }
    if (sp.letterbox) { c.fillStyle = "rgb(0,0,0)"; c.fillRect(0, 0, W, H * 0.05); c.fillRect(0, H * 0.95, W, H * 0.05); }
    c.restore();
    c.save(); c.globalAlpha = alpha; drawLabels(c, sc, ts); c.restore();                     // layer 8
    mark("scene:" + si);
  }
  function sceneAlpha(si, ts) {
    var sc = scenes[si], a = 1, tr = PROJECT.transitions;
    if (si > 0 && tr[si - 1] && ts < tr[si - 1].duration) a = ts / tr[si - 1].duration;
    var fi = 0, fo = sc.duration;
    (sc.timeline || []).forEach(function (e) { if (e.event === "main_action_start") fi = e.time; if (e.event === "fade_out_start") fo = e.time; });
    if (si === 0 && fi > 0 && ts < fi) a = Math.min(a, ts / fi);
    if (si < scenes.length - 1 && tr[si] && ts > sc.duration - tr[si].duration) a = Math.min(a, Math.max(0, (sc.duration - ts) / tr[si].duration));   // fade-through-black
    if (si === scenes.length - 1 && ts > fo) a = Math.min(a, Math.max(0, 1 - (ts - fo) / Math.max(0.001, sc.duration - fo)));
    return clamp(a, 0, 1);
  }
  function renderFrame(tg) {
    STATS = {};
    c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.fillStyle = "rgb(0,0,0)"; c.fillRect(0, 0, W, H);
    for (var i = 0; i < scenes.length; i++) {
      var ts = tg - starts[i];
      if (ts < 0 || ts > scenes[i].duration + 1e-6) continue;
      drawScene(i, ts, sceneAlpha(i, ts));
    }
    return STATS;
  }

  // ---------- صدا: Audio Plan → سنتز → Timeline → پخش ----------
  var AUD = {ctx: null, master: null, on: false, muted: false, voices: {}, fired: {}, lastT: -1, narration: "none"};
  var EV = PROJECT.global_audio || [];
  function noiseBuf(ctx, kind) {
    var n = 2 * ctx.sampleRate, b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0), last = 0;
    for (var i = 0; i < n; i++) { var w = Math.random() * 2 - 1; if (kind === "brown") { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; } else if (kind === "pink") { last = 0.98 * last + w * 0.12; d[i] = last; } else d[i] = w; }
    return b;
  }
  function ambience(ctx, out, cfg) {
    var src = ctx.createBufferSource(); src.buffer = noiseBuf(ctx, cfg.noise); src.loop = true;
    var f = ctx.createBiquadFilter(); f.type = cfg.ft; f.frequency.value = cfg.ff;
    var lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = cfg.lr; lg.gain.value = cfg.ld; lfo.connect(lg); lg.connect(f.frequency);
    var g = ctx.createGain(); g.gain.value = 0.0001; src.connect(f); f.connect(g); g.connect(out); src.start(0); lfo.start(0);
    return {gain: g, stop: function () { try { src.stop(); lfo.stop(); } catch (e) {} }};
  }
  var RECIPES = {
    rain: function (ctx, out) { return ambience(ctx, out, {noise: "white", ft: "highpass", ff: 900, lr: 3.0, ld: 150}); },
    wind: function (ctx, out) { return ambience(ctx, out, {noise: "pink", ft: "bandpass", ff: 500, lr: 0.25, ld: 300}); },
    underwater: function (ctx, out) { return ambience(ctx, out, {noise: "brown", ft: "lowpass", ff: 260, lr: 0.12, ld: 60}); },
    city: function (ctx, out) { return ambience(ctx, out, {noise: "brown", ft: "lowpass", ff: 520, lr: 0.08, ld: 120}); },
    forest: function (ctx, out) { return ambience(ctx, out, {noise: "pink", ft: "bandpass", ff: 1800, lr: 0.18, ld: 400}); },
    ambient_pad: function (ctx, out) {
      var g = ctx.createGain(); g.gain.value = 0.0001; g.connect(out); var oscs = [];
      [110, 138.6, 164.8, 220].forEach(function (fr, i) { var o = ctx.createOscillator(); o.type = "sine"; o.frequency.value = fr; o.detune.value = (i - 1.5) * 6; o.connect(g); o.start(0); oscs.push(o); });
      return {gain: g, stop: function () { oscs.forEach(function (o) { try { o.stop(); } catch (e) {} }); }};
    }
  };
  var SHOTS = {
    thunder: function (ctx, out, vol, dur) {
      var s = ctx.createBufferSource(); s.buffer = noiseBuf(ctx, "brown"); var f = ctx.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 420;
      var g = ctx.createGain(); var t0 = ctx.currentTime; g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(vol, t0 + 0.12); g.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      s.connect(f); f.connect(g); g.connect(out); s.start(t0); s.stop(t0 + dur + 0.1);
    },
    footstep: function (ctx, out, vol) {
      var s = ctx.createBufferSource(); s.buffer = noiseBuf(ctx, "brown"); var f = ctx.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 220;
      var g = ctx.createGain(); var t0 = ctx.currentTime; g.gain.setValueAtTime(vol, t0); g.gain.linearRampToValueAtTime(0.0001, t0 + 0.12);
      s.connect(f); f.connect(g); g.connect(out); s.start(t0); s.stop(t0 + 0.14);
    },
    door: function (ctx, out, vol, dur) {
      var o = ctx.createOscillator(); o.type = "sawtooth"; var f = ctx.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 400;
      var g = ctx.createGain(); var t0 = ctx.currentTime; o.frequency.setValueAtTime(140, t0); o.frequency.linearRampToValueAtTime(80, t0 + dur);
      g.gain.setValueAtTime(vol * 0.5, t0); g.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      o.connect(f); f.connect(g); g.connect(out); o.start(t0); o.stop(t0 + dur + 0.05);
    }
  };
  function audioEnv(e, t) {
    var a = 1, end = e.start + e.duration;
    if (e.fade_in > 0) a = Math.min(a, (t - e.start) / e.fade_in);
    if (e.fade_out > 0) a = Math.min(a, (end - t) / e.fade_out);
    return clamp(a, 0, 1);
  }
  function audioStart() {
    if (AUD.on) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { AUD.narration = AUD.narration; return; }
    try { AUD.ctx = new AC(); AUD.master = AUD.ctx.createGain(); AUD.master.gain.value = AUD.muted ? 0.0001 : 1; AUD.master.connect(AUD.ctx.destination); AUD.on = true; } catch (err) { AUD.on = false; }
  }
  function stopVoices() { Object.keys(AUD.voices).forEach(function (k) { AUD.voices[k].stop(); }); AUD.voices = {}; }
  function speak(e) {
    var n = PROJECT.narration;
    if (window.speechSynthesis && typeof SpeechSynthesisUtterance !== "undefined" && n) {
      try { var u = new SpeechSynthesisUtterance(n.text); u.lang = n.lang === "en" ? "en-US" : "fa-IR"; window.speechSynthesis.cancel(); window.speechSynthesis.speak(u); AUD.narration = "tts"; return; } catch (err) {}
    }
    AUD.narration = "subtitles";
  }
  function audioTick(tg) {
    if (!AUD.on || !AUD.ctx) return;
    if (tg < AUD.lastT - 0.05) { stopVoices(); AUD.fired = {}; }
    AUD.lastT = tg;
    var now = AUD.ctx.currentTime;
    EV.forEach(function (e) {
      var active = tg >= e.start && tg <= e.start + e.duration;
      if (e.type === "ambience" || e.type === "music") {
        var v = AUD.voices[e.id];
        if (active && !v && RECIPES[e.source]) { v = RECIPES[e.source](AUD.ctx, AUD.master); AUD.voices[e.id] = v; }
        if (v && active) v.gain.gain.setTargetAtTime(e.volume * audioEnv(e, tg), now, 0.08);
        if (v && !active) { v.stop(); delete AUD.voices[e.id]; }
      } else if (e.type === "sfx") {
        if (!AUD.fired[e.id] && tg >= e.start) { AUD.fired[e.id] = true; if (tg < e.start + 0.5 && SHOTS[e.source]) SHOTS[e.source](AUD.ctx, AUD.master, e.volume, e.duration); }
      } else if (e.type === "narration") {
        if (!AUD.fired[e.id] && tg >= e.start) { AUD.fired[e.id] = true; if (tg < e.start + 0.5) speak(e); }
      }
    });
  }
'''
