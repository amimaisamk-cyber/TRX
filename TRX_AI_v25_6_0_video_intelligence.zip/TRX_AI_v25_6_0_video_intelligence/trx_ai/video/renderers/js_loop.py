# -*- coding: utf-8 -*-
"""بخشِ چهارم: HUD، حلقهٔ اجرا، کیفیتِ تطبیقی، و hook مخصوصِ تست/بازرسی (``window.__TRX``)."""

JS_LOOP = r'''
  // ---------- HUD و حلقه ----------
  var root = document.getElementById("scene-root");
  var btnPlay = document.getElementById("btnPlayPause"), btnReset = document.getElementById("btnReset"), seek = document.getElementById("seek");
  var timeLabel = document.getElementById("timeLabel"), audioTag = document.getElementById("audioTag"), qualityTag = document.getElementById("qualityTag");
  var unlock = document.getElementById("audioUnlock"), btnMute = document.getElementById("btnMute");
  var TL = {playing: true, elapsed: 0, last: null};
  var srcs = {}; EV.forEach(function (e) { srcs[e.source] = true; });
  var srcList = Object.keys(srcs);
  var AC0 = (typeof window.AudioContext !== "undefined") || (typeof window.webkitAudioContext !== "undefined");
  if (PROJECT.explicit_silence) { audioTag.textContent = "🔇 بدونِ صدا (طبقِ درخواست)"; btnMute.style.display = "none"; }
  else if (!EV.length) { audioTag.textContent = "🔇 این صحنه صدایی ندارد"; btnMute.style.display = "none"; }
  else if (!AC0) { audioTag.textContent = "⚠️ WebAudio در این دستگاه موجود نیست؛ صدا پخش نمی‌شود: " + srcList.join("، "); btnMute.style.display = "none"; }
  else { audioTag.textContent = "🔈 " + srcList.join("، ") + " (سنتزِ زنده)"; unlock.style.display = "flex";
    unlock.addEventListener("click", function () { audioStart(); unlock.style.display = "none"; }, {once: true}); }
  btnMute.addEventListener("click", function () { AUD.muted = !AUD.muted; if (AUD.master) AUD.master.gain.value = AUD.muted ? 0.0001 : 1; btnMute.textContent = AUD.muted ? "🔇" : "🔈"; });
  qualityTag.textContent = "کیفیت: " + PROJECT.profile;
  function fmt(s) { s = Math.max(0, s); var m = Math.floor(s / 60), r = Math.floor(s % 60); return (m < 10 ? "0" + m : m) + ":" + (r < 10 ? "0" + r : r); }
  var ft = [];
  function perf(dt) {
    ft.push(dt); if (ft.length > 40) ft.shift();
    if (!LOWFX && ft.length === 40) { var avg = ft.reduce(function (a, b) { return a + b; }, 0) / 40; if (avg > 42) { LOWFX = true; qualityTag.textContent = "کیفیت: " + PROJECT.profile + " (کاهشِ خودکار به‌خاطرِ افتِ FPS)"; } }
  }
  function frame(now) {
    try {
      if (TL.last === null) TL.last = now;
      var dt = now - TL.last; TL.last = now; perf(dt);
      if (TL.playing) { TL.elapsed += dt; if (TL.elapsed >= TOTAL * 1000) { TL.elapsed = TOTAL * 1000; TL.playing = false; btnPlay.textContent = "▶"; if (AUD.ctx && AUD.ctx.suspend) AUD.ctx.suspend(); } }
      var tg = TL.elapsed / 1000;
      renderFrame(tg); if (TL.playing) audioTick(tg);
      timeLabel.textContent = fmt(tg) + " / " + fmt(TOTAL); seek.value = Math.round(TOTAL > 0 ? tg / TOTAL * 1000 : 0);
    } catch (err) { TL.playing = false; window.__TRX_ERROR = String(err && err.message || err); qualityTag.textContent = "⚠️ خطای اجرا -- صحنه متوقف شد."; return; }
    requestAnimationFrame(frame);
  }
  btnPlay.addEventListener("click", function () {
    if (TL.playing) { TL.playing = false; btnPlay.textContent = "▶"; if (AUD.ctx && AUD.ctx.suspend) AUD.ctx.suspend(); if (window.speechSynthesis) try { window.speechSynthesis.pause(); } catch (e) {} }
    else { if (TL.elapsed >= TOTAL * 1000) { TL.elapsed = 0; } TL.playing = true; btnPlay.textContent = "⏸"; if (AUD.ctx && AUD.ctx.resume) AUD.ctx.resume(); requestAnimationFrame(function (n) { TL.last = n; requestAnimationFrame(frame); }); }
  });
  btnReset.addEventListener("click", function () { TL.elapsed = 0; TL.playing = true; btnPlay.textContent = "⏸"; stopVoices(); AUD.fired = {}; requestAnimationFrame(function (n) { TL.last = n; requestAnimationFrame(frame); }); });
  seek.addEventListener("input", function () { TL.elapsed = (seek.value / 1000) * TOTAL * 1000; renderFrame(TL.elapsed / 1000); });
  // hook بازرسی: رندرِ همزمانِ یک فریم + آمارِ واقعیِ آنچه کشیده شد (برایِ Render→Inspect→Repair و تست)
  window.__TRX = {total: TOTAL, scenes: scenes.length, render: function (t) { return renderFrame(t); },
                  audioStart: audioStart, audioTick: function (t) { audioTick(t); }, aud: AUD, fired: function () { return AUD.fired; },
                  reset: function () { stopVoices(); AUD.fired = {}; AUD.lastT = -1; }};
  requestAnimationFrame(function (t0) { TL.last = t0; requestAnimationFrame(frame); });
  setTimeout(function () { root.style.opacity = "1"; }, 30);
})();
'''
