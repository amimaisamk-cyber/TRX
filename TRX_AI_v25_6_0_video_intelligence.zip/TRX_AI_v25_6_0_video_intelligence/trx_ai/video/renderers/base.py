# -*- coding: utf-8 -*-
"""
Backend Abstraction (بخشِ ۳۲ سندِ ارتقا): HTML/Canvas تنها backendِ دائمی نیست.

قراردادها (ABC) مستقل از هر پیاده‌سازی‌اند؛ ``HTMLCanvasRenderer`` اولین پیاده‌سازی
است و backendهایِ آینده (SVG/Native) فقط باید همین واسط‌ها را برآورده کنند.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class VideoRenderer(ABC):
    name: str = "abstract"

    @abstractmethod
    def render(self, project: Any) -> str:
        """VideoProject را به خروجیِ قابلِ‌نمایش (رشتهٔ HTML برایِ backend فعلی) تبدیل می‌کند."""

    @abstractmethod
    def supported_kinds(self) -> tuple[str, ...]:
        """kindهایی از شیء که این backend واقعاً می‌تواند بکشد (برایِ UNSUPPORTED صادقانه)."""


class AudioRenderer(ABC):
    @abstractmethod
    def supported_sources(self) -> tuple[str, ...]:
        """منابعِ صدایی که backend می‌تواند سنتز/پخش کند."""


class AssetProvider(ABC):
    @abstractmethod
    def get(self, key: str) -> bytes | None:
        """دارایی (فایلِ صوتی/تصویر). None = در دسترس نیست → procedural fallback."""


class ExportBackend(ABC):
    @abstractmethod
    def export(self, rendered: str, path: str) -> str:
        """نوشتنِ خروجی روی دیسک؛ مسیرِ نهایی را برمی‌گرداند."""


class NullAssetProvider(AssetProvider):
    """هیچ دارایی‌ای ندارد → همه‌چیز procedural (سازگار با موبایل، بدونِ دانلود)."""

    def get(self, key: str) -> bytes | None:
        return None


class FileExportBackend(ExportBackend):
    def export(self, rendered: str, path: str) -> str:
        with open(path, "w", encoding="utf-8") as f:
            f.write(rendered)
        return path
