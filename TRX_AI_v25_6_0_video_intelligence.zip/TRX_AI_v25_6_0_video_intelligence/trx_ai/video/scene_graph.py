# -*- coding: utf-8 -*-
"""
Scene Graph (بخشِ ۵ سندِ ارتقا): موجودیت‌ها + روابطِ معنایی.

حرکت و دوربین بر پایهٔ «معنا» (target = house) برنامه‌ریزی می‌شوند، نه
مختصاتِ خام. این ماژول فقط دادهٔ گراف و اعتبارسنجیِ ارجاع‌ها را دارد و هیچ
وابستگی‌ای به بقیهٔ پکیج ندارد.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

RELATION_KINDS = ("attached_to", "behind", "in_front_of", "inside", "near", "far_from",
                  "follows", "looks_at", "interacts_with", "emits_sound", "illuminated_by")


@dataclass
class Node:
    id: str
    type: str                                   # environment | sky | weather | subject-kind | light_source | label
    semantic_role: str = "decor"                # subject | secondary | environment | weather | light | sky | label
    transform: dict[str, float] = field(default_factory=lambda: {"x": 0.5, "y": 0.5, "scale": 1.0, "rotation": 0.0})
    visual_properties: dict[str, Any] = field(default_factory=dict)
    material: str = ""
    animation: list[dict[str, Any]] = field(default_factory=list)
    audio_sources: list[str] = field(default_factory=list)
    visibility: bool = True
    parent: str | None = None
    children: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    layer: int = 2                              # 0..8 (بخشِ ۶)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Relation:
    kind: str
    source: str
    target: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class SceneGraph:
    def __init__(self) -> None:
        self.nodes: dict[str, Node] = {}
        self.relations: list[Relation] = []

    # -- ساخت --
    def add(self, node: Node) -> Node:
        if node.id in self.nodes:
            raise ValueError(f"node تکراری: {node.id}")
        self.nodes[node.id] = node
        if node.parent and node.parent in self.nodes:
            p = self.nodes[node.parent]
            if node.id not in p.children:
                p.children.append(node.id)
        return node

    def remove(self, node_id: str) -> None:
        n = self.nodes.pop(node_id, None)
        if n and n.parent in self.nodes:
            self.nodes[n.parent].children = [c for c in self.nodes[n.parent].children if c != node_id]
        self.relations = [r for r in self.relations if node_id not in (r.source, r.target)]

    def relate(self, kind: str, source: str, target: str) -> None:
        if kind not in RELATION_KINDS:
            raise ValueError(f"relation ناشناخته: {kind}")
        rel = Relation(kind, source, target)
        if not any(r.kind == kind and r.source == source and r.target == target for r in self.relations):
            self.relations.append(rel)

    # -- پرس‌وجو --
    def by_role(self, role: str) -> list[Node]:
        return [n for n in self.nodes.values() if n.semantic_role == role]

    def by_type(self, typ: str) -> list[Node]:
        return [n for n in self.nodes.values() if n.type == typ]

    def get(self, node_id: str | None) -> Node | None:
        return self.nodes.get(node_id) if node_id else None

    def related(self, kind: str, source: str) -> list[str]:
        return [r.target for r in self.relations if r.kind == kind and r.source == source]

    # -- اعتبارسنجی --
    def validate(self) -> list[str]:
        errs: list[str] = []
        for n in self.nodes.values():
            if n.parent and n.parent not in self.nodes:
                errs.append(f"{n.id}: parent ناموجود ({n.parent})")
            for c in n.children:
                if c not in self.nodes:
                    errs.append(f"{n.id}: child ناموجود ({c})")
            if not 0 <= n.layer <= 8:
                errs.append(f"{n.id}: layer خارج از بازه ({n.layer})")
            # حلقه در parent
            seen, cur = set(), n
            while cur.parent:
                if cur.id in seen:
                    errs.append(f"{n.id}: حلقه در parent")
                    break
                seen.add(cur.id)
                cur = self.nodes.get(cur.parent) or Node(id="?")
                if cur.id == "?":
                    break
        for r in self.relations:
            if r.kind not in RELATION_KINDS:
                errs.append(f"relation ناشناخته: {r.kind}")
            for end in (r.source, r.target):
                if end not in self.nodes:
                    errs.append(f"relation {r.kind}: گرهٔ ناموجود ({end})")
        return errs

    # -- سریال‌سازی --
    def to_dict(self) -> dict[str, Any]:
        return {"nodes": [n.to_dict() for n in self.nodes.values()],
                "relations": [r.to_dict() for r in self.relations]}

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "SceneGraph":
        g = SceneGraph()
        for nd in d.get("nodes", []):
            g.nodes[nd["id"]] = Node(**nd)
        g.relations = [Relation(**r) for r in d.get("relations", [])]
        return g
