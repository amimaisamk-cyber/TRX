# -*- coding: utf-8 -*-
"""
Scene Planner (فازهای B/C/D سندِ ارتقا): ``VideoIntent`` → ``SceneSpec`` با Scene Graph واقعی.

طراحی: تصمیم‌هایِ برنامه‌ریزی در ``scene.graph["plan"]`` ثبت می‌شوند و Timeline/Audio
*از روی همان plan* بازسازی می‌شوند (``rebuild_timeline`` / ``rebuild_audio``).
بنابراین هر ``ensure_*`` idempotent است و Repair Loop فقط همان‌ها را دوباره صدا می‌زند
(اصلاحِ هدفمند، نه بازسازیِ کل).
"""

from __future__ import annotations

import hashlib
import random
import re
import time
import uuid
from typing import Any

from .scene_schema import SceneSpec, ObjectSpec, LightingSpec, TimelineEvent
from .scene_graph import SceneGraph, Node
from .semantic_planner.intent import VideoIntent
from . import environment_library as envlib
from . import object_library as objlib
from . import timeline_engine as tl
from . import camera_planner, lighting_planner, motion_planner, audio_planner, style_system

ASPECT_DIMS = {"16:9": (1280, 720), "9:16": (720, 1280), "1:1": (1000, 1000)}
RENDER_LONG_SIDE = {"low": 640, "medium": 960, "high": 1280}
_OLD_RE = re.compile(r"قدیمی|کهنه|متروکه|\bold\b|abandoned|ancient house")
_LIGHT_ENV = {"laboratory": "lab", "futuristic_city": "city", "village": "forest", "street": "city",
              "mountain": "desert", "space": "night_sky", "water_cycle": "sky"}
_ROLE_CAMERA = {
    "main": None,
    "establishing": {"shot": "establishing", "move": "pan"},
    "approach": {"move": "dolly_in"},
    "close": {"shot": "close_up"},
    "event": {"move": "focus_transition"},
    "ending": {"move": "dolly_out"},
}
_ROLE_SEQ = ("establishing", "approach", "close", "event", "ending")


class PlanCtx:
    def __init__(self, intent: VideoIntent, seed: int, quality: str = "medium", role: str = "main",
                 index: int = 0, n_scenes: int = 1, allow_auto_music: bool = False):
        self.intent, self.seed, self.quality = intent, seed, quality
        self.role, self.index, self.n_scenes = role, index, n_scenes
        self.allow_auto_music = allow_auto_music


# ----------------------------------------------------------------------
#   کمکی‌هایِ گراف
# ----------------------------------------------------------------------

def load_graph(scene: SceneSpec) -> SceneGraph:
    return SceneGraph.from_dict(scene.graph) if scene.graph.get("nodes") is not None else SceneGraph()


def save_graph(scene: SceneSpec, g: SceneGraph) -> None:
    d = g.to_dict()
    scene.graph = {**{k: v for k, v in scene.graph.items() if k not in ("nodes", "relations")}, **d}


def plan_of(scene: SceneSpec) -> dict[str, Any]:
    return scene.graph.setdefault("plan", {})


def stable_seed(intent: VideoIntent) -> int:
    if intent.seed:
        return intent.seed
    return int(hashlib.sha1(intent.semantic_key().encode("utf-8")).hexdigest()[:8], 16)


def new_scene_id() -> str:
    return f"scene_{int(time.time())}_{uuid.uuid4().hex[:6]}"


def ground_y(env_name: str) -> float:
    return min(0.92, envlib.env_def(env_name).horizon + 0.27)


def _sync_object(scene: SceneSpec, spec: ObjectSpec) -> None:
    scene.objects = [o for o in scene.objects if o.id != spec.id] + [spec]


def _drop_object(scene: SceneSpec, oid: str) -> None:
    scene.objects = [o for o in scene.objects if o.id != oid]


def default_environment(intent: VideoIntent) -> str:
    if intent.environment:
        return intent.environment
    if intent.subject == "house":
        return "village"
    return "forest"


# ----------------------------------------------------------------------
#   ensure_* : هر کدام فقط یک بخش را (دوباره) می‌سازند
# ----------------------------------------------------------------------

def ensure_environment(scene: SceneSpec, ctx: PlanCtx) -> None:
    g = load_graph(scene)
    g.remove("env")
    params = envlib.build_environment(scene.environment, ctx.seed, ctx.quality)
    g.add(Node(id="env", type="environment", semantic_role="environment", layer=1,
               visual_properties=params, tags=list(envlib.env_def(scene.environment).tags)))
    save_graph(scene, g)


def ensure_sky(scene: SceneSpec, ctx: PlanCtx) -> None:
    g = load_graph(scene)
    g.remove("sky")
    p = plan_of(scene)
    t_from = p.get("tod", {}).get("from", scene.time_of_day)
    t_to = p.get("tod", {}).get("to") or t_from
    g.add(Node(id="sky", type="sky", semantic_role="sky", layer=0,
               visual_properties={"from": t_from, "to": t_to, "visible": envlib.env_def(scene.environment).has_sky}))
    scene.sky = {"from": t_from, "to": t_to}
    scene.time_of_day = t_from
    save_graph(scene, g)


def _subject_position(ctx: PlanCtx, scene: SceneSpec, kind: str) -> tuple[float, float]:
    rng = random.Random(f"pos:{ctx.seed}")
    gy = ground_y(scene.environment)
    if kind == "character":
        return 0.5, gy + 0.06
    if kind in ("moon", "sun"):
        return round(0.68 + rng.uniform(-0.05, 0.05), 3), 0.22
    if kind == "house":
        return round(0.5 + rng.uniform(-0.05, 0.05), 3), gy
    return round(0.5 + rng.uniform(-0.05, 0.05), 3), gy


def _make_node(scene: SceneSpec, ctx: PlanCtx, node_id: str, kind: str, role: str, requested: str | None = None) -> Node:
    drawable = kind in objlib.KNOWN_KINDS
    actual = kind if drawable else "object"
    x, y = _subject_position(ctx, scene, actual)
    lit = scene.time_of_day in ("night", "dusk") or "window_light" in ctx.intent.lighting
    attrs = objlib.make_object(actual, ctx.seed + (0 if role == "subject" else 7), old=bool(_OLD_RE.search(ctx.intent.raw_text.lower())),
                               lit_window=lit)
    if not drawable:
        attrs["requested_kind"] = kind
    tags = [] if drawable else [f"unsupported:{kind}"]
    return Node(id=node_id, type=actual, semantic_role=role, layer=2 if role == "subject" else 3,
                transform={"x": x, "y": y, "scale": 1.0, "rotation": 0.0},
                visual_properties=attrs, material=attrs.get("material", ""), tags=tags)


def ensure_subject(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    g = load_graph(scene)
    g.remove("subject")
    _drop_object(scene, "subject")
    kind = it.subject or envlib.env_def(scene.environment).default_subject
    p = plan_of(scene)
    if kind:
        node = _make_node(scene, ctx, "subject", kind, "subject")
        g.add(node)
        scene.subject = "subject"
        _sync_object(scene, ObjectSpec(id="subject", type=node.type if node.type != "character" else "human_silhouette",
                                       kind=node.type, motion="slow_float" if node.type == "character" else "static",
                                       seed=ctx.seed, pos_x=node.transform["x"], pos_y=node.transform["y"],
                                       attrs=dict(node.visual_properties)))
        p["subject_kind"] = node.type
        p["subject_requested"] = kind
    else:
        scene.subject = None
        p["subject_kind"] = None
    save_graph(scene, g)


def ensure_character(scene: SceneSpec, ctx: PlanCtx) -> None:
    """شخصیتِ متحرک: اگر سوژه خودش character است همان؛ وگرنه شخصیتِ فرعی."""
    it = ctx.intent
    p = plan_of(scene)
    g = load_graph(scene)
    want = bool(it.motion) or "footsteps" in (it.audio or {}).get("sfx", []) or it.camera.get("move") == "follow"
    g.remove("character_1")
    _drop_object(scene, "character_1")
    if not want:
        p["motion"] = None
        save_graph(scene, g)
        return
    subj = g.get("subject")
    if subj is not None and subj.type == "character":
        cid = "subject"
    else:
        node = _make_node(scene, ctx, "character_1", "character", "secondary")
        node.transform["x"] = 0.15
        g.add(node)
        cid = "character_1"
        _sync_object(scene, ObjectSpec(id=cid, type="human_silhouette", kind="character", motion="walk", seed=ctx.seed + 7,
                                       pos_x=0.15, pos_y=node.transform["y"], attrs=dict(node.visual_properties)))
    direction = it.motion[0]["direction"] if it.motion else "ltr"
    speed = it.motion[0]["speed"] if it.motion else "normal"
    x0, x1 = (0.12, 0.88) if direction == "ltr" else (0.88, 0.12)
    cn = g.get(cid)
    cn.transform["x"] = x0
    cn.visual_properties["facing"] = 1 if direction == "ltr" else -1
    obj = next((o for o in scene.objects if o.id == cid), None)
    if obj is not None:
        obj.motion, obj.pos_x = "walk", x0
    prof = motion_planner.plan_motion_profile("walk", speed, scene.mood)
    p["motion"] = {"node": cid, "dir": direction, "x0": x0, "x1": x1, "profile": prof.to_dict()}
    save_graph(scene, g)


def ensure_weather(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    p = plan_of(scene)
    g = load_graph(scene)
    g.remove("weather")
    _drop_object(scene, "weather")
    kinds = {e.kind for e in it.events}
    if scene.weather == "none":
        p["weather"] = None
        save_graph(scene, g)
        return
    if not p.get("carries_events", True):
        mode = "always"
    elif "rain_start" in kinds:
        mode = "start_stop" if "rain_stop" in kinds else "start"
    elif "rain_stop" in kinds:
        mode = "stop"
    else:
        mode = "always"
    count = {"low": 90, "medium": 180, "high": 320}.get(ctx.quality, 180)
    g.add(Node(id="weather", type="weather", semantic_role="weather", layer=5,
               visual_properties={"kind": scene.weather, "count": count if scene.weather != "fog" else 14,
                                  "slant": 0.18, "seed": ctx.seed}, tags=[scene.weather]))
    _sync_object(scene, ObjectSpec(id="weather", type="particle_group", kind=scene.weather, motion="fall", seed=ctx.seed,
                                   density={"low": "low", "medium": "medium", "high": "high"}.get(ctx.quality, "medium")))
    p["weather"] = {"kind": scene.weather, "mode": mode}
    save_graph(scene, g)


def ensure_window_light(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    p = plan_of(scene)
    g = load_graph(scene)
    g.remove("window_light")
    _drop_object(scene, "window_light")
    subj = g.get("subject")
    night_like = (p.get("tod", {}).get("to") or scene.time_of_day) in ("night", "dusk") or scene.time_of_day in ("night", "dusk")
    want = "window_light" in it.lighting or (subj is not None and subj.type == "house" and night_like)
    if not want:
        p["window_light"] = False
        scene.lighting.local_sources = [s for s in scene.lighting.local_sources if s != "window_light"]
        save_graph(scene, g)
        return
    house = subj if (subj is not None and subj.type == "house") else None
    x = house.transform["x"] if house else 0.5
    y = house.transform["y"] - (house.visual_properties["h"] * 0.45 if house else 0.3)
    g.add(Node(id="window_light", type="light_source", semantic_role="light", layer=6,
               transform={"x": x, "y": y, "scale": 1.0, "rotation": 0.0}, parent="subject" if house else None,
               visual_properties={"color": "#ffd9a0", "radius": 0.16, "flicker": 0.05}, tags=["local", "warm"]))
    if house:
        house.visual_properties["window_lit"] = True
    if "window_light" not in scene.lighting.local_sources:
        scene.lighting.local_sources.append("window_light")
    p["window_light"] = True
    save_graph(scene, g)


def ensure_lighting(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    env = _LIGHT_ENV.get(scene.environment, scene.environment)
    light = lighting_planner.plan_lighting(env, mood=scene.mood)
    tod = scene.time_of_day
    if tod == "night":
        if scene.environment not in ("futuristic_city", "underwater", "laboratory", "room"):
            light.type, light.color_mood = "cold_moon", "dark"
        light.intensity = round(light.intensity * 0.75, 3)
    elif tod in ("sunset", "dawn"):
        light.type, light.color_mood = "warm_glow", "golden" if tod == "dawn" else "warm_orange"
    elif tod == "dusk":
        light.color_mood = "dark"
    if scene.weather in ("rain", "fog"):
        light.fog = True if scene.weather == "fog" else light.fog
        light.intensity = round(light.intensity * 0.9, 3)
    if "low_light" in it.lighting:
        light.intensity = round(max(0.1, light.intensity - 0.15), 3)
    if "neon_light" in it.lighting:
        light.type = "neon"
    light.time_of_day = tod
    light.local_sources = list(scene.lighting.local_sources)
    light.flash_times = list(scene.lighting.flash_times)
    scene.lighting = light
    scene.color_mood = light.color_mood


def ensure_storm(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    p = plan_of(scene)
    has = any(e.kind == "thunder" for e in it.events)
    n = 0
    if has:
        n = 2 if scene.duration >= 12 else 1
    p["storm"] = {"flashes": n}


def ensure_door(scene: SceneSpec, ctx: PlanCtx) -> None:
    p = plan_of(scene)
    want = any(e.kind == "door_open" for e in ctx.intent.events)
    g = load_graph(scene)
    if want:
        subj = g.get("subject")
        if subj is None or subj.type != "house":
            g.remove("house_1")
            _drop_object(scene, "house_1")
            node = _make_node(scene, ctx, "house_1", "house", "secondary")
            node.transform["x"] = 0.62
            g.add(node)
            _sync_object(scene, ObjectSpec(id="house_1", type="house", kind="house", seed=ctx.seed + 7,
                                           pos_x=0.62, pos_y=node.transform["y"], attrs=dict(node.visual_properties)))
            p["door_node"] = "house_1"
        else:
            p["door_node"] = "subject"
    else:
        p["door_node"] = None
    p["door"] = want
    save_graph(scene, g)


def ensure_labels(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    D = scene.duration
    labels: list[dict[str, Any]] = []
    d = envlib.env_def(scene.environment)
    fa = it.language != "en"
    if scene.environment == "water_cycle" or (it.educational and scene.environment == "water_cycle"):
        names = (("تبخیر", 0.18, 0.55), ("تراکم", 0.42, 0.14), ("بارش", 0.56, 0.42), ("رواناب", 0.80, 0.68)) if fa else \
                (("Evaporation", 0.18, 0.55), ("Condensation", 0.42, 0.14), ("Precipitation", 0.56, 0.42), ("Runoff", 0.80, 0.68))
        for i, (t, x, y) in enumerate(names):
            labels.append({"text": t, "x": x, "y": y, "start": round(D * (0.12 + 0.2 * i), 3), "duration": round(D * 0.3, 3), "role": "label"})
    if scene.environment == "ancient_persia" or it.historical:
        labels.append({"text": "بازسازیِ هنری بر پایهٔ شواهدِ تاریخی؛ جزئیاتِ رنگ و نور قطعی نیست" if fa else
                       "Artistic reconstruction based on historical evidence; colour and lighting are not certain",
                       "x": 0.5, "y": 0.06, "start": 0.0, "duration": D, "role": "disclaimer"})
        labels.append({"text": "تخت جمشید (پارسه): مجموعهٔ هخامنشی در فارس" if fa else "Persepolis: Achaemenid complex in Fars",
                       "x": 0.5, "y": 0.12, "start": round(D * 0.1, 3), "duration": round(D * 0.5, 3), "role": "fact"})
        scene.graph["historical"] = {"facts": ["Achaemenid complex", "columns and stairways"],
                                     "creative_reconstruction": ["colour palette", "lighting", "exact column arrangement"]}
    scene.labels = [lb for lb in scene.labels if lb.get("role") == "subtitle"] + labels


def ensure_camera(scene: SceneSpec, ctx: PlanCtx) -> None:
    it = ctx.intent
    g = load_graph(scene)
    p = plan_of(scene)
    role_cam = _ROLE_CAMERA.get(ctx.role) or {}
    cam_in = dict(it.camera) if ctx.role == "main" else {**role_cam, **({"move": it.camera["move"]} if (ctx.role == "approach" and it.camera.get("move")) else {})}
    move, shot, speed = cam_in.get("move"), cam_in.get("shot"), cam_in.get("speed")
    if move == "follow":
        tgt = (p.get("motion") or {}).get("node") or ("subject" if g.get("subject") else None)
    else:
        tgt = "subject" if g.get("subject") else None
    if tgt is None and (move or shot):
        tgt = "env"
    n = g.get(tgt)
    xy = (0.5, 0.5)
    if n is not None and tgt != "env":
        xy = (n.transform["x"], max(0.15, n.transform["y"] - 0.1))
    g.remove("camera")
    scene.camera = camera_planner.plan_semantic_camera(move, target=tgt, target_xy=xy, shot=shot, speed=speed, mood=scene.mood)
    g.add(Node(id="camera", type="camera", semantic_role="camera", layer=7,
               visual_properties={"move": scene.camera.move, "target": scene.camera.target}))
    save_graph(scene, g)


def rebuild_relations(scene: SceneSpec) -> None:
    g = load_graph(scene)
    g.relations = []
    subj = g.get("subject")
    if subj:
        g.relate("attached_to", "subject", "env")
        g.relate("in_front_of", "subject", "env")
    wl = g.get("window_light")
    if wl and subj:
        g.relate("attached_to", "window_light", "subject")
        g.relate("illuminated_by", "subject", "window_light")
    for cid in ("character_1",):
        if g.get(cid):
            g.relate("near", cid, "subject") if subj else None
            g.relate("in_front_of", cid, "env")
    cam = g.get("camera")
    tgt = scene.camera.target
    if cam and tgt and g.get(tgt):
        g.relate("follows" if scene.camera.move == "follow" else "looks_at", "camera", tgt)
    if g.get("weather"):
        g.relate("in_front_of", "weather", "env")
    save_graph(scene, g)


# ----------------------------------------------------------------------
#   Timeline از plan
# ----------------------------------------------------------------------

def rebuild_timeline(scene: SceneSpec, ctx: PlanCtx) -> None:
    D = scene.duration
    p = plan_of(scene)
    P: list[tl.Planned] = []
    fi = round(min(2.0, D * 0.25), 2)
    fo = round(max(fi + 0.5, D - D * 0.25), 2)
    P += [tl.Planned("t_fade_in", "fade_in", at=0.0), tl.Planned("t_main", "main_action_start", at=fi),
          tl.Planned("t_fade_out", "fade_out_start", at=fo), tl.Planned("t_end", "end", at=D)]

    w = p.get("weather")
    door = p.get("door")
    order: list[str] = []
    kinds_present = {e.kind for e in ctx.intent.events}
    if p.get("carries_events", True):
        for e in ctx.intent.events:
            if e.kind in ("rain_start", "rain_stop", "thunder", "door_open") and e.kind not in order:
                order.append(e.kind)
    if p.get("storm", {}).get("flashes") and "thunder" not in order:
        order.append("thunder")
    if door and "door_open" not in order:
        order.append("door_open")
    n = len(order)
    slot_t = {k: round(D * (0.4 if n == 1 else 0.15 + 0.6 * i / (n - 1)), 3) for i, k in enumerate(order)}
    prev_id, prev_t = None, 0.0

    def chained(pid: str, kind: str, t: float, **kw) -> tl.Planned:
        nonlocal prev_id, prev_t
        pl = tl.Planned(pid, kind, after=prev_id, offset=round(t - prev_t, 3), **kw) if prev_id else tl.Planned(pid, kind, at=t, **kw)
        prev_id, prev_t = pid, t
        return pl

    if w:
        mode = w["mode"] if p.get("carries_events", True) else "always"
        if mode == "always":
            P.append(tl.Planned("wx_on", "weather_intensity", at=0.0, target="weather", property="intensity", value=1.0))
        elif mode == "stop":
            P.append(tl.Planned("wx_on", "weather_intensity", at=0.0, target="weather", property="intensity", value=1.0))
        else:
            P.append(tl.Planned("wx_off0", "weather_intensity", at=0.0, target="weather", property="intensity", value=0.0))
    for kind in order:
        t = slot_t[kind]
        if kind == "rain_start" and w:
            P.append(chained("wx_start", "weather_intensity", t, target="weather", property="intensity", value=0.0, to=1.0, duration=1.0, easing="ease_out"))
        elif kind == "rain_stop" and w:
            P.append(chained("wx_stop", "weather_intensity", t, target="weather", property="intensity", value=1.0, to=0.0, duration=1.5, easing="ease_in_out"))
        elif kind == "thunder":
            flashes = p.get("storm", {}).get("flashes", 1) or 1
            P.append(chained("flash_1", "flash", t, target="sky", property="flash", value=1.0, duration=0.6))
            if flashes > 1 and t + max(1.5, D * 0.25) < D - 1.2:
                P.append(tl.Planned("flash_2", "flash", after="flash_1", offset=round(max(1.5, D * 0.25), 3),
                                    target="sky", property="flash", value=1.0, duration=0.6))
        elif kind == "door_open":
            dn = p.get("door_node") or "subject"
            P.append(chained("door_1", "door_open", t, target=dn, property="door", value=0.0, to=1.0, duration=1.0, easing="settle"))
    tod = p.get("tod", {})
    if tod.get("to") and tod["to"] != tod.get("from") and ctx.role in ("main",):
        P.append(tl.Planned("tod_blend", "time_transition", at=round(D * 0.1, 3), duration=round(D * 0.6, 3), target="sky",
                            property="time_blend", value=0.0, to=1.0, easing="ease_in_out"))
    elif tod.get("to") and ctx.role != "main":
        # continuity: صحنه‌هایِ بعدی در پایانِ انتقال شروع می‌شوند، نه ابتدای آن
        pass
    if p.get("window_light"):
        if tod.get("to") and tod.get("to") != tod.get("from") and tod["to"] in ("night", "dusk"):
            # شروعِ صریحاً خاموش؛ بدونِ این رویداد propAt پیش‌فرضِ «روشن» را برمی‌گرداند (باگِ کشف‌شده با probe).
            P.append(tl.Planned("win_off0", "light_off", at=0.0, target="window_light", property="intensity", value=0.0))
            P.append(tl.Planned("win_on", "light_on", at=round(D * 0.35, 3), duration=round(D * 0.15, 3), target="window_light",
                                property="intensity", value=0.0, to=1.0))
        else:
            P.append(tl.Planned("win_on", "light_on", at=0.0, target="window_light", property="intensity", value=1.0))
    m = p.get("motion")
    if m:
        P.append(tl.Planned("move_1", "motion", at=round(D * 0.12, 3), duration=round(D * 0.76, 3), target=m["node"],
                            property="pos_x", value=m["x0"], to=m["x1"], easing=m["profile"]["acceleration"]))
    if scene.camera.move or scene.camera.target:
        P.append(tl.Planned("cam_start", "camera_start", at=0.0, target="camera", property="move", value=scene.camera.move))
    for i, lb in enumerate(scene.labels):
        if lb.get("role") in ("label", "fact"):
            P.append(tl.Planned(f"lbl_{i}", "label_show", at=min(D, lb["start"]), duration=lb["duration"], target="label",
                                property="text", value=lb["text"]))
    scene.timeline = tl.resolve(P, D)
    scene.lighting.flash_times = [e.time for e in scene.timeline if e.event == "flash"]


def rebuild_audio(scene: SceneSpec, ctx: PlanCtx) -> None:
    scene.audio = audio_planner.plan_audio(scene, ctx.intent, allow_auto_music=ctx.allow_auto_music, mood=scene.mood)
    scene.labels = [lb for lb in scene.labels if lb.get("role") != "subtitle"]
    if scene.audio.narration:
        scene.labels += audio_planner.subtitle_labels(scene.audio.narration)
    g = load_graph(scene)
    for n in g.nodes.values():
        n.audio_sources = []
    by_src = {"rain": "weather", "footstep": (plan_of(scene).get("motion") or {}).get("node"),
              "door": plan_of(scene).get("door_node"), "thunder": "sky"}
    for e in scene.audio.events:
        nid = by_src.get(e["source"])
        if nid and g.get(nid) and e["id"] not in g.get(nid).audio_sources:
            g.get(nid).audio_sources.append(e["id"])
    save_graph(scene, g)


# ----------------------------------------------------------------------
#   نقطهٔ ورودِ اصلیِ planner
# ----------------------------------------------------------------------

def plan_scene(intent: VideoIntent, *, seed: int, quality: str = "medium", duration: float | None = None,
               role: str = "main", index: int = 0, n_scenes: int = 1, scene_id: str | None = None,
               allow_auto_music: bool = False, tod_override: tuple[str, str | None] | None = None) -> SceneSpec:
    ctx = PlanCtx(intent, seed, quality, role, index, n_scenes, allow_auto_music)
    env_name = default_environment(intent)
    d = envlib.env_def(env_name)
    tod_from = intent.time_of_day or d.default_tod
    tod_to = intent.time_transition[1] if intent.time_transition else None
    if tod_override:
        tod_from, tod_to = tod_override
    weather = intent.weather if intent.weather in ("rain", "snow", "fog") else "none"
    dur = float(duration if duration is not None else (intent.duration or 8.0))
    w, h = ASPECT_DIMS.get(intent.aspect_ratio or "16:9", ASPECT_DIMS["16:9"])
    long_side = RENDER_LONG_SIDE.get(quality, 960)
    k = long_side / max(w, h)
    scene = SceneSpec(scene_id=scene_id or new_scene_id(), duration=round(dur, 3), width=w, height=h, quality=quality,
                      mood=intent.mood or "calm", style=intent.style or ("educational" if intent.educational else
                                                                          "historical" if intent.historical else "cinematic"),
                      aspect_ratio=intent.aspect_ratio or "16:9", source_text=intent.raw_text, seed=seed,
                      environment=env_name, time_of_day=tod_from, weather=weather,
                      background_type="underwater_gradient" if env_name == "underwater" else "gradient",
                      render_scale={"w": int(w * k), "h": int(h * k)})
    p = plan_of(scene)
    carries = role in ("main", "event") or n_scenes == 1 or (n_scenes < 4 and index == n_scenes - 1)
    p.update({"role": role, "index": index, "n_scenes": n_scenes, "seed": seed, "quality": quality,
              "tod": {"from": tod_from, "to": tod_to}, "carries_events": carries})
    scene.graph["plan"] = p
    ensure_environment(scene, ctx)
    ensure_subject(scene, ctx)
    ensure_character(scene, ctx)
    ensure_weather(scene, ctx)
    ensure_storm(scene, ctx)
    ensure_door(scene, ctx)
    ensure_sky(scene, ctx)
    ensure_window_light(scene, ctx)
    ensure_lighting(scene, ctx)
    ensure_labels(scene, ctx)
    ensure_camera(scene, ctx)
    rebuild_relations(scene)
    rebuild_timeline(scene, ctx)
    rebuild_audio(scene, ctx)
    # سبک آخر از همه: روی نور/دوربین/حرکت/صدایِ *نهایی* اثر می‌گذارد
    style_system.apply_style(scene, scene.style)
    scene.style_profile = scene.style
    return scene


def ctx_from_scene(scene: SceneSpec, intent: VideoIntent) -> PlanCtx:
    p = plan_of(scene)
    return PlanCtx(intent, p.get("seed", scene.seed), scene.quality, p.get("role", "main"), p.get("index", 0),
                   p.get("n_scenes", 1))
