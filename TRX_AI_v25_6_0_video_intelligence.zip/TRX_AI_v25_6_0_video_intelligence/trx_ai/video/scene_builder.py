# -*- coding: utf-8 -*-
"""
Scene Specification Builder -- بخشِ ۵ و ۶ سندِ طراحی.

ورودی: دیکشنریِ خروجیِ ``request_normalizer.normalize_request``.
خروجی: یک ``SceneSpec`` کامل (اشیاء + دوربین + نور + تایم‌لاین) که به
``html_generator`` داده می‌شود.

این ماژول «صحنه را به اجزایِ قابلِ اجرا تبدیل می‌کند» (متنِ دقیقِ بخشِ ۵)
-- یعنی از رویِ نامِ محیط، مجموعه‌ای پیش‌فرض ولی معقول از اشیاء انتخاب
می‌کند. این پیش‌فرض‌ها قطعی و قابلِ توضیح‌اند (نه حدسِ مدل) که با محدودیتِ
«بدونِ وابستگیِ اجباری به API» پروژه سازگار است.
"""

from __future__ import annotations

import time
import uuid

from .scene_schema import SceneSpec, ObjectSpec, TimelineEvent
from . import motion_planner, camera_planner, lighting_planner

# محیط → اشیایِ پیش‌فرض (id, type, motion, layers, density)
_ENV_OBJECTS: dict[str, list[dict]] = {
    "underwater": [
        {"id": "subject", "type": "human_silhouette", "motion": "slow_float", "layers": ("hair", "clothes", "body")},
        {"id": "bubbles", "type": "particle_group", "motion": "rise", "density": "medium"},
    ],
    "rain_on_window": [
        {"id": "glass", "type": "surface_overlay", "motion": "static", "layers": ()},
        {"id": "raindrops", "type": "particle_group", "motion": "drift", "density": "medium"},
    ],
    "forest": [
        {"id": "trees", "type": "silhouette_layer", "motion": "sway", "layers": ()},
        {"id": "fog", "type": "particle_group", "motion": "drift", "density": "low"},
    ],
    "desert": [
        {"id": "dunes", "type": "silhouette_layer", "motion": "static", "layers": ()},
        {"id": "sand_particles", "type": "particle_group", "motion": "drift", "density": "low"},
    ],
    "city": [
        {"id": "skyline", "type": "silhouette_layer", "motion": "static", "layers": ()},
        {"id": "lights", "type": "particle_group", "motion": "pulse", "density": "medium"},
    ],
    "sky": [
        {"id": "clouds", "type": "silhouette_layer", "motion": "drift", "layers": ()},
    ],
    "night_sky": [
        {"id": "stars", "type": "particle_group", "motion": "pulse", "density": "high"},
    ],
    "room": [
        {"id": "ambient_dust", "type": "particle_group", "motion": "drift", "density": "low"},
    ],
    "lab": [
        {"id": "equipment_glow", "type": "particle_group", "motion": "pulse", "density": "low"},
    ],
    "ancient_persia": [
        {"id": "columns", "type": "silhouette_layer", "motion": "static", "layers": ()},
        {"id": "dust_light", "type": "particle_group", "motion": "drift", "density": "low"},
    ],
}

_ENV_BACKGROUND: dict[str, str] = {
    "underwater": "underwater_gradient",
    "night_sky": "night_sky",
    "rain_on_window": "gradient",
}


def _new_scene_id() -> str:
    return f"scene_{int(time.time())}_{uuid.uuid4().hex[:6]}"


def _build_timeline(duration: float) -> list[TimelineEvent]:
    """منطقِ تایم‌لاینِ بخشِ ۱۱: fade_in ابتدایی، اجرایِ اصلی در میانه،
    fade_out نرم در انتها -- نسبت‌ها از رویِ نمونه‌ی سندِ طراحی (۲/۸ و ۶/۸)
    به هر مدتی تعمیم داده شده‌اند.
    """
    fade_in_end = round(min(2.0, duration * 0.25), 2)
    fade_out_start = round(max(fade_in_end + 0.5, duration - duration * 0.25), 2)
    return [
        TimelineEvent(time=0.0, event="fade_in"),
        TimelineEvent(time=fade_in_end, event="main_action_start"),
        TimelineEvent(time=fade_out_start, event="fade_out_start"),
        TimelineEvent(time=duration, event="end"),
    ]


def build_scene(normalized_request: dict, *, quality: str = "medium",
                 scene_id: str | None = None) -> SceneSpec:
    environment = normalized_request.get("environment", "room")
    mood = normalized_request.get("mood", "calm")
    duration = float(normalized_request.get("duration", 6.0))
    camera_hint = normalized_request.get("camera", "slow_push_in")

    obj_defs = _ENV_OBJECTS.get(environment, _ENV_OBJECTS["room"])
    objects: list[ObjectSpec] = []
    for od in obj_defs:
        spec = ObjectSpec(
            id=od["id"], type=od["type"], motion=od.get("motion", "static"),
            layers=tuple(od.get("layers", ())),
        )
        if spec.type == "particle_group":
            spec.density = lighting_planner.particle_density_for(environment, quality)
        else:
            spec.density = od.get("density", "medium")
        objects.append(spec)

    motion_planner.plan_all(objects, mood=mood)
    camera = camera_planner.plan_camera(camera_hint, mood=mood)
    lighting = lighting_planner.plan_lighting(environment, mood=mood)

    scene = SceneSpec(
        scene_id=scene_id or _new_scene_id(),
        duration=duration,
        background_type=_ENV_BACKGROUND.get(environment, "gradient"),
        color_mood=lighting.color_mood,
        quality=quality,
        objects=objects,
        camera=camera,
        lighting=lighting,
        timeline=_build_timeline(duration),
        mood=mood,
        style=normalized_request.get("style", "cinematic"),
        aspect_ratio=normalized_request.get("aspect_ratio", "16:9"),
        source_text=normalized_request.get("raw_text", ""),
    )
    return scene
