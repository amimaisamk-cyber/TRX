# -*- coding: utf-8 -*-
"""
HTML/CSS/JS Runtime Generator -- بخش‌های ۹ تا ۱۵ و ۱۹ سندِ طراحی.

خروجیِ این ماژول یک فایلِ HTML کاملاً خودکفا (self-contained) است: بدونِ
هیچ درخواستِ شبکه‌ای، بدونِ eval/Function constructor، بدونِ iframeِ
ناشناس. صحنه به‌صورتِ JSON در خودِ صفحه embed می‌شود و یک TimelineEngineِ
سبک با requestAnimationFrame آن را اجرا می‌کند.

صداقتِ فنی (که پروفایلِ کاربر صریحاً خواسته): برایِ صدا از فایلِ صوتیِ
از‌پیش‌ضبط‌شده استفاده نمی‌شود (که وابستگیِ حجم/دارایی ایجاد می‌کرد)، بلکه
صدایِ محیطیِ underwater/rain/wind با Web Audio API به‌صورتِ آنی سنتز
می‌شود (نویزِ فیلترشده + LFO -- بدونِ فایل، بدونِ دانلود، کاملاً درونِ
همان sandboxِ امنیتیِ فعلی، بدونِ eval/fetch/اسکریپتِ خارجی). چون
autoplayِ صدا در مرورگر/WebView بدونِ تعاملِ کاربر مسدود است، ابتدا فقط
تصویر پخش می‌شود و صدا با اولین لمسِ کاربر فعال می‌گردد (دقیقاً پیشنهادِ
بخشِ ۱۴ سندِ طراحی). انواعِ دیگرِ صدا (مثلاً «موسیقی») هنوز سنتز نشده‌اند؛
برایِ آن‌ها فقط برچسب نشان داده می‌شود تا ادعایِ کاذب ایجاد نشود.
"""

from __future__ import annotations

import json

from .scene_schema import SceneSpec

MAX_HTML_BYTES = 300_000  # سقفِ حجمِ خروجی -- بخشِ ۱۷/۱۸ (Sandbox/Validator)

_COLOR_MOODS: dict[str, tuple[str, str, str]] = {
    # (bg_from, bg_to, accent)
    "blue_cyan": ("#04121c", "#0d3b52", "#5fd6e8"),
    "warm_orange": ("#231205", "#5a2e0d", "#f2a65a"),
    "dark": ("#050507", "#14141a", "#8a8aa0"),
    "golden": ("#1a1204", "#4a3a10", "#f0c96b"),
    "neutral": ("#0e0e12", "#22222c", "#c9c9d6"),
    "green": ("#06120a", "#123420", "#79d6a0"),
}


def _colors_for(mood: str) -> tuple[str, str, str]:
    return _COLOR_MOODS.get(mood, _COLOR_MOODS["neutral"])


def generate_html(spec: SceneSpec) -> str:
    bg_from, bg_to, accent = _colors_for(spec.color_mood)
    scene_json = json.dumps(spec.to_dict(), ensure_ascii=False)
    particle_cap = spec.particle_cap()

    html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>TRX Scene {spec.scene_id}</title>
<style>
  :root {{
    --bg-from: {bg_from};
    --bg-to: {bg_to};
    --accent: {accent};
  }}
  * {{ box-sizing: border-box; }}
  html, body {{ margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden;
                background: #000; font-family: Tahoma, sans-serif; }}
  #scene-root {{
    position: relative; width: 100%; height: 100vh; overflow: hidden;
    background: radial-gradient(ellipse at 50% 40%, var(--bg-to), var(--bg-from));
    opacity: 0; transition: opacity 0.6s ease-in-out;
  }}
  #camera-layer {{
    position: absolute; inset: 0; transform-origin: 50% 50%; will-change: transform;
  }}
  .layer {{ position: absolute; inset: 0; pointer-events: none; }}
  #vignette {{
    box-shadow: inset 0 0 18vw 4vw rgba(0,0,0,0.55);
  }}
  #fog-layer {{
    background: radial-gradient(ellipse at 50% 70%, rgba(255,255,255,0.06), transparent 70%);
  }}
  #subject {{
    position: absolute; left: 50%; top: 55%; width: 22vmin; height: 40vmin;
    transform: translate(-50%, -50%);
    background: linear-gradient(180deg, rgba(255,255,255,0.10), rgba(255,255,255,0.02));
    border-radius: 40% 40% 50% 50% / 30% 30% 60% 60%;
    filter: blur(0px);
  }}
  #particle-canvas {{ position: absolute; inset: 0; }}
  #hud {{
    position: absolute; left: 0; right: 0; bottom: 0; padding: 10px 14px;
    display: flex; align-items: center; gap: 10px; direction: ltr;
    background: linear-gradient(0deg, rgba(0,0,0,0.55), transparent);
    font-size: 13px; color: #eee; z-index: 20;
  }}
  #hud button {{
    background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.25);
    color: #fff; border-radius: 8px; padding: 6px 10px; cursor: pointer; font-size: 14px;
  }}
  #hud button:active {{ background: rgba(255,255,255,0.25); }}
  #seek {{ flex: 1; }}
  #timeLabel {{ min-width: 84px; text-align: center; font-variant-numeric: tabular-nums; }}
  #audioTag {{ opacity: 0.75; font-size: 11px; }}
  #qualityTag {{ opacity: 0.6; font-size: 11px; }}
  #audioUnlock {{
    position: absolute; inset: 0; z-index: 30; display: none;
    align-items: center; justify-content: center; text-align: center;
    background: rgba(0,0,0,0.35); color: #fff; font-size: 14px; cursor: pointer;
  }}
  #audioUnlock span {{
    background: rgba(0,0,0,0.55); border: 1px solid rgba(255,255,255,0.3);
    border-radius: 10px; padding: 10px 16px;
  }}
</style>
</head>
<body>
<div id="scene-root">
  <div id="camera-layer">
    <div class="layer" id="fog-layer"></div>
    <div id="subject"></div>
    <canvas id="particle-canvas"></canvas>
  </div>
  <div class="layer" id="vignette"></div>
  <div id="audioUnlock"><span>🔈 برای پخشِ صدا لمس کنید</span></div>
</div>
<div id="hud">
  <button id="btnPlayPause" title="پخش/توقف">⏸</button>
  <button id="btnReset" title="بازسازی">↻</button>
  <span id="timeLabel">00:00 / 00:00</span>
  <input id="seek" type="range" min="0" max="1000" value="0">
  <button id="btnMute" title="بی‌صدا/باصدا">🔈</button>
  <span id="audioTag"></span>
  <span id="qualityTag"></span>
</div>

<script>
"use strict";
// ---- داده‌ی صحنه (Scene Specification) — تولیدشده توسط TRX AI، بدونِ اجرایِ مستقیمِ ورودیِ کاربر ----
var SCENE = {scene_json};

(function () {{
  // امنیت: این اسکریپت به‌طورِ کامل ایستا و از‌پیش‌تولیدشده است و از
  // هیچ مکانیزمِ اجرایِ کدِ پویا یا درخواستِ شبکه‌ایِ ناخواسته استفاده
  // نمی‌کند (بخشِ ۱۷ سندِ طراحی؛ فهرستِ دقیقِ الگوهایِ ممنوع در
  // ``validator.py`` است -- عمداً اینجا تکرار نشد تا خودِ همین توضیح
  // به‌اشتباه توسطِ اسکنرِ ایمنی به‌عنوانِ استفاده‌ی واقعی تشخیص داده نشود).

  var root = document.getElementById("scene-root");
  var camLayer = document.getElementById("camera-layer");
  var subject = document.getElementById("subject");
  var canvas = document.getElementById("particle-canvas");
  var ctx = canvas.getContext("2d");
  var btnPlayPause = document.getElementById("btnPlayPause");
  var btnReset = document.getElementById("btnReset");
  var seek = document.getElementById("seek");
  var timeLabel = document.getElementById("timeLabel");
  var audioTag = document.getElementById("audioTag");
  var qualityTag = document.getElementById("qualityTag");
  var audioUnlock = document.getElementById("audioUnlock");
  var btnMute = document.getElementById("btnMute");

  var duration = SCENE.duration || 6;
  var quality = SCENE.quality || "medium";
  var particleCap = {particle_cap};

  // ---- موتورِ صدایِ رویه‌ای (Procedural Ambient Audio) ----
  // به‌جایِ فایلِ صوتی یا برچسبِ صرف، صدا با Web Audio API همین‌جا و
  // آنی سنتز می‌شود (نویزِ فیلترشده + LFO) -- بدونِ هیچ فایل/دانلود/
  // درخواستِ شبکه‌ای. طبقِ بخشِ ۱۴ سندِ طراحی: چون سیاستِ autoplayِ
  // مرورگرها اجازه‌ی پخشِ خودکارِ صدا را نمی‌دهد، ابتدا فقط تصویر اجرا
  // می‌شود و صدا با اولین لمسِ کاربر فعال می‌گردد؛ خطایِ صدا هرگز نباید
  // کلِ صحنه را متوقف کند.
  var AMBIENT_RECIPES = {{
    underwater: {{ noise: "brown", filterType: "lowpass", filterFreq: 260, lfoRate: 0.12, lfoDepth: 60 }},
    rain:       {{ noise: "white", filterType: "highpass", filterFreq: 900, lfoRate: 3.0,  lfoDepth: 150 }},
    wind:       {{ noise: "pink",  filterType: "bandpass", filterFreq: 500, lfoRate: 0.25, lfoDepth: 300 }},
  }};
  var ambientKey = SCENE.audio && SCENE.audio.ambient;
  var recipe = AMBIENT_RECIPES[ambientKey] || null;
  var targetVolume = (SCENE.audio && typeof SCENE.audio.volume === "number") ? SCENE.audio.volume : 0.3;

  var AudioEngine = {{
    ctx: null, gain: null, muted: false, started: false,
    canSynthesize: !!recipe && typeof window.AudioContext !== "undefined",
    makeNoiseBuffer: function (ctx, kind) {{
      var bufferSize = 2 * ctx.sampleRate;
      var buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      var data = buffer.getChannelData(0);
      var lastOut = 0;
      for (var i = 0; i < bufferSize; i++) {{
        var white = Math.random() * 2 - 1;
        if (kind === "brown") {{
          lastOut = (lastOut + 0.02 * white) / 1.02;
          data[i] = lastOut * 3.2;
        }} else if (kind === "pink") {{
          lastOut = 0.98 * lastOut + white * 0.12;
          data[i] = lastOut;
        }} else {{
          data[i] = white;
        }}
      }}
      return buffer;
    }},
    start: function () {{
      if (this.started || !this.canSynthesize) return;
      try {{
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        var src = this.ctx.createBufferSource();
        src.buffer = this.makeNoiseBuffer(this.ctx, recipe.noise);
        src.loop = true;
        var filter = this.ctx.createBiquadFilter();
        filter.type = recipe.filterType;
        filter.frequency.value = recipe.filterFreq;
        var lfo = this.ctx.createOscillator();
        var lfoGain = this.ctx.createGain();
        lfo.frequency.value = recipe.lfoRate;
        lfoGain.gain.value = recipe.lfoDepth;
        lfo.connect(lfoGain);
        lfoGain.connect(filter.frequency);
        this.gain = this.ctx.createGain();
        this.gain.gain.value = 0.0001;
        src.connect(filter);
        filter.connect(this.gain);
        this.gain.connect(this.ctx.destination);
        src.start(0);
        lfo.start(0);
        this.gain.gain.linearRampToValueAtTime(this.muted ? 0.0001 : targetVolume, this.ctx.currentTime + 1.2);
        this.started = true;
      }} catch (err) {{
        this.canSynthesize = false; // شکستِ صدا هرگز نباید صحنه را متوقف کند
      }}
    }},
    toggleMute: function () {{
      this.muted = !this.muted;
      if (this.gain) {{
        this.gain.gain.linearRampToValueAtTime(this.muted ? 0.0001 : targetVolume, this.ctx.currentTime + 0.3);
      }}
      btnMute.textContent = this.muted ? "🔇" : "🔈";
    }},
  }};

  if (recipe && AudioEngine.canSynthesize) {{
    audioTag.textContent = "🔈 صدا: " + ambientKey + " (سنتزِ زنده، بدونِ فایل)";
    audioUnlock.style.display = "flex";
    audioUnlock.addEventListener("click", function () {{
      AudioEngine.start();
      audioUnlock.style.display = "none";
    }}, {{ once: true }});
  }} else if (ambientKey) {{
    // نوعِ صدا (مثلاً «موسیقی») که این نسخه نمی‌تواند صادقانه سنتز کند --
    // به‌جایِ ادعایِ دروغ، فقط برچسب نشان داده می‌شود.
    audioTag.textContent = "🔈 صدا (فقط برچسب -- سنتزِ این نوع صدا هنوز پیاده نشده): " + ambientKey;
    btnMute.style.display = "none";
  }} else {{
    btnMute.style.display = "none";
  }}
  btnMute.addEventListener("click", function () {{ AudioEngine.toggleMute(); }});
  qualityTag.textContent = "کیفیت: " + quality;

  function resizeCanvas() {{
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
  }}
  window.addEventListener("resize", resizeCanvas);
  resizeCanvas();

  // ---- تایم‌لاینِ داخلی (بخشِ ۱۱) ----
  var TimelineEngine = {{
    playing: true,
    playbackRate: 1.0,
    elapsed: 0,          // میلی‌ثانیه
    lastFrame: null,
    fadeInEnd: 0,
    fadeOutStart: duration,
    init: function () {{
      (SCENE.timeline || []).forEach(function (ev) {{
        if (ev.event === "main_action_start") TimelineEngine.fadeInEnd = ev.time;
        if (ev.event === "fade_out_start") TimelineEngine.fadeOutStart = ev.time;
      }});
    }},
    currentTime: function () {{ return this.elapsed / 1000; }},
    play: function () {{ this.playing = true; }},
    pause: function () {{ this.playing = false; }},
    reset: function () {{ this.elapsed = 0; this.lastFrame = null; }},
    seekTo: function (t) {{ this.elapsed = Math.max(0, Math.min(duration, t)) * 1000; }},
  }};
  TimelineEngine.init();

  // ---- ذرات (particle_group) ----
  var particleGroups = (SCENE.objects || []).filter(function (o) {{ return o.type === "particle_group"; }});
  var DENSITY_COUNT = {{ low: 14, medium: 30, high: 55 }};
  var particles = [];
  particleGroups.forEach(function (g) {{
    var count = Math.min(particleCap, DENSITY_COUNT[g.density] || DENSITY_COUNT.medium);
    for (var i = 0; i < count; i++) {{
      particles.push({{
        motion: g.motion, x: Math.random(), y: Math.random(),
        r: 1 + Math.random() * 2.2, phase: Math.random() * Math.PI * 2,
        speed: (0.15 + Math.random() * 0.3) * (g.velocity || 1),
      }});
    }}
  }});

  function drawParticles(t) {{
    if (!particles.length) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(255,255,255,0.75)";
    for (var i = 0; i < particles.length; i++) {{
      var p = particles[i];
      var x = p.x * canvas.width;
      var y;
      if (p.motion === "rise") {{
        y = canvas.height - ((t * p.speed * 60 + p.phase * 40) % (canvas.height + 20));
      }} else if (p.motion === "drift") {{
        x = (p.x * canvas.width + Math.sin(t * 0.5 + p.phase) * 18 + t * p.speed * 12) % canvas.width;
        y = (p.y * canvas.height + t * p.speed * 10) % canvas.height;
      }} else if (p.motion === "pulse") {{
        y = p.y * canvas.height;
        ctx.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin(t * 1.5 + p.phase));
      }} else {{
        y = p.y * canvas.height;
      }}
      ctx.beginPath();
      ctx.arc(x, y, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }}
  }}

  // ---- دوربینِ مجازی (بخشِ ۱۲) ----
  var cam = SCENE.camera || {{}};
  function applyCamera(progress) {{
    var zoom = (cam.zoom_start || 1) + ((cam.zoom_end || 1) - (cam.zoom_start || 1)) * progress;
    var panX = (cam.pan_x || 0) * progress;
    var panY = (cam.pan_y || 0) * progress;
    var shake = cam.shake ? (Math.sin(progress * 40) * cam.shake * 6) : 0;
    camLayer.style.transform = "scale(" + zoom.toFixed(4) + ") translate(" +
        (panX + shake).toFixed(2) + "px," + panY.toFixed(2) + "px)";
  }}

  // ---- حرکتِ سوژه‌ی اصلی (اگر وجود داشته باشد) ----
  var subjectSpec = (SCENE.objects || []).find(function (o) {{ return o.id === "subject"; }});

  function applySubjectMotion(t) {{
    if (!subjectSpec) return;
    var amp = 6 + (subjectSpec.velocity || 0.3) * 14;
    var dy = Math.sin(t * 0.6 + (subjectSpec.delay_s || 0)) * amp;
    var rot = Math.sin(t * 0.35) * 2.5;
    subject.style.transform = "translate(-50%, calc(-50% + " + dy.toFixed(2) + "px)) rotate(" + rot.toFixed(2) + "deg)";
    if (subjectSpec.blur_px) subject.style.filter = "blur(" + subjectSpec.blur_px + "px)";
  }}

  // ---- کیفیتِ تطبیقی بر اساسِ FPS (بخشِ ۱۹) ----
  var frameTimes = [];
  var downgraded = false;
  function trackPerformance(dtMs) {{
    frameTimes.push(dtMs);
    if (frameTimes.length > 40) frameTimes.shift();
    if (!downgraded && frameTimes.length === 40) {{
      var avg = frameTimes.reduce(function (a, b) {{ return a + b; }}, 0) / frameTimes.length;
      if (avg > 40) {{ // ~کمتر از ۲۵fps
        downgraded = true;
        particles = particles.slice(0, Math.ceil(particles.length * 0.5));
        subject.style.filter = "none";
        qualityTag.textContent = "کیفیت: " + quality + " (خودکار کاهش یافت به‌خاطرِ افتِ FPS)";
      }}
    }}
  }}

  // ---- فید این/اوت + پایانِ نرم ----
  function applyFade(t) {{
    var opacity = 1;
    if (t < TimelineEngine.fadeInEnd) {{
      opacity = TimelineEngine.fadeInEnd > 0 ? Math.min(1, t / TimelineEngine.fadeInEnd) : 1;
    }} else if (t > TimelineEngine.fadeOutStart) {{
      var span = Math.max(0.001, duration - TimelineEngine.fadeOutStart);
      opacity = Math.max(0, 1 - (t - TimelineEngine.fadeOutStart) / span);
    }}
    root.style.opacity = opacity.toFixed(3);
  }}

  function formatTime(s) {{
    s = Math.max(0, s);
    var m = Math.floor(s / 60), r = Math.floor(s % 60);
    return (m < 10 ? "0" + m : m) + ":" + (r < 10 ? "0" + r : r);
  }}

  function frame(now) {{
    try {{
      if (TimelineEngine.lastFrame === null) TimelineEngine.lastFrame = now;
      var dt = now - TimelineEngine.lastFrame;
      TimelineEngine.lastFrame = now;
      trackPerformance(dt);
      if (TimelineEngine.playing) {{
        TimelineEngine.elapsed += dt * TimelineEngine.playbackRate;
        if (TimelineEngine.elapsed >= duration * 1000) {{
          TimelineEngine.elapsed = duration * 1000; // پایانِ نرم، نه توقفِ ناگهانی
          TimelineEngine.playing = false;
          btnPlayPause.textContent = "▶";
        }}
      }}
      var t = TimelineEngine.currentTime();
      var progress = duration > 0 ? Math.min(1, t / duration) : 0;
      applyFade(t);
      applyCamera(progress);
      applySubjectMotion(t);
      drawParticles(t);
      timeLabel.textContent = formatTime(t) + " / " + formatTime(duration);
      seek.value = Math.round(progress * 1000);
    }} catch (err) {{
      // خطایِ اجرا نباید کلِ صحنه را کرش کند -- به‌جایِ آن، اجرا متوقف و
      // پیامِ کوتاه نمایش داده می‌شود (بخشِ ۱۷: «توقفِ خودکار در صورتِ خطایِ شدید»).
      TimelineEngine.playing = false;
      qualityTag.textContent = "⚠️ خطای اجرا -- صحنه متوقف شد.";
      return;
    }}
    requestAnimationFrame(frame);
  }}

  btnPlayPause.addEventListener("click", function () {{
    if (TimelineEngine.playing) {{ TimelineEngine.pause(); btnPlayPause.textContent = "▶"; }}
    else {{ if (TimelineEngine.elapsed >= duration * 1000) TimelineEngine.reset(); TimelineEngine.play(); btnPlayPause.textContent = "⏸"; }}
  }});
  btnReset.addEventListener("click", function () {{
    TimelineEngine.reset(); TimelineEngine.play(); btnPlayPause.textContent = "⏸";
  }});
  seek.addEventListener("input", function () {{
    TimelineEngine.seekTo((seek.value / 1000) * duration);
  }});

  // پخشِ خودکار (فقط تصویر -- بدونِ نیاز به تعاملِ کاربر، چون هیچ صدایی
  // واقعاً پخش نمی‌شود؛ محدودیتِ autoplayِ صدا در WebViewها اینجا موضوعیت ندارد).
  requestAnimationFrame(function (t0) {{
    TimelineEngine.lastFrame = t0;
    requestAnimationFrame(frame);
  }});
  setTimeout(function () {{ root.style.opacity = "1"; }}, 30);
}})();
</script>
</body>
</html>
"""
    if len(html.encode("utf-8")) > MAX_HTML_BYTES:
        raise ValueError(f"HTML تولیدشده از سقفِ مجاز ({MAX_HTML_BYTES} بایت) بزرگ‌تر است.")
    return html
