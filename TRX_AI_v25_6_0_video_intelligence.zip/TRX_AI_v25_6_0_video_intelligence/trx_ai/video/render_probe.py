# -*- coding: utf-8 -*-
"""
Render Probe (بخشِ ۲۰ و ۲۱ سندِ ارتقا): اجرایِ *واقعیِ* JSِ صفحه با Canvas/WebAudio ساختگی (Node).

محدودیتِ صادقانه: این ابزارِ dev/CI است؛ در Pydroid/Android معمولاً Node نیست و
``available()`` False برمی‌گرداند -- در آن حالت لایهٔ اعتبارسنجیِ ایستا (semantic_validator)
تنها بررسی است و ادعایِ «رندرِ بازرسی‌شده» ثبت نمی‌شود. این probe پیکسلِ واقعی نمی‌سنجد؛
شمارشِ فراخوانی‌هایِ drawer و صداهایِ فعال‌شده را می‌سنجد.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from typing import Any

_JS = os.path.join(os.path.dirname(__file__), "tools", "render_probe.js")


def available() -> bool:
    return shutil.which("node") is not None and os.path.exists(_JS)


def probe(html: str, times: list[float], audio_times: list[float] | None = None, timeout: float = 30.0) -> dict[str, Any] | None:
    if not available():
        return None
    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf-8") as f:
        f.write(html)
        path = f.name
    try:
        r = subprocess.run(["node", _JS, path, json.dumps(times), json.dumps(audio_times or [])],
                           capture_output=True, text=True, timeout=timeout)
        return json.loads(r.stdout.strip().splitlines()[-1]) if r.stdout.strip() else {"errors": [r.stderr[:400]]}
    except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as exc:
        return {"errors": [str(exc)]}
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
