# -*- coding: utf-8 -*-
"""Lighting Planner -- بخشِ ۱۳ (نور) و بخشِ ۱۹ (کیفیتِ تطبیقی) سندِ طراحی."""

from __future__ import annotations

from .scene_schema import LightingSpec

_ENV_LIGHTING: dict[str, dict[str, str]] = {
    "underwater": {"type": "caustic_water_light", "color_mood": "blue_cyan", "movement": "slow_wave"},
    "rain_on_window": {"type": "soft_ambient", "color_mood": "dark", "movement": "static"},
    "forest": {"type": "soft_ambient", "color_mood": "green", "movement": "flicker"},
    "desert": {"type": "warm_glow", "color_mood": "warm_orange", "movement": "static"},
    "city": {"type": "neon", "color_mood": "neutral", "movement": "flicker"},
    "sky": {"type": "soft_ambient", "color_mood": "golden", "movement": "slow_wave"},
    "night_sky": {"type": "cold_moon", "color_mood": "dark", "movement": "static"},
    "room": {"type": "soft_ambient", "color_mood": "neutral", "movement": "static"},
    "lab": {"type": "harsh", "color_mood": "neutral", "movement": "static"},
    "ancient_persia": {"type": "warm_glow", "color_mood": "golden", "movement": "static"},
}

_MOOD_INTENSITY = {
    "calm": 0.4, "mysterious": 0.35, "epic": 0.65, "scientific": 0.5,
    "dreamy": 0.45, "dark": 0.3, "joyful": 0.7, "cinematic": 0.5,
}


def plan_lighting(environment: str, mood: str = "calm") -> LightingSpec:
    preset = _ENV_LIGHTING.get(environment, _ENV_LIGHTING["room"])
    return LightingSpec(
        type=preset["type"],
        color_mood=preset["color_mood"],
        intensity=_MOOD_INTENSITY.get(mood, 0.5),
        movement=preset["movement"],
        fog=environment in ("forest", "underwater"),
        vignette=True,
    )


def apply_edit(light: LightingSpec, *, dimmer: bool = False, brighter: bool = False,
                darker_mood: bool = False) -> LightingSpec:
    """اصلاحِ موضعیِ نور (بخشِ ۲۱)."""
    if dimmer:
        light.intensity = round(max(0.05, light.intensity - 0.15), 3)
    if brighter:
        light.intensity = round(min(1.0, light.intensity + 0.15), 3)
    if darker_mood:
        light.color_mood = "dark"
        light.intensity = round(max(0.1, light.intensity - 0.1), 3)
    return light


def particle_density_for(environment: str, quality: str) -> str:
    if environment in ("underwater", "rain_on_window", "sky", "forest"):
        base = "medium"
    else:
        base = "low"
    if quality == "high":
        return "high" if base != "low" else "medium"
    if quality == "low":
        return "low"
    return base
