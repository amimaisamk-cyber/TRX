// Render probe (dev/CI tool): اجرایِ واقعیِ JSِ صفحه در Node با Canvas/WebAudio ساختگی.
// خروجی JSON: آمارِ آنچه واقعاً کشیده/پخش شد. هیچ وابستگیِ npm ندارد.
const fs = require("fs"), vm = require("vm");
const html = fs.readFileSync(process.argv[2], "utf8");
const times = JSON.parse(process.argv[3] || "[0]");
const audioTimes = JSON.parse(process.argv[4] || "[]");
const m = html.match(/<script>([\s\S]*)<\/script>/);
if (!m) { console.log(JSON.stringify({error: "no script"})); process.exit(0); }
const calls = {};
function ctxProxy() {
  const grad = { addColorStop() {} };
  const base = { measureText: (t) => ({ width: String(t).length * 8 }), createLinearGradient: () => grad,
                 createRadialGradient: () => grad, setLineDash() {}, canvas: {} };
  return new Proxy(base, {
    get(t, k) { if (k in t) return t[k]; if (typeof k === "symbol") return undefined;
      return (...a) => { calls[k] = (calls[k] || 0) + 1; }; },
    set(t, k, v) { t[k] = v; return true; } });
}
const els = {};
function el(id) {
  return els[id] || (els[id] = { id, style: {}, textContent: "", value: 0, addEventListener() {},
    getContext: () => ctxProxy(), width: 0, height: 0 });
}
const created = { sources: 0, oscillators: 0, shots: [], voices: 0 };
function node() { return new Proxy({}, { get(t, k) { if (k in t) return t[k];
  if (k === "gain" || k === "frequency" || k === "detune") return { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, setTargetAtTime() {} };
  return (...a) => {}; }, set(t, k, v) { t[k] = v; return true; } }); }
class FakeAC { constructor() { this.sampleRate = 8000; this.currentTime = 0; this.destination = node(); }
  createBuffer(c, n) { return { getChannelData: () => new Float32Array(n) }; }
  createBufferSource() { created.sources++; return node(); }
  createOscillator() { created.oscillators++; return node(); }
  createGain() { return node(); } createBiquadFilter() { return node(); } suspend() {} resume() {} }
const sandbox = { document: { getElementById: el }, console, Math, JSON, Date, Float32Array, Object, Array, String, Number, isNaN,
  requestAnimationFrame: () => 1, setTimeout: () => 1, AudioContext: FakeAC, SpeechSynthesisUtterance: undefined };
sandbox.window = sandbox; sandbox.window.speechSynthesis = undefined;
vm.createContext(sandbox);
const out = { frames: [], errors: [] };
try {
  vm.runInContext(m[1], sandbox, { timeout: 15000 });
  const T = sandbox.__TRX;
  for (const t of times) {
    for (const k of Object.keys(calls)) delete calls[k];
    const stats = T.render(t);
    out.frames.push({ t, stats, ops: Object.assign({}, calls) });
  }
  if (audioTimes.length) {
    T.audioStart();
    const fired = [];
    for (const t of audioTimes) { T.audioTick(t); }
    out.audio = { on: T.aud.on, fired: Object.keys(T.fired()), voices: Object.keys(T.aud.voices), created };
  }
  out.runtime_error = sandbox.__TRX_ERROR || null;
} catch (e) { out.errors.push(String(e && e.stack || e)); }
console.log(JSON.stringify(out));
