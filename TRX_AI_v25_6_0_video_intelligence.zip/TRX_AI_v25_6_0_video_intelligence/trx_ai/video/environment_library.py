# -*- coding: utf-8 -*-
"""
Environment Library (بخشِ ۷ سندِ ارتقا): محیط = *پارامتر + مولدِ قطعی*، نه preset ثابت.

``build_environment(name, seed, quality)`` فهرستِ decor را با RNG بذردار می‌سازد:
ده درخت با یک seed هرگز کپیِ هم نیستند، و همان seed همیشه همان نتیجه را می‌دهد
(بخشِ ۳۰ determinism). رندرِ واقعی در ``renderers/html_canvas.py`` است؛ اینجا فقط داده.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any

# ضریبِ تعدادِ decor بر اساسِ کیفیت (degradation = کمتر کردنِ جزئیاتِ فرعی).
DECOR_MUL = {"low": 0.45, "medium": 0.8, "high": 1.0}


@dataclass(frozen=True)
class EnvDef:
    name: str
    horizon: float                       # 0..1 ارتفاعِ افق از بالا
    ground: str                          # grass | sand | stone | water | floor | none | street | snow
    default_tod: str = "day"
    default_subject: str | None = None
    default_ambience: str | None = None
    fog: bool = False
    stars_at_night: bool = True
    educational: bool = False
    historical: bool = False
    has_sky: bool = True
    tags: tuple[str, ...] = ()


ENV_DEFS: dict[str, EnvDef] = {
    "forest": EnvDef("forest", 0.60, "grass", default_ambience="forest", fog=True, tags=("nature",)),
    "city": EnvDef("city", 0.66, "street", default_ambience="city", tags=("urban",)),
    "futuristic_city": EnvDef("futuristic_city", 0.68, "street", default_tod="night", default_ambience="city", tags=("urban", "neon")),
    "desert": EnvDef("desert", 0.62, "sand", default_ambience="wind", tags=("nature",)),
    "mountain": EnvDef("mountain", 0.66, "snow", default_ambience="wind", tags=("nature",)),
    "underwater": EnvDef("underwater", 0.0, "water", has_sky=False, default_ambience="underwater", fog=True, tags=("water",)),
    "room": EnvDef("room", 0.62, "floor", has_sky=False, tags=("indoor",)),
    "rain_on_window": EnvDef("rain_on_window", 0.62, "floor", has_sky=False, default_tod="night", tags=("indoor",)),
    "laboratory": EnvDef("laboratory", 0.64, "floor", has_sky=False, tags=("indoor", "science")),
    "village": EnvDef("village", 0.64, "grass", default_subject="house", tags=("nature", "rural")),
    "street": EnvDef("street", 0.66, "street", default_ambience="city", tags=("urban",)),
    "space": EnvDef("space", 0.0, "none", default_tod="night", has_sky=False, tags=("space",)),
    "ancient_persia": EnvDef("ancient_persia", 0.64, "stone", default_tod="sunset", historical=True, tags=("historical",)),
    "water_cycle": EnvDef("water_cycle", 0.60, "water", educational=True, tags=("science", "educational")),
    "sky": EnvDef("sky", 0.80, "none", tags=("nature",)),
    "night_sky": EnvDef("night_sky", 0.80, "none", default_tod="night", tags=("nature",)),
}
SUPPORTED_ENVIRONMENTS = tuple(ENV_DEFS)


def env_def(name: str | None) -> EnvDef:
    return ENV_DEFS.get(name or "", ENV_DEFS["forest"])


def _n(rng: random.Random, lo: int, hi: int, mul: float) -> int:
    return max(1 if hi > 0 else 0, int(round(rng.randint(lo, hi) * mul)))


def _ridge(rng: random.Random, base: float, amp: float, pts: int = 14, snow: bool = False) -> dict[str, Any]:
    ys, v = [], rng.random()
    for _ in range(pts):
        v = max(0.0, min(1.0, v + rng.uniform(-0.35, 0.35)))
        ys.append(round(v * amp, 4))
    return {"k": "ridge", "y": base, "pts": ys, "snow": snow, "tone": round(rng.uniform(0.0, 1.0), 3)}


def build_environment(name: str, seed: int = 0, quality: str = "medium") -> dict[str, Any]:
    d = env_def(name)
    rng = random.Random(f"env:{d.name}:{seed}")
    mul = DECOR_MUL.get(quality, 0.8)
    decor: list[dict[str, Any]] = []

    def add(layer: str, **kw):
        decor.append({"layer": layer, **kw})

    if d.name in ("forest", "village"):
        add("far", **_ridge(rng, d.horizon, 0.16))
        for _ in range(_n(rng, 9, 13, mul)):
            add("far", k="tree", x=round(rng.random(), 3), y=d.horizon + 0.01, h=round(rng.uniform(0.10, 0.16), 3),
                w=round(rng.uniform(0.04, 0.07), 3), tone=round(rng.random(), 3), lean=round(rng.uniform(-0.05, 0.05), 3))
        for _ in range(_n(rng, 5, 8, mul)):
            add("mid", k="tree", x=round(rng.random(), 3), y=d.horizon + 0.08, h=round(rng.uniform(0.18, 0.30), 3),
                w=round(rng.uniform(0.06, 0.10), 3), tone=round(rng.random(), 3), lean=round(rng.uniform(-0.06, 0.06), 3))
        for _ in range(_n(rng, 2, 3, mul)):
            add("fore", k="tree", x=round(rng.choice([rng.uniform(0.0, 0.18), rng.uniform(0.82, 1.0)]), 3), y=0.98,
                h=round(rng.uniform(0.45, 0.62), 3), w=round(rng.uniform(0.12, 0.18), 3), tone=round(rng.random(), 3),
                lean=round(rng.uniform(-0.04, 0.04), 3))
        if d.name == "village":
            for i in range(_n(rng, 3, 5, mul)):
                add("mid", k="building", style="house", x=round(0.08 + i * 0.2 + rng.uniform(-0.03, 0.03), 3),
                    y=d.horizon + 0.10, w=round(rng.uniform(0.07, 0.11), 3), h=round(rng.uniform(0.07, 0.11), 3),
                    tone=round(rng.random(), 3), lit=rng.random() < 0.6)
    elif d.name in ("city", "street", "futuristic_city"):
        fut = d.name == "futuristic_city"
        for layer, (lo, hi), (hmin, hmax), yoff in (("far", (9, 13), (0.16, 0.34 if not fut else 0.50), 0.0),
                                                     ("mid", (6, 9), (0.22, 0.42 if not fut else 0.62), 0.04)):
            for _ in range(_n(rng, lo, hi, mul)):
                add(layer, k="building", style="tower" if fut else "block", x=round(rng.random(), 3), y=d.horizon + yoff,
                    w=round(rng.uniform(0.05, 0.10), 3), h=round(rng.uniform(hmin, hmax), 3),
                    tone=round(rng.random(), 3), lit=rng.random() < (0.75 if fut else 0.5), neon=fut,
                    windows=int(rng.randint(3, 7)), antenna=rng.random() < 0.3)
        if d.name == "street":
            for i in range(_n(rng, 3, 4, mul)):
                add("fore", k="lamp", x=round(0.1 + i * 0.27 + rng.uniform(-0.02, 0.02), 3), y=0.96, h=round(rng.uniform(0.3, 0.38), 3))
    elif d.name == "desert":
        for i, (base, amp) in enumerate(((d.horizon, 0.10), (d.horizon + 0.05, 0.12), (d.horizon + 0.12, 0.14))):
            add("far" if i == 0 else "mid", **_ridge(rng, base, amp, pts=10))
        for _ in range(_n(rng, 2, 4, mul)):
            add("mid", k="rock", x=round(rng.random(), 3), y=d.horizon + 0.12, w=round(rng.uniform(0.03, 0.07), 3),
                h=round(rng.uniform(0.03, 0.07), 3), tone=round(rng.random(), 3))
    elif d.name == "mountain":
        add("far", **_ridge(rng, d.horizon, 0.36, snow=True))
        add("mid", **_ridge(rng, d.horizon + 0.04, 0.28, snow=True))
        add("fore", **_ridge(rng, d.horizon + 0.12, 0.16))
        for _ in range(_n(rng, 4, 7, mul)):
            add("mid", k="tree", x=round(rng.random(), 3), y=d.horizon + 0.14, h=round(rng.uniform(0.10, 0.16), 3),
                w=round(rng.uniform(0.03, 0.05), 3), tone=round(rng.random(), 3), lean=0.0)
    elif d.name == "underwater":
        add("far", **_ridge(rng, 0.86, 0.10))
        for _ in range(_n(rng, 6, 10, mul)):
            add("mid", k="kelp", x=round(rng.random(), 3), y=0.98, h=round(rng.uniform(0.18, 0.42), 3),
                w=round(rng.uniform(0.012, 0.025), 3), tone=round(rng.random(), 3), phase=round(rng.uniform(0, 6.28), 3))
        for _ in range(_n(rng, 2, 4, mul)):
            add("mid", k="fish", x=round(rng.random(), 3), y=round(rng.uniform(0.25, 0.65), 3), w=round(rng.uniform(0.03, 0.05), 3),
                speed=round(rng.uniform(0.02, 0.05), 3), tone=round(rng.random(), 3))
    elif d.name in ("room", "rain_on_window"):
        add("far", k="window", x=0.5, y=0.12, w=0.5 if d.name == "rain_on_window" else 0.22, h=0.46 if d.name == "rain_on_window" else 0.34)
        if d.name == "room":
            add("mid", k="table", x=round(rng.uniform(0.25, 0.7), 3), y=0.80, w=round(rng.uniform(0.2, 0.3), 3), h=0.14)
    elif d.name == "laboratory":
        for i in range(_n(rng, 3, 4, mul)):
            add("mid", k="bench", x=round(0.12 + i * 0.26 + rng.uniform(-0.02, 0.02), 3), y=0.80, w=0.2, h=round(rng.uniform(0.12, 0.16), 3))
        for _ in range(_n(rng, 5, 9, mul)):
            add("mid", k="flask", x=round(rng.uniform(0.05, 0.95), 3), y=0.70, h=round(rng.uniform(0.05, 0.10), 3),
                tone=round(rng.random(), 3), fill=round(rng.uniform(0.3, 0.8), 2))
    elif d.name == "space":
        for _ in range(_n(rng, 1, 3, mul)):
            add("far", k="planet", x=round(rng.uniform(0.15, 0.85), 3), y=round(rng.uniform(0.15, 0.6), 3),
                w=round(rng.uniform(0.08, 0.22), 3), tone=round(rng.random(), 3), ring=rng.random() < 0.4)
    elif d.name == "ancient_persia":
        add("far", **_ridge(rng, d.horizon, 0.14))
        n_cols = _n(rng, 6, 9, mul)
        for i in range(n_cols):
            broken = rng.random() < 0.25
            add("mid", k="column", x=round(0.08 + i * (0.84 / max(1, n_cols - 1)) + rng.uniform(-0.01, 0.01), 3), y=d.horizon + 0.22,
                w=round(rng.uniform(0.035, 0.05), 3), h=round(rng.uniform(0.18, 0.30) * (0.55 if broken else 1.0), 3),
                wear=round(rng.uniform(0.2, 0.9), 2), broken=broken)
        for i in range(_n(rng, 3, 5, mul)):
            add("fore", k="stair", x=0.5, y=0.76 + i * 0.05, w=round(0.9 - i * 0.05, 3), h=0.05, tone=round(0.2 + i * 0.1, 2))
        add("mid", k="relief", x=0.5, y=d.horizon + 0.05, w=0.34, h=0.12, panels=int(rng.randint(4, 7)))
    elif d.name == "water_cycle":
        add("far", **_ridge(rng, d.horizon, 0.34, snow=True))
        add("fore", k="sea", y=0.80)
        for i in range(_n(rng, 2, 3, mul)):
            add("far", k="cloud", x=round(0.2 + i * 0.3 + rng.uniform(-0.05, 0.05), 3), y=round(rng.uniform(0.10, 0.22), 3),
                w=round(rng.uniform(0.14, 0.22), 3), tone=round(rng.random(), 3))
        add("mid", k="arrow", x=0.18, y=0.74, to_y=0.30, tone=0.0, label="evaporation")
        add("mid", k="arrow", x=0.55, y=0.26, to_y=0.56, tone=1.0, label="precipitation")
        add("mid", k="arrow", x=0.80, y=0.60, to_y=0.76, tone=0.5, label="runoff")
    elif d.name in ("sky", "night_sky"):
        for i in range(_n(rng, 2, 4, mul)):
            add("far", k="cloud", x=round(rng.random(), 3), y=round(rng.uniform(0.15, 0.55), 3),
                w=round(rng.uniform(0.14, 0.26), 3), tone=round(rng.random(), 3))
    return {"name": d.name, "horizon": d.horizon, "ground": d.ground, "has_sky": d.has_sky, "fog": d.fog,
            "stars": d.stars_at_night, "decor": decor, "seed": seed, "quality": quality}


def decor_count(env_params: dict[str, Any]) -> int:
    return len(env_params.get("decor", []))
