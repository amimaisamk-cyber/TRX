# -*- coding: utf-8 -*-
"""Camera Planner -- بخشِ ۱۲ سندِ طراحی."""

from __future__ import annotations

from .scene_schema import CameraSpec

_MOVEMENT_PRESETS: dict[str, dict[str, float]] = {
    "close_up": {"zoom_start": 1.1, "zoom_end": 1.18, "pan_x": 0.0, "pan_y": 0.0},
    "wide": {"zoom_start": 0.95, "zoom_end": 1.0, "pan_x": 0.0, "pan_y": 0.0},
    "slow_push_in": {"zoom_start": 1.0, "zoom_end": 1.1, "pan_x": 0.0, "pan_y": 0.0},
    "pan": {"zoom_start": 1.0, "zoom_end": 1.02, "pan_x": 4.0, "pan_y": 0.0},
}


def plan_camera(camera_hint: str, mood: str = "calm") -> CameraSpec:
    preset = _MOVEMENT_PRESETS.get(camera_hint, _MOVEMENT_PRESETS["slow_push_in"])
    movement = "slow_push_in" if camera_hint in ("close_up", "slow_push_in") else camera_hint
    intensity = 0.1 if mood in ("calm", "dreamy") else 0.2
    return CameraSpec(
        movement=movement,
        intensity=intensity,
        zoom_start=preset["zoom_start"],
        zoom_end=preset["zoom_end"],
        pan_x=preset["pan_x"],
        pan_y=preset["pan_y"],
        shake=0.0 if mood != "epic" else 0.04,
    )


def apply_edit(camera: CameraSpec, *, closer: bool = False, farther: bool = False) -> CameraSpec:
    """اصلاحِ موضعیِ دوربین (بخشِ ۲۱: patch به‌جایِ بازسازیِ کامل)."""
    if closer:
        camera.zoom_end = round(min(2.0, camera.zoom_end + 0.15), 3)
    if farther:
        camera.zoom_end = round(max(0.8, camera.zoom_end - 0.15), 3)
    return camera


# ----------------------------------------------------------------------
#   Camera Choreography هدف‌محور (بخشِ ۱۱ سندِ ارتقا)
# ----------------------------------------------------------------------
SEMANTIC_MOVES = ("static", "pan", "tilt", "dolly_in", "dolly_out", "zoom", "tracking", "orbit",
                  "crane", "reveal", "follow", "focus_transition")
SHOTS = ("establishing", "close_up", "wide", "over_shoulder", "pov")

# هر حرکت: (zoom_start, zoom_end, pan_x, easing)  -- pan_x نسبی به عرض
_SEM_PRESETS = {
    "static": (1.0, 1.0, 0.0, "linear"),
    "dolly_in": (1.0, 1.65, 0.0, "ease_in_out"),
    "dolly_out": (1.45, 1.0, 0.0, "ease_in_out"),
    "zoom": (1.0, 1.5, 0.0, "ease_in_out"),
    "pan": (1.08, 1.08, 0.12, "ease_in_out"),
    "tilt": (1.08, 1.08, 0.0, "ease_in_out"),
    "tracking": (1.15, 1.15, 0.0, "ease_in_out"),
    "follow": (1.3, 1.3, 0.0, "ease_out"),
    "orbit": (1.15, 1.3, 0.08, "ease_in_out"),
    "crane": (1.0, 1.35, 0.0, "ease_in_out"),
    "reveal": (1.5, 1.0, 0.0, "ease_out"),
    "focus_transition": (1.1, 1.2, 0.0, "ease_in_out"),
}
_SHOT_ZOOM = {"close_up": (1.55, 1.7), "wide": (1.0, 1.04), "establishing": (1.0, 1.06),
              "over_shoulder": (1.35, 1.4), "pov": (1.2, 1.25)}
_LEGACY_MOVEMENT = {"dolly_in": "slow_push_in", "zoom": "slow_push_in", "dolly_out": "slow_pull_out",
                    "pan": "pan_right", "static": "static"}


def plan_semantic_camera(move: str | None, *, target: str | None, target_xy: tuple[float, float] = (0.5, 0.5),
                         shot: str | None = None, speed: str | None = None, mood: str = "calm") -> CameraSpec:
    """دوربینِ subject-aware: target یک id در Scene Graph است و نقطهٔ کانونیِ زوم = مختصاتِ همان هدف."""
    mv = move if move in _SEM_PRESETS else ("static" if not shot else "zoom")
    zs, ze, pan_x, easing = _SEM_PRESETS[mv]
    if shot in _SHOT_ZOOM and (move is None or move == "static"):
        zs, ze = _SHOT_ZOOM[shot]
        mv = "static" if move is None else mv
    if speed == "slow":
        easing = "ease_in_out" if easing == "linear" else easing
        ze = zs + (ze - zs) * 0.85
    elif speed == "fast":
        ze = zs + (ze - zs) * 1.25
    intensity = 0.1 if mood in ("calm", "dreamy") else 0.2
    return CameraSpec(
        movement=_LEGACY_MOVEMENT.get(mv, "static" if mv == "static" else "slow_push_in"),
        intensity=intensity, zoom_start=round(zs, 3), zoom_end=round(ze, 3), pan_x=pan_x, pan_y=0.0,
        shake=0.04 if mood == "epic" else 0.0,
        move=mv, target=target, easing=easing, origin_x=round(target_xy[0], 3), origin_y=round(target_xy[1], 3),
    )
