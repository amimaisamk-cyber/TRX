# -*- coding: utf-8 -*-
"""
VideoProject (بخش‌هایِ ۲۴ تا ۲۵ سندِ ارتقا): چندصحنه‌ای + پیوستگی.

یک پروژه = فهرستِ SceneSpec + انتقال‌ها + صدایِ سراسری. تک‌صحنه‌ای حالتِ خاصِ n=1 است.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from .scene_schema import SceneSpec
from .semantic_planner.intent import VideoIntent
from . import scene_planner as sp

TRANSITION_S = 0.8
MAX_PROJECT_SECONDS = 60.0
MAX_SCENES = 6


@dataclass
class Transition:
    kind: str = "fade_through_black"
    duration: float = TRANSITION_S

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "duration": self.duration}


@dataclass
class VideoProject:
    project_id: str
    scenes: list[SceneSpec]
    transitions: list[Transition] = field(default_factory=list)
    profile: str = "medium"
    intent: dict[str, Any] = field(default_factory=dict)
    requirements: list[dict[str, Any]] = field(default_factory=list)

    # -- زمان --
    @property
    def starts(self) -> list[float]:
        out, t = [], 0.0
        for s in self.scenes:
            out.append(round(t, 3))
            t += s.duration
        return out

    @property
    def total(self) -> float:
        return round(sum(s.duration for s in self.scenes), 3)

    @property
    def explicit_silence(self) -> bool:
        return all(s.audio.explicit_silence for s in self.scenes)

    # -- صدایِ سراسری با ادغامِ ambience/music پیوسته (continuity صدا) --
    def global_audio(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for i, (sc, off) in enumerate(zip(self.scenes, self.starts)):
            for e in sc.audio.events:
                g = dict(e)
                g["start"] = round(e["start"] + off, 3)
                g["scene"] = i
                g["id"] = f"s{i}_{e['id']}"
                prev = next((x for x in reversed(out) if x["type"] == e["type"] and x["source"] == e["source"]
                             and x["type"] in ("ambience", "music")), None)
                if prev is not None and abs((prev["start"] + prev["duration"]) - g["start"]) <= 0.01 and prev["loop"]:
                    prev["duration"] = round(prev["duration"] + g["duration"], 3)
                    prev["fade_out"] = g["fade_out"]
                    prev["merged_scenes"] = prev.get("merged_scenes", [prev["scene"]]) + [i]
                    continue
                out.append(g)
        return out

    def narration(self) -> dict[str, Any] | None:
        for sc, off in zip(self.scenes, self.starts):
            if sc.audio.narration:
                n = dict(sc.audio.narration)
                n["start"] = round(n["start"] + off, 3)
                return n
        return None

    # -- سریال‌سازی --
    def to_render_dict(self) -> dict[str, Any]:
        first = self.scenes[0]
        return {"render": first.render_scale or {"w": first.width // 2, "h": first.height // 2},
                "scenes": [s.to_dict() for s in self.scenes], "starts": self.starts, "total": self.total,
                "transitions": [t.to_dict() for t in self.transitions], "global_audio": self.global_audio(),
                "narration": self.narration(), "explicit_silence": self.explicit_silence, "profile": self.profile}

    def to_dict(self) -> dict[str, Any]:
        return {"project_id": self.project_id, "scenes": [s.to_dict() for s in self.scenes],
                "transitions": [t.to_dict() for t in self.transitions], "profile": self.profile,
                "intent": self.intent, "requirements": self.requirements}

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "VideoProject":
        return VideoProject(project_id=d["project_id"], scenes=[SceneSpec.from_dict(s) for s in d["scenes"]],
                            transitions=[Transition(**t) for t in d.get("transitions", [])],
                            profile=d.get("profile", "medium"), intent=d.get("intent", {}),
                            requirements=d.get("requirements", []))


def scene_roles(n: int) -> list[str]:
    if n <= 1:
        return ["main"]
    seq = {2: ["establishing", "close"], 3: ["establishing", "approach", "close"],
           4: ["establishing", "approach", "close", "event"],
           5: ["establishing", "approach", "close", "event", "ending"]}
    return seq.get(n) or (["establishing", "approach", "close", "event", "close", "ending"][:n])


def build_project(intent: VideoIntent, *, quality: str = "medium", allow_auto_music: bool = False) -> VideoProject:
    """VideoIntent → VideoProject. continuity: seed/محیط/سبک/آب‌وهوا/سوژه مشترک؛ زمانِ روز فقط در مرزِ انتقال تغییر می‌کند."""
    seed = sp.stable_seed(intent)
    n = max(1, min(MAX_SCENES, intent.scene_count))
    total = float(intent.duration or (8.0 if n == 1 else 6.0 * n))
    total = max(2.0 * n, min(MAX_PROJECT_SECONDS, total))
    per = round(total / n, 3)
    roles = scene_roles(n)
    scenes: list[SceneSpec] = []
    t_from = intent.time_of_day
    t_to = intent.time_transition[1] if intent.time_transition else None
    for i, role in enumerate(roles):
        override = None
        if n > 1 and intent.time_transition:
            override = (intent.time_transition[1], None) if i == n - 1 else (intent.time_transition[0], None)
            if i == n - 1 and n > 1:
                override = (intent.time_transition[1], None)
        sc = sp.plan_scene(intent, seed=seed, quality=quality, duration=per, role=role, index=i, n_scenes=n,
                           allow_auto_music=allow_auto_music, tod_override=override)
        scenes.append(sc)
    tr = [Transition(duration=round(min(TRANSITION_S, per * 0.2), 3)) for _ in range(n - 1)]
    return VideoProject(project_id=f"vp_{int(time.time())}_{uuid.uuid4().hex[:6]}", scenes=scenes, transitions=tr,
                        profile=quality, intent=intent.to_dict())
