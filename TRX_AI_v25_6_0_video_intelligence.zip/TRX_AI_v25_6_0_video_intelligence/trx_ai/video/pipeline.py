# -*- coding: utf-8 -*-
"""
Video Pipeline v2 (Phase H): Intent → Requirements → Project → Degrade → Render → Verify → Repair.

تنها نقطهٔ ورودِ ارتقایافته؛ ``runtime_manager`` فقط این را صدا می‌زند و در صورتِ استثنا به مسیرِ
legacy (دست‌نخورده) برمی‌گردد (fail-open). هیچ تصمیمِ UI/HTML بیرون از این زنجیره نیست.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any

from .semantic_planner import understand, extract_requirements
from .semantic_planner.intent import VideoIntent, Requirement
from . import project as pj
from . import semantic_validator as sv
from . import repair as rp
from . import resource_guard as rg
from . import validator as safety
from . import render_probe
from .renderers import HTMLCanvasRenderer

MAX_REPAIR_ROUNDS = 3
_RENDERER = HTMLCanvasRenderer()


@dataclass
class VideoBuild:
    intent: VideoIntent
    requirements: list[Requirement]
    project: pj.VideoProject
    html: str
    results: list[sv.ReqResult]
    report: dict[str, Any]
    repairs: list[dict[str, Any]] = field(default_factory=list)
    degradations: list[rg.Degradation] = field(default_factory=list)
    stage_ms: dict[str, int] = field(default_factory=dict)
    cache_hit: bool = False

    @property
    def status(self) -> str:
        if any(r.status == sv.FAIL for r in self.results) or not self.report.get("passed", False):
            return "partial"
        return "degraded" if self.degradations else "ok"


def _probe_enabled(flag: bool | None) -> bool:
    if flag is not None:
        return flag
    return os.environ.get("TRX_VIDEO_PROBE") == "1" and render_probe.available()


def verify(project: pj.VideoProject, html: str, reqs: list[Requirement], *, probe: bool = False,
           resource: dict[str, Any] | None = None) -> tuple[list[sv.ReqResult], dict[str, Any]]:
    results = sv.check_requirements(reqs, html, project.intent)
    struct: list[str] = []
    for sc in project.scenes:
        struct += [f"{sc.scene_id}: {e}" for e in sv.validate_structure(sc)]
    pr = None
    if probe:
        times = sorted({0.5, project.total * 0.5, max(0.1, project.total - 0.5)})
        pr = render_probe.probe(html, times)
        if pr and (pr.get("errors") or pr.get("runtime_error")):
            struct.append(f"render_probe: {pr.get('errors') or pr.get('runtime_error')}")
    return results, sv.quality_report(results, project, html, struct, pr, resource)


def render_project(project: pj.VideoProject) -> str:
    html = _RENDERER.render(project)
    safe = safety.validate_html(html)
    if not safe["passed"]:
        raise ValueError("HTML تولیدشده از اعتبارسنجیِ ایمنی رد شد: " + "; ".join(safe["issues"]))
    return html


def build_video(text: str, *, quality: str | None = None, token: rg.CancelToken | None = None,
                max_repairs: int = MAX_REPAIR_ROUNDS, probe: bool | None = None,
                cache: rg.PlanCache | None = None, allow_auto_music: bool = False) -> VideoBuild:
    tok = token or rg.CancelToken()
    profile = rg.choose_profile(quality)
    ms: dict[str, int] = {}
    t0 = time.perf_counter()

    def lap(name: str) -> None:
        nonlocal t0
        now = time.perf_counter()
        ms[name] = int((now - t0) * 1000)
        t0 = now
        tok.check(name)

    tok.check("start")
    intent = understand(text)
    reqs = extract_requirements(intent)
    lap("understand")

    cache_hit = False
    project = None
    key = None
    if cache is not None:
        key = rg.PlanCache.key(intent.semantic_key(), profile)
        cached = cache.get(key)
        if cached is not None:
            project = pj.VideoProject.from_dict(cached)
            project.project_id = f"vp_{int(time.time())}_{os.urandom(3).hex()}"
            from . import scene_planner as sp
            for sc in project.scenes:
                sc.scene_id = sp.new_scene_id()
            cache_hit = True
    if project is None:
        project = pj.build_project(intent, quality=profile, allow_auto_music=allow_auto_music)
        if cache is not None and key:
            cache.put(key, project.to_dict())
    project.requirements = [r.to_dict() for r in reqs]
    lap("plan")

    degr = rg.degrade(project, profile)
    lap("degrade")
    html = render_project(project)
    lap("render")
    use_probe = _probe_enabled(probe)
    results, report = verify(project, html, reqs, probe=use_probe, resource=rg.estimate(project))
    lap("verify")

    repairs: list[dict[str, Any]] = []
    last_fail: set[str] = set()
    for rnd in range(max_repairs):
        failing = [r for r in results if r.status == sv.FAIL]
        ids = {r.id for r in failing}
        if not failing or ids == last_fail:
            break
        last_fail = ids
        log = rp.repair(project, intent, failing)
        repairs.append({"round": rnd + 1, "fixing": sorted(ids), "log": log})
        degr += rg.degrade(project, profile)
        html = render_project(project)
        results, report = verify(project, html, reqs, probe=use_probe, resource=rg.estimate(project))
        tok.check("repair")
    lap("repair")
    return VideoBuild(intent, reqs, project, html, results, report, repairs, degr, ms, cache_hit)


def rebuild_after_patch(project: pj.VideoProject, *, probe: bool | None = None) -> tuple[str, list[sv.ReqResult], dict[str, Any]]:
    """بعد از patch: صوتِ footsteps/… هم‌گام و دوباره رندر + بررسیِ requirementها."""
    intent = VideoIntent.from_dict(project.intent)
    from . import scene_planner as sp
    for sc in project.scenes:
        if sc.graph.get("plan"):
            sp.rebuild_audio(sc, sp.ctx_from_scene(sc, intent))
    reqs = [Requirement(**r) for r in project.requirements]
    html = render_project(project)
    results, report = verify(project, html, reqs, probe=_probe_enabled(probe), resource=rg.estimate(project))
    return html, results, report
