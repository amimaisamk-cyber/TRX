# -*- coding: utf-8 -*-
"""
Semantic Validator + Requirement Traceability (بخش‌هایِ ۱۸ تا ۲۱ سندِ ارتقا).

دو سطحِ مستقل از ``validator.validate_html`` (ایمنیِ کد، دست‌نخورده):
  1. ساختاری: SceneSpec / Scene Graph / Timeline / Audio events.
  2. معنایی: هر Requirement با شاهد → PASS | FAIL | UNSUPPORTED.
بررسی‌ها روی *JSِ جاسازی‌شده در همان HTML نهایی* انجام می‌شوند (نه فقط شیءِ پایتونی)
تا حذفِ بی‌صدایِ یک فیلد در renderer هم گرفته شود.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from typing import Any

from .scene_graph import SceneGraph, RELATION_KINDS
from .semantic_planner.intent import Requirement
from . import timeline_engine as tl
from . import audio_planner as ap
from . import object_library as objlib
from . import environment_library as envlib
from .scene_schema import SceneSpec

PASS, FAIL, UNSUPPORTED = "PASS", "FAIL", "UNSUPPORTED"
_NODE_TO_DRAWER = {"light_source": "window_light"}


@dataclass
class ReqResult:
    id: str
    kind: str
    expected: str
    status: str
    evidence: str
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class HtmlFacts:
    project: dict[str, Any] | None
    drawers: set[str] = field(default_factory=set)
    recipes: set[str] = field(default_factory=set)
    ok: bool = False
    error: str = ""


_PROJ_RE = re.compile(r"var PROJECT = (\{.*?\});\n\(function", re.S)


def inspect_html(html: str) -> HtmlFacts:
    """JSON و قابلیت‌هایِ واقعیِ داخلِ HTML را بیرون می‌کشد."""
    m = _PROJ_RE.search(html)
    if not m:
        return HtmlFacts(None, error="PROJECT json پیدا نشد")
    try:
        proj = json.loads(m.group(1))
    except json.JSONDecodeError as exc:
        return HtmlFacts(None, error=f"PROJECT json خراب: {exc}")
    drawers = set(re.findall(r"function draw_([a-z_]+)\(", html))
    rec_block = re.search(r"var RECIPES = \{(.*?)\n  \};", html, re.S)
    shot_block = re.search(r"var SHOTS = \{(.*?)\n  \};", html, re.S)
    recipes: set[str] = set()
    for blk in (rec_block, shot_block):
        if blk:
            recipes |= set(re.findall(r"^\s{4}([a-z_]+): function", blk.group(1), re.M))
    return HtmlFacts(proj, drawers, recipes, ok=True)


# ----------------------------------------------------------------------
#   اعتبارسنجیِ ساختاری
# ----------------------------------------------------------------------

def validate_structure(scene: SceneSpec) -> list[str]:
    errs = list(scene.validate())
    g = SceneGraph.from_dict(scene.graph) if scene.graph.get("nodes") is not None else SceneGraph()
    if scene.graph.get("nodes") is not None:
        errs += g.validate()
        cam = scene.camera
        if cam.target and cam.target not in g.nodes:
            errs.append(f"camera.target ارجاعِ ناموجود: {cam.target}")
        for o in scene.objects:
            if o.kind and o.kind not in objlib.KNOWN_KINDS and o.type not in ("particle_group",):
                errs.append(f"object {o.id}: kind ناشناخته ({o.kind})")
        if scene.camera.zoom_start <= 0 or scene.camera.zoom_end <= 0:
            errs.append("zoom نامعتبر")
    errs += tl.validate(scene.timeline, scene.duration)
    errs += ap.validate_events(scene.audio.events, scene.duration)
    for e in scene.audio.events:
        if e["source"] not in ap.SYNTH_RECIPES:
            if scene.audio.status.get(e["source"], "").startswith("unavailable"):
                continue
            errs.append(f"audio {e['id']}: source بدونِ recipe و بدونِ وضعیتِ unavailable")
    return errs


# ----------------------------------------------------------------------
#   بررسیِ هر Requirement
# ----------------------------------------------------------------------

def _scene_dicts(facts: HtmlFacts) -> list[dict[str, Any]]:
    return facts.project["scenes"] if facts.project else []


def _nodes(sd: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {n["id"]: n for n in sd["graph"]["nodes"]}


def _tl_value(sd: dict[str, Any], target: str, prop: str, t: float, default: float = 0.0) -> float:
    evs = [e for e in sd["timeline"] if e.get("target") == target and e.get("property") == prop]
    evs.sort(key=lambda e: e["time"])
    val = default
    for e in evs:
        if t < e["time"]:
            continue
        to, dur = e.get("to"), e.get("duration", 0)
        if to is not None and dur > 0:
            f = max(0.0, min(1.0, (t - e["time"]) / dur))
            a = e["value"] if isinstance(e.get("value"), (int, float)) else val
            val = a + (to - a) * f
        else:
            v = to if to is not None else e.get("value")
            if isinstance(v, (int, float)):
                val = float(v)
    return val


def _check(req: Requirement, facts: HtmlFacts, intent: dict[str, Any]) -> ReqResult:
    P = facts.project
    scenes = _scene_dicts(facts)
    k, exp = req.kind, req.expected

    def res(status, evidence, reason=""):
        return ReqResult(req.id, k, exp, status, evidence, reason)

    if k == "subject":
        for i, sd in enumerate(scenes):
            n = _nodes(sd).get("subject")
            if n is None:
                continue
            requested = n["visual_properties"].get("requested_kind", n["type"])
            if requested != exp:
                continue
            if exp not in objlib.KNOWN_KINDS:
                return res(UNSUPPORTED, f"scene{i}: {exp} → placeholder object", f"drawer برایِ «{exp}» وجود ندارد؛ placeholder کشیده می‌شود، نه خودِ شیء.")
            if exp not in facts.drawers:
                return res(FAIL, f"scene{i}: draw_{exp} در JS نیست", "drawer در renderer ناموجود")
            return res(PASS, f"scene{i}: node subject type={exp}, drawer=draw_{exp}")
        return res(FAIL, "گرهٔ subject با نوعِ مورد انتظار پیدا نشد")
    if k == "environment":
        if exp not in envlib.SUPPORTED_ENVIRONMENTS:
            return res(UNSUPPORTED, f"{exp} در Environment Library نیست")
        for i, sd in enumerate(scenes):
            env = _nodes(sd).get("env")
            if env and env["visual_properties"]["name"] == exp and (env["visual_properties"]["decor"] or exp in ("sky", "night_sky", "space")):
                return res(PASS, f"scene{i}: env={exp}, decor={len(env['visual_properties']['decor'])}")
        return res(FAIL, "env node با نامِ مورد انتظار/دکور پیدا نشد")
    if k == "weather":
        for i, sd in enumerate(scenes):
            w = _nodes(sd).get("weather")
            if not w or w["visual_properties"]["kind"] != exp:
                continue
            if exp not in facts.drawers:
                return res(FAIL, f"draw_{exp} نیست")
            mx = max(_tl_value(sd, "weather", "intensity", sd["duration"] * j / 40) for j in range(41))
            if mx > 0.05:
                return res(PASS, f"scene{i}: weather={exp}, max_intensity={mx:.2f}")
            return res(FAIL, f"scene{i}: weather هست ولی intensity همیشه ۰ است")
        return res(FAIL, "weather node پیدا نشد")
    if k == "time_of_day":
        if req.params.get("transition"):
            a, b = exp.split("->")
            for i, sd in enumerate(scenes):
                sky = _nodes(sd).get("sky")
                blend = [e for e in sd["timeline"] if e.get("target") == "sky" and e.get("property") == "time_blend"]
                if sky and sky["visual_properties"]["from"] == a and sky["visual_properties"]["to"] == b and blend:
                    return res(PASS, f"scene{i}: {a}→{b}, time_blend events={len(blend)}")
            # چندصحنه‌ای: انتقال بینِ صحنه‌ها
            froms = [_nodes(sd)["sky"]["visual_properties"]["from"] for sd in scenes if "sky" in _nodes(sd)]
            if len(scenes) > 1 and froms and froms[0] == a and froms[-1] == b:
                return res(PASS, f"انتقال بینِ صحنه‌ها: {froms}")
            return res(FAIL, "انتقالِ زمانیِ مورد انتظار در sky/timeline نیست")
        for i, sd in enumerate(scenes):
            sky = _nodes(sd).get("sky")
            if sky and sky["visual_properties"]["from"] == exp:
                return res(PASS, f"scene{i}: sky.from={exp}")
        return res(FAIL, "sky با زمانِ مورد انتظار پیدا نشد")
    if k == "camera":
        if exp.startswith("shot:"):
            shot = exp.split(":")[1]
            want = {"close_up": lambda c: c["zoom_end"] >= 1.5, "wide": lambda c: c["zoom_end"] <= 1.1,
                    "establishing": lambda c: c["zoom_end"] <= 1.1}.get(shot, lambda c: True)
            for i, sd in enumerate(scenes):
                if want(sd["camera"]):
                    return res(PASS, f"scene{i}: zoom_end={sd['camera']['zoom_end']}")
            return res(FAIL, "نمای مورد انتظار با zoom هم‌خوان نیست")
        for i, sd in enumerate(scenes):
            c = sd["camera"]
            if c["move"] != exp:
                continue
            nodes = _nodes(sd)
            if req.params.get("target_required") and (not c["target"] or c["target"] not in nodes):
                return res(FAIL, f"scene{i}: move={exp} ولی target نامعتبر ({c['target']})")
            if exp in ("dolly_in", "zoom") and not c["zoom_end"] > c["zoom_start"]:
                return res(FAIL, f"scene{i}: dolly_in ولی zoom تغییر نمی‌کند")
            if exp == "dolly_out" and not c["zoom_end"] < c["zoom_start"]:
                return res(FAIL, f"scene{i}: dolly_out ولی zoom تغییر نمی‌کند")
            if req.params.get("speed") == "slow" and c["easing"] == "linear":
                return res(FAIL, f"scene{i}: «آرام» خواسته شد ولی easing خطی است")
            return res(PASS, f"scene{i}: move={exp}, target={c['target']}, zoom {c['zoom_start']}→{c['zoom_end']}, easing={c['easing']}")
        return res(FAIL, f"هیچ صحنه‌ای camera.move={exp} ندارد")
    if k == "motion":
        kind, direction = exp.split(":")
        for i, sd in enumerate(scenes):
            for e in sd["timeline"]:
                if e.get("event") == "motion" and e.get("property") == "pos_x":
                    a, b = e["value"], e["to"]
                    if (direction == "ltr" and b > a) or (direction == "rtl" and b < a):
                        if e["target"] in _nodes(sd) and "character" in facts.drawers:
                            return res(PASS, f"scene{i}: {e['target']} pos_x {a}→{b} در [{e['time']},{e['time'] + e['duration']}]")
        return res(FAIL, "رویدادِ حرکتِ هم‌جهت با درخواست پیدا نشد")
    if k == "lighting":
        for i, sd in enumerate(scenes):
            n = _nodes(sd)
            if exp == "window_light" and "window_light" in n and sd["lighting"]["local_sources"]:
                mx = max(_tl_value(sd, "window_light", "intensity", sd["duration"] * j / 20) for j in range(21))
                if mx > 0.5:
                    return res(PASS, f"scene{i}: window_light max={mx:.2f}")
                return res(FAIL, "window_light هست ولی خاموش است")
            if exp in ("low_light", "moonlight", "warm_light", "neon_light"):
                return res(PASS, f"scene{i}: lighting.type={sd['lighting']['type']}, intensity={sd['lighting']['intensity']}")
        return res(FAIL, "منبعِ نورِ محلیِ درخواستی پیدا نشد")
    if k == "silence":
        evs = P["global_audio"]
        if not evs and P["explicit_silence"]:
            return res(PASS, "هیچ audio event ای نیست و explicit_silence=True")
        return res(FAIL, f"{len(evs)} audio event با وجودِ درخواستِ بی‌صدا")
    if k == "audio":
        evs = [e for e in P["global_audio"] if e["source"] == ("footstep" if exp == "footsteps" else exp)]
        if not evs:
            return res(FAIL, f"audio event برایِ {exp} نیست")
        src = evs[0]["source"]
        if src not in facts.recipes:
            return res(UNSUPPORTED, f"{src}: recipe در JS نیست", "صدا برنامه‌ریزی شد ولی سنتز/پخش ندارد؛ صراحتاً unavailable.")
        return res(PASS, f"{len(evs)} event({src}) + recipe موجود، اولین start={evs[0]['start']}")
    if k == "music":
        has = [e for e in P["global_audio"] if e["type"] == "music"]
        if req.negated:
            return res(PASS if not has else FAIL, "music events=" + str(len(has)))
        if has and "ambient_pad" in facts.recipes:
            return res(PASS, "music event + recipe ambient_pad")
        return res(FAIL, "موسیقیِ درخواستی ساخته نشد")
    if k == "narration":
        n = P.get("narration")
        subs = [lb for sd in scenes for lb in sd["labels"] if lb.get("role") == "subtitle"]
        ev = [e for e in P["global_audio"] if e["type"] == "narration"]
        if n and ev and subs:
            return res(PASS, f"narration {n['duration']}s، {len(subs)} زیرنویس، TTS اختیاریِ runtime")
        return res(FAIL, "narration/زیرنویس کامل نیست")
    if k == "event":
        return _check_event(req, facts, scenes, res)
    if k == "style":
        for i, sd in enumerate(scenes):
            if sd["style_profile"] == exp and sd["graph"].get("style", {}).get("name") == exp:
                return res(PASS, f"scene{i}: style_profile={exp}, graph.style اعمال شد")
        return res(FAIL, "style_profile اعمال نشده")
    if k == "duration":
        if abs(P["total"] - float(exp)) <= 0.6:
            return res(PASS, f"total={P['total']}")
        return res(FAIL, f"total={P['total']} ≠ {exp}")
    if k == "aspect_ratio":
        return res(PASS if all(sd["aspect_ratio"] == exp for sd in scenes) else FAIL, ",".join(sd["aspect_ratio"] for sd in scenes))
    if k == "multi_scene":
        return res(PASS if len(scenes) == int(exp) else FAIL, f"scenes={len(scenes)}")
    if k == "constraint":
        return res(UNSUPPORTED, "سیاست", "نمایشِ دقیقِ فردِ واقعی پشتیبانی/مجاز نیست؛ شخصیتِ عمومی/انتزاعی ساخته شد.")
    return res(FAIL, "نوعِ requirement ناشناخته")


def _check_event(req, facts, scenes, res) -> ReqResult:
    exp = req.expected
    P = facts.project
    if exp in ("rain_start", "rain_stop"):
        for i, sd in enumerate(scenes):
            w = _nodes(sd).get("weather")
            if not w:
                continue
            ts = [sd["duration"] * j / 80 for j in range(81)]
            vals = [_tl_value(sd, "weather", "intensity", t) for t in ts]
            if exp == "rain_start" and vals[0] < 0.2 and max(vals) > 0.8:
                t0 = next(t for t, v in zip(ts, vals) if v > 0.5)
                return res(PASS, f"scene{i}: intensity {vals[0]:.1f}→{max(vals):.1f} (آغاز≈{t0:.1f}s)")
            if exp == "rain_stop" and max(vals) > 0.8 and vals[-1] < 0.2:
                t1 = next(t for t, v in zip(ts, vals) if v < 0.5 and t > ts[vals.index(max(vals))])
                return res(PASS, f"scene{i}: intensity {max(vals):.1f}→{vals[-1]:.1f} (توقف≈{t1:.1f}s)")
        return res(FAIL, "منحنیِ intensityِ باران با رویداد هم‌خوان نیست")
    if exp == "thunder":
        for i, sd in enumerate(scenes):
            flashes = [e for e in sd["timeline"] if e["event"] == "flash"]
            thunders = [e for e in sd["audio"]["events"] if e["source"] == "thunder"]
            if flashes and thunders and "thunder" in facts.recipes:
                d = min(t["start"] - f["time"] for f in flashes for t in thunders if t["start"] >= f["time"] - 1e-6)
                if 0 <= d <= ap.SYNC_TOLERANCE_S:
                    return res(PASS, f"scene{i}: flash@{flashes[0]['time']}s ← thunder تأخیر {d:.2f}s")
                return res(FAIL, f"scene{i}: رعد و برق ناهماهنگ (delay={d})")
        return res(FAIL, "flash یا رعدِ هم‌گام نیست")
    if exp == "time_transition":
        for i, sd in enumerate(scenes):
            if any(e["event"] == "time_transition" for e in sd["timeline"]):
                return res(PASS, f"scene{i}: time_transition در timeline")
        froms = [_nodes(sd)["sky"]["visual_properties"]["from"] for sd in scenes]
        return res(PASS if len(set(froms)) > 1 else FAIL, f"sky.from per scene={froms}")
    if exp == "door_open":
        for i, sd in enumerate(scenes):
            d = [e for e in sd["timeline"] if e["event"] == "door_open"]
            s = [e for e in sd["audio"]["events"] if e["source"] == "door"]
            if d and s and abs(d[0]["time"] - s[0]["start"]) <= 0.6:
                return res(PASS, f"scene{i}: door@{d[0]['time']} صدا@{s[0]['start']}")
        return res(FAIL, "باز شدنِ در + صدایِ هم‌گام نیست")
    if exp == "character_move":
        for i, sd in enumerate(scenes):
            if any(e["event"] == "motion" for e in sd["timeline"]):
                return res(PASS, f"scene{i}: motion در timeline")
        return res(FAIL, "motion نیست")
    return res(FAIL, f"رویدادِ {exp} بررسی نمی‌شود")


def check_requirements(reqs: list[Requirement], html: str, intent: dict[str, Any] | None = None) -> list[ReqResult]:
    facts = inspect_html(html)
    if not facts.ok:
        return [ReqResult(r.id, r.kind, r.expected, FAIL, facts.error) for r in reqs]
    out: list[ReqResult] = []
    for r in reqs:
        try:
            out.append(_check(r, facts, intent or {}))
        except Exception as exc:  # noqa: BLE001 -- یک checkِ معیوب نباید کلِ اعتبارسنجی را بخواباند
            out.append(ReqResult(r.id, r.kind, r.expected, FAIL, f"خطایِ داخلیِ validator: {exc}"))
    return out


# ----------------------------------------------------------------------
#   کنترلِ پیوستگی (بخشِ ۲۵) و گزارشِ کیفیت (بخشِ ۲۱)
# ----------------------------------------------------------------------

def continuity_issues(project) -> list[str]:
    errs: list[str] = []
    sc = project.scenes
    if len(sc) < 2:
        return errs
    intent_tt = bool((project.intent or {}).get("time_transition"))
    base = sc[0]
    for i, s in enumerate(sc[1:], 1):
        if s.seed != base.seed:
            errs.append(f"scene{i}: seed با صحنهٔ اول فرق دارد")
        if s.environment != base.environment:
            errs.append(f"scene{i}: محیط تغییر کرده")
        if s.style != base.style:
            errs.append(f"scene{i}: سبک تغییر کرده")
        if s.weather != base.weather:
            errs.append(f"scene{i}: آب‌وهوا تغییر کرده")
        if not intent_tt and s.time_of_day != base.time_of_day:
            errs.append(f"scene{i}: زمانِ روز بدونِ انتقال تغییر کرده")
        a = next((o for o in base.objects if o.id == "subject"), None)
        b = next((o for o in s.objects if o.id == "subject"), None)
        transient = ("window_lit", "door_open", "facing")      # حالتِ لحظه‌ای؛ هویتِ شیء نیست
        ident = lambda o: {k: v for k, v in o.attrs.items() if k not in transient}  # noqa: E731
        if (a is None) != (b is None) or (a and b and (a.kind != b.kind or ident(a) != ident(b))):
            errs.append(f"scene{i}: هویتِ سوژه (kind/attrs) ناپیوسته است")
    return errs


def quality_report(results: list[ReqResult], project, html: str, struct_errors: list[str],
                   probe: dict[str, Any] | None = None, resource: dict[str, Any] | None = None) -> dict[str, Any]:
    """هر معیار یک نسبتِ قابلِ‌اندازه‌گیری + شاهد است (نه امتیازِ اتفاقی)."""
    def ratio(kinds):
        sel = [r for r in results if r.kind in kinds]
        if not sel:
            return None
        return {"pass": sum(r.status == PASS for r in sel), "total": len(sel),
                "ratio": round(sum(r.status == PASS for r in sel) / len(sel), 3),
                "evidence": [f"{r.id}:{r.status}" for r in sel]}
    total = len(results)
    p = sum(r.status == PASS for r in results)
    u = sum(r.status == UNSUPPORTED for r in results)
    f = sum(r.status == FAIL for r in results)
    audio_sync = [s for sc in project.scenes for s in ap.sync_report(sc)]
    nodes = sum(len(sc.graph.get("nodes", [])) for sc in project.scenes)
    decor = sum(len(next((n["visual_properties"]["decor"] for n in sc.graph.get("nodes", []) if n["id"] == "env"), [])) for sc in project.scenes)
    rep = {
        "semantic_coverage": {"pass": p, "fail": f, "unsupported": u, "total": total,
                              "ratio": round(p / total, 3) if total else None},
        "camera_coverage": ratio(("camera",)), "motion_coverage": ratio(("motion", "event")),
        "lighting_coverage": ratio(("lighting", "time_of_day", "weather")),
        "audio_coverage": ratio(("audio", "silence", "music", "narration")),
        "sync": {"checks": len(audio_sync), "ok": sum(s["ok"] for s in audio_sync),
                 "failed": [s["name"] for s in audio_sync if not s["ok"]]},
        "structure_errors": struct_errors,
        "continuity_errors": continuity_issues(project),
        "visual_complexity": {"graph_nodes": nodes, "decor_items": decor,
                              "layers_used": sorted({n["layer"] for sc in project.scenes for n in sc.graph.get("nodes", [])})},
        "html_bytes": len(html.encode("utf-8")),
        "resource": resource or {},
    }
    if probe is not None:
        frames = probe.get("frames", [])
        rep["render_probe"] = {"executed": True, "runtime_error": probe.get("runtime_error"), "errors": probe.get("errors", []),
                               "frames": len(frames), "draw_calls_max": max((sum(fr["ops"].values()) for fr in frames), default=0)}
    else:
        rep["render_probe"] = {"executed": False, "note": "Node در این محیط نیست؛ فقط اعتبارسنجیِ ایستا انجام شد."}
    rep["passed"] = (f == 0 and not struct_errors and not rep["continuity_errors"] and rep["sync"]["ok"] == rep["sync"]["checks"])
    return rep
