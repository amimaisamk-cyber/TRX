# -*- coding: utf-8 -*-
"""
Object Library (بخشِ ۸ سندِ ارتقا): جدا از preset؛ هر شیء استراتژیِ هندسه،
ابعاد، متریال و *تنوعِ بذردار* دارد. ``KNOWN_KINDS`` باید دقیقاً با
drawerهایِ ``draw_<kind>`` در renderer هم‌خوان باشد (تستِ قراردادی).
"""

from __future__ import annotations

import random
from typing import Any

KNOWN_KINDS = ("house", "character", "tree", "moon", "sun", "object")
# سوژه‌هایی که lexicon می‌شناسد ولی هنوز drawer ندارند -- صریحاً UNSUPPORTED گزارش می‌شوند.
UNSUPPORTED_KINDS = ("car", "bird", "ship", "flower", "dragon")

_SPECS: dict[str, dict[str, Any]] = {
    "house": {"geometry": "box+roof", "material": "wood_plaster", "motion": ["none"], "interaction": ["door", "window"]},
    "character": {"geometry": "articulated_2d", "material": "cloth", "motion": ["walk", "idle", "gesture"], "interaction": ["hand", "gaze"]},
    "tree": {"geometry": "trunk+crown", "material": "bark_leaf", "motion": ["sway"], "interaction": []},
    "moon": {"geometry": "disc", "material": "emissive", "motion": ["none"], "interaction": []},
    "sun": {"geometry": "disc", "material": "emissive", "motion": ["none"], "interaction": []},
    "object": {"geometry": "rounded_box", "material": "matte", "motion": ["none"], "interaction": []},
}


def make_object(kind: str, seed: int, *, old: bool = False, lit_window: bool = False,
                facing: int = 1) -> dict[str, Any]:
    """صفاتِ بذردارِ یک شیء؛ همان (kind, seed) همیشه همان نتیجه."""
    rng = random.Random(f"obj:{kind}:{seed}")
    spec = _SPECS.get(kind, _SPECS["object"])
    attrs: dict[str, Any] = {"geometry": spec["geometry"], "material": spec["material"],
                             "motion_capability": spec["motion"], "interaction_points": spec["interaction"]}
    if kind == "house":
        attrs.update(w=round(rng.uniform(0.17, 0.23), 3), h=round(rng.uniform(0.15, 0.21), 3),
                     roof=rng.choice(["gable", "hip", "flat"]), wear=round(rng.uniform(0.65, 0.95) if old else rng.uniform(0.05, 0.3), 2),
                     window_lit=lit_window, door_open=0.0, chimney=rng.random() < 0.6,
                     hue=round(rng.random(), 3), windows=rng.randint(2, 3))
    elif kind == "character":
        attrs.update(h=round(rng.uniform(0.26, 0.32), 3), hue=round(rng.random(), 3), hair=rng.choice(["short", "long", "cap"]),
                     facing=facing, gait=round(rng.uniform(0.9, 1.15), 2))
    elif kind == "tree":
        attrs.update(h=round(rng.uniform(0.25, 0.36), 3), crown=round(rng.uniform(0.6, 1.0), 2), lean=round(rng.uniform(-0.05, 0.05), 3),
                     hue=round(rng.random(), 3))
    elif kind in ("moon", "sun"):
        attrs.update(r=round(rng.uniform(0.045, 0.07), 3), glow=round(rng.uniform(0.5, 1.0), 2))
    else:
        attrs.update(w=round(rng.uniform(0.08, 0.14), 3), h=round(rng.uniform(0.08, 0.14), 3), hue=round(rng.random(), 3))
    return attrs
