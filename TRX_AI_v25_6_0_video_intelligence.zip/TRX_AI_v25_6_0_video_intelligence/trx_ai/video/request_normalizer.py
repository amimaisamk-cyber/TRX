# -*- coding: utf-8 -*-
"""
Request Normalizer -- بخشِ ۴ سندِ طراحی.

مسئولیت: گرفتنِ متنِ خامِ فارسیِ کاربر و تبدیلِ آن به یک دیکشنریِ ساختاریافته
(duration، style، environment، camera، audio، aspect_ratio، mood). این
مرحله عمداً کاملاً *قطعی* (deterministic, keyword/regex-based) است، نه
مدل‌محور -- دقیقاً همان فلسفه‌ای که بقیه‌ی nlu/ در این پروژه دارد (بدونِ
وابستگیِ اجباری به API/مدلِ سنگین، سازگار با Android/Pydroid).

از ``trx_ai.nlu.normalizer.normalize`` برایِ یکدست‌سازیِ حروفِ عربی/فارسی
و نیم‌فاصله استفاده می‌شود تا رفتارِ تشخیصِ کلیدواژه با بقیه‌یِ پروژه یکسان
بماند -- دوباره‌کاری/دو منبعِ حقیقتِ موازی ایجاد نمی‌شود.
"""

from __future__ import annotations

import re
from typing import Any

from ..nlu.normalizer import normalize as _nlu_normalize

DEFAULT_DURATION = 6.0
MIN_DURATION = 2.0
MAX_DURATION = 20.0  # سقفِ عمدیِ v1 برایِ محدودیتِ منابعِ Android/Pydroid؛ فراتر از آن به چندصحنه‌ای نیاز دارد (فازِ بعدی، بخشِ ۲۶).

_ENVIRONMENT_KEYWORDS: dict[str, tuple[str, ...]] = {
    "underwater": ("زیر آب", "زیرآب", "دریا", "اقیانوس", "غواصی"),
    "rain_on_window": ("بارون", "باران", "شیشه"),
    "forest": ("جنگل", "درخت", "مه‌آلود", "مه آلود"),
    "desert": ("کویر", "بیابان", "شن"),
    "city": ("شهر", "خیابان", "برج"),
    "sky": ("آسمان", "ابر", "پرواز"),
    "night_sky": ("شب", "ستاره", "کهکشان"),
    "room": ("اتاق", "خانه", "داخل"),
    "lab": ("آزمایشگاه", "لابراتوار"),
    "ancient_persia": ("ایران باستان", "پرسپولیس", "تخت جمشید", "هخامنشی"),
}

_MOOD_KEYWORDS: dict[str, tuple[str, ...]] = {
    "calm": ("آرام", "آروم", "ملایم"),
    "mysterious": ("رازآلود", "مرموز"),
    "epic": ("حماسی", "باشکوه"),
    "scientific": ("علمی",),
    "dreamy": ("رویایی", "رؤیایی", "خیال‌انگیز"),
    "dark": ("تاریک", "تیره", "شب"),
    "joyful": ("شاد", "پرانرژی"),
    "cinematic": ("سینمایی",),
}

_CAMERA_KEYWORDS: dict[str, tuple[str, ...]] = {
    "close_up": ("نمای نزدیک", "کلوزآپ", "نزدیک"),
    "wide": ("نمای باز", "نمای دور", "واید"),
    "slow_push_in": ("دوربین نزدیک شود", "زوم آرام", "پیش‌روی دوربین"),
    "pan": ("چرخش دوربین", "پن دوربین"),
}

_AUDIO_KEYWORDS: dict[str, tuple[str, ...]] = {
    "underwater": ("صدای خفه", "صدای زیر آب"),
    "rain": ("صدای باران", "صدای بارون"),
    "wind": ("صدای باد",),
    "music": ("موسیقی", "آهنگ پس‌زمینه"),
    "silent": ("بدون صدا", "بی‌صدا", "بی صدا"),
}

# اگر درخواست هیچ‌کدام از این‌ها را نداشته باشد، یعنی احتمالاً اصلاحِ صحنه‌ی
# قبلی است نه ساختِ صحنه‌ی جدید (استفاده در video_intent/runtime_manager).
_EDIT_HINT_WORDS = (
    "همون", "همین", "قبلی", "تر کن", "تر بشه", "کمتر", "بیشتر",
    "تاریک‌تر", "روشن‌تر", "سریع‌تر", "آهسته‌تر", "نزدیک‌تر", "دورتر",
)

_DURATION_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:ثانیه‌ای|ثانیه‌اس|ثانیه)")

_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")


def _extract_duration(norm_text: str) -> float:
    text = norm_text.translate(_FA_DIGITS)
    m = _DURATION_RE.search(text)
    if not m:
        return DEFAULT_DURATION
    try:
        value = float(m.group(1))
    except ValueError:
        return DEFAULT_DURATION
    return max(MIN_DURATION, min(MAX_DURATION, value))


def _match_first(norm_text: str, table: dict[str, tuple[str, ...]], default: str) -> str:
    for key, words in table.items():
        for w in words:
            if w in norm_text:
                return key
    return default


def normalize_text(raw_text: str) -> str:
    """دسترسیِ عمومی به یکدست‌سازیِ نویسه‌ای (برایِ patch_engine و غیره) --
    بدونِ نیاز به importِ مستقیمِ ``trx_ai.nlu.normalizer`` در هر ماژول."""
    return _nlu_normalize(raw_text)


_GEN_CUE_RE = re.compile(
    r"(ویدیو|ویدئو|انیمیشن|کلیپ|صحنه).{0,40}(بساز\b|درست\s*کن|تولید\s*کن|طراحی\s*کن)"
    r"|(بساز\b|درست\s*کن|تولید\s*کن|طراحی\s*کن).{0,40}(ویدیو|ویدئو|انیمیشن|کلیپ|صحنه)"
)


def has_generation_cue(raw_text: str) -> bool:
    """آیا جمله صراحتاً «ساختِ صحنه‌ی جدید» می‌خواهد (فعلِ ساخت + اسمِ ویدیو)؟
    این سیگنال بر «اصلاح» اولویت دارد: «یه ویدیو با نور کم بساز» ساخت است، نه
    اصلاحِ نور."""
    return bool(_GEN_CUE_RE.search(_nlu_normalize(raw_text)))


def looks_like_edit_request(raw_text: str) -> bool:
    """آیا این جمله بیشتر شبیهِ «اصلاحِ همان صحنه» است تا «ساختِ صحنه‌ی جدید»؟

    این فقط یک سیگنالِ کمکی است؛ تصمیمِ نهایی در runtime_manager با در نظر
    گرفتنِ وجودِ یک نشستِ فعال (SceneSession) گرفته می‌شود -- بخشِ ۲۰/۲۱.
    """
    norm = _nlu_normalize(raw_text)
    return any(w in norm for w in _EDIT_HINT_WORDS)


def normalize_request(raw_text: str) -> dict[str, Any]:
    """خروجیِ این تابع دقیقاً نمونه‌یِ بخشِ ۴ سندِ طراحی است."""
    norm = _nlu_normalize(raw_text)

    environment = _match_first(norm, _ENVIRONMENT_KEYWORDS, default="room")
    mood = _match_first(norm, _MOOD_KEYWORDS, default="calm")
    camera = _match_first(norm, _CAMERA_KEYWORDS, default="slow_push_in")
    audio = _match_first(norm, _AUDIO_KEYWORDS, default="ambient")
    duration = _extract_duration(norm)

    style = "cinematic"
    if "کارتونی" in norm:
        style = "cartoon"
    elif "مینیمال" in norm:
        style = "minimal"
    elif "واقع‌گرایانه" in norm or "واقعی" in norm:
        style = "realistic"

    return {
        "request_type": "create_video_scene",
        "duration": duration,
        "style": style,
        "environment": environment,
        "camera": camera,
        "audio": audio,
        "mood": mood,
        "aspect_ratio": "16:9",
        "is_edit_hint": looks_like_edit_request(raw_text),
        "raw_text": raw_text,
    }
