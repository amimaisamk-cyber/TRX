# -*- coding: utf-8 -*-
"""Explainability (بخشِ ۲۲): خلاصهٔ کوتاهِ فارسی برایِ کاربر؛ بدونِ ادعایِ اضافه."""

from __future__ import annotations

from . import semantic_validator as sv

_FA = {"subject": "سوژه", "environment": "محیط", "weather": "آب‌وهوا", "time_of_day": "زمان", "camera": "دوربین",
       "motion": "حرکت", "lighting": "نور", "audio": "صدا", "silence": "بی‌صدا", "music": "موسیقی", "narration": "روایت",
       "event": "رویداد", "style": "سبک", "duration": "مدت", "aspect_ratio": "نسبتِ تصویر", "multi_scene": "چندصحنه‌ای",
       "constraint": "محدودیت"}


def user_summary(build) -> str:
    ok = [r for r in build.results if r.status == sv.PASS]
    uns = [r for r in build.results if r.status == sv.UNSUPPORTED]
    bad = [r for r in build.results if r.status == sv.FAIL]
    lines = []
    if build.results:
        lines.append(f"✅ {len(ok)} از {len(build.results)} خواستهٔ شما در صحنه اعمال و بررسی شد.")
    if uns:
        lines.append("⚠️ پشتیبانی نشد: " + "؛ ".join(f"{_FA.get(r.kind, r.kind)} «{r.expected}» ({r.reason or r.evidence})" for r in uns[:3]))
    if bad:
        lines.append("❌ هنوز ناقص: " + "؛ ".join(f"{_FA.get(r.kind, r.kind)} «{r.expected}»" for r in bad[:3]))
    if build.repairs:
        lines.append(f"🔧 {len(build.repairs)} دورِ اصلاحِ خودکار انجام شد.")
    if build.degradations:
        lines.append("📉 برایِ سبک‌ماندن روی این دستگاه کاهشِ جزئیات: " + "، ".join(sorted({d.step for d in build.degradations})))
    a = build.project.global_audio()
    if any(e["type"] == "narration" for e in a):
        lines.append("ℹ️ روایت با TTSِ دستگاه پخش می‌شود و اگر فارسی نداشت، فقط زیرنویس نشان داده می‌شود.")
    if a:
        lines.append("ℹ️ صدا بعد از اولین لمس شروع می‌شود (سیاستِ مرورگر).")
    return "\n".join(lines)
