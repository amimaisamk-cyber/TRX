# -*- coding: utf-8 -*-
"""
Scene Specification — سندِ میانیِ موتورِ ویدیوی TRX (بخشِ ۶ سندِ طراحی:
``TRX_HTML_Video_Engine_Upgrade_Design``).

این فایل عمداً بدونِ هیچ منطقِ NLU/تولیدِ HTML است -- فقط *شکلِ داده* را
تعریف می‌کند، دقیقاً مثلِ فلسفه‌ی ``nlu/types.py`` در همین پروژه (یک زبانِ
مشترک بینِ normalizer، planners و generator). این جداسازی همان چیزی‌ست
که سند در بخشِ ۶ به آن اشاره می‌کند: «امکانِ بررسی، اصلاح، ذخیره و
بازتولیدِ صحنه بدونِ تولید دوبارهٔ کل کد».

هیچ importی از بقیه‌ی trx_ai اینجا نیست -- این ماژول باید بتواند کاملاً
مستقل (حتی در یک اسکریپتِ تستِ جدا) استفاده شود.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


# سه سطحِ کیفیت -- بخشِ ۱۹ سندِ طراحی (سیستمِ کیفیتِ تطبیقی).
QUALITY_LEVELS = ("low", "medium", "high")

# سقفِ تعدادِ ذرات به ازایِ هر سطحِ کیفیت -- محدودیتِ عملکردِ بخشِ ۱۳.
PARTICLE_CAPS = {"low": 18, "medium": 40, "high": 70}


@dataclass
class ObjectSpec:
    """یک شیءِ صحنه (سوژه، گروهِ ذرات، عنصرِ محیطی، ...) — بخشِ ۷."""

    id: str
    type: str
    position: str = "center"          # center | left | right | top | bottom | background
    motion: str = "static"            # static | slow_float | rise | sway | drift | pulse
    layers: tuple[str, ...] = ()
    scale: float = 1.0
    opacity: float = 1.0
    blur_px: float = 0.0
    depth: float = 0.5                # 0 (خیلی نزدیک) .. 1 (خیلی دور) — برایِ parallax
    velocity: float = 1.0             # ضریبِ نسبیِ سرعتِ حرکت
    delay_s: float = 0.0
    easing: str = "ease-in-out"
    loop: bool = True
    z_index: int = 1
    density: str = "medium"           # فقط برایِ particle_group معنادار است
    color: str = "#ffffff"
    # --- افزوده‌شده در v25.6.0 (Video Intelligence): همگی پیش‌فرض‌دارند تا
    # SceneSpecهایِ ذخیره‌شده‌یِ نسخه‌هایِ قبل بدونِ تغییر بارگذاری شوند. ---
    kind: str = ""                    # نوعِ معنایی/قابلِ رسم: house | tree_row | rain | character ...
    seed: int = 0                     # بذرِ تنوعِ قطعی (همان seed → همان شکل)
    pos_x: float = 0.5                # 0..1 از چپ به راست
    pos_y: float = 0.5                # 0..1 از بالا به پایین
    size: float = 1.0
    attrs: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CameraSpec:
    """دوربینِ مجازی — بخشِ ۱۲."""

    movement: str = "static"          # static | slow_push_in | slow_pull_out | pan_left | pan_right | handheld
    intensity: float = 0.15           # 0..1 -- دامنه‌ی نسبیِ حرکت
    zoom_start: float = 1.0
    zoom_end: float = 1.08
    pan_x: float = 0.0
    pan_y: float = 0.0
    shake: float = 0.0
    # --- v25.6.0: دوربینِ هدف‌محور ---
    move: str = ""                    # معناییِ سطح‌بالا: dolly_in | dolly_out | pan | orbit | follow | static ...
    target: str | None = None         # id شیءِ هدف (باید در صحنه وجود داشته باشد)
    easing: str = "linear"            # linear | ease_in_out | ease_out
    origin_x: float = 0.5             # نقطه‌یِ کانونیِ زوم (کسری از عرض)
    origin_y: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class LightingSpec:
    """نور و افکت‌های محیطی — بخشِ ۱۳."""

    type: str = "soft_ambient"        # soft_ambient | caustic_water_light | warm_glow | cold_moon | neon | harsh
    color_mood: str = "neutral"       # blue_cyan | warm_orange | dark | golden | neutral | green
    intensity: float = 0.5            # 0..1
    movement: str = "static"          # static | slow_wave | flicker
    fog: bool = False
    vignette: bool = True
    # --- v25.6.0 ---
    time_of_day: str = "day"          # dawn | day | sunset | dusk | night
    local_sources: list[str] = field(default_factory=list)   # مثلاً ["window_light"]
    flash_times: list[float] = field(default_factory=list)   # لحظه‌هایِ فلشِ رعدوبرق (ثانیه)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AudioSpec:
    """توضیح‌بند صدا — بخشِ ۱۴. (v1: فقط metadata؛ پخشِ واقعی در فازِ بعدی.)"""

    ambient: str | None = None        # underwater | rain | wind | none
    volume: float = 0.35
    loop: bool = True
    # صدایِ محیطیِ underwater/rain/wind واقعاً با Web Audio API سنتز و پخش
    # می‌شود (نویزِ فیلترشده، بدونِ فایل/دانلود) -- نه صرفاً یک برچسب.
    # چون autoplayِ صدا در مرورگر/WebView بدونِ تعاملِ کاربر مسدود است، صدا
    # با اولین لمسِ کاربر رویِ نمایشگر فعال می‌شود (بخشِ ۱۴ سندِ طراحی).
    # انواعِ دیگر (مثلاً «موسیقی») هنوز سنتز نمی‌شوند و فقط به‌صورتِ برچسب
    # نمایش داده می‌شوند تا ادعایِ کاذب ایجاد نشود.
    note: str = "underwater/rain/wind با Web Audio سنتز و پخش می‌شوند (بعد از اولین لمس)؛ سایرِ انواعِ صدا فعلاً فقط برچسب‌اند."
    # --- v25.6.0: خط‌لوله‌یِ واقعیِ صدا (Audio Plan → Synth → Timeline → Playback) ---
    explicit_silence: bool = False    # کاربر صریحاً «بدونِ صدا» خواسته
    events: list[dict[str, Any]] = field(default_factory=list)  # {id,type,start,duration,volume,loop,fade_in,fade_out,spatial_hint,trigger}
    music: str | None = None          # None | ambient_pad
    narration: dict[str, Any] | None = None   # {text,start,duration,lang}
    status: dict[str, str] = field(default_factory=dict)      # {نوع: available|procedural|unavailable:<دلیل>}

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class TimelineEvent:
    time: float
    event: str
    # --- v25.6.0: Timeline به‌عنوانِ منبعِ حقیقت (بخشِ ۱۷ سندِ ارتقا) ---
    id: str = ""
    target: str | None = None
    property: str | None = None
    value: Any = None
    to: Any = None
    easing: str = "linear"
    depends_on: list[str] = field(default_factory=list)
    duration: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        # سازگار با نسخه‌یِ قبل: رویدادهایِ ساده همان دو کلید را نگه می‌دارند.
        d: dict[str, Any] = {"time": self.time, "event": self.event}
        extra = {"id": self.id, "target": self.target, "property": self.property,
                 "value": self.value, "to": self.to, "duration": self.duration}
        d.update({k: v for k, v in extra.items() if v not in ("", None, 0.0)})
        if self.easing != "linear":
            d["easing"] = self.easing
        if self.depends_on:
            d["depends_on"] = list(self.depends_on)
        return d


@dataclass
class SceneSpec:
    """کلِ Scene Specification — بخشِ ۶ سندِ طراحی."""

    scene_id: str
    duration: float = 6.0
    width: int = 1280
    height: int = 720
    background_type: str = "gradient"     # gradient | underwater_gradient | night_sky | solid
    color_mood: str = "neutral"
    quality: str = "medium"               # low | medium | high
    objects: list[ObjectSpec] = field(default_factory=list)
    camera: CameraSpec = field(default_factory=CameraSpec)
    lighting: LightingSpec = field(default_factory=LightingSpec)
    audio: AudioSpec = field(default_factory=AudioSpec)
    timeline: list[TimelineEvent] = field(default_factory=list)
    mood: str = "calm"                    # calm | mysterious | epic | scientific | dreamy | dark | joyful | cinematic
    style: str = "cinematic"
    aspect_ratio: str = "16:9"
    source_text: str = ""
    # --- v25.6.0 ---
    seed: int = 0
    environment: str = ""
    time_of_day: str = "day"
    weather: str = "none"             # none | rain | snow | fog
    subject: str | None = None        # id شیءِ سوژه‌یِ اصلی
    sky: dict[str, Any] = field(default_factory=dict)         # پالتِ آسمان + انتقالِ زمانی
    labels: list[dict[str, Any]] = field(default_factory=list)  # آموزشی/تاریخی: {text,x,y,start,duration,role}
    graph: dict[str, Any] = field(default_factory=dict)       # Scene Graph سریال‌شده
    requirements: list[dict[str, Any]] = field(default_factory=list)
    style_profile: str = ""
    render_scale: dict[str, int] = field(default_factory=dict)  # {"w":..,"h":..} رزولوشنِ داخلیِ کَنوا

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "SceneSpec":
        objs = [ObjectSpec(**o) for o in data.get("objects", [])]
        cam = CameraSpec(**data.get("camera", {})) if isinstance(data.get("camera"), dict) else CameraSpec()
        light = LightingSpec(**data.get("lighting", {})) if isinstance(data.get("lighting"), dict) else LightingSpec()
        audio = AudioSpec(**data.get("audio", {})) if isinstance(data.get("audio"), dict) else AudioSpec()
        timeline = [TimelineEvent(**t) for t in data.get("timeline", [])]
        base = {k: v for k, v in data.items()
                if k not in ("objects", "camera", "lighting", "audio", "timeline")}
        return SceneSpec(objects=objs, camera=cam, lighting=light, audio=audio,
                          timeline=timeline, **base)

    def particle_cap(self) -> int:
        return PARTICLE_CAPS.get(self.quality, PARTICLE_CAPS["medium"])

    def validate(self) -> list[str]:
        """اعتبارسنجیِ سطحِ داده (نه سطحِ HTML -- آن کارِ validator.py است).

        فهرستی از پیام‌های خطا برمی‌گرداند؛ لیستِ خالی یعنی معتبر است.
        """
        errors: list[str] = []
        if not self.scene_id:
            errors.append("scene_id خالی است.")
        if self.duration <= 0 or self.duration > 60:
            errors.append(f"duration نامعتبر است ({self.duration}) -- باید بینِ ۰ و ۶۰ ثانیه باشد.")
        if self.quality not in QUALITY_LEVELS:
            errors.append(f"quality نامعتبر است ({self.quality}).")
        if len(self.objects) > 12:
            errors.append("تعدادِ اشیایِ صحنه بیش از حدِ مجاز (۱۲) است.")
        for obj in self.objects:
            if obj.type == "particle_group" and obj.density not in ("low", "medium", "high"):
                errors.append(f"density نامعتبر برایِ شیءِ {obj.id}: {obj.density}")
        return errors
