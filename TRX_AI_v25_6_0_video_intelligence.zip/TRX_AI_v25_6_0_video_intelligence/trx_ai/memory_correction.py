# -*- coding: utf-8 -*-
"""TRX AI Memory Correction Engine.

مدیریتِ اعتماد، تضاد و انقضایِ خاطرات.

نسخه‌ی قبلی این ماژول فقط یک اسکلتِ در-حافظه (in-memory) بود: هیچ‌جای
برنامه import نمی‌شد، هیچ داده‌ای پایدار نمی‌ماند و هیچ منطقِ واقعیِ
«تشخیصِ تضاد» نداشت (`resolve_conflict` فقط بینِ لیستی که خودِ کاربر از
قبل جمع کرده بود انتخاب می‌کرد). نتیجه‌ی عملی: در `MemoryEngine.save_fact`
هر حقیقتِ تازه فقط به یک لیست اضافه می‌شد و اگر بعداً حقیقتِ متناقضی گفته
می‌شد (مثلاً ابتدا «اسمم علی است» و بعداً «اسمم رضا است»)، هر دو برای
همیشه در کنارِ هم در پاسخ‌های آینده ظاهر می‌شدند — چون هیچ‌کس به موتورِ
تضاد وصل نبود.

این نسخه سه چیز را واقعاً اضافه می‌کند:
  ۱. پایداری: خاطرات مثلِ بقیه‌ی موتورهای پروژه (الگوهای مکالمه، دفترچه
     سلامت) در دیتابیسِ SQLiteِ همان کاربر (از طریق `db.get_profile` /
     `set_profile`) ذخیره می‌شوند، نه فقط در RAM.
  ۲. تشخیصِ تضاد: هر خاطره یک «کلیدِ موضوع» دارد (مثلاً از فرمتِ
     «کلید = مقدار» یا از چند کلمه‌ی معنادارِ اول جمله استخراج می‌شود).
     وقتی خاطره‌ی تازه‌ای با همان کلیدِ موضوع اما مقدارِ متفاوت ثبت شود،
     خاطره‌ی(های) قدیمی‌تر «منسوخ» (superseded) علامت می‌خورند — نه حذف،
     فقط دیگر به‌عنوانِ واقعیتِ فعلی برگردانده نمی‌شوند.
  ۳. بازیابیِ قابلِ‌اعتماد: `reliable()`/`current()` فقط خاطراتِ منسوخ‌نشده
     و با اعتمادِ کافی را برمی‌گرداند، پس لایه‌ی بالاتر (MemoryEngine) دیگر
     مجبور نیست بینِ نسخه‌های متناقض یکی را حدس بزند.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from time import time
from typing import List, Optional


@dataclass
class MemoryItem:
    value: str
    confidence: float = 0.5
    created: float = field(default_factory=time)
    category: str = "general"
    subject_key: str = ""
    superseded: bool = False


# واژه‌های عمومی/پرسشی که به‌تنهایی هرگز نباید یک خاطره را «مرتبط»
# قلمداد کنند -- وگرنه هر جمله‌ی جدید که تصادفاً یکی از این کلمات را
# دارد (مثلاً هر «کیست»/«چیست»ی) با هر خاطره‌ی قدیمی‌ای که همان کلمه
# را دارد قاطی می‌شود. این دقیقاً همان کانالِ دومی بود که باگِ
# «اکبر عبدی / کوروش کبیر» را تشدید می‌کرد: حتی پس از رفعِ
# resolve_pronoun، یک تطابقِ تک‌کلمه‌ایِ سست در `find()` می‌توانست
# هنوز خاطراتِ بی‌ربط را بالا بیاورد.
_GENERIC_STOPWORDS = frozenset({
    "کیست", "چیست", "کیه", "چیه", "چقدره", "چطوره", "چگونه", "بود",
    "است", "هست", "شود", "شد", "کند", "می", "که", "این", "آن", "اون",
    "یعنی", "برای", "درباره", "درباره‌ی", "توسط",
})


class MemoryCorrectionEngine:
    STORAGE_KEY = "memory:correction_v1"
    MAX_ITEMS = 500

    def __init__(self, db=None):
        # `db`: اختیاری تا کدِ قدیمی/تست‌هایی که بدونِ آرگومان
        # `MemoryCorrectionEngine()` می‌سازند هم کار کنند (در آن حالت
        # فقط در RAM کار می‌کند، مثلِ رفتارِ نسخه‌ی قبلی).
        self.db = db
        self.items: List[MemoryItem] = []
        self._load()

    # ------------------------------------------------------------
    #   پایداری
    # ------------------------------------------------------------
    def _load(self) -> None:
        if self.db is None:
            return
        raw = self.db.get_profile(self.STORAGE_KEY, "[]")
        try:
            data = json.loads(raw) if raw else []
        except (TypeError, ValueError):
            data = []
        self.items = [MemoryItem(**d) for d in data if isinstance(d, dict) and "value" in d]

    def _save(self) -> None:
        if self.db is None:
            return
        self.items = self.items[-self.MAX_ITEMS:]
        self.db.set_profile(self.STORAGE_KEY, json.dumps([asdict(x) for x in self.items], ensure_ascii=False))

    # ------------------------------------------------------------
    #   استخراجِ کلیدِ موضوع (برای تشخیصِ اینکه دو خاطره «درباره‌ی همان
    #   چیز» هستند یا نه، صرف‌نظر از اینکه دقیقاً هم‌متن باشند یا نه)
    # ------------------------------------------------------------
    @staticmethod
    def _subject_key(value: str) -> str:
        v = (value or "").strip()
        # فرمتِ صریحِ «کلید: مقدار» یا «کلید = مقدار» (خروجیِ self_learning)
        m = re.match(r'^([^:：=]{2,40})\s*[:：=]\s*.+$', v)
        if m:
            return m.group(1).strip().lower()
        # جمله‌های فارسیِ رایجِ «Xم فلان است/هست» (مثلاً «اسمم علی است»،
        # «پروژه‌ام ربات تلگرام است») — کلمه‌ی اول (خودِ موضوع، با پسوندِ
        # مالکیتِ «م») کلیدِ موضوع است؛ کلماتِ بعدی مقدار هستند و نباید
        # وارد کلید شوند، وگرنه دو مقدارِ متفاوت برای همان موضوع هرگز
        # هم‌کلید تشخیص داده نمی‌شوند.
        m = re.match(r'^([\wآ-ی]+(?:م|ام|‌ام))\s+.+?\s*(است|هست|میباشد|می‌باشد)?\s*$', v)
        if m:
            return m.group(1).strip().lower()
        # وگرنه، چند کلمه‌ی معنادارِ اول (بدونِ حروفِ اضافه‌ی خیلی کوتاه)
        words = [w for w in re.findall(r'[\wآ-ی]{2,}', v.lower())][:3]
        return " ".join(words)

    # ------------------------------------------------------------
    #   افزودن + تشخیصِ تضاد
    # ------------------------------------------------------------
    def add(self, value: str, confidence: float = 0.5, category: str = "general") -> MemoryItem:
        value = (value or "").strip()
        confidence = max(0.0, min(1.0, confidence))
        subject_key = self._subject_key(value)

        item = MemoryItem(value=value, confidence=confidence, category=category, subject_key=subject_key)

        if subject_key:
            for old in self.items:
                if old.superseded or old.subject_key != subject_key or old.category != category:
                    continue
                if old.value.strip().lower() == value.lower():
                    # همان حقیقت دوباره گفته شد: تقویتش کن، خاطره‌ی تازه‌ای نساز
                    old.confidence = min(1.0, old.confidence + 0.15)
                    old.created = time()
                    self._save()
                    return old
                # همان موضوع، مقدارِ متفاوت → تضاد؛ نسخه‌ی قدیمی منسوخ می‌شود
                # اما حذف نمی‌شود (برای مرورِ تاریخچه/دیباگ می‌ماند).
                old.superseded = True
                old.confidence = round(old.confidence * 0.3, 3)

        self.items.append(item)
        self._save()
        return item

    # ------------------------------------------------------------
    #   بازیابی
    # ------------------------------------------------------------
    def reliable(self, minimum: float = 0.7) -> List[MemoryItem]:
        """خاطراتِ منسوخ‌نشده با اعتمادِ حداقلِ `minimum`."""
        return [x for x in self.items if not x.superseded and x.confidence >= minimum]

    def current(self, category: Optional[str] = None) -> List[MemoryItem]:
        """همه‌ی خاطراتِ فعلاً معتبر (منسوخ‌نشده)، فارغ از سطحِ اعتماد؛
        برایِ نمایشِ «آخرین چیزی که کاربر گفته» حتی اگر اعتمادش پایین
        باشد (مثلاً یک حدسِ تازه که هنوز تقویت نشده)."""
        return [x for x in self.items if not x.superseded and (category is None or x.category == category)]

    def find(self, query: str, limit: int = 5) -> List[MemoryItem]:
        """جستجویِ لغویِ ساده در خاطراتِ معتبر — برایِ استفاده‌ی
        `MemoryEngine.get_relevant_memory` به‌جایِ پیمایشِ خامِ یک لیست.

        باگِ قبلی: هر کلمه‌ی ۲+ حرفی (حتی «بود»/«کیست»/«این») کافی بود
        تا یک خاطره «مرتبط» شمرده شود -- یعنی یک کلمه‌ی کاملاً عمومی
        در پرسشِ جدید می‌توانست خاطره‌ای کاملاً بی‌ربط از موضوعی دیگر
        را بالا بیاورد. اکنون واژه‌های عمومی/پرسشیِ فاقدِ محتوا
        (`_GENERIC_STOPWORDS`) فیلتر می‌شوند و حداقلِ طولِ کلمه به ۳
        افزایش یافته (هم‌راستا با فیلترِ مشابه در
        `MemoryEngine.get_relevant_memory`).
        """
        raw_words = re.findall(r'[\wآ-ی]{2,}', (query or "").lower())
        q_words = [w for w in raw_words if len(w) >= 3 and w not in _GENERIC_STOPWORDS]
        if not q_words:
            return []
        scored = []
        for item in self.current():
            v = item.value.lower()
            if any(w in v for w in q_words):
                scored.append(item)
        scored.sort(key=lambda x: x.confidence, reverse=True)
        return scored[:limit]

    def resolve_conflict(self, candidates: List[MemoryItem]) -> Optional[MemoryItem]:
        """انتخابِ خاطره با اعتمادِ بالاتر؛ در تضادها هیچ حدسی قطعی نمی‌شود."""
        if not candidates:
            return None
        return max(candidates, key=lambda x: x.confidence)

    def expire(self, seconds: int = 60 * 60 * 24 * 180) -> None:
        """خاطراتِ قدیمی و کم‌اعتماد را حذف می‌کند (خاطراتِ خیلی مطمئن،
        حتی قدیمی، نگه داشته می‌شوند)."""
        now = time()
        self.items = [x for x in self.items if now - x.created < seconds or x.confidence >= .9]
        self._save()
