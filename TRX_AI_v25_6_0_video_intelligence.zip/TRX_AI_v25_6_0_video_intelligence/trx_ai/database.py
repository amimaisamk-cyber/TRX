# -*- coding: utf-8 -*-
"""
مدیریت پایگاه‌داده‌ی SQLite: پروفایل کاربر، دانش آفلاین، تاریخچه و بازخورد.

بهبودها نسبت به نسخه‌ی اصلی:
    - خطاهای SQLite علاوه بر پیام فارسی روی صفحه، در فایل لاگ هم ثبت می‌شوند.
    - منطق و ساختار جداول دقیقاً بدون تغییر باقی مانده است.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime

from .logging_config import get_logger
from .tools import TextSimilarityEngine
from .text_crypto import _get_or_create_master_key, encrypt_at_rest, decrypt_at_rest

logger = get_logger(__name__)

class DatabaseManager:
    # نسخه‌ی فعلیِ ساختارِ جداول. قبلاً هیچ ردیابیِ نسخه‌ای برایِ schema
    # وجود نداشت (فقط `CREATE TABLE IF NOT EXISTS` پخش‌شده در چند جا)؛
    # یعنی اگر یک ستونِ جدید در آینده لازم می‌شد، هیچ نقطه‌ی مرکزی برایِ
    # تشخیصِ «این دیتابیس نسخه‌ی قدیمی است و باید ALTER شود» وجود نداشت.
    # `_ensure_schema_version` این را به یک الگویِ ساده و قابلِ‌توسعه
    # تبدیل می‌کند: نسخه‌ی ذخیره‌شده با `SCHEMA_VERSION` مقایسه می‌شود و
    # migrationهایِ آینده به‌ترتیب همان‌جا اضافه می‌شوند.
    SCHEMA_VERSION = 2

    def __init__(self, db_path="trx_ai_v20.db"):
        self.db_path = db_path
        self.context_queue = []
        # رمزنگاریِ در سطحِ ذخیره‌سازیِ جدولِ profile (دفترچه‌ی سلامت،
        # برنامه‌ی دارویی، حقایقِ شخصی و بقیه‌ی داده‌های کلید-مقدار).
        # اگر cryptography نصب نباشد یا ساختِ فایلِ کلید ناموفق باشد،
        # این مقدار None می‌ماند و دیتابیس دقیقاً مثلِ قبل (بدونِ
        # رمزنگاری) کار می‌کند — هیچ رفتاری نمی‌شکند.
        self._enc_key = _get_or_create_master_key(self.db_path)
        if self._enc_key is None:
            logger.warning(
                "رمزنگاریِ در سطحِ ذخیره‌سازی غیرفعال است (cryptography نصب "
                "نیست یا فایلِ کلید ساخته نشد)؛ داده‌هایِ حساس (سلامت، دارو، "
                "حقایقِ شخصی) به‌صورتِ خام ذخیره می‌شوند."
            )
        self._init_db()

    def _init_db(self):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("CREATE TABLE IF NOT EXISTS profile (key TEXT PRIMARY KEY, value TEXT)")
                c.execute("CREATE TABLE IF NOT EXISTS knowledge (keyword TEXT PRIMARY KEY, definition TEXT, confidence REAL)")
                c.execute("""CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT, user_query TEXT, response TEXT,
                    latency INTEGER, feedback TEXT, intent TEXT, confidence REAL
                )""")
                c.execute("CREATE TABLE IF NOT EXISTS user_data (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)")
                c.execute("CREATE TABLE IF NOT EXISTS feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, query TEXT, response TEXT, rating INTEGER, comment TEXT, created_at TEXT)")
                c.execute("""CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    due_at TEXT,
                    created_at TEXT,
                    done INTEGER DEFAULT 0,
                    reminded INTEGER DEFAULT 0,
                    project TEXT
                )""")
                c.execute("""CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    amount REAL NOT NULL,
                    category TEXT,
                    note TEXT,
                    created_at TEXT,
                    project TEXT
                )""")
                c.execute("CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT)")
                # حلقه‌ی بازخوردِ IntentEngine (trx_ai/nlu/feedback.py، گامِ ۵
                # روادمپِ ماژولارسازی): جفتِ (متن، نیتِ درست) که کاربر با
                # «نه منظورم این نبود» تصحیح کرده -- همین‌جا کنارِ بقیه‌ی
                # جدول‌ها، نه یک فایلِ جداگانه، تا با بکاپ/بازیابیِ فعلی
                # همخوان بماند.
                c.execute("""CREATE TABLE IF NOT EXISTS intent_corrections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    corrected_intent TEXT NOT NULL,
                    created_at TEXT
                )""")
                conn.commit()
                self._ensure_schema_version(conn)
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)

    def _ensure_schema_version(self, conn: sqlite3.Connection) -> None:
        """
        جدولِ `schema_meta` نسخه‌ی فعلیِ ساختارِ جداول را نگه می‌دارد.
        نصبِ تازه: نسخه‌ی فعلی ثبت می‌شود (هیچ migration ای لازم نیست،
        چون `CREATE TABLE IF NOT EXISTS` بالا از قبل ساختارِ کامل را
        ساخته). نصبِ قدیمی‌تر بدونِ این جدول: به‌جایِ فرضِ نسخه‌ی ۰،
        نسخه‌ی فعلی مستقیم ثبت می‌شود (هیچ ستونِ جدیدی هنوز اضافه نشده،
        پس چیزی برای migrate کردن نیست) -- وقتی اولین ستون/جدولِ واقعاً
        جدید اضافه شود، این تابع محلِ طبیعیِ افزودنِ منطقِ migration است:
        ``if current < 2: conn.execute("ALTER TABLE ... ADD COLUMN ...")``
        """
        c = conn.cursor()
        c.execute("SELECT value FROM schema_meta WHERE key = 'version'")
        row = c.fetchone()
        current = int(row[0]) if row else 0

        # --- محلِ افزودنِ migrationهایِ آینده ---
        # if current < 2:
        #     conn.execute("ALTER TABLE profile ADD COLUMN category TEXT")
        #     current = 2
        # -----------------------------------------

        if current != self.SCHEMA_VERSION:
            c.execute(
                "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('version', ?)",
                (str(self.SCHEMA_VERSION),),
            )
            conn.commit()

    def push_context(self, topic):
        if topic and topic not in self.context_queue:
            self.context_queue.append(topic)
            if len(self.context_queue) > 10:
                self.context_queue.pop(0)

    def get_last_topic(self):
        return self.context_queue[-1] if self.context_queue else None

    def get_profile(self, key, default=None):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT value FROM profile WHERE key = ?", (key,))
                row = c.fetchone()
                if not row:
                    return default
                return decrypt_at_rest(row[0], self._enc_key) if self._enc_key else row[0]
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return default

    def set_profile(self, key, value):
        if value is None:
            try:
                with sqlite3.connect(self.db_path, timeout=10) as conn:
                    c = conn.cursor()
                    c.execute("DELETE FROM profile WHERE key = ?", (key,))
                    conn.commit()
                return
            except sqlite3.Error as e:
                logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
                return

        stored_value = str(value)
        if self._enc_key:
            stored_value = encrypt_at_rest(stored_value, self._enc_key)

        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("INSERT OR REPLACE INTO profile (key, value) VALUES (?, ?)", (key, stored_value))
                conn.commit()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)

    def get_profile_by_prefix(self, prefix):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT key, value FROM profile WHERE key LIKE ?", (prefix + "%",))
                rows = c.fetchall()
                if self._enc_key:
                    return [(k, decrypt_at_rest(v, self._enc_key)) for k, v in rows]
                return rows
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return []

    def add_knowledge(self, keyword, definition, confidence=1.0):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT OR REPLACE INTO knowledge (keyword, definition, confidence) VALUES (?, ?, ?)",
                    (keyword.strip().lower(), definition.strip(), confidence)
                )
                conn.commit()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)

    def search_knowledge(self, query):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                clean_query = query.strip().lower()
                c.execute("SELECT keyword, definition FROM knowledge")
                rows = c.fetchall()
                best_match = None
                highest_sim = 0.0
                best_key = None
                for keyword, definition in rows:
                    if keyword == clean_query or keyword in clean_query:
                        self.push_context(keyword)
                        return definition
                    for word in clean_query.split():
                        sim = TextSimilarityEngine.calculate_similarity(keyword, word)
                        if sim > highest_sim:
                            highest_sim = sim
                            best_match = definition
                            best_key = keyword
                if highest_sim >= 0.75 and best_key:
                    self.push_context(best_key)
                    return best_match
                return None
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return None

    def add_history_record(self, timestamp, query, response, latency, feedback="None",
                           intent="", confidence=0.0):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT INTO history (timestamp, user_query, response, latency, feedback, intent, confidence) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (timestamp, query, str(response), latency, feedback, intent, confidence)
                )
                conn.commit()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)

    def add_feedback(self, query, response, rating, comment=""):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT INTO feedback (query, response, rating, comment, created_at) VALUES (?, ?, ?, ?, ?)",
                    (query, str(response), rating, comment, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                )
                conn.commit()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)

    def get_last_turn(self):
        """
        آخرین نوبتِ گفتگو را برمی‌گرداند: ``(user_query, intent)`` یا
        ``None``. برایِ حلقه‌ی بازخوردِ IntentEngine استفاده می‌شود --
        وقتی کاربر می‌گوید «نه منظورم این نبود»، باید بدانیم پیامِ قبلی
        چه بود تا از او بپرسیم منظورش چه نیتی بوده.
        """
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT user_query, intent FROM history ORDER BY id DESC LIMIT 1")
                return c.fetchone()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده در get_last_turn: %s", e)
            return None

    def record_intent_correction(self, text: str, corrected_intent: str) -> bool:
        """
        ذخیره‌یِ یک تصحیحِ کاربر برایِ یادگیریِ محلیِ IntentEngine
        (trx_ai/nlu/feedback.py، گامِ ۵ روادمپِ ماژولارسازی).
        """
        if not text or not corrected_intent:
            return False
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT INTO intent_corrections (text, corrected_intent, created_at) VALUES (?, ?, ?)",
                    (text.strip(), corrected_intent.strip(), datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                )
                conn.commit()
            return True
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)
            return False

    def get_intent_corrections(self, limit: int = 200):
        """لیستِ ``(text, corrected_intent)`` تصحیح‌هایِ قبلی، جدیدترین اول."""
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "SELECT text, corrected_intent FROM intent_corrections ORDER BY id DESC LIMIT ?",
                    (limit,),
                )
                return c.fetchall()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده در get_intent_corrections: %s", e)
            return []

    def get_stats(self):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT COUNT(*) FROM knowledge")
                k = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM history")
                h = c.fetchone()[0]
                c.execute("SELECT AVG(latency) FROM history")
                avg = c.fetchone()[0] or 0
                c.execute("SELECT AVG(confidence) FROM history WHERE confidence > 0")
                avg_conf = c.fetchone()[0] or 0
                return {"knowledge_size": k, "history_size": h,
                        "avg_latency": int(avg), "avg_confidence": f"{avg_conf*100:.0f}%"}
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return {"knowledge_size": 0, "history_size": 0, "avg_latency": 0, "avg_confidence": "0%"}

    def get_recent_history(self, limit=6):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "SELECT timestamp, user_query, response FROM history ORDER BY id DESC LIMIT ?",
                    (limit,)
                )
                return c.fetchall()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return []

    def clear_database(self):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("DELETE FROM knowledge")
                c.execute("DELETE FROM history")
                c.execute("DELETE FROM feedback")
                conn.commit()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)

    # ----------------------------------------------------------------
    #   کارها/یادآوری‌ها (Task/Reminder Manager)
    # ----------------------------------------------------------------
    def add_task(self, title: str, due_at: str = None, project: str = None) -> int:
        """یک کارِ جدید ثبت می‌کند و id آن را برمی‌گرداند (یا -1 در صورتِ خطا)."""
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT INTO tasks (title, due_at, created_at, done, reminded, project) "
                    "VALUES (?, ?, ?, 0, 0, ?)",
                    (title.strip(), due_at, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), project),
                )
                conn.commit()
                return c.lastrowid
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)
            return -1

    def list_tasks(self, include_done: bool = False, project: str = None):
        """فهرستِ کارها را برمی‌گرداند: [(id, title, due_at, done), ...]."""
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                query = "SELECT id, title, due_at, done FROM tasks WHERE 1=1"
                params = []
                if not include_done:
                    query += " AND done = 0"
                if project:
                    query += " AND (project = ? OR project IS NULL)"
                    params.append(project)
                query += " ORDER BY (due_at IS NULL), due_at, id"
                c.execute(query, params)
                return c.fetchall()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return []

    def complete_task(self, task_id: int) -> bool:
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("UPDATE tasks SET done = 1 WHERE id = ?", (task_id,))
                conn.commit()
                return c.rowcount > 0
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return False

    def delete_task(self, task_id: int) -> bool:
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
                conn.commit()
                return c.rowcount > 0
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return False

    def get_due_tasks(self, now_iso: str):
        """کارهایی که سررسیدشان رسیده، انجام نشده‌اند و هنوز یادآوری نشده‌اند."""
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "SELECT id, title, due_at FROM tasks "
                    "WHERE done = 0 AND reminded = 0 AND due_at IS NOT NULL AND due_at <= ? "
                    "ORDER BY due_at",
                    (now_iso,),
                )
                return c.fetchall()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return []

    def mark_task_reminded(self, task_id: int):
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("UPDATE tasks SET reminded = 1 WHERE id = ?", (task_id,))
                conn.commit()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)

    # ----------------------------------------------------------------
    #   خرج‌ها (Expense Tracker)
    # ----------------------------------------------------------------
    def add_expense(self, amount: float, category: str, note: str, project: str = None) -> int:
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "INSERT INTO expenses (amount, category, note, created_at, project) VALUES (?, ?, ?, ?, ?)",
                    (amount, category, note, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), project),
                )
                conn.commit()
                return c.lastrowid
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده: %s", e)
            return -1

    def list_expenses(self, project: str = None, since: str = None):
        """[(id, amount, category, note, created_at), ...]"""
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                query = "SELECT id, amount, category, note, created_at FROM expenses WHERE 1=1"
                params = []
                if project:
                    query += " AND (project = ? OR project IS NULL)"
                    params.append(project)
                if since:
                    query += " AND created_at >= ?"
                    params.append(since)
                query += " ORDER BY created_at DESC"
                c.execute(query, params)
                return c.fetchall()
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return []

    def delete_expense(self, expense_id: int) -> bool:
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
                conn.commit()
                return c.rowcount > 0
        except sqlite3.Error as e:
            logger.debug("خطای پایگاه‌داده نادیده گرفته شد (مقدار پیش‌فرض برگردانده می‌شود): %s", e)
            return False

    # فرمتِ فعلیِ Backup. وقتی ساختارِ export_all_data/import_all_data
    # به‌شکلی تغییر کند که با فایل‌هایِ پشتیبانِ قبلی سازگار نباشد، این
    # عدد باید زیاد شود و یک تابعِ migrate برایِ آن نسخه به
    # _migrate_backup_data اضافه شود (پایین‌تر) — نه اینکه فرمتِ قدیمی
    # را بی‌سروصدا نادیده بگیریم یا با یک KeyError/ساختارِ اشتباه
    # وسطِ import شکست بخوریم.
    # نسخه‌ی ۲: پیش از این (نسخه‌ی ۱)، export_all_data مقدارهایِ ستونِ
    # profile را همان‌طور که در دیتابیس نشسته بودند (یعنی، پس از اضافه‌شدنِ
    # رمزنگاریِ در سطحِ ذخیره‌سازی، به‌صورتِ رمزشده با کلیدِ محلیِ همان
    # دستگاه) صادر می‌کرد. چون خودِ فایلِ کلید هرگز داخلِ Backup قرار
    # نمی‌گیرد (و نباید بگیرد)، بازیابیِ آن Backup روی دستگاه/نصبِ دیگری
    # (دقیقاً کاربردِ اصلیِ این قابلیت) با کلیدِ متفاوتی مواجه می‌شد و
    # مقدارهایِ profile (دفترچه‌ی سلامت، دارو، حقایقِ شخصی) به‌جایِ خطایِ
    # روشن، بی‌سروصدا به‌صورتِ متنِ رمزشده‌ی خام بازمی‌گشتند. نسخه‌ی ۲
    # همیشه profile را پیش از export رمزگشایی (متنِ ساده) می‌کند و پیش از
    # import دوباره با کلیدِ دستگاهِ مقصد رمزنگاری می‌کند.
    CURRENT_BACKUP_VERSION = 2

    # ----------------------------------------------------------------
    #   پشتیبان‌گیری / بازیابیِ کاملِ داده (Backup & Restore)
    # ----------------------------------------------------------------
    def export_all_data(self) -> dict:
        """
        کلِ داده‌های کاربر (پروفایل، دانش، تاریخچه، کارها، خرج‌ها) را
        به یک دیکشنریِ قابلِ سریال‌سازیِ JSON برمی‌گرداند.
        """
        data = {
            "trx_backup_version": self.CURRENT_BACKUP_VERSION,
            "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute("SELECT key, value FROM profile")
                rows = c.fetchall()
                # همیشه به‌صورتِ متنِ ساده صادر می‌شود (نه رمزشده با کلیدِ
                # محلی) تا Backup روی هر دستگاهی قابلِ بازیابی باشد؛ نگاه
                # کنید به توضیحِ CURRENT_BACKUP_VERSION.
                if self._enc_key:
                    data["profile"] = [(k, decrypt_at_rest(v, self._enc_key)) for k, v in rows]
                else:
                    data["profile"] = rows
                c.execute("SELECT keyword, definition, confidence FROM knowledge")
                data["knowledge"] = c.fetchall()
                c.execute("SELECT key, value, updated_at FROM user_data")
                data["user_data"] = c.fetchall()
                c.execute("SELECT id, title, due_at, created_at, done, reminded, project FROM tasks")
                data["tasks"] = c.fetchall()
                c.execute("SELECT id, amount, category, note, created_at, project FROM expenses")
                data["expenses"] = c.fetchall()
                c.execute("SELECT timestamp, user_query, response, latency, intent, confidence FROM history ORDER BY id DESC LIMIT 500")
                data["history"] = c.fetchall()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده هنگامِ export: %s", e)
        return data

    def _migrate_backup_data(self, data: dict) -> dict:
        """
        اگر فایلِ پشتیبان از نسخه‌ی قدیمی‌تری از فرمت باشد، آن را به
        فرمتِ فعلی migrate می‌کند؛ اگر از نسخه‌ای جدیدتر از چیزی باشد که
        این کد می‌فهمد (مثلاً پشتیبانی که با یک TRX AI جدیدتر گرفته شده
        و بعداً روی یک نصبِ قدیمی‌تر بازیابی می‌شود)، به‌جایِ
        نیم‌وارد‌کردنِ بی‌سروصدایِ یک ساختارِ ناسازگار، ValueError واضح
        می‌دهد.

        نسخه‌ی ۱ فقط کلیدِ قدیمیِ بدونِ‌پیشوندِ «version» (که در اولین
        نسخه‌های این پروژه استفاده می‌شد) را با کلیدِ رسمیِ جدید یکی
        می‌کند. نسخه‌ی ۲: در نسخه‌ی ۱، مقدارهایِ profile با کلیدِ محلیِ
        همان دستگاه رمزشده صادر می‌شدند؛ اگر کلیدِ رمزنگاریِ فعلیِ همین
        نصب دردسترس باشد، تلاش می‌کنیم آن مقدارها را همین‌جا رمزگشایی
        کنیم (فقط وقتی که Backup روی همان دستگاهی بازیابی شود که گرفته
        شده -- کلید یکسان است). اگر رمزگشایی ناموفق بود (کلیدِ متفاوت،
        یعنی بازیابی روی دستگاه/نصبِ دیگر)، مقدار به‌همان‌صورتِ رمزشده
        باقی می‌ماند؛ در این حالت import_all_data به‌جایِ رمزنگاریِ دوباره‌ی
        آن، آن را خام درج می‌کند (چون از قبل رمزشده بوده) و این محدودیت
        به‌صراحت لاگ می‌شود -- نه اینکه بی‌سروصدا داده‌ی غیرقابل‌بازیابی
        تولید شود.
        """
        version = data.get("trx_backup_version", data.get("version", 1))
        if not isinstance(version, int):
            version = 1
        if version > self.CURRENT_BACKUP_VERSION:
            raise ValueError(
                f"این فایلِ پشتیبان با نسخه‌ی {version} از فرمتِ Backup ساخته شده، "
                f"ولی این نسخه از TRX AI فقط تا نسخه‌ی {self.CURRENT_BACKUP_VERSION} را می‌فهمد. "
                f"لطفاً TRX AI را به‌روزرسانی کنید."
            )
        if version < 2 and self._enc_key and data.get("profile"):
            migrated_profile = []
            any_failed = False
            for key, value in data["profile"]:
                decrypted = decrypt_at_rest(value, self._enc_key)
                if decrypted == value and value.startswith("enc:"):
                    any_failed = True
                migrated_profile.append((key, decrypted))
            data["profile"] = migrated_profile
            data["_profile_may_be_stale_ciphertext"] = any_failed
            if any_failed:
                logger.warning(
                    "برخی مقدارهایِ profile در این Backupِ قدیمی (نسخه‌ی %s) با "
                    "کلیدِ رمزنگاریِ این دستگاه قابلِ‌رمزگشایی نبودند -- احتمالاً "
                    "این Backup روی دستگاه/نصبِ دیگری گرفته شده. آن مقدارها "
                    "به‌صورتِ رمزشده (غیرِقابلِ‌استفاده) وارد می‌شوند.",
                    version,
                )
        data["trx_backup_version"] = self.CURRENT_BACKUP_VERSION
        return data

    def import_all_data(self, data: dict, overwrite: bool = False) -> int:
        """
        داده‌های خروجیِ export_all_data را بازمی‌گرداند. اگر
        overwrite=False (پیش‌فرض)، فقط ردیف‌های جدید اضافه می‌شوند
        (بدونِ پاک‌کردنِ چیزی)؛ برای profile/user_data/knowledge همیشه
        (صرف‌نظر از overwrite) از INSERT OR REPLACE استفاده می‌شود، چون
        کلیدِ یکتا دارند. اگر overwrite=True باشد، جدول‌هایی که کلیدِ
        یکتا ندارند (tasks/expenses/history) پیش از درج، کاملاً خالی
        می‌شوند تا داده‌های وارد‌شده واقعاً جایگزینِ داده‌های قبلی شوند
        نه اضافه‌شونده به آن‌ها.

        قبل از هر کاری، نسخه‌ی فرمتِ Backup بررسی/migrate می‌شود (به
        _migrate_backup_data نگاه کنید)؛ اگر فایل از نسخه‌ای جدیدتر از
        چیزی باشد که این کد می‌فهمد، هیچ ردیفی import نمی‌شود و ۰
        برمی‌گردد (پیامِ خطا هم لاگ/چاپ می‌شود) — نه یک نیم‌وارد‌کردنِ
        بی‌سروصدا و بالقوه ناقص/اشتباه.

        تعدادِ ردیف‌های وارد‌شده را برمی‌گرداند.
        """
        try:
            data = self._migrate_backup_data(data)
        except ValueError as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.error("نسخه‌ی فرمتِ Backup پشتیبانی نمی‌شود: %s", e)
            return 0

        imported = 0
        try:
            with sqlite3.connect(self.db_path, timeout=10) as conn:
                c = conn.cursor()
                if overwrite:
                    # این سه جدول کلیدِ یکتا ندارند (بر خلافِ
                    # profile/knowledge/user_data)، پس تنها راهِ واقعیِ
                    # «جایگزینی به‌جایِ اضافه‌کردن» این است که قبل از
                    # درجِ داده‌های جدید، کاملاً خالی شوند.
                    c.execute("DELETE FROM tasks")
                    c.execute("DELETE FROM expenses")
                    c.execute("DELETE FROM history")
                stale_ciphertext = data.pop("_profile_may_be_stale_ciphertext", False)
                for key, value in data.get("profile", []):
                    stored_value = value
                    # مقدارهایِ عادی (متنِ ساده -- چه از یک Backupِ نسخه‌ی ۲
                    # به‌بعد، چه از نسخه‌ی ۱ که با موفقیت رمزگشایی شدند در
                    # _migrate_backup_data) با کلیدِ همین دستگاه رمزنگاری
                    # می‌شوند، دقیقاً مثلِ set_profile. مقدارهایی که رمزگشاییِ
                    # آن‌ها ناموفق بود (stale ciphertext از دستگاهِ دیگر) دوباره
                    # رمزنگاری نمی‌شوند -- چون خودشان از قبل رمزشده‌اند و
                    # رمزنگاریِ دوباره فقط داده‌ی غیرِقابلِ‌بازیابی دیگری تولید
                    # می‌کرد.
                    if self._enc_key and not (stale_ciphertext and str(value).startswith("enc:")):
                        stored_value = encrypt_at_rest(str(value), self._enc_key)
                    c.execute("INSERT OR REPLACE INTO profile (key, value) VALUES (?, ?)", (key, stored_value))
                    imported += 1
                for keyword, definition, confidence in data.get("knowledge", []):
                    c.execute(
                        "INSERT OR REPLACE INTO knowledge (keyword, definition, confidence) VALUES (?, ?, ?)",
                        (keyword, definition, confidence),
                    )
                    imported += 1
                for key, value, updated_at in data.get("user_data", []):
                    c.execute(
                        "INSERT OR REPLACE INTO user_data (key, value, updated_at) VALUES (?, ?, ?)",
                        (key, value, updated_at),
                    )
                    imported += 1
                for row in data.get("tasks", []):
                    _id, title, due_at, created_at, done, reminded, project = row
                    c.execute(
                        "INSERT INTO tasks (title, due_at, created_at, done, reminded, project) VALUES (?, ?, ?, ?, ?, ?)",
                        (title, due_at, created_at, done, reminded, project),
                    )
                    imported += 1
                for row in data.get("expenses", []):
                    _id, amount, category, note, created_at, project = row
                    c.execute(
                        "INSERT INTO expenses (amount, category, note, created_at, project) VALUES (?, ?, ?, ?, ?)",
                        (amount, category, note, created_at, project),
                    )
                    imported += 1
                # باگِ قبلی: history در export_all_data خروجی گرفته
                # می‌شد، ولی اینجا هیچ‌وقت وارد نمی‌شد — یعنی Restore
                # همیشه تاریخچه را گم می‌کرد، حتی وقتی Export آن را
                # داشت.
                for row in data.get("history", []):
                    timestamp, user_query, response, latency, intent, confidence = row
                    c.execute(
                        "INSERT INTO history (timestamp, user_query, response, latency, intent, confidence) "
                        "VALUES (?, ?, ?, ?, ?, ?)",
                        (timestamp, user_query, response, latency, intent, confidence),
                    )
                    imported += 1
                conn.commit()
        except sqlite3.Error as e:
            print(f"🛡️ [Database Guard]: {e}")
            logger.exception("خطای پایگاه‌داده هنگامِ import: %s", e)
        return imported
