# -*- coding: utf-8 -*-
"""
Neural Adapter فاز ۳ (سندِ P3.0، بخشِ ۶ -- ``neural_adapter.py``:
«تنها نقطه تماس با trx_model / بارگذاری مدل / tokenizer / generate-
inference / مدیریتِ خطا / عدمِ وابستگیِ مستقیم به Core»).

**مرحله‌ی ۲ از ۱۰ (بخشِ ۱۹ سند):**

    مرحله ۲:
    - اتصال Neural Adapter به trx_model
    - فقط inference آزمایشی
    - تست load/unload
    - تست سازگاری tokenizer/model

یعنی دقیقاً همین محدوده -- نه یک قدم جلوتر:

- بدونِ ``inference_service.py`` (مرحله‌ی ۳) -- این ماژول خودش هیچ
  timeout/resource-guard/fallbackی ندارد؛ آن مسئولیتِ لایه‌ی بعدی است.
- بدونِ ``task_heads.py`` -- این ماژول topic/emotion/relation پیش‌بینی
  نمی‌کند، فقط یک تولیدِ متنِ آزمایشیِ خام (``trial_generate``) دارد که
  صرفاً اثبات می‌کند «مدل بارگذاری شد و inference واقعی اجرا می‌شود»،
  دقیقاً همان‌طور که سندِ خودِ ``NATIVE_MODEL_NOTES.md``/``model.py``
  صادقانه گفته‌اند: وزن‌ها -- مگر checkpoint داده شود -- آموزش‌ندیده‌اند
  و خروجیِ زبانی بی‌معنی خواهد بود؛ هدفِ این مرحله اثباتِ اتصال است، نه
  کیفیتِ زبانی.
- بدونِ importِ ``trx_ai.core_engine`` / ``trx_ai.intelligence`` --
  اتصالِ یک‌طرفه‌ی صفر مثلِ مرحله‌ی ۱ حفظ شده.

اصلِ غیرقابلِ‌مذاکره‌ی ۴ سند («خرابیِ مدل نباید مکالمه را متوقف کند»)
اینجا این‌طور اعمال شده: تنها مسیرهایی که ``load()`` را صدا می‌زنند
ممکن است شکست بخورند -- و آن شکست همیشه به‌شکلِ یک ``LoadResult(ok=False, ...)``
برمی‌گردد، نه یک exception ناگهانی. اما ``trial_generate`` روی آداپتورِ
بارگذاری‌نشده عمداً ``NeuralAdapterNotLoadedError`` می‌دهد (خطایِ برنامه‌نویس،
نه خطایِ زمانِ‌اجرا)؛ لایه‌ی محافظ در برابرِ خطاهایِ زمانِ‌اجرا (timeout،
exception حینِ inference، RAM) مسئولیتِ ``inference_service.py``
(مرحله‌ی ۳) است -- طبقِ همان جداییِ مسئولیت که خودِ سند در بخشِ ۶ برایِ
دو فایل جدا در نظر گرفته.
"""

from __future__ import annotations

import gc
import hashlib
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import numpy as np

from ..trx_model.interfaces import ModelInterface
from ..trx_model.model import TRXModelConfig, TRXNativeModel
from ..trx_model.model_adapter import DEFAULT_TOKENIZER_PATH, TRXNativeModelAdapter
from ..trx_model.tokenizer import ByteLevelBPETokenizer
from ..trx_model.training.autograd_cache import build_param_map
from .config import Phase3Config, get_config

__all__ = [
    "AdapterState",
    "LoadResult",
    "NeuralAdapterNotLoadedError",
    "NeuralAdapter",
]


class NeuralAdapterNotLoadedError(RuntimeError):
    """صدا زدنِ ``trial_generate`` روی آداپتوری که بارگذاری نشده."""


class AdapterState(str, Enum):
    """وضعیتِ چرخه‌ی حیاتِ آداپتور -- طبقِ آزمونِ صریحِ سند «تستِ load/unload»."""

    UNLOADED = "unloaded"
    LOADED = "loaded"
    ERROR = "error"


@dataclass
class LoadResult:
    """خروجیِ ``NeuralAdapter.load`` -- هیچ‌وقت exception خام نیست."""

    ok: bool
    state: AdapterState
    error: Optional[str] = None
    model_version: Optional[str] = None
    tokenizer_version: Optional[str] = None
    param_count: int = 0
    checkpoint_used: Optional[str] = None
    duration_ms: float = 0.0


def _tokenizer_version(tokenizer: ByteLevelBPETokenizer) -> str:
    """
    شناسه‌ی کوتاهِ سازگاریِ توکنایزر: نه یک ``versioning.py`` کامل
    (آن -- طبقِ سند بخشِ ۶ -- شاملِ سازگاریِ checkpoint هم می‌شود و
    خارج از محدوده‌ی صریحِ مرحله‌ی ۲ است)، فقط عددی که اگر merges یا
    vocab_size عوض شود، عوض می‌شود -- برایِ «تستِ سازگاریِ
    tokenizer/model» و ثبت در تله‌متری کافی است.
    """
    h = hashlib.sha256()
    for a, b in tokenizer.merges:
        h.update(f"{a},{b};".encode("utf-8"))
    return f"bpe-v{tokenizer.vocab_size}-m{len(tokenizer.merges)}-{h.hexdigest()[:8]}"


def _model_version(config: TRXModelConfig) -> str:
    return (
        f"trx-native-d{config.d_model}-l{config.n_layers}"
        f"-h{config.n_heads}-ff{config.d_ff}-seed{config.seed}"
    )


def _load_weights_only(path: str, model: TRXNativeModel, tokenizer: ByteLevelBPETokenizer) -> None:
    """
    بارگذاریِ فقط-وزن (بدونِ optimizer state) برایِ inference.

    ``trx_ai.trx_model.training.checkpoint.load_checkpoint`` عمداً یک
    ``AdamW`` اجباری می‌خواهد چون برایِ Resume آموزش طراحی شده. اینجا
    inference-only هستیم -- ساختنِ یک optimizer جعلی فقط برایِ صدا زدنِ
    آن تابع، یک وابستگیِ ساختگی بود؛ به‌جایش همان قراردادِ فایلِ
    ``<path>.weights.npz`` + ``<path>.meta.json`` را می‌خوانیم، فقط
    بخشِ ``param::*`` را اعمال می‌کنیم، و همان بررسیِ صریحِ عدم‌تطابقِ
    ``vocab_size`` را (بدونِ سکوت روی ناهم‌خوانی) حفظ می‌کنیم.
    """
    import json
    from pathlib import Path

    meta_file = Path(path + ".meta.json")
    weights_file = Path(path + ".weights.npz")
    if not meta_file.exists() or not weights_file.exists():
        raise FileNotFoundError(f"فایل‌هایِ checkpoint در مسیرِ '{path}' پیدا نشدند.")

    with open(meta_file, "r", encoding="utf-8") as f:
        meta = json.load(f)

    ckpt_vocab = meta.get("tokenizer_vocab_size")
    if ckpt_vocab is not None and ckpt_vocab != tokenizer.vocab_size:
        raise ValueError(
            "vocab_size توکنایزرِ فعلی با checkpoint یکسان نیست -- "
            f"checkpoint={ckpt_vocab} tokenizer={tokenizer.vocab_size}."
        )

    data = np.load(str(weights_file))
    params = build_param_map(model)
    missing = [k for k in params if f"param::{k}" not in data]
    if missing:
        raise ValueError(f"وزن‌هایِ ناقص در checkpoint: {missing}")
    for key in params:
        params[key][...] = data[f"param::{key}"]


class NeuralAdapter:
    """
    تنها نقطه‌ی تماسِ فاز ۳ با ``trx_ai/trx_model``. بدونِ importِ
    مستقیم توسطِ ``core.py``/``intelligence.py`` (طبقِ سندِ بخشِ ۱۴:
    ممنوعیتِ ``core.py -> model.generate()``).
    """

    def __init__(self, config: Optional[Phase3Config] = None) -> None:
        self.config = config or get_config()
        self._state: AdapterState = AdapterState.UNLOADED
        self._adapter: Optional[ModelInterface] = None
        self._tokenizer: Optional[ByteLevelBPETokenizer] = None
        self._model: Optional[TRXNativeModel] = None
        self._model_version: Optional[str] = None
        self._tokenizer_version: Optional[str] = None
        self._checkpoint_used: Optional[str] = None
        self._last_error: Optional[str] = None

    # ------------------------------------------------------------ state --
    @property
    def state(self) -> AdapterState:
        return self._state

    @property
    def is_loaded(self) -> bool:
        return self._state is AdapterState.LOADED

    @property
    def model_version(self) -> Optional[str]:
        return self._model_version

    @property
    def tokenizer_version(self) -> Optional[str]:
        return self._tokenizer_version

    @property
    def last_error(self) -> Optional[str]:
        return self._last_error

    # ------------------------------------------------------- load/unload --
    def load(self, checkpoint_path: Optional[str] = None) -> LoadResult:
        """
        بارگذاریِ tokenizer + مدل. اگر ``checkpoint_path`` داده نشود،
        از متغیرِ محیطیِ ``TRX_PHASE3_CHECKPOINT_PATH`` خوانده می‌شود؛
        اگر آن هم نباشد، مدل با وزن‌هایِ تصادفیِ ``seed``دار ساخته
        می‌شود (صادقانه در ``model_version`` مشخص است، نه یک checkpointِ
        آموزش‌دیده).

        هرگز exception به بیرون نشت نمی‌کند -- همیشه ``LoadResult``.
        """
        started = time.monotonic()
        checkpoint_path = checkpoint_path or os.environ.get("TRX_PHASE3_CHECKPOINT_PATH")

        try:
            if not os.path.exists(DEFAULT_TOKENIZER_PATH):
                raise FileNotFoundError(
                    f"توکنایزرِ پیش‌فرض یافت نشد: {DEFAULT_TOKENIZER_PATH}\n"
                    "ابتدا اجرا کنید: python scripts/train_native_tokenizer.py"
                )
            tokenizer = ByteLevelBPETokenizer.load(DEFAULT_TOKENIZER_PATH)

            model_config = TRXModelConfig(vocab_size=tokenizer.vocab_size)
            model = TRXNativeModel(model_config)

            if checkpoint_path:
                _load_weights_only(checkpoint_path, model, tokenizer)

            adapter = TRXNativeModelAdapter(tokenizer, model=model, config=model_config)

            self._tokenizer = tokenizer
            self._model = model
            self._adapter = adapter
            self._model_version = _model_version(model_config)
            self._tokenizer_version = _tokenizer_version(tokenizer)
            self._checkpoint_used = checkpoint_path
            self._state = AdapterState.LOADED
            self._last_error = None

            return LoadResult(
                ok=True,
                state=self._state,
                model_version=self._model_version,
                tokenizer_version=self._tokenizer_version,
                param_count=sum(p.size for p in build_param_map(model).values()),
                checkpoint_used=checkpoint_path,
                duration_ms=(time.monotonic() - started) * 1000.0,
            )
        except Exception as exc:  # noqa: BLE001 -- بارگذاری هرگز نباید کرش کند
            self._state = AdapterState.ERROR
            self._last_error = f"{type(exc).__name__}: {exc}"
            self._adapter = None
            self._tokenizer = None
            self._model = None
            self._model_version = None
            self._tokenizer_version = None
            return LoadResult(
                ok=False,
                state=self._state,
                error=self._last_error,
                duration_ms=(time.monotonic() - started) * 1000.0,
            )

    def unload(self) -> None:
        """آزادسازیِ صریحِ منابع -- بخشِ آزمونِ «تستِ load/unload» سند."""
        self._adapter = None
        self._model = None
        self._tokenizer = None
        self._model_version = None
        self._tokenizer_version = None
        self._checkpoint_used = None
        self._state = AdapterState.UNLOADED
        gc.collect()

    # ------------------------------------------------------------ infer --
    def trial_generate(self, text: str, max_new_tokens: int = 16) -> str:
        """
        Inference آزمایشیِ خام (بخشِ ۶ سند: «فقط inference آزمایشی»).

        این متد **هیچ** ``NeuralAdvice`` نمی‌سازد -- فقط ``adapter.generate``
        را صدا می‌زند تا اثبات کند مسیرِ encode -> forward -> decode واقعاً
        کار می‌کند. تبدیلِ این خروجی به وظایفِ ساختاریافته
        (topic/emotion/relation/...) کارِ ``task_heads.py`` است که طبقِ
        برنامه‌ی مرحله‌ای هنوز ساخته نشده.
        """
        if not self.is_loaded or self._adapter is None:
            raise NeuralAdapterNotLoadedError(
                "NeuralAdapter بارگذاری نشده -- ابتدا load() را صدا بزنید."
            )
        return self._adapter.generate(text, max_new_tokens=max_new_tokens)

    # -------------------------------------------------------- diagnostics --
    def check_compatibility(self) -> "CompatibilityCheck":
        """
        تستِ صریحِ «سازگاریِ tokenizer/model» سند: آیا ``vocab_size``ی
        که مدل با آن ساخته شده دقیقاً همان چیزی است که توکنایزرِ
        بارگذاری‌شده گزارش می‌دهد؟ چون هر دو در ``load()`` از یک
        ``tokenizer.vocab_size`` مشترک ساخته می‌شوند، در مسیرِ عادی این
        همیشه سازگار است -- این متد برایِ اثباتِ صریح (تست) و برایِ
        حالتِ آینده‌ی «checkpoint از یک توکنایزرِ دیگر» وجود دارد.
        """
        if not self.is_loaded or self._model is None or self._tokenizer is None:
            return CompatibilityCheck(compatible=False, reason="آداپتور بارگذاری نشده.")
        model_vocab = self._model.config.vocab_size
        tok_vocab = self._tokenizer.vocab_size
        if model_vocab != tok_vocab:
            return CompatibilityCheck(
                compatible=False,
                reason=f"vocab_size ناسازگار: مدل={model_vocab} توکنایزر={tok_vocab}",
            )
        return CompatibilityCheck(compatible=True, reason=None)


@dataclass
class CompatibilityCheck:
    compatible: bool
    reason: Optional[str] = None
