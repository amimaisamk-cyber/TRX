# -*- coding: utf-8 -*-
"""
Phase 3 -- Stage 4: Shadow Mode.

Responsibilities:
- read the existing Conversation Intelligence state without mutating it;
- build the exact Phase-3 feature contract from that state;
- run Native Neural inference through the already-tested Stage-3 service;
- record symbolic and neural observations side-by-side;
- append an evaluation example without changing the live answer or route.

Important limitation: Stage 4 does NOT invent structured neural predictions.
The current Native Model still returns raw generated text. Therefore
structured agreement scores are intentionally ``None`` until task heads are
implemented in a later stage.
"""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import asdict, dataclass
from typing import Any, Sequence

from .config import Phase3Config, Phase3Mode, get_config
from .evaluation_dataset import EvaluationDatasetWriter
from .controlled_fusion import ControlledFusionRunner
from .feature_builder import build_features
from .inference_service import InferenceOutcome, Phase3InferenceService

__all__ = ["ShadowComparisonRecord", "Phase3ShadowRunner", "get_shadow_runner", "reset_shadow_runner"]


@dataclass
class ShadowComparisonRecord:
    record_id: str
    timestamp: float
    conversation_id: str
    normalized_text: str
    symbolic: dict[str, Any]
    neural: dict[str, Any]
    comparison: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class Phase3ShadowRunner:
    """Read-only bridge from live Conversation Intelligence to Phase 3."""

    def __init__(
        self,
        config: Phase3Config | None = None,
        service: Phase3InferenceService | None = None,
        dataset: EvaluationDatasetWriter | None = None,
    ) -> None:
        self.config = config or get_config()
        self.service = service or Phase3InferenceService(config=self.config)
        self.dataset = dataset or EvaluationDatasetWriter()

    def observe(
        self,
        *,
        raw_text: str,
        conversation_id: str,
        normalized_text: str,
        context: Any,
        recent_messages: Sequence[Any] = (),
        intent_candidates: Sequence[Any] = (),
        symbolic_relation: str | None = None,
        symbolic_decision: Any | None = None,
        symbolic_emotion: Any | None = None,
    ) -> ShadowComparisonRecord | None:
        """Run one shadow inference. Any failure is contained and returns None."""
        try:
            if not self.config.enabled or self.config.mode is not Phase3Mode.SHADOW:
                return None

            features = build_features(
                raw_text,
                normalized_text,
                context,
                recent_messages=recent_messages,
                intent_candidates=intent_candidates,
                config=self.config,
            )
            outcome = self.service.run_trial(features.normalized_text or raw_text, max_new_tokens=16)

            decision_dict = self._safe_dict(symbolic_decision)
            emotion_dict = self._safe_dict(symbolic_emotion)
            symbolic = {
                "active_topic": context.active_topic,
                "recent_topics": list(context.recent_topics),
                "current_emotion": context.current_emotion,
                "previous_emotion": context.previous_emotion,
                "emotion_intensity": context.emotion_intensity,
                "known_cause": context.known_cause,
                "recent_event": context.recent_event,
                "conversation_mode": context.conversation_mode,
                "user_goal": context.user_goal,
                "pending_question": context.unanswered_question,
                "relation": symbolic_relation,
                "decision": decision_dict,
                "emotion_reading": emotion_dict,
            }

            neural = {
                "success": outcome.success,
                "output": outcome.output,
                "model_version": outcome.model_version,
                "tokenizer_version": outcome.tokenizer_version,
                "latency_ms": outcome.latency_ms,
                "fallback_used": outcome.fallback_used,
                "fallback_reason": outcome.fallback_reason.value if outcome.fallback_reason else None,
                "timed_out": outcome.timed_out,
            }

            # No fake semantic agreement: structured neural task heads do not exist yet.
            comparison = {
                "mode": "shadow",
                "status": "raw_neural_output_only",
                "structured_agreement_score": None,
                "note": "Structured symbolic-vs-neural comparison requires task_heads.py in a later stage.",
            }

            record = ShadowComparisonRecord(
                record_id=uuid.uuid4().hex[:12],
                timestamp=time.time(),
                conversation_id=conversation_id,
                normalized_text=normalized_text,
                symbolic=symbolic,
                neural=neural,
                comparison=comparison,
            )
            self.dataset.append(record.to_dict())
            return record
        except Exception:
            # Shadow mode is observational only; it can never break the turn.
            return None

    @staticmethod
    def _safe_dict(value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if hasattr(value, "__dataclass_fields__"):
            from dataclasses import asdict
            try:
                return asdict(value)
            except Exception:
                return {}
        return {}

    def shutdown(self) -> None:
        try:
            self.service.shutdown()
        except Exception:
            pass


_runner_lock = threading.Lock()
_runner: Phase3ShadowRunner | None = None


def get_shadow_runner() -> Phase3ShadowRunner:
    global _runner
    with _runner_lock:
        if _runner is None:
            _runner = Phase3ShadowRunner()
        return _runner


def reset_shadow_runner() -> None:
    global _runner
    with _runner_lock:
        old = _runner
        _runner = None
    if old is not None:
        old.shutdown()


_controlled_lock = threading.Lock()
_controlled_runner: ControlledFusionRunner | None = None

def get_controlled_runner() -> ControlledFusionRunner:
    global _controlled_runner
    with _controlled_lock:
        if _controlled_runner is None:
            _controlled_runner = ControlledFusionRunner(get_config())
        return _controlled_runner

def reset_controlled_runner() -> None:
    global _controlled_runner
    with _controlled_lock:
        old, _controlled_runner = _controlled_runner, None
    if old is not None: old.shutdown()
