# -*- coding: utf-8 -*-
"""
Feature Builder فاز ۳ (سندِ P3.0، بخشِ ۶: «تبدیلِ ContextSnapshot به
ورودیِ مدل / خلاصه‌سازیِ تاریخچه / ساختِ featureهایِ ساختاری / جلوگیری
از ارسالِ تاریخچه‌ی بی‌نهایت»).

این ماژول عمداً هیچ importی از ``trx_ai.phase3.neural_adapter`` ندارد
چون آن ماژول در این مرحله (مرحله‌ی ۱ از ۱۰) هنوز ساخته نشده -- طبقِ
دستورِ صریحِ «بدونِ اتصالِ واقعی به Core». ``build_features`` یک تابعِ
خالص است: هیچ I/O، هیچ مدل، هیچ state سراسری -- فقط تبدیلِ داده، پس
بدونِ هیچ پیش‌نیازی (نه ``trx_model``، نه شبکه) قابلِ‌تست است.
"""

from __future__ import annotations

from collections.abc import Sequence

from trx_ai.conversation.schemas import ContextSnapshot, IntentCandidate, MessageRecord

from .config import Phase3Config, get_config
from .schemas import NeuralInputFeatures

# طولِ برشِ هر پیام در خلاصه‌ی تاریخچه -- یک پیامِ تکی هرچقدر هم بلند
# باشد نباید به‌تنهایی کلِ بودجه‌ی max_history_chars را ببلعد.
_PER_MESSAGE_SUMMARY_CAP = 400


def _message_text(item: str | MessageRecord) -> str:
    if isinstance(item, MessageRecord):
        # normalized_text ترجیح دارد (سازگار با بقیه‌ی خط‌لوله‌ی نرمال‌سازی)
        return item.normalized_text or item.raw_text
    return str(item)


def _build_history_summary(
    recent_messages: Sequence[str | MessageRecord],
    *,
    max_history_messages: int,
    max_history_chars: int,
) -> tuple[tuple[str, ...], bool, int]:
    """
    ``recent_messages`` طبقِ قراردادِ موجودِ ``context_manager.py``:
    جدیدترین پیام آخرِ لیست است.

    برمی‌گرداند: (خلاصه‌ی نهایی به همان ترتیب, آیا چیزی حذف شد, تعدادِ
    کاراکترِ خلاصه‌ی نهایی).
    """
    if not recent_messages:
        return (), False, 0

    truncated_by_count = len(recent_messages) > max_history_messages
    # جدیدترین N پیام را نگه می‌داریم (جدیدترین‌ها همیشه مفیدترند).
    window = list(recent_messages)[-max_history_messages:]

    capped_texts = [_message_text(m)[:_PER_MESSAGE_SUMMARY_CAP] for m in window]

    # حالا از انتهای (جدیدترین) به‌سمتِ ابتدا، تا سقفِ کاراکتریِ کل جمع
    # می‌کنیم؛ هرچه از سقف رد شد (یعنی قدیمی‌ترها) کنار می‌رود.
    kept_reversed: list[str] = []
    running_chars = 0
    truncated_by_chars = False
    for text in reversed(capped_texts):
        added = len(text) + 1  # +1 برایِ جداکننده‌ی مفهومی
        if kept_reversed and running_chars + added > max_history_chars:
            truncated_by_chars = True
            break
        kept_reversed.append(text)
        running_chars += added

    kept = tuple(reversed(kept_reversed))
    total_chars = sum(len(t) for t in kept)
    return kept, (truncated_by_count or truncated_by_chars), total_chars


def build_features(
    raw_text: str,
    normalized_text: str,
    context: ContextSnapshot,
    *,
    recent_messages: Sequence[str | MessageRecord] = (),
    intent_candidates: Sequence[IntentCandidate] = (),
    config: Phase3Config | None = None,
) -> NeuralInputFeatures:
    """
    ``context``: همان ``ContextSnapshot`` واقعیِ تولیدشده توسطِ
    ``trx_ai.conversation.context_manager`` / ``state_tracker`` --
    این تابع خودش هیچ context جدیدی نمی‌سازد و نمی‌خواند (طبقِ اصلِ
    غیرقابلِ‌مذاکره‌ی سند: «فاز ۳ نباید Context Manager مستقل و رقیب
    بسازد»).

    ``config``: اگر داده نشود، از ``get_config()`` (متغیرهایِ محیطی)
    خوانده می‌شود؛ برایِ تست دادنِ یک ``Phase3Config`` دلخواه توصیه
    می‌شود تا رفتار مستقل از محیطِ سراسری باشد.
    """
    cfg = config or get_config()

    history_summary, truncated, char_count = _build_history_summary(
        recent_messages,
        max_history_messages=cfg.max_history_messages,
        max_history_chars=cfg.max_history_chars,
    )

    return NeuralInputFeatures(
        raw_text=raw_text,
        normalized_text=normalized_text,
        active_topic=context.active_topic,
        recent_topics=tuple(context.recent_topics),
        current_emotion=context.current_emotion,
        previous_emotion=context.previous_emotion,
        emotion_intensity=context.emotion_intensity,
        known_cause=context.known_cause,
        recent_event=context.recent_event,
        conversation_mode=context.conversation_mode,
        user_goal=context.user_goal,
        pending_question=context.unanswered_question,
        symbolic_intent_names=tuple(c.name for c in intent_candidates),
        history_summary=history_summary,
        history_truncated=truncated,
        history_char_count=char_count,
    )
