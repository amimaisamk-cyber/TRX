# -*- coding: utf-8 -*-
"""
TRX Native Neural Cognitive Layer -- Phase 3 (سندِ طراحیِ P3.0).

وضعیتِ فعلی: **مرحله‌ی ۳ از برنامه‌ی ده‌مرحله‌ایِ سند (بخشِ ۱۹)**.

    مرحله ۱ (انجام‌شده): ساختِ schemas + config + feature_builder --
    بدونِ اتصالِ واقعی به Core یا به ``trx_model``.

    مرحله ۲ (انجام‌شده): اتصالِ ``neural_adapter.py`` به ``trx_model``
    -- فقط inference آزمایشی، تستِ load/unload، تستِ سازگاریِ
    tokenizer/model.

    مرحله ۳ (انجام‌شده): ``inference_service.py`` -- timeout
    (``latency_guard.py``)، resource guard (RAM)، fallback
    (``fallback.py``)، تله‌متری (``telemetry.py``).

یعنی این پکیج همچنان:

- هیچ importی از ``trx_ai.core_engine`` / ``trx_ai.intelligence`` ندارد
  و هیچ importی از آن‌ها روی این پکیج وجود ندارد (اتصال یک‌طرفه‌ی صفر).
- هیچ فایلِ موجودِ دیگری را تغییر نداده -- کاملاً افزودنی است.
- هیچ ``NeuralAdvice``/``FusionDecision`` واقعی‌ای نمی‌سازد -- فقط
  ``InferenceOutcome`` (قراردادِ محلیِ همین مرحله). ``task_heads.py``،
  ``fusion_engine.py``، ``policy_bridge.py``، ``draft_generator.py`` و
  ``versioning.py`` کامل، طبقِ برنامه‌ی مرحله‌ایِ سند، هنوز عمداً ساخته
  نشده‌اند (مراحلِ ۴ به بعد).

با پرچمِ پیش‌فرض (``TRX_PHASE3_ENABLED=false``) این پکیج حتی اگر
importشود، هیچ رفتارِ زنده‌ای اجرا نمی‌کند و هیچ ریسکِ رگرسیونی برایِ
TRX ندارد -- ``Phase3InferenceService.run_trial`` بلافاصله fallback
می‌کند بدونِ لمسِ ``trx_model``.
"""

from __future__ import annotations

from .config import Phase3Config, Phase3Mode, get_config
from .fallback import FallbackReason
from .feature_builder import build_features
from .inference_service import InferenceOutcome, Phase3InferenceService
from .neural_adapter import (
    AdapterState,
    CompatibilityCheck,
    LoadResult,
    NeuralAdapter,
    NeuralAdapterNotLoadedError,
)
from .schemas import (
    DecisionSource,
    DiscourseRelation,
    FusionDecision,
    NeuralAdvice,
    NeuralInputFeatures,
    ResponseMode,
)
from .telemetry import InferenceTelemetryRecord, TelemetryLog
from .evaluation_dataset import EvaluationDatasetWriter
from .shadow import (ShadowComparisonRecord, Phase3ShadowRunner, get_shadow_runner, reset_shadow_runner,
                     get_controlled_runner, reset_controlled_runner)

__phase3_stage__ = (
    "4/10 -- Shadow + controlled conversational neural draft; "
    "tool/medical routing remains symbolic and deterministic"
)

__all__ = [
    "Phase3Config",
    "Phase3Mode",
    "get_config",
    "build_features",
    "DecisionSource",
    "DiscourseRelation",
    "FusionDecision",
    "NeuralAdvice",
    "NeuralInputFeatures",
    "ResponseMode",
    "AdapterState",
    "CompatibilityCheck",
    "LoadResult",
    "NeuralAdapter",
    "NeuralAdapterNotLoadedError",
    "FallbackReason",
    "InferenceOutcome",
    "Phase3InferenceService",
    "InferenceTelemetryRecord",
    "TelemetryLog",
    "EvaluationDatasetWriter",
    "ShadowComparisonRecord",
    "Phase3ShadowRunner",
    "get_shadow_runner",
    "reset_shadow_runner",
    "get_controlled_runner",
    "reset_controlled_runner",
    "__phase3_stage__",
]
