# -*- coding: utf-8 -*-
"""
Fallback فاز ۳ (سندِ P3.0، بخشِ ۶ -- ``fallback.py``: «بازگشت به سیستمِ
نمادین / پاسخِ امن در صورتِ خرابیِ مدل») و بخشِ ۱۳ («فهرستِ کاملِ
شرایطی که باید سیستم را به fallback ببرند»).

این فایل عمداً بدونِ state و بدونِ وابستگی به ``neural_adapter``/
``inference_service`` است -- فقط: «چرا fallback شد؟» را به یک enum
استاندارد و یک توضیحِ خوانا تبدیل می‌کند. خودِ *تصمیمِ* fallback-کردن و
ساختِ خروجیِ نهایی مسئولیتِ ``inference_service.py`` است (طبقِ همان
اصلِ سند که هر فایل «مسئولیتِ مشخص» دارد).
"""

from __future__ import annotations

from enum import Enum

__all__ = ["FallbackReason", "describe"]


class FallbackReason(str, Enum):
    """
    دقیقاً پوششِ فهرستِ بخشِ ۱۳ سند («اگر هرکدام از موارد زیر رخ داد»)
    -- به‌جز مواردی که هنوز در معماری وجود ندارند (schema invalid /
    NaN-Inf مربوط به ``advice_validator.py`` است، خروجیِ بی‌معنی مربوط
    به ``task_heads.py`` است؛ هردو مراحلِ بعدی‌اند).
    """

    DISABLED = "disabled"  # TRX_PHASE3_ENABLED=false یا mode=DISABLED
    NOT_LOADED = "not_loaded"  # آداپتور اصلاً بارگذاری نشده
    LOAD_FAILED = "load_failed"  # مدل/توکنایزر بارگذاری نشد (tokenizer ناسازگار و ...)
    RAM_LIMIT = "ram_limit"  # RAM بالا (بخشِ ۲۱)
    TIMEOUT = "timeout"  # تایم‌اوت (بخشِ ۶/۲۱)
    EXCEPTION = "exception"  # استثنایِ پیش‌بینی‌نشده حینِ inference


_DESCRIPTIONS: dict[FallbackReason, str] = {
    FallbackReason.DISABLED: "فاز ۳ غیرفعال است (TRX_PHASE3_ENABLED=false یا mode=disabled).",
    FallbackReason.NOT_LOADED: "آداپتورِ عصبی بارگذاری نشده است.",
    FallbackReason.LOAD_FAILED: "بارگذاریِ مدل/توکنایزر شکست خورد.",
    FallbackReason.RAM_LIMIT: "مصرفِ RAM از سقفِ مجاز بیشتر است.",
    FallbackReason.TIMEOUT: "inference از مهلتِ زمانیِ مجاز عبور کرد.",
    FallbackReason.EXCEPTION: "خطایِ پیش‌بینی‌نشده حینِ inference رخ داد.",
}


def describe(reason: FallbackReason) -> str:
    """توضیحِ فارسیِ خوانا برایِ لاگ/تله‌متری."""
    return _DESCRIPTIONS.get(reason, reason.value)
