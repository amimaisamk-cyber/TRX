# -*- coding: utf-8 -*-
"""
تنظیماتِ مرکزیِ لایه‌ی عصبیِ فاز ۳ (سندِ P3.0، بخشِ ۶ -- ``config.py``:
«حالتِ اجرا / محدودیتِ RAM / timeout / حداقلِ confidence / فعال‌غیرفعال
بودنِ وظایف»).

الگو دقیقاً همانِ ``trx_ai/conversation/config.py`` است: همه‌چیز از
متغیرِ محیطی هم قابلِ‌بازنویسی، پیش‌فرض‌ها امن، و یک kill-switch مرکزی.

تفاوتِ کلیدی با ``conversation/config.py``: پیش‌فرضِ آنجا (اتصالِ
Conversation Intelligence) ``True`` بود چونِ آن سامانه از قبل تکمیل و
تأیید شده بود. اینجا -- طبقِ اصلِ غیرِقابلِ‌مذاکره‌ی ۹ سند («اتصال باید
قابلِ‌خاموش‌کردن باشد») و ۱۲ («مدل باید ابتدا shadow و advisory را
پشتِ سر بگذارد») و بندِ ۱۱ («هیچ‌گاه نباید مستقیماً از Disabled به
Controlled Production رفت») -- پیش‌فرض همیشه ``False`` /
``Phase3Mode.DISABLED`` است، چون هنوز حتیِ ``neural_adapter.py``
(مرحله‌ی ۲ سند) ساخته نشده و چیزی برایِ اجرا وجود ندارد.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum


def _env_bool(name: str, default: bool) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _env_float(name: str, default: float) -> float:
    val = os.environ.get(name)
    if val is None:
        return default
    try:
        return float(val)
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    val = os.environ.get(name)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        return default


def _env_str(name: str, default: str) -> str:
    val = os.environ.get(name)
    if val is None:
        return default
    val = val.strip()
    return val if val else default


# ==========================================================
#   حالت‌هایِ اجرایِ فاز ۳ (سندِ بخشِ ۱۱) -- ترتیبِ خطی و اجباری
# ----------------------------------------------------------
class Phase3Mode(str, Enum):
    """
    دقیقاً شش حالتِ بخشِ ۱۱ سند. ترتیبِ اعضایِ enum همان ترتیبِ مجازِ
    پیشروی است -- ``ROLLOUT_ORDER`` پایین از همین ترتیب می‌خواند تا دو
    منبع از هم واگرا نشوند.

    این کلاس خودش هیچ اجباری در پرش بینِ مراحل نمی‌گذارد (آن مسئولیتِ
    orchestration/دیپلویمنت است، نه یک dataclassِ تنظیمات) -- فقط
    نام‌گذاریِ مشترک را تعریف می‌کند تا بقیه‌ی فاز ۳ به رشته‌هایِ دستی
    (typo-prone) وابسته نباشد.
    """

    DISABLED = "disabled"
    SHADOW = "shadow"
    ADVISORY = "advisory"
    CONTROLLED_FUSION = "controlled_fusion"
    LIMITED_DRAFT = "limited_draft"
    CONTROLLED_PRODUCTION = "controlled_production"


ROLLOUT_ORDER: tuple[Phase3Mode, ...] = (
    Phase3Mode.DISABLED,
    Phase3Mode.SHADOW,
    Phase3Mode.ADVISORY,
    Phase3Mode.CONTROLLED_FUSION,
    Phase3Mode.LIMITED_DRAFT,
    Phase3Mode.CONTROLLED_PRODUCTION,
)


class ResourceMode(str, Enum):
    """حالت‌هایِ منابعِ بخشِ ۲۱ سند (حفاظتِ Pydroid/Android)."""

    FULL = "full"
    BALANCED = "balanced"
    LOW = "low"
    SAFE = "safe"


# وظایفِ مدل که می‌توانند مستقل روشن/خاموش شوند (بخشِ ۵ سند: پیش‌بینیِ
# موضوع، رابطه‌ی گفتمانی، احساس، شدتِ احساس، انتقالِ احساس، حالتِ
# پاسخ، نامزدهایِ intent، پیش‌نویس). این لیست منبعِ واحدِ نام‌گذاری برایِ
# ``Phase3Config.enabled_tasks`` است.
ALL_TASKS: tuple[str, ...] = (
    "topic",
    "relation",
    "emotion",
    "emotion_intensity",
    "emotional_transition",
    "response_mode",
    "intent_candidates",
    "draft",
)

# در Advisory/Controlled Fusion (اولین حالت‌هایِ فعالِ واقعی طبقِ بخشِ
# ۱۱)، سند صراحتاً draft را در آن مرحله مجاز نمی‌داند («مرحلهٔ E: Limited
# Draft ... جداگانه»). پس پیش‌فرضِ وظایفِ فعال همه چیز *به‌جز* draft است.
_DEFAULT_ENABLED_TASKS: tuple[str, ...] = tuple(t for t in ALL_TASKS if t != "draft")


def _parse_enabled_tasks(raw: str | None) -> tuple[str, ...]:
    if raw is None:
        return _DEFAULT_ENABLED_TASKS
    names = tuple(t.strip() for t in raw.split(",") if t.strip())
    unknown = [t for t in names if t not in ALL_TASKS]
    if unknown or not names:
        # ورودیِ نامعتبر یعنی برگشتِ امن به پیش‌فرض -- نه crash، نه
        # سکوتِ کاملِ نامعتبر (طبقِ اصلِ پایداریِ سند).
        return _DEFAULT_ENABLED_TASKS
    return names


@dataclass(frozen=True)
class Phase3Config:
    """
    تصویرِ غیرقابل‌تغییرِ (frozen) یک پیکربندیِ فاز ۳. ``get_config()``
    این را یک‌بار از متغیرهایِ محیطی می‌سازد؛ توابعِ بعدیِ فاز ۳ (از
    مرحله‌ی ۲ به بعد) این شیء را پاس می‌دهند نه اینکه مستقیم
    ``os.environ`` بخوانند -- تا در تست بتوان یک ``Phase3Config``
    دلخواه ساخت بدونِ دستکاریِ متغیرِ محیطیِ سراسری.
    """

    enabled: bool = False
    mode: Phase3Mode = Phase3Mode.DISABLED

    # محدودیت‌هایِ اجرا (بخشِ ۶: inference_service.py / latency_guard.py
    # -- اینجا فقط عدد نگه‌داشته می‌شود، اجراکننده هنوز ساخته نشده).
    timeout_ms: float = 400.0
    max_ram_mb: float = 512.0
    min_confidence: float = 0.55

    # ساختِ feature (بخشِ feature_builder.py: «جلوگیری از ارسالِ
    # تاریخچه‌ی بی‌نهایت»).
    max_history_messages: int = 8
    max_history_chars: int = 2000

    enabled_tasks: tuple[str, ...] = field(default_factory=lambda: _DEFAULT_ENABLED_TASKS)

    def task_enabled(self, task: str) -> bool:
        return task in self.enabled_tasks

    def __post_init__(self) -> None:
        # dataclass(frozen=True) اجازه‌ی assignment نمی‌دهد، پس فقط
        # اعتبارسنجی می‌کنیم و در نامعتبر بودن هم crash نمی‌کنیم --
        # مقادیرِ نامعتبر همین‌جا (در ساختِ خودِ get_config) به
        # پیش‌فرض تبدیل شده‌اند؛ این فقط یک قراردادِ داخلی است که
        # فراخوانی‌هایِ دستیِ آینده (تست/کد) هم به یاد داشته باشند.
        if not (0.0 <= self.min_confidence <= 1.0):
            raise ValueError(
                f"min_confidence باید بینِ ۰ و ۱ باشد، نه {self.min_confidence!r}"
            )
        if self.timeout_ms <= 0:
            raise ValueError(f"timeout_ms باید مثبت باشد، نه {self.timeout_ms!r}")
        if self.max_history_messages <= 0:
            raise ValueError(
                f"max_history_messages باید مثبت باشد، نه {self.max_history_messages!r}"
            )
        if self.max_history_chars <= 0:
            raise ValueError(
                f"max_history_chars باید مثبت باشد، نه {self.max_history_chars!r}"
            )


def get_config() -> Phase3Config:
    """
    ``Phase3Config`` را از متغیرهایِ محیطی می‌سازد (بندِ ۱۴ سند:
    ``TRX_PHASE3_ENABLED`` / ``TRX_PHASE3_MODE``).

    قاعده‌ی امنِ حیاتی: اگر ``TRX_PHASE3_ENABLED`` نباشد یا مقدارِ
    ``TRX_PHASE3_MODE`` نامعتبر/ناشناخته باشد، همیشه ``DISABLED``
    برمی‌گردد -- هرگز حدسِ خوش‌بینانه نمی‌زند و هرگز روی مقدارِ
    نامعتبر crash نمی‌کند (اصلِ پایداریِ سند: «خرابیِ فاز ۳ نباید
    مکالمه را متوقف کند»، حتی پیش از آنکه inference واقعی‌ای وجود
    داشته باشد).
    """

    enabled = _env_bool("TRX_PHASE3_ENABLED", False)

    mode_raw = _env_str("TRX_PHASE3_MODE", Phase3Mode.DISABLED.value)
    try:
        mode = Phase3Mode(mode_raw.strip().lower())
    except ValueError:
        mode = Phase3Mode.DISABLED

    if not enabled:
        mode = Phase3Mode.DISABLED

    return Phase3Config(
        enabled=enabled,
        mode=mode,
        timeout_ms=_env_float("TRX_PHASE3_TIMEOUT_MS", 400.0),
        max_ram_mb=_env_float("TRX_PHASE3_MAX_RAM_MB", 512.0),
        min_confidence=_env_float("TRX_PHASE3_MIN_CONFIDENCE", 0.55),
        max_history_messages=_env_int("TRX_PHASE3_MAX_HISTORY_MESSAGES", 8),
        max_history_chars=_env_int("TRX_PHASE3_MAX_HISTORY_CHARS", 2000),
        enabled_tasks=_parse_enabled_tasks(os.environ.get("TRX_PHASE3_ENABLED_TASKS")),
    )
