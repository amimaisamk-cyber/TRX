# -*- coding: utf-8 -*-
"""
قراردادهایِ داده‌یِ فاز ۳ (سندِ P3.0، بخش‌هایِ ۵، ۷ و ۸).

دقیقاً همانِ فلسفه‌ی ``trx_ai/conversation/schemas.py``: این فایل
عمداً بدونِ هیچ منطقی است -- فقط شکلِ داده. اعتبارسنجیِ واقعی
(«confidence بینِ ۰ و ۱»، «NaN/Inf ممنوع»، ...) وظیفه‌ی
``advice_validator.py`` است که طبقِ برنامه‌ی مرحله‌ایِ سند (بخشِ ۱۹)
در مرحله‌ی ۳ ساخته می‌شود -- نه اینجا. اینجا فقط قراردادِ خودِ داده
تعریف می‌شود تا از همین مرحله‌ی ۱، بقیه‌ی فاز ۳ (و تست‌ها) یک زبانِ
مشترک داشته باشند.

نکته‌ی مهم دربابِ هم‌زیستی: ``NeuralInputFeatures`` جایگزینِ
``trx_ai.conversation.schemas.ContextBundle`` نیست -- ورودیِ آن
است. ``feature_builder.build_features`` یک ``ContextSnapshot`` واقعی
(همان کلاسِ موجودِ ``trx_ai.conversation.schemas``) می‌گیرد و یک
``NeuralInputFeatures`` مسطح و محدودشده برایِ مصرفِ آینده‌یِ
``neural_adapter.py`` تولید می‌کند -- طبقِ اصلِ غیرقابلِ‌مذاکره‌ی سند:
«فاز ۳ نباید Context Manager مستقل و رقیب بسازد.»
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


# ==========================================================
#   DiscourseRelation -- بخشِ ۵.۲ سند (رابطه‌یِ گفتمانی)
# ==========================================================
class DiscourseRelation(str, Enum):
    """
    رابطه‌ی پیامِ فعلی با پیامِ قبلی، از دیدِ مدلِ عصبی.

    توجه: این enum عمداً جدا از ``trx_ai.conversation.schemas.TopicRelation``
    نگه داشته شده -- نه به این دلیل که آن یکی بد است، بلکه چون دو منبعِ
    متفاوت‌اند (یکی خروجیِ ``topic_tracker.py`` نمادین، این یکی خروجیِ
    مدلِ عصبی) و سندِ فاز ۳ صراحتاً یک مقدارِ اضافی دارد که در enumِ
    نمادین نیست (``EMOTIONAL_UPDATE``). نگاشتِ متناظر برایِ
    ``fusion_engine.py`` (مرحله‌ی ۶ سند، هنوز ساخته نشده) لازم است؛
    نگاشتِ پیشنهادی این‌جا مستند شده تا آن مرحله دوباره طراحی نکند:

        DiscourseRelation.CONTINUATION            <-> TopicRelation.CONTINUATION
        DiscourseRelation.CAUSE                    <-> TopicRelation.CAUSE
        DiscourseRelation.EFFECT                   <-> TopicRelation.CONSEQUENCE
        DiscourseRelation.CLARIFICATION             <-> TopicRelation.EXPLANATION
        DiscourseRelation.CORRECTION                <-> TopicRelation.CORRECTION
        DiscourseRelation.CONTRAST                  <-> TopicRelation.CONTRAST
        DiscourseRelation.ANSWER_TO_PREVIOUS_QUESTION <-> TopicRelation.ANSWER_TO_QUESTION
        DiscourseRelation.TOPIC_SHIFT               <-> TopicRelation.TOPIC_SHIFT
        DiscourseRelation.UNRELATED                 <-> TopicRelation.UNRELATED
        DiscourseRelation.EMOTIONAL_UPDATE           <-> (بدونِ معادلِ نمادین)
    """

    CONTINUATION = "continuation"
    CAUSE = "cause"
    EFFECT = "effect"
    CLARIFICATION = "clarification"
    CORRECTION = "correction"
    CONTRAST = "contrast"
    ANSWER_TO_PREVIOUS_QUESTION = "answer_to_previous_question"
    EMOTIONAL_UPDATE = "emotional_update"
    TOPIC_SHIFT = "topic_shift"
    UNRELATED = "unrelated"


# ==========================================================
#   ResponseMode -- بخشِ ۵.۶ سند (پیشنهادِ حالتِ پاسخ)
# ==========================================================
class ResponseMode(str, Enum):
    EMPATHETIC_REFLECTION = "empathetic_reflection"
    DIRECT_ANSWER = "direct_answer"
    CLARIFICATION = "clarification"
    EXPLANATION = "explanation"
    ENCOURAGEMENT = "encouragement"
    CONCISE_ACKNOWLEDGMENT = "concise_acknowledgment"
    FOLLOWUP_QUESTION = "followup_question"
    REPAIR_RESPONSE = "repair_response"
    TOOL_RESPONSE = "tool_response"


# ==========================================================
#   DecisionSource -- بخشِ ۸ سند (FusionDecision.decision_source)
# ==========================================================
class DecisionSource(str, Enum):
    SYMBOLIC = "symbolic"
    NEURAL = "neural"
    FUSED = "fused"
    FALLBACK = "fallback"


# ==========================================================
#   NeuralInputFeatures -- ورودیِ ساختاریافته‌یِ مدل (feature_builder.py)
# ==========================================================
@dataclass(frozen=True)
class NeuralInputFeatures:
    """
    خروجیِ ``feature_builder.build_features`` -- شکلِ مسطح و
    محدودشده‌ای که مرحله‌ی ۲ سند (``neural_adapter.py``) قرار است
    tokenize و به مدل بدهد. خودِ این دیتاکلاس هیچ tokenization‌ای
    انجام نمی‌دهد.

    ``history_summary`` از قبل به ``max_history_messages`` و
    ``max_history_chars`` (بخشِ ``Phase3Config``) محدود شده -- طبقِ
    مسئولیتِ صریحِ feature_builder در سند: «جلوگیری از ارسالِ تاریخچه‌ی
    بی‌نهایت».
    """

    raw_text: str
    normalized_text: str

    active_topic: str | None
    recent_topics: tuple[str, ...]
    current_emotion: str
    previous_emotion: str | None
    emotion_intensity: float
    known_cause: str | None
    recent_event: str | None
    conversation_mode: str
    user_goal: str | None
    pending_question: str | None

    symbolic_intent_names: tuple[str, ...]

    history_summary: tuple[str, ...]
    history_truncated: bool
    history_char_count: int


# ==========================================================
#   NeuralAdvice -- بخشِ ۷ سند
# ==========================================================
@dataclass
class NeuralAdvice:
    topic: str | None = None
    subtopic: str | None = None

    relation: DiscourseRelation | None = None
    continuity_score: float = 0.0

    current_emotion: str | None = None
    previous_emotion: str | None = None
    emotion_intensity: float = 0.0
    mixed_emotion: bool = False
    emotional_transition: str | None = None

    intent_candidates: tuple[str, ...] = ()
    response_mode: ResponseMode | None = None
    followup_type: str | None = None

    draft: str | None = None

    confidence: float = 0.0
    evidence: tuple[str, ...] = ()

    model_version: str | None = None
    tokenizer_version: str | None = None
    latency_ms: float = 0.0
    warnings: tuple[str, ...] = ()


# ==========================================================
#   FusionDecision -- بخشِ ۸ سند
# ==========================================================
@dataclass
class FusionDecision:
    final_topic: str | None = None
    final_relation: DiscourseRelation | None = None
    final_emotion: str | None = None
    final_continuity: float = 0.0
    final_intent_candidates: tuple[str, ...] = ()

    selected_mode: ResponseMode | None = None
    final_route: str | None = None
    tool_allowed: bool = True
    tool_block_reason: str | None = None
    response_strategy: str | None = None

    confidence: float = 0.0
    evidence: tuple[str, ...] = ()
    conflicts: tuple[str, ...] = ()
    fallback_used: bool = False
    decision_source: DecisionSource = DecisionSource.SYMBOLIC
