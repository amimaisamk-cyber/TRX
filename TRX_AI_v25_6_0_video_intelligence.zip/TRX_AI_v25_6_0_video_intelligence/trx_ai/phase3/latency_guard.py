# -*- coding: utf-8 -*-
"""
Latency Guard فاز ۳ (سندِ P3.0، بخشِ ۶ -- ``latency_guard.py``: «کنترلِ
زمانِ پاسخ / قطعِ inference در شرایطِ سنگین») و بخشِ ۲۱ («RAM قبل از
inference بررسی شود»).

**مرحله‌ی ۳ از ۱۰ (بخشِ ۱۹ سند):** «ساختِ Inference Service / timeout /
resource guard / fallback / telemetry».

نکته‌ی صادقانه دربابِ timeout (همان روحیه‌ی ``model.py``/``core.py``
در این پروژه -- محدودیتِ واقعی را پنهان نکن):

CPython نمی‌تواند یک Thread را از بیرون به‌زور بکشد. ``run_with_timeout``
یک ``ThreadPoolExecutor`` تک-نخی می‌سازد و با ``future.result(timeout=...)``
منتظر می‌ماند؛ اگر مهلت تمام شود، ``timed_out=True`` برمی‌گرداند و
**فوراً کنترل را پس می‌دهد** -- اما اگر forward pass واقعاً طولانی باشد،
نخِ زمینه تا پایانِ طبیعیِ خودش (یا خطا) به اجرا ادامه می‌دهد؛ فقط
دیگر نتیجه‌اش مصرف نمی‌شود. این همان چیزی است که سند هم می‌خواهد
(«قطعِ inference» از دیدِ کاربر/مسیرِ پاسخ، نه لزوماً kill سطحِ سیستم‌عامل)
و دقیقاً به همین دلیل RAM guard قبل از هر inference لازم است: تایم‌اوت
به‌تنهایی مانعِ تجمعِ چند نخِ زمینه‌ی سنگین نمی‌شود.
"""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from dataclasses import dataclass
from typing import Any, Callable, Optional, TypeVar

from ..dependencies import PSUTIL_AVAILABLE

if PSUTIL_AVAILABLE:
    import psutil

__all__ = ["TimeoutOutcome", "run_with_timeout", "RamCheck", "check_ram_budget"]

T = TypeVar("T")


@dataclass
class TimeoutOutcome:
    completed: bool
    timed_out: bool
    result: Optional[Any] = None
    error: Optional[str] = None
    elapsed_ms: float = 0.0


def run_with_timeout(
    fn: Callable[..., T],
    timeout_ms: float,
    *args: Any,
    **kwargs: Any,
) -> TimeoutOutcome:
    """
    اجرایِ ``fn(*args, **kwargs)`` با سقفِ زمانیِ ``timeout_ms``.

    - موفقیت: ``completed=True, timed_out=False, result=...``
    - تایم‌اوت: ``completed=False, timed_out=True``
    - استثنایِ خودِ ``fn``: ``completed=False, timed_out=False, error=...``
      (نه raise -- طبقِ اصلِ سند «خرابیِ مدل نباید مکالمه را متوقف کند»؛
      لایه‌ی بالادست/فراخواننده تصمیم می‌گیرد چطور fallback کند).
    """
    import time

    started = time.monotonic()
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(fn, *args, **kwargs)
        try:
            result = future.result(timeout=max(timeout_ms, 0.0) / 1000.0)
            return TimeoutOutcome(
                completed=True,
                timed_out=False,
                result=result,
                elapsed_ms=(time.monotonic() - started) * 1000.0,
            )
        except FutureTimeoutError:
            return TimeoutOutcome(
                completed=False,
                timed_out=True,
                elapsed_ms=(time.monotonic() - started) * 1000.0,
            )
        except Exception as exc:  # noqa: BLE001 -- ثبت، نه crash
            return TimeoutOutcome(
                completed=False,
                timed_out=False,
                error=f"{type(exc).__name__}: {exc}",
                elapsed_ms=(time.monotonic() - started) * 1000.0,
            )


@dataclass
class RamCheck:
    ok: bool
    measured: bool
    current_mb: Optional[float] = None
    limit_mb: Optional[float] = None
    reason: Optional[str] = None


def check_ram_budget(max_ram_mb: float) -> RamCheck:
    """
    بررسیِ RAM قبل از inference (بخشِ ۲۱ سند). اگر ``psutil`` نصب نباشد
    (طبقِ همان الگویِ ``dependencies.PSUTIL_AVAILABLE`` که در سراسرِ
    پروژه استفاده شده)، بررسی امکان‌پذیر نیست -- ``ok=True`` (مانعِ
    inference نمی‌شویم) اما ``measured=False`` تا تله‌متری بداند این
    عدد قابلِ‌اتکا نیست، نه اینکه واقعاً زیرِ سقف بوده.
    """
    if not PSUTIL_AVAILABLE:
        return RamCheck(ok=True, measured=False, limit_mb=max_ram_mb)

    try:
        proc = psutil.Process(os.getpid())
        current_mb = proc.memory_info().rss / (1024 * 1024)
    except Exception as exc:  # noqa: BLE001 -- بررسیِ منابع هم نباید crash کند
        return RamCheck(ok=True, measured=False, limit_mb=max_ram_mb, reason=str(exc))

    if current_mb > max_ram_mb:
        return RamCheck(
            ok=False,
            measured=True,
            current_mb=current_mb,
            limit_mb=max_ram_mb,
            reason=f"RAM فعلیِ فرآیند ({current_mb:.1f}MB) از سقفِ {max_ram_mb:.1f}MB بیشتر است.",
        )
    return RamCheck(ok=True, measured=True, current_mb=current_mb, limit_mb=max_ram_mb)
