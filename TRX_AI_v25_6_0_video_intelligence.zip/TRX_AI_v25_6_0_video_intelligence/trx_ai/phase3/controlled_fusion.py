from __future__ import annotations
import re, threading, time
from dataclasses import dataclass
from typing import Sequence
from .config import Phase3Config, Phase3Mode
from .inference_service import Phase3InferenceService

_PERSIAN = re.compile(r'[\u0600-\u06FF]')
_LATIN = re.compile(r'[A-Za-z]')
_BAD = ('<pad>', '<bos>', '<eos>', 'nan', 'inf')

@dataclass(frozen=True)
class ControlledNeuralDraft:
    conversation_id: str
    text: str
    confidence: float
    latency_ms: float
    model_version: str | None
    tokenizer_version: str | None
    created_at: float

class ControlledFusionRunner:
    """Fail-soft, one-shot bridge for controlled conversational drafts."""
    def __init__(self, config: Phase3Config, service: Phase3InferenceService | None = None) -> None:
        self.config = config
        self.service = service or Phase3InferenceService(config=config)
        self._lock = threading.Lock()
        self._pending: dict[str, ControlledNeuralDraft] = {}

    @staticmethod
    def _quality(text: str, source: str, context: Sequence[str]) -> float:
        text = (text or '').strip()
        if not text or len(text) < 8 or len(text) > 700: return 0.0
        low = text.lower()
        if any(x in low for x in _BAD) or re.search(r'(.)\1{5,}', text): return 0.0
        letters = len(re.findall(r'[^\W\d_]', text, flags=re.UNICODE))
        if letters < 4: return 0.0
        if len(_PERSIAN.findall(text)) + len(_LATIN.findall(text)) < 4: return 0.0
        words = set(re.findall(r'[\w\u0600-\u06FF]{3,}', (source + ' ' + ' '.join(context)).lower()))
        out_words = set(re.findall(r'[\w\u0600-\u06FF]{3,}', low))
        grounding = 0.15 if words & out_words else 0.0
        return min(1.0, 0.45 + grounding + min(0.35, letters / 500.0))

    def try_advice(self, *, conversation_id: str, text: str, recent_messages: Sequence[str] = (),
                   symbolic_route: str, symbolic_intent: str, symbolic_confidence: float) -> ControlledNeuralDraft | None:
        try:
            if self.config.mode is not Phase3Mode.CONTROLLED_FUSION: return None
            if symbolic_route != 'conversation': return None
            if symbolic_intent not in {'general', 'casual_conversation'}: return None
            if symbolic_confidence < self.config.min_confidence: return None
            outcome = self.service.run_trial(text, max_new_tokens=48)
            if not outcome.success or not outcome.output: return None
            quality = self._quality(outcome.output, text, recent_messages)
            if quality < self.config.min_confidence: return None
            draft = ControlledNeuralDraft(conversation_id, outcome.output.strip(), min(quality, 1.0),
                                          outcome.latency_ms, outcome.model_version, outcome.tokenizer_version, time.time())
            with self._lock: self._pending[conversation_id] = draft
            return draft
        except Exception:
            return None

    def consume(self, conversation_id: str) -> ControlledNeuralDraft | None:
        with self._lock: return self._pending.pop(conversation_id, None)

    def shutdown(self) -> None:
        try: self.service.shutdown()
        except Exception: pass
