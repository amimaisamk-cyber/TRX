# -*- coding: utf-8 -*-
"""
Evaluation dataset sink for Phase 3 Stage 4.

Stage 4 is deliberately shadow-only: records are append-only JSONL examples
and never feed back into the live routing/response path.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


def default_dataset_path() -> Path:
    raw = os.environ.get(
        "TRX_PHASE3_SHADOW_DATASET_PATH",
        "logs/phase3_shadow_dataset.jsonl",
    ).strip()
    return Path(raw or "logs/phase3_shadow_dataset.jsonl")


class EvaluationDatasetWriter:
    """Fail-soft JSONL writer used only by Stage 4 shadow evaluation."""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else default_dataset_path()

    def append(self, record: dict[str, Any]) -> bool:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
            return True
        except Exception:
            # Dataset I/O must never affect live conversation behavior.
            return False

    def read_recent(self, limit: int = 100) -> list[dict[str, Any]]:
        if limit <= 0 or not self.path.exists():
            return []
        try:
            with self.path.open("r", encoding="utf-8") as fh:
                lines = fh.readlines()
            result: list[dict[str, Any]] = []
            for line in lines[-limit:]:
                try:
                    result.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
            return result
        except Exception:
            return []
