# -*- coding: utf-8 -*-
"""
Inference Service فاز ۳ (سندِ P3.0، بخشِ ۶ -- ``inference_service.py``:
«اجرایِ inference / timeout / محدودیتِ مصرف / اجرایِ taskهایِ فعال /
بازگرداندنِ نتیجه‌ی استاندارد»).

**مرحله‌ی ۳ از ۱۰ (بخشِ ۱۹ سند):** «ساختِ Inference Service / timeout /
resource guard / fallback / telemetry».

این سرویس -- طبقِ همان انضباطِ مرحله‌ی ۲ -- عمداً از محدوده‌ی صریحِ سند
فراتر نمی‌رود:

- «اجرایِ taskهایِ فعال» در این مرحله یعنی همان ``trial_generate``ی
  خامِ ``neural_adapter`` (بخشِ ۵ سند -- پیش‌بینیِ topic/emotion/... --
  به ``task_heads.py`` نیاز دارد که هنوز ساخته نشده). این سرویس فقط
  مسیرِ ایمنی/orchestration را می‌سازد؛ وقتی ``task_heads.py`` در مرحله‌ی
  بعد ساخته شود، همین ``_run_adapter`` جایگزین می‌شود، نه کلِ سرویس.
- بدونِ ``fusion_engine.py``/``policy_bridge.py`` -- این سرویس
  ``NeuralAdvice``/``FusionDecision`` نمی‌سازد و به هیچ Core متصل نیست؛
  فقط ``InferenceOutcome`` (قراردادِ محلیِ همین مرحله) برمی‌گرداند.

اصلِ غیرقابلِ‌مذاکره‌ی ۴ و ۹ سند اینجا به‌صورتِ کد درآمده: این سرویس
**هیچ‌وقت** exception به بیرون پرتاب نمی‌کند و با پرچمِ
``Phase3Config.enabled``/``mode`` کاملاً خاموش‌شدنی است.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

from .config import Phase3Config, Phase3Mode, get_config
from .fallback import FallbackReason, describe
from .latency_guard import check_ram_budget, run_with_timeout
from .neural_adapter import NeuralAdapter, NeuralAdapterNotLoadedError
from .telemetry import TelemetryLog

__all__ = ["InferenceOutcome", "Phase3InferenceService"]


@dataclass
class InferenceOutcome:
    """نتیجه‌ی استانداردِ سرویس -- همیشه یک شیءِ سازگار، هرگز استثنا."""

    success: bool
    output: Optional[str] = None
    model_version: Optional[str] = None
    tokenizer_version: Optional[str] = None
    latency_ms: float = 0.0
    timed_out: bool = False
    fallback_used: bool = False
    fallback_reason: Optional[FallbackReason] = None
    error: Optional[str] = None


class Phase3InferenceService:
    """
    نقطه‌ی ورودیِ واحد برایِ inference آزمایشیِ فاز ۳. مصرف‌کننده‌ی
    آینده (Conversation Engine -- هنوز وصل نشده) فقط باید
    ``run_trial(text)`` را صدا بزند و هیچ‌وقت لازم نیست خودش
    timeout/RAM/fallback را مدیریت کند.
    """

    def __init__(
        self,
        config: Optional[Phase3Config] = None,
        adapter: Optional[NeuralAdapter] = None,
        telemetry: Optional[TelemetryLog] = None,
    ) -> None:
        self.config = config or get_config()
        self.adapter = adapter or NeuralAdapter(self.config)
        self.telemetry = telemetry if telemetry is not None else TelemetryLog()

    # ------------------------------------------------------------------ --
    def _fallback(
        self,
        reason: FallbackReason,
        *,
        started: float,
        error: Optional[str] = None,
        timed_out: bool = False,
    ) -> InferenceOutcome:
        latency_ms = (time.monotonic() - started) * 1000.0
        outcome = InferenceOutcome(
            success=False,
            latency_ms=latency_ms,
            timed_out=timed_out,
            fallback_used=True,
            fallback_reason=reason,
            error=error or describe(reason),
        )
        self.telemetry.record(
            mode=self.config.mode.value,
            success=False,
            timed_out=timed_out,
            fallback_used=True,
            fallback_reason=reason,
            error=outcome.error,
            latency_ms=latency_ms,
        )
        return outcome

    def run_trial(self, text: str, max_new_tokens: int = 16) -> InferenceOutcome:
        """
        اجرایِ یک inference آزمایشی برایِ ``text``، همیشه پشتِ سرِ هم:
        بررسیِ فعال‌بودن -> بررسیِ RAM -> اطمینان از بارگذاریِ مدل ->
        اجرا زیرِ timeout -> ثبتِ تله‌متری. هیچ مرحله‌ای exception را به
        بیرون نشت نمی‌دهد.
        """
        started = time.monotonic()

        # ۱) قابلِ خاموش‌کردن (اصلِ ۹ سند)
        if not self.config.enabled or self.config.mode is Phase3Mode.DISABLED:
            return self._fallback(FallbackReason.DISABLED, started=started)

        # ۲) RAM قبل از inference (بخشِ ۲۱ سند)
        ram = check_ram_budget(self.config.max_ram_mb)
        if not ram.ok:
            return self._fallback(FallbackReason.RAM_LIMIT, started=started, error=ram.reason)

        # ۳) اطمینان از بارگذاریِ آداپتور
        if not self.adapter.is_loaded:
            load_result = self.adapter.load()
            if not load_result.ok:
                return self._fallback(
                    FallbackReason.LOAD_FAILED, started=started, error=load_result.error
                )

        # ۴) اجرا زیرِ timeout
        timeout_outcome = run_with_timeout(
            self._run_adapter, self.config.timeout_ms, text, max_new_tokens
        )

        if timeout_outcome.timed_out:
            return self._fallback(FallbackReason.TIMEOUT, started=started, timed_out=True)

        if not timeout_outcome.completed:
            return self._fallback(
                FallbackReason.EXCEPTION, started=started, error=timeout_outcome.error
            )

        latency_ms = (time.monotonic() - started) * 1000.0
        outcome = InferenceOutcome(
            success=True,
            output=timeout_outcome.result,
            model_version=self.adapter.model_version,
            tokenizer_version=self.adapter.tokenizer_version,
            latency_ms=latency_ms,
        )
        self.telemetry.record(
            mode=self.config.mode.value,
            success=True,
            latency_ms=latency_ms,
            ram_mb=ram.current_mb,
            ram_measured=ram.measured,
        )
        return outcome

    def _run_adapter(self, text: str, max_new_tokens: int) -> str:
        """پوششِ نازکِ فراخوانی -- جداشده تا ``run_with_timeout`` بتواند
        آن را در یک نخِ جدا اجرا کند."""
        try:
            return self.adapter.trial_generate(text, max_new_tokens=max_new_tokens)
        except NeuralAdapterNotLoadedError:
            # بینِ مرحله‌ی «بررسیِ is_loaded» و اجرا، نظری وضعیت عوض
            # نمی‌شود (این سرویس تک‌نخی مصرف می‌شود) اما محافظه‌کارانه
            # به‌جای فرض، صریح دوباره raise می‌کنیم تا لایه‌ی timeout آن
            # را به‌عنوانِ خطا (نه موفقیت) ثبت کند.
            raise

    # ------------------------------------------------------------- misc --
    def shutdown(self) -> None:
        """آزادسازیِ منابعِ مدل -- برایِ استفاده در تست/چرخه‌ی عمرِ سرویس."""
        self.adapter.unload()
