# -*- coding: utf-8 -*-
"""Stage 4: Shadow Mode, live-state bridge, and evaluation dataset."""
from __future__ import annotations

import tempfile
import unittest
from dataclasses import dataclass
from pathlib import Path

from trx_ai.conversation.schemas import ContextSnapshot
from trx_ai.phase3.config import Phase3Config, Phase3Mode
from trx_ai.phase3.evaluation_dataset import EvaluationDatasetWriter
from trx_ai.phase3.inference_service import InferenceOutcome
from trx_ai.phase3.shadow import Phase3ShadowRunner


class FakeService:
    def __init__(self) -> None:
        self.calls = []

    def run_trial(self, text: str, max_new_tokens: int = 16) -> InferenceOutcome:
        self.calls.append((text, max_new_tokens))
        return InferenceOutcome(
            success=True,
            output="امروز کنکور دادم و خیلی خوشحالم",
            model_version="fake-model",
            tokenizer_version="fake-tokenizer",
            latency_ms=1.25,
        )

    def shutdown(self) -> None:
        pass


@dataclass
class FakeDecision:
    route: str = "conversation"
    selected_intent: str = "general"
    confidence: float = 0.91


@dataclass
class FakeEmotion:
    emotion: str = "happy"
    intensity: float = 0.7


class TestStage4Shadow(unittest.TestCase):
    def test_shadow_records_symbolic_and_neural_without_mutating_context(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "dataset.jsonl"
            dataset = EvaluationDatasetWriter(path)
            service = FakeService()
            cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, max_ram_mb=4096.0)
            runner = Phase3ShadowRunner(config=cfg, service=service, dataset=dataset)
            context = ContextSnapshot(
                active_topic="کنکور",
                current_emotion="happy",
                previous_emotion="tired",
                emotion_intensity=0.8,
                known_cause="آزمون",
            )
            record = runner.observe(
                raw_text="اما واقعاً خوشحالم",
                normalized_text="اما واقعاً خوشحالم",
                conversation_id="c1",
                context=context,
                recent_messages=["امروز خیلی خسته شدم", "کنکور دادم"],
                symbolic_relation="contrast",
                symbolic_decision=FakeDecision(),
                symbolic_emotion=FakeEmotion(),
            )
            self.assertIsNotNone(record)
            self.assertEqual(service.calls[0][0], "اما واقعاً خوشحالم")
            self.assertEqual(record.neural["output"], "امروز کنکور دادم و خیلی خوشحالم")
            self.assertEqual(record.symbolic["active_topic"], "کنکور")
            self.assertEqual(record.comparison["status"], "raw_neural_output_only")
            self.assertIsNone(record.comparison["structured_agreement_score"])
            self.assertEqual(context.current_emotion, "happy")
            self.assertEqual(len(dataset.read_recent()), 1)

    def test_disabled_or_non_shadow_never_runs_inference(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            service = FakeService()
            cfg = Phase3Config(enabled=False, mode=Phase3Mode.DISABLED)
            runner = Phase3ShadowRunner(
                config=cfg,
                service=service,
                dataset=EvaluationDatasetWriter(Path(td) / "dataset.jsonl"),
            )
            record = runner.observe(
                raw_text="سلام",
                normalized_text="سلام",
                conversation_id="c1",
                context=ContextSnapshot(),
            )
            self.assertIsNone(record)
            self.assertEqual(service.calls, [])

    def test_dataset_writer_is_fail_soft(self) -> None:
        writer = EvaluationDatasetWriter("/dev/null/impossible/path.jsonl")
        self.assertFalse(writer.append({"x": 1}))


if __name__ == "__main__":
    unittest.main()

class TestControlledFusion(unittest.TestCase):
    def test_controlled_runner_accepts_only_conversation(self) -> None:
        from trx_ai.phase3.controlled_fusion import ControlledFusionRunner
        cfg = Phase3Config(enabled=True, mode=Phase3Mode.CONTROLLED_FUSION, min_confidence=0.55, max_ram_mb=4096.0)
        service = FakeService(); runner = ControlledFusionRunner(config=cfg, service=service)
        draft = runner.try_advice(conversation_id='c2', text='امروز کنکور دادم و خیلی خوشحالم',
                                   recent_messages=['امروز خیلی خسته شدم','کنکور دادم'],
                                   symbolic_route='conversation', symbolic_intent='general', symbolic_confidence=0.9)
        self.assertIsNotNone(draft); self.assertEqual(runner.consume('c2'), draft); self.assertIsNone(runner.consume('c2'))
        self.assertIsNone(runner.try_advice(conversation_id='c3', text='قیمت دلار چنده؟',
                                            symbolic_route='tool', symbolic_intent='currency', symbolic_confidence=0.99))
        runner.shutdown()
