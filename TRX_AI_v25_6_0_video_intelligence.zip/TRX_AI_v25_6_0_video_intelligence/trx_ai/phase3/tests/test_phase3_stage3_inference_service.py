# -*- coding: utf-8 -*-
"""
تست‌هایِ مرحله‌ی ۳ فاز ۳ (``inference_service.py`` + ``latency_guard.py``
+ ``fallback.py`` + ``telemetry.py``).

طبقِ متنِ صریحِ برنامه‌ی مرحله‌ایِ سند (بخشِ ۱۹):

    مرحله ۳:
    - ساخت Inference Service
    - timeout
    - resource guard
    - fallback
    - telemetry

هر پنج مورد اینجا پوشش داده شده -- به‌اضافه‌ی اصلِ غیرقابلِ‌مذاکره‌ی ۴
و ۹ سند («خرابی نباید مکالمه را متوقف کند» / «قابلِ خاموش‌کردن»).

با ``unittest`` استاندارد (نه ``pytest``) -- همان دلیلِ محیطیِ بقیه‌ی
تست‌هایِ فاز ۳.
"""

from __future__ import annotations

import os
import time
import unittest

from trx_ai.phase3.config import Phase3Config, Phase3Mode
from trx_ai.phase3.fallback import FallbackReason, describe
from trx_ai.phase3.inference_service import InferenceOutcome, Phase3InferenceService
from trx_ai.phase3.latency_guard import check_ram_budget, run_with_timeout
from trx_ai.phase3.neural_adapter import NeuralAdapter
from trx_ai.phase3.telemetry import TelemetryLog
from trx_ai.trx_model.model_adapter import DEFAULT_TOKENIZER_PATH

_TOKENIZER_AVAILABLE = os.path.exists(DEFAULT_TOKENIZER_PATH)


# ==========================================================
#   latency_guard.py
# ==========================================================
class TestRunWithTimeout(unittest.TestCase):
    def test_fast_function_completes(self) -> None:
        outcome = run_with_timeout(lambda: 41 + 1, 1000.0)
        self.assertTrue(outcome.completed)
        self.assertFalse(outcome.timed_out)
        self.assertEqual(outcome.result, 42)

    def test_slow_function_times_out(self) -> None:
        def _slow():
            time.sleep(0.2)
            return "late"

        outcome = run_with_timeout(_slow, 1.0)  # 1ms مهلت
        self.assertFalse(outcome.completed)
        self.assertTrue(outcome.timed_out)

    def test_exception_is_captured_not_raised(self) -> None:
        def _boom():
            raise ValueError("boom")

        outcome = run_with_timeout(_boom, 1000.0)
        self.assertFalse(outcome.completed)
        self.assertFalse(outcome.timed_out)
        self.assertIn("boom", outcome.error or "")


class TestCheckRamBudget(unittest.TestCase):
    def test_generous_budget_passes(self) -> None:
        check = check_ram_budget(max_ram_mb=1_000_000.0)
        self.assertTrue(check.ok)

    def test_tiny_budget_fails_when_measurable(self) -> None:
        check = check_ram_budget(max_ram_mb=0.0001)
        if check.measured:
            self.assertFalse(check.ok)
            self.assertIsNotNone(check.reason)
        else:
            # psutil نصب نیست -- نباید مانعِ inference شویم.
            self.assertTrue(check.ok)


# ==========================================================
#   fallback.py
# ==========================================================
class TestFallbackDescriptions(unittest.TestCase):
    def test_every_reason_has_a_description(self) -> None:
        for reason in FallbackReason:
            text = describe(reason)
            self.assertIsInstance(text, str)
            self.assertTrue(text)


# ==========================================================
#   telemetry.py
# ==========================================================
class TestTelemetryLog(unittest.TestCase):
    def test_record_and_recent(self) -> None:
        log = TelemetryLog(maxlen=10)
        log.record(mode="shadow", success=True, latency_ms=12.5)
        log.record(mode="shadow", success=False, fallback_used=True, fallback_reason=FallbackReason.TIMEOUT)
        self.assertEqual(len(log), 2)
        recent = log.recent(1)
        self.assertEqual(len(recent), 1)
        self.assertEqual(recent[0].fallback_reason, FallbackReason.TIMEOUT.value)

    def test_bounded_by_maxlen(self) -> None:
        log = TelemetryLog(maxlen=3)
        for i in range(10):
            log.record(mode="shadow", success=True, latency_ms=float(i))
        self.assertEqual(len(log), 3)

    def test_summary_on_empty_log(self) -> None:
        log = TelemetryLog()
        summary = log.summary()
        self.assertEqual(summary["count"], 0)
        self.assertIsNone(summary["success_rate"])

    def test_summary_computes_rates(self) -> None:
        log = TelemetryLog()
        log.record(mode="shadow", success=True, latency_ms=10.0)
        log.record(mode="shadow", success=False, fallback_used=True, timed_out=True, latency_ms=20.0)
        summary = log.summary()
        self.assertEqual(summary["count"], 2)
        self.assertAlmostEqual(summary["success_rate"], 0.5)
        self.assertAlmostEqual(summary["fallback_rate"], 0.5)
        self.assertAlmostEqual(summary["timeout_rate"], 0.5)
        self.assertAlmostEqual(summary["avg_latency_ms"], 15.0)


# ==========================================================
#   inference_service.py -- orchestration
# ==========================================================
class TestPhase3InferenceServiceDisabled(unittest.TestCase):
    def test_default_config_is_disabled_and_falls_back_immediately(self) -> None:
        service = Phase3InferenceService()
        outcome = service.run_trial("سلام")
        self.assertFalse(outcome.success)
        self.assertTrue(outcome.fallback_used)
        self.assertEqual(outcome.fallback_reason, FallbackReason.DISABLED)
        self.assertIsNone(outcome.output)

    def test_disabled_path_never_touches_adapter(self) -> None:
        adapter = NeuralAdapter()
        service = Phase3InferenceService(adapter=adapter)
        service.run_trial("سلام")
        self.assertFalse(adapter.is_loaded)

    def test_disabled_path_records_telemetry(self) -> None:
        service = Phase3InferenceService()
        service.run_trial("سلام")
        self.assertEqual(len(service.telemetry), 1)
        self.assertFalse(service.telemetry.recent(1)[0].success)


class TestPhase3InferenceServiceRamGuard(unittest.TestCase):
    def test_ram_over_budget_falls_back_without_loading(self) -> None:
        cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, max_ram_mb=0.0001)
        adapter = NeuralAdapter(cfg)
        service = Phase3InferenceService(config=cfg, adapter=adapter)
        outcome = service.run_trial("سلام")
        if outcome.fallback_reason == FallbackReason.RAM_LIMIT:
            self.assertFalse(outcome.success)
            self.assertFalse(adapter.is_loaded)
        else:
            # psutil نصب نیست -- بررسیِ RAM قابلِ‌اتکا نبود، مسیرِ عادی رفت.
            pass


@unittest.skipUnless(
    _TOKENIZER_AVAILABLE, f"توکنایزرِ پیش‌فرض یافت نشد: {DEFAULT_TOKENIZER_PATH}"
)
class TestPhase3InferenceServiceSuccessPath(unittest.TestCase):
    def test_enabled_shadow_mode_runs_and_returns_output(self) -> None:
        cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, timeout_ms=5000.0, max_ram_mb=4096.0)
        service = Phase3InferenceService(config=cfg)
        outcome = service.run_trial("امروز خیلی خسته شدم", max_new_tokens=4)
        self.assertTrue(outcome.success, outcome.error)
        self.assertIsInstance(outcome.output, str)
        self.assertIsNotNone(outcome.model_version)
        self.assertIsNotNone(outcome.tokenizer_version)
        self.assertFalse(outcome.fallback_used)
        service.shutdown()

    def test_adapter_is_reused_across_calls_not_reloaded(self) -> None:
        cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, timeout_ms=5000.0, max_ram_mb=4096.0)
        service = Phase3InferenceService(config=cfg)
        service.run_trial("پیام اول", max_new_tokens=2)
        version_after_first = service.adapter.model_version
        service.run_trial("پیام دوم", max_new_tokens=2)
        self.assertEqual(service.adapter.model_version, version_after_first)
        service.shutdown()

    def test_load_failure_produces_fallback_not_exception(self) -> None:
        os.environ["TRX_PHASE3_CHECKPOINT_PATH"] = "/tmp/nonexistent-phase3-checkpoint"
        try:
            cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, timeout_ms=5000.0, max_ram_mb=4096.0)
            service = Phase3InferenceService(config=cfg)
            outcome = service.run_trial("سلام")
            self.assertFalse(outcome.success)
            self.assertEqual(outcome.fallback_reason, FallbackReason.LOAD_FAILED)
        finally:
            del os.environ["TRX_PHASE3_CHECKPOINT_PATH"]

    def test_timeout_produces_fallback_not_exception(self) -> None:
        cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, timeout_ms=0.001, max_ram_mb=4096.0)
        service = Phase3InferenceService(config=cfg)
        outcome = service.run_trial("سلام", max_new_tokens=32)
        self.assertFalse(outcome.success)
        self.assertTrue(outcome.timed_out)
        self.assertEqual(outcome.fallback_reason, FallbackReason.TIMEOUT)

    def test_outcome_is_always_inference_outcome_type(self) -> None:
        cfg = Phase3Config(enabled=True, mode=Phase3Mode.SHADOW, timeout_ms=5000.0, max_ram_mb=4096.0)
        service = Phase3InferenceService(config=cfg)
        outcome = service.run_trial("سلام")
        self.assertIsInstance(outcome, InferenceOutcome)
        service.shutdown()


if __name__ == "__main__":
    unittest.main()
