# -*- coding: utf-8 -*-
"""
تست‌هایِ مرحله‌ی ۱ فاز ۳ (schemas + config + feature_builder).

عمداً با ``unittest`` استاندارد نوشته شده، نه ``pytest`` -- در این
sandbox آفلاین ``pytest`` نصب نیست (نگاه کن به یادداشت‌هایِ محیط)، و
چون این ماژول‌ها هیچ fixture/asyncی لازم ندارند، ``unittest`` بدونِ
هیچ shim یا وابستگیِ بیرونی مستقیماً با
``python3 -m unittest discover`` اجرا و تأیید می‌شود -- تا خودِ تستِ
مرحله‌ی ۱ هم به هیچ ابزارِ نصب‌نشده وابسته نباشد.
"""

from __future__ import annotations

import os
import unittest

from trx_ai.conversation.schemas import ContextSnapshot, IntentCandidate, MessageRecord
from trx_ai.phase3 import config as phase3_config
from trx_ai.phase3.config import ALL_TASKS, Phase3Config, Phase3Mode, ROLLOUT_ORDER, get_config
from trx_ai.phase3.feature_builder import build_features
from trx_ai.phase3.schemas import (
    DecisionSource,
    DiscourseRelation,
    FusionDecision,
    NeuralAdvice,
    NeuralInputFeatures,
    ResponseMode,
)

_ENV_KEYS = (
    "TRX_PHASE3_ENABLED",
    "TRX_PHASE3_MODE",
    "TRX_PHASE3_TIMEOUT_MS",
    "TRX_PHASE3_MAX_RAM_MB",
    "TRX_PHASE3_MIN_CONFIDENCE",
    "TRX_PHASE3_MAX_HISTORY_MESSAGES",
    "TRX_PHASE3_MAX_HISTORY_CHARS",
    "TRX_PHASE3_ENABLED_TASKS",
)


class _EnvIsolatedCase(unittest.TestCase):
    """قبل/بعدِ هر تست، متغیرهایِ محیطیِ فاز ۳ را پاک می‌کند تا تست‌ها
    به ترتیبِ اجرا یا محیطِ سیستم وابسته نباشند."""

    def setUp(self) -> None:
        self._saved = {k: os.environ.get(k) for k in _ENV_KEYS}
        for k in _ENV_KEYS:
            os.environ.pop(k, None)

    def tearDown(self) -> None:
        for k, v in self._saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


# ==========================================================
#   config.py
# ==========================================================
class TestPhase3Config(_EnvIsolatedCase):
    def test_default_is_fully_disabled(self) -> None:
        cfg = get_config()
        self.assertFalse(cfg.enabled)
        self.assertEqual(cfg.mode, Phase3Mode.DISABLED)

    def test_mode_forced_disabled_when_not_enabled(self) -> None:
        # حتیِ اگر کسی مود را shadow بگذارد، بدونِ ENABLED=true باید
        # DISABLED بماند -- طبقِ اصلِ سند: اتصال باید قابلِ‌خاموش‌کردن
        # مرکزی باشد.
        os.environ["TRX_PHASE3_MODE"] = "shadow"
        cfg = get_config()
        self.assertFalse(cfg.enabled)
        self.assertEqual(cfg.mode, Phase3Mode.DISABLED)

    def test_enabled_with_valid_mode(self) -> None:
        os.environ["TRX_PHASE3_ENABLED"] = "true"
        os.environ["TRX_PHASE3_MODE"] = "shadow"
        cfg = get_config()
        self.assertTrue(cfg.enabled)
        self.assertEqual(cfg.mode, Phase3Mode.SHADOW)

    def test_invalid_mode_falls_back_to_disabled_not_crash(self) -> None:
        os.environ["TRX_PHASE3_ENABLED"] = "true"
        os.environ["TRX_PHASE3_MODE"] = "totally_not_a_real_mode"
        cfg = get_config()
        self.assertEqual(cfg.mode, Phase3Mode.DISABLED)

    def test_numeric_overrides_respected(self) -> None:
        os.environ["TRX_PHASE3_TIMEOUT_MS"] = "999"
        os.environ["TRX_PHASE3_MIN_CONFIDENCE"] = "0.8"
        os.environ["TRX_PHASE3_MAX_HISTORY_MESSAGES"] = "3"
        cfg = get_config()
        self.assertEqual(cfg.timeout_ms, 999.0)
        self.assertEqual(cfg.min_confidence, 0.8)
        self.assertEqual(cfg.max_history_messages, 3)

    def test_rollout_order_matches_enum_and_starts_disabled(self) -> None:
        self.assertEqual(ROLLOUT_ORDER[0], Phase3Mode.DISABLED)
        self.assertEqual(set(ROLLOUT_ORDER), set(Phase3Mode))
        self.assertEqual(len(ROLLOUT_ORDER), len(set(ROLLOUT_ORDER)))

    def test_default_enabled_tasks_excludes_draft(self) -> None:
        cfg = get_config()
        self.assertIn("topic", cfg.enabled_tasks)
        self.assertNotIn("draft", cfg.enabled_tasks)
        self.assertTrue(cfg.task_enabled("emotion"))
        self.assertFalse(cfg.task_enabled("draft"))

    def test_enabled_tasks_env_override(self) -> None:
        os.environ["TRX_PHASE3_ENABLED_TASKS"] = "topic,emotion"
        cfg = get_config()
        self.assertEqual(cfg.enabled_tasks, ("topic", "emotion"))

    def test_enabled_tasks_invalid_falls_back_to_default(self) -> None:
        os.environ["TRX_PHASE3_ENABLED_TASKS"] = "topic,not_a_real_task"
        cfg = get_config()
        self.assertEqual(cfg.enabled_tasks, phase3_config._DEFAULT_ENABLED_TASKS)

    def test_config_validates_confidence_bounds(self) -> None:
        with self.assertRaises(ValueError):
            Phase3Config(min_confidence=1.5)
        with self.assertRaises(ValueError):
            Phase3Config(min_confidence=-0.1)

    def test_config_validates_positive_limits(self) -> None:
        with self.assertRaises(ValueError):
            Phase3Config(timeout_ms=0)
        with self.assertRaises(ValueError):
            Phase3Config(max_history_messages=0)
        with self.assertRaises(ValueError):
            Phase3Config(max_history_chars=0)

    def test_config_is_frozen(self) -> None:
        cfg = get_config()
        with self.assertRaises(Exception):
            cfg.enabled = True  # type: ignore[misc]

    def test_all_tasks_are_unique(self) -> None:
        self.assertEqual(len(ALL_TASKS), len(set(ALL_TASKS)))


# ==========================================================
#   schemas.py
# ==========================================================
class TestPhase3Schemas(unittest.TestCase):
    def test_neural_advice_defaults_are_safe(self) -> None:
        advice = NeuralAdvice()
        self.assertEqual(advice.confidence, 0.0)
        self.assertEqual(advice.intent_candidates, ())
        self.assertEqual(advice.warnings, ())
        self.assertIsNone(advice.draft)

    def test_fusion_decision_defaults_favor_symbolic(self) -> None:
        decision = FusionDecision()
        # اصلِ ۸ سند («در تعارض شدید، سیستم نمادین یا fallback کنترل
        # را حفظ می‌کند») یعنی پیش‌فرضِ decision_source هرگز نباید
        # neural باشد.
        self.assertEqual(decision.decision_source, DecisionSource.SYMBOLIC)
        self.assertTrue(decision.tool_allowed)
        self.assertFalse(decision.fallback_used)

    def test_discourse_relation_matches_document_section_5_2(self) -> None:
        expected = {
            "continuation",
            "cause",
            "effect",
            "clarification",
            "correction",
            "contrast",
            "answer_to_previous_question",
            "emotional_update",
            "topic_shift",
            "unrelated",
        }
        actual = {member.value for member in DiscourseRelation}
        self.assertEqual(actual, expected)

    def test_response_mode_matches_document_section_5_6(self) -> None:
        expected = {
            "empathetic_reflection",
            "direct_answer",
            "clarification",
            "explanation",
            "encouragement",
            "concise_acknowledgment",
            "followup_question",
            "repair_response",
            "tool_response",
        }
        actual = {member.value for member in ResponseMode}
        self.assertEqual(actual, expected)

    def test_neural_advice_accepts_enum_fields(self) -> None:
        advice = NeuralAdvice(
            relation=DiscourseRelation.EMOTIONAL_UPDATE,
            response_mode=ResponseMode.EMPATHETIC_REFLECTION,
            confidence=0.9,
        )
        self.assertEqual(advice.relation, DiscourseRelation.EMOTIONAL_UPDATE)
        self.assertEqual(advice.response_mode, ResponseMode.EMPATHETIC_REFLECTION)


# ==========================================================
#   feature_builder.py
# ==========================================================
class TestBuildFeatures(unittest.TestCase):
    def setUp(self) -> None:
        self.small_history_config = Phase3Config(max_history_messages=2, max_history_chars=1000)

    def test_maps_context_snapshot_fields(self) -> None:
        ctx = ContextSnapshot(
            active_topic="exam",
            recent_topics=("exam", "school"),
            current_emotion="happy",
            previous_emotion="tired",
            emotion_intensity=0.7,
            known_cause="exam",
            recent_event="exam_completed",
            conversation_mode="casual",
            user_goal=None,
            unanswered_question=None,
        )
        features = build_features(
            "اما واقعاً خوشحالم",
            "اما واقعا خوشحالم",
            ctx,
            config=self.small_history_config,
        )
        self.assertIsInstance(features, NeuralInputFeatures)
        self.assertEqual(features.active_topic, "exam")
        self.assertEqual(features.recent_topics, ("exam", "school"))
        self.assertEqual(features.current_emotion, "happy")
        self.assertEqual(features.previous_emotion, "tired")
        self.assertEqual(features.emotion_intensity, 0.7)
        self.assertEqual(features.known_cause, "exam")
        self.assertEqual(features.pending_question, None)

    def test_history_truncated_by_message_count(self) -> None:
        ctx = ContextSnapshot()
        features = build_features(
            "پیام سوم",
            "پیام سوم",
            ctx,
            recent_messages=["پیام اول", "پیام دوم", "پیام سوم قبلی"],
            config=self.small_history_config,  # max_history_messages=2
        )
        self.assertEqual(len(features.history_summary), 2)
        # جدیدترین دوتا باید بمانند (ترتیب: جدیدترین آخر)
        self.assertEqual(features.history_summary[-1], "پیام سوم قبلی")
        self.assertTrue(features.history_truncated)

    def test_no_truncation_when_within_limits(self) -> None:
        ctx = ContextSnapshot()
        features = build_features(
            "متن",
            "متن",
            ctx,
            recent_messages=["سلام"],
            config=self.small_history_config,
        )
        self.assertEqual(features.history_summary, ("سلام",))
        self.assertFalse(features.history_truncated)

    def test_history_truncated_by_char_budget(self) -> None:
        cfg = Phase3Config(max_history_messages=10, max_history_chars=20)
        ctx = ContextSnapshot()
        features = build_features(
            "متن",
            "متن",
            ctx,
            recent_messages=["ک" * 15, "خ" * 15],  # هر کدام به‌تنهایی زیرِ سقف، هر دو باهم بیشتر
            config=cfg,
        )
        self.assertTrue(features.history_truncated)
        # فقط جدیدترین پیام باید مانده باشد
        self.assertEqual(len(features.history_summary), 1)
        self.assertEqual(features.history_summary[0], "خ" * 15)

    def test_accepts_message_record_objects(self) -> None:
        ctx = ContextSnapshot()
        record = MessageRecord(
            message_id="m1",
            raw_text="سلام خام",
            normalized_text="سلام نرمال",
        )
        features = build_features(
            "متن",
            "متن",
            ctx,
            recent_messages=[record],
            config=self.small_history_config,
        )
        self.assertEqual(features.history_summary, ("سلام نرمال",))

    def test_empty_history_is_not_truncated(self) -> None:
        ctx = ContextSnapshot()
        features = build_features("متن", "متن", ctx, config=self.small_history_config)
        self.assertEqual(features.history_summary, ())
        self.assertFalse(features.history_truncated)
        self.assertEqual(features.history_char_count, 0)

    def test_symbolic_intent_candidates_are_flattened_to_names(self) -> None:
        ctx = ContextSnapshot()
        candidates = [
            IntentCandidate(name="web_search", score=0.4),
            IntentCandidate(name="conversation", score=0.9),
        ]
        features = build_features(
            "متن",
            "متن",
            ctx,
            intent_candidates=candidates,
            config=self.small_history_config,
        )
        self.assertEqual(features.symbolic_intent_names, ("web_search", "conversation"))

    def test_uses_get_config_when_no_config_passed(self) -> None:
        # بدونِ config صریح، نباید crash کند -- باید از get_config() امنِ
        # پیش‌فرض استفاده کند.
        ctx = ContextSnapshot()
        features = build_features("متن", "متن", ctx)
        self.assertIsInstance(features, NeuralInputFeatures)


if __name__ == "__main__":
    unittest.main()
