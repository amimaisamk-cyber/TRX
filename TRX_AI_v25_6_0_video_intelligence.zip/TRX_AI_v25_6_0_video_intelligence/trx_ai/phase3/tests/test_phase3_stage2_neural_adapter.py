# -*- coding: utf-8 -*-
"""
تست‌هایِ مرحله‌ی ۲ فاز ۳ (``neural_adapter.py``).

طبقِ متنِ صریحِ برنامه‌ی مرحله‌ایِ سند (بخشِ ۱۹):

    مرحله ۲:
    - اتصال Neural Adapter به trx_model
    - فقط inference آزمایشی
    - تست load/unload
    - تست سازگاری tokenizer/model

همین چهار مورد اینجا پوشش داده شده‌اند -- بدونِ فرضِ وجودِ
``task_heads``/``fusion_engine`` (مراحلِ بعدی).

با ``unittest`` استاندارد (نه ``pytest``) -- همان دلیلِ محیطیِ
``test_phase3_foundation.py``.
"""

from __future__ import annotations

import os
import tempfile
import unittest

import numpy as np

from trx_ai.phase3.config import Phase3Config
from trx_ai.phase3.neural_adapter import (
    AdapterState,
    NeuralAdapter,
    NeuralAdapterNotLoadedError,
)
from trx_ai.trx_model.model import TRXModelConfig, TRXNativeModel
from trx_ai.trx_model.model_adapter import DEFAULT_TOKENIZER_PATH
from trx_ai.trx_model.tokenizer import ByteLevelBPETokenizer
from trx_ai.trx_model.training.autograd_cache import build_param_map


def _default_tokenizer_available() -> bool:
    return os.path.exists(DEFAULT_TOKENIZER_PATH)


@unittest.skipUnless(
    _default_tokenizer_available(),
    f"توکنایزرِ پیش‌فرض یافت نشد: {DEFAULT_TOKENIZER_PATH}",
)
class TestNeuralAdapterLoadUnload(unittest.TestCase):
    def test_starts_unloaded(self) -> None:
        adapter = NeuralAdapter()
        self.assertEqual(adapter.state, AdapterState.UNLOADED)
        self.assertFalse(adapter.is_loaded)
        self.assertIsNone(adapter.model_version)
        self.assertIsNone(adapter.tokenizer_version)

    def test_load_succeeds_with_default_tokenizer(self) -> None:
        adapter = NeuralAdapter()
        result = adapter.load()
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.state, AdapterState.LOADED)
        self.assertTrue(adapter.is_loaded)
        self.assertIsNotNone(result.model_version)
        self.assertIsNotNone(result.tokenizer_version)
        self.assertGreater(result.param_count, 0)
        adapter.unload()

    def test_unload_resets_state_and_frees_references(self) -> None:
        adapter = NeuralAdapter()
        adapter.load()
        self.assertTrue(adapter.is_loaded)
        adapter.unload()
        self.assertEqual(adapter.state, AdapterState.UNLOADED)
        self.assertFalse(adapter.is_loaded)
        self.assertIsNone(adapter.model_version)
        self.assertIsNone(adapter.tokenizer_version)
        self.assertIsNone(adapter._adapter)  # noqa: SLF001 -- تستِ داخلی عمدی

    def test_reload_after_unload_works(self) -> None:
        adapter = NeuralAdapter()
        adapter.load()
        adapter.unload()
        result = adapter.load()
        self.assertTrue(result.ok, result.error)
        self.assertTrue(adapter.is_loaded)
        adapter.unload()

    def test_load_never_raises_on_missing_tokenizer(self) -> None:
        adapter = NeuralAdapter()
        # شبیه‌سازیِ نبودِ توکنایزر بدونِ لمسِ فایلِ واقعی روی دیسک:
        # مستقیماً مسیرِ نامعتبر را جایگزین می‌کنیم تا مطمئن شویم
        # ``load`` هیچ‌وقت raw exception پرتاب نمی‌کند.
        import trx_ai.phase3.neural_adapter as na_module

        original = na_module.DEFAULT_TOKENIZER_PATH
        na_module.DEFAULT_TOKENIZER_PATH = "/tmp/definitely-does-not-exist.json"
        try:
            result = adapter.load()
            self.assertFalse(result.ok)
            self.assertEqual(result.state, AdapterState.ERROR)
            self.assertIsNotNone(result.error)
        finally:
            na_module.DEFAULT_TOKENIZER_PATH = original


@unittest.skipUnless(
    _default_tokenizer_available(),
    f"توکنایزرِ پیش‌فرض یافت نشد: {DEFAULT_TOKENIZER_PATH}",
)
class TestNeuralAdapterCompatibility(unittest.TestCase):
    def test_compatible_when_loaded_normally(self) -> None:
        adapter = NeuralAdapter()
        adapter.load()
        check = adapter.check_compatibility()
        self.assertTrue(check.compatible, check.reason)
        adapter.unload()

    def test_incompatible_when_not_loaded(self) -> None:
        adapter = NeuralAdapter()
        check = adapter.check_compatibility()
        self.assertFalse(check.compatible)
        self.assertIsNotNone(check.reason)

    def test_load_rejects_checkpoint_with_mismatched_vocab(self) -> None:
        """یک checkpoint جعلی با vocab_size اشتباه بساز و مطمئن شو
        ``load`` صریحاً شکست می‌خورد (بدونِ سکوت رویِ ناهم‌خوانی --
        طبقِ اصلِ سند)."""
        tokenizer = ByteLevelBPETokenizer.load(DEFAULT_TOKENIZER_PATH)
        wrong_vocab = tokenizer.vocab_size + 5
        fake_model_config = TRXModelConfig(vocab_size=wrong_vocab, d_model=8, n_layers=1, n_heads=2, d_ff=16)
        fake_model = TRXNativeModel(fake_model_config)
        params = build_param_map(fake_model)

        with tempfile.TemporaryDirectory() as tmp:
            ckpt_path = os.path.join(tmp, "fake_ckpt")
            payload = {f"param::{k}": v for k, v in params.items()}
            np.savez(ckpt_path + ".weights.npz", **payload)
            import json

            with open(ckpt_path + ".meta.json", "w", encoding="utf-8") as f:
                json.dump({"tokenizer_vocab_size": wrong_vocab}, f)

            adapter = NeuralAdapter()
            result = adapter.load(checkpoint_path=ckpt_path)
            self.assertFalse(result.ok)
            self.assertIn("vocab_size", result.error or "")


@unittest.skipUnless(
    _default_tokenizer_available(),
    f"توکنایزرِ پیش‌فرض یافت نشد: {DEFAULT_TOKENIZER_PATH}",
)
class TestNeuralAdapterTrialGenerate(unittest.TestCase):
    def test_trial_generate_raises_when_not_loaded(self) -> None:
        adapter = NeuralAdapter()
        with self.assertRaises(NeuralAdapterNotLoadedError):
            adapter.trial_generate("سلام")

    def test_trial_generate_returns_text_when_loaded(self) -> None:
        adapter = NeuralAdapter()
        adapter.load()
        out = adapter.trial_generate("امروز خیلی خسته شدم", max_new_tokens=4)
        self.assertIsInstance(out, str)
        adapter.unload()

    def test_trial_generate_raises_again_after_unload(self) -> None:
        adapter = NeuralAdapter()
        adapter.load()
        adapter.unload()
        with self.assertRaises(NeuralAdapterNotLoadedError):
            adapter.trial_generate("سلام")


if __name__ == "__main__":
    unittest.main()
