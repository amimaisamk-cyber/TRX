# -*- coding: utf-8 -*-
"""
Telemetry فاز ۳ (سندِ P3.0، بخشِ ۶ -- ``telemetry.py``: «ثبتِ زمان /
RAM / confidence / اختلافِ تحلیل‌ها / خطا / route نهایی»).

**محدوده‌ی این مرحله (۳ از ۱۰):** چون ``confidence`` واقعی (خروجیِ
``task_heads.py``)، «اختلافِ تحلیل‌ها» (خروجیِ ``fusion_engine.py``، Shadow
Mode) و «route نهایی» هنوز وجود ندارند -- آن‌ها مراحلِ ۴ به بعدِ سند
هستند -- این نسخه فقط زیرمجموعه‌ای را ثبت می‌کند که در مرحله‌ی ۳ واقعاً
تولید می‌شود: زمان، RAM، موفقیت/شکست، تایم‌اوت، دلیلِ fallback و خطا.
افزودنِ فیلدهایِ باقی‌مانده بدونِ شکستنِ این ساختار در مراحلِ بعدی ممکن
است (``dataclass`` قابلِ گسترش است).

پیاده‌سازی عمداً هم‌الگو با ``core_engine/trace.py`` (``TraceRecorder``/
``TraceLog``): بافرِ محدود در حافظه (بدونِ I/O دیسک، بدونِ وابستگیِ
جدید)، fail-soft -- خودِ ثبت‌کردن هرگز نباید مسیرِ inference را خراب
کند.
"""

from __future__ import annotations

import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Deque, Optional

from .fallback import FallbackReason

__all__ = ["InferenceTelemetryRecord", "TelemetryLog"]

_DEFAULT_MAXLEN = 200


@dataclass
class InferenceTelemetryRecord:
    record_id: str
    timestamp: float

    mode: str  # Phase3Mode.value در لحظه‌ی ثبت
    success: bool
    timed_out: bool = False
    fallback_used: bool = False
    fallback_reason: Optional[str] = None
    error: Optional[str] = None

    latency_ms: float = 0.0
    ram_mb: Optional[float] = None
    ram_measured: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


class TelemetryLog:
    """بافرِ محدودِ درون‌حافظه‌ای -- دقیقاً هم‌الگو با ``TraceLog``."""

    def __init__(self, maxlen: int = _DEFAULT_MAXLEN) -> None:
        self._records: Deque[InferenceTelemetryRecord] = deque(maxlen=maxlen)

    def record(
        self,
        *,
        mode: str,
        success: bool,
        timed_out: bool = False,
        fallback_used: bool = False,
        fallback_reason: Optional[FallbackReason] = None,
        error: Optional[str] = None,
        latency_ms: float = 0.0,
        ram_mb: Optional[float] = None,
        ram_measured: bool = False,
    ) -> InferenceTelemetryRecord:
        rec = InferenceTelemetryRecord(
            record_id=uuid.uuid4().hex[:8],
            timestamp=time.time(),
            mode=mode,
            success=success,
            timed_out=timed_out,
            fallback_used=fallback_used,
            fallback_reason=(fallback_reason.value if fallback_reason else None),
            error=error,
            latency_ms=latency_ms,
            ram_mb=ram_mb,
            ram_measured=ram_measured,
        )
        self._records.append(rec)
        return rec

    def recent(self, n: Optional[int] = None) -> list[InferenceTelemetryRecord]:
        items = list(self._records)
        return items if n is None else items[-n:]

    def __len__(self) -> int:
        return len(self._records)

    def summary(self) -> dict:
        """آمارِ خلاصه -- برایِ داشبورد/تستِ رگرسیون، نه Shadow Mode واقعی."""
        items = list(self._records)
        if not items:
            return {
                "count": 0,
                "success_rate": None,
                "fallback_rate": None,
                "timeout_rate": None,
                "avg_latency_ms": None,
            }
        count = len(items)
        successes = sum(1 for r in items if r.success)
        fallbacks = sum(1 for r in items if r.fallback_used)
        timeouts = sum(1 for r in items if r.timed_out)
        avg_latency = sum(r.latency_ms for r in items) / count
        return {
            "count": count,
            "success_rate": successes / count,
            "fallback_rate": fallbacks / count,
            "timeout_rate": timeouts / count,
            "avg_latency_ms": avg_latency,
        }
