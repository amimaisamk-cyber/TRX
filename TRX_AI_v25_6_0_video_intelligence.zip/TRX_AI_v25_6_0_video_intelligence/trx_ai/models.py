# -*- coding: utf-8 -*-
"""
ساختارهای داده‌ی مشترک (dataclass) استفاده‌شده در سراسر برنامه.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class Message:
    """پیام در حافظه مکالمه"""
    role: str
    content: str
    timestamp: str
    topic: Optional[str] = None
    importance: float = 1.0
    id: int = 0
    metadata: Dict = field(default_factory=dict)

@dataclass
class ToolScore:
    """امتیاز ابزار"""
    name: str
    score: float
    confidence: float
    reason: str
    metadata: Dict = field(default_factory=dict)

@dataclass
class Workflow:
    """گردش کار"""
    id: str
    name: str
    steps: List[Dict]
    status: str = "pending"
    created_at: str = ""
    updated_at: str = ""
    result: Any = None
    metadata: Dict = field(default_factory=dict)

@dataclass
class Plugin:
    """پلاگین"""
    name: str
    version: str
    description: str
    author: str
    license: str
    dependencies: List[str]
    path: str
    enabled: bool = True
    loaded: bool = False
    # مجوزهایی که خودِ پلاگین ادعا می‌کند لازم دارد (مثلاً ["math"]،
    # ["text"]). این یک sandbox واقعیِ scoped نیست (AST-blocklistِ
    # find_dangerous_pattern هنوز تنها لایه‌ی واقعیِ اجراست) — هدفش
    # شفافیت است: کاربر/سیستم از قبل می‌داند این پلاگین ادعا می‌کند به
    # چه چیزی نیاز دارد، و می‌شود پلاگینی که ادعای بیش از حد می‌کند
    # (مثلاً می‌گوید «فقط math» ولی کدش تلاش می‌کند فایل باز کند) را
    # همان لحظه‌ی نصب رد کرد، نه اینکه فقط لحظه‌ی اجرا فهمیده شود.
    permissions: List[str] = field(default_factory=list)
