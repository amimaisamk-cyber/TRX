# -*- coding: utf-8 -*-
"""
مجموعه‌ی دیتاستِ برچسب‌خورده برایِ ارزیابی (گامِ ۳ روادمپ).

به‌جایِ نگه‌داشتنِ یک فایلِ جدایِ ۲۰-۳۰ جمله‌ای برایِ هر نیت (که خودش
می‌توانست یک منبعِ سومِ واگرایی از کلیدواژه‌هایِ واقعی بشود)، این ماژول
مستقیماً از ``IntentSpec.positive_examples`` / ``negative_examples`` --
که همین‌الان کنارِ کلیدواژه‌هایِ هر نیت در intents/*.py نگه داشته
می‌شوند -- دیتاست می‌سازد. یعنی هروقت کلیدواژه‌ای عوض شد، نمونه‌های
مربوطه هم همان‌جا کنارش هستند و فراموش نمی‌شوند.

جمله‌هایِ ``negative_examples`` یک نیت به‌عنوانِ نمونه‌ی «این نیت
نباید اینجا برنده شود» ثبت می‌شوند؛ برچسبِ درستِ آن‌ها به‌صورتِ خودکار
از رویِ خودِ ``detect`` در زمانِ اجرا تعیین نمی‌شود، بلکه به‌سادگی
به‌عنوانِ «هر نیتی جز این یکی» بررسی می‌شوند (رجوع به run_eval.py).

توسعه: افزودنِ نمونه‌یِ بیشتر یعنی فقط اضافه‌کردن به تاپلِ
``positive_examples``/``negative_examples`` در فایلِ خودِ آن نیت --
این فایل نیازی به تغییر ندارد.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..registry import PATTERNS


@dataclass(frozen=True)
class LabeledExample:
    text: str
    expected_intent: str
    is_negative: bool = False  # True یعنی «expected_intent نباید نتیجه باشد»


def build_dataset() -> list[LabeledExample]:
    dataset: list[LabeledExample] = []
    for name, spec in PATTERNS.items():
        for text in spec.positive_examples:
            dataset.append(LabeledExample(text=text, expected_intent=name))
        for text in spec.negative_examples:
            dataset.append(LabeledExample(text=text, expected_intent=name, is_negative=True))
    return dataset
