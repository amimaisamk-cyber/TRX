# -*- coding: utf-8 -*-
"""
اجرایِ ارزیابی و چاپِ Precision/Recall/Confusion-Matrix (گامِ ۳ روادمپ).

استفاده::

    python -m trx_ai.nlu.eval.run_eval

این دقیقاً همان چیزی است که روادمپ می‌خواست: «بعدِ هر گام، run_eval.py
را اجرا کن و عددِ دقت را قبل/بعد مقایسه کن -- نه فقط حسی». چون این
هارنس رویِ ``detect`` واقعی اجرا می‌شود (نه یک شبیه‌سازی)، هر تغییری در
matchers/normalizer/registry بلافاصله در این عدد منعکس می‌شود.
"""

from __future__ import annotations

import sys
from collections import Counter, defaultdict

from ..scorer import detect
from .dataset import LabeledExample, build_dataset


def _evaluate(dataset: list[LabeledExample]):
    positives = [ex for ex in dataset if not ex.is_negative]
    negatives = [ex for ex in dataset if ex.is_negative]

    confusion: dict[str, Counter] = defaultdict(Counter)
    correct = 0
    for ex in positives:
        predicted = detect(ex.text).intent
        confusion[ex.expected_intent][predicted] += 1
        if predicted == ex.expected_intent:
            correct += 1

    negative_violations = []
    for ex in negatives:
        predicted = detect(ex.text).intent
        if predicted == ex.expected_intent:
            negative_violations.append((ex.text, ex.expected_intent))

    return positives, negatives, confusion, correct, negative_violations


def _per_intent_precision_recall(confusion: dict[str, Counter]):
    all_intents = set(confusion.keys()) | {p for row in confusion.values() for p in row}
    rows = []
    for intent in sorted(all_intents):
        tp = confusion.get(intent, Counter()).get(intent, 0)
        support = sum(confusion.get(intent, Counter()).values())
        predicted_as_intent = sum(confusion.get(other, Counter()).get(intent, 0) for other in confusion)
        precision = tp / predicted_as_intent if predicted_as_intent else float("nan")
        recall = tp / support if support else float("nan")
        rows.append((intent, precision, recall, support))
    return rows


def evaluate() -> dict:
    """
    نسخه‌یِ برنامه‌نویسی‌شده‌یِ همین ارزیابی -- خروجیِ ساختاریافته (نه چاپ)
    برایِ استفاده‌یِ ``trx_ai.eval.report`` (گزارشِ یکپارچه‌یِ NLU/Memory/
    Router/Regression در کنارِ هم، طبقِ بندِ ۶ روادمپِ نسخه‌ی بعدی).

    ``main()`` عمداً دست‌نخورده می‌ماند و مستقیماً از همین تابع استفاده
    می‌کند تا اجرایِ خط‌فرمانِ فعلی (``python -m trx_ai.nlu.eval.run_eval``)
    دقیقاً همان خروجیِ قبلی را بدهد.
    """
    dataset = build_dataset()
    positives, negatives, confusion, correct, violations = _evaluate(dataset)
    total = len(positives)
    return {
        "accuracy": correct / total if total else 0.0,
        "total": total,
        "correct": correct,
        "negatives_checked": len(negatives),
        "negative_violations": len(violations),
        "violations": violations,
        "confusion": confusion,
    }


def main() -> int:
    result = evaluate()
    confusion = result["confusion"]
    total = result["total"]
    correct = result["correct"]
    negatives = result["negatives_checked"]
    violations = result["violations"]
    accuracy = result["accuracy"]

    print(f"=== ارزیابیِ موتورِ تشخیصِ نیت ===")
    print(f"نمونه‌هایِ مثبت: {total}   |   دقتِ کلی: {accuracy:.2%} ({correct}/{total})")
    print(f"نمونه‌هایِ منفی بررسی‌شده: {negatives}   |   نقض‌شده: {len(violations)}")
    print()
    print(f"{'نیت':<22}{'Precision':>12}{'Recall':>12}{'تعداد':>10}")
    for intent, precision, recall, support in _per_intent_precision_recall(confusion):
        p_str = f"{precision:.0%}" if precision == precision else "—"
        r_str = f"{recall:.0%}" if recall == recall else "—"
        print(f"{intent:<22}{p_str:>12}{r_str:>12}{support:>10}")

    if violations:
        print()
        print("نمونه‌هایِ منفیِ نقض‌شده (نیتی که نباید برنده شود ولی شد):")
        for text, intent in violations:
            print(f"  - «{text}» → نباید {intent} باشد")

    return 0 if not violations else 1


if __name__ == "__main__":
    sys.exit(main())
