# -*- coding: utf-8 -*-
"""ابزارِ ارزیابیِ عینیِ موتورِ تشخیصِ نیت (Precision/Recall/Confusion Matrix)."""
