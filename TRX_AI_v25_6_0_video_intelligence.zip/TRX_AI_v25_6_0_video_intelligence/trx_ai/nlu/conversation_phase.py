# -*- coding: utf-8 -*-
"""
conversation_phase.py -- تشخیصِ مرحله‌یِ فعلیِ مکالمه.

مکملِ ``user_state`` است، نه جایگزینِ آن: ``user_state`` می‌گوید «کاربر
چه حالی دارد؟»، این ماژول می‌گوید «گفتگو در چه مرحله‌ای است؟» (بخشِ ۱۲
سند). دو محورِ کاملاً جداگانه که فقط در ``response_strategy`` با هم
ترکیب می‌شوند.

طراحیِ عمداً ساده و کلیدواژه‌ای (بدونِ embedding): مراحلِ گفتگو تنوعِ
زبانیِ نیت‌ها/احساسات را ندارند (عبارات محدود و نسبتاً قالبی‌اند --
«سلام»، «خداحافظ»، «باز هم نشد»)، پس همان دلیلِ محافظه‌کارانه‌ی
fuzzy/semantic (کاهشِ false-positive رویِ عباراتِ کوتاه) اینجا برعکس
عمل می‌کند: کلیدواژه‌یِ ساده هم دقیق و هم ارزان است.
"""

from __future__ import annotations

from .normalizer import normalize

# دقیقاً همان فهرستِ بخشِ ۱۲ سند.
PHASES = (
    "greeting", "problem", "clarification", "information_request", "planning",
    "problem_solving", "retry", "failure", "success", "closing", "follow_up",
    "emotional_state", "unknown",
)

_PHASE_CUES: dict[str, tuple[str, ...]] = {
    "greeting": ("سلام", "درود", "صبح بخیر", "عصر بخیر", "سلام علیک"),
    "closing": ("خداحافظ", "فعلاً", "فعلا خداحافظ", "شب بخیر", "می‌رم دیگه", "میرم دیگه"),
    "problem": ("کار نمی‌کنه", "کار نمیکنه", "مشکل دارم", "خطا میده", "ارور میده", "باگ داره", "درست کار نمی‌کنه"),
    "clarification": ("منظورت چیه", "یعنی چی دقیقاً", "کدوم قسمتش", "منظورم رو واضح‌تر بگم"),
    "information_request": ("چیست", "چیه؟", "چرا", "چطور", "چگونه", "توضیح بده", "معنیش چیه"),
    "planning": ("برنامه بریزیم", "قدم بعدی", "چطور شروع کنم", "مراحلش چیه", "برنامه‌ریزی کنیم"),
    "retry": ("دوباره امتحان کردم", "بازم امتحان کردم", "این بار امتحان کردم", "یه بار دیگه امتحان کردم"),
    "failure": ("نشد", "خراب شد", "کار نکرد", "جواب نداد", "درست نشد", "بازم نشد", "باز هم نشد"),
    "success": ("درست شد", "حل شد", "جواب داد", "موفق شدم", "عالی شد", "بالاخره شد"),
    "follow_up": ("راستی", "یه چیز دیگه", "در ضمن", "یه سؤال دیگه هم داشتم"),
}

# اگر هیچ‌کدام از سرنخ‌هایِ بالا پیدا نشد ولی وضعیتِ کاربر به‌شدت منفی
# است، به‌جایِ «unknown» صادقانه‌تر است بگوییم مرحله «حالتِ عاطفی»ست
# (بخشِ ۱۲: مثالِ «خسته شدم» تنها → phase=emotional_state).
_NEGATIVE_STATES = {"tired", "frustrated", "sad", "angry", "stressed", "dissatisfied", "bored"}


def detect_phase(text: str, user_state: str = "neutral", previous_failures: int = 0) -> str:
    """
    ``previous_failures``: تعدادِ نوبت‌هایِ اخیری که مرحله‌شان
    failure/retry بوده (از صدازننده -- مثلاً از
    ``UserStateSessionMemory.recent_failures`` یا از تاریخچه‌یِ
    ``ConversationPatternEngine``). اگر مرحله‌یِ فعلی هم failure/retry
    باشد و این عدد بالا باشد، «repeated_failure» برمی‌گردد -- یک
    پالایشِ کاربردیِ failure/retری که در بخش‌هایِ ۱۵/۲۹ سند صراحتاً
    خواسته شده، نه یکی از ۱۳ مرحله‌یِ پایه.
    """
    norm = normalize(text or "")
    scores: dict[str, int] = {}
    for phase, cues in _PHASE_CUES.items():
        hits = sum(1 for cue in cues if normalize(cue) in norm)
        if hits:
            scores[phase] = hits

    if not scores:
        if user_state in _NEGATIVE_STATES:
            return "emotional_state"
        return "unknown"

    best = max(scores, key=scores.get)
    if best in {"retry", "failure"} and previous_failures >= 2:
        return "repeated_failure"
    return best
