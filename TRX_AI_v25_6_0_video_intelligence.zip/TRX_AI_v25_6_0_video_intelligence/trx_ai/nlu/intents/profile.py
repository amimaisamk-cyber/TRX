# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="profile_update",
        category="profile",
        keywords=("من را صدا کن",),
        regex=(r'^نام من \S', r'^اسم من \S(?!.*چیه)'),
        weight=10,
        structural=(r'^(نام\s*من|اسم\s*من|من\s*را\s*صدا\s*کن)\s+(?!چیه|چیست|هست\b)\S',),
        positive_examples=("نام من علی است",),
    ),
    IntentSpec(
        name="profile_query",
        category="profile",
        keywords=("اسم من", "نام من چیه", "اسمم چیه", "من کی هستم"),
        weight=9,
        # مهم: پرسیدنِ نام («اسم من چیه؟») باید پیش از دستورِ تنظیمِ نام
        # بررسی شود -- وگرنه چون هر دو با «اسم من»/«نام من» شروع می‌شوند،
        # به‌اشتباه profile_update تشخیص داده می‌شود. ترتیب در
        # registry.STRUCTURAL_ORDER تضمین می‌شود.
        structural=(r'(اسم\s*من\s*چیه|نام\s*من\s*چیه|اسمم\s*چیه|من\s*کی\s*هستم)',),
        positive_examples=("اسم من چیه", "من کی هستم"),
    ),
]
