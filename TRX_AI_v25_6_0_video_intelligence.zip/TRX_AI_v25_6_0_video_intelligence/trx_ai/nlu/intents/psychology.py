# -*- coding: utf-8 -*-
"""
نیتِ «emotional_support» -- پریشانیِ هیجانی/تنهایی/استرس بدونِ علامتِ
جسمی همراه. عمداً از نیتِ «medical» جدا نگه داشته شده (نه فقط چند
کلیدواژه‌ی اضافه به آن) چون:
  ۱. مسیرِ اجراییِ متفاوتی دارد (medical/therapy/engine.py، نه
     تشخیصِ‌علائم/دارو/کمکِ‌اولیه).
  ۲. اجازه می‌دهد core.py لحن/UIِ متفاوتی (پیشوندِ «💙 همراه شما»به‌جایِ
     «🏥 پاسخ پزشکی») برایِ این دسته نشان دهد.

کلیدواژه‌ها از trx_ai.medical.router.EMOTIONAL_SUPPORT_KEYWORDS می‌آیند
تا یک منبعِ حقیقتِ واحد داشته باشیم -- نه دو فهرستِ جداگانه که ممکن است
از هم واگرا شوند.

نکته‌یِ ایمنی: کلیدواژه‌هایِ خودآسیبی/خودکشی عمداً *اینجا* نیستند --
آن‌ها در نیتِ «medical» می‌مانند (trx_ai/nlu/intents/medical.py) چون
باید همیشه از طریقِ مسیرِ EMERGENCY/redflags با بالاترین اولویت گرفته
شوند، نه از طریقِ این نیتِ کم‌فوریت‌ترِ همراهی.
"""

from __future__ import annotations

from ...medical.router import EMOTIONAL_SUPPORT_KEYWORDS
from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="emotional_support",
        category="medical",
        keywords=EMOTIONAL_SUPPORT_KEYWORDS,
        weight=9,
        ref_tool="emotional_support",
        tool_weight=5,
        tool_description="همراهِ روان‌شناختی/گوشِ‌شنوا برایِ پریشانیِ هیجانی",
        semantic_enabled=True,
        positive_examples=(
            "امروز خیلی ناراحتم",
            "دلم گرفته و نمی‌دونم چرا",
            "خیلی تنهام این روزا",
            "استرس زیادی دارم و نمی‌تونم آروم بشم",
            "می‌خوام یکم درد دل کنم",
        ),
        negative_examples=("سردرد و تب دارم", "سلام چطوری"),
    ),
]
