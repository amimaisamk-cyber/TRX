# -*- coding: utf-8 -*-
"""
پنج قابلیتِ کوچکِ اضافه‌شده (تبدیلِ واحد، رمزِ عبور، BMI، خرج‌ها، بکاپ) --
همه صرفاً ساختاری‌اند، در یک فایلِ موضوعی گروه شده‌اند.
"""

from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="unit_convert",
        category="utility",
        structural=(
            r'\d+.*?(کیلومتر|متر|سانتی[\s\u200c]*متر|میلی[\s\u200c]*متر|مایل|فوت|اینچ|'
            r'کیلوگرم|کیلو|گرم|پوند|اونس|درجه).*?به.*?(کیلومتر|متر|سانتی[\s\u200c]*متر|'
            r'میلی[\s\u200c]*متر|مایل|فوت|اینچ|کیلوگرم|کیلو|گرم|پوند|اونس|'
            r'سانتی[\s\u200c]*گراد|فارنهایت|کلوین)',
        ),
        positive_examples=("۵ کیلومتر به مایل چقدره",),
    ),
    IntentSpec(
        name="password_gen",
        category="utility",
        structural=(r'(رمز[\s\u200c]*عبور|پسورد)[\s\u200c]*(قوی|امن|جدید)?[\s\u200c]*(بساز|تولید[\s\u200c]*کن)',),
        positive_examples=("یه رمز عبور قوی بساز",),
    ),
    IntentSpec(
        name="bmi",
        category="utility",
        structural=(r'(بی[\s\u200c]*ام[\s\u200c]*آی|bmi|شاخص[\s\u200c]*توده)',),
        positive_examples=("بی ام آی من رو حساب کن",),
    ),
    IntentSpec(
        name="expense_summary",
        category="utility",
        structural=(r'(خلاصه[\s\u200c]*خرج|چقدر[\s\u200c]*خرج[\s\u200c]*کردم|گزارش[\s\u200c]*هزینه)',),
        positive_examples=("خلاصه خرجام رو بده",),
    ),
    IntentSpec(
        name="expense_add",
        category="utility",
        structural=(r'^(خرج[\s\u200c]*کردم|هزینه[\s\u200c]*کردم|پول[\s\u200c]*دادم)\b',),
        positive_examples=("خرج کردم ۵۰ تومن برای ناهار",),
    ),
    IntentSpec(
        name="backup_data",
        category="utility",
        structural=(r'^(پشتیبان[\s\u200c]*گیری|بک[\s\u200c]*آپ)\b',),
        positive_examples=("پشتیبان گیری کن",),
    ),
    IntentSpec(
        name="restore_data",
        category="utility",
        structural=(r'^(بازیابی)\b',),
        positive_examples=("بازیابی کن",),
    ),
]
