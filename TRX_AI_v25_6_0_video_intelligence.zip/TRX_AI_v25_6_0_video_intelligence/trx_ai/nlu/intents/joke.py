# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="joke",
        category="fun",
        keywords=("جوک", "لطیفه", "بامزه بگو", "بخندون", "چیز خنده‌دار", "منو بخندون"),
        regex=(
            r'(یه|یک)?\s*(جوک|لطیفه)\s*(بگو|بگی|تعریف\s*کن)?',
            r'(من\s*(رو|را)?\s*)?بخندون(م)?',
        ),
        weight=9,
        positive_examples=("یه جوک بگو", "جوک بگو", "لطیفه بگو", "منو بخندون", "بخندونم"),
    ),
]
