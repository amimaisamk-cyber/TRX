# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="mood_report",
        category="system",
        structural=(
            r'(تحلیل\s*احساسی|حال\s*و\s*هوای\s*گفتگو|چند\s*درصد\s*(ناراحت|خوشحال|عصبانی|نگران)|'
            r'درصد\s*احساسات|گزارش\s*احساسی|این\s*گفتگو\s*چقدر|آمار\s*احساسی)',
        ),
        positive_examples=("حال و هوای گفتگو چطوره",),
    ),
    IntentSpec(
        name="project_query",
        category="system",
        # اصلاح: normalizer.normalize نیم‌فاصله‌ی واقعی (U+200C) را به
        # فاصله‌ی معمولی تبدیل می‌کند، پس الگو باید هر دو را بپذیرد --
        # نه فقط نیم‌فاصله‌ی لنگرشده‌ی قدیمی (که در عمل هرگز تطبیق پیدا
        # نمی‌کرد، چون متن رسیده به اینجا همیشه از normalize رد شده).
        structural=(r'(پروژه\s*جدید|پروژه[\s\u200c]?هام|پروژه[\s\u200c]?ها\s*چیه)',),
        positive_examples=("پروژه جدید", "پروژه‌هام چیه", "پروژه‌ها چیه"),
    ),
    IntentSpec(
        name="help",
        category="system",
        structural=(r'^(راهنما|کمک\s*کن\s*با\s*دستورها)$',),
        positive_examples=("راهنما",),
    ),
    IntentSpec(
        name="exit",
        category="system",
        structural=(r'^(خروج|exit|quit)$',),
        positive_examples=("خروج", "exit"),
    ),
]
