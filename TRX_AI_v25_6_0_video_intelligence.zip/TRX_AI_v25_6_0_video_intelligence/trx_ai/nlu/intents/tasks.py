# -*- coding: utf-8 -*-
"""
نیت‌هایِ مدیریتِ کارها/یادآوری‌ها -- همه‌شان صرفاً ساختاری‌اند (بدونِ
امتیازدهیِ آماری)، پس در یک فایلِ موضوعی گروه شده‌اند (رجوع به توضیحِ
intents/__init__.py). ترتیبِ بررسیِ اینها نسبت به هم در
registry.STRUCTURAL_ORDER حفظ شده: الگوهایِ دارایِ شماره
(انجام‌شده/حذف) باید پیش از task_add بررسی شوند تا با «کار جدید» یا
عباراتِ مشابه تداخل نکنند.
"""

from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="task_done",
        category="task",
        structural=(r'کار\s*#?\d+.*?(انجام\s*دادم|انجام\s*شد|تموم\s*شد|تمومش\s*کردم|تمومش\s*کن)',),
        positive_examples=("کار ۲ رو انجام دادم",),
    ),
    IntentSpec(
        name="task_delete",
        category="task",
        structural=(r'(کار\s*#?\d+.*?(حذف\s*کن|رو\s*حذف)|حذف\s*کار\s*#?\d+)',),
        positive_examples=("کار ۳ رو حذف کن", "حذف کار ۴"),
    ),
    IntentSpec(
        name="task_add",
        category="task",
        structural=(r'^(یادم\s*بنداز|یادآوری\s*کن|به\s*کارهام\s*اضافه\s*کن|کار\s*جدید)\b',),
        positive_examples=("یادم بنداز فردا ساعت ۵ به دکتر زنگ بزنم", "یادآوری کن که نون بخرم"),
    ),
    IntentSpec(
        name="task_list",
        category="task",
        # «کارام» (بخشِ A11 سندِ ممیزیِ AMS) شکلِ محاوره‌ایِ رایجِ «کارهام»ه --
        # قبل از این، این شکل اصلاً در STRUCTURAL نبود و به general/۰.۴
        # سقوط می‌کرد (دقیقاً همان باگِ کشف‌شده در intent_candidates.py).
        structural=(r'^(کارهام\s*چیه|کارام\s*چیه|کارام\b|لیست\s*کارها|یادآوری[\s\u200c]?هام|کارهای\s*من\s*چیه|کارهامو\s*نشون\s*بده)\b',),
        positive_examples=("کارهام چیه", "لیست کارها", "کارام چیه", "کارام"),
    ),
]
