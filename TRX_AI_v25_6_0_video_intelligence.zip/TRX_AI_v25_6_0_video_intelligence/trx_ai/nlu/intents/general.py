# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="general",
        category="general",
        weight=1,
        positive_examples=("سلام چطوری",),
    ),
]
