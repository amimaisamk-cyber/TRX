# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="project_analysis",
        category="code",
        keywords=("تحلیل پروژه", "آنالیز پروژه", "بررسی پروژه", "اسکن پروژه", "گزارش پروژه"),
        regex=(r'(تحلیل|آنالیز|بررسی|اسکن)\s+پروژه',),
        weight=12,
        # دستورِ ساختاری: باید پیش از خیلی از الگوهایِ دیگر (persian_interpreter
        # و غیره) بررسی شود -- ترتیب در registry.STRUCTURAL_ORDER حفظ شده.
        structural=(r'(تحلیل|آنالیز|بررسی|اسکن)\s+پروژه',),
        positive_examples=(
            "تحلیل پروژه رو انجام بده",
            "آنالیز پروژه ./trx_ai",
            "بررسی پروژه فعلی رو شروع کن",
        ),
    ),
]
