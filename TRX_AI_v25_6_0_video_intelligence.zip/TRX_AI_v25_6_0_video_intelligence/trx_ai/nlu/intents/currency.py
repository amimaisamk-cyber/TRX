# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="currency",
        category="tool",
        keywords=("قیمت دلار", "قیمت طلا", "ارز", "دلار", "یورو", "پوند", "تومان"),
        synonyms=("نرخ ارز", "قیمت سکه", "بازار ارز چطوره"),
        regex=(r'قیمت\s+(دلار|یورو|پوند|طلا)',),
        weight=6,
        ref_tool="currency",
        tool_weight=3,
        tool_description="نرخ ارز",
        fuzzy_enabled=True,
        positive_examples=("قیمت دلار چنده", "قیمت طلا امروز", "نرخ ارز چطوره"),
        negative_examples=("هوای تهران چطوره",),
    ),
]
