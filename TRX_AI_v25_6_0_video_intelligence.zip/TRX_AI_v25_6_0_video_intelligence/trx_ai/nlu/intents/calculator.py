# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="calculator",
        category="tool",
        keywords=("محاسبه", "حساب", "چقدر", "ضربدر", "تقسیم", "جمع", "منهای", "مساوی چنده", "بعلاوه"),
        regex=(r'\d+\s*[\+\-\*\/\^]\s*\d+', r'حاصل\s+\d+', r'مساوی'),
        weight=10,
        ref_tool="calculator",
        tool_weight=5,
        tool_category="math",
        tool_description="محاسبات ریاضی",
        fuzzy_enabled=True,
        positive_examples=(
            "۵ بعلاوه ۳ چقدر میشه",
            "۱۰ ضربدر ۲ چند میشه",
            "حاصل ۲۰ تقسیم بر ۴ چقدره",
            "۷ منهای ۲ چند میشه",
            "میشه برام محاسبه کنی ۹ ضربدر ۹",
        ),
        negative_examples=("این جمله رو به انگلیسی ترجمه کن", "هوای تهران چطوره"),
    ),
]
