# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="self_learning",
        category="memory",
        keywords=("یاد بگیر", "به خاطر بسپار", "یادت باشه"),
        regex=(r'^یاد بگیر:', r'^به خاطر بسپار:'),
        weight=10,
        structural=(r'^(یادت\s*باشه|یاد\s*بگیر|به\s*خاطر\s*بسپار)\s*[:：]?',),
        positive_examples=("یاد بگیر: من قهوه دوست دارم", "به خاطر بسپار: تولدم مرداده"),
    ),
]
