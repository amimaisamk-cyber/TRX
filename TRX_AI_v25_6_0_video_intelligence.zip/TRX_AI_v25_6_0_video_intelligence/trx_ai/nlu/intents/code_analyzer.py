# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="code_analyzer",
        category="code",
        keywords=(
            "کد", "باگ", "خطا", "اجرا", "پایتون", "برنامه", "فانکشن", "کلاس", "def", "import",
            "تحلیل کد", "بررسی کد", "اصلاح کد", "دیباگ",
        ),
        regex=(r'```', r'def\s+\w+', r'class\s+\w+', r'import\s+\w+'),
        weight=9,
        ref_tool="code_analyzer",
        tool_weight=5,
        tool_category="code",
        tool_description="تحلیل و اصلاح کد",
        positive_examples=(
            "این کد رو تحلیل کن: def f(): pass",
            "این برنامه‌ی پایتون باگ داره بررسی کن",
            "کلاس زیر رو دیباگ کن",
            "خطای این کد رو پیدا کن",
        ),
        negative_examples=("پایتون چیست", "هوای تهران چطوره"),
    ),
]
