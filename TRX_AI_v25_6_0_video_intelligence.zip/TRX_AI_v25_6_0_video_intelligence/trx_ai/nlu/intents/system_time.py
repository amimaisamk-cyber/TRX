# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="system_time",
        category="system",
        keywords=("ساعت چنده", "ساعت چند", "الان ساعت", "امروز چنده", "تاریخ", "چه روزیه"),
        regex=(r'ساعت\s+\w+', r'تاریخ\s+\w+'),
        weight=10,
        positive_examples=("الان ساعت چنده", "تاریخ امروز چیه", "امروز چه روزیه"),
    ),
]
