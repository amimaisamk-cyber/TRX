# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="workflow",
        category="workflow",
        # «بعد» و «سپس» به‌تنهایی حذف شدند: رایج‌ترین حروفِ ربطِ فارسی‌اند
        # و تقریباً در هر جمله‌ای می‌آیند. فقط عباراتِ صریحِ چندمرحله‌ای
        # شمارش می‌شوند.
        keywords=("مرحله به مرحله", "قدم به قدم", "پشت سر هم انجام بده", "این کارها رو به ترتیب"),
        regex=(r'مرحله\s*\d', r'قدم\s*\d', r'اول\s+.+\s+بعد\s+.+\s+سپس'),
        weight=6,
        positive_examples=("مرحله به مرحله راهنماییم کن", "قدم به قدم انجامش بده"),
        negative_examples=("بعد از غذا چیکار کنم خوبه",),
    ),
]
