# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="persian_interpreter",
        category="code",
        # نسخه‌ی قبلی «اگر»، «برای» و «تابع» را کلیدواژه می‌دانست -- اما
        # این‌ها رایج‌ترین کلماتِ زبانِ فارسی‌اند و تقریباً در هر جمله‌ای
        # ممکن است ظاهر شوند («برای تولدش چی بخرم؟»). این نیت اکنون فقط
        # با نحوِ واقعیِ فراخوانیِ شبه‌کد یا درخواستِ صریح شمارش می‌شود.
        keywords=("چاپ(", "بگو(", "مفسر فارسی", "اجرا کن کد فارسی"),
        regex=(r'چاپ\s*\(', r'بگو\s*\('),
        weight=9,
        structural=(r'(فعال\s*شو\s*مفسر|مفسر\s*فارسی)',),
        ref_tool="persian_interpreter",
        tool_weight=5,
        tool_category="code",
        tool_description="اجرای کد فارسی",
        positive_examples=("چاپ(سلام دنیا)", "بگو(سلام)", "مفسر فارسی رو فعال کن"),
        negative_examples=("برای تولدش چی بخرم", "اگر بارون بیاد چیکار کنم"),
    ),
]
