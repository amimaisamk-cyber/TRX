# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="translator",
        category="tool",
        keywords=("ترجمه", "به انگلیسی", "به فارسی", "ترجمه کن", "معنی انگلیسی", "معنی فارسی"),
        synonyms=("برگردون به", "معادل انگلیسیش چیه", "این رو ترجمه کن"),
        # «معنی\s+(انگلیسی|فارسی)» به‌عنوانِ regexِ اختصاصیِ اضافه شد:
        # بدونِ آن، dictionary (که «معنی» را هم کلیدواژه و هم regex
        # می‌داند: معنی\s+\w+) رویِ جمله‌ی «معنی انگلیسی کتاب چیه» با
        # امتیازِ ترکیبیِ باالتر برنده می‌شد، چون خودِ کلمه‌ی «معنی»
        # هم برایِ dictionary امتیاز داشت هم برایِ translator، ولی فقط
        # dictionary از آن regex بونوس می‌گرفت. این regexِ اضافه دقیقاً
        # همان بونوس را به translator هم می‌دهد تا در این تداخلِ خاص
        # (پرسیدنِ معنیِ انگلیسی/فارسیِ یک کلمه = ترجمه، نه لغت‌نامه)
        # translator برنده شود.
        regex=(r'ترجمه\s+.*\s+به\s+(\w+)', r'معنی\s+(انگلیسی|فارسی)'),
        weight=10,
        ref_tool="translator",
        tool_weight=5,
        tool_category="language",
        tool_description="ترجمه متن",
        fuzzy_enabled=True,
        semantic_enabled=True,
        positive_examples=(
            "این جمله رو به انگلیسی ترجمه کن",
            "سلام دنیا رو به انگلیسی برگردون",
            "این متن رو ترجمه کن لطفا",
            "معنی انگلیسی کتاب چیه",
        ),
        negative_examples=("معنی کلمه‌ی سلام چیه", "هوای تهران چطوره"),
    ),
]
