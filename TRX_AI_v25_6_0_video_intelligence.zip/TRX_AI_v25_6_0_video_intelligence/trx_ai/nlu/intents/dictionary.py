# -*- coding: utf-8 -*-
from __future__ import annotations

from ..types import IntentSpec

SPECS = [
    IntentSpec(
        name="dictionary",
        category="search",
        keywords=("معنی", "معنی کلمه", "یعنی چی", "تعریف", "لغت", "واژه"),
        regex=(r'معنی\s+\w+', r'لغت\s+\w+'),
        weight=8,
        ref_tool="dictionary",
        tool_weight=4,
        tool_category="language",
        tool_description="معنی کلمات",
        fuzzy_enabled=True,
        semantic_enabled=True,
        positive_examples=(
            "معنی کلمه‌ی سلام چیه",
            "یعنی چی این کلمه",
            "تعریف واژه‌ی دموکراسی چیه",
            "لغت استعاره یعنی چی",
        ),
        negative_examples=("این جمله رو به انگلیسی ترجمه کن",),
    ),
]
