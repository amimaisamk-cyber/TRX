# -*- coding: utf-8 -*-
"""
دیتاکلاس‌هایِ مشترکِ User State Engine.

عمداً هم‌شکلِ ``nlu/types.py`` (``IntentSpec`` / ``IntentResult``) است تا
همان معماریِ چندلایه‌ی موجود (کلیدواژه → مترادف → regex → فازی → معنایی)
بدونِ کپی‌کاری برایِ تشخیصِ *وضعیتِ کاربر* هم استفاده شود -- طبقِ سندِ
ارتقا (بخش‌هایِ ۵ و ۲۱): «از همان معماری و همان embedding backend
استفاده شود، نه یک موتورِ جدا».

نکته‌یِ مهمِ معماری (بخشِ ۲ سند): ``UserStateSpec`` جایگزینِ
``IntentSpec`` نیست و هیچ‌کدام از ماژول‌هایِ ``nlu`` را وابسته به این
فایل نمی‌کند -- Intent و User State دو محورِ کاملاً مستقل می‌مانند.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class UserStateSpec:
    """
    توصیفِ کاملِ یک وضعیتِ ممکنِ کاربر (نه یک نیت، نه یک ویژگیِ دائمی).

    name / description:
        نامِ یکتا (کلیدِ ``user_state_registry.USER_STATE_SPECS``) و
        توضیحِ کوتاهِ فارسی برایِ لاگ/دیباگ.
    keywords / synonyms / regex:
        دقیقاً همان معنایِ ``IntentSpec`` -- کلیدواژه‌هایِ اصلی، بسطِ
        محاوره‌ای با ضریبِ کمتر، و الگوهایِ regexِ آزاد.
    positive_examples:
        جملاتِ برچسب‌خورده برایِ لایه‌یِ معنایی (``matchers/semantic.py``
        مستقیماً از این فیلد استفاده می‌کند -- duck-typing با IntentSpec).
    weight:
        وزنِ آماریِ این State در Score Fusion.
    threshold:
        آستانه‌یِ شباهتِ کسینوسیِ لایه‌یِ معنایی، مخصوصِ همین State
        (به‌جایِ یک آستانه‌یِ سراسری -- بعضی حالت‌ها مثلِ «کنجکاوی» مرزِ
        معناییِ گنگ‌تری دارند و به آستانه‌یِ بالاتری نیاز دارند).
    semantic_enabled / fuzzy_enabled:
        دقیقاً همان فلسفه‌یِ محافظه‌کارانه‌یِ ``IntentSpec``: فعال‌سازیِ
        دستی و تدریجی، پیش‌فرض ``False`` برایِ فازی (نویزِ زیاد رویِ
        کلماتِ کوتاه)، ``True`` برایِ معنایی چون این وضعیت‌ها معمولاً با
        عباراتِ آزادِ زیادی بیان می‌شوند.
    polarity:
        فقط برایِ گزارش/Response Strategy مفید است، در امتیازدهی اثری
        ندارد -- «negative» / «positive» / «neutral».
    """

    name: str
    description: str = ""
    keywords: tuple[str, ...] = ()
    synonyms: tuple[str, ...] = ()
    regex: tuple[str, ...] = ()
    positive_examples: tuple[str, ...] = ()
    weight: float = 1.0
    threshold: float = 0.55
    semantic_enabled: bool = False
    fuzzy_enabled: bool = False
    polarity: str = "neutral"


@dataclass
class StateHit:
    """یک شاهدِ منفرد برایِ اینکه چرا یک State امتیاز گرفت (دیباگ/eval)."""

    state: str
    matcher: str  # "keyword" | "synonym" | "regex" | "fuzzy" | "semantic_match" | "context"
    detail: str
    score: float


@dataclass
class SingleState:
    """یک ورودیِ فهرستِ ``UserStateResult.states`` -- بخشِ ۶ سند."""

    state: str
    confidence: float


@dataclass
class UserStateResult:
    """
    خروجیِ ساختاریافته‌یِ ``user_state.detect`` -- دقیقاً فرمتِ پیشنهادیِ
    بخشِ ۶ سند (``primary_state`` + فهرستِ ``states`` با اطمینانِ جدا).
    """

    primary_state: str
    confidence: float
    raw_text: str = ""
    states: list[SingleState] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    # وقتی فاصله‌ی امتیازِ برنده تا نفرِ دوم خیلی کم است یا سیگنال کلاً
    # ضعیف است -- بخشِ ۷/۲۶ سند: «سیستم نباید بیش از حد مطمئن باشد».
    uncertain: bool = False

    def as_dict(self) -> dict:
        return {
            "primary_state": self.primary_state,
            "confidence": self.confidence,
            "states": [{"state": s.state, "confidence": s.confidence} for s in self.states],
            "evidence": self.evidence,
            "uncertain": self.uncertain,
        }
