# -*- coding: utf-8 -*-
"""
پاداشِ اختیاریِ ششمِ روادمپ: وقتی نفرِ اول و دومِ امتیازدهی خیلی به هم
نزدیک‌اند، به‌جایِ حدسِ کورکورانه، یک سؤالِ کوتاهِ بله/خیر (یا
چندگزینه‌ای) بپرس -- همان مکانیزمِ followup که در گفتگویِ پزشکی
(``MedicalAIEngine`` / ``self.ui.show_followup_question``) از قبل وجود
دارد، فقط اینجا رویِ نیت‌هایِ عمومی هم قابلِ استفاده می‌شود.

این ماژول عمداً «فقط منطق» است -- هیچ‌چیزی به UI/core.py وصل نمی‌کند؛
تصمیمِ اینکه کِی و چطور این سؤال پرسیده شود با لایه‌یِ فراخوان است
(دقیقاً طبقِ یادداشتِ خودِ روادمپ که این را «نیاز به UI برایِ گرفتنِ
تصحیح» می‌داند، یعنی وایرینگِ کامل به رابطِ کاربری، فراتر از خودِ
موتورِ تشخیصِ نیت است).
"""

from __future__ import annotations

# اگر فاصله‌یِ نسبیِ امتیازِ برنده تا نفرِ دوم از این کمتر باشد، توصیه
# می‌شود قبل از اجرا سؤال پرسیده شود.
DEFAULT_MARGIN_THRESHOLD = 0.15

# سؤال‌هایِ آماده برایِ چند نیتِ پرکاربرد؛ برایِ بقیه از یک سؤالِ عمومی
# استفاده می‌شود.
_FRIENDLY_NAMES: dict[str, str] = {
    "weather": "آب‌وهوا",
    "currency": "قیمتِ ارز/طلا",
    "web_search": "جستجویِ وب",
    "translator": "ترجمه",
    "dictionary": "معنیِ کلمه",
    "calculator": "محاسبه",
    "medical": "سؤالِ سلامتی",
    "joke": "جوک",
    "code_analyzer": "تحلیلِ کد",
}


def should_ask_followup(
    ranked_scores: list[tuple[str, float]],
    margin_threshold: float = DEFAULT_MARGIN_THRESHOLD,
) -> bool:
    """
    ``ranked_scores`` باید نزولی مرتب باشد: ``[(intent, score), ...]``.
    اگر کمتر از دو نیتِ غیرصفر وجود داشته باشد، هیچ ابهامی نیست.
    """
    if len(ranked_scores) < 2:
        return False
    best_name, best_score = ranked_scores[0]
    _, second_score = ranked_scores[1]
    if best_score <= 0:
        return False
    margin = (best_score - second_score) / best_score
    return margin < margin_threshold


def _label(intent_name: str) -> str:
    return _FRIENDLY_NAMES.get(intent_name, intent_name)


def build_followup_question(top_two_intents: tuple[str, str]) -> str:
    """یک سؤالِ کوتاهِ فارسی برایِ رفعِ ابهامِ بینِ دو نیتِ نزدیک می‌سازد."""
    first, second = top_two_intents
    return f"منظورت {_label(first)} بود یا {_label(second)}؟"


def match_clarification_reply(reply: str, top_two_intents: tuple[str, str]) -> str | None:
    """
    وایرینگِ واقعیِ نیمه‌یِ دومِ این ماژول (که تا اینجا فقط منطقِ تولیدِ
    سؤال بود، نه تفسیرِ پاسخ). وقتی کاربر به ``build_followup_question``
    جواب می‌دهد -- مثلاً «همون آب‌وهوا» یا صرفاً «ترجمه» -- این تابع
    تشخیص می‌دهد کدام‌یک از دو نیتِ کاندیدا مقصودِ کاربر بوده.

    عمداً محافظه‌کار است: فقط وقتی یکی از دو نامِ دوستانه/شناسه‌یِ نیت
    به‌وضوح در پاسخ دیده شود مطابقت می‌دهد؛ در غیرِ این‌صورت ``None``
    برمی‌گرداند تا لایه‌ی فراخوان (``turn_processor.py``) به‌جایِ حدسِ
    نادرست، پیامِ اصلی + این توضیح را دوباره به تشخیصِ نیتِ کاملِ
    ``IntentEngine`` بسپارد (نه یک قیاسِ کورکورانه‌ی دوتایی).
    """
    normalized = (reply or "").strip().lower()
    if not normalized:
        return None
    for intent_name in top_two_intents:
        candidates = {intent_name.lower(), _label(intent_name).lower()}
        if any(c in normalized for c in candidates if c):
            return intent_name
    return None
