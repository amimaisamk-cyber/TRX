# -*- coding: utf-8 -*-
"""
registry.py -- تنها نقطه‌یِ مرکزیِ بارگذاریِ نیت‌ها.

هدفِ اصلیِ این فایل (طبقِ روادمپ): حذفِ دو منبعِ حقیقتِ موازی‌یِ قدیمی
(``IntentEngine.INTENT_PATTERNS`` در برابرِ ``ToolScorer.TOOLS`` /
``ToolScorer._KEYWORD_SOURCE``) که قبلاً یک‌بار از هم واگرا شده بودند.
اکنون هر دو از همین یک دیکشنری (``PATTERNS``) ساخته می‌شوند.

بارگذاریِ خودکار: هر فایلِ زیرِ ``intents/`` یک ``SPECS: list[IntentSpec]``
صادر می‌کند؛ افزودنِ نیتِ جدید یعنی فقط یک فایلِ جدید آنجا -- این فایل
یا intelligence.py نیازی به تغییر ندارند.
"""

from __future__ import annotations

import importlib
import pkgutil
import re

from . import intents as _intents_pkg
from .types import IntentSpec


def _load_all_specs() -> dict[str, IntentSpec]:
    specs: dict[str, IntentSpec] = {}
    for modinfo in pkgutil.iter_modules(_intents_pkg.__path__):
        module = importlib.import_module(f"{_intents_pkg.__name__}.{modinfo.name}")
        for spec in getattr(module, "SPECS", []):
            if spec.name in specs:
                raise ValueError(
                    f"نیتِ تکراری در registry: '{spec.name}' هم در "
                    f"{specs[spec.name].__module__ if hasattr(specs[spec.name], '__module__') else '?'} "
                    f"و هم در {module.__name__} تعریف شده است."
                )
            specs[spec.name] = spec
    return specs


# نام→IntentSpec ؛ معادلِ IntentEngine.INTENT_PATTERNS قدیمی، به‌علاوه‌یِ
# نیت‌هایِ صرفاً ساختاری که در دیکشنریِ قدیمی اصلاً وجود نداشتند.
PATTERNS: dict[str, IntentSpec] = _load_all_specs()

# نیت‌هایی که واقعاً در امتیازدهیِ آماری شرکت می‌کنند (کلیدواژه/regex/وزنِ
# غیرِپیش‌فرض دارند) -- برایِ eval و برایِ مسیرِ سریعِ نیتیو.
STATISTICAL_INTENTS: dict[str, IntentSpec] = {
    name: spec
    for name, spec in PATTERNS.items()
    if name != "general" and (spec.keywords or spec.regex)
}

# ---------------------------------------------------------------------------
#   ترتیبِ بررسیِ دستوراتِ ساختاری -- این ترتیب اهمیتِ حیاتی دارد (نگاه
#   کنید به کامنت‌هایِ خودِ هر IntentSpec برایِ دلیلِ هر جایگاه). دقیقاً
#   همان ترتیبِ STRUCTURAL_COMMANDS قدیمی حفظ شده است.
# ---------------------------------------------------------------------------
STRUCTURAL_ORDER: tuple[str, ...] = (
    "project_analysis",
    "persian_interpreter",
    "self_learning",
    "memory_query",
    "task_done",
    "task_delete",
    "task_add",
    "task_list",
    "unit_convert",
    "password_gen",
    "bmi",
    "expense_summary",
    "expense_add",
    "backup_data",
    "restore_data",
    "mood_report",
    "project_query",
    "memory_save",
    "profile_query",
    "profile_update",
    "personality_change",
    "help",
    "exit",
)

STRUCTURAL: list[tuple[str, "re.Pattern[str]"]] = []
for _name in STRUCTURAL_ORDER:
    _spec = PATTERNS.get(_name)
    if not _spec:
        continue
    for _pat in _spec.structural:
        STRUCTURAL.append((_name, re.compile(_pat)))

# ---------------------------------------------------------------------------
#   ادغامِ ToolScorer.TOOLS / _KEYWORD_SOURCE قدیمی در همین registry --
#   حذفِ دو منبعِ حقیقت (گامِ ۲ روادمپ).
# ---------------------------------------------------------------------------
TOOLS: dict[str, dict] = {}
KEYWORD_SOURCE: dict[str, str] = {}
for _name, _spec in PATTERNS.items():
    if not _spec.ref_tool:
        continue
    TOOLS[_spec.ref_tool] = {
        "weight": _spec.tool_weight if _spec.tool_weight is not None else _spec.weight,
        "category": _spec.tool_category or _spec.category,
        "description": _spec.tool_description or _spec.name,
    }
    KEYWORD_SOURCE[_spec.ref_tool] = _spec.name

# دو ابزارِ بدونِ نیتِ متناظر (هرگز چیزی به‌عنوانِ این دو از
# IntentEngine.detect_intent برنمی‌گردد -- دقیقاً مثلِ نسخه‌یِ قبلی).
# «file_reader» با یک لیستِ کلیدواژه‌یِ محلی (نه از registry) در
# scorer.py امتیاز می‌گیرد؛ «code_runner» اصلاً کلیدواژه‌ای ندارد --
# این یک رفتارِ پیشین است که عمداً بدونِ تغییر نگه داشته شده.
TOOLS["file_reader"] = {"weight": 4, "category": "file", "description": "خواندن فایل"}
TOOLS["code_runner"] = {"weight": 5, "category": "code", "description": "اجرای کد"}

FILE_READER_FALLBACK_KEYWORDS: tuple[str, ...] = ("فایل", "بخوان", "باز کن")

# اولویتِ تساویِ امتیاز در ToolScorer (وقتی چند ابزار امتیازِ برابر و
# غیرصفر دارند) -- دقیقاً همان ترتیبِ قدیمی.
TOOL_PRIORITY: tuple[str, ...] = (
    "medical", "project_analysis", "calculator", "translator", "code_analyzer",
    "persian_interpreter", "dictionary", "currency", "weather", "web_search",
    "file_reader", "code_runner",
)

# نگاشتِ نیت→ابزار برایِ امتیازِ پایه در ToolScorer.
#
# قبلاً این یک دیکشنریِ دستیِ جداگانه بود که هرکسی که یک نیتِ جدیدِ
# دارایِ ref_tool اضافه می‌کرد، باید همزمان یادش می‌بود اینجا هم یک
# ردیف اضافه کند -- دقیقاً همان الگویِ «دو منبعِ حقیقت» که TOOLS/
# KEYWORD_SOURCE بالاتر (با ساختنِ خودکار از رویِ PATTERNS) حلش کرده
# بودند. وقتی نیتِ «emotional_support» اضافه شد (نگاه کنید به
# nlu/intents/psychology.py)، TOOLS/KEYWORD_SOURCE به‌درستی خودکار پر
# شدند ولی این دیکشنریِ دستی به‌روزرسانی نشد -- یعنی score_tools هرگز
# پاداشِ +100*confidence را برایِ emotional_support اعمال نمی‌کرد، حتی
# وقتی detect() کاملاً درست intent=emotional_support را تشخیص می‌داد.
# این دقیقاً همان چیزی بود که باعث می‌شد «می‌خوام یکم درد دل کنم» در
# سطحِ score_tools هنوز به‌جایِ emotional_support، ابزارِ medical انتخاب
# شود (نگاه کنید به trx_ai/eval/router_eval.py --failures).
#
# حالا مثلِ TOOLS/KEYWORD_SOURCE خودکار از PATTERNS ساخته می‌شود --
# دیگر جایی برایِ فراموش‌کردنِ یک نیتِ جدید وجود ندارد.
INTENT_TO_TOOL: dict[str, str] = {
    _spec.name: _spec.ref_tool for _spec in PATTERNS.values() if _spec.ref_tool
}


def get(name: str) -> IntentSpec | None:
    return PATTERNS.get(name)
