# -*- coding: utf-8 -*-
"""
حلقه‌یِ بازخورد/یادگیریِ محلی (گامِ ۵ روادمپ).

وقتی کاربر می‌گوید «نه، منظورم این نبود» (یا مشابه‌اش)، این ماژول آن
لحظه را تشخیص می‌دهد (``is_correction_trigger``). سپس core.py (طبقِ
همان الگویِ ``_pending_restore`` که از قبل برایِ تأییدِ بازیابیِ بکاپ
دارد) یک سؤالِ کوتاه می‌پرسد و پاسخِ بعدیِ کاربر را به‌عنوانِ نیتِ درست
به ``record_correction`` می‌دهد.

ذخیره‌سازی از همان sqlite / DatabaseManager موجود استفاده می‌کند (جدولِ
جدیدِ ``intent_corrections``)، نه یک فایلِ جداگانه -- تا با مکانیزمِ
پشتیبان‌گیری/بازیابیِ فعلی همخوان بماند (دقیقاً طبقِ یادداشتِ روادمپ).

``boost_from_feedback`` دقیقاً همان الگویی است که
``AutonomousLearningEngine`` برایِ حقایقِ عمومی دارد، اینجا برایِ
نگاشتِ متن→نیت تکرار می‌شود: اگر ورودیِ فعلی به یکی از تصحیح‌هایِ
قبلی خیلی شبیه باشد، امتیازِ همان نیتِ تصحیح‌شده موقتاً باال می‌رود.
"""

from __future__ import annotations

import re

from . import _levenshtein
from .types import MatchHit

CORRECTION_TRIGGER = re.compile(
    r'^(نه[،,]?\s*(منظورم|منظور\s*من)\s*این\s*نبود|'
    r'نه[،,]?\s*اشتباه\s*(گرفتی|فهمیدی|متوجه\s*شدی)|'
    r'این\s*(درست|همون)\s*نبود|'
    r'منظورم\s*این\s*نبود)\b'
)

SIMILARITY_THRESHOLD = 0.82
FEEDBACK_BOOST_SCORE = 15.0
MAX_CORRECTIONS_CHECKED = 200


def is_correction_trigger(text: str) -> bool:
    """آیا این پیام یک اعتراضِ صریحِ کاربر به تشخیصِ اشتباه است؟"""
    return bool(CORRECTION_TRIGGER.search((text or "").strip()))


def record_correction(original_query: str, correct_intent: str, db) -> bool:
    """
    جفتِ (متنِ اصلی، نیتِ درست) را در sqlite ذخیره می‌کند تا دفعه‌یِ بعد
    ورودیِ مشابه با اطمینانِ بیشتری تشخیص داده شود.
    """
    if db is None or not original_query or not correct_intent:
        return False
    record = getattr(db, "record_intent_correction", None)
    if record is None:
        return False
    try:
        return bool(record(original_query, correct_intent))
    except Exception:
        return False


def boost_from_feedback(
    norm_text: str,
    scores: dict[str, float],
    db,
    hits: list[MatchHit] | None = None,
) -> dict[str, float]:
    """
    اگر متنِ فعلی به یکی از تصحیح‌هایِ قبلیِ ذخیره‌شده شبیه باشد، امتیازِ
    نیتِ تصحیح‌شده را افزایش می‌دهد. در غیرِ این صورت ``scores`` را
    دست‌نخورده برمی‌گرداند.

    ``hits``: پارامترِ اختیاریِ جدید (رفعِ باگِ ۲۰۲۶-۰۹-۲۰: نگاه کنید به
    ``BUGFIX_v25_5_2_FEEDBACK_FUZZY_CAP.md``). اگر داده شود و بوستی
    واقعاً اعمال شود، یک ``MatchHit(matcher="feedback", ...)`` به آن
    append می‌شود -- تا مصرف‌کننده‌هایِ پایین‌دست (مثلِ
    ``conversation/intent_candidates.py``) بتوانند یک برنده‌یِ *واقعاً
    تصحیح‌شده‌یِ کاربر* را از یک تطبیقِ فازیِ تصادفی تشخیص بدهند --
    بدونِ این پارامتر رفتارِ قبلی (فقط برگرداندنِ ``scores``) کاملاً
    حفظ می‌شود؛ پیش‌فرضش ``None`` است، پس هیچ فراخوانیِ موجودی نمی‌شکند.
    """
    if db is None:
        return scores
    getter = getattr(db, "get_intent_corrections", None)
    if getter is None:
        return scores
    try:
        corrections = getter(limit=MAX_CORRECTIONS_CHECKED)
    except Exception:
        return scores
    if not corrections:
        return scores

    best_sim = 0.0
    best_intent: str | None = None
    for stored_text, corrected_intent in corrections:
        sim = _levenshtein.calculate_similarity(norm_text, stored_text)
        if sim > best_sim:
            best_sim, best_intent = sim, corrected_intent

    if best_intent and best_sim >= SIMILARITY_THRESHOLD:
        boosted = dict(scores)
        boost_amount = FEEDBACK_BOOST_SCORE * best_sim
        boosted[best_intent] = boosted.get(best_intent, 0.0) + boost_amount
        if hits is not None:
            hits.append(
                MatchHit(
                    intent=best_intent,
                    matcher="feedback",
                    detail=f"correction_similarity:{best_sim:.2f}",
                    score=boost_amount,
                )
            )
        return boosted
    return scores
