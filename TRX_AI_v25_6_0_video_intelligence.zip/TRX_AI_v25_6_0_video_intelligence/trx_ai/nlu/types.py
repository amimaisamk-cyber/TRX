# -*- coding: utf-8 -*-
"""
دیتاکلاس‌های مشترکِ موتورِ تشخیصِ نیت (nlu).

این فایل عمداً بدونِ هیچ منطقی است — فقط شکلِ داده را تعریف می‌کند تا
matchers، registry، scorer و ماژول‌هایِ intents/ همه یک زبانِ مشترک
داشته باشند.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class IntentSpec:
    """
    توصیفِ کاملِ یک نیت: دقیقاً همان چیزی که قبلاً یک ورودیِ دستیِ
    ``INTENT_PATTERNS[name]`` بود، به‌علاوه‌یِ فیلدهایِ جدید (synonyms،
    structural، ref_tool، ...) که در دیکشنریِ قدیمی وجود نداشتند.

    name:
        نامِ یکتایِ نیت (کلیدِ registry).
    category:
        دسته‌بندیِ نمایشی (مثلاً "tool"، "search"، "medical").
    keywords:
        کلیدواژه‌هایِ اصلی -- امتیازِ کامل می‌گیرند.
    synonyms:
        بسطِ محلیِ کلیدواژه‌ها -- امتیازِ کمی کمتر می‌گیرند (نکته‌یِ
        matchers/synonym.py) تا کلیدواژه‌یِ اصلی همچنان اولویتِ اول
        بماند.
    regex:
        الگوهایِ regex؛ هر تطبیق weight×۱.۵ امتیاز می‌دهد (دقیقاً مثلِ
        نسخه‌یِ قبلی).
    weight:
        وزنِ آماریِ این نیت در امتیازدهیِ IntentEngine.
    structural:
        الگوهایِ regexِ لنگرشده که همیشه با اطمینانِ ثابتِ ۰.۹۸ برنده
        می‌شوند (معادلِ STRUCTURAL_COMMANDS قدیمی). ترتیبِ بررسیِ این
        الگوها بینِ نیت‌هایِ مختلف در registry.STRUCTURAL_ORDER مشخص
        می‌شود، نه اینجا.
    ref_tool:
        نامِ ابزارِ متناظر در ToolScorer (اگر این نیت به یک ابزارِ
        اجراشدنی نگاشت می‌شود). None یعنی این نیت هیچ ابزارِ مستقیمی
        ندارد (مثلاً نیت‌هایِ گفتگویی/سیستمی).
    tool_weight / tool_category:
        وزن/دسته‌یِ این نیت وقتی به‌عنوانِ *ابزار* امتیازدهی می‌شود --
        این عمداً می‌تواند با weight/category بالا فرق کند (دقیقاً مثلِ
        TOOLS قدیمی که مقیاسِ وزنیِ متفاوتی از INTENT_PATTERNS داشت).
        اگر None باشد، از weight/category خودِ نیت استفاده می‌شود.
    positive_examples / negative_examples:
        جملاتِ برچسب‌خورده برایِ eval/run_eval.py.
    """

    name: str
    category: str = "general"
    keywords: tuple[str, ...] = ()
    synonyms: tuple[str, ...] = ()
    regex: tuple[str, ...] = ()
    weight: float = 1.0
    structural: tuple[str, ...] = ()
    ref_tool: str | None = None
    tool_weight: float | None = None
    tool_category: str | None = None
    tool_description: str = ""
    positive_examples: tuple[str, ...] = ()
    negative_examples: tuple[str, ...] = ()
    # آیا لایه‌ی فازی/تحملِ‌غلط‌املایی (matchers/fuzzy.py) برایِ این نیت
    # فعال باشد؟ پیش‌فرض False -- فعال‌سازی عمداً دستی و تدریجی است
    # (دقیقاً طبقِ توصیه‌یِ خودِ روادمپ برایِ گامِ ۴/۵: «اول ۳-۴ نیتِ
    # پرکاربرد، بعد بقیه» و «آستانه را با eval باید تنظیم کرد، نه
    # حدسی»). بدونِ این گیت، کلماتِ رایجِ کوتاه (مثلاً «سلام» در برابرِ
    # کلیدواژه‌یِ «سلامت») با فاصله‌یِ ویرایشیِ ۱ به‌اشتباه امتیاز
    # می‌گیرند -- خصوصاً خطرناک برایِ medical که فهرستِ کلیدواژه‌اش هم
    # طولانی و هم پرتصادف با کلماتِ روزمره است.
    fuzzy_enabled: bool = False
    # آیا لایه‌ی معنایی (matchers/semantic.py -- شباهتِ embedding با
    # positive_examples) برایِ این نیت فعال باشد؟ پیش‌فرض False، دقیقاً
    # با همان فلسفه‌ی fuzzy_enabled: فعال‌سازی دستی و تدریجی، اول رویِ
    # چند نیتِ پرکاربرد، بعد از تأییدِ run_eval.py. این لایه فقط وقتی
    # اثر دارد که پکیجِ اختیاریِ sentence-transformers نصب باشد؛ در غیرِ
    # این صورت بی‌صدا نادیده گرفته می‌شود (بدونِ خطا، بدونِ نیاز به
    # اینترنت یا کلیدِ API در زمانِ اجرا -- مدل کاملاً محلی است).
    semantic_enabled: bool = False
    # الگوهای regexِ *عمومیِ خیلی گسترده* (مثلاً «X چیست/چیه؟» که با هر
    # موضوعی تطبیق پیدا می‌کند) -- برخلافِ ``regex`` معمولی که همیشه
    # بدونِ قید‌وشرط امتیاز می‌دهد، این‌ها فقط وقتی به مجموعِ امتیازها
    # اضافه می‌شوند که در کلِ جمله *هیچ نیتِ دیگری* از قبل سرنخِ
    # کلیدواژه/مترادف/regexِ خاص‌تری نداشته باشد (نگاه کنید به
    # scorer._statistical_scores). دلیل: یک الگویِ عمومی مثلِ «X چیست»
    # اگر بدونِ قید امتیاز بدهد، هر جمله‌ای که تصادفاً به «چیست/چیه» ختم
    # شود را می‌بَرَد -- حتی اگر همان جمله یک عبارتِ کلیدیِ دوکلمه‌ایِ
    # نیتِ دیگری (مثلاً «مراحل انجام» در planning) را هم داشته باشد.
    # این فیلد دقیقاً همان فلسفه‌ی گیتِ fuzzy_enabled/semantic_enabled را
    # ادامه می‌دهد: یک لایه‌ی *نجات‌دهنده* برایِ جمله‌هایی که وگرنه به
    # "general" سقوط می‌کردند، نه یک امتیازِ برنده در برابرِ نیتی که
    # خودش واقعاً سرنخ دارد.
    fallback_regex: tuple[str, ...] = ()


@dataclass
class MatchHit:
    """یک شاهدِ منفرد برایِ اینکه چرا یک نیت امتیاز گرفت (برایِ دیباگ/eval)."""

    intent: str
    matcher: str  # "structural" | "keyword" | "synonym" | "regex" | "fuzzy" | "feedback"
    detail: str
    score: float


@dataclass
class IntentResult:
    """خروجیِ کاملِ تشخیصِ نیت -- نسخه‌یِ غنی‌ترِ سه‌تاییِ قدیمی."""

    intent: str
    confidence: float
    raw_text: str
    scores: dict[str, float] = field(default_factory=dict)
    hits: list[MatchHit] = field(default_factory=list)

    def __iter__(self):
        """
        سازگاری: کدهایی که قبلاً می‌نوشتند
        ``intent, confidence, raw = IntentEngine.detect_intent(...)``
        می‌توانند دقیقاً همان‌طور این شیء را هم باز کنند.
        """
        return iter((self.intent, self.confidence, self.raw_text))
