# -*- coding: utf-8 -*-
"""
user_state_registry.py -- تنها نقطه‌یِ مرکزیِ تعریفِ حالت‌هایِ کاربر.

دقیقاً همان دلیلِ ``nlu/registry.py`` برایِ نیت‌ها: یک منبعِ حقیقتِ
واحد، نه پخش‌شدنِ کلیدواژه‌ها در چند فایل (بخشِ ۴ و ۲۷ سند). چون تعدادِ
حالت‌ها کم و پایدار است (برخلافِ نیت‌ها که هرکدام یک فایلِ جدا در
``intents/`` دارند)، اینجا عمداً از الگویِ auto-discovery استفاده نشده
-- یک دیکشنریِ صریح، ساده‌تر برایِ مرور و نگهداری.

افزودنِ حالتِ جدید یعنی فقط یک ورودیِ جدید در ``USER_STATE_SPECS``؛ هیچ
فایلِ دیگری (``user_state.py``، ``response_strategy.py``) نیازی به
تغییر ندارد.
"""

from __future__ import annotations

from .user_state_types import UserStateSpec

USER_STATE_SPECS: dict[str, UserStateSpec] = {
    "neutral": UserStateSpec(
        name="neutral",
        description="بدونِ سیگنالِ خاصِ عاطفی/رفتاری -- حالتِ پیش‌فرض.",
        polarity="neutral",
    ),
    "tired": UserStateSpec(
        name="tired",
        description="خستگیِ ذهنی/جسمی -- نه لزوماً ناراحتی یا عصبانیت.",
        keywords=("خسته شدم", "خسته ام", "خسته‌ام", "خیلی خسته", "انرژی ندارم",
                  "دیگه نا ندارم", "بی حالم", "بی‌حالم", "رمق ندارم"),
        synonyms=("حال ندارم", "خواب آلودم", "خواب‌آلودم", "کوفته‌ام"),
        semantic_enabled=True,
        positive_examples=(
            "دیگه نمی‌تونم ادامه بدم، خیلی خسته شدم",
            "امروز خیلی خسته‌ام و فقط دلم می‌خواد استراحت کنم",
            "دیگه انرژی برام نمونده",
        ),
        threshold=0.58,
        weight=1.0,
        polarity="negative",
    ),
    "frustrated": UserStateSpec(
        name="frustrated",
        description="کلافگیِ ناشی از تلاشِ ناموفقِ تکرارشونده (نه صرفاً ناراحتیِ عاطفی).",
        keywords=("کلافه شدم", "کلافه‌ام", "دیگه بریدم", "دیگه نمی‌کشم",
                  "به نتیجه نمی‌رسم", "دیگه خسته شدم", "دیگه خسته‌ام",
                  "بازم نشد", "باز هم نشد", "باز خراب شد", "دوباره خراب شد",
                  "دوباره ارور داد", "جواب نداد", "درست نشد"),
        synonyms=("حوصلم سر رفته از بس امتحان کردم", "اعصابم خرده", "دیگه کشش ندارم"),
        semantic_enabled=True,
        positive_examples=(
            "چند بار درستش کردم ولی بازم خراب می‌شه، دیگه کلافه شدم",
            "از بس این مشکل رو امتحان کردم به نتیجه نرسیدم",
            "هر کاری می‌کنم درست نمی‌شه، اعصابم خرده",
        ),
        threshold=0.58,
        weight=1.1,
        polarity="negative",
    ),
    "confused": UserStateSpec(
        name="confused",
        description="عدمِ درکِ یک موضوع/توضیح -- نیازمندِ ساده‌سازی، نه همدلی.",
        keywords=("نمی‌فهمم", "نمیفهمم", "گیج شدم", "گیجم", "متوجه نمی‌شم",
                  "متوجه نمیشم", "سردرگمم", "قاطی کردم"),
        synonyms=("چی شد یهو", "اصلا نفهمیدم چی گفتی"),
        semantic_enabled=True,
        positive_examples=(
            "اصلاً نمی‌فهمم این قسمت چیکار می‌کنه",
            "یه بار دیگه ساده‌تر توضیح می‌دی؟ گیج شدم",
        ),
        threshold=0.6,
        weight=1.0,
        polarity="negative",
    ),
    "happy": UserStateSpec(
        name="happy",
        description="خوشحالیِ عمومی -- لزوماً نتیجه‌ی یک موفقیتِ مشخص نیست.",
        keywords=("خوشحالم", "خیلی خوشحال شدم", "عالیه", "حال خوبی دارم", "خوشحال‌ام"),
        semantic_enabled=True,
        positive_examples=("امروز خیلی حال خوبی دارم", "چقدر خوشحالم امروز"),
        threshold=0.6,
        weight=1.0,
        polarity="positive",
    ),
    "sad": UserStateSpec(
        name="sad",
        description="ناراحتیِ عاطفی -- نیازمندِ همدلی، نه راه‌حلِ فوری.",
        keywords=("ناراحتم", "غمگینم", "دلم گرفته", "حالم بده", "دلگیرم"),
        semantic_enabled=True,
        positive_examples=("امروز خیلی حالم بده و دلم گرفته", "دلم می‌خواد فقط یکی گوش بده"),
        threshold=0.6,
        weight=1.0,
        polarity="negative",
    ),
    "angry": UserStateSpec(
        name="angry",
        description="عصبانیت -- برخلافِ frustrated، لزوماً مرتبط با تلاشِ فنیِ ناموفق نیست.",
        keywords=("عصبانی‌ام", "عصبانیم", "حرصم گرفته", "کفریم", "خیلی عصبانیم"),
        semantic_enabled=True,
        positive_examples=("خیلی عصبانی‌ام از این وضعیت", "حرصم گرفته از این رفتار"),
        threshold=0.6,
        weight=1.0,
        polarity="negative",
    ),
    "excited": UserStateSpec(
        name="excited",
        description="هیجانِ مثبت -- معمولاً پیش از یا حینِ یک اتفاقِ خوب.",
        keywords=("هیجان زده‌ام", "هیجان‌زده‌ام", "خیلی ذوق دارم", "بی‌صبرم", "دلم لک زده"),
        semantic_enabled=True,
        positive_examples=("خیلی هیجان‌زده‌ام برای این پروژه", "بی‌صبرانه منتظرشم"),
        threshold=0.6,
        weight=1.0,
        polarity="positive",
    ),
    "bored": UserStateSpec(
        name="bored",
        description="بی‌حوصلگیِ ناشی از تکرار/کندی -- نه لزوماً خستگیِ فیزیکی.",
        keywords=("حوصله ندارم", "حوصلم سر رفته", "کسل‌کننده‌ست", "کسل کننده ست", "بی‌حوصله‌ام"),
        semantic_enabled=True,
        positive_examples=("این کار خیلی کسل‌کننده شده", "دیگه حوصله‌م سررفته از تکرار"),
        threshold=0.62,
        weight=0.95,
        polarity="negative",
    ),
    "disengaged": UserStateSpec(
        name="disengaged",
        description="بی‌علاقگی/قطعِ مشارکت -- سیگنالِ «دیگر پیگیری نکن».",
        keywords=("ولش کن", "بیخیال", "مهم نیست", "فرقی نداره", "اصلاً مهم نیست"),
        semantic_enabled=True,
        positive_examples=("ولش کن، مهم نیست دیگه", "بیخیال بحثش رو"),
        threshold=0.62,
        weight=1.0,
        polarity="negative",
    ),
    "curious": UserStateSpec(
        name="curious",
        description="کنجکاویِ مثبت -- تمایل به دانستنِ بیشتر.",
        keywords=("جالبه", "خیلی جالبه", "کنجکاوم", "دوست دارم بدونم", "چطور ممکنه"),
        semantic_enabled=True,
        positive_examples=("وای این خیلی جالبه، بیشتر بگو", "کنجکاوم بدونم این چطور کار می‌کنه"),
        threshold=0.6,
        weight=0.95,
        polarity="positive",
    ),
    "stressed": UserStateSpec(
        name="stressed",
        description="استرس/نگرانیِ فعال -- نزدیک به anxious در conversation_patterns.py.",
        keywords=("استرس دارم", "نگرانم", "دلشوره دارم", "تحتِ فشارم", "تحت فشارم", "می‌ترسم"),
        semantic_enabled=True,
        positive_examples=("خیلی استرس دارم و ذهنم آروم نمی‌شه", "نگرانم که درست نشه"),
        threshold=0.58,
        weight=1.0,
        polarity="negative",
    ),
    "satisfied": UserStateSpec(
        name="satisfied",
        description="رضایت از یک نتیجه‌ی مشخص -- معمولاً پس از حلِ یک مشکل.",
        keywords=("دمت گرم", "درست شد", "حل شد", "عالی شد", "راضیم", "جواب داد"),
        semantic_enabled=True,
        positive_examples=("بالاخره درست شد، ممنون", "دمت گرم، حل شد مشکل"),
        threshold=0.6,
        weight=1.0,
        polarity="positive",
    ),
    "dissatisfied": UserStateSpec(
        name="dissatisfied",
        description="نارضایتی از یک نتیجه -- برخلافِ frustrated، لزوماً تلاشِ تکرارشونده نیست.",
        keywords=("راضی نیستم", "خوب نشد", "بد شد", "دوست نداشتم", "انتظار این رو نداشتم"),
        semantic_enabled=True,
        positive_examples=("از نتیجه راضی نیستم", "این چیزی نبود که انتظار داشتم"),
        threshold=0.6,
        weight=1.0,
        polarity="negative",
    ),
}
