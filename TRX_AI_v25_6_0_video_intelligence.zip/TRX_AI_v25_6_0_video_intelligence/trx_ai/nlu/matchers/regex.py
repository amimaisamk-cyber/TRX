# -*- coding: utf-8 -*-
"""
اجرایِ الگوهایِ regex هر نیت -- دقیقاً همان قانونِ قدیمی: هر الگویی که
تطبیق پیدا کند weight×۱.۵ امتیاز می‌دهد. تعدادشان کم است، پس نیازی به
مسیرِ نیتیو ندارند (طبق یادداشتِ روادمپ).
"""

from __future__ import annotations

import re

REGEX_WEIGHT_MULTIPLIER = 1.5


def regex_score(text: str, patterns: tuple[str, ...], weight: float) -> float:
    score = 0.0
    for pattern in patterns:
        try:
            if re.search(pattern, text):
                score += weight * REGEX_WEIGHT_MULTIPLIER
        except re.error:
            continue
    return score
