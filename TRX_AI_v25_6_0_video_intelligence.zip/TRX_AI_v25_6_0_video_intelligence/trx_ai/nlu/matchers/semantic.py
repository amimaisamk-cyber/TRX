# -*- coding: utf-8 -*-
"""
تطبیقِ معنایی با embedding محلی -- برایِ نیت‌هایی که هیچ تطبیقِ دقیقی
(کلیدواژه/مترادف/regex/فازی) پیدا نکرده‌اند اما از نظرِ *معنا* خیلی به
یکی از ``positive_examples`` آن نیت نزدیک‌اند.

مثال: «بگو این کلمه رو چطوری میگن انگلیسیا» -- هیچ‌کدام از کلیدواژه‌های
translator (ترجمه/به انگلیسی/...) را ندارد، ولی معنایش با «این جمله رو
به انگلیسی ترجمه کن» (یکی از positive_examples همان نیت) خیلی نزدیک
است؛ کلیدواژه/regex/فازی این را نمی‌بینند چون اصلاً کلمه‌ی مشترکی رد و
بدل نشده.

طراحی -- دقیقاً همان فلسفه‌یِ محافظه‌کارانه‌ی fuzzy.py:
    - فقط برایِ نیت‌هایی اجرا می‌شود که semantic_enabled=True دارند
      (فعال‌سازیِ دستی و تدریجی، رجوع به IntentSpec.semantic_enabled).
    - در scorer.py فقط وقتی به یک نیت اضافه می‌شود که امتیازِ آن هنوز
      صفر است -- یعنی هرگز یک برنده‌ی واقعیِ کلیدواژه/regex را عوض
      نمی‌کند، فقط نیت‌هایی را نجات می‌دهد که وگرنه به «general» سقوط
      می‌کردند.
    - زیرِ آستانه‌یِ شباهت صفر برمی‌گرداند (نه امتیازِ منفی) تا نویز
      اضافه نکند؛ آستانه با eval قابلِ تنظیم است، نه حدسی.

بارگذاریِ مدل از ``trx_ai.embedding_backend`` می‌آید -- همان نمونه‌یِ
مشترکی که ``memory_store.py`` و ``conversation_patterns.py`` هم استفاده
می‌کنند (یک لود، سه مصرف). بدونِ اینترنت/کلیدِ API در زمانِ اجرا: مدل
فقط یک‌بار (بعد از ``pip install sentence-transformers``) کاملاً محلی
لود و اجرا می‌شود.

اگر پکیج نصب نباشد یا لودِ مدل با خطا مواجه شود، این ماژول کاملاً
بی‌صدا غیرفعال می‌ماند (``semantic_score`` همیشه ۰.۰ برمی‌گرداند) --
بقیه‌ی موتورِ تشخیصِ نیت دقیقاً مثلِ قبل کار می‌کند.
"""

from __future__ import annotations

from ... import embedding_backend as backend

# آستانه‌یِ پیش‌فرضِ شباهتِ کسینوسی -- زیرِ این مقدار امتیاز صفر است.
# بعدِ نصبِ sentence-transformers با ``python -m trx_ai.nlu.eval.run_eval``
# قابلِ تنظیمِ دقیق است.
DEFAULT_THRESHOLD = 0.55

# name -> (examples_tuple, embedding_matrix) -- کشِ سبکِ حافظه‌ای؛ چون
# positive_examples هر نیت در طولِ اجرایِ برنامه ثابت است، محاسبه فقط
# یک‌بار به‌ازایِ هر نیت لازم است.
_example_cache: dict = {}


def is_available() -> bool:
    """آیا لایه‌ی معنایی واقعاً فعال است (پکیج نصب و مدل قابلِ لود است)؟"""
    return backend.is_available()


def _examples_matrix(intent_name: str, examples: tuple):
    cached = _example_cache.get(intent_name)
    if cached is not None and cached[0] == examples:
        return cached[1]
    matrix = backend.encode(list(examples))
    if matrix is None:
        return None
    _example_cache[intent_name] = (examples, matrix)
    return matrix


def semantic_score(text: str, spec, weight: float, threshold: float = DEFAULT_THRESHOLD) -> float:
    """
    بیشینه‌ی شباهتِ کسینوسیِ ``text`` با ``spec.positive_examples``،
    نگاشت‌شده به بازه‌ی ``[0, weight]``. اگر ``spec.semantic_enabled``
    نباشد، پکیج نصب نباشد، یا شباهت زیرِ ``threshold`` باشد: ۰.۰.
    """
    if not getattr(spec, "semantic_enabled", False):
        return 0.0
    if not spec.positive_examples or not text.strip():
        return 0.0

    matrix = _examples_matrix(spec.name, spec.positive_examples)
    if matrix is None:
        return 0.0

    query_vec = backend.encode(text)
    if query_vec is None:
        return 0.0

    similarities = backend.cosine_sim(query_vec, matrix)
    best = float(similarities.max())

    if best < threshold:
        return 0.0
    return (best - threshold) / (1.0 - threshold) * weight
