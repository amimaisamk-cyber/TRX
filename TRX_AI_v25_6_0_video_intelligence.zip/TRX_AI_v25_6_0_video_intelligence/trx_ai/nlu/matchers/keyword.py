# -*- coding: utf-8 -*-
"""
تطبیقِ کلیدواژه با مرزِ کلمه + آگاهی از نفی.

این ماژول دقیقاً همان منطقِ ``IntentEngine._keyword_hit_score`` قدیمی را
نگه می‌دارد (از جمله مسیرِ سریعِ نیتیوِ ++C اگر موجود باشد) -- فقط از
کلاس بیرون کشیده شده تا هم توسطِ scorer.py و هم توسطِ ابزارهایِ دیگر
(مثلاً feedback.py) قابلِ استفاده باشد بدونِ وابستگی به کلِ intelligence.py.
"""

from __future__ import annotations

import re

try:
    from ... import _intent_native as _native  # type: ignore
except ImportError:  # pragma: no cover - محیط‌هایی که ماژولِ نیتیو ندارند
    _native = None

# علائمِ منفی‌ساز که در نزدیکیِ یک کلیدواژه امتیازِ آن را کاهش می‌دهند.
NEGATIONS: tuple[str, ...] = ("ندارم", "نیست", "نبود", "نداشتم", "نه ")

_NEGATION_WINDOW = 12


def _boundary_pattern(keyword: str) -> re.Pattern[str] | None:
    """
    کامپایلِ regexِ مرزبندی‌شده‌یِ یک عبارت -- منطقِ مشترکِ زیرِ
    ``keyword_hit_score`` و ``phrase_in_text``. جدا شده تا هر دو دقیقاً
    یک قانون داشته باشند (نه دو پیاده‌سازیِ موازی که ممکن است واگرا
    شوند -- رجوع به اصلِ «منبعِ واحدِ حقیقت» در یادداشت‌هایِ پروژه).
    """
    kw = keyword.replace("\u200c", " ").strip().lower()
    if not kw:
        return None
    ends_with_word_char = bool(re.match(r".*[\w\u0600-\u06FF]$", kw))
    lead = r"(?<!\S)"
    trail = r"(?!\S)" if ends_with_word_char else ""
    return re.compile(lead + re.escape(kw) + trail)


def phrase_in_text(text: str, phrase: str) -> bool:
    """
    True اگر ``phrase`` با مرزِ کلمه (نه substringِ خام) در ``text`` دیده
    شود. برایِ ماژول‌هایی که فقط یک بررسیِ بولیِ ساده لازم دارند (نه
    امتیازدهیِ کامل/آگاهی از نفی مثلِ ``keyword_hit_score``) -- مثلاً
    ``conversation_patterns.py`` که کلیدواژه‌هایِ حال/نوع/کنش را با
    substringِ خام چک می‌کرد و همین باعث می‌شد «کد» داخلِ «کدام» یا «نه»
    داخلِ «خونه» به‌اشتباه match بگیرد.
    """
    pat = _boundary_pattern(phrase)
    return bool(pat.search(text)) if pat else False


def keyword_hit_score(text: str, keyword: str) -> float:
    """
    امتیازِ یک کلیدواژه در متن: با مرزبندیِ کلمه (نه فقط substring) و
    کاهشِ امتیاز در صورتِ وجودِ نشانه‌یِ نفیِ نزدیکِ آن.
    """
    if _native is not None:
        return _native.keyword_hit_score(text, keyword)
    pat = _boundary_pattern(keyword)
    if pat is None:
        return 0.0
    matches = list(pat.finditer(text))
    if not matches:
        return 0.0
    score = 0.0
    for m in matches:
        window = text[max(0, m.start() - _NEGATION_WINDOW) : m.start()]
        negated = any(neg in window for neg in NEGATIONS)
        score += 0.4 if negated else 1.0
    return score
