# -*- coding: utf-8 -*-
"""
بسطِ کلیدواژه با مترادف/عباراتِ محلیِ هر نیت (IntentSpec.synonyms).

برخلافِ کلیدواژه‌هایِ اصلی، مترادف‌ها با ضریبِ ``SYNONYM_WEIGHT_FACTOR``
امتیازدهی می‌شوند -- یعنی می‌توانند یک نیت را از صفر بیرون بیاورند، اما
به‌تنهایی به‌همان قطعیتِ یک کلیدواژه‌یِ اصلی نمی‌رسند. این عمداً از
لیستِ کلیدواژه‌هایِ اصلی جدا نگه داشته می‌شود (نه merge در registry)
تا مسیرِ نیتیو (که فقط کلیدواژه‌هایِ اصلی را می‌بیند) دست‌نخورده بماند.
"""

from __future__ import annotations

from .keyword import keyword_hit_score

SYNONYM_WEIGHT_FACTOR = 0.85


def synonym_score(text: str, synonyms: tuple[str, ...], weight: float) -> float:
    score = 0.0
    for syn in synonyms:
        score += keyword_hit_score(text, syn) * weight * SYNONYM_WEIGHT_FACTOR
    return score
