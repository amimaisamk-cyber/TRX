# -*- coding: utf-8 -*-
"""
تطبیقِ تحمل‌پذیرِ غلطِ املایی/پسوندِ محاوره‌ای -- برایِ نیت‌هایی که هیچ
تطبیقِ دقیقی (کلیدواژه/مترادف/regex) پیدا نکردند.

طراحیِ عمدیِ محافظه‌کارانه: این تابع فقط برایِ *نجاتِ* نیت‌هایی به کار
می‌رود که در غیرِ این صورت امتیازشان صفر می‌ماند (مثلاً «حوا» به‌جایِ
«هوا»، یا «هواشو» به‌جایِ «هوا»). هرگز به نیتی که از قبل با تطبیقِ دقیق
امتیاز گرفته اضافه نمی‌شود -- یعنی هیچ‌کدام از تست‌هایِ رگرسیونِ فعلی
(که رویِ تطبیقِ دقیق ساخته شده‌اند) نمی‌توانند از این لایه تحتِ‌تأثیر
قرار بگیرند. از همان الگوریتمِ Levenshtein که در
``trx_ai.tools.TextSimilarityEngine`` از قبل استفاده می‌شود بهره می‌برد
(طبقِ توصیه‌یِ روادمپ: از پیاده‌سازیِ موجود استفاده کن، دوباره ننویس).
"""

from __future__ import annotations

import re

from .. import _levenshtein
from ..normalizer import stem

FUZZY_WEIGHT_FACTOR = 0.5
_MIN_KEYWORD_LEN = 3
_TOKEN_STRIP_CHARS = "().,!؟?:؛\"'«»"


def _tokens(text: str) -> list[str]:
    return [t.strip(_TOKEN_STRIP_CHARS) for t in re.split(r"\s+", text) if t.strip(_TOKEN_STRIP_CHARS)]


def _max_distance_for(keyword_len: int) -> int:
    # طبقِ خودِ مثال‌هایِ روادمپ («هوا»→«حوا»، «ترجمه»→«ترجمعه») هر دو
    # فاصله‌یِ ویرایشیِ ۱ دارند. آستانه‌یِ ۲ برایِ کلماتِ بلندتر امتحان
    # شد اما باعثِ قاطیِ کلماتِ کاملاً بی‌ربط می‌شد (مثلاً «تهران» با
    # فاصله‌یِ ۲ به‌اشتباه به «تومان» شبیه تشخیص داده می‌شد). پس طبقِ
    # همان اصلِ خودِ روادمپ («آستانه را باید با eval تنظیم کرد، نه
    # حدسی») این آستانه بعدِ ارزیابیِ عملی رویِ ۱ ثابت نگه داشته شده.
    return 1


def fuzzy_keyword_hit(text: str, keyword: str) -> bool:
    """
    True اگر یک توکنِ متن (با ریشه‌یابیِ سبک یا فاصله‌یِ ویرایشیِ کم) به
    این کلیدواژه شبیه باشد. فقط برایِ کلیدواژه‌هایِ تک‌کلمه‌ای معنی دارد؛
    عبارات چندکلمه‌ای رد می‌شوند (پرهزینه و پرنویز است).
    """
    kw = keyword.replace("\u200c", " ").strip().lower()
    if not kw or " " in kw or len(kw) < _MIN_KEYWORD_LEN:
        return False
    kw_stem = stem(kw)
    max_dist = _max_distance_for(len(kw))
    for tok in _tokens(text):
        if not tok or tok == kw:
            continue  # تطبیقِ دقیق قبلاً جایِ دیگری حساب شده
        if stem(tok) == kw_stem:
            return True
        if abs(len(tok) - len(kw)) <= max_dist:
            if _levenshtein.levenshtein_distance(tok, kw) <= max_dist:
                return True
    return False


def fuzzy_score(text: str, keywords: tuple[str, ...], weight: float) -> float:
    """امتیازِ فازیِ یک نیت: اولین کلیدواژه‌یِ تک‌کلمه‌ایِ تطبیق‌خورده کافی است."""
    for kw in keywords:
        if fuzzy_keyword_hit(text, kw):
            return weight * FUZZY_WEIGHT_FACTOR
    return 0.0
