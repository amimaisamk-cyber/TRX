# -*- coding: utf-8 -*-
"""
تشخیصِ چندنیتی (گامِ ۷ روادمپ): «هوای تهران چطوره و دلار چنده؟» باید هر
دو نیت (weather + currency) را برگرداند، نه فقط یکی.

این ماژول جمله را با حروفِ ربطِ رایج («و»، «همچنین»، ویرگول) به چند
بندِ مستقل می‌شکند، هرکدام را جداگانه با همان ``scorer.detect`` نمره
می‌دهد، و اگر بیش از یک نیتِ قوی پیدا شد، لیستی از IntentResult
برمی‌گرداند.

طبقِ یادداشتِ خودِ روادمپ («ریسکِ متوسط»، نیازمندِ ترکیبِ پاسخ‌ها در
core.py)، این قابلیت اینجا کاملاً پیاده و تست‌پذیر است اما به‌صورتِ
پیش‌فرض به مسیرِ اصلیِ ``IntentEngine.detect_intent`` وصل نشده -- چون
آن تابع طبقِ قراردادِ فعلی فقط یک (intent, confidence, raw) برمی‌گرداند
و core.py هنوز منطقِ «اجرایِ دو ابزار و ترکیبِ دو پاسخ» را ندارد. این
تابع به‌عنوانِ یک قابلیتِ آماده برایِ گامِ بعدی (وقتی core.py برایِ
ترکیبِ پاسخ‌ها آماده شود) در دسترس است -- بدونِ اینکه ریسکی به مسیرِ
پایدارِ فعلی اضافه کند.
"""

from __future__ import annotations

import re

from .types import IntentResult

_SPLIT_PATTERN = re.compile(r'\s*(?:،|,|\bو\b|\bهمچنین\b)\s*')
_MIN_CLAUSE_LEN = 3
_STRONG_CONFIDENCE = 0.55


def split_clauses(text: str) -> list[str]:
    """جمله را به بندهای مستقل می‌شکند (خامِ حروفِ ربط، بدونِ NLP سنگین)."""
    parts = [p.strip() for p in _SPLIT_PATTERN.split(text or "") if p.strip()]
    return [p for p in parts if len(p) >= _MIN_CLAUSE_LEN]


def split_intents(text: str, *, detect_fn, context=None, db=None) -> list[IntentResult]:
    """
    ``detect_fn`` همان ``scorer.detect`` است (این‌جا به‌صورتِ پارامتر
    گرفته می‌شود تا importِ چرخه‌ای بینِ multi_intent.py و scorer.py
    پیش نیاید).

    خروجی: لیستِ نیت‌هایِ *متمایز و قوی* (confidence >= آستانه)، به
    ترتیبی که در جمله ظاهر شده‌اند. اگر کلِ جمله فقط یک نیتِ معنادار
    داشته باشد، یک‌عضوی برمی‌گردد (رفتار یکسان با تکِ‌نیتیِ قبلی).
    """
    clauses = split_clauses(text)
    if len(clauses) < 2:
        return [detect_fn(text, context=context, db=db)]

    results: list[IntentResult] = []
    seen_intents: set[str] = set()
    for clause in clauses:
        result = detect_fn(clause, context=context, db=db)
        if result.intent == "general" or result.confidence < _STRONG_CONFIDENCE:
            continue
        if result.intent in seen_intents:
            continue
        seen_intents.add(result.intent)
        results.append(result)

    if not results:
        # هیچ بندی به‌تنهایی نیتِ قوی نداد -- به رفتارِ قبلی (نمره‌دهیِ
        # کلِ جمله به‌صورتِ یکجا) برمی‌گردیم تا چیزی از دست نرود.
        return [detect_fn(text, context=context, db=db)]
    return results
