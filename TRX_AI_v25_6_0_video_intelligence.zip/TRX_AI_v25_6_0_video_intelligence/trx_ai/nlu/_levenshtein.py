# -*- coding: utf-8 -*-
"""
پیاده‌سازیِ محلیِ فاصله‌ی ویرایشی (Levenshtein).

چرا این یک کپیِ کوچک است، نه importِ مستقیم از
``trx_ai.tools.TextSimilarityEngine``: آن الگوریتم عیناً همین است (و
همانی است که روادمپ توصیه کرده بود دوباره‌نویسی نشود) -- اما
``trx_ai/tools.py`` در همان فایل چند کلاسِ دیگر هم دارد که در سطحِ
ماژول ``aiohttp`` ایمپورت می‌کنند. تستِ رگرسیونِ فعلیِ
``tests/test_intent_engine.py`` صریحاً روی این فرض بنا شده که
``trx_ai/intelligence.py`` «هیچ وابستگیِ سنگینی ندارد (فقط ``re``)... بدونِ
نیاز به شبکه». وارد کردنِ کلِ ``trx_ai.tools`` از داخلِ زنجیره‌ی
IntentEngine همین فرض را می‌شکند (و در محیط‌هایی که ``aiohttp`` نصب
نیست، کلِ تشخیصِ نیت را خراب می‌کند). پس همان الگوریتم، بدونِ آن
وابستگی، اینجا تکرار شده.
"""

from __future__ import annotations


def levenshtein_distance(s1: str, s2: str) -> int:
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            current_row.append(
                min(
                    previous_row[j + 1] + 1,
                    current_row[j] + 1,
                    previous_row[j] + (c1 != c2),
                )
            )
        previous_row = current_row
    return previous_row[-1]


def calculate_similarity(w1: str, w2: str) -> float:
    w1, w2 = w1.strip().lower(), w2.strip().lower()
    max_len = max(len(w1), len(w2))
    if max_len == 0:
        return 1.0
    return 1.0 - (levenshtein_distance(w1, w2) / max_len)
