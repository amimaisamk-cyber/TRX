# -*- coding: utf-8 -*-
"""
user_state.py -- تشخیصِ وضعیتِ احتمالیِ کاربر در مکالمه.

هدف (طبقِ سندِ ارتقا): TRX AI فقط «نیت کاربر» را تشخیص ندهد، بلکه
بفهمد کاربر در این لحظه‌ی مکالمه چه وضعیتِ احتمالی‌ای دارد (خسته،
کلافه، گیج، ...) و این را به‌عنوانِ یک محورِ کاملاً *جدا* از Intent در
اختیارِ Response Strategy بگذارد.

معماری -- دقیقاً همان لایه‌بندیِ چندگانه‌یِ ``nlu/scorer.py`` برایِ
نیت‌ها، فقط رویِ ``USER_STATE_SPECS``:

    Normalization → Keyword → Synonym → Fuzzy (اختیاری) →
    Semantic (اختیاری، embedding محلی) → Context Analysis → Score Fusion

نکته‌هایِ طراحیِ عمدی:
    - این ماژول از همان ``embedding_backend`` مشترک استفاده می‌کند
      (بخشِ ۲۱ سند: «یک Embedding Backend برایِ همه»)، نه یک مدلِ جدا.
    - بدونِ sentence-transformers نصب‌شده، لایه‌ی معنایی بی‌صدا صفر
      امتیاز می‌دهد -- بقیه‌ی لایه‌ها (کلیدواژه/مترادف/فازی) دقیقاً مثلِ
      قبل کار می‌کنند (بخشِ ۲۲: Offline First).
    - سیستم عمداً نسبت به وضعیتِ کاربر «بیش از حد مطمئن» نمی‌شود: اگر
      فاصله‌ی امتیازِ برنده تا نفرِ دوم کم باشد یا سیگنالِ خام ضعیف
      باشد، ``UserStateResult.uncertain = True`` می‌شود (بخشِ ۷/۲۶).
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Optional

from . import _levenshtein
from .matchers.fuzzy import fuzzy_score
from .matchers.keyword import keyword_hit_score
from .matchers.regex import regex_score
from .matchers.semantic import semantic_score
from .matchers.synonym import synonym_score
from .normalizer import normalize
from .user_state_registry import USER_STATE_SPECS
from .user_state_types import SingleState, StateHit, UserStateResult

# وزنِ نسبیِ زمینه (پیام‌هایِ *قبل* از پیامِ فعلی) در امتیازدهی -- کمتر
# از خودِ پیامِ فعلی، اما کافی برایِ اینکه بتواند حالتی را که خودِ پیامِ
# فعلی به‌تنهایی نشان نمی‌دهد هم وارد کند (بخشِ ۹ سند: مثالِ دیباگِ
# چندنوبتی که «خسته شدم» فقط با context معنایِ frustrated هم می‌گیرد).
CONTEXT_WEIGHT = 0.30

# اگر اطمینانِ نهایی از این کمتر باشد، خروجی uncertain می‌شود.
LOW_CONFIDENCE_THRESHOLD = 0.45

# اگر فاصله‌ی نسبیِ امتیازِ برنده تا نفرِ دوم از این کمتر باشد، یعنی دو
# حالت به هم خیلی نزدیک‌اند -> uncertain (بخشِ ۲۶: «۰.۵۲ در برابرِ ۰.۴۹
# نباید با اطمینانِ بالا انتخاب شود»).
LOW_MARGIN_THRESHOLD = 0.18

# هر حالتِ دیگری که امتیازش دستِ‌کم این نسبت از حالتِ برنده باشد،
# به‌عنوانِ حالتِ ثانویه هم گزارش می‌شود (نه فقط جایگزینِ برنده -- بخشِ
# ۶: خروجیِ چندحالته).
SECONDARY_RATIO = 0.55
MAX_STATES = 3

_MATCHER_EVIDENCE_LABEL = {
    "keyword": "phrase_match",
    "synonym": "synonym_match",
    "regex": "pattern_match",
    "fuzzy": "fuzzy_match",
    "semantic": "semantic_match",
    "context": "context_match",
    "history": "history_match",
}

_STATE_FEEDBACK_KEY = "nlu:user_state_corrections"
_FEEDBACK_SIMILARITY_THRESHOLD = 0.82
_FEEDBACK_BOOST = 3.0


def _raw_scores(norm: str) -> tuple[dict[str, float], list[StateHit]]:
    """کلیدواژه + مترادف + regex + فازی + معنایی -- دقیقاً به همان ترتیبِ
    محافظه‌کارانه‌یِ ``nlu/scorer._statistical_scores`` برایِ نیت‌ها."""
    scores: dict[str, float] = {}
    hits: list[StateHit] = []

    for name, spec in USER_STATE_SPECS.items():
        if name == "neutral":
            continue
        s = 0.0
        for kw in spec.keywords:
            hs = keyword_hit_score(norm, kw)
            if hs:
                weighted = hs * spec.weight
                s += weighted
                hits.append(StateHit(name, "keyword", kw, weighted))
        if spec.synonyms:
            syn = synonym_score(norm, spec.synonyms, spec.weight)
            if syn:
                s += syn
                hits.append(StateHit(name, "synonym", spec.synonyms[0], syn))
        if spec.regex:
            rx = regex_score(norm, spec.regex, spec.weight)
            if rx:
                s += rx
                hits.append(StateHit(name, "regex", "pattern", rx))
        if s > 0:
            scores[name] = s

    # فازی -- فقط برای حالت‌هایی که هنوز صفرند و صریحاً فعال‌اند (هرگز
    # یک تطبیقِ دقیق را عوض نمی‌کند، فقط نجات می‌دهد).
    for name, spec in USER_STATE_SPECS.items():
        if name == "neutral" or not spec.fuzzy_enabled or scores.get(name, 0.0) > 0:
            continue
        fs = fuzzy_score(norm, spec.keywords, spec.weight)
        if fs:
            scores[name] = fs
            hits.append(StateHit(name, "fuzzy", "edit-distance", fs))

    # معنایی -- فقط برای حالت‌هایی که هنوز صفرند و صریحاً فعال‌اند. اگر
    # sentence-transformers نصب نباشد، semantic_score همیشه ۰ می‌دهد.
    for name, spec in USER_STATE_SPECS.items():
        if name == "neutral" or not spec.semantic_enabled or scores.get(name, 0.0) > 0:
            continue
        ss = semantic_score(norm, spec, spec.weight, threshold=spec.threshold)
        if ss:
            scores[name] = ss
            hits.append(StateHit(name, "semantic", "embedding", ss))

    return scores, hits


def _boost_from_feedback(norm: str, scores: dict[str, float], db) -> dict[str, float]:
    """
    اگر متنِ فعلی به یکی از تصحیح‌هایِ قبلیِ ثبت‌شده‌یِ کاربر شبیه باشد،
    امتیازِ همان حالتِ تصحیح‌شده را کمی بالا می‌برد -- دقیقاً همان الگویِ
    ``nlu/feedback.py`` برایِ نیت (بخشِ ۲۰ سند)، اما رویِ یک کلیدِ
    profileِ جداگانه (بدونِ نیاز به migration جدولِ دیتابیس).
    """
    if db is None:
        return scores
    getter = getattr(db, "get_profile", None)
    if getter is None:
        return scores
    try:
        raw = getter(_STATE_FEEDBACK_KEY, "[]")
        corrections = json.loads(raw) if raw else []
    except Exception:
        return scores
    if not corrections:
        return scores

    best_sim, best_state = 0.0, None
    for item in corrections[-200:]:
        stored_text = item.get("text", "")
        state = item.get("state")
        if not stored_text or not state:
            continue
        sim = _levenshtein.calculate_similarity(norm, normalize(stored_text))
        if sim > best_sim:
            best_sim, best_state = sim, state

    if best_state and best_sim >= _FEEDBACK_SIMILARITY_THRESHOLD:
        boosted = dict(scores)
        boosted[best_state] = boosted.get(best_state, 0.0) + _FEEDBACK_BOOST * best_sim
        return boosted
    return scores


def record_state_correction(text: str, correct_state: str, db) -> bool:
    """
    ذخیره‌ی یک تصحیحِ صریح («این تشخیص اشتباه بود، حالتِ درست این
    بود») -- بدونِ محدودیت، هر پیامِ کاربر را به‌عنوانِ داده‌یِ آموزشیِ
    دائمی ذخیره نمی‌کند؛ فقط مواردی که صراحتاً تصحیح شده‌اند (بخشِ ۲۰).
    """
    if db is None or not text or not correct_state or correct_state not in USER_STATE_SPECS:
        return False
    setter = getattr(db, "set_profile", None)
    getter = getattr(db, "get_profile", None)
    if setter is None or getter is None:
        return False
    try:
        raw = getter(_STATE_FEEDBACK_KEY, "[]")
        data = json.loads(raw) if raw else []
        data.append({"text": text, "state": correct_state})
        data = data[-200:]
        setter(_STATE_FEEDBACK_KEY, json.dumps(data, ensure_ascii=False))
        return True
    except Exception:
        return False


def detect(text: str, context_text: str = "", db=None) -> UserStateResult:
    """
    تشخیصِ وضعیتِ کاربر برایِ یک پیامِ منفرد.

    ``context_text``: نوبت‌هایِ *قبل* از همین پیام (اختیاری) -- برایِ
    Context Analysis (بخشِ ۹). ``db``: اگر داده شود، از تصحیح‌هایِ
    قبلیِ کاربر هم استفاده می‌شود (بخشِ ۲۰).
    """
    raw = text or ""
    norm = normalize(raw)
    scores, hits = _raw_scores(norm)

    if context_text:
        ctx_scores, ctx_hits = _raw_scores(normalize(context_text))
        for name, sc in ctx_scores.items():
            scores[name] = scores.get(name, 0.0) + sc * CONTEXT_WEIGHT
        for h in ctx_hits:
            hits.append(StateHit(h.state, "context", h.detail, h.score * CONTEXT_WEIGHT))

    if db is not None:
        scores = _boost_from_feedback(norm, scores, db)

    if not scores:
        return UserStateResult(
            primary_state="neutral", confidence=0.4, raw_text=raw,
            states=[SingleState("neutral", 0.4)], evidence=[],
        )

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    best_name, best_score = ranked[0]
    second_score = ranked[1][1] if len(ranked) > 1 else 0.0

    margin = (best_score - second_score) / best_score if best_score > 0 else 0.0
    absolute = min(best_score / 3.0, 1.0)
    confidence = round(max(0.3, min(0.99, 0.55 * margin + 0.45 * absolute)), 3)

    uncertain = confidence < LOW_CONFIDENCE_THRESHOLD or margin < LOW_MARGIN_THRESHOLD

    states = [SingleState(best_name, confidence)]
    for name, sc in ranked[1:MAX_STATES]:
        if sc >= best_score * SECONDARY_RATIO:
            secondary_conf = round(min(0.95, (sc / best_score) * confidence), 3)
            states.append(SingleState(name, secondary_conf))

    evidence = []
    for h in hits:
        if h.state != best_name:
            continue
        label = _MATCHER_EVIDENCE_LABEL.get(h.matcher, h.matcher)
        if label not in evidence:
            evidence.append(label)

    return UserStateResult(
        primary_state=best_name,
        confidence=confidence,
        raw_text=raw,
        states=states,
        evidence=evidence,
        uncertain=uncertain,
    )


class UserStateSessionMemory:
    """
    Stateِ *مکالمه‌یِ جاری*، عمداً جدا از هرگونه ویژگیِ دائمیِ کاربر
    (بخشِ ۱۹ سند). ``current_state`` یک TTL بر اساسِ تعدادِ نوبت دارد --
    خسته‌بودنِ چند نوبتِ پیش نباید تا فردا روی لحنِ پاسخ اثر بگذارد.
    ``state_history`` جداگانه و بدونِ TTL نگه داشته می‌شود (فقط برایِ
    گزارش/تحلیل، نه برایِ تصمیم‌گیریِ لحظه‌ای).

    این کلاس عمداً چیزی در دیتابیسِ دائمی ذخیره نمی‌کند -- یک شیِ
    درون‌حافظه‌ای برایِ طولِ یک نشست/جلسه است (دقیقاً مثلِ
    ``ConversationPatternEngine.turn_buffer``).
    """

    def __init__(self, ttl_turns: int = 6, max_history: int = 50):
        self.ttl_turns = ttl_turns
        self.max_history = max_history
        self.current_state: Optional[str] = None
        self.current_confidence: float = 0.0
        self._age = 0
        self.state_history: list[dict] = []

    def update(self, result: UserStateResult) -> None:
        self.current_state = result.primary_state
        self.current_confidence = result.confidence
        self._age = 0
        self.state_history.append({
            "state": result.primary_state,
            "confidence": result.confidence,
            "uncertain": result.uncertain,
            "at": datetime.now().isoformat(timespec="seconds"),
        })
        self.state_history = self.state_history[-self.max_history:]

    def tick(self) -> None:
        """در هر نوبتی که ``update`` صدا زده نشود، این را صدا بزن تا TTL بگذرد."""
        self._age += 1
        if self._age > self.ttl_turns:
            self.current_state = None
            self.current_confidence = 0.0

    def get(self) -> tuple[Optional[str], float]:
        return self.current_state, self.current_confidence

    def recent_failures(self, within: int = 5) -> int:
        """تعدادِ حالت‌هایِ منفیِ اخیر -- برایِ conversation_phase (repeated_failure)."""
        negative = {"frustrated", "sad", "angry", "stressed", "dissatisfied"}
        return sum(1 for h in self.state_history[-within:] if h.get("state") in negative)
