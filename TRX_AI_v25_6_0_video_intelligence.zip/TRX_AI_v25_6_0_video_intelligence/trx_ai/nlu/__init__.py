# -*- coding: utf-8 -*-
"""
trx_ai.nlu -- موتورِ ماژولارِ تشخیصِ نیت.

رابطِ عمومیِ این پکیج عمداً کوچک است:

    from trx_ai.nlu import detect
    result = detect("هوای تهران چطوره؟")
    result.intent, result.confidence

هرچیزِ دیگر (registry، matchers، intents/) پیاده‌سازیِ داخلی است.
``trx_ai.intelligence.IntentEngine``/``ToolScorer`` یک لایه‌ی نازکِ
سازگاری رویِ همین پکیج هستند تا هیچ فایلِ دیگری در پروژه نیاز به تغییر
نداشته باشد.
"""

from __future__ import annotations

from .scorer import detect, score_tools
from .types import IntentResult, IntentSpec, MatchHit

__all__ = ["detect", "score_tools", "IntentResult", "IntentSpec", "MatchHit"]
