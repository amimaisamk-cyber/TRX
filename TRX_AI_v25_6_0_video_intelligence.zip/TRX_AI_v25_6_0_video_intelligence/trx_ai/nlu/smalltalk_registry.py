# -*- coding: utf-8 -*-
"""
smalltalk_registry.py -- توصیفِ دسته‌هایِ گفتگویِ روزمره (سلام/احوال‌پرسی/
تشکر/خداحافظی/...) برایِ ``SmallTalkEngine`` در ``intelligence.py``.

چرا این فایل اضافه شد:
    قبلاً ``SmallTalkEngine._CATEGORIES`` یک لیستِ ثابتِ regex بود --
    یعنی هر بار که کاربر یک عبارتِ محاوره‌ایِ تازه به کار می‌برد (مثلاً
    «حالت خوبه» به‌جایِ «حالت چطوره») باید دستی به regex اضافه می‌شد.
    این دقیقاً همان مشکلی‌ست که کاربر صراحتاً درباره‌اش نوشت: «خودِ
    سیستم باید الگو بسازه، نه من از چت کلمه‌به‌کلمه اضافه کنم».

    راه‌حل: به‌جایِ یک regex ثابت، از همان معماریِ چندلایه‌ای که برایِ
    ``nlu/user_state.py`` ساخته شده استفاده می‌کنیم (کلیدواژه → مترادف
    → regex → فازی [تحمل‌پذیرِ غلطِ املایی/پسوند] → معنایی [embedding
    محلی، فقط اگر ``sentence-transformers`` نصب باشد]). نتیجه: عبارات
    محاوره‌ایِ نزدیک به کلیدواژه‌ها یا مترادف‌ها (نه فقط عینِ آن‌ها)
    خودکار تشخیص داده می‌شوند -- بدونِ نیاز به افزودنِ دستیِ هر تکرار.

    نکته‌ی مهم و صادقانه: لایه‌ی «فازی» فقط غلطِ تایپی/پسوندِ محاوره‌ای
    (فاصله‌ی ویرایشیِ کم) را نجات می‌دهد -- یک جمله‌بندیِ کاملاً متفاوت
    را نمی‌فهمد. تعمیمِ واقعی به جمله‌بندی‌هایِ کاملاً جدید (بدونِ هیچ
    کلمه‌ی مشترک) فقط با لایه‌ی معنایی ممکن است، و آن لایه فقط وقتی
    واقعاً فعال می‌شود که ``sentence-transformers`` نصب شده باشد (پیش‌فرض
    نصب نیست -- رجوع به ``requirements.txt``).
"""

from __future__ import annotations

from .user_state_types import UserStateSpec

SMALLTALK_SPECS: dict[str, UserStateSpec] = {
    "greeting": UserStateSpec(
        name="greeting",
        description="سلام/احوال‌پرسیِ آغازین",
        regex=(r"^(سلام|درود|های|هلو|سلام\s*علیک)\b",),
        positive_examples=("سلام", "درود بر شما", "سلام چطوری", "های چه خبر", "سلام علیک"),
        weight=1.0,
        fuzzy_enabled=False,
        semantic_enabled=True,
    ),
    "wellbeing": UserStateSpec(
        name="wellbeing",
        description="پرسیدنِ حالِ دستیار",
        keywords=("خوبی", "چطوری", "چه خبر"),
        synonyms=(
            "حالت چطوره", "حالت خوبه", "اوضاع چطوره", "اوضاعت چطوره",
            "اوضاع خوبه", "اوضاعت خوبه", "حالت چیه", "اوضاعت چیه",
            "چه خبرا", "خبری هست",
        ),
        positive_examples=(
            "حالت خوبه؟", "اوضاع چطوره؟", "چطوری؟", "حالت چطوره؟",
            "خوبی؟", "چه خبرا", "اوضاعت چیه", "حالت چیه",
        ),
        weight=1.0,
        fuzzy_enabled=False,
        semantic_enabled=True,
    ),
    "thanks": UserStateSpec(
        name="thanks",
        description="تشکر/قدردانی از دستیار",
        keywords=("ممنون", "متشکرم", "مرسی", "تشکر", "سپاسگزارم"),
        synonyms=("دستت درد نکنه", "لطف کردی", "خیلی ممنون"),
        positive_examples=("ممنونم", "خیلی ممنون بابتش", "دستت درد نکنه", "مرسی ازت", "لطف کردی"),
        weight=1.0,
        fuzzy_enabled=True,
        semantic_enabled=True,
    ),
    "farewell": UserStateSpec(
        name="farewell",
        description="خداحافظی",
        keywords=("خداحافظ", "خدانگهدار", "بای", "فعلا"),
        synonyms=("می‌رم دیگه", "میرم دیگه", "شب بخیر"),
        positive_examples=("خداحافظ", "فعلاً می‌رم", "شب بخیر", "بای بای"),
        weight=1.0,
        fuzzy_enabled=True,
        semantic_enabled=True,
    ),
    "compliment": UserStateSpec(
        name="compliment",
        description="تعریف/تمجید از دستیار",
        synonyms=("باحالی", "باهوشی", "خفنی", "عالی هستی", "دمت گرم", "فوق‌العاده‌ای", "محشری", "نابغه‌ای"),
        positive_examples=("خیلی باحالی", "چقدر باهوشی", "دمت گرم واقعاً", "محشری تو"),
        weight=1.0,
        fuzzy_enabled=False,
        semantic_enabled=True,
    ),
    "insult": UserStateSpec(
        name="insult",
        description="گلایه/توهین به دستیار",
        synonyms=("احمقی", "خنگی", "بی‌فایده‌ای", "بدردنخوری", "افتضاحی"),
        positive_examples=("اصلاً به‌دردبخور نیستی", "جوابت اشتباه بود، خنگی"),
        weight=1.0,
        fuzzy_enabled=False,
        semantic_enabled=True,
    ),
    "identity": UserStateSpec(
        name="identity",
        description="پرسیدنِ هویتِ دستیار",
        regex=(r"(تو\s*کی\s*هستی|اسمت\s*چیه|خودتو\s*معرفی\s*کن|چه\s*کسی\s*(هستی|ساختت)|کی\s*ساختت)",),
        positive_examples=("تو کی هستی؟", "اسمت چیه؟", "خودتو معرفی کن", "کی ساختتت؟"),
        weight=1.0,
        fuzzy_enabled=False,
        semantic_enabled=True,
    ),
    "capability": UserStateSpec(
        name="capability",
        description="پرسیدنِ توانایی‌هایِ دستیار",
        # v25.5.9: الگویِ قدیمی («چه کارهایی بلدی») فقط شکلِ جمع را می‌گرفت
        # و با هیچ کلمه‌ی میانی (مثلاً یک صفت مثلِ «خاصی») سازگار نبود --
        # نتیجه: عبارتِ کاملاً طبیعیِ «چه کار خاصی بلدی» (دقیقاً یکی از
        # پیام‌هایِ واقعیِ گزارش‌شده که به boilerplateِ عمومی سقوط کرد) اصلاً
        # تشخیص داده نمی‌شد. الگویِ جدید تا ۲ کلمه‌ی میانی (هر صفت/قیدی)
        # بینِ «چه کار» و «بلدی» را می‌پذیرد -- نگاه کنید به
        # audit/SMALLTALK_CAPABILITY_MISS_v25_5_9.md.
        regex=(
            r"(چی\s*کار\s*می\s*کنی|چی\s*کار\s*بلدی|"
            r"چه\s*کار(?:ی|ها|هایی)?(?:\s+\S+){0,2}?\s*بلدی|"
            r"چه\s*کمکی\s*می\s*تونی|چه\s*قابلیت\s*هایی\s*داری)",
        ),
        positive_examples=(
            "چیکار می‌کنی؟", "چه کارهایی بلدی؟", "چه کمکی می‌تونی بکنی؟",
            "چه کار خاصی بلدی؟", "چه کاری بلدی؟",
        ),
        weight=1.0,
        fuzzy_enabled=False,
        semantic_enabled=True,
    ),
    "courtesy_appreciation": UserStateSpec(
        name="courtesy_appreciation",
        description=(
            "تعارفِ اجتماعیِ قدردانی از زحمت -- «خسته نباشید» و مشابه. طبقِ "
            "سندِ AMS (بخشِ ۴۳ -- Failure Trace «خسته نباشید»): این یک "
            "Social Conversation Act است، نه سؤالِ دانشی/ناقص که باید به "
            "ویکی‌پدیا/DuckDuckGo یا پاسخِ عمومیِ ژنریک سپرده شود."
        ),
        keywords=("خسته نباشید", "خسته نباشی"),
        synonyms=("دست شما درد نکنه", "دستت درد نکنه", "قربونت", "زحمت کشیدی", "زحمت کشیدید"),
        positive_examples=("خسته نباشید", "خسته نباشی رفیق", "دستت درد نکنه بابت زحمتت"),
        weight=1.0,
        fuzzy_enabled=True,
        semantic_enabled=True,
    ),
    "boredom": UserStateSpec(
        name="boredom",
        description="اعلامِ بی‌حوصلگی/کسالت (نه غم/دردِ دل -- آن از قبل توسطِ emotional_support_mode جدا فیلتر می‌شود)",
        keywords=("کسل",),
        synonyms=("حوصلم سررفته", "بی‌حوصله‌ام", "بی حوصله‌ام", "کسل‌ام"),
        positive_examples=("حوصله‌ام سر رفته", "کسل‌ام امروز", "بی‌حوصله‌ام"),
        weight=1.0,
        fuzzy_enabled=True,
        semantic_enabled=True,
    ),
}
