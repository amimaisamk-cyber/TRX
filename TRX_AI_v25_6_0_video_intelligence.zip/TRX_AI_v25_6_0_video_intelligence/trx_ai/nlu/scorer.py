# -*- coding: utf-8 -*-
"""
موتورِ اصلیِ ترکیبِ امتیازها -- جایگزینِ منطقِ درونیِ
``IntentEngine.detect_intent`` و ``ToolScorer.score_tools`` قدیمی.

طراحیِ ایمن برایِ عدمِ رگرسیون: مسیرِ «کلیدواژه‌یِ اصلی + regex» دقیقاً
همان الگوریتمِ قبلی است (همان امتیازها، همان فرمولِ اطمینان). لایه‌هایِ
جدید (مترادف، فازی، بازخورد) فقط *افزوده* می‌شوند:

- مترادف‌ها هرگز به فراخوانیِ نیتیو داده نمی‌شوند (که فقط کلیدواژه‌هایِ
  اصلی را می‌بیند)، همیشه در پایتون و با ضریبِ کمتر جداگانه جمع
  می‌شوند -- یعنی مسیرِ نیتیو دقیقاً همان ورودیِ قبلی را می‌بیند.
- فازی فقط برایِ نیت‌هایی اجرا می‌شود که امتیازشان بعدِ کلیدواژه/مترادف/
  regex هنوز صفر است -- پس هیچ‌وقت نمی‌تواند یک برنده‌یِ واقعی را عوض
  کند، فقط نیت‌هایی را که وگرنه به "general" سقوط می‌کردند نجات می‌دهد.
- بازخورد هم به همین ترتیب فقط یک امتیازِ اضافه می‌دهد، رتبه‌بندیِ
  نهایی هنوز با همان فرمولِ margin/absolute محاسبه می‌شود.
"""

from __future__ import annotations

import re

from . import feedback as feedback_mod
from . import registry
from .matchers.fuzzy import fuzzy_score
from .matchers.keyword import keyword_hit_score
from .matchers.regex import regex_score
from .matchers.semantic import semantic_score
from .matchers.synonym import synonym_score
from .normalizer import normalize
from .types import IntentResult, MatchHit

try:
    from .. import _intent_native as _native  # type: ignore
except ImportError:  # pragma: no cover
    _native = None


def _keyword_match_spans(norm: str, keyword: str) -> list[tuple[int, int, bool]]:
    """
    مکانِ دقیقِ (start, end, negated) هر matchِ یک کلیدواژه در متن.

    برخلافِ ``keyword_hit_score`` که فقط جمعِ امتیاز را برمی‌گرداند، این
    تابع مکانِ matchها را هم می‌دهد -- پیش‌نیازِ ``_suppress_overlapping``
    (نگاه کنید به توضیحِ آنجا). عمداً همیشه پایتونِ خالص است (نه نیتیو):
    این یک قابلیتِ جدید و ارزانِ محاسباتی است (دیتاست‌ها کوچک‌اند)، نه
    یک مسیرِ داغِ عملکردی که نیاز به بهینه‌سازیِ C++ داشته باشد.
    """
    kw = keyword.replace("\u200c", " ").strip().lower()
    if not kw:
        return []
    ends_with_word_char = bool(re.match(r".*[\w\u0600-\u06FF]$", kw))
    lead = r"(?<!\S)"
    trail = r"(?!\S)" if ends_with_word_char else ""
    spans = []
    for m in re.finditer(lead + re.escape(kw) + trail, norm):
        window = norm[max(0, m.start() - 12) : m.start()]
        negated = any(neg in window for neg in ("ندارم", "نیست", "نبود", "نداشتم", "نه "))
        spans.append((m.start(), m.end(), negated))
    return spans


def _statistical_scores(norm: str) -> dict[str, float]:
    """کلیدواژه (با سرکوبِ overlapِ کوتاه‌تر) + مترادف + regex + فازی."""
    specs = registry.STATISTICAL_INTENTS

    # --- گامِ ۱: همه‌ی matchهایِ کلیدواژه‌ایِ همه‌ی نیت‌ها را با مکانشان
    # جمع می‌کنیم؛ هنوز جمع نمی‌زنیم.
    # ساختار: هر آیتم = (intent_name, weight, start, end, negated, keyword_text)
    all_matches: list[tuple[str, float, int, int, bool, str]] = []
    for name, spec in specs.items():
        for kw in spec.keywords:
            for start, end, negated in _keyword_match_spans(norm, kw):
                all_matches.append((name, spec.weight, start, end, negated, kw))

    # --- گامِ ۲: سرکوبِ matchهایِ کوتاه‌تری که کاملاً داخلِ یک matchِ
    # *بلندترِ* دیگر (از هر نیتی، حتی همان نیت) قرار دارند.
    #
    # باگِ واقعی که این حل می‌کند: کلیدواژه‌یِ تک‌کلمه‌ایِ «درد» (نیتِ
    # medical) داخلِ کلیدواژه‌یِ سه‌کلمه‌ایِ «درد دل کنم» (نیتِ
    # emotional_support) به‌طورِ کامل جا می‌گیرد. قبلاً هر دو مستقل
    # امتیاز می‌گرفتند و فقط تفاوتِ جزئیِ وزنِ نیت (۱۰ در برابرِ ۹) تصمیم
    # می‌گرفت -- یعنی جمله‌یِ «می‌خوام یکم درد دل کنم» اشتباه به medical
    # می‌رفت. با «طولانی‌ترین matchِ هم‌پوشان برنده است» (اصلِ
    # maximal-munch، رایج در تطبیقِ الگو)، «درد» چون زیرمجموعه‌یِ کاملِ
    # یک matchِ بلندتر است، سرکوب می‌شود و «درد دل کنم» تنها امتیازِ آن
    # بازه را می‌گیرد.
    #
    # عمداً *سراسری* است (نه یک استثنایِ دستی فقط برایِ این دو نیت):
    # هر جفت کلیدواژه از هر دو نیتی که این رابطه را داشته باشند همینطور
    # رفتار می‌کنند. تفاوتِ مهم با یک «ضریبِ طولِ عبارت» ساده (که قبلاً
    # امتحان و رد شد): اینجا فقط وقتی دو match واقعاً هم‌پوشانی دارند
    # سرکوب رخ می‌دهد -- یک کلیدواژه‌یِ دوکلمه‌ای در جایی کاملاً جدا از
    # متن (مثلاً «پیدا کن» در «خطای این کد رو پیدا کن») هیچ‌وقت کلیدواژه‌یِ
    # بی‌ربطِ دیگری (مثلاً «کد») را سرکوب نمی‌کند، چون اصلاً هم‌پوشان
    # نیستند.
    kept: list[tuple[str, float, bool, str]] = []
    for i, (name, weight, start, end, negated, kw) in enumerate(all_matches):
        length = end - start
        suppressed = False
        for j, (name2, _w2, start2, end2, _neg2, _kw2) in enumerate(all_matches):
            if i == j:
                continue
            if start2 <= start and end2 >= end and (end2 - start2) > length:
                suppressed = True
                break
        if not suppressed:
            kept.append((name, weight, negated, kw))

    scores: dict[str, float] = {}
    for name, weight, negated, kw in kept:
        scores[name] = scores.get(name, 0.0) + (0.4 if negated else 1.0) * weight

    # regex -- همیشه پایتونیِ خالص (تعدادشان کم است، طبقِ یادداشتِ روادمپ)
    regex_scored: set[str] = set()
    for name, spec in specs.items():
        rscore = regex_score(norm, spec.regex, spec.weight)
        if rscore:
            scores[name] = scores.get(name, 0.0) + rscore
            regex_scored.add(name)

    # مترادف -- همیشه پایتونیِ خالص و جدا از مسیرِ نیتیو (گامِ ۶ روادمپ)
    for name, spec in specs.items():
        if not spec.synonyms:
            continue
        sscore = synonym_score(norm, spec.synonyms, spec.weight)
        if sscore:
            scores[name] = scores.get(name, 0.0) + sscore

    # regexِ نجات‌دهنده (fallback_regex) -- الگوهایِ خیلی عمومی (مثلِ «X
    # چیست/چیه») که با هر موضوعی تطبیق پیدا می‌کنند. برخلافِ regexِ
    # معمولیِ بالا، این‌ها فقط وقتی اضافه می‌شوند که در کلِ جمله هیچ
    # *سرنخِ خاصِ* دیگری وجود نداشته باشد -- دقیقاً همان گیتِ فازی/معنایی
    # زیر، با این تفاوت که سراسری است (رویِ کلِ جمله)، چون این الگوها
    # آن‌قدر عمومی‌اند که باید به‌جایِ «برنده شدن دربرابرِ نیتِ دیگر» فقط
    # «جمله‌ای که وگرنه به general سقوط می‌کرد را نجات بدهند» (رجوع به
    # توضیحِ IntentSpec.fallback_regex).
    #
    # «سرنخِ خاص» یعنی: یک matchِ کلیدواژه‌ایِ *چندکلمه‌ای* (مثلاً
    # «مراحل انجام»)، یا یک matchِ regexِ صریح (مثلاً ``def\s+\w+``).
    # یک کلیدواژه‌یِ *تک‌کلمه‌ایِ* عمومی (مثلاً «پایتون» در code_analyzer)
    # به‌تنهایی سرنخِ خاص حساب نمی‌شود -- وگرنه «پایتون چیست؟» (که باید
    # web_search باشد، نه code_analyzer؛ رجوع به negative_examples خودِ
    # code_analyzer) به‌اشتباه سرکوب می‌شد. این دقیقاً همان معیارِ
    # «طولانی‌تر=خاص‌تر» است که سرکوبِ هم‌پوشانیِ بالا هم استفاده می‌کند،
    # فقط این‌بار بدونِ نیاز به هم‌پوشانیِ مکانی.
    specific_keyword_intents = {name for name, _w, _neg, kw in kept if len(kw.split()) >= 2}
    if not (specific_keyword_intents or regex_scored):
        for name, spec in specs.items():
            if not spec.fallback_regex:
                continue
            fscore = regex_score(norm, spec.fallback_regex, spec.weight)
            if fscore:
                scores[name] = scores.get(name, 0.0) + fscore

    # فازی -- فقط برایِ نیت‌هایِ هنوز-صفر و فقط برایِ نیت‌هایی که صریحاً
    # fuzzy_enabled=True دارند (گامِ ۴/۵ روادمپ: ریشه‌یابیِ پسوند + تحملِ
    # غلطِ املایی؛ گیت‌شده برایِ جلوگیری از قاطیِ کلماتِ رایج مثلِ
    # «سلام»/«سلامت» -- رجوع به توضیحِ IntentSpec.fuzzy_enabled).
    for name, spec in specs.items():
        if not spec.fuzzy_enabled:
            continue
        if scores.get(name, 0.0) > 0:
            continue
        fscore = fuzzy_score(norm, spec.keywords, spec.weight)
        if fscore:
            scores[name] = fscore

    # معنایی (embedding) -- فقط برایِ نیت‌هایی که هنوز صفرند و صریحاً
    # semantic_enabled=True دارند (گامِ جدید، همان گیتِ محافظه‌کارانه‌ی
    # فازی: هرگز یک برنده‌ی کلیدواژه/regex را عوض نمی‌کند، فقط جمله‌های
    # هم‌معنی-بدونِ‌کلیدواژه‌ی‌مشترک را نجات می‌دهد). اگر
    # sentence-transformers نصب نباشد، semantic_score همیشه ۰ برمی‌گرداند
    # و این حلقه هیچ اثری ندارد.
    for name, spec in specs.items():
        if not spec.semantic_enabled:
            continue
        if scores.get(name, 0.0) > 0:
            continue
        sscore = semantic_score(norm, spec, spec.weight)
        if sscore:
            scores[name] = sscore

    return scores


def detect(text: str, context=None, db=None) -> IntentResult:
    """
    تشخیصِ نیت با امتیازدهیِ چندگانه. ``context`` نگه داشته شده برایِ
    سازگاریِ امضا (در نسخه‌ی فعلی مثلِ قبل استفاده نمی‌شود)؛ ``db`` اگر
    داده شود، برایِ تقویتِ امتیاز از رویِ تصحیح‌هایِ قبلیِ کاربر استفاده
    می‌شود (feedback.py، گامِ ۵ روادمپ).
    """
    raw = text
    norm = normalize(text)

    # ۱) دستوراتِ ساختاریِ قطعی (لنگرشده)
    for intent_name, pattern in registry.STRUCTURAL:
        if pattern.search(norm):
            return IntentResult(intent=intent_name, confidence=0.98, raw_text=raw)

    # ۲) امتیازدهیِ آماری
    scores = _statistical_scores(norm)

    # ۳) تقویتِ بازخورد (اگر db داده شده و تصحیحِ مشابهی ثبت شده باشد)
    # ``hits`` اینجا جمع‌آوری می‌شود (رفعِ باگِ ۲۰۲۶-۰۹-۲۰ -- نگاه کنید
    # به ``BUGFIX_v25_5_2_FEEDBACK_FUZZY_CAP.md``) تا اگر یک نیت واقعاً
    # به‌خاطرِ تصحیحِ صریحِ کاربر برنده شد، این حقیقت در خروجی قابلِ
    # مشاهده باشد -- نه فقط یک عددِ امتیازِ بی‌نام‌ونشان که از دیدِ
    # مصرف‌کننده‌یِ پایین‌دست با یک تطبیقِ فازیِ تصادفی یکسان به‌نظر برسد.
    hits: list[MatchHit] = []
    if db is not None:
        scores = feedback_mod.boost_from_feedback(norm, scores, db, hits=hits)

    if not scores:
        return IntentResult(intent="general", confidence=0.4, raw_text=raw, scores=scores, hits=hits)

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    best_intent, best_score = ranked[0]
    second_score = ranked[1][1] if len(ranked) > 1 else 0.0

    margin = (best_score - second_score) / best_score if best_score > 0 else 0
    absolute = min(best_score / 20.0, 1.0)
    confidence = round(max(0.35, min(0.99, 0.5 * margin + 0.5 * absolute + 0.15)), 2)

    return IntentResult(intent=best_intent, confidence=confidence, raw_text=raw, scores=scores, hits=hits)


def score_tools(text: str, intent: str, confidence: float, context=None):
    """
    امتیازدهیِ ابزار -- دقیقاً همان الگوریتمِ قدیمیِ ``ToolScorer.score_tools``،
    فقط با کلیدواژه‌ها/وزن‌ها از ``registry`` به‌جایِ دو دیکشنریِ جدا.

    Returns: (tool_name, scores_dict, tool_confidence)
    """
    scores: dict[str, float] = {}
    norm = normalize(text)

    for tool_name, tool_config in registry.TOOLS.items():
        base_score = 0.0

        if registry.INTENT_TO_TOOL.get(intent) == tool_name:
            base_score += 100 * confidence

        src_intent = registry.KEYWORD_SOURCE.get(tool_name)
        if src_intent and src_intent in registry.PATTERNS:
            for kw in registry.PATTERNS[src_intent].keywords:
                base_score += keyword_hit_score(norm, kw) * tool_config["weight"]
        elif tool_name == "file_reader":
            for kw in registry.FILE_READER_FALLBACK_KEYWORDS:
                base_score += keyword_hit_score(norm, kw) * tool_config["weight"]

        if context and tool_name in context and base_score > 0:
            base_score += min(context[tool_name], 5) * 2

        scores[tool_name] = base_score

    max_score = max(scores.values()) if scores else 0
    if max_score <= 0:
        return "general", scores, 0.3

    tied = [t for t, s in scores.items() if s == max_score]
    if len(tied) > 1:
        best_tool = next((t for t in registry.TOOL_PRIORITY if t in tied), tied[0])
    else:
        best_tool = tied[0]

    total_score = sum(scores.values()) or 1
    tool_confidence = min(max_score / total_score, 1.0)

    return best_tool, scores, tool_confidence
