# -*- coding: utf-8 -*-
"""
دارایی‌هایِ رابطِ کاربریِ وب (HTML/CSS/JS) — تک‌فایلی و embedded.

چرا embedded (نه فایل‌هایِ استاتیکِ جدا):
    این پروژه قبلاً چند بار به این مشکل خورده که مسیرِ اجرا/پوشه‌ی
    کاری در محیط‌هایِ مختلف (Pydroid3، Termux، دسکتاپ) قابلِ‌پیش‌بینی
    نیست (نگاه کنید به `main.py._ensure_project_root_on_path`). به‌جایِ
    اضافه‌کردنِ یک دسته‌بندیِ مسیرِ استاتیکِ دیگر که ممکن است در یکی از
    این محیط‌ها پیدا نشود، کلِ صفحه یک رشته‌ی پایتونی است که مستقیماً
    aiohttp برمی‌گرداند — هیچ فایلِ جانبی، هیچ مسیرِ نسبیِ شکننده‌ای.

چرا اصلاً یک رابطِ وب (به‌جایِ/در‌کنارِ PySide6):
    PySide6 یک وابستگیِ کامپایل‌شده‌ی سنگین است که رویِ خیلی از محیط‌های
    اندروید/Pydroid3 اصلاً قابلِ‌نصب نیست. یک رابطِ HTML که با aiohttp
    (که همین الان CORE پروژه است) سرو می‌شود، در مرورگرِ خودِ گوشی باز
    می‌شود — بدونِ هیچ وابستگیِ گرافیکیِ جدید، رویِ هر پلتفرمی که پایتون
    و یک مرورگر دارد (یعنی عملاً همه‌جا).
"""

from __future__ import annotations

INDEX_HTML = r"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
<title>TRX AI — دستیار هوشمند فارسی</title>
<style>
:root {
    --bg: #0f0d0b;
    --bg-elevated: #1a1613;
    --card: #211c18;
    --card-hover: #2a231e;
    --border: #352d26;
    --text: #f2ece4;
    --text-muted: #a89b8d;
    --primary: #cc785c;
    --primary-dark: #b5654a;
    --primary-light: #3a2620;
    --primary-glow: rgba(204, 120, 92, 0.35);
    --danger: #e5605a;
    --success: #6fcf97;
    --warning: #f0ad4e;
    --radius-lg: 20px;
    --radius-md: 14px;
    --radius-sm: 10px;
    --shadow: 0 8px 30px rgba(0,0,0,0.35);
    color-scheme: dark;
}
:root.light {
    --bg: #f7f2ec;
    --bg-elevated: #ffffff;
    --card: #ffffff;
    --card-hover: #fbf6f0;
    --border: #e7dcd0;
    --text: #2b2118;
    --text-muted: #8a7c6d;
    --primary: #cc785c;
    --primary-dark: #b5654a;
    --primary-light: #f3e0d5;
    --primary-glow: rgba(204, 120, 92, 0.22);
    --shadow: 0 8px 30px rgba(60,40,20,0.10);
    color-scheme: light;
}
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
html, body {
    height: 100%;
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: "Vazirmatn", "Noto Naskh Arabic", "Segoe UI", Tahoma, sans-serif;
    overflow: hidden;
}
body {
    display: flex;
    flex-direction: column;
    height: 100dvh;
}

/* ===================== هدر ===================== */
#header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 18px;
    background: linear-gradient(120deg, var(--primary-dark), var(--primary));
    box-shadow: var(--shadow);
    z-index: 10;
    flex-shrink: 0;
}
#header .brand { display: flex; flex-direction: column; gap: 2px; }
#header .brand .name { font-size: 17px; font-weight: 800; color: #fff; display:flex; align-items:center; gap:6px;}
#header .brand .sub { font-size: 11.5px; color: rgba(255,255,255,.85); }
#header .actions { display: flex; align-items: center; gap: 8px; }
.icon-btn {
    background: rgba(255,255,255,0.14);
    border: none;
    color: #fff;
    width: 34px; height: 34px;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    font-size: 16px;
    transition: background .15s, transform .1s;
}
.icon-btn:hover { background: rgba(255,255,255,0.26); }
.icon-btn:active { transform: scale(0.92); }
#connDot {
    width: 9px; height: 9px; border-radius: 50%;
    background: var(--warning);
    box-shadow: 0 0 0 3px rgba(255,255,255,0.15);
    transition: background .3s;
}
#connDot.ok { background: var(--success); }
#connDot.bad { background: var(--danger); }

/* ===================== تاریخچه‌ی گفتگو ===================== */
#chat {
    flex: 1;
    overflow-y: auto;
    padding: 18px 14px 8px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    scroll-behavior: smooth;
}
#chat::-webkit-scrollbar { width: 7px; }
#chat::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

.row { display: flex; width: 100%; animation: fadeUp .28s ease; }
.row.user { justify-content: flex-start; }
.row.bot  { justify-content: flex-end; }
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(6px); }
    to   { opacity: 1; transform: translateY(0); }
}

.bubble {
    max-width: 82%;
    padding: 11px 15px;
    border-radius: var(--radius-md);
    font-size: 14.5px;
    line-height: 1.65;
    white-space: pre-wrap;
    word-wrap: break-word;
    box-shadow: 0 2px 10px rgba(0,0,0,0.12);
    position: relative;
}
.bubble .label { font-size: 11px; font-weight: 700; margin-bottom: 4px; opacity: .85; display:block; }
.bubble .time { font-size: 10px; opacity: .55; margin-top: 5px; display:block; }

.row.user .bubble {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: #fff;
    border-bottom-left-radius: 4px;
}
.row.bot .bubble {
    background: var(--card);
    border: 1px solid var(--border);
    color: var(--text);
    border-bottom-right-radius: 4px;
}
.row.bot .bubble.emergency { background: #3a1414; border-color: var(--danger); color: #ffd9d6; }
:root.light .row.bot .bubble.emergency { background: #fdecea; color: var(--danger); }
.row.bot .bubble.followup { background: var(--primary-light); border-color: var(--primary); }
.row.bot .bubble.system { background: transparent; border: none; box-shadow: none; color: var(--text-muted); font-size: 12px; padding: 2px 6px; }

.cursor-blink::after {
    content: "▍";
    display: inline-block;
    margin-inline-start: 2px;
    animation: blink 1s step-start infinite;
    color: var(--primary);
}
@keyframes blink { 50% { opacity: 0; } }

.typing-dots { display: inline-flex; gap: 4px; align-items: center; padding: 3px 2px; }
.typing-dots span {
    width: 6px; height: 6px; border-radius: 50%;
    background: var(--primary);
    animation: bounce 1.2s infinite ease-in-out;
}
.typing-dots span:nth-child(2) { animation-delay: .15s; }
.typing-dots span:nth-child(3) { animation-delay: .3s; }
@keyframes bounce { 0%, 60%, 100% { transform: translateY(0); opacity:.5 } 30% { transform: translateY(-5px); opacity:1 } }

.guide-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
.guide-table td { padding: 6px 8px; border-bottom: 1px solid var(--border); vertical-align: top; }
.guide-table td:first-child { color: var(--primary); font-weight: 700; white-space: nowrap; }

/* ===================== نوارِ میانبرها ===================== */
#chips {
    display: flex;
    gap: 8px;
    padding: 8px 14px;
    overflow-x: auto;
    flex-shrink: 0;
    scrollbar-width: none;
}
#chips::-webkit-scrollbar { display: none; }
.chip {
    flex-shrink: 0;
    background: var(--card);
    border: 1px solid var(--border);
    color: var(--text);
    padding: 7px 14px;
    border-radius: 16px;
    font-size: 12.5px;
    cursor: pointer;
    white-space: nowrap;
    transition: all .15s;
}
.chip:hover { background: var(--primary-light); border-color: var(--primary); }
.chip:active { transform: scale(0.95); }

/* ===================== نوارِ ورودی ===================== */
#inputBar {
    display: flex;
    align-items: flex-end;
    gap: 8px;
    padding: 10px 14px calc(10px + env(safe-area-inset-bottom));
    background: var(--bg-elevated);
    border-top: 1px solid var(--border);
    flex-shrink: 0;
}
#textInput {
    flex: 1;
    resize: none;
    border: 1px solid var(--border);
    background: var(--card);
    color: var(--text);
    border-radius: 20px;
    padding: 11px 16px;
    font-size: 14.5px;
    font-family: inherit;
    max-height: 120px;
    line-height: 1.4;
    outline: none;
    transition: border-color .15s, box-shadow .15s;
}
#textInput:focus { border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-glow); }
#sendBtn {
    background: var(--primary);
    color: #fff;
    border: none;
    width: 44px; height: 44px;
    border-radius: 50%;
    font-size: 18px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    flex-shrink: 0;
    transition: background .15s, transform .1s;
}
#sendBtn:hover { background: var(--primary-dark); }
#sendBtn:active { transform: scale(0.9); }
#sendBtn:disabled { background: var(--border); cursor: not-allowed; }
#attachBtn {
    background: transparent;
    color: var(--primary);
    border: 1.5px solid var(--border);
    width: 44px; height: 44px;
    border-radius: 50%;
    font-size: 18px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    flex-shrink: 0;
    transition: border-color .15s, transform .1s;
}
#attachBtn:hover { border-color: var(--primary); }
#attachBtn:active { transform: scale(0.9); }
#attachBtn:disabled { opacity: .5; cursor: not-allowed; }
.bubble img.chat-image {
    display: block;
    max-width: 260px;
    max-height: 260px;
    border-radius: 12px;
    margin: 6px 0;
    cursor: zoom-in;
}
.image-caption { font-size: 13px; opacity: .85; margin-top: 4px; }
.file-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    border-radius: 10px;
    background: var(--bubble-bot, rgba(127,127,127,.12));
    font-size: 13.5px;
}
#imagePreviewBar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: var(--bubble-bot, rgba(127,127,127,.08));
    border-top: 1px solid var(--border);
}
#imagePreviewBar img {
    width: 44px; height: 44px;
    object-fit: cover;
    border-radius: 8px;
}
#imagePreviewBar .name {
    flex: 1;
    font-size: 12.5px;
    opacity: .8;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
#imagePreviewBar button {
    background: transparent;
    border: none;
    color: var(--primary);
    font-size: 16px;
    cursor: pointer;
    padding: 4px 8px;
}
#attachFileBtn {
    background: transparent;
    color: var(--primary);
    border: 1.5px solid var(--border);
    width: 44px; height: 44px;
    border-radius: 50%;
    font-size: 16px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    flex-shrink: 0;
    transition: border-color .15s, transform .1s;
}
#attachFileBtn:hover { border-color: var(--primary); }
#attachFileBtn:active { transform: scale(0.9); }
#attachFileBtn:disabled { opacity: .5; cursor: not-allowed; }
#filePreviewBar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: var(--bubble-bot, rgba(127,127,127,.08));
    border-top: 1px solid var(--border);
}
#filePreviewBar .file-icon { font-size: 24px; flex-shrink: 0; }
#filePreviewBar .name {
    flex: 1;
    font-size: 12.5px;
    opacity: .8;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
#filePreviewBar button {
    background: transparent;
    border: none;
    color: var(--primary);
    font-size: 16px;
    cursor: pointer;
    padding: 4px 8px;
}
/* پخشِ متن در همان صفحه — شیشه‌ای و سبک، بدون ساخت فایل صوتی */
.speak-btn {
    margin-top: 10px;
    padding: 7px 12px;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,.22);
    background: rgba(255,255,255,.10);
    color: var(--text-muted);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.12), 0 4px 14px rgba(0,0,0,.08);
    font-size: 12px;
    cursor: pointer;
    transition: all .18s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.speak-btn:hover {
    transform: translateY(-1px);
    background: rgba(255,255,255,.17);
    color: var(--text);
}
.speak-btn:active { transform: scale(.97); }
.speak-btn.speaking {
    background: rgba(99,102,241,.22);
    border-color: rgba(99,102,241,.45);
    color: var(--text);
}
.speak-btn:disabled { opacity: .55; cursor: not-allowed; transform: none; }

/* ===================== مودال خوش‌آمد ===================== */
#welcomeOverlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.55);
    display: flex; align-items: center; justify-content: center;
    z-index: 100;
    backdrop-filter: blur(4px);
}
#welcomeCard {
    background: var(--bg-elevated);
    border-radius: var(--radius-lg);
    padding: 28px 24px;
    width: min(360px, 88vw);
    box-shadow: var(--shadow);
    text-align: center;
}
#welcomeCard h2 { margin: 0 0 6px; font-size: 20px; }
#welcomeCard p { margin: 0 0 18px; color: var(--text-muted); font-size: 13px; }
#nameInput {
    width: 100%;
    padding: 11px 14px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    background: var(--card);
    color: var(--text);
    font-size: 14px;
    margin-bottom: 14px;
    outline: none;
    text-align: center;
}
#nameInput:focus { border-color: var(--primary); }
#startBtn {
    width: 100%;
    padding: 12px;
    border-radius: var(--radius-sm);
    border: none;
    background: var(--primary);
    color: #fff;
    font-size: 14.5px;
    font-weight: 700;
    cursor: pointer;
}
#startBtn:hover { background: var(--primary-dark); }

.hidden { display: none !important; }
</style>
</head>
<body>

<div id="welcomeOverlay">
    <div id="welcomeCard">
        <h2>🧠 TRX AI</h2>
        <p>دستیار هوشمند فارسی‌زبان شما — نام‌تان را وارد کنید (اختیاری)</p>
        <input id="nameInput" type="text" placeholder="مثلاً: امیر" />
        <button id="startBtn">شروع گفتگو</button>
    </div>
</div>

<div id="header">
    <div class="brand">
        <div class="name">🧠 TRX AI <span id="connDot" title="وضعیتِ اتصال"></span></div>
        <div class="sub" id="headerSub">دستیار هوشمند فارسی</div>
    </div>
    <div class="actions">
        <button class="icon-btn" id="themeBtn" title="تغییرِ پوسته">🌙</button>
    </div>
</div>

<div id="chat"></div>

<div id="chips"></div>

<div id="inputBar">
    <button id="attachBtn" title="پیوستِ عکس">📷</button>
    <input id="imageInput" type="file" accept="image/*" class="hidden" />
    <button id="attachFileBtn" title="پیوستِ فایل (PDF/Word/Excel/متن/کد)">📎</button>
    <input id="fileInput" type="file" accept=".pdf,.docx,.doc,.xlsx,.xls,.txt,.py,.json,.csv,.html,.css,.js,.md" class="hidden" />
    <textarea id="textInput" rows="1" placeholder="پیام خود را بنویسید..."></textarea>
    <button id="sendBtn" title="ارسال">➤</button>
</div>

<script>
(function () {
    "use strict";

    const chat = document.getElementById("chat");
    const chips = document.getElementById("chips");
    const textInput = document.getElementById("textInput");
    const sendBtn = document.getElementById("sendBtn");
    const attachBtn = document.getElementById("attachBtn");
    const imageInput = document.getElementById("imageInput");
    const attachFileBtn = document.getElementById("attachFileBtn");
    const fileInput = document.getElementById("fileInput");
    const connDot = document.getElementById("connDot");
    const themeBtn = document.getElementById("themeBtn");
    const headerSub = document.getElementById("headerSub");
    const welcomeOverlay = document.getElementById("welcomeOverlay");
    const nameInput = document.getElementById("nameInput");
    const startBtn = document.getElementById("startBtn");

    let ws = null;
    let wsReady = false;
    let activeStreamRow = null;   // <div class="row bot"> در حالِ استریم
    let activeStreamId = null;
    let activeAudio = null;
    let activeSpeakButton = null;

    function stopSpeech() {
        if (activeAudio) {
            try { activeAudio.pause(); activeAudio.currentTime = 0; } catch (_) {}
            if (activeAudio._objectUrl) URL.revokeObjectURL(activeAudio._objectUrl);
        }
        if (activeSpeakButton) {
            activeSpeakButton.classList.remove("speaking");
            activeSpeakButton.innerHTML = "🔊 خواندن";
        }
        activeAudio = null;
        activeSpeakButton = null;
    }

    function cleanSpeechText(text) {
        return String(text || "")
            .replace(/```[\s\S]*?```/g, " کد. ")
            .replace(/`([^`]+)`/g, "$1")
            .replace(/[*_#>~]/g, " ")
            .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
            .replace(/https?:\/\/\S+/g, "")
            .replace(/\s+/g, " ")
            .trim();
    }

    async function speakPersian(text, btn) {
        const clean = cleanSpeechText(text);
        if (!clean) return;

        stopSpeech();
        btn.classList.add("speaking");
        btn.innerHTML = "⏳ در حال آماده‌سازی";
        activeSpeakButton = btn;

        try {
            // صدا را خودِ TRX با همان Microsoft Neural / edge-tts می‌سازد؛
            // فایل روی دیسک ساخته نمی‌شود و MP3 مستقیم به مرورگر می‌رسد.
            const res = await fetch("/tts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: clean, voice: "2" })
            });
            if (!res.ok) {
                let detail = "خطا در ساخت صدای فارسی.";
                try {
                    const data = await res.json();
                    if (data.error) detail = data.error;
                } catch (_) {}
                throw new Error(detail);
            }

            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const audio = new Audio(url);
            audio._objectUrl = url;
            activeAudio = audio;
            btn.innerHTML = "⏹ توقف";

            audio.onended = () => {
                if (activeAudio === audio) stopSpeech();
            };
            audio.onerror = () => {
                if (activeAudio === audio) {
                    stopSpeech();
                    alert("پخش صدای فارسی انجام نشد.");
                }
            };
            await audio.play();
        } catch (err) {
            stopSpeech();
            alert(err && err.message ? err.message : "خطا در پخش صدای فارسی.");
        }
    }

    function addSpeakButton(bubble, text) {
        const clean = cleanSpeechText(text);
        if (!clean) return;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "speak-btn";
        btn.title = "خواندن همین پاسخ با صدای Microsoft Neural (Dilara)";
        btn.innerHTML = "🔊 خواندن";
        btn.onclick = () => {
            if (activeSpeakButton === btn && activeAudio) {
                stopSpeech();
                return;
            }
            speakPersian(clean, btn);
        };
        bubble.appendChild(btn);
    }

    const CHIPS = [
        ["📊 آمار", "آمار"],
        ["🖥️ داشبورد", "داشبورد"],
        ["📋 کارهام", "کارهام چیه"],
        ["📖 راهنما", "راهنما"],
        ["😄 جوک", "یه جوک بگو"],
    ];
    CHIPS.forEach(([label, cmd]) => {
        const b = document.createElement("button");
        b.className = "chip";
        b.textContent = label;
        b.onclick = () => sendMessage(cmd);
        chips.appendChild(b);
    });

    function nowLabel() {
        const d = new Date();
        return d.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
    }

    function scrollToBottom() {
        chat.scrollTop = chat.scrollHeight;
    }

    function escapeHtml(s) {
        const div = document.createElement("div");
        div.textContent = s;
        return div.innerHTML;
    }

    function addRow(side, bubbleClass, innerHtml) {
        const row = document.createElement("div");
        row.className = "row " + side;
        const bubble = document.createElement("div");
        bubble.className = "bubble" + (bubbleClass ? " " + bubbleClass : "");
        bubble.innerHTML = innerHtml;
        row.appendChild(bubble);
        chat.appendChild(row);
        scrollToBottom();
        return row;
    }

    function addUserMessage(text) {
        addRow("user", "", `<span class="label">شما</span>${escapeHtml(text)}<span class="time">${nowLabel()}</span>`);
    }

    function openFullImage(url) {
        window.open(url, "_blank", "noopener");
    }

    function addUserImage(objectUrl, caption) {
        const capHtml = caption ? `<div class="image-caption">${escapeHtml(caption)}</div>` : "";
        const row = addRow("user", "", `<span class="label">شما</span><img class="chat-image" src="${objectUrl}" alt="عکسِ ارسالی" />${capHtml}<span class="time">${nowLabel()}</span>`);
        const img = row.querySelector("img.chat-image");
        if (img) img.onclick = () => openFullImage(objectUrl);
        return row;
    }

    function addUserFile(filename, caption) {
        const capHtml = caption ? `<div class="image-caption">${escapeHtml(caption)}</div>` : "";
        return addRow("user", "", `<span class="label">شما</span><div class="file-chip">📎 ${escapeHtml(filename)}</div>${capHtml}<span class="time">${nowLabel()}</span>`);
    }

    function addBotImage(url, title, caption) {
        const capHtml = caption ? `<div class="image-caption">${escapeHtml(caption)}</div>` : "";
        const row = addRow("bot", "", `<span class="label">🤖 ${escapeHtml(title || "تصویر")}</span><img class="chat-image" src="${url}" alt="تصویر" />${capHtml}<div class="image-caption">🔍 برایِ دیدن/دانلودِ اندازه‌ی کامل، رویِ عکس بزن.</div><span class="time">${nowLabel()}</span>`);
        const img = row.querySelector("img.chat-image");
        if (img) img.onclick = () => openFullImage(url);
        return row;
    }

    function addBotScene(url, title, sceneId, duration) {
        // امنیت: sandbox عمداً فقط "allow-scripts" دارد -- بدونِ
        // allow-same-origin/allow-popups/allow-top-navigation، یعنی
        // اسکریپتِ داخلِ صحنه نه به کوکی/DOMِ صفحه‌ی اصلی دسترسی دارد،
        // نه می‌تواند تب/پنجره باز کند یا صفحه‌ی اصلی را ناوبری کند
        // (بخشِ ۱۶ و ۱۷ سندِ طراحیِ موتورِ ویدیو).
        const durLabel = duration ? ` · ${Math.round(duration)} ثانیه` : "";
        const frameHtml =
            `<span class="label">${escapeHtml(title || "🎬 صحنه‌ی ویدیو")}</span>` +
            `<iframe class="chat-scene-frame" src="${url}" sandbox="allow-scripts"` +
            ` style="width:100%;max-width:480px;aspect-ratio:16/9;border:1px solid rgba(255,255,255,0.15);` +
            `border-radius:10px;background:#000;display:block;" loading="lazy"></iframe>` +
            `<div class="image-caption">🎬 صحنه‌ی داخلیِ TRX${durLabel} -- برایِ اصلاح بگو مثلاً «نور رو کم کن».</div>` +
            `<span class="time">${nowLabel()}</span>`;
        return addRow("bot", "", frameHtml);
    }

    function addBotMessage(text, title, styleClass) {
        const row = addRow("bot", styleClass || "", `<span class="label">🤖 ${escapeHtml(title || "پاسخ")}</span>${escapeHtml(text)}<span class="time">${nowLabel()}</span>`);
        const bubble = row.querySelector(".bubble");
        if (bubble) addSpeakButton(bubble, text);
        return row;
    }

    function addSystemLine(text) {
        addRow("bot", "system", escapeHtml(text));
    }

    function addGuide(rows) {
        let html = `<span class="label">📖 راهنما</span><table class="guide-table">`;
        rows.forEach(([a, b]) => { html += `<tr><td>${escapeHtml(a)}</td><td>${escapeHtml(b)}</td></tr>`; });
        html += `</table>`;
        addRow("bot", "", html);
    }

    let typingRow = null;
    function showTyping() {
        if (typingRow) return;
        typingRow = addRow("bot", "", `<div class="typing-dots"><span></span><span></span><span></span></div>`);
    }
    function hideTyping() {
        if (typingRow) { typingRow.remove(); typingRow = null; }
    }

    // ---------------- استریمِ زنده ----------------
    function streamStart(streamId, title) {
        hideTyping();
        stopSpeech();
        activeStreamId = streamId;
        activeStreamRow = addRow("bot", "", `<span class="label">🤖 ${escapeHtml(title || "پاسخ")}</span><span class="stream-text cursor-blink"></span>`);
    }
    function streamDelta(streamId, text) {
        if (streamId !== activeStreamId || !activeStreamRow) return;
        const el = activeStreamRow.querySelector(".stream-text");
        if (el) el.textContent = text;
        scrollToBottom();
    }
    function streamEnd(streamId) {
        if (streamId !== activeStreamId) return;
        const el = activeStreamRow && activeStreamRow.querySelector(".stream-text");
        if (el) el.classList.remove("cursor-blink");
        const bubble = activeStreamRow && activeStreamRow.querySelector(".bubble");
        if (bubble) {
            const text = (el && el.textContent) || "";
            const t = document.createElement("span");
            t.className = "time";
            t.textContent = nowLabel();
            bubble.appendChild(t);
            addSpeakButton(bubble, text);
        }
        activeStreamRow = null;
        activeStreamId = null;
    }

    // ---------------- WebSocket ----------------
    function connect() {
        const proto = location.protocol === "https:" ? "wss:" : "ws:";
        ws = new WebSocket(`${proto}//${location.host}/ws`);

        ws.onopen = () => {
            wsReady = true;
            connDot.className = "ok";
        };
        ws.onclose = () => {
            wsReady = false;
            connDot.className = "bad";
            setTimeout(connect, 1500);
        };
        ws.onerror = () => { connDot.className = "bad"; };
        ws.onmessage = (ev) => {
            let data;
            try { data = JSON.parse(ev.data); } catch (e) { return; }
            handleEvent(data);
        };
    }

    function handleEvent(ev) {
        switch (ev.kind) {
            case "message":
                hideTyping();
                addBotMessage(ev.text, ev.title, "");
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
            case "emergency":
                hideTyping();
                addBotMessage(ev.text, "🚨 اورژانسی", "emergency");
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
            case "followup":
                hideTyping();
                addBotMessage(ev.text, "🩺 سؤال پیگیری", "followup");
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
            case "raw":
                if (ev.text && ev.text.trim()) addSystemLine(ev.text);
                break;
            case "image":
                hideTyping();
                addBotImage(ev.url, ev.title, ev.caption);
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
            case "scene":
                hideTyping();
                addBotScene(ev.url, ev.title, ev.scene_id, ev.duration);
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
            case "guide":
                addGuide(ev.rows || []);
                break;
            case "status_start":
                showTyping();
                break;
            case "status_end":
                hideTyping();
                break;
            case "stream_start":
                streamStart(ev.stream_id, ev.title);
                break;
            case "stream_delta":
                streamDelta(ev.stream_id, ev.text);
                break;
            case "stream_end":
                streamEnd(ev.stream_id);
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
            case "status":
                headerSub.textContent = [ev.user, ev.personality, ev.project ? "پروژه: " + ev.project : ""]
                    .filter(Boolean).join(" · ") || "دستیار هوشمند فارسی";
                break;
            case "turn_end":
                // سیگنالِ معتبرِ «نوبت تمام شد» — چه با یک پیامِ معمولی
                // تمام شده باشد، چه با دستورهایی مثلِ «آمار»/«داشبورد»/
                // «تاریخچه» که فقط یک رویدادِ raw می‌فرستند (باگی که
                // قبلاً باعث می‌شد sendBtn بعدِ این دستورها برای همیشه
                // غیرفعال بماند). تکرار بی‌ضرر است.
                hideTyping();
                sendBtn.disabled = false;
                attachBtn.disabled = false;
                attachFileBtn.disabled = false;
                break;
        }
    }

    // ---------------- ارسال پیام (متن و/یا عکس/فایلِ درحالِ‌پیوست) ----------------
    let pendingImage = null; // { file, mime, base64, previewUrl } یا null
    let pendingFile = null; // { file, filename, base64 } یا null

    function sendMessage(text) {
        text = (text !== undefined ? text : textInput.value).trim();
        if (!wsReady) return;

        if (pendingImage) {
            if (!pendingImage.base64) return; // هنوز در حالِ خواندنِ فایل است؛ صبر کن
            stopSpeech();
            addUserImage(pendingImage.previewUrl, text);
            sendBtn.disabled = true;
            attachBtn.disabled = true;
            attachFileBtn.disabled = true;
            showTyping();
            ws.send(JSON.stringify({ type: "image", data: pendingImage.base64, mime: pendingImage.mime, caption: text }));
            clearPendingImage();
            textInput.value = "";
            autoResize();
            return;
        }

        if (pendingFile) {
            if (!pendingFile.base64) return; // هنوز در حالِ خواندنِ فایل است؛ صبر کن
            stopSpeech();
            addUserFile(pendingFile.filename, text);
            sendBtn.disabled = true;
            attachBtn.disabled = true;
            attachFileBtn.disabled = true;
            showTyping();
            ws.send(JSON.stringify({ type: "file", data: pendingFile.base64, filename: pendingFile.filename, caption: text }));
            clearPendingFile();
            textInput.value = "";
            autoResize();
            return;
        }

        if (!text) return;
        stopSpeech();
        addUserMessage(text);
        sendBtn.disabled = true;
        showTyping();
        ws.send(JSON.stringify({ type: "message", text }));
        textInput.value = "";
        autoResize();
    }

    sendBtn.onclick = () => sendMessage();
    textInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    function autoResize() {
        textInput.style.height = "auto";
        textInput.style.height = Math.min(textInput.scrollHeight, 120) + "px";
    }
    textInput.addEventListener("input", autoResize);

    // ---------------- پیوستِ عکس ----------------
    // نکته‌ی مهم (رفعِ باگِ گزارش‌شده): انتخابِ فایل دیگر بلافاصله
    // نمی‌فرستد. اگر می‌فرستاد، هیچ‌وقت فرصتی برایِ نوشتنِ کپشنِ
    // «کیفیت...»/«متن...» *بعدِ* پیوست‌کردن وجود نداشت (کاربر باید اول
    // کپشن را حدس می‌زد و تایپ می‌کرد، بعد عکس را پیوست می‌کرد — برعکسِ
    // رفتارِ طبیعیِ هر اپِ چتِ دیگر). حالا: پیوست → پیش‌نمایش → کاربر
    // کپشن می‌نویسد → دکمه‌ی ارسال را می‌زند.
    const MAX_IMAGE_MB = 15; // باید با vision.MAX_IMAGE_BYTES در بک‌اند هماهنگ بماند

    attachBtn.onclick = () => imageInput.click();

    function clearPendingImage() {
        if (pendingImage && pendingImage.previewUrl) URL.revokeObjectURL(pendingImage.previewUrl);
        pendingImage = null;
        const bar = document.getElementById("imagePreviewBar");
        if (bar) bar.remove();
        textInput.placeholder = "پیام خود را بنویسید...";
    }

    function showPendingImagePreview(previewUrl, fileName) {
        const old = document.getElementById("imagePreviewBar");
        if (old) old.remove();
        const bar = document.createElement("div");
        bar.id = "imagePreviewBar";
        bar.innerHTML = `
            <img src="${previewUrl}" alt="پیش‌نمایش" />
            <span class="name">${escapeHtml(fileName)}</span>
            <button type="button" title="حذفِ عکس">✕</button>
        `;
        bar.querySelector("button").onclick = () => clearPendingImage();
        const inputBar = document.getElementById("inputBar");
        inputBar.parentNode.insertBefore(bar, inputBar);
        textInput.placeholder = "کپشن بنویس: «توضیح بده» / «متن رو بخون» / «کیفیتش رو ببر بالا» ...";
        textInput.focus();
    }

    imageInput.addEventListener("change", () => {
        const file = imageInput.files && imageInput.files[0];
        imageInput.value = ""; // تا انتخابِ دوباره‌ی همان فایل هم رویداد بدهد
        if (!file) return;
        if (!file.type.startsWith("image/")) {
            alert("فقط فایلِ عکس پذیرفته می‌شود.");
            return;
        }
        if (file.size > MAX_IMAGE_MB * 1024 * 1024) {
            alert(`حجمِ عکس بیش از ${MAX_IMAGE_MB} مگابایت است.`);
            return;
        }
        const previewUrl = URL.createObjectURL(file);
        clearPendingFile();
        pendingImage = { file, mime: file.type, base64: null, previewUrl };
        showPendingImagePreview(previewUrl, file.name);

        const reader = new FileReader();
        reader.onload = () => {
            // reader.result یعنی "data:image/jpeg;base64,AAAA..." — فقط بخشِ بعدِ کاما لازم است
            if (pendingImage && pendingImage.file === file) {
                pendingImage.base64 = String(reader.result).split(",")[1] || "";
            }
        };
        reader.onerror = () => {
            alert("خواندنِ فایلِ عکس شکست خورد.");
            clearPendingImage();
        };
        reader.readAsDataURL(file);
    });

    // ---------------- پیوستِ فایل (PDF/Word/Excel/متن/کد) ----------------
    // معادلِ دقیقِ منطقِ «پیوستِ عکس» بالا: پیوست → پیش‌نمایش → کپشنِ
    // اختیاری → ارسال. باید با FileManager.ALLOWED_UPLOAD_EXTENSIONS و
    // FileManager.MAX_UPLOAD_BYTES در بک‌اند (tools.py) هماهنگ بماند.
    const MAX_FILE_MB = 20;
    const ALLOWED_FILE_EXT = [".pdf", ".docx", ".doc", ".xlsx", ".xls",
        ".txt", ".py", ".json", ".csv", ".html", ".css", ".js", ".md"];

    attachFileBtn.onclick = () => fileInput.click();

    function clearPendingFile() {
        pendingFile = null;
        const bar = document.getElementById("filePreviewBar");
        if (bar) bar.remove();
        textInput.placeholder = "پیام خود را بنویسید...";
    }

    function showPendingFilePreview(fileName) {
        const old = document.getElementById("filePreviewBar");
        if (old) old.remove();
        const bar = document.createElement("div");
        bar.id = "filePreviewBar";
        bar.innerHTML = `
            <span class="file-icon">📎</span>
            <span class="name">${escapeHtml(fileName)}</span>
            <button type="button" title="حذفِ فایل">✕</button>
        `;
        bar.querySelector("button").onclick = () => clearPendingFile();
        const inputBar = document.getElementById("inputBar");
        inputBar.parentNode.insertBefore(bar, inputBar);
        textInput.placeholder = "یادداشتِ اختیاری بنویس (یا خالی بگذار) و ارسال کن...";
        textInput.focus();
    }

    fileInput.addEventListener("change", () => {
        const file = fileInput.files && fileInput.files[0];
        fileInput.value = ""; // تا انتخابِ دوباره‌ی همان فایل هم رویداد بدهد
        if (!file) return;
        const ext = "." + (file.name.split(".").pop() || "").toLowerCase();
        if (!ALLOWED_FILE_EXT.includes(ext)) {
            alert(`فرمتِ «${ext}» پشتیبانی نمی‌شود.\nفرمت‌هایِ مجاز: ${ALLOWED_FILE_EXT.join("، ")}`);
            return;
        }
        if (file.size > MAX_FILE_MB * 1024 * 1024) {
            alert(`حجمِ فایل بیش از ${MAX_FILE_MB} مگابایت است.`);
            return;
        }
        pendingFile = { file, filename: file.name, base64: null };
        clearPendingImage();
        showPendingFilePreview(file.name);

        const reader = new FileReader();
        reader.onload = () => {
            if (pendingFile && pendingFile.file === file) {
                pendingFile.base64 = String(reader.result).split(",")[1] || "";
            }
        };
        reader.onerror = () => {
            alert("خواندنِ فایل شکست خورد.");
            clearPendingFile();
        };
        reader.readAsDataURL(file);
    });

    // ---------------- تم ----------------
    function applyTheme(mode) {
        document.documentElement.classList.toggle("light", mode === "light");
        themeBtn.textContent = mode === "light" ? "☀️" : "🌙";
        try { localStorage.setItem("trx_theme", mode); } catch (e) {}
    }
    themeBtn.onclick = () => {
        const isLight = document.documentElement.classList.contains("light");
        applyTheme(isLight ? "dark" : "light");
    };
    try {
        const saved = localStorage.getItem("trx_theme");
        if (saved) applyTheme(saved);
    } catch (e) {}

    // ---------------- شروع ----------------
    startBtn.onclick = () => {
        const name = nameInput.value.trim();
        welcomeOverlay.classList.add("hidden");
        // تا وقتی سرور رویدادِ «turn_end» را بعدِ اتمامِ init_for_gui
        // نفرستد، ارسال غیرفعال است — وگرنه اگر کاربر سریع تایپ کند،
        // پیام قبل از تمام‌شدنِ راه‌اندازیِ سمتِ سرور می‌رسد (مثلاً
        // self.session هنوز ساخته نشده).
        sendBtn.disabled = true;
        connect();
        const waitAndInit = () => {
            if (wsReady) {
                ws.send(JSON.stringify({ type: "init", name }));
            } else {
                setTimeout(waitAndInit, 100);
            }
        };
        waitAndInit();
        textInput.focus();
    };
    nameInput.addEventListener("keydown", (e) => { if (e.key === "Enter") startBtn.click(); });
})();
</script>
</body>
</html>
"""
