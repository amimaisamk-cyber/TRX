# -*- coding: utf-8 -*-
"""
تبدیل متن به گفتار فارسی با استفاده از edge-tts.
"""

from __future__ import annotations

import os
import re
import time

try:
    from edge_tts import Communicate
    EDGE_TTS_AVAILABLE = True
except ImportError:
    Communicate = None
    EDGE_TTS_AVAILABLE = False

from .config import OS_AUDIO_DIR, VOICES
from .logging_config import get_logger

logger = get_logger(__name__)

if not EDGE_TTS_AVAILABLE:
    logger.warning("edge_tts در دسترس نیست؛ تبدیلِ متن‌به‌گفتار غیرفعال می‌ماند.")

class AudioVoiceEngine:
    @staticmethod
    async def text_to_speech_save(text, voice_choice):
        if not EDGE_TTS_AVAILABLE:
            # به‌جایِ کرش‌کردنِ کلِ برنامه در لحظه‌یِ import (چون این
            # پکیجِ اختیاری نصب نیست)، فقط این یک قابلیت را غیرفعال
            # می‌کنیم. صدازنِ این تابع (core.py) از قبل None را به
            # معنیِ شکستِ تولیدِ صدا می‌گیرد و پیامِ voice_failed را
            # نشان می‌دهد — پس رفتارِ بیرونی همان چیزی‌ست که پیش از این
            # هم برایِ خطاهایِ دیگرِ تبدیلِ صدا وجود داشت.
            logger.warning("تلاش برای تبدیلِ متن‌به‌گفتار درحالی‌که edge_tts نصب نیست.")
            return None
        try:
            clean_text = re.sub(r'\[.*?\]', '', text)
            clean_text = re.sub(r'[*`#]', '', clean_text).strip()
            if len(clean_text) > 3000:
                clean_text = clean_text[:3000] + "..."
            if not clean_text:
                return None
            voice = VOICES.get(voice_choice, "fa-IR-FaridNeural")
            filename = f"voice_{int(time.time())}.mp3"
            filepath = os.path.join(OS_AUDIO_DIR, filename)
            communicate = Communicate(clean_text, voice)
            await communicate.save(filepath)
            if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                return filepath
            return None
        except Exception as e:
            print(f"❌ خطای صوتی: {e}")
            logger.exception("خطای تبدیل متن به گفتار: %s", e)
            return None
