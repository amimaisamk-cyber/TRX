# -*- coding: utf-8 -*-
"""
سیستم پلاگین: بارگذاری، فعال/غیرفعال‌سازی و اجرای افزونه‌های JSON.

⚠️ توجه امنیتی (بدون تغییر رفتار):
    اجرای پلاگین از exec() روی محتوای فایل پلاگین استفاده می‌کند. این
    قابلیت به‌طور ذاتی به معنای اجرای کد دلخواه است و باید فقط برای
    پلاگین‌هایی به کار رود که خودِ کاربر (یا منبعی مورد اعتماد) نوشته
    است. اکنون هر بار پیش از اجرا یک هشدار در لاگ ثبت می‌شود.
"""

from __future__ import annotations

import json
import math
import os
import random
import re
from pathlib import Path

from .logging_config import get_logger
from .models import Plugin
from .security import (
    ExecutionTimeout,
    find_dangerous_pattern,
    restricted_builtins,
    time_limited_execution,
)

logger = get_logger(__name__)

# جداکننده‌هایِ مسیر و «..» هیچ‌وقت نباید در نامِ یک پلاگین باشند —
# وگرنه مسیرِ ساخته‌شده می‌تواند از پوشه‌ی plugins بیرون بزند (مثلاً
# نامِ «../escape» باعث می‌شود plugin.path به‌جایِ چیزی داخلِ plugins/
# به یک فایلِ بیرون از آن اشاره کند: Path Traversal).
_UNSAFE_PLUGIN_NAME_RE = re.compile(r'[\\/]')


def _sanitize_plugin_name(name: str) -> str:
    """
    اگر نام شاملِ جداکننده‌ی مسیر یا «..» باشد (یا خالی/فقط «.»/«..»
    باشد)، ValueError می‌دهد؛ در غیرِ این‌صورت همان نامِ strip‌شده را
    برمی‌گرداند.
    """
    cleaned = (name or "").strip()
    if not cleaned or cleaned in (".", "..") or ".." in cleaned or _UNSAFE_PLUGIN_NAME_RE.search(cleaned):
        raise ValueError(f"نامِ پلاگین نامعتبر است (نباید شاملِ /، \\، یا .. باشد): {name!r}")
    return cleaned


# مجوزهایی که یک پلاگین می‌تواند ادعا کند لازم دارد. «network» و
# «filesystem» عمداً همیشه رد می‌شوند (نه فقط علامت‌گذاری می‌شوند):
# چون find_dangerous_pattern در security.py به‌طورِ کامل و برایِ همه‌ی
# پلاگین‌ها os/subprocess/شبکه/دسترسیِ فایل را مسدود می‌کند، هیچ راهی
# برای واقعاً «اعطاکردنِ» این دو مجوز در این نسخه وجود ندارد؛ قبول‌کردنِ
# نصبِ چنین پلاگینی و بعداً بلوک‌کردنش موقعِ اجرا (با یک خطایِ گنگ)
# گمراه‌کننده است — بهتر است همان لحظه‌ی نصب، شفاف رد شود.
KNOWN_PLUGIN_PERMISSIONS = {"math", "random", "text"}
UNGRANTABLE_PLUGIN_PERMISSIONS = {"network", "filesystem", "shell", "database"}


def _validate_plugin_permissions(permissions) -> list[str]:
    perms = [str(p).strip().lower() for p in (permissions or []) if str(p).strip()]
    unknown = [p for p in perms if p not in KNOWN_PLUGIN_PERMISSIONS and p not in UNGRANTABLE_PLUGIN_PERMISSIONS]
    if unknown:
        raise ValueError(f"مجوزِ ناشناخته: {unknown!r} (مجوزهایِ معتبر: {sorted(KNOWN_PLUGIN_PERMISSIONS)})")
    ungrantable = [p for p in perms if p in UNGRANTABLE_PLUGIN_PERMISSIONS]
    if ungrantable:
        raise ValueError(
            f"این نسخه از TRX AI نمی‌تواند مجوزهایِ {ungrantable!r} را به هیچ پلاگینی بدهد "
            f"(دسترسیِ سیستمی/شبکه/فایل برایِ همه‌ی پلاگین‌ها همیشه مسدود است)."
        )
    return perms


class PluginSystem:
    """
    سیستم مدیریت پلاگین‌ها
    """

    # همان محدودیتِ زمانیِ مفسر فارسی، برای همان دلیل: بدونش، یک پلاگینِ
    # معیوب با حلقه‌ی بی‌پایان کلِ برنامه را فریز می‌کرد.
    EXECUTION_TIMEOUT_SECONDS = 5

    def __init__(self, plugins_dir="plugins"):
        self.plugins_dir = Path(plugins_dir)
        self.plugins_dir.mkdir(exist_ok=True)
        self.plugins = {}
        self._load_plugins()

    def _load_plugins(self):
        """بارگذاری پلاگین‌ها از دایرکتوری"""
        for plugin_file in self.plugins_dir.glob("*.json"):
            try:
                with open(plugin_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    plugin = Plugin(
                        name=data.get("name", plugin_file.stem),
                        version=data.get("version", "1.0.0"),
                        description=data.get("description", ""),
                        author=data.get("author", "ناشناس"),
                        license=data.get("license", "MIT"),
                        dependencies=data.get("dependencies", []),
                        path=str(plugin_file),
                        enabled=data.get("enabled", True),
                        permissions=data.get("permissions", []),
                    )
                    self.plugins[plugin.name] = plugin
            except Exception as e:
                print(f"⚠️ خطا در بارگذاری پلاگین {plugin_file}: {e}")

    def install_plugin(self, plugin_data, plugin_content):
        """نصب پلاگین جدید"""
        try:
            safe_name = _sanitize_plugin_name(plugin_data["name"])
            permissions = _validate_plugin_permissions(plugin_data.get("permissions", []))
            plugin = Plugin(
                name=safe_name,
                version=plugin_data.get("version", "1.0.0"),
                description=plugin_data.get("description", ""),
                author=plugin_data.get("author", "ناشناس"),
                license=plugin_data.get("license", "MIT"),
                dependencies=plugin_data.get("dependencies", []),
                path=str(self.plugins_dir / f"{safe_name}.json"),
                enabled=True,
                permissions=permissions,
            )

            # لایه‌ی دومِ محافظت (defense-in-depth): حتی اگر sanitize
            # بالا یک چیزی را از قلم بیندازد، این بررسیِ نهایی مطمئن
            # می‌شود مسیرِ واقعاً resolve‌شده هنوز داخلِ plugins_dir است.
            resolved = Path(plugin.path).resolve()
            if resolved.parent != self.plugins_dir.resolve():
                raise ValueError(f"مسیرِ پلاگین بیرون از پوشه‌ی مجاز است: {resolved}")

            with open(plugin.path, 'w', encoding='utf-8') as f:
                json.dump({
                    "name": plugin.name,
                    "version": plugin.version,
                    "description": plugin.description,
                    "author": plugin.author,
                    "license": plugin.license,
                    "dependencies": plugin.dependencies,
                    "enabled": plugin.enabled,
                    "permissions": plugin.permissions,
                    "content": plugin_content
                }, f, ensure_ascii=False, indent=2)
            
            self.plugins[plugin.name] = plugin
            return plugin
        except Exception as e:
            print(f"❌ خطا در نصب پلاگین: {e}")
            logger.exception("خطا در نصب پلاگین: %s", e)
            return None

    def uninstall_plugin(self, plugin_name):
        """حذف پلاگین"""
        if plugin_name in self.plugins:
            plugin = self.plugins[plugin_name]
            try:
                os.remove(plugin.path)
                del self.plugins[plugin_name]
                return True
            except Exception as e:
                print(f"❌ خطا در حذف پلاگین: {e}")
                logger.exception("خطا در حذف پلاگین: %s", e)
                return False
        return False

    def get_plugin(self, plugin_name):
        """دریافت پلاگین"""
        return self.plugins.get(plugin_name)

    def list_plugins(self):
        """لیست پلاگین‌ها"""
        return [{"name": p.name, "version": p.version, "enabled": p.enabled, "permissions": p.permissions}
                for p in self.plugins.values()]

    def execute_plugin(self, plugin_name, input_data):
        """اجرای پلاگین"""
        plugin = self.get_plugin(plugin_name)
        if not plugin or not plugin.enabled:
            return None
        
        try:
            # بارگذاری محتوای پلاگین
            with open(plugin.path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                code = data.get("content", "")

            danger = find_dangerous_pattern(code)
            if danger:
                msg = f"⛔ اجرای پلاگین '{plugin_name}' متوقف شد: {danger}"
                print(msg)
                logger.warning(msg)
                return None

            # اجرای کد پلاگین — __builtins__ محدودشده (لایه‌ی دومِ
            # دفاعی، مستقل از find_dangerous_pattern بالا؛ نگاه کنید به
            # restricted_builtins در security.py).
            exec_globals = {
                "__builtins__": restricted_builtins(),
                "input_data": input_data,
                "math": math,
                "random": random
            }
            logger.warning(
                "در حال اجرای کد پلاگین '%s' (exec). مجوزهایِ اعلام‌شده: %s.",
                plugin_name, plugin.permissions or ["(هیچ‌کدام)"]
            )
            try:
                with time_limited_execution(self.EXECUTION_TIMEOUT_SECONDS):
                    exec(code, exec_globals)
                    result = exec_globals["run"](input_data) if "run" in exec_globals else None
                return result
            except ExecutionTimeout:
                msg = f"⏱️ اجرای پلاگین '{plugin_name}' بیش از {self.EXECUTION_TIMEOUT_SECONDS} ثانیه طول کشید و متوقف شد."
                print(msg)
                logger.warning(msg)
                return None
        except Exception as e:
            print(f"❌ خطا در اجرای پلاگین {plugin_name}: {e}")
            logger.exception("خطا در اجرای پلاگین: %s", e)
            return None
