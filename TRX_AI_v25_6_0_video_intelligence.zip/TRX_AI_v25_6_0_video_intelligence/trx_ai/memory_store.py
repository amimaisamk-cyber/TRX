# -*- coding: utf-8 -*-
"""
لایه‌ی حافظه‌ی سیستم: حافظه‌ی مکالمه‌ای چندلایه (MemoryEngine)، کش نتایج
(CacheManager)، حافظه‌ی برداری برای جستجوی معنایی (VectorDatabase) و
مدیریت نشست/پروژه‌ها (SessionManager).
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from collections import defaultdict, deque
from datetime import datetime

from .dependencies import CHROMA_AVAILABLE, SENTENCE_TRANSFORMER_AVAILABLE
from .logging_config import get_logger
from .models import Message
from .memory_correction import MemoryCorrectionEngine, _GENERIC_STOPWORDS

logger = get_logger(__name__)

if CHROMA_AVAILABLE:
    import chromadb
    from chromadb.config import Settings as ChromaSettings
if SENTENCE_TRANSFORMER_AVAILABLE:
    from sentence_transformers import SentenceTransformer

class MemoryEngine:
    """
    سیستم حافظه چندلایه TRX AI v20
    - حافظه کوتاه‌مدت: 30 پیام اخیر در RAM
    - حافظه بلندمدت: SQLite (علایق، پروژه‌ها، حقایق)
    - حافظه برداری: ChromaDB برای جستجوی معنایی
    - خلاصه‌سازی خودکار هر 30 پیام
    - اولویت‌بندی و حذف اطلاعات کم‌اهمیت
    """

    def __init__(self, db, vector_db=None):
        self.db = db
        self.vector_db = vector_db
        # حافظه کوتاه‌مدت: deque با سقف 30 پیام
        self.short_term = deque(maxlen=30)
        # حافظه پروژه‌ها
        self.projects = {}
        # حافظه علایق
        self.interests = defaultdict(int)
        # حافظه حقایق مهم
        self.facts = []
        # موضوع جاری مکالمه
        self.current_topic = None
        # پیشینه ارجاعات (برای ضمایر)
        self.entity_stack = deque(maxlen=10)
        # شمارنده پیام برای trigger خلاصه‌سازی
        self.message_count = 0
        # خلاصه گفتگو
        self.conversation_summary = ""
        # اهداف کاربر
        self.user_goals = []

        # ==================================================
        #   موتورِ تصحیحِ حافظه (قابلیتِ تازه‌سیم‌کشی‌شده)
        # --------------------------------------------------
        # قبلاً `memory_correction.py` در پروژه وجود داشت اما هیچ‌جا
        # import نمی‌شد؛ یعنی حقایقِ متناقض (مثلاً تغییرِ اسم/پروژه‌ی
        # فعلی) برای همیشه کنارِ هم در `self.facts` می‌ماندند و هر دو در
        # جستجوی حافظه برمی‌گشتند. حالا `save_fact` هر حقیقتِ تازه را از
        # این موتور هم رد می‌کند تا نسخه‌ی قدیمیِ متناقض «منسوخ» علامت
        # بخورد و دیگر در پاسخ‌های بعدی گیج‌کننده ظاهر نشود.
        # ==================================================
        self.correction = MemoryCorrectionEngine(db)

        # بارگذاری حافظه بلندمدت
        self._load_long_term_memory()

        # مهاجرتِ یک‌باره: اگر حقایقِ قدیمی از دیتابیس بارگذاری شدند اما
        # موتورِ تصحیح هنوز چیزی برایشان ندارد (اولین اجرا پس از این
        # ارتقا)، آن‌ها را با اعتمادِ متوسط به موتورِ تصحیح هم می‌دهیم تا
        # داده‌ی قدیمی از دست نرود.
        if self.facts and not self.correction.items:
            for fact in self.facts:
                self.correction.add(fact, confidence=0.6, category="fact")

    def _load_long_term_memory(self):
        """
        بارگذاری حافظه بلندمدت از دیتابیس.

        هر بخش (پروژه‌ها/علایق/حقایق/خلاصه/اهداف) در try/except جداگانه
        بارگذاری می‌شود. قبلاً همه در یک try مشترک بودند؛ یعنی اگر مثلاً
        یک مقدارِ «علاقه» خراب/غیرعددی در دیتابیس بود (ValueError در
        `int(value)`)، کل تابع همان‌جا متوقف می‌شد و بارگذاریِ حقایق،
        خلاصه‌ی مکالمه و اهدافِ کاربر که بعد از آن می‌آمدند، اصلاً اجرا
        نمی‌شد — یک خرابیِ کوچک در یک بخش، بقیه‌ی حافظه را هم می‌بلعید.
        """
        try:
            projects_data = self.db.get_profile_by_prefix("memory:projects:")
            for key, value in projects_data:
                name = key.replace("memory:projects:", "").split(":")[0]
                if ":time" not in key and name not in self.projects:
                    self.projects[name] = value
        except Exception as e:
            logger.warning("بارگذاریِ پروژه‌های حافظه ناموفق بود: %s", e)

        try:
            interests_data = self.db.get_profile_by_prefix("memory:interests:")
            for key, value in interests_data:
                interest = key.replace("memory:interests:", "")
                try:
                    self.interests[interest] = int(value)
                except (TypeError, ValueError):
                    logger.debug("مقدارِ علاقه‌ی نامعتبر نادیده گرفته شد: %s=%r", interest, value)
        except Exception as e:
            logger.warning("بارگذاریِ علایقِ حافظه ناموفق بود: %s", e)

        try:
            facts_data = self.db.get_profile_by_prefix("memory:facts:")
            for key, value in facts_data:
                fact = key.replace("memory:facts:", "")
                self.facts.append(fact)
        except Exception as e:
            logger.warning("بارگذاریِ حقایقِ حافظه ناموفق بود: %s", e)

        try:
            self.conversation_summary = self.db.get_profile("memory:summary") or ""
        except Exception as e:
            logger.warning("بارگذاریِ خلاصه‌ی مکالمه ناموفق بود: %s", e)

        try:
            goals_data = self.db.get_profile("memory:goals")
            if goals_data:
                try:
                    self.user_goals = json.loads(goals_data)
                except (json.JSONDecodeError, TypeError) as e:
                    logger.warning("داده‌ی اهدافِ ذخیره‌شده معتبر نبود؛ نادیده گرفته شد: %s", e)
                    self.user_goals = []
        except Exception as e:
            logger.warning("بارگذاریِ اهدافِ کاربر ناموفق بود: %s", e)

    def add_message(self, role, content, topic=None, importance=1.0, metadata=None):
        """افزودن پیام به حافظه کوتاه‌مدت"""
        entry = Message(
            role=role,
            content=content,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            topic=topic,
            importance=importance,
            id=self.message_count,
            metadata=metadata or {}
        )
        self.short_term.append(entry)
        self.message_count += 1
        
        if topic:
            self.current_topic = topic
            self.entity_stack.append(topic)
        
        # هر 30 پیام خلاصه‌سازی کن
        if self.message_count % 30 == 0:
            self._auto_summarize()
        
        # ذخیره در حافظه برداری اگر فعال باشد
        if self.vector_db and importance > 0.5:
            self.vector_db.add_document(
                f"msg_{entry.id}",
                content,
                {"role": role, "topic": topic or "general", "timestamp": entry.timestamp}
            )

    def get_messages(self, limit=10, min_importance=0.0):
        """دریافت پیام‌های اخیر با فیلتر اهمیت"""
        messages = list(self.short_term)
        if min_importance > 0:
            messages = [m for m in messages if m.importance >= min_importance]
        return messages[-limit:]

    def get_context(self, max_messages=10, include_summary=True):
        """دریافت متن Context برای مدل"""
        messages = self.get_messages(max_messages)
        if not messages:
            return ""
        
        lines = []
        for msg in messages:
            role_label = "کاربر" if msg.role == "user" else "AI"
            lines.append(f"[{msg.timestamp}] {role_label}: {msg.content[:150]}")
        
        context = "\n".join(lines)
        
        if include_summary and self.conversation_summary:
            context = f"خلاصه مکالمه قبلی:\n{self.conversation_summary}\n\n{context}"
        
        return context

    @staticmethod
    def extract_topic_entity(text: str):
        """
        استخراجِ سبکِ موضوع/Entity از یک جمله برای تغذیه‌ی entity_stack.

        این متد جدید است چون بدون آن، entity_stack هرگز چیزی دریافت
        نمی‌کرد (در سراسر core.py هیچ‌جا add_message با topic=... صدا
        زده نمی‌شد) و resolve_pronoun همیشه بی‌اثر بود — یعنی مثال
        دقیقِ «RTX4090 چیه؟» → «اون چقدره؟» هرگز کار نمی‌کرد.

        فقط چند الگوی رایج و کم‌ریسک پوشش داده می‌شود (نه NER کامل):
        «X چیه/چیست/کیه/کیست»، «معنی X چیه»، «X یعنی چی»،
        «X که بود/کی بود» (مثلِ «اکبر عبدی که بود؟»).
        """
        t = text.strip()
        patterns = [
            r'^معنی\s+(?P<e>.+?)\s+چیه\؟?$',
            r'^(?P<e>.+?)\s+یعنی\s+چی\؟?$',
            r'^(?P<e>.+?)\s+(چیه|چیست|کیه|کیست)\؟?$',
            r'^(?P<e>.+?)\s+(که|کی)\s+بود\؟?$',
        ]
        for p in patterns:
            m = re.match(p, t)
            if m:
                entity = m.group("e").strip()
                # موضوعات خیلی کوتاه یا خیلی عمومی (مثل «این»/«اون»)
                # به‌عنوان Entity معتبر شمرده نمی‌شوند.
                if entity and len(entity) > 1 and entity not in ("این", "اون", "آن", "او"):
                    return entity
        return None

    def resolve_pronoun(self, text):
        """ارجاع هوشمند ضمایر به موضوع آخر یا Entity مناسب.

        باگِ قبلی (رفع‌شده): این لیست شاملِ صرفاً واژه‌های *پرسشی*
        («کیه؟»، «چیه؟»، «چیست؟»، «کیست؟»، «چقدره؟») هم می‌شد -- این‌ها
        علامتِ یک *سؤال*اند، نه یک *ضمیر/ارجاع*. نتیجه: با پرسیدنِ
        «اکبر عبدی که بود؟» (که entity_stack را با «اکبر عبدی» پر
        می‌کند) و سپس یک سؤالِ کاملاً مستقل مثلِ «کوروش کبیر کیست؟»،
        چون «کیست؟» در این لیست بود، has_pronoun اشتباهاً True می‌شد و
        از آن‌جا که «اکبر عبدی» در متنِ جدید نبود، تابع رشته‌ی آلوده‌ی
        «اکبر عبدی کوروش کبیر کیست» را برمی‌گرداند -- همان متنی که
        بعداً به IntentEngine/جستجوی حافظه/وب می‌رفت و باعث می‌شد
        سؤالِ کاملاً بی‌ربط با موضوعِ گفتگوی قبلی قاطی شود.

        اصلاح: فقط عبارت‌هایی که واقعاً *جای‌گزینِ* یک Entity می‌شوند
        (اون/این/آن/او/اونو/اینو/همون/همینو/سازنده‌اش/خالقش/مخترعش/
        نویسنده‌اش/قیمتش) به‌عنوانِ ضمیر شمرده می‌شوند. صرفاً داشتنِ یک
        فعلِ پرسشی در انتهایِ جمله (چیست/کیست/...) به‌تنهایی کافی نیست؛
        وگرنه هر پرسشِ نو و مستقل هم اشتباهاً به آخرین Entity وصل می‌شود.
        """
        pronoun_patterns = [
            r'\bاو\b', r'\bآن\b', r'\bاین\b',
            r'\bاون\b', r'\bاینو\b', r'\bاونو\b', r'\bهمون\b', r'\bهمینو\b',
            r'سازنده‌اش', r'خالقش', r'مخترعش', r'نویسنده‌اش', r'قیمتش',
        ]
        has_pronoun = any(re.search(p, text) for p in pronoun_patterns)

        if has_pronoun and self.entity_stack:
            # پیدا کردن بهترین Entity
            for entity in reversed(self.entity_stack):
                if entity and len(entity) > 1:
                    # بررسی اینکه Entity در متن هست یا خیر
                    if entity not in text:
                        return f"{entity} {text}", entity
                    
        return text, None

    def _auto_summarize(self):
        """خلاصه‌سازی خودکار حافظه کوتاه‌مدت"""
        if len(self.short_term) < 10:
            return
        
        messages = list(self.short_term)
        topics = [m.topic for m in messages if m.topic]
        user_messages = [m.content[:100] for m in messages if m.role == "user" and len(m.content) > 10]
        
        if topics:
            main_topics = list(set(topics))
            summary_parts = []
            
            # خلاصه موضوعات
            if main_topics:
                summary_parts.append(f"موضوعات بررسی‌شده: {', '.join(main_topics[:5])}")
            
            # خلاصه سوالات کاربر
            if user_messages:
                questions = [q for q in user_messages if "?" in q or "؟" in q]
                if questions:
                    summary_parts.append(f"سوالات مطرح‌شده: {', '.join(questions[:3])}")
            
            # تشخیص پروژه‌ها
            project_keywords = ["پروژه", "کار می‌کنم", "در حال", "روی"]
            for msg in user_messages:
                for kw in project_keywords:
                    if kw in msg:
                        summary_parts.append(f"پروژه: {msg[:60]}")
                        break
            
            if summary_parts:
                self.conversation_summary = " | ".join(summary_parts)
                self.db.set_profile("memory:summary", self.conversation_summary)

    def save_project(self, project_name, description):
        """ثبت پروژه کاربر"""
        self.projects[project_name] = description
        self.save_long_term("projects", project_name, description)
        self.save_long_term("projects", f"{project_name}:time", datetime.now().strftime("%Y-%m-%d %H:%M"))
        
        # ذخیره در حافظه برداری
        if self.vector_db:
            self.vector_db.add_document(
                f"project_{project_name}",
                f"پروژه: {project_name} - {description}",
                {"type": "project", "name": project_name}
            )

    def get_all_projects(self):
        """دریافت همه پروژه‌های ذخیره‌شده"""
        return self.projects

    def save_interest(self, interest, weight=1):
        """ثبت علاقه کاربر"""
        self.interests[interest] += weight
        self.save_long_term("interests", interest, str(self.interests[interest]))
        
        if self.vector_db:
            self.vector_db.add_document(
                f"interest_{interest}",
                f"علاقه: {interest}",
                {"type": "interest", "name": interest}
            )

    def save_fact(self, fact, confidence: float = 0.75):
        """ثبت حقیقت مهم.

        علاوه بر ذخیره‌ی قبلی (لیستِ ساده + دیتابیس، برای سازگاری با
        بقیه‌ی کدهایی که مستقیماً `self.facts` را می‌خوانند)، حقیقت از
        `MemoryCorrectionEngine` هم رد می‌شود تا اگر با یک حقیقتِ قبلیِ
        هم‌موضوع تناقض داشته باشد، نسخه‌ی قدیمی به‌طور خودکار منسوخ شود.
        """
        self.correction.add(fact, confidence=confidence, category="fact")
        if fact not in self.facts:
            self.facts.append(fact)
            self.save_long_term("facts", hashlib.md5(fact.encode()).hexdigest()[:8], fact)
            
            if self.vector_db:
                self.vector_db.add_document(
                    f"fact_{hashlib.md5(fact.encode()).hexdigest()[:8]}",
                    fact,
                    {"type": "fact"}
                )

    def save_long_term(self, category, key, value):
        """ذخیره در حافظه بلندمدت"""
        full_key = f"memory:{category}:{key}"
        self.db.set_profile(full_key, str(value))

    def load_long_term(self, category, key):
        """بازیابی از حافظه بلندمدت"""
        full_key = f"memory:{category}:{key}"
        return self.db.get_profile(full_key)

    def save_user_goal(self, goal):
        """ثبت هدف کاربر"""
        if goal not in self.user_goals:
            self.user_goals.append(goal)
            self.db.set_profile("memory:goals", json.dumps(self.user_goals))

    def get_relevant_memory(self, query, limit=5):
        """جستجوی معنایی در حافظه"""
        results = []

        # جستجو در حافظه برداری
        if self.vector_db:
            vector_results = self.vector_db.search(query, limit=limit)
            for doc in vector_results:
                distance = doc.get("distance", 0) or 0
                # ChromaDB فاصله‌ی کسینوسی برمی‌گرداند (کمتر = مرتبط‌تر)؛
                # برای یکسان‌سازی با امتیازهای حقایق/پروژه‌ها (که بالاتر
                # یعنی مرتبط‌تر) اینجا به شباهت تبدیل می‌شود، وگرنه
                # مرتب‌سازیِ نزولیِ زیر دقیقاً برعکسِ نتیجه‌ی درست را
                # اول نشان می‌داد.
                similarity = max(0.0, min(1.0, 1.0 - (distance / 2.0)))
                results.append({
                    "type": "vector",
                    "content": doc.get("document", ""),
                    "metadata": doc.get("metadata", {}),
                    "score": similarity
                })

        # کلمات معنادار پرس‌وجو (کلمات خیلی کوتاه/حروف اضافه، و همچنین
        # واژه‌های عمومی/پرسشیِ فاقدِ محتوا مثلِ «بود»/«کیست»/«این» --
        # نگاه کنید به `_GENERIC_STOPWORDS` -- نادیده گرفته می‌شوند تا
        # تطابقِ تصادفیِ یک کلمه‌ی بی‌ربط با یک پروژه/حقیقتِ قدیمی،
        # نتایج را با موضوعی کاملاً غیرمرتبط شلوغ نکند.)
        query_words = [
            w for w in query.split()
            if len(w) >= 3 and w not in _GENERIC_STOPWORDS
        ]

        # جستجو در حقایق — از موتورِ تصحیح استفاده می‌شود تا فقط حقایقِ
        # فعلاً معتبر (منسوخ‌نشده) برگردند؛ اگر یک حقیقت با نسخه‌ی تازه‌تری
        # جایگزین شده باشد (مثلاً تغییرِ اسم/پروژه)، دیگر اینجا ظاهر
        # نمی‌شود — پیش از این، نسخه‌ی قدیمی و جدید هر دو با هم برمی‌گشتند.
        if query_words:
            for item in self.correction.find(query, limit=limit):
                results.append({
                    "type": "fact",
                    "content": item.value,
                    "score": 0.55 + 0.35 * item.confidence,
                })

            # جستجو در پروژه‌ها
            for name, desc in self.projects.items():
                if any(word in desc or word in name for word in query_words):
                    results.append({
                        "type": "project",
                        "content": f"پروژه {name}: {desc}",
                        "score": 0.6
                    })

        # مرتب‌سازی بر اساس امتیاز پیش از برش با limit؛ نسخه‌ی قبلی این
        # مرتب‌سازی را انجام نمی‌داد، پس اگر جستجوی برداری به‌تنهایی به
        # اندازه‌ی limit نتیجه برمی‌گرداند، حقایق/پروژه‌های مرتبط‌تر هرگز
        # دیده نمی‌شدند.
        results.sort(key=lambda r: r.get("score", 0), reverse=True)
        return results[:limit]

    def get_memory_stats(self):
        """آمار حافظه"""
        return {
            "short_term_size": len(self.short_term),
            "projects_count": len(self.projects),
            "interests_count": len(self.interests),
            "facts_count": len(self.facts),
            "reliable_facts_count": len(self.correction.reliable()),
            "superseded_facts_count": len([x for x in self.correction.items if x.superseded]),
            "goals_count": len(self.user_goals),
            "has_summary": bool(self.conversation_summary),
            "message_count": self.message_count
        }

class CacheManager:
    """
    کش نتایج جستجو و محاسبات تکراری
    TTL: زمان انقضا (پیش‌فرض 30 دقیقه)
    """

    def __init__(self, ttl_minutes=30, max_size=200):
        self._cache = {}
        self._timestamps = {}
        self.ttl = ttl_minutes * 60
        self.max_size = max_size
        self.hits = 0
        self.misses = 0

    def _make_key(self, text, tool_name=""):
        """ساخت کلید یکتا"""
        return hashlib.md5(f"{text.strip().lower()[:200]}_{tool_name}".encode()).hexdigest()

    def get(self, text, tool_name=""):
        """بازیابی از کش"""
        key = self._make_key(text, tool_name)
        if key in self._cache:
            if time.time() - self._timestamps[key] < self.ttl:
                self.hits += 1
                return self._cache[key]
            else:
                del self._cache[key]
                del self._timestamps[key]
        self.misses += 1
        return None

    def set(self, text, value, tool_name=""):
        """ذخیره در کش"""
        if len(self._cache) >= self.max_size:
            oldest = min(self._timestamps, key=lambda k: self._timestamps[k])
            del self._cache[oldest]
            del self._timestamps[oldest]
        key = self._make_key(text, tool_name)
        self._cache[key] = value
        self._timestamps[key] = time.time()

    def stats(self):
        total = self.hits + self.misses
        rate = (self.hits / total * 100) if total > 0 else 0
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": f"{rate:.1f}%",
            "size": len(self._cache),
            "max_size": self.max_size
        }

    def clear(self):
        """پاک کردن کش"""
        self._cache.clear()
        self._timestamps.clear()
        self.hits = 0
        self.misses = 0

class VectorDatabase:
    """
    مدیریت حافظه برداری با ChromaDB
    """

    def __init__(self, persist_directory="vector_db"):
        self.persist_directory = persist_directory
        self._client = None
        self._collection = None
        self._embedding_model = None
        
        if CHROMA_AVAILABLE and SENTENCE_TRANSFORMER_AVAILABLE:
            try:
                self._init_chroma()
            except Exception as e:
                print(f"⚠️ خطا در راه‌اندازی ChromaDB: {e}")
                logger.exception("خطا در راه‌اندازی ChromaDB: %s", e)
                self._client = None

    def _init_chroma(self):
        """راه‌اندازی ChromaDB"""
        if not CHROMA_AVAILABLE:
            return False
        
        try:
            self._client = chromadb.PersistentClient(
                path=self.persist_directory,
                settings=ChromaSettings(anonymized_telemetry=False)
            )
            
            # ایجاد یا دریافت collection
            self._collection = self._client.get_or_create_collection(
                name="trx_memory",
                metadata={"hnsw:space": "cosine"}
            )
            
            # بارگذاری مدل تعبیه‌سازی -- از trx_ai.embedding_backend گرفته می‌شود
            # (منبعِ مشترکِ لود؛ همان نمونه‌ای که NLU/conversation_patterns هم
            # استفاده می‌کنند، تا مدل فقط یک‌بار در کلِ برنامه لود شود).
            if SENTENCE_TRANSFORMER_AVAILABLE:
                from . import embedding_backend as _shared_backend
                self._embedding_model = _shared_backend.get_model()
            
            return True
        except Exception as e:
            print(f"⚠️ ChromaDB خطا: {e}")
            logger.exception("ChromaDB خطا: %s", e)
            return False

    def add_document(self, doc_id, text, metadata=None):
        """افزودن سند به حافظه برداری"""
        if not self._collection or not self._embedding_model:
            return False
        
        try:
            embedding = self._embedding_model.encode(text).tolist()
            self._collection.add(
                documents=[text],
                embeddings=[embedding],
                metadatas=[metadata or {}],
                ids=[doc_id]
            )
            return True
        except Exception as e:
            print(f"⚠️ خطا در افزودن سند: {e}")
            logger.exception("خطا در افزودن سند: %s", e)
            return False

    def search(self, query, limit=5):
        """جستجوی معنایی"""
        if not self._collection or not self._embedding_model:
            return []
        
        try:
            query_embedding = self._embedding_model.encode(query).tolist()
            results = self._collection.query(
                query_embeddings=[query_embedding],
                n_results=limit
            )
            
            documents = []
            if results and results.get('documents'):
                for i in range(len(results['documents'][0])):
                    doc = {
                        'document': results['documents'][0][i],
                        'metadata': results['metadatas'][0][i] if results.get('metadatas') else {},
                        'distance': results['distances'][0][i] if results.get('distances') else 0
                    }
                    documents.append(doc)
            
            return documents
        except Exception as e:
            print(f"⚠️ خطا در جستجوی برداری: {e}")
            logger.exception("خطا در جستجوی برداری: %s", e)
            return []

    def delete_document(self, doc_id):
        """حذف سند"""
        if not self._collection:
            return False
        
        try:
            self._collection.delete(ids=[doc_id])
            return True
        except Exception as e:
            logger.debug("حذف سند از حافظه‌ی برداری ناموفق بود: %s", e)
            return False

    def get_stats(self):
        """آمار حافظه برداری"""
        if not self._collection:
            return {"status": "disabled", "count": 0}
        
        try:
            count = self._collection.count()
            return {"status": "active", "count": count}
        except Exception as e:
            logger.warning("دریافت آمار حافظه‌ی برداری ناموفق بود: %s", e)
            return {"status": "error", "count": 0}

class SessionManager:
    """
    مدیریت پروژه‌ها - هر پروژه یک Session جداگانه
    """

    def __init__(self, db):
        self.db = db
        self.active_session = "عمومی"
        self.sessions = {}
        self._load_sessions()

    def _load_sessions(self):
        """بارگذاری Session‌ها"""
        sessions_data = self.db.get_profile_by_prefix("session:")
        for key, value in sessions_data:
            if key.endswith(":name"):
                session_name = key.replace("session:", "").replace(":name", "")
                self.sessions[session_name] = {
                    "name": session_name,
                    "created_at": self.db.get_profile(f"session:{session_name}:created_at") or "",
                    "last_access": self.db.get_profile(f"session:{session_name}:last_access") or ""
                }

    def switch_session(self, session_name):
        """تغییر پروژه/Session"""
        if not session_name:
            return
        
        self.active_session = session_name
        if session_name not in self.sessions:
            self.sessions[session_name] = {
                "name": session_name,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "last_access": datetime.now().strftime("%Y-%m-%d %H:%M")
            }
            self.db.set_profile(f"session:{session_name}:name", session_name)
            self.db.set_profile(f"session:{session_name}:created_at", self.sessions[session_name]["created_at"])
        
        # به‌روزرسانی زمان دسترسی
        self.sessions[session_name]["last_access"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        self.db.set_profile(f"session:{session_name}:last_access", self.sessions[session_name]["last_access"])
        self.db.set_profile("last_session", session_name)

    def save_to_session(self, key, value):
        """ذخیره در Session جاری"""
        full_key = f"session:{self.active_session}:{key}"
        self.db.set_profile(full_key, str(value))

    def load_from_session(self, key):
        """بازیابی از Session جاری"""
        full_key = f"session:{self.active_session}:{key}"
        return self.db.get_profile(full_key)

    def list_sessions(self):
        """لیست همه Session‌ها"""
        return list(self.sessions.keys())

    def delete_session(self, session_name):
        """حذف Session"""
        if session_name in self.sessions:
            del self.sessions[session_name]
            # حذف از دیتابیس
            for key in self.db.get_profile_by_prefix(f"session:{session_name}:"):
                self.db.set_profile(key[0], None)
            if self.active_session == session_name:
                self.active_session = "عمومی"
            return True
        return False
