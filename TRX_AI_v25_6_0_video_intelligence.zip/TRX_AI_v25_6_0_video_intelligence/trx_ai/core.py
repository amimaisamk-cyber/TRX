# -*- coding: utf-8 -*-
"""
هسته‌ی اصلی TRX Enterprise AI: کلاس TRXEnterpriseAI که همه‌ی موتورهای
دیگر را در حلقه‌ی تعامل با کاربر هماهنگ می‌کند.

معماری (پس از ماژولارسازی): این فایل دیگر خودش منطقِ مسیریابی/نمایش/
داشبورد/بازیابی را پیاده نمی‌کند -- هرکدام به یک موتورِ مستقل در
``trx_ai/core_engine/`` منتقل شده‌اند و ``TRXEnterpriseAI`` فقط نقشِ
«ریشه‌ی ترکیب» (composition root) را دارد:

    ┌─────────────────────────────────────────────────────────┐
    │                    TRXEnterpriseAI                       │
    │   (نگه‌داری state مشترک: db, ui, memory, cache, session)  │
    └───────────────┬─────────────────────────────────────────┘
                     │  می‌سازد و نگه می‌دارد
        ┌────────────┼─────────────┬─────────────┬────────────┐
        ▼            ▼             ▼             ▼            ▼
  Presentation  Diagnostics   BackupManager  AgentBridge  ToolRouter
  (نمایش/صدا)   (داشبورد/     (پشتیبان/      (حلقه‌ی      (مسیریابیِ
                 متریک)        بازیابی)       عامل)        نیت→ابزار)
                                                                │
                                                                ▼
                                                          TurnProcessor
                                                       (چرخه‌ی یک نوبت:
                                                        متن/عکس/فایل)

هر متدِ عمومی/نیمه‌عمومیِ قبلیِ این کلاس (``_process_turn``،
``_present``، ``_execute_route`` و ...) همچنان روی خودِ
``TRXEnterpriseAI`` در دسترس است -- اما بدنه‌اش فقط یک تفویضِ یک‌خطی
به موتورِ مسئول است. این یعنی هیچ کدِ بیرونی (``gui_app.py``،
``webserver.py``، تست‌ها) نیازی به تغییر ندارد، درحالی‌که هر موتور
اکنون در فایلِ خودش، مستقل و قابلِ‌تستِ جداگانه است.
"""

from __future__ import annotations

import asyncio
import os
import time
import traceback
from collections import deque
from datetime import datetime

import aiohttp

from .config import OS_FILES_DIR, OS_PLUGINS_DIR
from .conversation_patterns import ConversationPatternEngine
from .database import DatabaseManager
from .dependencies import CHROMA_AVAILABLE, PSUTIL_AVAILABLE

if PSUTIL_AVAILABLE:
    import psutil

from .expenses import ExpenseManager
from .nlu import user_state as user_state_engine
from .interpreter import PersianPythonInterpreter
from .logging_config import get_logger
from .runtime_intelligence import RuntimeIntelligence
from .medical import MedicalAIEngine
from .memory_store import CacheManager, MemoryEngine, SessionManager, VectorDatabase
from .plugins import PluginSystem
from .tasks import TaskManager
from .vision import ImageEngine
from .ui import UIEngine

from .core_engine import (
    AgentBridge,
    BackupManager,
    DiagnosticsPanel,
    PresentationEngine,
    ToolRouter,
    TraceLog,
    TurnProcessor,
    text_extraction,
)

logger = get_logger(__name__)

# ==========================================
#   تنظیماتِ سراسریِ شبکه (ارتقاء پایداری)
# ------------------------------------------
# قبلاً `aiohttp.ClientSession()` بدونِ هیچ Timeout ساخته می‌شد. پیش‌فرضِ
# خودِ aiohttp برای این حالت «بدونِ محدودیتِ زمانی» است؛ یعنی اگر یک
# سرویسِ بیرونی (آب‌وهوا/ترجمه/ویکی‌پدیا/DuckDuckGo/...) هرگز پاسخ ندهد
# یا اتصال به‌طرزی «نیمه‌باز» گیر کند، همان یک نوبتِ گفتگو (و در نسخه‌ی
# ترمینالی، کلِ حلقه‌ی `await`) برای همیشه معلق می‌ماند -- نه خطا، نه
# timeout، فقط سکوتِ ابدی. این عملاً یک نقطه‌ی شکستِ پایداری در تمامِ
# مسیرهایی‌ست که از `self.session` استفاده می‌کنند. یک Timeoutِ منطقی
# (نه خیلی کوتاه که به سرویس‌های کندتر مثلِ ویکی‌پدیا/DDG آسیب بزند، نه
# خیلی بلند که کاربر را عملاً بی‌پاسخ نگه دارد) اینجا یک‌بار تعریف و در
# هر دو مسیرِ ساختِ session (ترمینال/GUI) استفاده می‌شود.
# ==========================================
HTTP_TOTAL_TIMEOUT_SECONDS = 20
HTTP_CONNECT_TIMEOUT_SECONDS = 8


def _build_http_timeout() -> aiohttp.ClientTimeout:
    """Timeoutِ پیش‌فرضِ سراسریِ کلِ درخواست‌های خروجیِ برنامه."""
    return aiohttp.ClientTimeout(
        total=HTTP_TOTAL_TIMEOUT_SECONDS,
        connect=HTTP_CONNECT_TIMEOUT_SECONDS,
    )


class GenerationUnavailableError(RuntimeError):
    """هیچ منبعِ رایگان (ویکی‌پدیا/DuckDuckGo/الگویِ همدلانه) پاسخی نداد — قابلِ گرفتنِ جداگانه پایین‌تر.

    این پروژه دیگر به هیچ APIِ مولدِ خارجی (Gemini یا مشابه) وصل نمی‌شود؛
    هر «پاسخِ هوشمند» یا از موتورِ کاملاً محلی می‌آید یا از منابعِ رایگانِ
    وب (ویکی‌پدیا/DuckDuckGo) که از قبل بدونِ کلید در دسترس بودند.
    """


async def async_input(prompt_text=""):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: input(prompt_text))


# ==========================================
#   کلاس اصلی TRX Enterprise AI v20
# ==========================================

class TRXEnterpriseAI:
    # ==========================================
    #   ثابت‌های سطحِ کلاس (ارتقاء نگهداری‌پذیری)
    # ------------------------------------------
    # عبارت‌های دستوریِ خام که چند جای مختلفِ منطقِ نوبت (اکنون در
    # ``core_engine/turn_processor.py``) به آن‌ها نیاز دارند. جمع‌کردنشان
    # اینجا هیچ رفتاری را تغییر نمی‌دهد، اما هر تغییرِ آینده (مثلاً
    # افزودنِ یک کلمه‌ی مترادف برایِ خروج) را به یک نقطه محدود می‌کند.
    # ==========================================
    EXIT_COMMANDS = ("خروج", "exit", "quit")
    RESTORE_CONFIRM_WORDS = ("بله", "آره", "تایید", "تأیید", "yes", "y")
    SECRET_CONSOLE_TRIGGERS = ("درِ مخفی", "در مخفی", "trx debug")

    def __init__(self):
        self.db = DatabaseManager()
        self.ui = UIEngine()
        # آماده‌سازیِ اندازه‌گیریِ CPU (بدونِ بلاک‌کردن): فراخوانیِ اول به
        # psutil.Process.cpu_percent فقط یک نقطه‌ی مرجع ثبت می‌کند. اگر این
        # «فراخوانیِ گرم‌کننده» انجام نشود، مجبوریم در دیباگِ داشبورد از
        # cpu_percent(interval=0.2) استفاده کنیم که یعنی هر بار دستورِ
        # «داشبورد» کلِ event loop را ۲۰۰ میلی‌ثانیه بلاک می‌کند (چون آن
        # متد sync است و از دلِ یک نوبتِ async صدا زده می‌شود). با این
        # فراخوانیِ اولیه، بعداً می‌توانیم از interval=None (غیربلاک‌کننده)
        # استفاده کنیم (نگاه کنید به ``core_engine/diagnostics.py``).
        if PSUTIL_AVAILABLE:
            try:
                psutil.Process(os.getpid()).cpu_percent(interval=None)
            except Exception:  # noqa: BLE001 - صرفاً یک بهینه‌سازیِ غیربحرانی است
                pass
        # لایه‌ی Runtime Intelligence v25: ورودی/context/کیفیت را مستقل از API کنترل می‌کند.
        self.runtime = RuntimeIntelligence(max_input_chars=12000, history_items=12, repeat_window_seconds=20)
        self.session = None
        self.user_name = "کاربر محترم"
        self.personality = "رسمی"

        # موتورهای جدید
        self.vector_db = VectorDatabase() if CHROMA_AVAILABLE else None
        self.memory = MemoryEngine(self.db, self.vector_db)
        # موتور یادگیری الگوی مکالمه: از چند نوبتِ واقعی، نوع گفتگو، حال‌وهوا،
        # موضوع‌ها و راهبرد مناسب پاسخ را استخراج و برای نوبت‌های بعدی بازیابی می‌کند.
        self.conversation_patterns = ConversationPatternEngine(self.db)
        # وضعیتِ *جاریِ* کاربر (خسته/کلافه/گیج/...) -- محورِ کاملاً جدا از
        # نیت و از حافظه‌ی دائمی؛ با TTL کوتاه منقضی می‌شود (بخشِ ۱۹ سند).
        self.user_state_memory = user_state_engine.UserStateSessionMemory()
        self.cache = CacheManager(ttl_minutes=30, max_size=200)
        self.session_mgr = SessionManager(self.db)
        self.plugin_system = PluginSystem(OS_PLUGINS_DIR)
        self.task_manager = TaskManager(self.db)
        self.expense_manager = ExpenseManager(self.db)

        # موتور پزشکی
        self.medical_engine = MedicalAIEngine()

        # موتورِ سراسریِ تصویر (نه فقط پزشکی): ذخیره/OCR محلی/بهبودِ کیفیت/
        # توصیفِ محلی با Vision Super. هیچ APIِ خارجی/کلیدی لازم ندارد --
        # نگاه کنید به vision.py.
        self.image_engine = ImageEngine(files_dir=OS_FILES_DIR)
        # مسیرِ آخرین تصویر/فایلِ آپلودشده در همین جلسه -- فقط برای اینکه
        # ابزارِ «vision»یِ حلقه‌ی عامل (`trx_ai/agent`) بداند رویِ کدام
        # تصویر کار کند؛ رفتارِ مسیرهای موجودِ آپلود را تغییر نمی‌دهد.
        self._last_image_path: str | None = None

        # مفسر فارسی
        self.persian_interpreter = PersianPythonInterpreter()
        self._persian_code_buffer = ""

        # Task Queue
        self.task_queue = deque()
        self.running_tasks = {}

        # مدها
        self.modes = {
            "calculator": False,
            "code_analyzer": False,
            "translator": False,
            "persian_interpreter": False,
            "web_search": False
        }
        self.translation_direction = "auto"

        # شمارش استفاده‌ی اخیر از هر ابزار در همین نشست؛ به ToolScorer
        # به‌عنوان context واقعی داده می‌شود (نسخه‌ی قبلی همیشه None
        # می‌فرستاد و این بخش از امتیازدهی کاملاً بی‌اثر بود).
        self.tool_usage_history: dict = {}

        # آمار
        self.stats = {
            "total_requests": 0,
            "cache_hits": 0,
            "api_calls": 0,
            "errors": 0
        }
        self._boot_time = time.time()
        self._last_joke = None  # آخرین جوکِ گفته‌شده، برای پرهیز از تکرارِ فوری
        self._response_times = deque(maxlen=100)  # آخرین زمان‌های پاسخ (میلی‌ثانیه) برای داشبورد
        self._error_log = deque(maxlen=30)  # آخرین خطاها برای داشبورد (پیام + زمان)
        self._response_lang = "fa"  # زبانِ پاسخِ نوبتِ جاری (برای قابلیتِ چندزبانگی)

        # آیا یک درخواستِ «بازیابی» منتظرِ تأییدِ صریحِ کاربر است؟ چون
        # overwrite=True داده‌های فعلیِ tasks/expenses/history را
        # بی‌سروصدا با محتوایِ فایلِ پشتیبان جایگزین می‌کند، یک عملِ
        # به‌همین‌اندازه مخرب باید پشتِ یک تأییدِ صریح باشد، نه فقط با
        # گفتنِ یک کلمه («بازیابی») بلافاصله همه‌چیز را پاک/جایگزین کند.
        self._pending_restore = False

        # وقتی کاربر بگوید «نه، منظورم این نبود»، این فیلد متنِ همان
        # پیامِ قبلی را نگه می‌دارد تا پاسخِ بعدیِ کاربر (توضیحِ نیتِ
        # واقعی) به آن نسبت داده و در حلقه‌یِ بازخوردِ IntentEngine ثبت
        # شود (trx_ai/nlu/feedback.py).
        self._pending_correction: str | None = None

        # وقتی امتیازِ دو ابزارِ نامزد به‌قدرِ کافی به هم نزدیک باشد
        # (``nlu/disambiguator.should_ask_followup``)، به‌جایِ حدسِ
        # کورکورانه یک سؤالِ کوتاه پرسیده می‌شود و این فیلد متنِ اصلی +
        # دو نامزد را نگه می‌دارد تا پیامِ *بعدیِ* کاربر به‌عنوانِ پاسخِ
        # همان سؤال تفسیر شود، نه یک پیامِ کاملاً تازه (همان الگویِ
        # ``_pending_correction`` بالا، برایِ ابهامِ نیت به‌جایِ بازخوردِ
        # نیتِ اشتباه). نگاه کنید به ``core_engine/tool_router.py`` (جایی
        # که ساخته می‌شود) و ``core_engine/turn_processor.py`` (جایی که
        # مصرف می‌شود).
        self._pending_disambiguation: dict | None = None

        # تابعِ دریافتِ ورودیِ تعاملی (برای صدا/نامِ اولیه/مدِ مفسر). پیش‌فرض
        # همان async_input ترمینالی است؛ رابطِ گرافیکی این را با نسخه‌ای
        # غیربلاک‌کننده جایگزین می‌کند (چون در GUI منتظرِ input() ترمینال
        # ماندن یعنی برنامه برای همیشه فریز شود).
        self._input_fn = async_input
        self._is_gui = False
        self._user_name_preset = False  # GUI این را True می‌کند وقتی از قبل نام را با دیالوگ گرفته

        # ==========================================
        #   لایه‌ی مشاهده‌پذیری (core_engine/trace.py) -- اولویتِ ۱ سندِ
        #   ارتقایِ نسلِ بعد. ``current_trace`` شیءِ trace همینِ نوبتِ
        #   جاری است (در ابتدایِ ``TurnProcessor.process_turn`` ساخته
        #   می‌شود)؛ ``trace_log`` تاریخچه‌ی محدودِ نوبت‌هایِ قبلی است
        #   (برایِ دستورِ «ردیابی»). کاملاً additive: نبودِ این دو
        #   attribute هیچ مسیرِ قدیمی‌ای را نمی‌شکند چون هر مصرف‌کننده
        #   با ``getattr(ai, "current_trace", None)`` به آن دسترسی دارد.
        # ==========================================
        self.trace_log = TraceLog(maxlen=200)
        self.current_trace = None

        # ==========================================
        #   موتورهای تفکیک‌شده (composition root)
        # ------------------------------------------
        # هرکدام یک مسئولیتِ واحد دارند و همه از طریقِ همینِ نمونه
        # (self) به state مشترک دسترسی دارند -- نگاه کنید به
        # ``trx_ai/core_engine/__init__.py`` برایِ نقشه‌ی کامل.
        # ==========================================
        self._presentation = PresentationEngine(self)
        self._diagnostics = DiagnosticsPanel(self)
        self._backup = BackupManager(self)
        self._agent_bridge = AgentBridge(self)
        self._router = ToolRouter(self)
        self._turns = TurnProcessor(self)

    async def init_for_gui(self, ui_engine, user_name: str = None):
        """
        معادلِ ابتدای start_loop، اما برایِ رابطِ گرافیکی: به‌جایِ
        `async with aiohttp.ClientSession()` (که با پایانِ حلقه بسته
        می‌شود)، یک session باز نگه می‌دارد تا کلِ عمرِ برنامه‌ی GUI
        زنده بماند (باید در انتها با `shutdown_gui()` بسته شود).
        """
        self.ui = ui_engine
        self._is_gui = True

        async def _gui_input_fn(prompt: str = "") -> str:
            """
            جایگزینِ async_input برایِ GUI: هرگز بلاک نمی‌کند.
            - برایِ پرامپتِ انتخابِ صدا: مقدارِ از‌پیش‌تنظیم‌شده (چک‌باکسِ
              GUI) را برمی‌گرداند.
            - برایِ هر پرامپتِ دیگری (مثلاً اگر به‌هردلیل نامِ کاربر از
              قبل تنظیم نشده بود): رشته‌ی خالی برمی‌گرداند تا کدِ
              فراخوان (که همیشه یک fallback معقول دارد، مثلِ «کاربر
              محترم») به‌جایِ فریز‌کردن، مقدارِ پیش‌فرض را استفاده کند.
            """
            return getattr(ui_engine, "auto_voice_choice", "")

        self._input_fn = _gui_input_fn

        if user_name:
            self.user_name = user_name
            self._user_name_preset = True

        self.session = aiohttp.ClientSession(timeout=_build_http_timeout())
        await self._load_profile()
        self.ui.show_header(self.user_name, self.personality, self.session_mgr.active_session)
        self.ui.show_guide()

    async def shutdown_gui(self):
        """بستنِ منظمِ session هنگامِ خروج از رابطِ گرافیکی."""
        if self.session and not self.session.closed:
            await self.session.close()

    async def start_loop(self):
        """حلقه اصلی تعامل با کاربر"""
        async with aiohttp.ClientSession(timeout=_build_http_timeout()) as session:
            self.session = session
            await self._load_profile()
            self.ui.show_header(self.user_name, self.personality, self.session_mgr.active_session)
            self.ui.show_guide()

            while True:
                try:
                    user_input = await async_input("\n👤 شما: ")
                    should_continue = await self._process_turn(user_input)
                    if not should_continue:
                        break

                except KeyboardInterrupt:
                    print("\n👋 برنامه متوقف شد.")
                    break
                except Exception as e:
                    print(f"❌ خطا: {e}")
                    logger.exception("خطای پردازش‌نشده در حلقه‌ی اصلی: %s", e)
                    traceback.print_exc()
                    self.stats["errors"] += 1
                    self._error_log.append({
                        "time": datetime.now().strftime("%H:%M:%S"),
                        "message": str(e)[:200],
                    })

    # ==========================================
    #   تفویض‌های نازک به موتورهای تفکیک‌شده
    # ------------------------------------------
    # از این‌جا به بعد، هر متد فقط یک خط دارد: صدازدنِ موتورِ مسئول.
    # امضایِ هرکدام دقیقاً همانِ قبل مانده تا نه کدِ بیرونی
    # (``gui_app.py``/``webserver.py``) و نه تست‌ها نیاز به تغییر
    # داشته باشند.
    # ==========================================

    # --- چرخه‌ی نوبت (turn_processor.py) ---
    async def _process_turn(self, user_input: str) -> bool:
        return await self._turns.process_turn(user_input)

    async def _process_image_turn(self, raw_bytes: bytes, mime_type: str, caption: str = "") -> None:
        return await self._turns.process_image_turn(raw_bytes, mime_type, caption)

    async def _process_file_turn(self, raw_bytes: bytes, filename: str, caption: str = "") -> None:
        return await self._turns.process_file_turn(raw_bytes, filename, caption)

    async def _run_persian_interpreter_mode(self):
        return await self._turns.run_persian_interpreter_mode()

    async def _search_memory(self, query):
        return await self._turns.search_memory(query)

    def _medical_session_key(self) -> str:
        return self._turns.medical_session_key()

    async def _handle_medical_query(self, text: str) -> dict:
        return await self._turns.handle_medical_query(text)

    def _finalize(self, query: str, response: str, start_time: float, intent: str, confidence: float):
        return self._turns.finalize(query, response, start_time, intent, confidence)

    async def _load_profile(self):
        return await self._turns.load_profile()

    # --- مسیریابیِ ابزارها (tool_router.py) ---
    async def _execute_route(self, intent, confidence, original_text):
        return await self._router.execute(intent, confidence, original_text)

    # --- استخراجِ متنِ محض (text_extraction.py) ---
    @staticmethod
    def _extract_city_name(text: str) -> str:
        return text_extraction.extract_city_name(text)

    @staticmethod
    def _extract_search_subject(text: str) -> str:
        return text_extraction.extract_search_subject(text)

    # --- نمایش/صدا (presentation.py) ---
    async def _present(self, text: str, title: str = "", style: str = "cyan"):
        return await self._presentation.present(text, title, style)

    async def _handle_voice_option(self, text):
        return await self._presentation.handle_voice_option(text)

    def _get_personality_prefix(self):
        return self._presentation.get_personality_prefix()

    def _get_emoji(self, text, intent=""):
        return self._presentation.get_emoji(text, intent)

    # --- حلقه‌ی عامل (agent_bridge.py) ---
    @classmethod
    def _extract_agent_goal(cls, user_input: str) -> str | None:
        return AgentBridge.extract_goal(user_input)

    def _get_agent_registry(self):
        return self._agent_bridge.get_registry()

    async def _handle_agent_task(self, goal: str) -> None:
        return await self._agent_bridge.handle_task(goal)

    # --- تشخیص/گزارش‌گیری (diagnostics.py) ---
    def _show_dashboard(self):
        return self._diagnostics.show_dashboard()

    def _show_secret_console(self):
        return self._diagnostics.show_secret_console()

    def _show_metrics(self):
        return self._diagnostics.show_metrics()

    def _show_history_table(self):
        return self._diagnostics.show_history_table()

    def _show_projects(self):
        return self._diagnostics.show_projects()

    def _show_last_trace(self, n: int = 1):
        return self._diagnostics.show_last_trace(n)

    def export_history_to_html(self, file_path="trx_ai_v20_report.html"):
        return self._diagnostics.export_history_to_html(file_path)

    # --- پشتیبان‌گیری/بازیابی (backup_manager.py) ---
    def _create_backup(self) -> str:
        return self._backup.create_backup()

    def _find_latest_backup(self):
        return self._backup.find_latest_backup()

    def _prompt_restore_confirmation(self) -> str:
        return self._backup.prompt_restore_confirmation()

    def _do_restore_latest_backup(self) -> str:
        return self._backup.do_restore_latest_backup()
