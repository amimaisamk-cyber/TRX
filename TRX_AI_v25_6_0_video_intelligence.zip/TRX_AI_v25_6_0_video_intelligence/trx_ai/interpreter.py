# -*- coding: utf-8 -*-
"""
مفسر پایتون فارسی: ترجمه‌ی دستورات نوشته‌شده با کلیدواژه‌های فارسی به
کد پایتون معتبر و اجرای آن، همراه با اصلاح خودکار خطاهای رایج نحوی.

⚠️ توجه امنیتی (بدون تغییر رفتار):
    این کلاس به‌طور ذاتی کد پایتون تولیدشده را با exec() اجرا می‌کند؛
    این رفتار همان قابلیت اصلی «مفسر فارسی» است و عمداً حفظ شده است.
    این ابزار باید فقط در محیط قابل‌اعتماد (دستگاه شخصی کاربر) استفاده
    شود، نه به‌عنوان سرویس پذیرای کد از کاربران ناشناس.
"""

from __future__ import annotations

import ast
import difflib
import math
import random
import re
import time

from .logging_config import get_logger
from .security import (
    ExecutionTimeout,
    find_dangerous_pattern,
    restricted_builtins,
    time_limited_execution,
)

logger = get_logger(__name__)


class PersianPythonInterpreter:
    # حداکثر زمانِ مجاز برای اجرای یک بلاکِ کد (ثانیه). بدونِ این محدودیت،
    # یک اشتباهِ ساده مثلِ «تاوقتی درست:» (while True:) بدونِ break کلِ
    # برنامه را برای همیشه فریز می‌کرد و تنها راهِ نجات، بستنِ کاملِ
    # برنامه بود.
    EXECUTION_TIMEOUT_SECONDS = 5

    def __init__(self):
        self.translations = {
            "چاپ": "print", "بگو": "print", "نمایش": "print",
            "بپرس": "input", "اگر": "if", "اگه": "if",
            "وگرنه": "else", "وگرنه_اگر": "elif",
            "برای": "for", "در": "in", "تاوقتی": "while",
            "تعداد": "range", "تابع": "def", "برگردان": "return",
            "و": "and", "یا": "or", "نه": "not",
            "درست": "True", "غلط": "False",
            "برابر": "==", "نابرابر": "!=",
            "عدد": "int", "اعشاری": "float", "متن": "str",
            "ریشه": "math.sqrt", "تصادفی": "random.randint",
            "ادامه": "continue", "توقف": "break", "عبور": "pass",
            "کلاس": "class", "خود": "self", "حذف": "del",
            "هیچ": "None", "است": "is", "نیست": "is not",
            "درون": "in", "نیست_در": "not in",
            "سراسری": "global", "غیرمحلی": "nonlocal",
            "تلاش": "try", "بجز": "except", "بالاخره": "finally",
            "وگرنه_تلاش": "else", "ایجاد_خطا": "raise",
            "تأیید": "assert", "با": "with", "به_عنوان": "as",
            "واردکن": "import", "از": "from", "لامبدا": "lambda",
            "بده": "yield", "ناهمگام": "async", "منتظر": "await",
            "تطبیق": "match", "حالت": "case",
            "لیست": "list", "تاپل": "tuple", "مجموعه": "set",
            "دیکشنری": "dict", "بولی": "bool", "بایت": "bytes",
            "طول": "len", "نوع": "type", "جمع": "sum",
            "حداکثر": "max", "حداقل": "min", "مرتب": "sorted",
            "برعکس": "reversed", "فهرست": "enumerate", "زیپ": "zip",
            "نگاشت": "map", "فیلتر": "filter",
            "همه": "all", "هرکدام": "any", "باز": "open",
            "کمک": "help", "شناسه": "id", "هش": "hash",
            "قالب": "format", "ارزیابی": "eval", "اجرا": "exec",
            "کامپایل": "compile",
            "افزودن": "append", "درج": "insert", "حذف_مورد": "remove",
            "بردار": "pop", "پاک": "clear", "کپی": "copy",
            "شمارش": "count", "مرتب_کن": "sort", "وارونه": "reverse",
            "کلیدها": "keys", "مقادیر": "values", "آیتمها": "items",
            "دریافت": "get", "بروزرسانی": "update",
            "جداکن": "split", "بچسبان": "join", "جایگزین": "replace",
            "شروع_میشود": "startswith", "پایان_میشود": "endswith",
            "پیداکن": "find", "حروف_کوچک": "lower",
            "حروف_بزرگ": "upper", "عنوان": "title",
            "حذف_فاصله": "strip",
            "قدرمطلق": "abs", "گرد": "round", "توان": "pow",
            "سینوس": "math.sin", "کسینوس": "math.cos",
            "تانژانت": "math.tan", "پی": "math.pi",
            "عدد_نپر": "math.e", "سقف": "math.ceil",
            "کف": "math.floor",
            "انتخاب": "random.choice", "درهم": "random.shuffle",
            "تصادفی_اعشاری": "random.random",
        }
        self.auto_fix_enabled = True
        self.output_capture = []

    def validate_input(self, code):
        if not code.strip():
            print("❌ کدی وارد نشده")
            return False
        return True

    def suggest_word(self, word):
        result = difflib.get_close_matches(
            word, self.translations.keys(), n=1, cutoff=0.70
        )
        return result[0] if result else None

    def fix_wrong_commands(self, code, auto_confirm=False):
        """اصلاح دستورات اشتباه با تأیید خودکار"""
        lines = code.split("\n")
        new_lines = []
        for line in lines:
            tokens = re.findall(r'[A-Za-zآ-ی_][A-Za-zآ-ی0-9_]*', line)
            for token in tokens:
                if token in self.translations:
                    continue
                suggestion = self.suggest_word(token)
                if suggestion:
                    if not auto_confirm:
                        print(f"\n⚠ دستور ناشناخته: '{token}' → آیا منظور '{suggestion}' است؟")
                        answer = input("(بله/خیر/همیشه): ").strip()
                        if answer == "همیشه":
                            auto_confirm = True
                            answer = "بله"
                    else:
                        answer = "بله"
                    
                    if answer == "بله":
                        line = re.sub(rf'\b{token}\b', suggestion, line)
            new_lines.append(line)
        return "\n".join(new_lines), auto_confirm

    @staticmethod
    def _strip_comment(line: str) -> str:
        """
        هر چیزِ بعدِ یک «#» را (تا انتهایِ خط) حذف می‌کند — مگر آن‌که آن
        «#» داخلِ یک رشته‌ی کوتیشن‌دار باشد (مثلاً چاپ("قیمت #۱")).
        قبلاً هیچ پشتیبانیِ کامنتی وجود نداشت: خطِ «# توضیح» یا حتی یک
        کامنت در انتهایِ یک خطِ کد، کلمه‌به‌کلمه توکنایز و ترجمه می‌شد
        (مثلاً «است» داخلِ متنِ کامنت به «is» تبدیل می‌شد) و کدِ پایتونیِ
        نامعتبر تولید می‌کرد — یعنی همان یک خط کامنت، کلِ اجرا را با
        SyntaxError می‌ترکاند.
        """
        result = []
        in_quote = None
        for ch in line:
            if in_quote:
                result.append(ch)
                if ch == in_quote:
                    in_quote = None
                continue
            if ch in ('"', "'"):
                in_quote = ch
                result.append(ch)
                continue
            if ch == "#":
                break
            result.append(ch)
        return "".join(result)

    def translate(self, code):
        lines = code.split("\n")
        final_code = []
        # ردیابیِ واقعیِ تورفتگیِ کاربر (پشته‌ای از عرضِ فاصله‌هایِ ابتدایِ
        # هر خط) — دقیقاً همان کاری که خودِ پایتون برایِ تشخیصِ بلاک‌ها
        # انجام می‌دهد.
        #
        # نسخه‌ی قبلی اصلاً به فاصله‌هایِ واقعیِ کاربر نگاه نمی‌کرد؛ فقط
        # با دیدنِ «:» در پایانِ یک خط عمق را زیاد می‌کرد و فقط با یک خطِ
        # خالی، «وگرنه»، یا یک دستورِ پایان‌دهنده (برگردان/توقف/ادامه/
        # عبور) آن را کم می‌کرد. نتیجه: خطی که کاربر با فاصله‌گذاری
        # صریحاً بیرونِ یک if/for نشان داده بود (مثلاً «چاپ("B")» بدونِ
        # تورفتگی، درست بعد از یک بلاکِ تورفته)، برایِ همیشه داخلِ همان
        # بلاک می‌ماند — چون هیچ‌کدام از آن سه شرط برایش برقرار نبود؛
        # برای بلاک‌هایِ تودرتو (اگر → برای → ...) این مشکل حتی بدتر هم
        # می‌شد. الان عمق مستقیماً از رویِ فاصله‌یِ واقعیِ هر خط تعیین
        # می‌شود: اگر تورفتگیِ خط از بالایِ پشته کمتر باشد، به همان تعداد
        # سطح dedent می‌کنیم؛ اگر بیشتر باشد، یک سطحِ جدید push می‌شود.
        indent_stack = [0]

        for raw_line in lines:
            raw_line = self._strip_comment(raw_line)
            stripped = raw_line.strip()
            if not stripped:
                # خطِ خالی یا خطی که فقط کامنت بود (بعدِ حذفِ کامنت خالی
                # شد): فقط برایِ هم‌ترازیِ شماره‌خط با اسکریپتِ اصلی
                # (برایِ اصلاحِ خودکار در smart_execute) در خروجی هم
                # خالی نوشته می‌شود؛ به تورفتگی دست نمی‌زند — دقیقاً
                # همان‌طور که خودِ پایتون هم به تورفتگیِ خطِ کامنت اهمیتی
                # نمی‌دهد.
                final_code.append("")
                continue

            leading_ws_len = len(raw_line) - len(raw_line.lstrip(" \t"))
            line = stripped

            while len(indent_stack) > 1 and leading_ws_len < indent_stack[-1]:
                indent_stack.pop()
            if leading_ws_len > indent_stack[-1]:
                indent_stack.append(leading_ws_len)

            tokens = re.findall(
                r'"[^"]*"|\'[^\']*\'|==|!=|<=|>=|'
                r'[A-Za-zآ-ی_][A-Za-zآ-ی0-9_]*|'
                r'[():=+\-*/<>.,\[\]]|\d+', line
            )
            translated_tokens = []
            for token in tokens:
                if token.startswith('"') or token.startswith("'"):
                    translated_tokens.append(token)
                    continue
                translated_tokens.append(self.translations.get(token, token))
            if (len(translated_tokens) >= 3 and translated_tokens[0] == "for"
                    and translated_tokens[2] == "range"):
                translated_tokens.insert(2, "in")
            new_line = ""
            for i, token in enumerate(translated_tokens):
                if token in [")", ":", ",", ".", "]"]:
                    new_line += token
                elif token == "[":
                    new_line += token
                elif i > 0 and translated_tokens[i - 1] == "(":
                    new_line += token
                else:
                    new_line += (" " if new_line else "") + token

            depth = len(indent_stack) - 1
            final_code.append("    " * depth + new_line)

        return "\n".join(final_code)

    def analyze_error(self, error, lines):
        """تحلیل خطا با پیشنهاد اصلاح"""
        error_text = str(error)
        line_number = getattr(error, "lineno", None)
        if not line_number or line_number > len(lines):
            return None
        
        bad_line = lines[line_number - 1]
        
        if "expected ':'" in error_text:
            return {"message": "دو نقطه فراموش شده", "line": line_number, "new": bad_line + ":", "type": "syntax"}
        
        if "cannot assign" in error_text or "Maybe you meant" in error_text:
            fixed = re.sub(r'(?<![<>!])=(?!=)', '==', bad_line)
            return {"message": "احتمالاً == لازم است", "line": line_number, "new": fixed, "type": "syntax"}
        
        if "was never closed" in error_text:
            if "(" in bad_line and ")" not in bad_line:
                return {"message": "پرانتز بسته نشده", "line": line_number, "new": bad_line + ")", "type": "syntax"}
            if "[" in bad_line and "]" not in bad_line:
                return {"message": "کروشه بسته نشده", "line": line_number, "new": bad_line + "]", "type": "syntax"}
        
        if "expected an indented block" in error_text:
            # نکته: در پایتونِ ۳٫۱۰+ (که ast.parse این پروژه هم رویش
            # اجرا می‌شود)، lineno برایِ این خطا مستقیماً به همان خطی
            # اشاره می‌کند که باید تورفته می‌شد (یعنی خودِ bad_line که
            # بالای همین تابع محاسبه شده) — نه به خطِ بعد از آن. نسخه‌ی
            # قبلی فرض کرده بود lineno به خطِ «اگر/برای» اشاره دارد و
            # خطِ *بعدی* (lines[line_number]) را تورفته می‌کرد؛ نتیجه:
            # وقتی خطِ فاقدِ تورفتگی آخرین خطِ اسکریپت بود
            # (line_number == len(lines))، شرطِ «line_number < len(lines)»
            # هیچ‌وقت برقرار نمی‌شد و اصلاحِ خودکار اصلاً اجرا نمی‌شد؛ و
            # حتی وقتی برقرار می‌شد، خطِ اشتباهی را تورفته می‌کرد.
            return {"message": "تورفتگی فراموش شده", "line": line_number, "new": "    " + bad_line, "type": "indentation"}
        
        return None

    def smart_execute(self, code, auto_confirm=False):
        """اجرای هوشمند کد با اصلاح خودکار"""
        if not self.validate_input(code):
            return "❌ کدی وارد نشده"
        
        code, auto_confirm = self.fix_wrong_commands(code, auto_confirm)
        lines = code.split("\n")
        max_attempts = 20
        output_log = []
        
        for attempt in range(max_attempts):
            code_text = "\n".join(lines)
            python_code = self.translate(code_text)
            output_log.append(f"🟡 کد ترجمه شده (تلاش {attempt + 1}):\n{python_code}")
            
            try:
                ast.parse(python_code)

                danger = find_dangerous_pattern(python_code)
                if danger:
                    output_log.append(f"🛑 اجرا متوقف شد: {danger}")
                    return "\n".join(output_log)

                with time_limited_execution(self.EXECUTION_TIMEOUT_SECONDS):
                    # __builtins__ محدودشده (به‌جایِ __builtins__ کاملِ
                    # پایتون): لایه‌ی دومِ دفاعی، مستقل از
                    # find_dangerous_pattern — نگاه کنید به کامنتِ
                    # restricted_builtins در security.py.
                    exec(python_code, {"__builtins__": restricted_builtins(), "math": math,
                                       "random": random, "time": time})

                output_log.append("✅ اجرا با موفقیت انجام شد!")
                return "\n".join(output_log)
            except ExecutionTimeout:
                output_log.append(
                    f"\n⏱️ اجرا بیش از {self.EXECUTION_TIMEOUT_SECONDS} ثانیه طول کشید و متوقف شد "
                    f"(احتمالاً یک حلقه‌ی بی‌پایان — مثلاً «تاوقتی» بدون «توقف»)."
                )
                return "\n".join(output_log)
            except Exception as error:
                output_log.append(f"\n❌ خطا: {error}")
                fix = self.analyze_error(error, lines)
                if not fix:
                    output_log.append("⛔ اصلاح خودکار ممکن نیست")
                    return "\n".join(output_log)
                
                output_log.append(f"🔍 مشکل: {fix['message']} | خط {fix['line']}")
                
                if not auto_confirm:
                    answer = input("❓ اصلاح خودکار انجام شود؟ (بله/خیر/همیشه): ").strip()
                    if answer == "همیشه":
                        auto_confirm = True
                        answer = "بله"
                else:
                    answer = "بله"
                
                if answer != "بله":
                    output_log.append("⛔ اصلاح انجام نشد")
                    return "\n".join(output_log)
                
                if fix["line"] <= len(lines):
                    lines[fix["line"] - 1] = fix["new"]
                    output_log.append("✅ اصلاح انجام شد...")
        
        return "\n".join(output_log) + "\n⛔ تعداد تلاش‌ها تمام شد"
