# -*- coding: utf-8 -*-
"""
tokenizer.py -- توکنایزرِ BPE سطحِ بایت (byte-level BPE).

چرا سطحِ بایت؟ (بخشِ ۱۲-الف سند: «زبانِ فارسی، انگلیسی، کد، اعداد،
علائم، متنِ چندزبانه» باید پوشش داده شود.) واحدِ پایه به‌جایِ کاراکتر
یا کلمه، **بایتِ UTF-8** است؛ در نتیجه:

    - هیچ کاراکترِ یونیکدی (فارسی، اموجی، هر زبانِ دیگر) هرگز باعثِ
      «توکنِ ناشناخته/<unk>» نمی‌شود -- هر رشته‌ی متنی به ۲۵۶ بایتِ پایه
      قابلِ تجزیه است.
    - encode/decode همیشه **بدونِ افتِ اطلاعات** است:
      ``decode(encode(x)) == x`` برایِ هر ``x`` (تستِ round-trip در
      ``tests/test_native_model.py``).

الگوریتمِ آموزش دقیقاً BPE استانداردِ کلاسیک است (همان خانواده‌ی
GPT-2/الگوریتمِ Sennrich et al. 2016؛ نسخه‌یِ سبک‌ترِ الهام‌گرفته از
پیاده‌سازیِ مرجعِ karpathy/minbpe -- «مطالعه، نه کپی»، دقیقاً طبقِ
اصلِ بخشِ ۳۲ سند): پیکره پیش‌توکنایز می‌شود (رونِ همگنِ حروف/ارقام/
فاصله/علائم)، سپس پرتکرارترین جفتِ توکنِ مجاور به‌طورِ تکراری با یک
توکنِ جدید ادغام می‌شود تا اندازه‌یِ واژگانِ هدف برسد.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

# سه توکنِ ویژه؛ بعد از فضایِ (۲۵۶ بایت + merges) قرار می‌گیرند.
SPECIAL_TOKENS: Tuple[str, ...] = ("<pad>", "<bos>", "<eos>")


def _char_class(ch: str) -> str:
    if ch.isspace():
        return "space"
    if ch.isalpha():
        return "alpha"
    if ch.isdigit():
        return "digit"
    return "other"


def pre_tokenize(text: str) -> List[str]:
    """متن را به رشته‌هایی با کلاسِ کاراکتریِ همگن می‌شکند.

    نمونه: ``"سلام Hi 123!"`` -> ``["سلام", " ", "Hi", " ", "123", "!"]``
    این تفکیک باعث می‌شود BPE مرزِ کلمه/رقم/فاصله را حدس نزند و ادغام‌ها
    داخلِ هر دسته منطقی بمانند.
    """
    if not text:
        return []
    chunks: List[str] = []
    start = 0
    current_class = _char_class(text[0])
    for i in range(1, len(text)):
        cls = _char_class(text[i])
        if cls != current_class:
            chunks.append(text[start:i])
            start = i
            current_class = cls
    chunks.append(text[start:])
    return chunks


def _get_pair_counts(sequences: Dict[Tuple[int, ...], int]) -> Dict[Tuple[int, int], int]:
    counts: Dict[Tuple[int, int], int] = {}
    for seq, freq in sequences.items():
        for a, b in zip(seq, seq[1:]):
            counts[(a, b)] = counts.get((a, b), 0) + freq
    return counts


def _merge_sequence(seq: Tuple[int, ...], pair: Tuple[int, int], new_id: int) -> Tuple[int, ...]:
    out: List[int] = []
    i = 0
    n = len(seq)
    while i < n:
        if i < n - 1 and seq[i] == pair[0] and seq[i + 1] == pair[1]:
            out.append(new_id)
            i += 2
        else:
            out.append(seq[i])
            i += 1
    return tuple(out)


@dataclass
class ByteLevelBPETokenizer:
    """توکنایزرِ BPE سطحِ بایت -- قابلِ ``train`` روی هر پیکره‌ی متنی."""

    merges: List[Tuple[int, int]] = field(default_factory=list)
    merge_rank: Dict[Tuple[int, int], int] = field(default_factory=dict, repr=False)
    merge_to_id: Dict[Tuple[int, int], int] = field(default_factory=dict, repr=False)
    id_to_bytes: Dict[int, bytes] = field(default_factory=lambda: {i: bytes([i]) for i in range(256)})
    special_tokens: Tuple[str, ...] = SPECIAL_TOKENS

    # ---------------------------------------------------------- meta ----
    @property
    def base_vocab_size(self) -> int:
        """۲۵۶ بایت + تعدادِ merge (بدونِ توکن‌هایِ ویژه)."""
        return 256 + len(self.merges)

    @property
    def vocab_size(self) -> int:
        return self.base_vocab_size + len(self.special_tokens)

    def special_id(self, name: str) -> int:
        return self.base_vocab_size + self.special_tokens.index(name)

    @property
    def pad_id(self) -> int:
        return self.special_id("<pad>")

    @property
    def bos_id(self) -> int:
        return self.special_id("<bos>")

    @property
    def eos_id(self) -> int:
        return self.special_id("<eos>")

    # ------------------------------------------------------- training ----
    def train(self, corpus: Sequence[str], vocab_size: int, min_frequency: int = 2) -> None:
        """آموزشِ merges رویِ ``corpus`` تا رسیدن به ``vocab_size`` (یا
        تمام‌شدنِ جفت‌هایی که حداقل ``min_frequency`` بار تکرار شده‌اند،
        هرکدام زودتر برسد).

        قطعی (deterministic): با یک پیکره‌ی ثابت، همیشه همان merges را
        تولید می‌کند -- تساویِ فرکانس با کوچک‌ترینِ جفت (لغزیکوگرافیک)
        شکسته می‌شود، نه با ترتیبِ دیکشنری که بینِ اجراها ممکن است
        فرق کند.
        """
        target_merges = max(0, vocab_size - 256 - len(self.special_tokens))

        chunk_freq: Dict[str, int] = {}
        for text in corpus:
            for chunk in pre_tokenize(text):
                chunk_freq[chunk] = chunk_freq.get(chunk, 0) + 1

        sequences: Dict[Tuple[int, ...], int] = {}
        for chunk, freq in chunk_freq.items():
            seq = tuple(chunk.encode("utf-8"))
            sequences[seq] = sequences.get(seq, 0) + freq

        merges: List[Tuple[int, int]] = []
        id_to_bytes: Dict[int, bytes] = {i: bytes([i]) for i in range(256)}
        next_id = 256

        while len(merges) < target_merges:
            pair_counts = _get_pair_counts(sequences)
            if not pair_counts:
                break
            best_pair = max(pair_counts.items(), key=lambda kv: (kv[1], -kv[0][0], -kv[0][1]))
            (a, b), freq = best_pair
            if freq < min_frequency:
                break
            new_id = next_id
            next_id += 1
            id_to_bytes[new_id] = id_to_bytes[a] + id_to_bytes[b]
            merges.append((a, b))

            new_sequences: Dict[Tuple[int, ...], int] = {}
            for seq, cnt in sequences.items():
                merged = _merge_sequence(seq, (a, b), new_id)
                new_sequences[merged] = new_sequences.get(merged, 0) + cnt
            sequences = new_sequences

        self.merges = merges
        self.merge_rank = {pair: i for i, pair in enumerate(merges)}
        self.merge_to_id = {pair: 256 + i for i, pair in enumerate(merges)}
        self.id_to_bytes = id_to_bytes

    # ------------------------------------------------------- encode ----
    def _encode_chunk(self, chunk: str) -> List[int]:
        ids = list(chunk.encode("utf-8"))
        if not self.merge_rank:
            return ids
        while len(ids) >= 2:
            pairs = list(zip(ids, ids[1:]))
            ranked = [(self.merge_rank[p], idx) for idx, p in enumerate(pairs) if p in self.merge_rank]
            if not ranked:
                break
            _, idx = min(ranked)
            pair = (ids[idx], ids[idx + 1])
            new_id = self.merge_to_id[pair]
            ids = ids[:idx] + [new_id] + ids[idx + 2 :]
        return ids

    def encode(self, text: str, add_bos: bool = False, add_eos: bool = False) -> List[int]:
        ids: List[int] = []
        if add_bos:
            ids.append(self.bos_id)
        for chunk in pre_tokenize(text):
            ids.extend(self._encode_chunk(chunk))
        if add_eos:
            ids.append(self.eos_id)
        return ids

    def decode(self, ids: Sequence[int]) -> str:
        parts: List[bytes] = []
        for i in ids:
            if i in self.id_to_bytes:
                parts.append(self.id_to_bytes[i])
            # توکن‌های ویژه (pad/bos/eos) معادلِ بایتی ندارند؛ در متنِ
            # قابلِ‌نمایش حذف می‌شوند (رفتاری صریح، نه بی‌صدا -- بدونِ
            # آن‌ها هم decode هرگز crash نمی‌کند).
        return b"".join(parts).decode("utf-8", errors="replace")

    # --------------------------------------------------------- io ----
    def to_dict(self) -> dict:
        return {
            "merges": self.merges,
            "special_tokens": list(self.special_tokens),
        }

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: dict) -> "ByteLevelBPETokenizer":
        tok = cls(special_tokens=tuple(data.get("special_tokens", SPECIAL_TOKENS)))
        merges = [tuple(p) for p in data["merges"]]
        id_to_bytes: Dict[int, bytes] = {i: bytes([i]) for i in range(256)}
        for i, (a, b) in enumerate(merges):
            id_to_bytes[256 + i] = id_to_bytes[a] + id_to_bytes[b]
        tok.merges = merges
        tok.merge_rank = {pair: i for i, pair in enumerate(merges)}
        tok.merge_to_id = {pair: 256 + i for i, pair in enumerate(merges)}
        tok.id_to_bytes = id_to_bytes
        return tok

    @classmethod
    def load(cls, path: str) -> "ByteLevelBPETokenizer":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)
