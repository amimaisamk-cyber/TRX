# -*- coding: utf-8 -*-
"""
interfaces.py -- قراردادِ (contract) مشترکِ مدل، طبقِ بخشِ ۹ و ۱۱ سند:

    «TRX باید از ابتدا contract-based باشد.»
    «مدل نباید کل سیستم باشد... Model Adapter... به این شکل، مدل
     می‌تواند در آینده تعویض شود.»

هر پیاده‌سازیِ آینده‌یِ مدل (بزرگ‌تر، آموزش‌دیده، یا حتی یک آداپتورِ
جدا برایِ یک مدلِ بیرونی) فقط کافی است این interface را رعایت کند --
بقیه‌ی سیستم (اگر/وقتی به این لایه وصل شود) بدونِ تغییر باقی می‌ماند.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional


class ModelInterface(ABC):
    """قراردادِ حداقلیِ هر Model Adapter در TRX."""

    @abstractmethod
    def encode(self, text: str) -> List[int]:
        """متن -> فهرستِ idِ توکن‌ها."""
        raise NotImplementedError

    @abstractmethod
    def decode(self, ids: List[int]) -> str:
        """فهرستِ idِ توکن‌ها -> متن."""
        raise NotImplementedError

    @abstractmethod
    def generate(self, prompt: str, max_new_tokens: int = 32, **kwargs) -> str:
        """متنِ ورودی -> متنِ تولیدشده (end-to-end: encode->forward loop->decode)."""
        raise NotImplementedError


class ConversationalModelInterface(ModelInterface):
    """
    گسترشِ ``ModelInterface`` برایِ مدل‌هایی که مکالمه‌ی چندنقشی
    (system/user/assistant) و تاریخچه را به‌عنوانِ یک قابلیتِ *رسمی*
    پشتیبانی می‌کنند -- نه فقط یک متدِ اضافیِ خصوصیِ یک پیاده‌سازیِ
    خاص.

    چرا این کلاسِ جدا لازم بود (رفعِ نکته‌یِ معماریِ ۲۰۲۶-۰۹-۲۰):
    ``conversational_bridge.py`` قبلاً مستقیماً به ``adapter.chat(...)``
    وابسته بود -- درحالی‌که ``ModelInterface`` فقط ``generate()`` را
    قرارداد کرده بود. یعنی اگر فردا یک Adapterِ دیگر فقط
    ``ModelInterface`` را پیاده می‌کرد (بدونِ ``chat``)، بی‌سروصدا
    خراب می‌شد. حالا ``conversational_bridge`` قبل از فراخوانی،
    ``isinstance(adapter, ConversationalModelInterface)`` را چک
    می‌کند -- تعویضِ مدل دقیقاً همان تمیزی‌ای می‌شود که ``ModelInterface``
    از اول می‌خواست.
    """

    @abstractmethod
    def chat(
        self,
        *,
        system_prompt: str,
        user_text: str,
        history: Optional[list[tuple[str, str]]] = None,
        max_new_tokens: int = 512,
        temperature: float = 0.6,
        seed: Optional[int] = None,
    ) -> str:
        """
        مکالمه‌ی چندنقشی: ``history`` فهرستی از جفت‌هایِ
        ``(role, content)`` با ``role`` یکی از ``"user"``/``"assistant"``،
        به‌ترتیبِ زمانی (قدیمی‌ترین اول).

        ``seed`` (افزوده‌یِ v25.5.7، اختیاری): اگر داده شود، تولیدِ متن
        قطعی (deterministic) می‌شود -- برایِ آزمایش‌هایِ کنترل‌شده‌ای که
        باید فقط یک متغیر (مثلاً ``pattern_context``) را تغییر دهند،
        بدونِ اینکه randomnessِ خودِ مدل هم یک متغیرِ ناخواسته باشد.
        ``None`` (پیش‌فرض) یعنی دقیقاً همان رفتارِ قبل از v25.5.7 --
        بدونِ seedِ ثابت.
        """
        raise NotImplementedError
