# -*- coding: utf-8 -*-
"""
model_adapter.py -- Model Adapter (بخشِ ۱۱ سند):

    TRX -> Intelligence Runtime -> Model Adapter -> Model

این لایه tokenizer و TRXNativeModel را پشتِ یک API متنی-به-متنیِ ساده
پنهان می‌کند و قراردادِ ``ModelInterface`` را رعایت می‌کند. مصرف‌کننده‌ی
بالادست (اگر در آینده وصل شود) فقط ``adapter.generate("...")`` صدا
می‌زند و از جزئیاتِ tokenizer/RoPE/ابعادِ مدل بی‌خبر می‌ماند -- دقیقاً
همان چیزی که بخشِ ۱۱ سند می‌خواهد: «مدل می‌تواند در آینده تعویض شود.»

**عمداً به core.py/intelligence.py وصل نشده** -- ر.ک. NATIVE_MODEL_NOTES.md.
"""

from __future__ import annotations

import os
from typing import List, Optional

import numpy as np

from .interfaces import ModelInterface
from .model import TRXModelConfig, TRXNativeModel
from .tokenizer import ByteLevelBPETokenizer

DEFAULT_TOKENIZER_PATH = os.path.join(os.path.dirname(__file__), "data", "tokenizer.json")


class TRXNativeModelAdapter(ModelInterface):
    """پیاده‌سازیِ ``ModelInterface`` رویِ مدلِ بومیِ TRX."""

    def __init__(
        self,
        tokenizer: ByteLevelBPETokenizer,
        model: Optional[TRXNativeModel] = None,
        config: Optional[TRXModelConfig] = None,
        rng_seed: Optional[int] = None,
    ):
        self.tokenizer = tokenizer
        if model is not None:
            self.model = model
        else:
            cfg = config or TRXModelConfig(vocab_size=tokenizer.vocab_size)
            if cfg.vocab_size != tokenizer.vocab_size:
                raise ValueError(
                    "config.vocab_size با tokenizer.vocab_size ناسازگار است "
                    f"({cfg.vocab_size} != {tokenizer.vocab_size})."
                )
            self.model = TRXNativeModel(cfg)
        self._rng = np.random.default_rng(rng_seed)

    # ---------------------------------------------------- factory ----
    @classmethod
    def from_default_tokenizer(cls, config: Optional[TRXModelConfig] = None) -> "TRXNativeModelAdapter":
        """بارگذاریِ توکنایزرِ آموزش‌دیده‌ی پیش‌فرض (روی پیکره‌ی خودِ
        پروژه -- ر.ک. ``scripts/train_native_tokenizer.py``).

        اگر فایلِ توکنایزر هنوز ساخته نشده باشد، خطایِ صریح می‌دهد
        (نه یک fallback بی‌صدا -- طبقِ قانونِ ممنوعیتِ راه‌حلِ فریبنده).
        """
        if not os.path.exists(DEFAULT_TOKENIZER_PATH):
            raise FileNotFoundError(
                f"توکنایزرِ پیش‌فرض یافت نشد: {DEFAULT_TOKENIZER_PATH}\n"
                "ابتدا اجرا کنید: python scripts/train_native_tokenizer.py"
            )
        tokenizer = ByteLevelBPETokenizer.load(DEFAULT_TOKENIZER_PATH)
        return cls(tokenizer, config=config)

    # ------------------------------------------------ ModelInterface ----
    def encode(self, text: str) -> List[int]:
        return self.tokenizer.encode(text)

    def decode(self, ids: List[int]) -> str:
        return self.tokenizer.decode(ids)

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 32,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        **kwargs,
    ) -> str:
        prompt_ids = self.tokenizer.encode(prompt, add_bos=True)
        out_ids = self.model.generate(
            prompt_ids,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_k=top_k,
            rng=self._rng,
            stop_id=self.tokenizer.eos_id,
        )
        return self.tokenizer.decode(out_ids[len(prompt_ids) :])
