# -*- coding: utf-8 -*-
"""
trx_ai.trx_model -- زیرساختِ مدلِ بومیِ TRX (Model Adapter مستقل).

این پکیج پیاده‌سازیِ بخش‌هایِ ۱۱ تا ۱۳ سندِ معماریِ TRX است:

    متن -> Tokenizer -> Embedding -> Transformer Core -> Logits -> متن

هرچه اینجا هست **واقعاً اجرا می‌شود** (forward pass واقعیِ عددی روی
numpy، نه شبیه‌سازی/mock) اما وزن‌ها آموزش‌ندیده‌اند (init تصادفیِ
seed-دار). یعنی:

    - Tokenizer: واقعی و آموزش‌دیده (BPE سطحِ بایت روی پیکره‌ی خودِ
      پروژه) -- encode/decode آن بدونِ افتِ اطلاعات (lossless) است.
    - Transformer: معماریِ واقعی (RoPE + RMSNorm + SwiGLU + causal
      attention) با forward pass صحیح و قابلِ تست.
    - "هوشمندی"/کیفیتِ تولیدِ متن: **وجود ندارد هنوز** -- چون هیچ
      حلقه‌ی آموزشی (Stage 14 سند: Pretraining/Instruction/Reasoning/
      Alignment) پیاده نشده. `generate()` فقط توکنِ بعدی را از
      توزیعِ خروجیِ وزنِ تصادفی نمونه‌برداری می‌کند -- خروجی بی‌معنی
      خواهد بود تا وقتی آموزش اضافه شود.

جزئیاتِ کامل: ``NATIVE_MODEL_NOTES.md`` در ریشه‌ی پروژه.

این پکیج **به مسیرِ پاسخِ اصلیِ چت (core.py) وصل نیست** -- طبقِ
تصمیمِ صریح: هدفِ این نسخه فقط «زیرساخت»، نه جایگزینیِ چیزی موجود
است (قانونِ قرمزِ ۱: چیزی حذف/جایگزین نمی‌شود مگر با معادلِ
قوی‌ترِ تست‌شده).
"""

from __future__ import annotations

from .interfaces import ModelInterface
from .tokenizer import ByteLevelBPETokenizer
from .model import TRXModelConfig, TRXNativeModel
from .model_adapter import TRXNativeModelAdapter

__all__ = [
    "ModelInterface",
    "ByteLevelBPETokenizer",
    "TRXModelConfig",
    "TRXNativeModel",
    "TRXNativeModelAdapter",
]
