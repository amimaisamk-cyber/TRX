# -*- coding: utf-8 -*-
"""
autograd_cache.py -- ``forward_with_cache`` (بخشِ چهارم سندِ فعال‌سازیِ
آموزش: «Forward قابلِ آموزش»).

قانونِ حیاتی: **هیچ فایلِ موجودی (``model.py``/``transformer_core.py``)
تغییر نمی‌کند.** این فایل فقط همان محاسباتِ ``TRXNativeModel.forward``/
``TransformerBlock.__call__``/``CausalSelfAttention.__call__``/
``SwiGLUFeedForward.__call__`` را -- با همان وزن‌هایِ واقعیِ آبجکت‌های
مدل -- دوباره، قدم‌به‌قدم، بازمی‌سازد تا میانجی‌هایِ لازم برایِ
Backward (که در ``forward`` عادی دور ریخته می‌شوند) نگه داشته شوند.

خروجی عددیِ ``forward_with_cache`` باید دقیقاً با ``model.forward``
یکسان باشد -- تستِ ``test_forward_cache_matches_forward`` همین را
می‌سنجد. اگر این دو مسیر واگرا شوند، Backward رویِ مسیرِ اشتباه محاسبه
خواهد شد.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List

import numpy as np

from ..transformer_core import softmax


@dataclass
class AttentionCache:
    """میانجی‌هایِ لازم برایِ Backward در Attention (بخشِ ۴.۲، ردیفِ
    Attention)."""

    x_norm_input: np.ndarray  # ورودیِ Attention == خروجیِ attn_norm  (seq, d_model)
    q_raw: np.ndarray  # (seq, n_heads, head_dim) -- قبل از RoPE
    k_raw: np.ndarray
    v_raw: np.ndarray
    q_rope: np.ndarray  # (n_heads, seq, head_dim) -- بعد از RoPE و transpose
    k_rope: np.ndarray
    scores: np.ndarray  # (n_heads, seq, seq) -- قبل از softmax
    probs: np.ndarray  # (n_heads, seq, seq) -- بعد از softmax (P)
    context: np.ndarray  # (seq, d_model) -- Attention Output قبل از Wo
    output: np.ndarray  # (seq, d_model) -- Attention Output بعد از Wo
    causal_mask: np.ndarray  # (seq, seq) bool -- True یعنی ماسک‌شده


@dataclass
class FFNCache:
    """میانجی‌هایِ لازم برایِ Backward در SwiGLU (بخشِ ۴.۲، ردیفِ FFN)."""

    x_norm_input: np.ndarray  # ورودیِ FFN == خروجیِ ffn_norm  (seq, d_model)
    pre_gate: np.ndarray  # x @ W1  (قبل از SiLU)
    gate: np.ndarray  # SiLU(pre_gate)
    up: np.ndarray  # x @ W3
    hidden: np.ndarray  # gate * up
    output: np.ndarray  # hidden @ W2


@dataclass
class BlockCache:
    """میانجی‌هایِ یک ``TransformerBlock`` کامل (بخشِ شانزدهم)."""

    x0: np.ndarray  # ورودیِ block
    attn_norm_output: np.ndarray  # a_norm
    attn: AttentionCache
    x1: np.ndarray  # x0 + attention_output
    ffn_norm_output: np.ndarray  # f_norm
    ffn: FFNCache
    x2: np.ndarray  # x1 + ffn_output  (خروجیِ block)


@dataclass
class ModelCache:
    """میانجی‌هایِ کاملِ یک forward pass (بخشِ ۴.۲، سطرِ آخر)."""

    token_ids: np.ndarray
    embedding_output: np.ndarray  # x0 کلِ مدل
    blocks: List[BlockCache] = field(default_factory=list)
    final_norm_input: np.ndarray = None  # type: ignore[assignment]
    final_norm_output: np.ndarray = None  # type: ignore[assignment]
    hidden_states: np.ndarray = None  # type: ignore[assignment]
    logits: np.ndarray = None  # type: ignore[assignment]


def _rmsnorm_forward(x: np.ndarray, weight: np.ndarray, eps: float) -> np.ndarray:
    """دقیقاً همان فرمولِ ``RMSNorm.__call__`` در transformer_core.py."""
    variance = np.mean(np.square(x), axis=-1, keepdims=True)
    x_norm = x * (1.0 / np.sqrt(variance + eps))
    return x_norm * weight


def _attention_forward_with_cache(attn, x_norm: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> AttentionCache:
    """بازسازیِ دقیقِ ``CausalSelfAttention.__call__`` + ذخیره‌یِ میانجی‌ها."""
    seq_len, d_model = x_norm.shape
    head_dim = attn.head_dim

    q_raw = (x_norm @ attn.w_q).reshape(seq_len, attn.n_heads, head_dim)
    k_raw = (x_norm @ attn.w_k).reshape(seq_len, attn.n_heads, head_dim)
    v_raw = (x_norm @ attn.w_v).reshape(seq_len, attn.n_heads, head_dim)

    from ..transformer_core import apply_rope

    q_rope = apply_rope(q_raw, cos[:seq_len], sin[:seq_len]).transpose(1, 0, 2)
    k_rope = apply_rope(k_raw, cos[:seq_len], sin[:seq_len]).transpose(1, 0, 2)
    v_heads = v_raw.transpose(1, 0, 2)

    scores = np.einsum("hqd,hkd->hqk", q_rope, k_rope) / math.sqrt(head_dim)
    causal_mask = np.triu(np.ones((seq_len, seq_len), dtype=bool), k=1)
    scores_masked = np.where(causal_mask[None, :, :], -np.inf, scores)
    probs = softmax(scores_masked, axis=-1)

    context_heads = np.einsum("hqk,hkd->hqd", probs, v_heads)
    context = context_heads.transpose(1, 0, 2).reshape(seq_len, d_model)
    output = context @ attn.w_o

    return AttentionCache(
        x_norm_input=x_norm,
        q_raw=q_raw,
        k_raw=k_raw,
        v_raw=v_raw,
        q_rope=q_rope,
        k_rope=k_rope,
        scores=scores_masked,
        probs=probs,
        context=context,
        output=output,
        causal_mask=causal_mask,
    )


def _ffn_forward_with_cache(ffn, x_norm: np.ndarray) -> FFNCache:
    """بازسازیِ دقیقِ ``SwiGLUFeedForward.__call__`` + ذخیره‌یِ میانجی‌ها."""
    from ..transformer_core import silu

    pre_gate = x_norm @ ffn.w1
    gate = silu(pre_gate)
    up = x_norm @ ffn.w3
    hidden = gate * up
    output = hidden @ ffn.w2
    return FFNCache(x_norm_input=x_norm, pre_gate=pre_gate, gate=gate, up=up, hidden=hidden, output=output)


def _block_forward_with_cache(block, x0: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> BlockCache:
    attn_norm_output = _rmsnorm_forward(x0, block.attn_norm.weight, block.attn_norm.eps)
    attn_cache = _attention_forward_with_cache(block.attn, attn_norm_output, cos, sin)
    x1 = x0 + attn_cache.output

    ffn_norm_output = _rmsnorm_forward(x1, block.ffn_norm.weight, block.ffn_norm.eps)
    ffn_cache = _ffn_forward_with_cache(block.ffn, ffn_norm_output)
    x2 = x1 + ffn_cache.output

    return BlockCache(
        x0=x0,
        attn_norm_output=attn_norm_output,
        attn=attn_cache,
        x1=x1,
        ffn_norm_output=ffn_norm_output,
        ffn=ffn_cache,
        x2=x2,
    )


def forward_with_cache(model, token_ids: np.ndarray) -> "tuple[np.ndarray, ModelCache]":
    """معادلِ ``model.forward`` -- عدداً یکسان -- به‌همراهِ ذخیره‌یِ همه‌یِ
    میانجی‌هایِ لازم برایِ ``backward.backward``.

    هیچ متدی رویِ ``model``/``block``/``attn``/``ffn`` تغییر نمی‌کند؛ این
    تابع فقط arrayهایِ وزنِ همان آبجکت‌ها را می‌خواند (read-only).
    """
    token_ids = np.asarray(token_ids, dtype=np.int64)
    if token_ids.ndim != 1:
        raise ValueError("forward_with_cache فقط یک دنباله‌ی یک‌بعدی می‌پذیرد (بدونِ batch).")
    seq_len = token_ids.shape[0]
    if seq_len > model.config.max_seq_len:
        raise ValueError(
            f"طولِ دنباله ({seq_len}) از max_seq_len ({model.config.max_seq_len}) بیشتر است."
        )
    if token_ids.max(initial=0) >= model.config.vocab_size or token_ids.min(initial=0) < 0:
        raise ValueError("id توکن خارج از بازه‌ی vocab_size است.")

    x0 = model.token_embedding[token_ids]

    block_caches: List[BlockCache] = []
    x = x0
    for block in model.blocks:
        bc = _block_forward_with_cache(block, x, model.rope_cos, model.rope_sin)
        block_caches.append(bc)
        x = bc.x2

    final_norm_input = x
    final_norm_output = _rmsnorm_forward(final_norm_input, model.final_norm.weight, model.final_norm.eps)
    logits = final_norm_output @ model.token_embedding.T

    cache = ModelCache(
        token_ids=token_ids,
        embedding_output=x0,
        blocks=block_caches,
        final_norm_input=final_norm_input,
        final_norm_output=final_norm_output,
        hidden_states=final_norm_output,
        logits=logits,
    )
    return logits, cache


def build_param_map(model) -> "dict[str, np.ndarray]":
    """نگاشتِ نامِ یکتا -> ارجاعِ واقعیِ آرایه (بخشِ بیستم سند: Parameter
    Map). ``token_embedding`` تنها یک بار حاضر است (Weight Tying)."""
    params: "dict[str, np.ndarray]" = {"token_embedding": model.token_embedding}
    for i, block in enumerate(model.blocks):
        prefix = f"blocks.{i}"
        params[f"{prefix}.attn.w_q"] = block.attn.w_q
        params[f"{prefix}.attn.w_k"] = block.attn.w_k
        params[f"{prefix}.attn.w_v"] = block.attn.w_v
        params[f"{prefix}.attn.w_o"] = block.attn.w_o
        params[f"{prefix}.attn_norm.weight"] = block.attn_norm.weight
        params[f"{prefix}.ffn.w1"] = block.ffn.w1
        params[f"{prefix}.ffn.w2"] = block.ffn.w2
        params[f"{prefix}.ffn.w3"] = block.ffn.w3
        params[f"{prefix}.ffn_norm.weight"] = block.ffn_norm.weight
    params["final_norm.weight"] = model.final_norm.weight
    return params
