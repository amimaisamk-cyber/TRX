# -*- coding: utf-8 -*-
"""
dataset.py -- آماده‌سازیِ داده برایِ آموزشِ Causal LM (بخشِ سومِ سند).

نکته‌یِ حیاتیِ علت‌ومعلولی (بخشِ ۳.۳): این ماژول Input/Target را با
یک خانه اختلاف می‌سازد -- Target هرگز به مدل داده نمی‌شود؛ فقط برایِ
محاسبه‌یِ Loss استفاده می‌شود. مدل خودش (با Causal Mask در
``transformer_core.py``) مطمئن می‌شود توکنِ آینده دیده نمی‌شود.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np


@dataclass
class Sequence_:
    input_ids: np.ndarray
    target_ids: np.ndarray


def build_sequences(tokenizer, texts: Sequence[str], seq_len: int) -> List[Sequence_]:
    """متن‌هایِ خام -> توکن -> پنجره‌هایِ ``(input, target)`` با طولِ
    ``seq_len`` (بخشِ ۳.۱ و ۳.۲ سند).

    هر متن جداگانه توکنایز می‌شود (بدونِ چسبیدنِ متن‌هایِ نامرتبط به
    هم) و با ``<bos>``/``<eos>`` مرزبندی می‌شود. اگر یک متن به‌تنهایی
    کوتاه‌تر از ``seq_len+1`` توکن باشد، رد می‌شود (نه pad با صفرِ
    بی‌معنا -- padding معنادار خارج از دامنه‌یِ این سند است).
    """
    if seq_len < 1:
        raise ValueError("seq_len باید حداقل ۱ باشد.")

    sequences: List[Sequence_] = []
    for text in texts:
        ids = tokenizer.encode(text, add_bos=True, add_eos=True)
        if len(ids) < seq_len + 1:
            continue
        ids_arr = np.asarray(ids, dtype=np.int64)
        # پنجره‌هایِ غیرِ هم‌پوشان -- هر توکن حداکثر یک‌بار target می‌شود
        # (ساده‌ترین و قطعی‌ترین انتخاب؛ overlap اختیاریِ آینده است).
        n_windows = (len(ids_arr) - 1) // seq_len
        for w in range(n_windows):
            start = w * seq_len
            chunk = ids_arr[start : start + seq_len + 1]
            sequences.append(Sequence_(input_ids=chunk[:-1], target_ids=chunk[1:]))
    return sequences


def train_val_split(sequences: List[Sequence_], val_fraction: float = 0.1, seed: int = 0) -> Tuple[List[Sequence_], List[Sequence_]]:
    """تقسیمِ ۹۰٪/۱۰٪ (یا نسبتِ دلخواه) -- بخشِ ۳.۴ سند. Validation
    هرگز در به‌روزرسانیِ وزن استفاده نمی‌شود (مصرف‌کننده -- trainer.py
    -- این قانون را رعایت می‌کند)."""
    if not sequences:
        raise ValueError("لیستِ sequences خالی است -- تقسیم ممکن نیست.")
    if not (0.0 < val_fraction < 1.0):
        raise ValueError("val_fraction باید بینِ ۰ و ۱ باشد.")

    rng = np.random.default_rng(seed)
    order = rng.permutation(len(sequences))
    n_val = max(1, int(round(len(sequences) * val_fraction))) if len(sequences) > 1 else 0
    val_idx = set(order[:n_val].tolist())
    train_seqs = [sequences[i] for i in range(len(sequences)) if i not in val_idx]
    val_seqs = [sequences[i] for i in range(len(sequences)) if i in val_idx]
    if not train_seqs:
        raise ValueError("پس از تقسیم، Training Set خالی شد -- داده‌یِ ورودی خیلی کم است.")
    return train_seqs, val_seqs


def shuffle_sequences(sequences: List[Sequence_], seed: int) -> List[Sequence_]:
    """درهم‌ریزیِ ترتیبِ batchها در ابتدایِ هر epoch (بخشِ ۲۱ سند)."""
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(sequences))
    return [sequences[i] for i in order]
