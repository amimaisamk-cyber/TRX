# -*- coding: utf-8 -*-
"""
backward.py -- موتورِ Backward واقعی (بخشِ ششم تا هفدهم سند).

هیچ‌کدام از این توابع گرادیانِ ساختگی/حدسی تولید نمی‌کنند؛ هرکدام
مشتقِ تحلیلیِ دقیقِ همان فرمولِ Forwardِ متناظر (در
``transformer_core.py``/``model.py``، بازسازی‌شده در
``autograd_cache.py``) است.

خروجیِ نهاییِ ``backward()``: یک دیکشنریِ ``name -> gradient`` که
دقیقاً با کلیدهایِ ``autograd_cache.build_param_map`` یکسان است.
"""

from __future__ import annotations

import math
from typing import Dict

import numpy as np

from .autograd_cache import ModelCache


# ============================================================ RMSNorm ====
def rmsnorm_backward(x: np.ndarray, weight: np.ndarray, eps: float, dy: np.ndarray):
    """Backward دقیقِ RMSNorm (بخشِ هشتم سند).

    Forward: ``variance=mean(x**2); r=1/sqrt(variance+eps); y=x*r*weight``.
    اشتباهِ رایجِ ``dx=dy*weight`` (نادیده‌گرفتنِ وابستگیِ variance به
    همه‌یِ عناصر) اینجا عمداً *استفاده نشده*:

        dweight = sum(dy * normalized_x, axis=0)
        dy_n    = dy * weight
        dx      = r*dy_n - (r**3/n) * x * sum(dy_n * x, axis=-1, keepdims=True)
    """
    n = x.shape[-1]
    variance = np.mean(np.square(x), axis=-1, keepdims=True)
    r = 1.0 / np.sqrt(variance + eps)
    normalized_x = x * r

    dweight = np.sum(dy * normalized_x, axis=tuple(range(x.ndim - 1)))
    dy_n = dy * weight
    dx = r * dy_n - (np.power(r, 3) / n) * x * np.sum(dy_n * x, axis=-1, keepdims=True)
    return dx, dweight


# =========================================================== SwiGLU ====
def _silu_derivative(x: np.ndarray) -> np.ndarray:
    """``d(SiLU)/dx = sigmoid(x)*(1+x*(1-sigmoid(x)))`` (بخشِ ۱۴)."""
    sig = 1.0 / (1.0 + np.exp(-x))
    return sig * (1.0 + x * (1.0 - sig))


def swiglu_backward(ffn, ffn_cache, d_output: np.ndarray):
    """Backward کاملِ SwiGLU (بخشِ چهاردهم): ``output=hidden@W2``,
    ``hidden=gate*up``, ``gate=SiLU(x@W1)``, ``up=x@W3``.
    برمی‌گرداند ``(dX, dW1, dW2, dW3)`` -- ``dX`` گرادیانِ ورودیِ FFN
    (خروجیِ ffn_norm)."""
    x = ffn_cache.x_norm_input
    gate = ffn_cache.gate
    up = ffn_cache.up
    hidden = ffn_cache.hidden
    pre_gate = ffn_cache.pre_gate

    d_hidden = d_output @ ffn.w2.T
    d_w2 = hidden.T @ d_output

    d_gate = d_hidden * up
    d_up = d_hidden * gate

    d_x_up = d_up @ ffn.w3.T
    d_w3 = x.T @ d_up

    d_pre_gate = d_gate * _silu_derivative(pre_gate)
    d_x_gate = d_pre_gate @ ffn.w1.T
    d_w1 = x.T @ d_pre_gate

    d_x = d_x_up + d_x_gate
    return d_x, d_w1, d_w2, d_w3


# ========================================================== RoPE/Attn ====
def _rotate_half_transpose(dy: np.ndarray) -> np.ndarray:
    """ترانهاده‌یِ ``rotate_half`` (بخشِ یازدهم): برایِ
    ``rotate_half(x)=concat(-x2,x1)``، ترانهاده ``concat(dy2,-dy1)``
    است."""
    d = dy.shape[-1]
    dy1 = dy[..., : d // 2]
    dy2 = dy[..., d // 2 :]
    return np.concatenate([dy2, -dy1], axis=-1)


def apply_rope_backward(dy: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
    """Backward RoPE (بخشِ یازدهم): چرخشِ خطیِ متعامد -> Backward همان
    ترانهاده است؛ RoPE پارامترِ قابلِ‌آموزش ندارد، فقط گرادیان عبور
    می‌کند. ``dy`` شکلِ ``(seq, n_heads, head_dim)`` دارد."""
    cos_b = cos[:, None, :]
    sin_b = sin[:, None, :]
    return dy * cos_b + _rotate_half_transpose(dy) * sin_b


def attention_backward(attn, attn_cache, cos: np.ndarray, sin: np.ndarray, d_output: np.ndarray):
    """Backward کاملِ Attention (بخشِ دهم تا دوازدهم):
    Wo -> (P@V) -> Softmax -> Scores -> RoPE -> Q/K/V Projection.
    برمی‌گرداند ``(dX, dWq, dWk, dWv, dWo)``."""
    seq_len, d_model = d_output.shape
    n_heads = attn.n_heads
    head_dim = attn.head_dim

    # ۱۰.۱ Backward از Wo:  Output = Context @ Wo
    d_context = d_output @ attn.w_o.T
    d_w_o = attn_cache.context.T @ d_output
    d_context_heads = d_context.reshape(seq_len, n_heads, head_dim).transpose(1, 0, 2)

    # ۱۰.۲ Backward از Context = P @ V
    v_heads = attn_cache.v_raw.transpose(1, 0, 2)  # V از RoPE عبور نمی‌کند
    d_p = np.einsum("hqd,hkd->hqk", d_context_heads, v_heads)
    d_v_heads = np.einsum("hqk,hqd->hkd", attn_cache.probs, d_context_heads)

    # ۱۰.۳ Backward از Softmax:  dS = P*(dP - sum(dP*P, axis=-1))
    p = attn_cache.probs
    d_scores = p * (d_p - np.sum(d_p * p, axis=-1, keepdims=True))
    # ۱۰.۵ ماسکِ علّی: گرادیانِ موقعیت‌هایِ ماسک‌شده صریحاً صفر می‌شود.
    d_scores = np.where(attn_cache.causal_mask[None, :, :], 0.0, d_scores)

    # ۱۰.۴ Backward از Scores = Q@K.T/sqrt(d)
    scale = 1.0 / math.sqrt(head_dim)
    d_q_rope = np.einsum("hqk,hkd->hqd", d_scores, attn_cache.k_rope) * scale
    d_k_rope = np.einsum("hqk,hqd->hkd", d_scores, attn_cache.q_rope) * scale

    # بخشِ یازدهم: Backward RoPE. ورودیِ apply_rope در forward شکلِ
    # (seq,h,hd) داشت (قبلِ transpose به (h,seq,hd)).
    d_q_raw = apply_rope_backward(d_q_rope.transpose(1, 0, 2), cos[:seq_len], sin[:seq_len])
    d_k_raw = apply_rope_backward(d_k_rope.transpose(1, 0, 2), cos[:seq_len], sin[:seq_len])
    d_v_raw = d_v_heads.transpose(1, 0, 2)  # V از RoPE عبور نکرده بود

    # بخشِ دوازدهم: Backward Q/K/V Projection
    x_norm = attn_cache.x_norm_input
    d_q_flat = d_q_raw.reshape(seq_len, d_model)
    d_k_flat = d_k_raw.reshape(seq_len, d_model)
    d_v_flat = d_v_raw.reshape(seq_len, d_model)

    d_x_q = d_q_flat @ attn.w_q.T
    d_w_q = x_norm.T @ d_q_flat
    d_x_k = d_k_flat @ attn.w_k.T
    d_w_k = x_norm.T @ d_k_flat
    d_x_v = d_v_flat @ attn.w_v.T
    d_w_v = x_norm.T @ d_v_flat

    d_x = d_x_q + d_x_k + d_x_v
    return d_x, d_w_q, d_w_k, d_w_v, d_w_o


# ======================================================= Transformer Block ====
def block_backward(block, block_cache, cos: np.ndarray, sin: np.ndarray, d_x2: np.ndarray,
                    grads: Dict[str, np.ndarray], prefix: str) -> np.ndarray:
    """Backward یک ``TransformerBlock`` کامل (بخشِ شانزدهم):

        dx1 = dx2 + Backward_FFN(dx2)
        dx0 = dx1 + Backward_Attention(dx1)

    گرادیانِ پارامترها با کلیدِ ``{prefix}.<name>`` در ``grads``
    نوشته می‌شود (in-place). خروجی ``dx0`` -- گرادیانِ ورودیِ block --
    به block قبلی (یا به Embedding، برایِ block اول) می‌رود.
    """
    # --- Residual FFN ---
    d_ffn_norm_out, d_w1, d_w2, d_w3 = swiglu_backward(block.ffn, block_cache.ffn, d_x2)
    d_x1_extra, d_ffn_norm_weight = rmsnorm_backward(
        block_cache.x1, block.ffn_norm.weight, block.ffn_norm.eps, d_ffn_norm_out
    )
    d_x1 = d_x2 + d_x1_extra

    grads[f"{prefix}.ffn.w1"] = d_w1
    grads[f"{prefix}.ffn.w2"] = d_w2
    grads[f"{prefix}.ffn.w3"] = d_w3
    grads[f"{prefix}.ffn_norm.weight"] = d_ffn_norm_weight

    # --- Residual Attention ---
    d_attn_norm_out, d_wq, d_wk, d_wv, d_wo = attention_backward(
        block.attn, block_cache.attn, cos, sin, d_x1
    )
    d_x0_extra, d_attn_norm_weight = rmsnorm_backward(
        block_cache.x0, block.attn_norm.weight, block.attn_norm.eps, d_attn_norm_out
    )
    d_x0 = d_x1 + d_x0_extra

    grads[f"{prefix}.attn.w_q"] = d_wq
    grads[f"{prefix}.attn.w_k"] = d_wk
    grads[f"{prefix}.attn.w_v"] = d_wv
    grads[f"{prefix}.attn.w_o"] = d_wo
    grads[f"{prefix}.attn_norm.weight"] = d_attn_norm_weight

    return d_x0


# ============================================================== Model ====
def backward(model, cache: ModelCache, d_logits: np.ndarray) -> Dict[str, np.ndarray]:
    """Backward کاملِ مدل (بخشِ هفتم/هشتم/شانزدهم/هفدهم): از Output
    Head به Final RMSNorm، از آخرین block به اولین، تا Embedding --
    با ترکیبِ درستِ دو مسیرِ گرادیانِ Weight Tying.

    خروجی: دیکشنریِ کاملی با همان کلیدهایِ ``build_param_map``.
    """
    grads: Dict[str, np.ndarray] = {}

    # --- بخشِ هفتم: Output Head (Weight Tying -- مسیرِ اول: dE_output) ---
    hidden = cache.final_norm_output  # H  (logits = H @ E.T)
    embedding = model.token_embedding  # E
    d_hidden = d_logits @ embedding
    d_embedding_output_path = d_logits.T @ hidden

    # --- بخشِ هشتم: Final RMSNorm ---
    d_final_norm_input, d_final_norm_weight = rmsnorm_backward(
        cache.final_norm_input, model.final_norm.weight, model.final_norm.eps, d_hidden
    )
    grads["final_norm.weight"] = d_final_norm_weight

    # --- بخشِ شانزدهم: از آخرین block به اولین ---
    d_x = d_final_norm_input
    for i in reversed(range(len(model.blocks))):
        block = model.blocks[i]
        block_cache = cache.blocks[i]
        d_x = block_backward(block, block_cache, model.rope_cos, model.rope_sin, d_x, grads, prefix=f"blocks.{i}")

    # --- بخشِ هفدهم: Embedding -- Scatter-Add (مسیرِ دوم: dE_input) ---
    d_embedding_input_path = np.zeros_like(embedding)
    np.add.at(d_embedding_input_path, cache.token_ids, d_x)

    # --- بخشِ هفتم، نکته‌ی نهایی: ترکیبِ دو مسیرِ Weight Tying ---
    grads["token_embedding"] = d_embedding_output_path + d_embedding_input_path

    return grads


def check_gradients_finite(grads: Dict[str, np.ndarray]) -> None:
    """تستِ اجباریِ ۳ (بخشِ ۲۶): ``isfinite(gradient).all()`` برایِ
    همه‌یِ پارامترها. اگر NaN/Inf دیده شود، خطایِ صریح -- نه سکوت."""
    bad = [name for name, g in grads.items() if not np.all(np.isfinite(g))]
    if bad:
        raise FloatingPointError(f"گرادیانِ غیرِ finite (NaN/Inf) در پارامترهایِ: {bad}")
