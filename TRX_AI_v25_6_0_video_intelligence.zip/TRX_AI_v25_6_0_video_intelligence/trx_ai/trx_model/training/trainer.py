# -*- coding: utf-8 -*-
"""
trainer.py -- Training Loop واقعی (بخشِ بیست‌ویکم سند).

هیچ پیامِ موفقیتِ جعلی نمی‌دهد (بخشِ ۳۴): اگر Loss محاسبه نشود، اگر
گرادیان finite نباشد، یا اگر Checkpoint ذخیره نشود، خطا بالا می‌رود --
نه لاگِ خوش‌بینانه.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np

from .autograd_cache import build_param_map, forward_with_cache
from .backward import backward, check_gradients_finite
from .checkpoint import CheckpointMeta, save_checkpoint
from .dataset import Sequence_, shuffle_sequences
from .evaluator import evaluate
from .losses import cross_entropy_loss
from .optim import AdamW, clip_gradients


@dataclass
class TrainingConfig:
    learning_rate: float = 3e-4
    weight_decay: float = 0.01
    beta1: float = 0.9
    beta2: float = 0.999
    adam_eps: float = 1e-8
    max_grad_norm: float = 1.0
    epochs: int = 1
    seed: int = 0
    checkpoint_path: Optional[str] = None
    checkpoint_every_steps: Optional[int] = None
    log_every_steps: int = 1


@dataclass
class StepRecord:
    epoch: int
    step: int
    loss: float
    grad_norm_before_clip: float
    grad_clip_scale: float
    token_count: int


@dataclass
class TrainingReport:
    step_records: List[StepRecord] = field(default_factory=list)
    validation_losses: List[float] = field(default_factory=list)
    best_validation_loss: Optional[float] = None
    final_step: int = 0
    final_epoch: int = 0


def train_step(model, params, optimizer: AdamW, seq: Sequence_, max_grad_norm: float) -> StepRecord:
    """یک قدمِ کاملِ آموزش رویِ یک دنباله (batch_size=1 -- بخشِ ۲۷ سند:
    محدودیتِ گوشی): forward_with_cache -> loss -> backward -> clip ->
    optimizer.step."""
    logits, cache = forward_with_cache(model, seq.input_ids)
    loss, d_logits = cross_entropy_loss(logits, seq.target_ids)

    grads = backward(model, cache, d_logits)
    check_gradients_finite(grads)
    grad_norm, scale = clip_gradients(grads, max_grad_norm)

    optimizer.step(params, grads)

    return StepRecord(
        epoch=-1,
        step=-1,
        loss=loss,
        grad_norm_before_clip=grad_norm,
        grad_clip_scale=scale,
        token_count=len(seq.input_ids),
    )


def train(
    model,
    train_sequences: List[Sequence_],
    val_sequences: Optional[List[Sequence_]],
    config: TrainingConfig,
    tokenizer=None,
    on_step: Optional[Callable[[StepRecord], None]] = None,
) -> TrainingReport:
    """حلقه‌یِ کاملِ آموزش (بخشِ ۲۱ سند). ``val_sequences`` هرگز در
    ``train_step`` استفاده نمی‌شود -- فقط در ``evaluate`` بعد از هر
    epoch."""
    if not train_sequences:
        raise ValueError("train(): train_sequences خالی است.")

    params = build_param_map(model)
    optimizer = AdamW(
        param_names=params.keys(),
        lr=config.learning_rate,
        betas=(config.beta1, config.beta2),
        eps=config.adam_eps,
        weight_decay=config.weight_decay,
    )

    report = TrainingReport()
    best_val = None
    global_step = 0

    for epoch in range(config.epochs):
        epoch_seqs = shuffle_sequences(train_sequences, seed=config.seed + epoch)
        for seq in epoch_seqs:
            record = train_step(model, params, optimizer, seq, config.max_grad_norm)
            global_step += 1
            record.epoch = epoch
            record.step = global_step
            report.step_records.append(record)
            if on_step is not None and (global_step % max(1, config.log_every_steps) == 0):
                on_step(record)

            if (
                config.checkpoint_path is not None
                and config.checkpoint_every_steps is not None
                and global_step % config.checkpoint_every_steps == 0
            ):
                val_loss_now = evaluate(model, val_sequences).average_loss if val_sequences else None
                if val_loss_now is not None:
                    best_val = val_loss_now if best_val is None else min(best_val, val_loss_now)
                meta = CheckpointMeta(
                    epoch=epoch,
                    step=global_step,
                    training_loss=record.loss,
                    validation_loss=val_loss_now,
                    best_validation_loss=best_val,
                    tokenizer_vocab_size=tokenizer.vocab_size if tokenizer is not None else -1,
                    tokenizer_num_merges=len(tokenizer.merges) if tokenizer is not None else -1,
                    seed=config.seed,
                )
                save_checkpoint(config.checkpoint_path, model, optimizer, tokenizer, meta)

        if val_sequences:
            val_report = evaluate(model, val_sequences)
            report.validation_losses.append(val_report.average_loss)
            best_val = val_report.average_loss if best_val is None else min(best_val, val_report.average_loss)

    report.best_validation_loss = best_val
    report.final_step = global_step
    report.final_epoch = config.epochs - 1

    if config.checkpoint_path is not None:
        val_loss_final = evaluate(model, val_sequences).average_loss if val_sequences else None
        meta = CheckpointMeta(
            epoch=report.final_epoch,
            step=report.final_step,
            training_loss=report.step_records[-1].loss if report.step_records else float("nan"),
            validation_loss=val_loss_final,
            best_validation_loss=report.best_validation_loss,
            tokenizer_vocab_size=tokenizer.vocab_size if tokenizer is not None else -1,
            tokenizer_num_merges=len(tokenizer.merges) if tokenizer is not None else -1,
            seed=config.seed,
        )
        save_checkpoint(config.checkpoint_path, model, optimizer, tokenizer, meta)

    return report
