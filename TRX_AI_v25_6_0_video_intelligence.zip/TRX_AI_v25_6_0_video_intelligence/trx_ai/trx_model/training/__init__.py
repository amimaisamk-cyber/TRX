# -*- coding: utf-8 -*-
"""بسته‌ی training -- فعال‌سازیِ چرخه‌یِ کاملِ آموزشِ TRX Native Model.

هیچ‌کدام از فایل‌هایِ ``trx_ai/trx_model/*.py`` (model.py،
transformer_core.py، tokenizer.py، model_adapter.py) توسطِ این بسته
تغییر داده نشده‌اند -- طبقِ بخشِ سی‌ودوم سند («اتصال به Core نباید زود
انجام شود») و اصلِ Preserve->Improve->Extend، همه‌چیز additive است."""
