# -*- coding: utf-8 -*-
"""
resource_guard.py -- تخمینِ منابع قبل از آموزش (بخشِ ۲۷ و ۲۸ سند).

هدف: قبل از این‌که آموزش رویِ گوشی/Pydroid RAM را پر کند و کرش کند،
یک تخمینِ خشن اما محافظه‌کارانه بدهیم و اگر خطرناک بود، پیشنهادِ
کوچک‌ترشدنِ کنترل‌شده (batch_size=1، sequence_length=64، ...) بدهیم.
این ماژول چیزی را متوقف نمی‌کند به‌تنهایی -- ``trainer.py`` است که
تصمیم می‌گیرد آیا با یک هشدار ادامه دهد یا نه.
"""

from __future__ import annotations

from dataclasses import dataclass

BYTES_PER_FLOAT64 = 8


@dataclass
class ResourceEstimate:
    param_count: int
    param_memory_mb: float
    optimizer_memory_mb: float  # m + v برایِ AdamW (۲ برابرِ param)
    activation_memory_mb_per_step: float  # تخمینِ خشنِ Cache یک forward
    total_estimated_mb: float
    warning: str = ""


def estimate_resources(config, seq_len: int, batch_size: int = 1) -> ResourceEstimate:
    """تخمینِ محافظه‌کارانه‌یِ RAM لازم (بخشِ ۲۸: RAM، اندازه‌یِ مدل،
    طولِ توالی، batch size، تعدادِ پارامتر، فضایِ ذخیره‌سازی)."""
    d_model = config.d_model
    n_layers = config.n_layers
    d_ff = config.d_ff
    vocab_size = config.vocab_size

    # پارامترهایِ هر block: Wq,Wk,Wv,Wo (هرکدام d_model*d_model) +
    # attn_norm (d_model) + W1,W3 (d_model*d_ff) + W2 (d_ff*d_model) + ffn_norm (d_model)
    per_block = 4 * (d_model * d_model) + 2 * d_model + 2 * (d_model * d_ff) + (d_ff * d_model)
    embedding_params = vocab_size * d_model  # Weight Tying -- فقط یک‌بار
    final_norm_params = d_model
    param_count = embedding_params + n_layers * per_block + final_norm_params

    param_memory_mb = param_count * BYTES_PER_FLOAT64 / (1024 ** 2)
    optimizer_memory_mb = param_memory_mb * 2  # m و v

    # کش هر توکن تقریباً چند برابرِ d_model عدد است (Q,K,V,rope,scores...)
    activation_per_token = 12 * d_model + 2 * seq_len  # تخمینِ خشن
    activation_memory_mb_per_step = (activation_per_token * seq_len * batch_size * BYTES_PER_FLOAT64) / (1024 ** 2)

    total = param_memory_mb + optimizer_memory_mb + activation_memory_mb_per_step

    warning = ""
    if total > 512:
        warning = (
            "تخمینِ RAM بیش از ۵۱۲ مگابایت است -- برایِ اجرا رویِ گوشی توصیه می‌شود "
            "batch_size=1، sequence_length کوچک‌تر (مثلاً ۶۴)، یا اندازه‌یِ مدل کاهش یابد."
        )

    return ResourceEstimate(
        param_count=param_count,
        param_memory_mb=param_memory_mb,
        optimizer_memory_mb=optimizer_memory_mb,
        activation_memory_mb_per_step=activation_memory_mb_per_step,
        total_estimated_mb=total,
        warning=warning,
    )


def suggest_safe_defaults() -> dict:
    """تنظیماتِ پیشنهادیِ محافظه‌کارانه برایِ گوشی (بخشِ ۲۸ سند)."""
    return {"batch_size": 1, "sequence_length": 64, "gradient_accumulation": 1}
