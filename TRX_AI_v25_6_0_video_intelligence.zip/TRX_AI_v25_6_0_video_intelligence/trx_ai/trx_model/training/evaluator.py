# -*- coding: utf-8 -*-
"""
evaluator.py -- Validation Loss + Perplexity + نمونه‌یِ تولیدی (بخشِ
بیست‌ویکم و بیست‌وسوم سند).

قانونِ حیاتی: این ماژول هرگز رویِ Validation Set به‌روزرسانیِ وزن
انجام نمی‌دهد -- فقط forward (بدونِ cache، بدونِ backward) اجرا
می‌کند.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from .dataset import Sequence_
from .losses import cross_entropy_loss, perplexity_from_loss


@dataclass
class EvaluationReport:
    average_loss: float
    perplexity: float
    n_sequences: int


def evaluate(model, sequences: List[Sequence_]) -> EvaluationReport:
    """میانگینِ Loss و Perplexity رویِ ``sequences`` (Validation یا
    Training، بسته به این‌که مصرف‌کننده چه چیزی پاس می‌دهد). فقط
    ``model.forward`` (بدونِ cache) استفاده می‌شود -- بدونِ گرادیان."""
    if not sequences:
        raise ValueError("evaluate: لیستِ sequences خالی است.")
    total_loss = 0.0
    for seq in sequences:
        logits = model.forward(seq.input_ids)
        loss, _ = cross_entropy_loss(logits, seq.target_ids)
        total_loss += loss
    avg_loss = total_loss / len(sequences)
    return EvaluationReport(average_loss=avg_loss, perplexity=perplexity_from_loss(avg_loss), n_sequences=len(sequences))


def compare_before_after(model, sequences: List[Sequence_], before: EvaluationReport) -> dict:
    """مقایسه‌یِ قبل/بعدِ آموزش (بخشِ دهم سند: «برایِ هر Upgrade، قبل و
    بعد مقایسه شود»)."""
    after = evaluate(model, sequences)
    return {
        "loss_before": before.average_loss,
        "loss_after": after.average_loss,
        "perplexity_before": before.perplexity,
        "perplexity_after": after.perplexity,
        "loss_decreased": after.average_loss < before.average_loss,
    }


def generate_sample(model, tokenizer, prompt: str, max_new_tokens: int = 20, temperature: float = 1.0, seed: int = 0) -> str:
    """یک نمونه‌یِ تولیدیِ کوتاه برایِ بازرسیِ کیفی (بخشِ بیست‌ویکم/
    بیست‌وچهارم سند: «نمونه تولید» به‌عنوانِ یکی از معیارهایِ ارزیابی،
    نه صرفاً Perplexity به‌تنهایی)."""
    rng = np.random.default_rng(seed)
    ids = tokenizer.encode(prompt, add_bos=True)
    max_len = model.config.max_seq_len
    for _ in range(max_new_tokens):
        window = ids[-max_len:]
        logits = model.forward(np.asarray(window, dtype=np.int64))
        last_logits = logits[-1] / max(temperature, 1e-6)
        shifted = last_logits - np.max(last_logits)
        probs = np.exp(shifted)
        probs = probs / probs.sum()
        next_id = int(rng.choice(len(probs), p=probs))
        if next_id == tokenizer.eos_id:
            break
        ids.append(next_id)
    return tokenizer.decode(ids)
