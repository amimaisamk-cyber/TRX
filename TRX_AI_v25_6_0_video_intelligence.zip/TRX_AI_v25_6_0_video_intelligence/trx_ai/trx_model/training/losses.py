# -*- coding: utf-8 -*-
"""
losses.py -- Causal Cross Entropy (بخشِ پنجم سند).

هیچ‌کدام از این توابع مستقیماً ``exp(logits)`` را بدونِ shift اجرا
نمی‌کنند (بخشِ ۵.۲: پایداریِ عددی).
"""

from __future__ import annotations

from typing import Tuple

import numpy as np


def stable_softmax(logits: np.ndarray, axis: int = -1) -> np.ndarray:
    """``softmax`` پایدارِ عددی: shift با بیشترین logit قبل از exp."""
    shifted = logits - np.max(logits, axis=axis, keepdims=True)
    exp = np.exp(shifted)
    return exp / np.sum(exp, axis=axis, keepdims=True)


def cross_entropy_loss(logits: np.ndarray, targets: np.ndarray) -> Tuple[float, np.ndarray]:
    """Causal Cross Entropy رویِ یک دنباله.

    ورودی:
        logits  -- (seq_len, vocab_size)
        targets -- (seq_len,) idِ توکنِ صحیح در هر موقعیت

    خروجی:
        loss    -- میانگینِ ``-log(P(correct_token))`` رویِ موقعیت‌ها
        dLogits -- گرادیانِ Loss نسبتِ به logits، شکلِ یکسان با logits
                   (``dLogits = (P - OneHot(target)) / N`` -- بخشِ ۵.۳)

    اگر هیچ‌کدام از targets معتبر نباشند (دنباله‌ی خالی)، خطایِ صریح
    می‌دهد -- نه یک مقدارِ جعلی مثلِ صفر (بخشِ ۳۴: ممنوعیتِ گزارشِ
    موفقیتِ جعلی).
    """
    logits = np.asarray(logits, dtype=np.float64)
    targets = np.asarray(targets, dtype=np.int64)
    if logits.ndim != 2:
        raise ValueError("cross_entropy_loss فقط (seq_len, vocab_size) می‌پذیرد.")
    seq_len, vocab_size = logits.shape
    if targets.shape != (seq_len,):
        raise ValueError(f"شکلِ targets ({targets.shape}) با logits ({logits.shape}) سازگار نیست.")
    if seq_len == 0:
        raise ValueError("دنباله‌ی خالی -- Loss تعریف نمی‌شود.")
    if targets.max(initial=0) >= vocab_size or targets.min(initial=0) < 0:
        raise ValueError("id در targets خارج از بازه‌ی vocab_size است.")

    probs = stable_softmax(logits, axis=-1)
    correct_probs = probs[np.arange(seq_len), targets]
    # جلوگیری از log(0) در صورتِ underflow عددیِ شدید (نه پوشاندنِ خطا،
    # فقط پایداریِ عددیِ محضِ log -- خودِ probs از softmax پایدار آمده).
    eps = 1e-12
    loss = float(-np.mean(np.log(np.clip(correct_probs, eps, 1.0))))

    one_hot = np.zeros_like(probs)
    one_hot[np.arange(seq_len), targets] = 1.0
    d_logits = (probs - one_hot) / seq_len

    if not np.isfinite(loss):
        raise FloatingPointError("Loss غیرِ finite شد (NaN/Inf) -- قبل از ادامه‌ی آموزش باید بررسی شود.")

    return loss, d_logits


def perplexity_from_loss(loss: float) -> float:
    """``Perplexity = exp(loss)`` (بخشِ بیست‌وسوم سند)."""
    return float(np.exp(loss))
