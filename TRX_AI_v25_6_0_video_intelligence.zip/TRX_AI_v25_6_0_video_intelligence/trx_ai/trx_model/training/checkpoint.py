# -*- coding: utf-8 -*-
"""
checkpoint.py -- Checkpoint واقعی (بخشِ بیست‌ودوم سند).

فقط وزن کافی نیست -- Resume واقعی نیازمندِ Optimizer state، epoch/step
فعلی، Lossها، config، هویتِ tokenizer، vocab_size، seed، و بهترین
Validation Loss است. اگر هرکدام غایب باشد، ``load_checkpoint`` صریحاً
خطا می‌دهد (نه بازیابیِ نصفه‌وخاموش).
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

import numpy as np

from .autograd_cache import build_param_map
from .optim import AdamW

REQUIRED_KEYS = (
    "epoch",
    "step",
    "training_loss",
    "validation_loss",
    "best_validation_loss",
    "config",
    "tokenizer_vocab_size",
    "tokenizer_num_merges",
    "seed",
)


@dataclass
class CheckpointMeta:
    epoch: int
    step: int
    training_loss: float
    validation_loss: Optional[float]
    best_validation_loss: Optional[float]
    tokenizer_vocab_size: int
    tokenizer_num_merges: int
    seed: int


def save_checkpoint(path: str, model, optimizer: AdamW, tokenizer, meta: CheckpointMeta) -> None:
    """ذخیره‌یِ کاملِ Checkpoint: ``<path>.weights.npz`` (وزن‌هایِ مدل
    + m/v اپتیمایزر) + ``<path>.meta.json`` (بقیه‌یِ فرادادهِ بخشِ
    ۲۲ سند، از جمله config کاملِ مدل)."""
    path = str(path)
    params = build_param_map(model)

    weights_payload = {f"param::{k}": v for k, v in params.items()}
    for k, v in optimizer.m.items():
        weights_payload[f"adamw_m::{k}"] = v
    for k, v in optimizer.v.items():
        weights_payload[f"adamw_v::{k}"] = v
    np.savez(path + ".weights.npz", **weights_payload)

    meta_dict = asdict(meta)
    meta_dict["config"] = asdict(model.config) if hasattr(model.config, "__dataclass_fields__") else dict(model.config.__dict__)
    meta_dict["optimizer"] = {
        "lr": optimizer.lr,
        "beta1": optimizer.beta1,
        "beta2": optimizer.beta2,
        "eps": optimizer.eps,
        "weight_decay": optimizer.weight_decay,
        "step_count": optimizer.step_count,
    }
    with open(path + ".meta.json", "w", encoding="utf-8") as f:
        json.dump(meta_dict, f, ensure_ascii=False, indent=2)


def load_checkpoint(path: str, model, optimizer: AdamW, tokenizer) -> CheckpointMeta:
    """بازیابیِ کامل. اگر vocab_size/تعدادِ merges توکنایزرِ فعلی با
    Checkpoint نخوانَد، خطایِ صریح (بخشِ ۳۴: بدونِ سکوت رویِ ناهم‌خوانی)."""
    path = str(path)
    meta_file = Path(path + ".meta.json")
    weights_file = Path(path + ".weights.npz")
    if not meta_file.exists() or not weights_file.exists():
        raise FileNotFoundError(f"فایل‌هایِ Checkpoint در مسیرِ '{path}' پیدا نشدند.")

    with open(meta_file, "r", encoding="utf-8") as f:
        meta_dict = json.load(f)

    for key in REQUIRED_KEYS:
        if key not in meta_dict:
            raise ValueError(f"Checkpoint ناقص است -- کلیدِ اجباریِ '{key}' وجود ندارد.")

    if meta_dict["tokenizer_vocab_size"] != tokenizer.vocab_size:
        raise ValueError(
            "vocab_size توکنایزرِ فعلی با Checkpoint یکسان نیست -- Resume نامعتبر خواهد بود."
        )

    data = np.load(str(weights_file))
    params = build_param_map(model)
    for key in params:
        npz_key = f"param::{key}"
        if npz_key not in data:
            raise ValueError(f"وزنِ '{key}' در Checkpoint موجود نیست.")
        params[key][...] = data[npz_key]

    optimizer.m = {}
    optimizer.v = {}
    for npz_key in data.files:
        if npz_key.startswith("adamw_m::"):
            optimizer.m[npz_key[len("adamw_m::"):]] = np.array(data[npz_key], dtype=np.float64)
        elif npz_key.startswith("adamw_v::"):
            optimizer.v[npz_key[len("adamw_v::"):]] = np.array(data[npz_key], dtype=np.float64)

    opt_meta = meta_dict.get("optimizer", {})
    optimizer.lr = opt_meta.get("lr", optimizer.lr)
    optimizer.beta1 = opt_meta.get("beta1", optimizer.beta1)
    optimizer.beta2 = opt_meta.get("beta2", optimizer.beta2)
    optimizer.eps = opt_meta.get("eps", optimizer.eps)
    optimizer.weight_decay = opt_meta.get("weight_decay", optimizer.weight_decay)
    optimizer.step_count = opt_meta.get("step_count", optimizer.step_count)

    return CheckpointMeta(
        epoch=meta_dict["epoch"],
        step=meta_dict["step"],
        training_loss=meta_dict["training_loss"],
        validation_loss=meta_dict["validation_loss"],
        best_validation_loss=meta_dict["best_validation_loss"],
        tokenizer_vocab_size=meta_dict["tokenizer_vocab_size"],
        tokenizer_num_merges=meta_dict["tokenizer_num_merges"],
        seed=meta_dict["seed"],
    )
