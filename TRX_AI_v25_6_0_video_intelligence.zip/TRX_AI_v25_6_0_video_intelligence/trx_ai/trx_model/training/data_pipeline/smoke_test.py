# -*- coding: utf-8 -*-
"""
smoke_test.py -- Smoke Test اجباری (بخشِ ۱۱ سندِ فازِ دوم).

نقل‌قولِ مستقیمِ سند: «با شکستِ هر مورد، آموزشِ اصلی متوقف شود.» --
پس ``run_smoke_test`` با اولین شکست ``SmokeTestFailure`` می‌دهد
(نه ادامه‌دادنِ بقیه‌ی موارد و گزارشِ نهایی)، و همچنان یک گزارشِ
کاملِ «تا همین‌جا چه چیزی پاس شد» برمی‌گرداند تا مشخص باشد دقیقاً
کجا خراب شد.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from ..autograd_cache import build_param_map, forward_with_cache
from ..backward import backward, check_gradients_finite
from ..checkpoint import CheckpointMeta, load_checkpoint, save_checkpoint
from ..evaluator import evaluate
from ..losses import cross_entropy_loss
from ..optim import AdamW, clip_gradients


class SmokeTestFailure(RuntimeError):
    """با ذکرِ دقیقِ این‌که کدام موردِ بخشِ ۱۱ شکست خورد."""


@dataclass
class SmokeTestReport:
    passed_checks: List[str] = field(default_factory=list)
    failed_check: Optional[str] = None
    failure_reason: Optional[str] = None


def run_smoke_test(model, tokenizer, train_sequences, val_sequences) -> SmokeTestReport:
    """اجرایِ دقیقِ چک‌لیستِ بخشِ ۱۱ سند، به‌همان ترتیب:

    dataset خالی نیست -> tokenizer معتبر -> شکلِ input/target درست ->
    forward بدون NaN -> loss finite -> backward بدون NaN -> gradientها
    finite -> وزن‌ها پس از update تغییر می‌کنند -> checkpoint
    save/load -> validation اجرا می‌شود -> generation اجرا می‌شود.
    """
    report = SmokeTestReport()

    def _fail(name: str, reason: str) -> None:
        report.failed_check = name
        report.failure_reason = reason
        raise SmokeTestFailure(f"[{name}] {reason}")

    # ۱. dataset خالی نباشد
    if not train_sequences:
        _fail("dataset_not_empty", "train_sequences خالی است.")
    if not val_sequences:
        _fail("dataset_not_empty", "val_sequences خالی است.")
    report.passed_checks.append("dataset_not_empty")

    # ۲. tokenizer معتبر باشد
    if tokenizer.vocab_size != model.config.vocab_size:
        _fail("tokenizer_valid", f"vocab_size توکنایزر ({tokenizer.vocab_size}) با مدل ({model.config.vocab_size}) نمی‌خواند.")
    probe = tokenizer.decode(tokenizer.encode("سلام"))
    if not isinstance(probe, str):
        _fail("tokenizer_valid", "decode(encode(...)) رشته برنمی‌گرداند.")
    report.passed_checks.append("tokenizer_valid")

    # ۳. شکلِ input و target درست باشد
    seq = train_sequences[0]
    if len(seq.input_ids) != len(seq.target_ids):
        _fail("input_target_shape", f"طولِ input ({len(seq.input_ids)}) با target ({len(seq.target_ids)}) یکسان نیست.")
    if len(seq.input_ids) == 0:
        _fail("input_target_shape", "دنباله‌ی اولِ train_sequences طولِ صفر دارد.")
    report.passed_checks.append("input_target_shape")

    # ۴. forward بدون NaN
    logits, cache = forward_with_cache(model, seq.input_ids)
    if not np.all(np.isfinite(logits)):
        _fail("forward_no_nan", "logits شاملِ NaN/Inf است.")
    report.passed_checks.append("forward_no_nan")

    # ۵. loss finite
    loss, d_logits = cross_entropy_loss(logits, seq.target_ids)
    if not np.isfinite(loss):
        _fail("loss_finite", f"loss غیرِ finite است: {loss}")
    report.passed_checks.append("loss_finite")

    # ۶. backward بدون NaN  &  ۷. gradientها finite
    grads = backward(model, cache, d_logits)
    try:
        check_gradients_finite(grads)
    except FloatingPointError as e:
        _fail("backward_gradients_finite", str(e))
    report.passed_checks.append("backward_no_nan")
    report.passed_checks.append("gradients_finite")

    # ۸. وزن‌ها پس از update تغییر کنند
    params = build_param_map(model)
    before = {k: v.copy() for k, v in params.items()}
    clip_gradients(grads, max_norm=1.0)
    optimizer = AdamW(param_names=params.keys(), lr=1e-2)
    optimizer.step(params, grads)
    if not any(not np.allclose(before[k], params[k]) for k in params):
        _fail("weights_change_after_update", "هیچ وزنی پس از AdamW.step تغییر نکرد.")
    report.passed_checks.append("weights_change_after_update")

    # ۹. checkpoint ذخیره و load شود
    with tempfile.TemporaryDirectory() as tmp_dir:
        ckpt_path = os.path.join(tmp_dir, "smoke_ckpt")
        meta = CheckpointMeta(
            epoch=0, step=1, training_loss=loss, validation_loss=None, best_validation_loss=None,
            tokenizer_vocab_size=tokenizer.vocab_size, tokenizer_num_merges=len(tokenizer.merges), seed=0,
        )
        try:
            save_checkpoint(ckpt_path, model, optimizer, tokenizer, meta)
            load_checkpoint(ckpt_path, model, optimizer, tokenizer)
        except Exception as e:  # noqa: BLE001 -- عمداً وسیع: هر خطایی یعنی شکستِ همین چک
            _fail("checkpoint_save_load", str(e))
    report.passed_checks.append("checkpoint_save_load")

    # ۱۰. validation اجرا شود
    try:
        val_report = evaluate(model, val_sequences)
        if not np.isfinite(val_report.average_loss):
            _fail("validation_runs", "Validation Loss غیرِ finite است.")
    except Exception as e:  # noqa: BLE001
        _fail("validation_runs", str(e))
    report.passed_checks.append("validation_runs")

    # ۱۱. generation اجرا شود
    try:
        ids = tokenizer.encode("تست", add_bos=True)
        out_logits = model.forward(np.asarray(ids[-model.config.max_seq_len :], dtype=np.int64))
        if not np.all(np.isfinite(out_logits)):
            _fail("generation_runs", "logitsِ generation شاملِ NaN/Inf است.")
    except Exception as e:  # noqa: BLE001
        _fail("generation_runs", str(e))
    report.passed_checks.append("generation_runs")

    return report
