# -*- coding: utf-8 -*-
"""
cleaning.py -- پاک‌سازیِ سند (بخشِ ۴ سندِ فازِ دوم).

قاعده‌یِ صریحِ سند: «نباید بدونِ دلیل علائمِ نگارشی، اعداد، کلماتِ
انگلیسیِ داخلِ فارسی، کدِ کوتاه یا نیم‌فاصله حذف شوند.» -- پس این
ماژول محافظه‌کار است: فقط چیزهایی که صریحاً در سند فهرست شده حذف
می‌شوند، نه هر چیزِ «غریب».
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

ZWNJ = "\u200c"  # نیم‌فاصله‌ی فارسی -- هرگز حذف نمی‌شود

_HTML_TAG_RE = re.compile(r"<[^>]+>")
_CONTROL_CHARS_RE = re.compile(
    "[" + "".join(chr(c) for c in range(0x00, 0x20) if c not in (0x09, 0x0A)) + chr(0x7F) + "]"
)
_MULTI_SPACE_RE = re.compile(r"[ \t]+")
_MULTI_NEWLINE_RE = re.compile(r"\n{3,}")
_TRAILING_SPACE_RE = re.compile(r"[ \t]+\n")

MIN_MEANINGFUL_LENGTH = 20  # کاراکتر -- بخشِ ۴: «متنِ بسیار کوتاه و بی‌معنا»
MAX_UNUSUAL_CHAR_RATIO = 0.25  # بخشِ ۴: «کنترلِ نسبتِ کاراکترهایِ غیرعادی»


@dataclass
class CleaningResult:
    cleaned_text: Optional[str]
    kept: bool
    reason: Optional[str]  # اگر kept=False، دلیلِ صریحِ حذف (بخشِ ۴: «ثبتِ دلیلِ حذفِ هر سند»)


def _strip_html(text: str) -> str:
    return _HTML_TAG_RE.sub(" ", text)


def _normalize_whitespace(text: str) -> str:
    """یکسان‌سازیِ فاصله‌ها/newline -- بدونِ دست‌زدن به نیم‌فاصله (ZWNJ)."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _TRAILING_SPACE_RE.sub("\n", text)
    text = _MULTI_SPACE_RE.sub(" ", text)
    text = _MULTI_NEWLINE_RE.sub("\n\n", text)
    return text.strip()


def _unusual_char_ratio(text: str) -> float:
    """نسبتِ کاراکترهایی که نه حرف/رقم‌اند، نه فاصله/newline، نه از
    علائمِ نگارشیِ معمولِ فارسی/انگلیسی -- بخشِ ۵: «درصدِ کاراکترهایِ
    غیرعادی»."""
    if not text:
        return 0.0
    normal_punct = set(".,!?;:؛،؟!()[]{}\"'`-_/\\@#$%^&*+=~<>|\n\t ")
    unusual = sum(1 for ch in text if not (ch.isalnum() or ch in normal_punct or ch == ZWNJ))
    return unusual / len(text)


def clean_document(raw_text: str) -> CleaningResult:
    """پاک‌سازیِ یک سند طبقِ بخشِ ۴ سند. اگر سند باید حذف شود،
    ``kept=False`` و ``reason`` صریح برمی‌گردد -- بدونِ سکوت."""
    if raw_text is None:
        return CleaningResult(cleaned_text=None, kept=False, reason="empty_text")

    text = _strip_html(raw_text)
    text = _CONTROL_CHARS_RE.sub("", text)
    text = _normalize_whitespace(text)

    if not text:
        return CleaningResult(cleaned_text=None, kept=False, reason="empty_text")

    if len(text) < MIN_MEANINGFUL_LENGTH:
        return CleaningResult(cleaned_text=None, kept=False, reason="too_short")

    ratio = _unusual_char_ratio(text)
    if ratio > MAX_UNUSUAL_CHAR_RATIO:
        return CleaningResult(cleaned_text=None, kept=False, reason=f"unusual_char_ratio={ratio:.2f}")

    return CleaningResult(cleaned_text=text, kept=True, reason=None)


def remove_duplicate_lines(text: str) -> str:
    """حذفِ خطوطِ تکراری *داخلِ* یک سند (بخشِ ۴)، با حفظِ ترتیبِ اولین
    ظهور. خطوطِ خالی حذف نمی‌شوند (ساختارِ پاراگراف حفظ می‌شود)."""
    seen = set()
    out_lines = []
    for line in text.split("\n"):
        stripped = line.strip()
        if stripped == "":
            out_lines.append(line)
            continue
        if stripped in seen:
            continue
        seen.add(stripped)
        out_lines.append(line)
    return "\n".join(out_lines)
