# -*- coding: utf-8 -*-
"""
corpus_builder.py -- ساختِ Corpusِ نسخه‌یِ اول (بخشِ ۳ و ۷ سندِ فازِ
دوم).

هر سندِ خام به چند «Document» کوچک‌تر (سطحِ پاراگراف) شکسته می‌شود
تا با خواسته‌یِ بخشِ ۷ («۱۰۰ تا ۵۰۰ سندِ تمیز، متنِ کوتاه و متوسط»)
سازگار باشد -- به‌جایِ چند فایلِ بزرگ.

زنجیره‌یِ این ماژول دقیقاً بخشِ ۲ سند است:
Dataset -> Cleaning -> Deduplication -> Document Split
"""

from __future__ import annotations

import glob
import json
import os
import re
from dataclasses import asdict, dataclass, field
from typing import List, Optional, Tuple

from . import quality as quality_mod
from .cleaning import clean_document, remove_duplicate_lines
from .dedup import deduplicate

_PARAGRAPH_SPLIT_RE = re.compile(r"\n\s*\n+")


@dataclass
class Document:
    doc_id: str
    source: str
    language: str
    raw_text: str
    cleaned_text: Optional[str] = None
    char_length: int = 0
    status: str = "pending"  # pending | kept | removed
    removal_reason: Optional[str] = None
    quality_score: Optional[float] = None
    quality_tier: Optional[str] = None


@dataclass
class CorpusManifest:
    total_raw_paragraphs: int
    kept_documents: int
    removed_by_cleaning: int
    removed_by_dedup: int
    removed_by_quality: int
    tier_counts: dict
    documents: List[dict] = field(default_factory=list)


def _detect_language(text: str) -> str:
    persian_chars = sum(1 for ch in text if "\u0600" <= ch <= "\u06FF")
    latin_chars = sum(1 for ch in text if ch.isascii() and ch.isalpha())
    if persian_chars == 0 and latin_chars == 0:
        return "unknown"
    return "fa" if persian_chars >= latin_chars else "en"


def load_root_markdown_corpus(root_dir: str) -> List[Tuple[str, str]]:
    """بخشِ ۷ سند: پیکره‌یِ واقعیِ خودِ پروژه (همان فایل‌هایِ ``*.md``
    ریشه که توکنایزرِ v25.4.4 هم ازش استفاده کرد) -- «بدونِ اینترنت/
    دیتاستِ بیرونی»."""
    sources = []
    for path in sorted(glob.glob(os.path.join(root_dir, "*.md"))):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            sources.append((os.path.basename(path), f.read()))
    return sources


def split_into_paragraph_documents(sources: List[Tuple[str, str]], min_chars: int = 20, max_docs: int = 500) -> List[Document]:
    """هر منبع (سندِ خام) را به Documentهایِ سطحِ پاراگراف می‌شکند
    (بخشِ ۷: «متنِ کوتاه و متوسط»، «۱۰۰ تا ۵۰۰ سند»)."""
    documents: List[Document] = []
    for source_name, raw_text in sources:
        paragraphs = [p.strip() for p in _PARAGRAPH_SPLIT_RE.split(raw_text) if p.strip()]
        for i, para in enumerate(paragraphs):
            if len(para) < min_chars:
                continue
            doc_id = f"{source_name}::p{i:04d}"
            documents.append(
                Document(
                    doc_id=doc_id,
                    source=source_name,
                    language=_detect_language(para),
                    raw_text=para,
                    char_length=len(para),
                )
            )
            if len(documents) >= max_docs:
                return documents
    return documents


def run_cleaning_stage(documents: List[Document]) -> None:
    """اجرایِ Cleaning رویِ همه‌یِ Documentها (in-place). بخشِ ۴ سند."""
    for doc in documents:
        result = clean_document(doc.raw_text)
        if not result.kept:
            doc.status = "removed"
            doc.removal_reason = result.reason
            continue
        cleaned = remove_duplicate_lines(result.cleaned_text)
        doc.cleaned_text = cleaned
        doc.char_length = len(cleaned)
        doc.status = "kept"


def run_quality_stage(documents: List[Document], keep_tiers: Tuple[str, ...] = ("A", "B")) -> None:
    """بخشِ ۵ سند: امتیازدهی + رده‌بندی. Documentهایی که رده‌شان در
    ``keep_tiers`` نیست، ``status="removed"`` می‌شوند (بخشِ ۵: «در
    corpus اصلی از A و مقدارِ کنترل‌شده‌ای از B استفاده شود»)."""
    for doc in documents:
        if doc.status != "kept" or doc.cleaned_text is None:
            continue
        qs = quality_mod.score_document(doc.cleaned_text)
        doc.quality_score = qs.score
        doc.quality_tier = qs.tier
        if qs.tier not in keep_tiers:
            doc.status = "removed"
            doc.removal_reason = f"quality_tier={qs.tier}"


def build_corpus_v1(root_dir: str, output_dir: str, max_docs: int = 500, seed: int = 0) -> CorpusManifest:
    """زنجیره‌یِ کاملِ بخشِ ۲: Dataset->Cleaning->Deduplication->
    Document Split. خروجی در ``output_dir/manifest.json`` نوشته
    می‌شود (بخشِ ۲۰: «corpus manifest»)."""
    os.makedirs(output_dir, exist_ok=True)

    sources = load_root_markdown_corpus(root_dir)
    documents = split_into_paragraph_documents(sources, max_docs=max_docs)
    total_raw = len(documents)

    run_cleaning_stage(documents)
    removed_by_cleaning = sum(1 for d in documents if d.status == "removed")

    kept_docs = [d for d in documents if d.status == "kept"]
    deduped, dedup_report = deduplicate(kept_docs, text_attr="cleaned_text")
    dedup_ids = {d.doc_id for d in deduped}
    for d in kept_docs:
        if d.doc_id not in dedup_ids:
            d.status = "removed"
            d.removal_reason = "duplicate"

    run_quality_stage(documents)
    removed_by_quality = sum(1 for d in documents if d.removal_reason and d.removal_reason.startswith("quality_tier"))

    tier_counts = {"A": 0, "B": 0, "C": 0}
    for d in documents:
        if d.quality_tier:
            tier_counts[d.quality_tier] += 1

    manifest = CorpusManifest(
        total_raw_paragraphs=total_raw,
        kept_documents=sum(1 for d in documents if d.status == "kept"),
        removed_by_cleaning=removed_by_cleaning,
        removed_by_dedup=dedup_report.removed_duplicates,
        removed_by_quality=removed_by_quality,
        tier_counts=tier_counts,
        documents=[asdict(d) for d in documents],
    )

    with open(os.path.join(output_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(asdict(manifest), f, ensure_ascii=False, indent=2)

    return manifest


def load_manifest(output_dir: str) -> List[Document]:
    with open(os.path.join(output_dir, "manifest.json"), "r", encoding="utf-8") as f:
        data = json.load(f)
    return [Document(**d) for d in data["documents"]]
