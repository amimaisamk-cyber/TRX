# -*- coding: utf-8 -*-
"""
resource_monitor.py -- مانیتورِ منابع در حینِ آموزش (بخشِ ۱۶ سندِ
فازِ دوم).

قبل از آموزش: فضایِ آزاد + RAMِ تخمینی (با
``training/resource_guard.py``ی فازِ اول، دست‌نخورده).
در حینِ آموزش: بررسیِ دوره‌ایِ RAM (با ``psutil`` -- که از قبل در
``requirements-core.txt`` است)، و در عبور از حد، ``should_stop=True``
برمی‌گردد تا ``trainer`` بتواند graceful stop + checkpoint انجام دهد.

اگر ``psutil`` در دسترس نباشد (محیطِ محدود)، این ماژول کرش نمی‌کند
-- فقط RAM را نمی‌تواند اندازه بگیرد و صریحاً همین را در گزارش
می‌گوید (بخشِ ۳۴ فازِ اول: بدونِ سکوت رویِ ناتوانی)."""

from __future__ import annotations

import logging
import logging.handlers
import os
import shutil
from dataclasses import dataclass
from typing import Optional

try:
    import psutil  # type: ignore
except ImportError:  # pragma: no cover - محیط بدون psutil
    psutil = None


@dataclass
class ResourceCheck:
    ram_available_mb: Optional[float]
    disk_free_mb: float
    should_stop: bool
    reason: str = ""


def check_disk_space(path: str, min_free_mb: float = 100.0) -> float:
    """فضایِ آزادِ دیسک در مگابایت (بخشِ ۱۶: «قبل از آموزش، فضایِ آزاد
    را بررسی کن»)."""
    usage = shutil.disk_usage(path)
    return usage.free / (1024 ** 2)


class ResourceMonitor:
    """بخشِ ۱۶ سند: بررسیِ دوره‌ایِ RAM + حدِ منابع + graceful stop."""

    def __init__(self, max_ram_mb: Optional[float] = None, min_disk_free_mb: float = 50.0, workdir: str = "."):
        self.max_ram_mb = max_ram_mb
        self.min_disk_free_mb = min_disk_free_mb
        self.workdir = workdir

    def check(self) -> ResourceCheck:
        disk_free = check_disk_space(self.workdir, self.min_disk_free_mb)
        ram_available = None
        if psutil is not None:
            ram_available = psutil.virtual_memory().available / (1024 ** 2)

        should_stop = False
        reason = ""
        if disk_free < self.min_disk_free_mb:
            should_stop = True
            reason = f"فضایِ آزادِ دیسک ({disk_free:.1f}MB) از حدِ مجاز ({self.min_disk_free_mb}MB) کمتر است."
        elif self.max_ram_mb is not None and ram_available is not None and ram_available < self.max_ram_mb:
            should_stop = True
            reason = f"RAMِ آزاد ({ram_available:.1f}MB) از حدِ ایمنِ ({self.max_ram_mb}MB) کمتر است."

        return ResourceCheck(ram_available_mb=ram_available, disk_free_mb=disk_free, should_stop=should_stop, reason=reason)


def make_rotating_logger(name: str, log_path: str, max_bytes: int = 1_000_000, backup_count: int = 3) -> logging.Logger:
    """چرخشِ لاگ (بخشِ ۱۶: «لاگ‌ها را چرخشی کن») -- با
    ``RotatingFileHandler`` استانداردِ خودِ کتابخانه‌یِ پایتون، نه
    پیاده‌سازیِ دستی."""
    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers = [h for h in logger.handlers if not isinstance(h, logging.handlers.RotatingFileHandler)]
    handler = logging.handlers.RotatingFileHandler(log_path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
    return logger
