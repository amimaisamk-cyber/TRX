# -*- coding: utf-8 -*-
"""
generalization_test.py -- Generalization Test (بخشِ ۱۹/بخشِ ۱۲ سندِ
فازِ دوم: «مدل دچار تکرارِ بی‌پایان نشود»، «مدل روی prompt جدید نیز
الگو نشان دهد»).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .fixed_prompts import generate_with_top_k

UNSEEN_PROMPTS: List[str] = [
    "در آینده‌ی نزدیک، فناوری",
    "یکی از مهم‌ترین درس‌های زندگی این است که",
    "The weather today is",
]


@dataclass
class RepetitionCheck:
    prompt: str
    output: str
    has_infinite_repetition: bool
    repeated_ngram: str = ""


def _has_repeating_ngram(text: str, n: int = 4, min_repeats: int = 3) -> "tuple[bool, str]":
    """اگر یک n-gram (رویِ کاراکتر، برای پوششِ فارسی/انگلیسیِ هردو)
    حداقل ``min_repeats`` بارِ متوالی تکرار شود، «تکرارِ بی‌پایان»
    تشخیص داده می‌شود."""
    if len(text) < n * min_repeats:
        return False, ""
    for start in range(len(text) - n * min_repeats + 1):
        gram = text[start : start + n]
        if not gram.strip():
            continue
        ok = all(text[start + k * n : start + (k + 1) * n] == gram for k in range(min_repeats))
        if ok:
            return True, gram
    return False, ""


def run_generalization_test(model, tokenizer, prompts: List[str] = None, max_new_tokens: int = 30, seed: int = 0) -> List[RepetitionCheck]:
    prompts = prompts if prompts is not None else UNSEEN_PROMPTS
    results = []
    for prompt in prompts:
        output = generate_with_top_k(model, tokenizer, prompt, max_new_tokens=max_new_tokens, seed=seed)
        has_rep, gram = _has_repeating_ngram(output)
        results.append(RepetitionCheck(prompt=prompt, output=output, has_infinite_repetition=has_rep, repeated_ngram=gram))
    return results
