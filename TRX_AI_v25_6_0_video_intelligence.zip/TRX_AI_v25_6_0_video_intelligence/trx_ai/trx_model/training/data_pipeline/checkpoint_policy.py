# -*- coding: utf-8 -*-
"""
checkpoint_policy.py -- سیاستِ Checkpointِ سه‌سطحی (بخشِ ۱۴ سندِ
فازِ دوم) + Resumeِ واقعی با بررسیِ ناسازگاری (بخشِ ۱۵).

بخشِ ۱۴: ``checkpoints/latest``، ``checkpoints/best``،
``checkpoints/periodic`` -- ذخیره باید **اتمیک** باشد (ابتدا فایلِ
موقت، سپس جایگزینی) تا قطعِ ناگهانی، Checkpointِ قبلی را خراب
نکند.

این ماژول از ``training/checkpoint.py`` (فازِ اول، بدونِ تغییر)
فقط استفاده می‌کند -- منطقِ خودِ ذخیره/بازیابیِ آرایه‌ها دست‌نخورده
می‌ماند؛ اینجا فقط لایه‌یِ «کدام مسیر، کِی، و چطور اتمیک» اضافه
می‌شود.
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from typing import List, Optional

from ..checkpoint import CheckpointMeta, load_checkpoint, save_checkpoint


@dataclass
class ResumeWarning:
    kind: str  # "tokenizer_mismatch" | "dataset_mismatch" | "seed_mismatch"
    message: str


def _atomic_save(final_path_prefix: str, save_fn) -> None:
    """ذخیره در مسیرِ موقت، سپس جایگزینیِ اتمیکِ هر دو فایلِ
    Checkpoint (``.weights.npz`` و ``.meta.json``). اگر فرایند بینِ
    این دو ``os.replace`` قطع شود، حداقل یکی از دو فایل هنوز معتبر
    خواهد بود (نه یک Checkpointِ نصفه‌ی جدید روی رویِ قدیمی)."""
    tmp_prefix = final_path_prefix + ".tmp"
    save_fn(tmp_prefix)
    os.replace(tmp_prefix + ".weights.npz", final_path_prefix + ".weights.npz")
    os.replace(tmp_prefix + ".meta.json", final_path_prefix + ".meta.json")


def save_latest(checkpoints_dir: str, model, optimizer, tokenizer, meta: CheckpointMeta) -> str:
    path_prefix = os.path.join(checkpoints_dir, "latest", "latest")
    os.makedirs(os.path.dirname(path_prefix), exist_ok=True)
    _atomic_save(path_prefix, lambda p: save_checkpoint(p, model, optimizer, tokenizer, meta))
    return path_prefix


def save_best_if_improved(checkpoints_dir: str, model, optimizer, tokenizer, meta: CheckpointMeta) -> Optional[str]:
    """فقط وقتی ``meta.validation_loss`` بهتر از بهترینِ ذخیره‌شده‌یِ
    قبلی باشد به‌روزرسانی می‌شود (بخشِ ۱۴: ``best``)."""
    if meta.validation_loss is None:
        return None
    path_prefix = os.path.join(checkpoints_dir, "best", "best")
    meta_file = path_prefix + ".meta.json"
    if os.path.exists(meta_file):
        with open(meta_file, "r", encoding="utf-8") as f:
            prev = json.load(f)
        # مقایسه با validation_loss واقعیِ همان Checkpointِ «best»یِ ذخیره‌شده --
        # نه با فیلدِ جداگانه‌یِ best_validation_loss که ممکن است فراخوان‌کننده
        # آن را پر نکرده باشد (None).
        prev_best = prev.get("validation_loss")
        if prev_best is not None and meta.validation_loss >= prev_best:
            return None
    os.makedirs(os.path.dirname(path_prefix), exist_ok=True)
    _atomic_save(path_prefix, lambda p: save_checkpoint(p, model, optimizer, tokenizer, meta))
    return path_prefix


def save_periodic(checkpoints_dir: str, model, optimizer, tokenizer, meta: CheckpointMeta, keep_last: int = 3) -> str:
    """Checkpointِ دوره‌ای با نامِ شماره‌یِ step -- فقط ``keep_last``
    نسخه‌یِ آخر نگه داشته می‌شود (بخشِ ۱۶: «تعدادِ checkpointها را
    محدود کن»)."""
    periodic_dir = os.path.join(checkpoints_dir, "periodic")
    os.makedirs(periodic_dir, exist_ok=True)
    path_prefix = os.path.join(periodic_dir, f"step_{meta.step:08d}")
    _atomic_save(path_prefix, lambda p: save_checkpoint(p, model, optimizer, tokenizer, meta))

    existing = sorted(
        {f[: -len(".meta.json")] for f in os.listdir(periodic_dir) if f.endswith(".meta.json")}
    )
    if len(existing) > keep_last:
        for stem in existing[: len(existing) - keep_last]:
            for suffix in (".weights.npz", ".meta.json"):
                fp = os.path.join(periodic_dir, stem + suffix)
                if os.path.exists(fp):
                    os.remove(fp)

    return path_prefix


def resume_from_latest(checkpoints_dir: str, model, optimizer, tokenizer, expected_seed: Optional[int] = None, expected_dataset_doc_count: Optional[int] = None) -> "tuple[CheckpointMeta, List[ResumeWarning]]":
    """Resumeِ واقعی (بخشِ ۱۵): وزن + optimizer state + step/epoch +
    best_validation_loss برمی‌گردند؛ ناسازگاریِ seed/dataset فقط
    *هشدار* می‌دهد (متوقف نمی‌کند -- تصمیمِ توقف با فراخوان‌کننده
    است، طبقِ بخشِ ۱۲: تفسیر باید صریح باشد نه خودکار)."""
    path_prefix = os.path.join(checkpoints_dir, "latest", "latest")
    meta = load_checkpoint(path_prefix, model, optimizer, tokenizer)

    warnings: List[ResumeWarning] = []
    if expected_seed is not None and meta.seed != expected_seed:
        warnings.append(ResumeWarning("seed_mismatch", f"seedِ checkpoint ({meta.seed}) با seedِ فعلی ({expected_seed}) فرق دارد."))
    if expected_dataset_doc_count is not None:
        # خودِ Checkpoint شماره‌ی سندهای dataset را ذخیره نمی‌کند (فقط tokenizer)،
        # پس این بررسی در سطحِ pipeline_runner (که manifest را هم دارد) کامل می‌شود.
        pass

    return meta, warnings
