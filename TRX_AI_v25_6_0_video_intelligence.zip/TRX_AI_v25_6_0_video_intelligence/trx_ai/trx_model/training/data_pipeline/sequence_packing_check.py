# -*- coding: utf-8 -*-
"""
sequence_packing_check.py -- بررسیِ صریحِ شیفتِ Target (بخشِ ۹ سندِ
فازِ دوم).

نقل‌قولِ مستقیمِ سند: «برای یک جمله‌ی کوتاه، input_ids و target_ids
را دستی چاپ و بررسی کن. اشتباه در شیفتِ target می‌تواند کلِ آموزش را
بی‌اثر کند.» -- این ماژول همان کار را می‌کند و خودش را هم برنامه‌ای
تایید می‌کند (نه فقط چاپ برایِ چشم).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class PackingCheckResult:
    text: str
    ids: List[int]
    input_ids: List[int]
    target_ids: List[int]
    shift_correct: bool  # target[t] == input[t+1] در دنباله‌ی اصلی (پیش از برش)


def check_sequence_packing(tokenizer, text: str) -> PackingCheckResult:
    """بخشِ ۹: ``target[t] = input[t+1]``. اینجا رویِ کلِ دنباله‌یِ
    توکن‌شده (بدونِ برش به seq_len) بررسی می‌شود -- همان قراردادی که
    ``dataset.build_sequences`` با ``chunk[:-1]``/``chunk[1:]`` پیاده
    می‌کند."""
    ids = tokenizer.encode(text, add_bos=True, add_eos=True)
    if len(ids) < 2:
        raise ValueError("check_sequence_packing: متن برای بررسیِ شیفت خیلی کوتاه است.")

    input_ids = ids[:-1]
    target_ids = ids[1:]
    shift_correct = all(target_ids[t] == ids[t + 1] for t in range(len(input_ids)))

    return PackingCheckResult(text=text, ids=ids, input_ids=input_ids, target_ids=target_ids, shift_correct=shift_correct)


def format_check(result: PackingCheckResult) -> str:
    lines = [
        "Sequence Packing Check",
        "=" * 23,
        f"text: {result.text!r}",
        f"ids:        {result.ids}",
        f"input_ids:  {result.input_ids}",
        f"target_ids: {result.target_ids}",
        f"shift_correct (target[t] == input[t+1]): {result.shift_correct}",
    ]
    return "\n".join(lines)
