# -*- coding: utf-8 -*-
"""
tokenizer_report.py -- بررسیِ Tokenizer (بخشِ ۸ سندِ فازِ دوم).

توکنایزرِ ``ByteLevelBPETokenizer`` ذاتاً lossless است (هر بایتِ
UTF-8 قابلِ‌رمزگشایی است -- تستِ round-trip در
``tests/test_native_model.py`` هم همین را می‌سنجد)، پس این ماژول
«unk» را کشف نمی‌کند به این معنا که اصلاً چنین توکنی وجود ندارد؛
به‌جایش موادِ عملیِ بخشِ ۸ را می‌سنجد: آیا round-trip واقعاً بدونِ
افتِ اطلاعات است، آیا طولِ توالی غیرعادی می‌شود، و آیا
special-tokenها (bos/eos/pad) به‌درستی جدا هستند.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class TokenizerCheckResult:
    sample_text: str
    encoded_len: int
    roundtrip_ok: bool
    contains_special_token_leak: bool  # آیا متنِ decode شده شاملِ کاراکترِ نامعتبر شد؟


@dataclass
class TokenizerReport:
    n_samples: int
    all_roundtrip_ok: bool
    max_encoded_len: int
    min_encoded_len: int
    avg_chars_per_token: float
    checks: List[TokenizerCheckResult]


def run_tokenizer_report(tokenizer, sample_texts: List[str]) -> TokenizerReport:
    """اجرایِ ``text -> encode -> decode`` رویِ ``sample_texts`` و
    بررسیِ موادِ بخشِ ۸ سند."""
    if not sample_texts:
        raise ValueError("run_tokenizer_report: sample_texts خالی است.")

    checks: List[TokenizerCheckResult] = []
    total_chars = 0
    total_tokens = 0

    for text in sample_texts:
        ids = tokenizer.encode(text)
        decoded = tokenizer.decode(ids)
        roundtrip_ok = decoded == text
        leak = any(tok_id >= tokenizer.base_vocab_size for tok_id in ids)  # special tokenها هرگز از encode(text) بدون add_bos/add_eos نباید بیایند
        checks.append(
            TokenizerCheckResult(
                sample_text=text[:60],
                encoded_len=len(ids),
                roundtrip_ok=roundtrip_ok,
                contains_special_token_leak=leak,
            )
        )
        total_chars += len(text)
        total_tokens += len(ids)

    lengths = [c.encoded_len for c in checks]
    return TokenizerReport(
        n_samples=len(checks),
        all_roundtrip_ok=all(c.roundtrip_ok for c in checks),
        max_encoded_len=max(lengths),
        min_encoded_len=min(lengths),
        avg_chars_per_token=(total_chars / total_tokens) if total_tokens else 0.0,
        checks=checks,
    )


def format_report(report: TokenizerReport) -> str:
    lines = [
        "Tokenizer Report",
        "=" * 16,
        f"n_samples={report.n_samples}  all_roundtrip_ok={report.all_roundtrip_ok}",
        f"encoded_len: min={report.min_encoded_len} max={report.max_encoded_len}  "
        f"avg_chars_per_token={report.avg_chars_per_token:.2f}",
    ]
    for c in report.checks:
        flag = "OK" if c.roundtrip_ok and not c.contains_special_token_leak else "FAIL"
        lines.append(f"  [{flag}] len={c.encoded_len:4d}  {c.sample_text!r}")
    return "\n".join(lines)
