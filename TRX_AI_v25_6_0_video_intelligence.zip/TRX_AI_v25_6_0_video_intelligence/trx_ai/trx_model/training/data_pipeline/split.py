# -*- coding: utf-8 -*-
"""
split.py -- تقسیمِ Train/Validation در سطحِ سند (بخشِ ۶ سندِ فازِ
دوم: جلوگیری از Data Leakage).

روشِ صحیح (طبقِ سند): Raw Documents -> Cleaning -> Deduplication ->
Train/Validation Documents -> Tokenization -> Sequence Packing.

روشِ غلط (که این ماژول عمداً *نمی‌کند*): All Tokens -> Random Split.

**Validation باید ثابت باشد** تا نسخه‌های مختلفِ مدل قابلِ مقایسه
باشند -- به همین دلیل، اگر یک split.json از قبل وجود داشته باشد،
همان idهای Validation دوباره استفاده می‌شوند (نه split تصادفیِ
جدید)، مگرِاین‌که مجموعه‌یِ Documentها عوض شده باشد که آن‌وقت هشدار
داده می‌شود.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from .corpus_builder import Document

DEFAULT_VAL_FRACTION = 0.1  # بخشِ ۶: «۹۰٪ train / ۱۰٪ validation»


@dataclass
class SplitReport:
    train_doc_ids: List[str]
    val_doc_ids: List[str]
    reused_fixed_split: bool
    warning: str = ""


def split_documents(
    documents: List[Document],
    output_dir: str,
    val_fraction: float = DEFAULT_VAL_FRACTION,
    seed: int = 0,
) -> Tuple[List[Document], List[Document], SplitReport]:
    """تقسیمِ سطحِ سند -- فقط رویِ Documentهایی که ``status=="kept"``.
    اگر ``output_dir/split.json`` از قبل وجود دارد، همان
    val_doc_ids (اگر هنوز در Documentهایِ فعلی حاضرند) دوباره
    استفاده می‌شود -- بخشِ ۶: «Validation باید ثابت باشد»."""
    kept = [d for d in documents if d.status == "kept"]
    if not kept:
        raise ValueError("split_documents: هیچ سندِ kept برای تقسیم وجود ندارد.")

    kept_ids = {d.doc_id for d in kept}
    split_path = os.path.join(output_dir, "split.json")
    reused = False
    warning = ""

    if os.path.exists(split_path):
        with open(split_path, "r", encoding="utf-8") as f:
            previous = json.load(f)
        previous_val_ids = set(previous.get("val_doc_ids", []))
        still_valid = previous_val_ids & kept_ids
        if still_valid and len(still_valid) == len(previous_val_ids):
            val_ids = previous_val_ids
            train_ids = kept_ids - val_ids
            reused = True
        else:
            missing = previous_val_ids - kept_ids
            warning = (
                f"split.json قبلی با Documentهایِ فعلی سازگار نیست "
                f"({len(missing)} سندِ Validation قبلی دیگر موجود نیست) -- split جدید ساخته شد."
            )
            train_ids, val_ids = _fresh_split(kept_ids, val_fraction, seed)
    else:
        train_ids, val_ids = _fresh_split(kept_ids, val_fraction, seed)

    train_docs = [d for d in kept if d.doc_id in train_ids]
    val_docs = [d for d in kept if d.doc_id in val_ids]

    os.makedirs(output_dir, exist_ok=True)
    with open(split_path, "w", encoding="utf-8") as f:
        json.dump({"train_doc_ids": sorted(train_ids), "val_doc_ids": sorted(val_ids), "seed": seed}, f, ensure_ascii=False, indent=2)

    report = SplitReport(
        train_doc_ids=sorted(train_ids), val_doc_ids=sorted(val_ids), reused_fixed_split=reused, warning=warning
    )
    return train_docs, val_docs, report


def _fresh_split(kept_ids: set, val_fraction: float, seed: int) -> Tuple[set, set]:
    ids_sorted = sorted(kept_ids)  # قطعی -- ترتیبِ set بینِ اجراها فرق می‌کند
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(ids_sorted))
    n_val = max(1, int(round(len(ids_sorted) * val_fraction)))
    val_ids = {ids_sorted[i] for i in order[:n_val]}
    train_ids = kept_ids - val_ids
    return train_ids, val_ids
