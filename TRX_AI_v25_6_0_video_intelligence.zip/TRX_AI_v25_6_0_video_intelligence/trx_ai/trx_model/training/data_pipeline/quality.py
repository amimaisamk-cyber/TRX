# -*- coding: utf-8 -*-
"""
quality.py -- امتیازِ کیفیتِ سند (بخشِ ۵ سندِ فازِ دوم).

هر معیار در بازه‌یِ ``[0,1]`` نرمال می‌شود؛ امتیازِ نهایی میانگینِ
وزن‌دارِ آن‌هاست. رده‌بندی: **A** (بسیار تمیز)، **B** (قابلِ‌استفاده
با کنترل)، **C** (ضعیف).
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_SENTENCE_SPLIT_RE = re.compile(r"[.!?؟!\n]+")
_WORD_SPLIT_RE = re.compile(r"\s+")
_PUNCT_RE = re.compile(r"[.,!?;:؛،؟!()\[\]{}\"'`\-_/\\]")

IDEAL_LENGTH_RANGE = (60, 4000)  # کاراکتر -- «طولِ مناسب» (بخشِ ۷: کوتاه/متوسط)
IDEAL_SENTENCE_LENGTH_RANGE = (20, 220)  # کاراکتر به‌ازایِ هر جمله -- «خوانایی/جمله‌بندی»


@dataclass
class QualityScore:
    score: float  # ۰..۱
    tier: str  # "A" | "B" | "C"
    length_score: float
    readability_score: float
    repetition_score: float
    paragraph_score: float
    punctuation_ratio: float


def _length_score(text: str) -> float:
    n = len(text)
    lo, hi = IDEAL_LENGTH_RANGE
    if n < lo:
        return max(0.0, n / lo)
    if n > hi:
        return max(0.3, hi / n)
    return 1.0


def _readability_score(text: str) -> float:
    """میانگینِ طولِ جمله -- نه خیلی کوتاهِ بی‌معنا، نه خیلی بلندِ
    بی‌ساختار."""
    sentences = [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]
    if not sentences:
        return 0.0
    avg_len = sum(len(s) for s in sentences) / len(sentences)
    lo, hi = IDEAL_SENTENCE_LENGTH_RANGE
    if avg_len < lo:
        return max(0.2, avg_len / lo)
    if avg_len > hi:
        return max(0.2, hi / avg_len)
    return 1.0


def _repetition_score(text: str) -> float:
    """میزانِ تکرار: نسبتِ کلماتِ یکتا به کلِ کلمات (نزدیکِ ۱ = تکرارِ
    کم)."""
    words = [w for w in _WORD_SPLIT_RE.split(text) if w]
    if not words:
        return 0.0
    unique_ratio = len(set(words)) / len(words)
    return unique_ratio


def _paragraph_score(text: str) -> float:
    """ساختارِ پاراگراف: وجودِ حداقل یک شکستِ خط معنادار در متن‌هایِ
    بلند امتیازِ کامل می‌گیرد؛ متنِ کوتاهِ تک‌خطی جریمه نمی‌شود."""
    if len(text) < 200:
        return 1.0
    return 1.0 if "\n" in text.strip() else 0.6


def _punctuation_ratio(text: str) -> float:
    letters = sum(1 for ch in text if ch.isalpha())
    if letters == 0:
        return 1.0  # بدونِ حرف -- بعداً توسطِ length_score/unusual_char_ratio جریمه می‌شود
    punct = len(_PUNCT_RE.findall(text))
    return punct / letters


def score_document(text: str) -> QualityScore:
    length_s = _length_score(text)
    readability_s = _readability_score(text)
    repetition_s = _repetition_score(text)
    paragraph_s = _paragraph_score(text)
    punct_ratio = _punctuation_ratio(text)
    punct_s = 1.0 if punct_ratio < 0.3 else max(0.0, 1.0 - (punct_ratio - 0.3))

    score = (
        0.25 * length_s
        + 0.25 * readability_s
        + 0.25 * repetition_s
        + 0.15 * paragraph_s
        + 0.10 * punct_s
    )

    if score >= 0.75:
        tier = "A"
    elif score >= 0.5:
        tier = "B"
    else:
        tier = "C"

    return QualityScore(
        score=score,
        tier=tier,
        length_score=length_s,
        readability_score=readability_s,
        repetition_score=repetition_s,
        paragraph_score=paragraph_s,
        punctuation_ratio=punct_ratio,
    )
