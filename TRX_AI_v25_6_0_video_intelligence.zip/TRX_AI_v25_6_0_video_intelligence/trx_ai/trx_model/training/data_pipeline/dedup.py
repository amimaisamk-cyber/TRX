# -*- coding: utf-8 -*-
"""
dedup.py -- حذفِ duplicateِ کاملِ سند (بخشِ ۴ سندِ فازِ دوم).

سطحِ سند، نه سطحِ توکن -- طبقِ بخشِ ۶ (جلوگیری از Data Leakage):
dedup باید *قبل* از تقسیمِ train/validation و *قبل* از tokenize
اجرا شود.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Dict, List, Tuple


def _normalize_for_hash(text: str) -> str:
    return " ".join(text.split()).strip().lower()


def content_hash(text: str) -> str:
    return hashlib.sha256(_normalize_for_hash(text).encode("utf-8")).hexdigest()


@dataclass
class DedupReport:
    total_in: int
    kept: int
    removed_duplicates: int
    duplicate_groups: int


def deduplicate(documents: List, text_attr: str = "cleaned_text") -> Tuple[List, DedupReport]:
    """حذفِ duplicateِ کامل. ``documents`` هر آبجکتی می‌تواند باشد که
    attributeِ ``text_attr`` را دارد (اینجا coupling به یک کلاسِ
    خاص عمداً نیست -- ``corpus_builder.Document`` این attribute را
    دارد).

    اولین رخدادِ هر hash نگه داشته می‌شود؛ بقیه حذف (اما در گزارش
    شمارش می‌شوند -- بخشِ ۴: «ثبتِ دلیلِ حذفِ هر سند» هم برایِ اینها
    توسطِ فراخوان‌کننده ثبت می‌شود، نه اینجا مستقیماً روی خودِ سند
    چون این تابع فقط فیلتر می‌کند)."""
    seen: Dict[str, int] = {}
    kept: List = []
    removed = 0
    for doc in documents:
        text = getattr(doc, text_attr)
        if text is None:
            continue
        h = content_hash(text)
        if h in seen:
            removed += 1
            continue
        seen[h] = 1
        kept.append(doc)

    return kept, DedupReport(
        total_in=len(documents),
        kept=len(kept),
        removed_duplicates=removed,
        duplicate_groups=len(seen),
    )
