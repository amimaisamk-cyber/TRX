# -*- coding: utf-8 -*-
"""
fixed_prompts.py -- مجموعه‌یِ ثابتِ Generation (بخشِ ۱۳ سندِ فازِ
دوم).

دقیقاً همان promptهایِ ذکرشده در سند + یک جمله‌یِ آموزشیِ جدید. قبل
و بعدِ هر آموزش دقیقاً همین promptها اجرا می‌شوند و ``checkpoint``،
``prompt``، ``output``، ``temperature``، ``top_k``، ``تعدادِ
توکن``، ``تاریخِ آزمایش`` ثبت می‌شوند.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import List

import numpy as np

FIXED_PROMPTS: List[str] = [
    "امروز هوا",
    "هوش مصنوعی یعنی",
    "برای حل یک مسئله ابتدا",
    "اگر باران ببارد، زمین",
    "Python یک زبان",
    "چرا آسمان آبی است؟",
    "این یک جمله‌ی آموزشیِ جدید برای آزمایشِ Generalization است.",
]


@dataclass
class GenerationRecord:
    checkpoint_label: str
    prompt: str
    output: str
    temperature: float
    top_k: int
    max_new_tokens: int
    timestamp: str


def generate_with_top_k(model, tokenizer, prompt: str, max_new_tokens: int = 25, temperature: float = 0.8, top_k: int = 20, seed: int = 0) -> str:
    """نمونه‌برداریِ top-k (بخشِ ۱۳ سند صریحاً ``top-k`` را در گزارش
    می‌خواهد). این تابع مستقل از ``evaluator.generate_sample``ی فازِ
    اول است (که فقط temperature داشت) -- طبقِ اصلِ Preserve، آن فایل
    دست نخورده باقی می‌ماند."""
    rng = np.random.default_rng(seed)
    ids = tokenizer.encode(prompt, add_bos=True)
    max_len = model.config.max_seq_len

    for _ in range(max_new_tokens):
        window = ids[-max_len:]
        logits = model.forward(np.asarray(window, dtype=np.int64))
        last_logits = logits[-1] / max(temperature, 1e-6)

        k = min(top_k, last_logits.shape[0])
        top_idx = np.argpartition(last_logits, -k)[-k:]
        top_logits = last_logits[top_idx]
        shifted = top_logits - np.max(top_logits)
        probs = np.exp(shifted)
        probs = probs / probs.sum()
        choice = int(rng.choice(len(probs), p=probs))
        next_id = int(top_idx[choice])

        if next_id == tokenizer.eos_id:
            break
        ids.append(next_id)

    return tokenizer.decode(ids)


def run_fixed_prompt_suite(
    model,
    tokenizer,
    checkpoint_label: str,
    output_path: str,
    max_new_tokens: int = 25,
    temperature: float = 0.8,
    top_k: int = 20,
    seed: int = 0,
) -> List[GenerationRecord]:
    """اجرایِ همه‌یِ ``FIXED_PROMPTS`` و append کردنِ نتیجه به
    ``output_path`` (JSON Lines -- هر آموزش یک بلوکِ جدید، بدونِ
    ازبین‌بردنِ سابقه‌یِ قبلی، تا مقایسه‌یِ قبل/بعد ممکن بماند)."""
    records: List[GenerationRecord] = []
    now = datetime.now(timezone.utc).isoformat()
    for prompt in FIXED_PROMPTS:
        output = generate_with_top_k(model, tokenizer, prompt, max_new_tokens, temperature, top_k, seed)
        records.append(
            GenerationRecord(
                checkpoint_label=checkpoint_label,
                prompt=prompt,
                output=output,
                temperature=temperature,
                top_k=top_k,
                max_new_tokens=max_new_tokens,
                timestamp=now,
            )
        )

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "a", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(asdict(r), ensure_ascii=False) + "\n")

    return records


def load_generation_log(output_path: str) -> List[GenerationRecord]:
    if not os.path.exists(output_path):
        return []
    records = []
    with open(output_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(GenerationRecord(**json.loads(line)))
    return records
