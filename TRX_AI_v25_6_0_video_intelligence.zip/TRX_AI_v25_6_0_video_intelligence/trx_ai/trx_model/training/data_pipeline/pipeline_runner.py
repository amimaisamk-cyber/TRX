# -*- coding: utf-8 -*-
"""
pipeline_runner.py -- هماهنگ‌کننده‌ی کاملِ فازِ دوم (بخشِ ۱۷ سند:
«ترتیبِ اجراییِ دقیق»، مراحلِ ۲.۱ تا ۲.۹).

هیچ مرحله‌ای حذف نمی‌شود (بخشِ ۲ سند: «هیچ مرحله‌ای نباید حذف
شود»). با شکستِ Smoke Test (مرحله‌یِ ۲.۴)، اجرا با
``SmokeTestFailure`` متوقف می‌شود -- طبقِ بخشِ ۱۱: «با شکستِ هر
مورد، آموزشِ اصلی متوقف شود.»
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Optional

from ...model import TRXModelConfig, TRXNativeModel
from ..checkpoint import CheckpointMeta
from ..dataset import build_sequences
from ..evaluator import evaluate
from ..gradient_check import run_gradient_check
from ..resource_guard import estimate_resources
from ..trainer import TrainingConfig, train
from . import checkpoint_policy
from .corpus_builder import build_corpus_v1, load_manifest
from .fixed_prompts import run_fixed_prompt_suite
from .generalization_test import run_generalization_test
from .resource_monitor import check_disk_space
from .sequence_packing_check import check_sequence_packing, format_check
from .smoke_test import SmokeTestFailure, run_smoke_test
from .split import split_documents
from .tokenizer_report import format_report, run_tokenizer_report


@dataclass
class PipelineResult:
    stage_2_1_corpus: dict = field(default_factory=dict)
    stage_2_2_split: dict = field(default_factory=dict)
    stage_2_3_tokenizer: dict = field(default_factory=dict)
    stage_2_4_smoke_test: dict = field(default_factory=dict)
    stage_2_5_training: dict = field(default_factory=dict)
    stage_2_6_analysis: dict = field(default_factory=dict)
    stage_2_8_resume: dict = field(default_factory=dict)
    stage_2_9_generalization: dict = field(default_factory=dict)
    resource_report: dict = field(default_factory=dict)


def run_phase2_pipeline(
    root_dir: str,
    output_dir: str,
    tokenizer_path: str,
    seq_len: int = 64,
    d_model: int = 64,
    n_layers: int = 2,
    n_heads: int = 4,
    d_ff: int = 128,
    model_seed: int = 42,
    training_steps_subset: int = 60,
    training_epochs: int = 3,
    learning_rate: float = 3e-3,
) -> PipelineResult:
    """اجرایِ کاملِ مراحلِ ۲.۱ تا ۲.۹ رویِ پیکره‌ی واقعیِ پروژه.
    ``output_dir`` ساختارِ بخشِ ۳ و ۱۴ سند را می‌سازد:
    ``data/{corpus_v1,reports}`` و ``checkpoints/{latest,best,periodic}``.
    """
    from trx_ai.trx_model.tokenizer import ByteLevelBPETokenizer

    result = PipelineResult()
    data_dir = os.path.join(output_dir, "data")
    corpus_dir = os.path.join(data_dir, "corpus_v1")
    reports_dir = os.path.join(data_dir, "reports")
    checkpoints_dir = os.path.join(output_dir, "checkpoints")
    os.makedirs(reports_dir, exist_ok=True)

    disk_free_mb = check_disk_space(output_dir if os.path.exists(output_dir) else ".")
    result.resource_report["disk_free_mb_before"] = disk_free_mb

    # --- ۲.۱ + ۲.۲: تثبیتِ pipeline داده + Corpus v1 (بخشِ ۳,۴,۵,۶,۷) ---
    manifest = build_corpus_v1(root_dir, corpus_dir, max_docs=500, seed=0)
    result.stage_2_1_corpus = {
        "total_raw_paragraphs": manifest.total_raw_paragraphs,
        "kept_documents": manifest.kept_documents,
        "removed_by_cleaning": manifest.removed_by_cleaning,
        "removed_by_dedup": manifest.removed_by_dedup,
        "removed_by_quality": manifest.removed_by_quality,
        "tier_counts": manifest.tier_counts,
    }

    documents = load_manifest(corpus_dir)
    train_docs, val_docs, split_report = split_documents(documents, corpus_dir, val_fraction=0.1, seed=0)
    result.stage_2_2_split = {
        "n_train_docs": len(train_docs),
        "n_val_docs": len(val_docs),
        "reused_fixed_split": split_report.reused_fixed_split,
        "warning": split_report.warning,
    }

    # --- ۲.۳: تست Tokenizer و Dataset (بخشِ ۸ و ۹) ---
    tokenizer = ByteLevelBPETokenizer.load(tokenizer_path)
    sample_texts = [d.cleaned_text for d in (train_docs[:5] + val_docs[:2]) if d.cleaned_text]
    tok_report = run_tokenizer_report(tokenizer, sample_texts)
    packing_check = check_sequence_packing(tokenizer, train_docs[0].cleaned_text[:80])
    result.stage_2_3_tokenizer = {
        "all_roundtrip_ok": tok_report.all_roundtrip_ok,
        "avg_chars_per_token": tok_report.avg_chars_per_token,
        "sequence_packing_shift_correct": packing_check.shift_correct,
    }
    with open(os.path.join(reports_dir, "tokenizer_report.txt"), "w", encoding="utf-8") as f:
        f.write(format_report(tok_report) + "\n\n" + format_check(packing_check))

    train_texts = [d.cleaned_text for d in train_docs]
    val_texts = [d.cleaned_text for d in val_docs]
    train_seqs = build_sequences(tokenizer, train_texts, seq_len=seq_len)
    val_seqs = build_sequences(tokenizer, val_texts, seq_len=seq_len)
    if not train_seqs or not val_seqs:
        raise ValueError("پس از Document Split، train یا validation sequences خالی شد -- corpus/seq_len را بررسی کنید.")

    config = TRXModelConfig(
        vocab_size=tokenizer.vocab_size, d_model=d_model, n_layers=n_layers,
        n_heads=n_heads, d_ff=d_ff, max_seq_len=seq_len, seed=model_seed,
    )
    model = TRXNativeModel(config)
    est = estimate_resources(config, seq_len)
    result.resource_report["param_count"] = est.param_count
    result.resource_report["estimated_total_mb"] = est.total_estimated_mb

    # --- ۲.۴: Smoke Test اجباری (بخشِ ۱۱) -- شکست => توقفِ کل ---
    smoke_report = run_smoke_test(model, tokenizer, train_seqs, val_seqs)  # با شکست، SmokeTestFailure پرتاب می‌کند
    result.stage_2_4_smoke_test = {"passed_checks": smoke_report.passed_checks}

    # Gradient Check رویِ همین مدلِ واقعی -- پیش‌نیازِ خودِ فازِ اول، اینجا هم دوباره طبقِ بخشِ ۱۸: «آموزشِ بدون checkpoint ممنوع» و احتیاط تکرار می‌شود
    gc = run_gradient_check(model, train_seqs[0].input_ids, train_seqs[0].target_ids, tolerance=1e-4, seed=0)
    if not gc.passed:
        raise SmokeTestFailure(f"Gradient Check رد شد (max_rel_err={gc.max_relative_error:.2e}) -- آموزش متوقف شد.")

    # --- Generation قبل از آموزش (بخشِ ۱۳) ---
    generation_log_path = os.path.join(reports_dir, "generation_comparison.jsonl")
    before_eval = evaluate(model, val_seqs)
    run_fixed_prompt_suite(model, tokenizer, checkpoint_label="before_training", output_path=generation_log_path)

    # --- ۲.۵: Controlled Training (بخشِ ۱۰: batch_size=1، AdamW، clipping فعال) ---
    small_train = train_seqs[: max(1, training_steps_subset)]
    t0 = time.time()
    step_losses = []
    training_config = TrainingConfig(learning_rate=learning_rate, epochs=training_epochs, seed=1, max_grad_norm=1.0)
    training_report = train(model, small_train, val_seqs, training_config, tokenizer=tokenizer, on_step=lambda r: step_losses.append(r.loss))
    train_time = time.time() - t0

    after_eval = evaluate(model, val_seqs)
    run_fixed_prompt_suite(model, tokenizer, checkpoint_label="after_training", output_path=generation_log_path)

    result.stage_2_5_training = {
        "n_steps": len(step_losses),
        "train_time_seconds": train_time,
        "train_loss_first": step_losses[0] if step_losses else None,
        "train_loss_last": step_losses[-1] if step_losses else None,
        "val_loss_before": before_eval.average_loss,
        "val_loss_after": after_eval.average_loss,
        "perplexity_before": before_eval.perplexity,
        "perplexity_after": after_eval.perplexity,
        "val_losses_per_epoch": training_report.validation_losses,
    }

    # --- Checkpoint (بخشِ ۱۴): latest/best/periodic اتمیک ---
    from ..autograd_cache import build_param_map
    from ..optim import AdamW

    optimizer_for_ckpt = AdamW(param_names=build_param_map(model).keys(), lr=learning_rate)
    meta = CheckpointMeta(
        epoch=training_report.final_epoch, step=training_report.final_step,
        training_loss=step_losses[-1] if step_losses else float("nan"),
        validation_loss=after_eval.average_loss, best_validation_loss=training_report.best_validation_loss,
        tokenizer_vocab_size=tokenizer.vocab_size, tokenizer_num_merges=len(tokenizer.merges), seed=1,
    )
    checkpoint_policy.save_latest(checkpoints_dir, model, optimizer_for_ckpt, tokenizer, meta)
    checkpoint_policy.save_best_if_improved(checkpoints_dir, model, optimizer_for_ckpt, tokenizer, meta)
    checkpoint_policy.save_periodic(checkpoints_dir, model, optimizer_for_ckpt, tokenizer, meta, keep_last=3)

    # --- ۲.۶: تحلیلِ نتایج (بخشِ ۱۲: تفسیرِ صریح) ---
    gap = after_eval.average_loss - (step_losses[-1] if step_losses else float("nan"))
    result.stage_2_6_analysis = {
        "train_loss_decreased": (step_losses[-1] < step_losses[0]) if len(step_losses) >= 2 else None,
        "val_loss_decreased": after_eval.average_loss < before_eval.average_loss,
        "perplexity_decreased": after_eval.perplexity < before_eval.perplexity,
        "train_val_gap": gap,
        "interpretation": _interpret(step_losses, before_eval.average_loss, after_eval.average_loss),
    }

    # --- ۲.۸: Resume Test (بخشِ ۱۵) ---
    model_resumed = TRXNativeModel(config)
    optimizer_resumed = AdamW(param_names=build_param_map(model_resumed).keys(), lr=learning_rate)
    resumed_meta, resume_warnings = checkpoint_policy.resume_from_latest(
        checkpoints_dir, model_resumed, optimizer_resumed, tokenizer, expected_seed=1
    )
    params_before = build_param_map(model)
    params_after_resume = build_param_map(model_resumed)
    weights_match = all((params_before[k] == params_after_resume[k]).all() for k in params_before)
    result.stage_2_8_resume = {
        "resumed_step": resumed_meta.step,
        "weights_match_after_resume": bool(weights_match),
        "warnings": [w.message for w in resume_warnings],
    }

    # --- ۲.۹: Generalization Test (بخشِ ۱۹) ---
    generalization_results = run_generalization_test(model, tokenizer, max_new_tokens=25, seed=0)
    result.stage_2_9_generalization = {
        "n_prompts": len(generalization_results),
        "any_infinite_repetition": any(r.has_infinite_repetition for r in generalization_results),
        "samples": [{"prompt": r.prompt, "output": r.output[:80]} for r in generalization_results],
    }

    result.resource_report["disk_free_mb_after"] = check_disk_space(output_dir)

    with open(os.path.join(reports_dir, "phase2_result.json"), "w", encoding="utf-8") as f:
        json.dump(asdict(result), f, ensure_ascii=False, indent=2)

    return result


def _interpret(step_losses, val_before: float, val_after: float) -> str:
    """تفسیرِ خودکارِ بخشِ ۱۲ سند (چهار حالتِ صریحاً ذکرشده)."""
    if not step_losses or len(step_losses) < 2:
        return "داده‌ی کافی برای تفسیر نیست."
    train_decreased = step_losses[-1] < step_losses[0]
    val_decreased = val_after < val_before
    if not train_decreased and not val_decreased:
        return "هر دو ثابت/بدتر -- مشکلِ داده، نرخِ یادگیری یا ظرفیتِ مدل محتمل است."
    if train_decreased and not val_decreased:
        return "Train پایین ولی Validation بالا -- احتمالِ overfitting."
    if train_decreased and val_decreased:
        return "هم Train و هم Validation کاهش یافتند -- یادگیریِ واقعی محتمل است."
    return "الگویِ غیرمنتظره -- بررسیِ دستی لازم است."
