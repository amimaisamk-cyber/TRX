# -*- coding: utf-8 -*-
"""
optim.py -- Gradient Clipping (بخشِ هجدهم) + AdamW (بخشِ نوزدهم سند).
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


def clip_gradients(grads: Dict[str, np.ndarray], max_norm: float) -> Tuple[float, float]:
    """Gradient Clipping (بخشِ هجدهم).

    ابتدا isfinite بررسی می‌شود -- clipping درمانِ NaN/Inf نیست
    (نکته‌ی صریحِ سند). اگر global_norm > max_norm همه‌یِ گرادیان‌ها
    (in-place) مقیاس می‌شوند.

    برمی‌گرداند: ``(global_norm_before_clip, scale_applied)``.
    """
    for name, g in grads.items():
        if not np.all(np.isfinite(g)):
            raise FloatingPointError(
                f"گرادیانِ '{name}' غیرِ finite است -- Gradient Clipping نمی‌تواند این را درمان کند."
            )

    total_sq = 0.0
    for g in grads.values():
        total_sq += float(np.sum(np.square(g)))
    global_norm = float(np.sqrt(total_sq))

    scale = 1.0
    if global_norm > max_norm and global_norm > 0.0:
        scale = max_norm / global_norm
        for g in grads.values():
            g *= scale

    return global_norm, scale


class AdamW:
    """AdamW (بخشِ نوزدهم سند) -- Weight Decay جداگانه از گرادیانِ
    Adam اعمال می‌شود (با Adam معمولی که Weight Decay را داخلِ
    گرادیان مخلوط می‌کند فرق دارد)."""

    def __init__(self, param_names, lr: float = 3e-4, betas=(0.9, 0.999), eps: float = 1e-8, weight_decay: float = 0.01):
        self.lr = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.step_count = 0
        self.m: Dict[str, np.ndarray] = {}
        self.v: Dict[str, np.ndarray] = {}
        self._param_names = list(param_names)

    def state_dict(self) -> dict:
        return {
            "lr": self.lr,
            "beta1": self.beta1,
            "beta2": self.beta2,
            "eps": self.eps,
            "weight_decay": self.weight_decay,
            "step_count": self.step_count,
            "m": {k: v.copy() for k, v in self.m.items()},
            "v": {k: v.copy() for k, v in self.v.items()},
        }

    def load_state_dict(self, state: dict) -> None:
        self.lr = state["lr"]
        self.beta1 = state["beta1"]
        self.beta2 = state["beta2"]
        self.eps = state["eps"]
        self.weight_decay = state["weight_decay"]
        self.step_count = state["step_count"]
        self.m = {k: np.array(v, dtype=np.float64) for k, v in state["m"].items()}
        self.v = {k: np.array(v, dtype=np.float64) for k, v in state["v"].items()}

    def step(self, params: Dict[str, np.ndarray], grads: Dict[str, np.ndarray]) -> None:
        """به‌روزرسانیِ in-place رویِ همان arrayهایِ ``params`` (که
        ارجاعِ واقعیِ وزن‌هایِ مدل هستند -- ``build_param_map``)."""
        self.step_count += 1
        t = self.step_count
        bias_c1 = 1.0 - self.beta1 ** t
        bias_c2 = 1.0 - self.beta2 ** t

        for name in self._param_names:
            if name not in grads:
                continue
            grad = grads[name]
            param = params[name]

            if name not in self.m:
                self.m[name] = np.zeros_like(param, dtype=np.float64)
                self.v[name] = np.zeros_like(param, dtype=np.float64)

            self.m[name] = self.beta1 * self.m[name] + (1 - self.beta1) * grad
            self.v[name] = self.beta2 * self.v[name] + (1 - self.beta2) * np.square(grad)

            m_hat = self.m[name] / bias_c1
            v_hat = self.v[name] / bias_c2

            update = self.lr * m_hat / (np.sqrt(v_hat) + self.eps)
            param -= update
            # Weight Decay -- جداگانه، نه مخلوط با گرادیانِ Adam
            if self.weight_decay > 0.0:
                param -= self.lr * self.weight_decay * param
