# -*- coding: utf-8 -*-
"""
gradient_check.py -- Gradient Check (بخشِ بیست‌وچهارم سند).

قبل از آموزشِ واقعی، این ماژول Backward تحلیلی را با گرادیانِ عددی
(Finite Difference) مقایسه می‌کند. بدونِ عبورِ این تست، آموزشِ مدلِ
بزرگ‌تر «خطرناک» است (نقل‌قولِ مستقیمِ سند).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from .autograd_cache import build_param_map, forward_with_cache
from .backward import backward
from .losses import cross_entropy_loss

DEFAULT_PARAM_NAMES = (
    "token_embedding",
    "blocks.0.attn.w_q",
    "blocks.0.attn.w_k",
    "blocks.0.attn.w_v",
    "blocks.0.attn.w_o",
    "blocks.0.ffn.w1",
    "blocks.0.ffn.w2",
    "blocks.0.ffn.w3",
    "blocks.0.attn_norm.weight",
    "blocks.0.ffn_norm.weight",
    "final_norm.weight",
)


@dataclass
class GradientCheckResult:
    checks: List[Tuple[str, Tuple[int, ...], float, float, float]]  # name, idx, analytic, numeric, rel_err
    max_relative_error: float
    passed: bool


def run_gradient_check(
    model,
    input_ids: np.ndarray,
    target_ids: np.ndarray,
    param_names: Tuple[str, ...] = DEFAULT_PARAM_NAMES,
    n_indices_per_param: int = 3,
    epsilon: float = 1e-5,
    tolerance: float = 1e-4,
    seed: int = 0,
) -> GradientCheckResult:
    """اجرایِ Gradient Check رویِ چند اندیسِ تصادفیِ هرکدام از
    ``param_names`` (بخشِ ۲۴ سند: Embedding, Wq..Wo, W1..W3, RMSNorm,
    Final Norm).

    ``relative_error = |analytic-numeric| / max(|analytic|,|numeric|,eps)``
    -- اگر بیشترین relative_error از ``tolerance`` رد شود،
    ``passed=False``.
    """
    rng = np.random.default_rng(seed)
    params = build_param_map(model)

    def compute_loss() -> float:
        logits = model.forward(input_ids)
        loss, _ = cross_entropy_loss(logits, target_ids)
        return loss

    logits, cache = forward_with_cache(model, input_ids)
    loss, d_logits = cross_entropy_loss(logits, target_ids)
    analytic_grads = backward(model, cache, d_logits)

    checks: List[Tuple[str, Tuple[int, ...], float, float, float]] = []
    max_rel_err = 0.0

    for name in param_names:
        if name not in params:
            continue
        arr = params[name]
        flat_size = arr.size
        n_pick = min(n_indices_per_param, flat_size)
        flat_indices = rng.choice(flat_size, size=n_pick, replace=False)
        for flat_idx in flat_indices:
            idx = np.unravel_index(int(flat_idx), arr.shape)
            original = arr[idx]

            arr[idx] = original + epsilon
            loss_plus = compute_loss()
            arr[idx] = original - epsilon
            loss_minus = compute_loss()
            arr[idx] = original

            numeric_grad = (loss_plus - loss_minus) / (2 * epsilon)
            analytic_grad = float(analytic_grads[name][idx])
            denom = max(abs(analytic_grad), abs(numeric_grad), 1e-8)
            rel_err = abs(analytic_grad - numeric_grad) / denom
            max_rel_err = max(max_rel_err, rel_err)
            checks.append((name, idx, analytic_grad, numeric_grad, rel_err))

    return GradientCheckResult(checks=checks, max_relative_error=max_rel_err, passed=max_rel_err <= tolerance)


def format_report(result: GradientCheckResult) -> str:
    lines = ["Gradient Check Report", "=" * 22]
    for name, idx, analytic, numeric, rel_err in result.checks:
        lines.append(f"{name}{idx}: analytic={analytic:.8f} numeric={numeric:.8f} rel_err={rel_err:.2e}")
    lines.append("-" * 22)
    lines.append(f"MAX relative error: {result.max_relative_error:.2e}")
    lines.append(f"PASSED: {result.passed}")
    return "\n".join(lines)
