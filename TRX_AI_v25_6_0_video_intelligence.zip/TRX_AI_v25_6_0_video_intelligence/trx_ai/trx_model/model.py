# -*- coding: utf-8 -*-
"""
model.py -- مدلِ decoder-only کاملِ TRX (بخشِ ۱۲-ج سند: «این بخش باید
ساده، قابلِ تست و قابلِ اندازه‌گیری باشد»).

مسیرِ forward دقیقاً همان دیاگرامِ کاربر است:

    token ids -> Embedding -> [TransformerBlock] * n_layers -> RMSNorm
              -> Output Head (tied weights) -> logits

نکته‌یِ صادقانه (طبقِ ارزشِ «گزارشِ صادقانه‌یِ scope» در working-notes):
وزن‌ها با ``seed`` مشخص و تصادفی مقداردهیِ اولیه می‌شوند. هیچ حلقه‌ی
آموزشی (loss/optimizer/backprop) اینجا نیست -- آن، Stage 14 سند
(Pretraining/Instruction/Reasoning/Alignment) است و عمداً در این
نسخه پیاده نشده. ``generate()`` واقعاً forward pass و sampling انجام
می‌دهد، اما چون وزن‌ها آموزش‌ندیده‌اند خروجی زبانیِ بی‌معنی خواهد بود.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np

from .transformer_core import RMSNorm, TransformerBlock, precompute_rope, softmax


@dataclass
class TRXModelConfig:
    """ابرپارامترهایِ معماری. مقادیرِ پیش‌فرض عمداً کوچک نگه داشته
    شده‌اند (طبقِ بخشِ ۱۳: «Scaling نباید قبل از correctness باشد») تا
    forward pass رویِ CPU با numpy فوری اجرا شود و در تست قابلِ تکرار
    باشد."""

    vocab_size: int
    d_model: int = 128
    n_layers: int = 2
    n_heads: int = 4
    d_ff: int = 256
    max_seq_len: int = 256
    seed: int = 42

    def __post_init__(self) -> None:
        if self.d_model % self.n_heads != 0:
            raise ValueError("d_model باید بر n_heads بخش‌پذیر باشد.")
        if self.vocab_size <= 0:
            raise ValueError("vocab_size باید مثبت باشد.")


class TRXNativeModel:
    """مدلِ بومیِ TRX -- پیاده‌سازیِ کاملِ عددی، بدونِ وابستگیِ خارجی
    (فقط numpy)."""

    def __init__(self, config: TRXModelConfig):
        self.config = config
        rng = np.random.default_rng(config.seed)

        std = 0.02
        self.token_embedding = rng.normal(0.0, std, size=(config.vocab_size, config.d_model))

        head_dim = config.d_model // config.n_heads
        self.rope_cos, self.rope_sin = precompute_rope(head_dim, config.max_seq_len)

        self.blocks: List[TransformerBlock] = [
            TransformerBlock(config.d_model, config.n_heads, config.d_ff, rng)
            for _ in range(config.n_layers)
        ]
        self.final_norm = RMSNorm(config.d_model)
        # وزنِ خروجی با embedding مشترک است (weight tying -- استانداردِ
        # رایج در مدل‌هایِ کوچک: کاهشِ تعدادِ پارامتر بدونِ افتِ کیفیتِ
        # قابلِ‌سنجش).

    def forward(self, token_ids: np.ndarray) -> np.ndarray:
        """ورودی: آرایه‌ی یک‌بعدیِ id توکن‌ها ``(seq_len,)``.
        خروجی: ``logits`` با شکلِ ``(seq_len, vocab_size)``.

        محدودیتِ صریح: batch پشتیبانی نمی‌شود (فقط یک دنباله در هر
        فراخوانی) -- برایِ اثباتِ صحتِ معماری کافی است؛ batching یک
        بهینه‌سازیِ Stage-۱۳ (Scaling) است، نه پیش‌نیازِ correctness.
        """
        token_ids = np.asarray(token_ids, dtype=np.int64)
        if token_ids.ndim != 1:
            raise ValueError("forward فقط یک دنباله‌ی یک‌بعدی می‌پذیرد (بدونِ batch).")
        seq_len = token_ids.shape[0]
        if seq_len > self.config.max_seq_len:
            raise ValueError(
                f"طولِ دنباله ({seq_len}) از max_seq_len ({self.config.max_seq_len}) بیشتر است."
            )
        if token_ids.max(initial=0) >= self.config.vocab_size or token_ids.min(initial=0) < 0:
            raise ValueError("id توکن خارج از بازه‌ی vocab_size است.")

        x = self.token_embedding[token_ids]
        for block in self.blocks:
            x = block(x, self.rope_cos, self.rope_sin)
        x = self.final_norm(x)
        logits = x @ self.token_embedding.T
        return logits

    def generate(
        self,
        prompt_ids: List[int],
        max_new_tokens: int = 16,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        rng: Optional[np.random.Generator] = None,
        stop_id: Optional[int] = None,
    ) -> List[int]:
        """حلقه‌ی نمونه‌برداریِ token-by-token (autoregressive).

        هر بار ``forward`` رویِ کلِ context (با پنجره‌یِ لغزانِ
        ``max_seq_len``) اجرا می‌شود و توکنِ بعدی از softmax(logits[-1])
        نمونه‌برداری می‌شود. با وزنِ آموزش‌ندیده، این فقط صحتِ مکانیزم را
        نشان می‌دهد، نه کیفیتِ متن.
        """
        if rng is None:
            rng = np.random.default_rng()
        ids = list(prompt_ids)
        for _ in range(max_new_tokens):
            context = ids[-self.config.max_seq_len :]
            logits = self.forward(np.array(context, dtype=np.int64))
            next_logits = logits[-1] / max(temperature, 1e-6)
            if top_k is not None and 0 < top_k < next_logits.shape[0]:
                kth = np.partition(next_logits, -top_k)[-top_k]
                next_logits = np.where(next_logits < kth, -np.inf, next_logits)
            probs = softmax(next_logits)
            next_id = int(rng.choice(len(probs), p=probs))
            ids.append(next_id)
            if stop_id is not None and next_id == stop_id:
                break
        return ids

    # --------------------------------------------------------- io ----
    def save_weights(self, path: str) -> None:
        """ذخیره‌یِ وزن‌ها (npz) -- برایِ بازتولیدپذیریِ دقیقِ همین وزن‌ها
        در آینده، فارغ از اینکه با کدام seed ساخته شده‌اند."""
        arrays = {"token_embedding": self.token_embedding}
        for i, block in enumerate(self.blocks):
            arrays[f"block{i}.attn.w_q"] = block.attn.w_q
            arrays[f"block{i}.attn.w_k"] = block.attn.w_k
            arrays[f"block{i}.attn.w_v"] = block.attn.w_v
            arrays[f"block{i}.attn.w_o"] = block.attn.w_o
            arrays[f"block{i}.attn_norm.weight"] = block.attn_norm.weight
            arrays[f"block{i}.ffn.w1"] = block.ffn.w1
            arrays[f"block{i}.ffn.w3"] = block.ffn.w3
            arrays[f"block{i}.ffn.w2"] = block.ffn.w2
            arrays[f"block{i}.ffn_norm.weight"] = block.ffn_norm.weight
        arrays["final_norm.weight"] = self.final_norm.weight
        np.savez(path, **arrays)

    def load_weights(self, path: str) -> None:
        data = np.load(path)
        self.token_embedding = data["token_embedding"]
        for i, block in enumerate(self.blocks):
            block.attn.w_q = data[f"block{i}.attn.w_q"]
            block.attn.w_k = data[f"block{i}.attn.w_k"]
            block.attn.w_v = data[f"block{i}.attn.w_v"]
            block.attn.w_o = data[f"block{i}.attn.w_o"]
            block.attn_norm.weight = data[f"block{i}.attn_norm.weight"]
            block.ffn.w1 = data[f"block{i}.ffn.w1"]
            block.ffn.w3 = data[f"block{i}.ffn.w3"]
            block.ffn.w2 = data[f"block{i}.ffn.w2"]
            block.ffn_norm.weight = data[f"block{i}.ffn_norm.weight"]
        self.final_norm.weight = data["final_norm.weight"]
