# -*- coding: utf-8 -*-
"""
transformer_core.py -- هسته‌ی Transformer (decoder-only)، پیاده‌سازیِ
خالصِ numpy، بدونِ وابستگی به torch/tensorflow (چون در محیطِ اجرایِ
فعلیِ پروژه -- ر.ک. requirements-core.txt -- هیچ‌کدام نصب نیستند و
هدفِ این مرحله اثباتِ صحتِ معماری است، نه کارایی؛ طبقِ بخشِ ۱۳ سند:
«Scaling نباید قبل از اثباتِ correctness انجام شود»).

اجزا دقیقاً طبقِ بخشِ ۵ و ۱۲-ج سند (درسِ Qwen: RoPE + RMSNorm + SwiGLU؛
درسِ DeepSeek/Llama: هر جزء در فایلِ/کلاسِ خودش، نه یک تابعِ غول‌پیکر):

    RMSNorm            نرمال‌سازی (بدونِ میانگین‌گیری، فقط rescale)
    RoPE               کدگذاریِ موقعیتِ چرخشی (rotary position embedding)
    CausalSelfAttention  توجهِ چندسر با ماسکِ علّی (تک‌طرفه)
    SwiGLUFeedForward   لایه‌ی feed-forward با gate‌ِ SiLU
    TransformerBlock    RMSNorm->Attn->residual, RMSNorm->FFN->residual

هر کلاس مستقلاً قابلِ import/تست است (بدونِ نیاز به کلِ مدل) -- دقیقاً
درسِ بخشِ ۹ سند («TRX باید از ابتدا contract-based باشد»).
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np


def silu(x: np.ndarray) -> np.ndarray:
    """SiLU / Swish: ``x * sigmoid(x)``."""
    return x / (1.0 + np.exp(-x))


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    x = x - np.max(x, axis=axis, keepdims=True)
    ex = np.exp(x)
    return ex / np.sum(ex, axis=axis, keepdims=True)


class RMSNorm:
    """Root-Mean-Square Layer Normalization (بدونِ centering، بدونِ bias)."""

    def __init__(self, dim: int, eps: float = 1e-6):
        self.dim = dim
        self.eps = eps
        self.weight = np.ones(dim, dtype=np.float64)

    def __call__(self, x: np.ndarray) -> np.ndarray:
        variance = np.mean(np.square(x), axis=-1, keepdims=True)
        x_norm = x * (1.0 / np.sqrt(variance + self.eps))
        return x_norm * self.weight


def precompute_rope(head_dim: int, max_seq_len: int, base: float = 10000.0) -> Tuple[np.ndarray, np.ndarray]:
    """جدولِ از پیش‌محاسبه‌شده‌یِ cos/sin برایِ Rotary Position Embedding.

    خروجی: دو آرایه‌یِ ``(max_seq_len, head_dim)``.
    """
    if head_dim % 2 != 0:
        raise ValueError("head_dim باید زوج باشد تا RoPE قابلِ اعمال باشد.")
    inv_freq = 1.0 / (base ** (np.arange(0, head_dim, 2, dtype=np.float64) / head_dim))
    t = np.arange(max_seq_len, dtype=np.float64)
    freqs = np.outer(t, inv_freq)  # (seq, head_dim/2)
    emb = np.concatenate([freqs, freqs], axis=-1)  # (seq, head_dim)
    return np.cos(emb), np.sin(emb)


def _rotate_half(x: np.ndarray) -> np.ndarray:
    d = x.shape[-1]
    x1 = x[..., : d // 2]
    x2 = x[..., d // 2 :]
    return np.concatenate([-x2, x1], axis=-1)


def apply_rope(x: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
    """اعمالِ RoPE رویِ ``x`` با شکلِ ``(seq, n_heads, head_dim)``.

    ``cos``/``sin`` با شکلِ ``(seq, head_dim)`` هستند و رویِ محورِ سر
    broadcast می‌شوند.
    """
    cos_b = cos[:, None, :]
    sin_b = sin[:, None, :]
    return x * cos_b + _rotate_half(x) * sin_b


class CausalSelfAttention:
    """توجهِ چندسرِ خودکار با ماسکِ علّی (هر موقعیت فقط به گذشته/خودش
    نگاه می‌کند -- پیش‌نیازِ صریحِ «پیش‌بینیِ توکنِ بعدی»)."""

    def __init__(self, d_model: int, n_heads: int, rng: np.random.Generator, std: float = 0.02):
        if d_model % n_heads != 0:
            raise ValueError("d_model باید بر n_heads بخش‌پذیر باشد.")
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.w_q = rng.normal(0.0, std, size=(d_model, d_model))
        self.w_k = rng.normal(0.0, std, size=(d_model, d_model))
        self.w_v = rng.normal(0.0, std, size=(d_model, d_model))
        self.w_o = rng.normal(0.0, std, size=(d_model, d_model))

    def __call__(self, x: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
        seq_len, d_model = x.shape
        q = (x @ self.w_q).reshape(seq_len, self.n_heads, self.head_dim)
        k = (x @ self.w_k).reshape(seq_len, self.n_heads, self.head_dim)
        v = (x @ self.w_v).reshape(seq_len, self.n_heads, self.head_dim)

        q = apply_rope(q, cos[:seq_len], sin[:seq_len])
        k = apply_rope(k, cos[:seq_len], sin[:seq_len])

        # (n_heads, seq, head_dim)
        q = q.transpose(1, 0, 2)
        k = k.transpose(1, 0, 2)
        v = v.transpose(1, 0, 2)

        scores = np.einsum("hqd,hkd->hqk", q, k) / math.sqrt(self.head_dim)
        causal_mask = np.triu(np.ones((seq_len, seq_len), dtype=bool), k=1)
        scores = np.where(causal_mask[None, :, :], -np.inf, scores)
        weights = softmax(scores, axis=-1)

        out = np.einsum("hqk,hkd->hqd", weights, v)  # (n_heads, seq, head_dim)
        out = out.transpose(1, 0, 2).reshape(seq_len, d_model)
        return out @ self.w_o


class SwiGLUFeedForward:
    """FFN با دروازه‌یِ SiLU: ``(silu(xW1) * xW3) W2`` (طبقِ درسِ Qwen)."""

    def __init__(self, d_model: int, d_ff: int, rng: np.random.Generator, std: float = 0.02):
        self.w1 = rng.normal(0.0, std, size=(d_model, d_ff))
        self.w3 = rng.normal(0.0, std, size=(d_model, d_ff))
        self.w2 = rng.normal(0.0, std, size=(d_ff, d_model))

    def __call__(self, x: np.ndarray) -> np.ndarray:
        gate = silu(x @ self.w1)
        up = x @ self.w3
        return (gate * up) @ self.w2


class TransformerBlock:
    """یک لایه‌یِ کاملِ Transformer: RMSNorm->Attention->residual،
    RMSNorm->SwiGLU->residual (معماریِ pre-norm، همان الگویِ Llama/Qwen)."""

    def __init__(self, d_model: int, n_heads: int, d_ff: int, rng: np.random.Generator):
        self.attn_norm = RMSNorm(d_model)
        self.attn = CausalSelfAttention(d_model, n_heads, rng)
        self.ffn_norm = RMSNorm(d_model)
        self.ffn = SwiGLUFeedForward(d_model, d_ff, rng)

    def __call__(self, x: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
        x = x + self.attn(self.attn_norm(x), cos, sin)
        x = x + self.ffn(self.ffn_norm(x))
        return x
