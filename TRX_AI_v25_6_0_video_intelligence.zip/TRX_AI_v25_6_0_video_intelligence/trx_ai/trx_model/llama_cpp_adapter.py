# -*- coding: utf-8 -*-
"""
llama_cpp_adapter.py -- یک پیاده‌سازیِ واقعیِ ``ModelInterface`` (بخشِ ۱۱
سند) روی یک مدلِ زبانیِ متن‌بازِ *محلی* (فایلِ GGUF، از طریقِ
``llama-cpp-python``).

چرا این فایل: ``trx_model`` (شبکه‌ی بومیِ TRX) با d_model=128 و ۲ لایه،
فقط رویِ اسنادِ خودِ پروژه آموزش دیده -- برایِ اثباتِ concept خوب است،
اما فهمِ زبانِ طبیعیِ واقعی ندارد. راه‌حلِ واقع‌بینانه (نه یک پروژه‌ی
ماه‌ها آموزشِ از صفر) این است: به‌جایِ ساختِ یک مدل، از یک مدلِ
از‌پیش‌آموزش‌دیده‌ی متن‌بازِ کوچک استفاده کنیم -- **کاملاً محلی، بدونِ
هیچ APIِ خارجی و بدونِ اتصالِ اینترنت در زمانِ اجرا** -- دقیقاً همان
اصلِ «بدونِ هیچ APIِ خارجی» که خودِ اپ از اول ادعایش را دارد.

این فایل دقیقاً همان ``ModelInterface`` را پیاده می‌کند که
``TRXNativeModelAdapter`` هم پیاده می‌کند -- یعنی طبقِ کامنتِ خودِ
``interfaces.py``: «حتی یک آداپتورِ جدا برایِ یک مدلِ بیرونی، کافی
است این interface را رعایت کند».

**نصب/راه‌اندازی (باید رویِ سیستمِ خودِ کاربر انجام شود -- این sandbox
اینترنت ندارد):**

    pip install llama-cpp-python

یک فایلِ GGUF دانلود کنید (مثلاً از Hugging Face، جست‌وجویِ
"Qwen2.5-3B-Instruct-GGUF"، کوانتیزاسیونِ Q4_K_M -- حدودِ ۲ گیگابایت،
رویِ CPUِ معمولی با ~۴-۶ گیگابایت RAM آزاد قابلِ اجراست، بدونِ نیاز به
GPU). جزئیاتِ کامل و توصیه‌هایِ سایزِ دیگر: ``LOCAL_LLM_INTEGRATION_NOTES.md``.

سپس مسیرِ فایل را با متغیرِ محیطیِ ``TRX_LOCAL_LLM_MODEL_PATH`` بدهید.

**لود تنبل (lazy):** import این فایل هرگز ``llama_cpp`` را import
نمی‌کند مگر واقعاً یک نمونه ساخته شود -- پس نبودِ کتابخانه/مدل هیچ‌کدام
از تست‌هایِ موجودِ پروژه را نمی‌شکند.
"""

from __future__ import annotations

import os
import threading
from typing import Any, List, Optional

from .interfaces import ConversationalModelInterface

DEFAULT_N_CTX = 4096
DEFAULT_N_THREADS = max(1, (os.cpu_count() or 4) - 1)
DEFAULT_MAX_NEW_TOKENS = 512
DEFAULT_TEMPERATURE = 0.6


class LocalLLMNotAvailableError(RuntimeError):
    """
    خطایِ صریح -- نه یک fallbackِ بی‌صدا (طبقِ قانونِ ممنوعیتِ راه‌حلِ
    فریبنده). وقتی ``llama-cpp-python`` نصب نیست یا فایلِ مدل پیدا
    نمی‌شود، این خطا بالا می‌آید تا مصرف‌کننده (``conversational_bridge.py``)
    آگاهانه به مسیرِ قدیمی برگردد -- نه اینکه سکوت کند و کاربر فکر کند
    چیزی «کار کرد» درحالی‌که اصلاً اجرا نشده.
    """


class LlamaCppModelAdapter(ConversationalModelInterface):
    """پیاده‌سازیِ ``ModelInterface`` رویِ یک مدلِ GGUFِ محلی از طریقِ llama-cpp-python."""

    def __init__(
        self,
        model_path: str,
        *,
        n_ctx: int = DEFAULT_N_CTX,
        n_threads: int = DEFAULT_N_THREADS,
        n_gpu_layers: int = 0,
        llama_factory: Optional[Any] = None,
    ):
        """
        ``llama_factory``: پارامترِ تزریقِ وابستگی برایِ تست -- در حالتِ
        عادی ``None`` می‌ماند و خودِ کلاس ``llama_cpp.Llama`` را
        lazy-import می‌کند؛ تست‌ها یک stub اینجا تزریق می‌کنند تا بدونِ
        نصبِ واقعیِ ``llama-cpp-python`` و بدونِ فایلِ چندگیگابایتیِ
        مدل، منطقِ خودِ این آداپتور (نه خودِ کتابخانه‌ی llama.cpp) تست
        شود.
        """
        if not model_path or not os.path.isfile(model_path):
            raise LocalLLMNotAvailableError(
                f"فایلِ مدلِ محلی پیدا نشد: {model_path!r}. "
                "طبقِ LOCAL_LLM_INTEGRATION_NOTES.md یک فایلِ GGUF دانلود "
                "کنید و مسیرش را با TRX_LOCAL_LLM_MODEL_PATH بدهید."
            )
        self.model_path = model_path
        self.n_ctx = n_ctx
        self.n_threads = n_threads
        self.n_gpu_layers = n_gpu_layers
        self._lock = threading.Lock()
        self._llama = self._build_llama(llama_factory)

    def _build_llama(self, llama_factory: Optional[Any]):
        if llama_factory is not None:
            # مسیرِ تست: خودِ factory مسئولِ ساختِ شیءِ stub است.
            return llama_factory(
                model_path=self.model_path,
                n_ctx=self.n_ctx,
                n_threads=self.n_threads,
                n_gpu_layers=self.n_gpu_layers,
            )
        try:
            from llama_cpp import Llama  # type: ignore
        except ImportError as exc:
            raise LocalLLMNotAvailableError(
                "بسته‌ی llama-cpp-python نصب نیست. طبقِ "
                "LOCAL_LLM_INTEGRATION_NOTES.md اجرا کنید: "
                "pip install llama-cpp-python"
            ) from exc
        return Llama(
            model_path=self.model_path,
            n_ctx=self.n_ctx,
            n_threads=self.n_threads,
            n_gpu_layers=self.n_gpu_layers,
            verbose=False,
        )

    # ------------------------------------------------- ModelInterface ----
    def encode(self, text: str) -> List[int]:
        return list(self._llama.tokenize(text.encode("utf-8")))

    def decode(self, ids: List[int]) -> str:
        raw = self._llama.detokenize(list(ids))
        return raw.decode("utf-8", errors="ignore") if isinstance(raw, bytes) else str(raw)

    def generate(self, prompt: str, max_new_tokens: int = DEFAULT_MAX_NEW_TOKENS, **kwargs) -> str:
        return self.chat(system_prompt="", user_text=prompt, max_new_tokens=max_new_tokens, **kwargs)

    # ------------------------------------------------- extra: chat API ----
    def chat(
        self,
        *,
        system_prompt: str,
        user_text: str,
        history: Optional[list[tuple[str, str]]] = None,
        max_new_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
        seed: Optional[int] = None,
    ) -> str:
        """
        نسخه‌ی chat-templateِ ``generate`` -- برایِ مدل‌هایِ instruct
        (مثلِ Qwen2.5-Instruct) که بدونِ قالبِ صحیحِ نقش‌ها (system/user/
        assistant) کیفیتِ پاسخشان بد می‌شود. ``create_chat_completion``ی
        llama-cpp-python خودش قالبِ درستِ مدل را (از متادیتایِ GGUF)
        اعمال می‌کند.

        ``seed`` (v25.5.7): فقط اگر صریحاً داده شود به
        ``create_chat_completion`` پاس داده می‌شود -- در نبودِ آن
        (``None``، پیش‌فرض)، دقیقاً همان رفتارِ تصادفیِ قبلی حفظ می‌شود
        (صفر تغییرِ رفتار برایِ مسیرِ تولیدِ فعلی).
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        for role, content in (history or []):
            messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": user_text})

        kwargs = {"messages": messages, "max_tokens": max_new_tokens, "temperature": temperature}
        if seed is not None:
            kwargs["seed"] = seed

        with self._lock:  # llama.cpp روی یک context، از دو ترد هم‌زمان امن نیست
            result = self._llama.create_chat_completion(**kwargs)
        try:
            return result["choices"][0]["message"]["content"].strip()
        except (KeyError, IndexError, TypeError) as exc:
            raise LocalLLMNotAvailableError(
                f"خروجیِ غیرمنتظره از llama-cpp-python: {result!r}"
            ) from exc
