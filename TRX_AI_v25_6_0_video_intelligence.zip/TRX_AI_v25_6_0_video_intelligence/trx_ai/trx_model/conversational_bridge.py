# -*- coding: utf-8 -*-
"""
conversational_bridge.py -- نقطه‌ی اتصالِ *ایمن* و *اختیاری* بینِ
``LlamaCppModelAdapter`` (مدلِ زبانیِ محلیِ واقعی) و مسیرِ گفتگویِ
زنده (``core_engine/tool_router.py``).

فلسفه‌ی طراحی (طبقِ همان الگویِ kill-switchِ ``phase3/config.py``،
اما ساده‌تر -- چون برخلافِ ``trx_model`` بومی که هنوز اثبات‌نشده است،
یک مدلِ متن‌بازِ استاندارد از قبل توسطِ سازنده‌اش آزموده شده؛ ریسکِ
اصلیِ اینجا فقط باگِ خودِ کدِ اتصال است، نه خودِ مدل):

    - پیش‌فرض خاموش (``TRX_LOCAL_LLM_ENABLED=false``) -- فعال‌سازی
      صریح لازم است.
    - هر خطایی (کتابخانه نصب نیست، فایلِ مدل نیست، timeout، خروجیِ
      غیرمنتظره) هرگز اپ را نمی‌ترکاند -- ``None`` برمی‌گرداند تا
      ``tool_router.py`` دقیقاً به همان fallbackِ قدیمی‌اش برگردد.
      یعنی فعال‌کردنِ این قابلیت **هیچ رفتارِ موجودی را حذف نمی‌کند**؛
      فقط یک مسیرِ *بهتر* را جلوی همان مسیرِ قدیمی می‌گذارد.
"""

from __future__ import annotations

import logging
import os
import threading
from typing import Optional

logger = logging.getLogger(__name__)

_ENABLED_ENV = "TRX_LOCAL_LLM_ENABLED"
_MODEL_PATH_ENV = "TRX_LOCAL_LLM_MODEL_PATH"
_MAX_TOKENS_ENV = "TRX_LOCAL_LLM_MAX_NEW_TOKENS"
_TEMPERATURE_ENV = "TRX_LOCAL_LLM_TEMPERATURE"

_SYSTEM_PROMPT = (
    "تو TRX AI هستی، یک دستیارِ هوشمندِ فارسی‌زبان. همیشه فقط و فقط به "
    "فارسیِ روان و طبیعی جواب بده (مگر کاربر صریحاً زبانِ دیگری بخواهد). "
    "کوتاه، صادق و مفید باش؛ اگر چیزی را نمی‌دانی، بگو نمی‌دانی به‌جایِ "
    "حدس‌زدن."
)

_adapter_lock = threading.Lock()
_adapter_instance = None  # type: ignore[var-annotated]
_adapter_load_failed = False


def is_enabled() -> bool:
    return os.environ.get(_ENABLED_ENV, "false").strip().lower() in ("1", "true", "yes", "on")


def _get_adapter():
    """
    Singletonِ lazy -- مدلِ چندگیگابایتی فقط یک‌بار (در اولین استفاده‌یِ
    واقعی) لود می‌شود، نه در import. اگر لود قبلاً fail شده باشد، دوباره
    امتحان نمی‌کنیم (از تلاشِ تکراریِ گران‌قیمت برایِ هر پیام جلوگیری
    می‌کند) -- تا وقتی پردازه ری‌استارت شود.
    """
    global _adapter_instance, _adapter_load_failed
    if _adapter_instance is not None:
        return _adapter_instance
    if _adapter_load_failed:
        return None
    with _adapter_lock:
        if _adapter_instance is not None:
            return _adapter_instance
        if _adapter_load_failed:
            return None
        try:
            from .llama_cpp_adapter import LlamaCppModelAdapter, LocalLLMNotAvailableError

            model_path = os.environ.get(_MODEL_PATH_ENV, "")
            _adapter_instance = LlamaCppModelAdapter(model_path=model_path)
            return _adapter_instance
        except Exception:
            logger.warning(
                "بارگذاریِ مدلِ زبانیِ محلی ناموفق بود -- به fallbackِ قدیمی برمی‌گردیم.",
                exc_info=True,
            )
            _adapter_load_failed = True
            return None


_MAX_HISTORY_TURNS_ENV = "TRX_LOCAL_LLM_MAX_HISTORY_TURNS"


def get_adapter():
    """
    دسترسیِ *عمومیِ* v25.5.7 به همان singleton lazy -- برایِ
    مصرف‌کننده‌هایی مثلِ ``nervous_system/experiments`` که نیاز به خودِ
    Adapter دارند (نه فقط ``try_generate_reply``ی سطح‌بالا)، بدونِ
    دوباره‌سازیِ منطقِ لود/کش. رفتارش دقیقاً هم‌الگو با ``_get_adapter``
    است (fail-soft -- در نبودِ کتابخانه/فایلِ مدل، ``None``).
    """
    return _get_adapter()


def build_history_from_db(db, limit: Optional[int] = None) -> list[tuple[str, str]]:
    """
    تاریخچه‌ی گفتگویِ *واقعی* (نه یک متنِ خلاصه‌ی flatten‌شده) را از
    همون جدولِ ``history``یِ موجود (``DatabaseManager.get_recent_history``)
    به شکلِ جفت‌هایِ ``(role, content)`` می‌سازد -- به‌ترتیبِ زمانیِ
    درست (قدیمی‌ترین اول)، چون ``get_recent_history`` خودش DESC
    برمی‌گرداند.

    نکته‌ی مهم (رفعِ ایرادِ ۲۰۲۶-۰۹-۲۰: «history=None بود»): این تابع
    دقیقاً قبل از اینکه پیامِ *جاری* در جدولِ history ذخیره شود صدا زده
    می‌شود (``ai._finalize`` بعداً آن را می‌نویسد -- نگاه کنید به
    کامنتِ همان قسمت در ``tool_router.py``) -- پس هیچ‌وقت پیامِ جاری
    را دوبار (هم در history، هم در user_text) نمی‌بینیم.

    اگر ``db`` این متد را نداشته باشد یا هر خطایی بدهد، فهرستِ خالی
    برمی‌گرداند (نه crash) -- سازگار با فلسفه‌ی محافظه‌کارانه‌ی بقیه‌ی
    این فایل.
    """
    if db is None:
        return []
    getter = getattr(db, "get_recent_history", None)
    if getter is None:
        return []
    if limit is None:
        limit = int(os.environ.get(_MAX_HISTORY_TURNS_ENV, "6"))
    try:
        rows = getter(limit=limit)
    except Exception:
        logger.warning("خواندنِ تاریخچه برایِ LLM محلی ناموفق بود.", exc_info=True)
        return []
    if not rows:
        return []

    pairs: list[tuple[str, str]] = []
    for row in reversed(list(rows)):  # DESC -> زمانیِ صعودی
        try:
            _timestamp, user_query, response = row
        except (ValueError, TypeError):
            continue
        if user_query:
            pairs.append(("user", str(user_query)))
        if response:
            pairs.append(("assistant", str(response)))
    return pairs


def try_generate_reply(
    user_text: str,
    *,
    history: Optional[list[tuple[str, str]]] = None,
    db=None,
) -> Optional[str]:
    """
    اگر فعال و در دسترس باشد، یک پاسخِ واقعیِ تولیدشده توسطِ مدلِ محلی
    برمی‌گرداند؛ در غیرِ این صورت (خاموش، نصب‌نشده، هر خطایِ دیگر)
    ``None`` -- که یعنی «فراخوان باید دقیقاً مثلِ قبل رفتار کند».

    ``history``: اگر صریحاً داده شود، همان استفاده می‌شود (مفید برایِ
    تست). اگر داده نشود ولی ``db`` داده شده باشد، تاریخچه‌ی واقعیِ
    گفتگو با ``build_history_from_db(db)`` ساخته می‌شود -- رفعِ
    ایرادِ ۲۰۲۶-۰۹-۲۰ («history از tool_router.py چیزی دریافت
    نمی‌کند»).
    """
    if not is_enabled():
        return None
    if not user_text or not user_text.strip():
        return None
    if history is None and db is not None:
        history = build_history_from_db(db)

    adapter = _get_adapter()
    if adapter is None:
        return None

    from .interfaces import ConversationalModelInterface

    if not isinstance(adapter, ConversationalModelInterface):
        # طبقِ رفعِ نکته‌یِ معماریِ ۲۰۲۶-۰۹-۲۰: یک Adapterِ آینده ممکن
        # است فقط ``ModelInterface`` (فقط ``generate``) را پیاده کند،
        # نه مکالمه‌ی چندنقشی را. اینجا صریحاً چک می‌کنیم و بی‌سروصدا
        # ``None`` برمی‌گردانیم -- به‌جایِ فرضِ ضمنیِ خطرناکِ اینکه هر
        # Adapterی حتماً ``.chat`` دارد.
        logger.warning(
            "آداپتورِ مدلِ محلی ConversationalModelInterface را پیاده نمی‌کند -- "
            "مکالمه‌ی محلی غیرفعال می‌ماند."
        )
        return None

    try:
        max_tokens = int(os.environ.get(_MAX_TOKENS_ENV, "512"))
        temperature = float(os.environ.get(_TEMPERATURE_ENV, "0.6"))
        reply = adapter.chat(
            system_prompt=_SYSTEM_PROMPT,
            user_text=user_text,
            history=history or [],
            max_new_tokens=max_tokens,
            temperature=temperature,
        )
        return reply.strip() or None
    except Exception:
        logger.warning("تولیدِ پاسخ با مدلِ محلی ناموفق بود -- به fallbackِ قدیمی برمی‌گردیم.", exc_info=True)
        return None


def reset_for_tests() -> None:
    """فقط برایِ تست: singleton را پاک می‌کند تا هر تست از صفر شروع کند."""
    global _adapter_instance, _adapter_load_failed
    with _adapter_lock:
        _adapter_instance = None
        _adapter_load_failed = False
