# -*- coding: utf-8 -*-
"""
سرورِ رابطِ کاربریِ وب — جایگزینِ کم‌وابستگی‌تر و باتوان‌تر برایِ
gui_app.py (PySide6).

چرا این معماری بهتر است:
    1. بدونِ وابستگیِ گرافیکیِ جدید: aiohttp از قبل CORE پروژه است
       (همان چیزی که برایِ آب‌وهوا/جستجوی وب استفاده می‌شود)، پس این
       رابط رویِ هر پلتفرمی که پایتون دارد کار می‌کند — از جمله
       Pydroid3/Termux روی اندروید، جایی که PySide6 اصلاً نصب نمی‌شود.
    2. بدونِ AsyncBridge/نخِ جداگانه: gui_app.py مجبور بود یک نخِ
       asyncio جدا اجرا کند و بینِ آن و نخِ اصلیِ Qt سیگنال رد‌و‌بدل
       کند (نگاه کنید به کامنت‌هایِ AsyncBridge در gui_app.py، و باگی
       که آنجا مستند شده). اینجا نیازی به این پیچیدگی نیست: aiohttp
       خودش asyncio-native است، پس core.py (که کاملاً async است)
       مستقیماً در همان event loop اجرا می‌شود.
    3. چند-کاربره‌بودنِ رایگان: چون رابط یک صفحه‌ی وب است، هر مرورگری
       (دسکتاپ یا موبایل) که به آدرسِ سرور وصل شود همان گفتگو را
       می‌بیند — مفید برایِ دسترسی از چند دستگاه.

پلِ رویداد ↔ WebSocket:
    `GuiUIEngine` (که قبلاً برایِ gui_app.py نوشته شده بود) از قبل هر
    خروجی را به‌صورتِ یک `GuiEvent(kind, **payload)` در یک صفِ
    thread-safe می‌گذارد. به‌جایِ نوشتنِ یک UIEngine کاملاً جدید برایِ
    وب، همان کلاس عیناً استفاده می‌شود؛ فقط یک تسکِ پس‌زمینه
    (`_event_broadcaster`) آن صف را می‌خواند و هر رویداد را به‌صورتِ
    JSON رویِ WebSocket برایِ کلاینت(های) متصل می‌فرستد. یعنی هیچ باگی
    که در مسیریابیِ core.py رفع شده دوباره در رابطِ وب ظاهر نمی‌شود —
    دقیقاً همان کد اجرا می‌شود (همان فلسفه‌ای که در docstring خودِ
    gui_ui_engine.py هم آمده).

🔐 احراز هویتِ اختیاری (``TRX_WEB_TOKEN``):
    پیش‌فرض (بدونِ تنظیمِ این متغیر) دقیقاً رفتارِ قبلی حفظ شده: هیچ
    احرازهویتی نیست — چون میزبانِ پیش‌فرض ``127.0.0.1`` است و فقط خودِ
    کاربر روی همان دستگاه به آن دسترسی دارد.

    اما README همین پروژه صراحتاً ``TRX_WEB_HOST=0.0.0.0`` را برایِ
    دسترسیِ چنددستگاهی پیشنهاد می‌دهد؛ در آن حالت، بدونِ هیچ محافظتی، هر
    کسِ دیگری رویِ همان شبکه (Wi-Fi مشترک/دانشگاه/کافه) به کلِ گفتگو،
    حافظه‌ی شخصی، هزینه‌ها و حتی مفسرِ کدِ فارسی دسترسیِ کامل پیدا
    می‌کرد. برایِ رفعِ این حفره، اگر ``TRX_WEB_TOKEN`` تنظیم شده باشد:
        - بارِ اولِ بازکردنِ صفحه باید با ``?token=...`` در URL باشد؛
          سرور آن را در یک کوکیِ HttpOnly ذخیره می‌کند و بلافاصله با
          یک ریدایرکتِ ۳۰۲ به همان مسیر *بدونِ* توکن در query string
          هدایت می‌کند -- یعنی توکن در نوارِ آدرس/historyِ مرورگر باقی
          نمی‌ماند (قبلاً می‌ماند، که می‌توانست از طریقِ history/لاگِ
          سرور/هدرِ Referrer نشت کند).
        - درخواست‌هایِ بعدی (``/ws``, ``/tts``) با همان کوکی تأیید
          می‌شوند؛ چون کوکی same-origin است، جاوااسکریپتِ موجود در
          ``web_assets.py`` به هیچ تغییری نیاز نداشت.
        - اگر توکن نادرست/نبود، ۴۰۱ برمی‌گردد (نه یک کرش گنگ).
        - تلاش‌هایِ ناموفقِ پیاپیِ یک IP محدود می‌شوند (rate limiting
          سادهِ درون‌حافظه‌ای: بیش از ۱۰ تلاشِ ناموفق در هر دقیقه = ۴۲۹)
          تا حدسِ brute-forceِ توکن عملاً کند/غیرِعملی شود.
    اگر میزبان غیرِ‌لوکال باشد ولی توکنی تنظیم نشده باشد، یک هشدارِ
    صریح در لاگ/کنسول چاپ می‌شود (نه سکوت) — نگاه کنید به ``run()``.

    محدودیتِ صادقانه: این سرور خودش TLS/HTTPS برقرار نمی‌کند؛ رویِ
    شبکه‌هایِ عمومی/مشترک (نه یک شبکه‌ی خانگیِ قابلِ‌اعتماد)، توکن/کوکی
    رویِ سیم به‌صورتِ متنِ‌ساده قابلِ استراق‌سمع‌اند. برایِ آن حالت، یک
    reverse proxy با TLS یا تانلِ SSH جلویِ این سرور لازم است.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import hmac
import json
import os
import queue
import secrets
import time
import webbrowser
from collections import defaultdict, deque

from aiohttp import web, WSMsgType

try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except Exception:  # pragma: no cover
    edge_tts = None
    EDGE_TTS_AVAILABLE = False

from .core import TRXEnterpriseAI
from .config import OS_FILES_DIR
from .gui_ui_engine import GuiEvent, GuiUIEngine
from .logging_config import get_logger
from .web_assets import INDEX_HTML

logger = get_logger(__name__)

# نامِ کوکیِ نگه‌دارنده‌ی توکن، فقط وقتی TRX_WEB_TOKEN تنظیم شده باشد استفاده می‌شود.
_TOKEN_COOKIE = "trx_token"

# --------------------------------------------------------------
# محدودسازیِ نرخِ تلاش‌هایِ ناموفقِ احرازهویت (brute-force protection).
# قبلاً هیچ محدودیتی نبود: یک مهاجم می‌توانست هزاران توکنِ تصادفی را
# پشتِ‌سرِهم امتحان کند بدونِ این‌که چیزی جلویش را بگیرد. این یک
# rate-limiter سادهِ درون‌حافظه‌ای است (نه توزیع‌شده/چندپردازشی -- برایِ
# یک سرورِ تک‌پردازشیِ شخصی که این پروژه هست کافی است): برای هر IP،
# اگر در بازه‌ی _RATE_LIMIT_WINDOW ثانیه بیش از _RATE_LIMIT_MAX تلاشِ
# ناموفق ثبت شود، تا پایانِ آن بازه با ۴۲۹ رد می‌شود.
# --------------------------------------------------------------
_RATE_LIMIT_WINDOW = 60.0   # ثانیه
_RATE_LIMIT_MAX = 10        # حداکثر تلاشِ ناموفقِ مجاز در هر بازه
_failed_attempts: dict[str, deque] = defaultdict(deque)


def _client_key(request: web.Request) -> str:
    return request.remote or "unknown"


def _is_rate_limited(request: web.Request) -> bool:
    key = _client_key(request)
    now = time.monotonic()
    attempts = _failed_attempts[key]
    while attempts and now - attempts[0] > _RATE_LIMIT_WINDOW:
        attempts.popleft()
    return len(attempts) >= _RATE_LIMIT_MAX


def _record_failed_attempt(request: web.Request) -> None:
    key = _client_key(request)
    _failed_attempts[key].append(time.monotonic())


def _configured_token() -> str | None:
    """مقدارِ TRX_WEB_TOKEN را می‌خواند؛ اگر خالی/تنظیم‌نشده بود، None."""
    token = os.environ.get("TRX_WEB_TOKEN", "").strip()
    return token or None


def _token_matches(request: web.Request, token: str) -> bool:
    """بررسیِ ثابت‌زمانِ توکنِ query-string یا کوکی در برابرِ مقدارِ تنظیم‌شده.

    از ``hmac.compare_digest`` استفاده می‌شود (نه ``==``) تا مقایسه در
    برابرِ حملاتِ timing-attack ایمن باشد.
    """
    supplied = request.query.get("token") or request.cookies.get(_TOKEN_COOKIE) or ""
    return bool(supplied) and hmac.compare_digest(supplied, token)


@web.middleware
async def _auth_middleware(request: web.Request, handler):
    """اگر TRX_WEB_TOKEN تنظیم شده باشد، هر درخواست را قبل از رسیدن به
    handler اصلی تأیید می‌کند؛ در غیرِ این‌صورت (پیش‌فرض) بدونِ هیچ
    تغییری در رفتار عبور می‌کند."""
    token = _configured_token()
    if not token:
        return await handler(request)

    if _is_rate_limited(request):
        logger.warning(
            "IPِ %s به‌دلیلِ تعدادِ زیادِ تلاشِ ناموفقِ توکن موقتاً مسدود شد.",
            _client_key(request),
        )
        return web.Response(
            text="🔒 تعداد تلاش‌های ناموفق زیاد بوده؛ کمی بعد دوباره امتحان کنید.",
            status=429,
        )

    if not _token_matches(request, token):
        _record_failed_attempt(request)
        logger.warning(
            "درخواستِ بدونِ توکنِ معتبر رد شد: %s %s از %s",
            request.method, request.path, request.remote,
        )
        if request.path == "/ws":
            # برای WebSocket نمی‌توان یک پاسخِ JSON معمولی داد؛ همان
            # هندشیک با کدِ ۴۰۱ رد می‌شود.
            raise web.HTTPUnauthorized(text="توکن نامعتبر است.")
        return web.Response(
            text="🔒 دسترسی نیاز به توکن دارد. آدرس را با «?token=توکن‌شما» باز کنید.",
            status=401,
        )

    # توکن از query string آمده (نه از کوکیِ از‌پیش‌موجود): به‌جایِ
    # اینکه همین حالا درخواستِ اصلی را پاسخ بدهیم (که یعنی توکن برایِ
    # همیشه در URL بارِ مرورگر و در historyِ آن می‌ماند)، کوکیِ HttpOnly
    # را همین‌جا تنظیم و کاربر را با ۳۰۲ به همان مسیر *بدونِ* query
    # string توکن هدایت می‌کنیم. این دقیقاً همان حفره‌ای را می‌بندد که
    # قبلاً مستند شده بود: «توکن در URL می‌تواند در browser
    # history/log/referrer نشت کند» — چون بعد از این ریدایرکت، توکن
    # دیگر در نوارِ آدرس/historyِ مرورگر باقی نمی‌ماند، فقط در کوکیِ
    # HttpOnلی (که جاوااسکریپت هم نمی‌تواند بخواندش) نگه داشته می‌شود.
    if request.query.get("token") == token and request.cookies.get(_TOKEN_COOKIE) != token:
        redirect_response = web.HTTPFound(location=request.path or "/")
        redirect_response.set_cookie(_TOKEN_COOKIE, token, httponly=True, samesite="Lax")
        return redirect_response

    return await handler(request)


async def _index(request: web.Request) -> web.Response:
    return web.Response(text=INDEX_HTML, content_type="text/html", charset="utf-8")


async def _tts(request: web.Request) -> web.StreamResponse:
    """تبدیلِ مستقیمِ متنِ پاسخ به صدایِ نورالِ مایکروسافت و پخشِ آن در وب.

    هیچ فایل MP3 روی دیسک ساخته نمی‌شود؛ edge-tts صوت را به‌صورتِ chunk
    تولید می‌کند و همان chunkها مستقیماً به مرورگر فرستاده می‌شوند.
    """
    if not EDGE_TTS_AVAILABLE:
        return web.json_response(
            {"error": "edge-tts نصب نیست؛ صدای نورال مایکروسافت در دسترس نیست."},
            status=503,
        )
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "درخواست صوتی نامعتبر است."}, status=400)

    text = str(data.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "متنی برای خواندن وجود ندارد."}, status=400)

    # همان صداهای Microsoft Neural قبلی پروژه. پیش‌فرض: صدای زن فارسی.
    choice = str(data.get("voice") or "2")
    voice = {
        "1": "fa-IR-FaridNeural",
        "2": "fa-IR-DilaraNeural",
    }.get(choice, "fa-IR-DilaraNeural")

    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "audio/mpeg",
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        },
    )
    await response.prepare(request)
    try:
        communicate = edge_tts.Communicate(text, voice)
        async for chunk in communicate.stream():
            if chunk.get("type") == "audio" and chunk.get("data"):
                await response.write(chunk["data"])
    except (ConnectionResetError, asyncio.CancelledError):
        raise
    except Exception as e:
        logger.exception("خطا در تولید صدای نورال مایکروسافت: %s", e)
        # اگر هدرها قبلاً ارسال شده باشند، پاسخ JSON ممکن نیست؛ اتصال را می‌بندیم.
    finally:
        try:
            await response.write_eof()
        except Exception as e:
            logger.debug("بستنِ استریمِ پاسخِ TTS شکست خورد (احتمالاً کلاینت زودتر قطع کرده): %s", e)
    return response


async def _ws_handler(request: web.Request) -> web.WebSocketResponse:
    # max_msg_size پیش‌فرضِ aiohttp (۴ مگابایت) برایِ یک عکسِ معمولیِ
    # موبایل (که بعدِ Base64 حدودِ ۱.۳۳ برابرِ حجمِ اصلی می‌شود) کافی
    # نیست؛ سقفِ واقعیِ حجمِ فایل در vision.MAX_IMAGE_BYTES (۱۵ مگابایت)
    # است، پس اینجا باید کمی بیشتر از آن (با احتسابِ overheadِ Base64 +
    # JSON) اجازه داده شود.
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=22 * 1024 * 1024)
    await ws.prepare(request)

    app = request.app
    app["clients"].add(ws)
    logger.info("یک کلاینتِ وب متصل شد (مجموع: %d).", len(app["clients"]))

    try:
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                continue
            try:
                data = json.loads(msg.data)
            except (json.JSONDecodeError, TypeError):
                continue

            msg_type = data.get("type")

            if msg_type == "init":
                # فقط یک‌بار (برایِ اولین کلاینتی که وصل می‌شود) واقعاً
                # راه‌اندازی می‌کند؛ اگر کلاینتِ دومی (مثلاً تبِ دیگر)
                # وصل شود، همان app_core/ui_engینِ مشترک از قبل آماده
                # است و دوباره init نمی‌شود (جلوگیری از بازنشانیِ حافظه).
                #
                # قفل (نه فقط چک‌کردنِ ساده‌ی «if not initialized»):
                # بدونِ قفل، اگر دو کلاینت تقریباً هم‌زمان «init» بفرستند،
                # هردو تسک قبل از این‌که هرکدام app["initialized"] را
                # True کند از رویِ چک رد می‌شوند (چون بینِ چک‌کردن و
                # ست‌کردن یک await فاصله است) و init_for_gui دوبار و
                # هم‌زمان اجرا می‌شود — مثلاً دو aiohttp.ClientSession
                # ساخته می‌شود و یکی‌شان بی‌صاحب می‌ماند.
                async with app["init_lock"]:
                    if not app["initialized"]:
                        name = (data.get("name") or "").strip() or None
                        try:
                            await app["app_core"].init_for_gui(app["ui_engine"], user_name=name)
                            app["initialized"] = True
                        except Exception as e:  # noqa: BLE001 - راه‌اندازیِ اولیه نباید سرور را بترکاند
                            logger.exception("خطا در راه‌اندازیِ اولیه‌ی وب: %s", e)
                            app["ui_engine"].events.put(
                                _make_error_event(f"خطا در راه‌اندازیِ اولیه: {e}")
                            )
                        finally:
                            # همان رویدادِ «turn_end» که پایینِ _run_turn
                            # توضیح داده شده: کلاینت با دیدنِ این، فرم
                            # ورودی را فعال می‌کند (چه init موفق شود چه
                            # نه — حتی روی خطا نباید کاربر برای همیشه
                            # پشتِ صفحه‌ی خوش‌آمدگویی گیر کند).
                            app["ui_engine"].events.put(GuiEvent("turn_end"))

            elif msg_type == "message":
                text = (data.get("text") or "").strip()
                if text:
                    asyncio.create_task(_run_turn(app, text))

            elif msg_type == "image":
                # {"type":"image","data":"<base64 بدونِ پیشوندِ data:...>","mime":"image/jpeg","caption":"..."}
                b64 = data.get("data") or ""
                mime = (data.get("mime") or "").strip()
                caption = (data.get("caption") or "").strip()
                try:
                    raw_bytes = base64.b64decode(b64, validate=True)
                except (binascii.Error, ValueError):
                    app["ui_engine"].events.put(_make_error_event("❌ داده‌ی عکس نامعتبر بود."))
                    app["ui_engine"].events.put(GuiEvent("turn_end"))
                    continue
                if raw_bytes:
                    asyncio.create_task(_run_image_turn(app, raw_bytes, mime, caption))

            elif msg_type == "file":
                # {"type":"file","data":"<base64>","filename":"report.pdf","caption":"..."}
                # معادلِ «image» بالا، اما برایِ اسناد (PDF/Word/Excel/متن/کد)
                # -- نگاه کنید به core.py._process_file_turn.
                b64 = data.get("data") or ""
                filename = (data.get("filename") or "").strip()
                caption = (data.get("caption") or "").strip()
                try:
                    raw_bytes = base64.b64decode(b64, validate=True)
                except (binascii.Error, ValueError):
                    app["ui_engine"].events.put(_make_error_event("❌ داده‌ی فایل نامعتبر بود."))
                    app["ui_engine"].events.put(GuiEvent("turn_end"))
                    continue
                if raw_bytes:
                    asyncio.create_task(_run_file_turn(app, raw_bytes, filename, caption))


    finally:
        app["clients"].discard(ws)
        logger.info("یک کلاینتِ وب قطع شد (مجموع: %d).", len(app["clients"]))

    return ws


async def _run_turn(app: web.Application, text: str) -> None:
    """اجرایِ یک نوبتِ گفتگو در یک taskِ جدا، تا حلقه‌ی اصلیِ WebSocket بلاک نشود."""
    async with app["turn_lock"]:
        # قفل: بدونِ این، اگر کاربر (یا یک تبِ دوم) قبل از رسیدنِ پاسخِ
        # نوبتِ اول یک پیامِ دیگر بفرستد، دو _process_turn هم‌زمان رویِ
        # همان app_core مشترک اجرا می‌شوند — self._pending_restore،
        # self._response_times، و نوشتن‌هایِ history می‌توانند قاطی
        # شوند. سمتِ کلاینت هم sendBtn را غیرفعال می‌کند، اما آن فقط
        # همان یک کلاینت را می‌گیرد، نه یک تبِ دومِ باز یا یک کلاینتِ
        # دیگر رویِ همان شبکه (این رابط عمداً چندکاربره طراحی شده).
        try:
            await app["app_core"]._process_turn(text)
        except Exception as e:  # noqa: BLE001 - خطایِ یک نوبت نباید کلِ سرور را بترکاند
            logger.exception("خطا در پردازشِ پیام: %s", e)
            app["ui_engine"].events.put(_make_error_event(f"خطا: {e}"))
        finally:
            # باگِ واقعی که با همین رویداد رفع شد: کلاینتِ وب sendBtn را
            # فقط با دیدنِ رویدادهایِ خاص (message/emergency/followup/
            # stream_end) دوباره فعال می‌کرد. دستورهایی که فقط از طریقِ
            # self.ui.console.print(...) خروجی می‌دهند (مثلاً «آمار»،
            # «داشبورد»، «تاریخچه»، «در مخفی» — که «آمار»/«داشبورد»/
            # «تاریخچه» دقیقاً همان‌هایی هستند که در نوارِ میانبرها هم
            # هستند) فقط یک رویدادِ «raw» تولید می‌کنند؛ نتیجه: دکمه‌ی
            # ارسال بعد از این دستورها تا ابد غیرفعال می‌ماند — همان
            # کلاسِ باگی که در gui_app.py (v20.18/v20.19) پیدا و رفع
            # شد، اینجا به شکلِ دیگری دوباره ظاهر شده بود. راه‌حلِ درست:
            # به‌جایِ حدس‌زدن از رویِ نوعِ رویداد، یک رویدادِ صریحِ
            # «پایانِ نوبت» همیشه (چه موفق چه خطا) فرستاده می‌شود.
            app["ui_engine"].events.put(GuiEvent("turn_end"))


async def _run_image_turn(app: web.Application, raw_bytes: bytes, mime: str, caption: str) -> None:
    """معادلِ `_run_turn` برایِ عکس -- همان قفل، همان تضمینِ «پایانِ نوبت»."""
    async with app["turn_lock"]:
        try:
            await app["app_core"]._process_image_turn(raw_bytes, mime, caption)
        except Exception as e:  # noqa: BLE001 - خطایِ یک نوبت نباید کلِ سرور را بترکاند
            logger.exception("خطا در پردازشِ عکس: %s", e)
            app["ui_engine"].events.put(_make_error_event(f"خطا در پردازشِ عکس: {e}"))
        finally:
            app["ui_engine"].events.put(GuiEvent("turn_end"))


async def _run_file_turn(app: web.Application, raw_bytes: bytes, filename: str, caption: str) -> None:
    """معادلِ `_run_turn` برایِ آپلودِ فایل -- همان قفل، همان تضمینِ «پایانِ نوبت»."""
    async with app["turn_lock"]:
        try:
            await app["app_core"]._process_file_turn(raw_bytes, filename, caption)
        except Exception as e:  # noqa: BLE001 - خطایِ یک نوبت نباید کلِ سرور را بترکاند
            logger.exception("خطا در پردازشِ فایل: %s", e)
            app["ui_engine"].events.put(_make_error_event(f"خطا در پردازشِ فایل: {e}"))
        finally:
            app["ui_engine"].events.put(GuiEvent("turn_end"))


def _make_error_event(text: str):
    from .gui_ui_engine import GuiEvent

    return GuiEvent("message", text=text, title="❌ خطا", style="")


async def _event_broadcaster(app: web.Application) -> None:
    """
    هر ۳۰ میلی‌ثانیه صفِ رویدادهایِ GuiUIEngine را خالی می‌کند و هرچه
    پیدا کرد را به‌صورتِ JSON به همه‌ی کلاینت‌هایِ WebSocketِ متصل
    می‌فرستد. صفِ `queue.Queue` عمداً thread-safe است (میراثِ طراحیِ
    gui_app.py)، اما اینجا چون همه‌چیز در یک event loop اجرا می‌شود،
    فقط با `get_nowait()` غیرمسدودکننده خوانده می‌شود.
    """
    ui_engine: GuiUIEngine = app["ui_engine"]
    while True:
        await asyncio.sleep(0.03)
        events = []
        while True:
            try:
                events.append(ui_engine.events.get_nowait())
            except queue.Empty:
                break
        if not events or not app["clients"]:
            continue

        dead = []
        for ev in events:
            payload = {"kind": ev.kind, **ev.payload}
            try:
                text = json.dumps(payload, ensure_ascii=False, default=str)
            except (TypeError, ValueError):
                continue
            for ws in list(app["clients"]):
                try:
                    await ws.send_str(text)
                except Exception:  # noqa: BLE001 - یک کلاینتِ خراب نباید بقیه را متوقف کند
                    dead.append(ws)
        for ws in dead:
            app["clients"].discard(ws)


async def _on_startup(app: web.Application) -> None:
    app["broadcaster_task"] = asyncio.create_task(_event_broadcaster(app))


async def _on_cleanup(app: web.Application) -> None:
    task = app.get("broadcaster_task")
    if task:
        task.cancel()
    app_core: TRXEnterpriseAI = app["app_core"]
    if app.get("initialized"):
        try:
            await app_core.shutdown_gui()
        except Exception as e:  # noqa: BLE001
            logger.debug("خطا هنگامِ بستنِ منظمِ session: %s", e)


def build_app() -> web.Application:
    app = web.Application(middlewares=[_auth_middleware])
    app["app_core"] = TRXEnterpriseAI()
    app["ui_engine"] = GuiUIEngine()
    app["clients"] = set()
    app["initialized"] = False
    # این دو قفل با هم باعث می‌شوند «فقط یک چیز در یک لحظه»: نه دو
    # init_for_gui هم‌زمان، نه دو _process_turn هم‌زمان رویِ همان
    # app_coreِ مشترک (نگاه کنید به کامنت‌هایِ _ws_handler/_run_turn).
    app["init_lock"] = asyncio.Lock()
    app["turn_lock"] = asyncio.Lock()

    app.router.add_get("/", _index)
    app.router.add_get("/ws", _ws_handler)
    app.router.add_post("/tts", _tts)
    # سرو کردنِ عکس‌هایِ ذخیره‌شده/بهبودیافته (vision.py) برایِ نمایش در
    # حباب‌هایِ چت -- همان پوشه‌ای که `ImageEngine` رویش می‌نویسد
    # (`config.OS_FILES_DIR`)، نه یک مسیرِ جدا.
    app.router.add_static("/files/", path=OS_FILES_DIR, show_index=False)

    app.on_startup.append(_on_startup)
    app.on_cleanup.append(_on_cleanup)
    return app


def run(host: str = "127.0.0.1", port: int = 8765, open_browser: bool = True) -> None:
    """
    اجرایِ سرورِ وب — نقطه‌ی ورودِ ساده که ``web_main.py`` صدا می‌زند.

    نکته برایِ Pydroid3: بعد از اجرا، خودِ Pydroid3 در ترمینالِ داخلی‌اش
    برنامه را در پس‌زمینه اجرا نگه می‌دارد؛ کافی‌ست مرورگرِ گوشی
    (Chrome/...) را باز کنید و به آدرسِ نمایش‌داده‌شده بروید (معمولاً
    http://127.0.0.1:8765).
    """
    # اگر میزبان غیرِ‌لوکال است (مثلاً TRX_WEB_HOST=0.0.0.0 طبقِ توصیه‌ی
    # README برایِ دسترسیِ چنددستگاهی) و هیچ توکنی هم تنظیم نشده، یعنی
    # هر کسِ دیگری رویِ همان شبکه می‌تواند بدونِ محدودیت وصل شود. به‌جایِ
    # سکوت، یک توکنِ تصادفی همین‌جا ساخته و به‌عنوانِ متغیرِ محیطی برایِ
    # همین پردازش تنظیم می‌شود تا middleware آن را اعمال کند، و در
    # کنسول/لاگ به‌وضوح نمایش داده می‌شود.
    if host not in ("127.0.0.1", "localhost", "::1") and not _configured_token():
        auto_token = secrets.token_urlsafe(16)
        os.environ["TRX_WEB_TOKEN"] = auto_token
        logger.warning(
            "میزبانِ غیرِ‌لوکال (%s) بدونِ TRX_WEB_TOKEN تنظیم شده بود؛ "
            "یک توکنِ موقت به‌صورتِ خودکار ساخته شد.", host,
        )
        print(f"⚠️  دسترسی رویِ شبکه بدونِ توکن ناامن است — یک توکنِ موقت ساخته شد.")
        print(f"   فقط با این آدرس وارد شوید تا معتبر بماند:")
        print(f"   http://{host}:{port}/?token={auto_token}")
        print(f"   (برایِ تنظیمِ یک توکنِ ثابتِ خودتان: TRX_WEB_TOKEN=... را از قبل export کنید)")

    if host not in ("127.0.0.1", "localhost", "::1"):
        # نکته‌ی صادقانه: توکن جلویِ دسترسیِ بدونِ‌مجوز را می‌گیرد، اما
        # این سرور خودش هیچ‌گاه TLS/HTTPS برقرار نمی‌کند -- ترافیک
        # (شاملِ همان توکن و کوکی) رویِ شبکه‌ی محلی به‌صورتِ متنِ‌سادهِ
        # HTTP رد‌و‌بدل می‌شود. رویِ یک Wi-Fi عمومی/مشترک، کسی که ترافیک
        # را استراق‌سمع کند می‌تواند توکن/کوکی را بخواند. برایِ دسترسیِ
        # واقعاً امن رویِ شبکه (نه فقط شبکه‌ی خانگیِ قابلِ‌اعتماد)، یک
        # reverse proxy با TLS (مثلاً Caddy/nginx یا یک تانلِ SSH) جلویِ
        # این سرور لازم است -- این پروژه خودش این را فراهم نمی‌کند.
        print(
            "⚠️  این سرور از HTTPS/TLS پشتیبانی نمی‌کند؛ روی شبکه‌های "
            "عمومی/مشترک (نه شبکه‌ی خانگیِ قابل‌اعتماد)، برای امنیتِ "
            "واقعی از یک reverse proxy با TLS یا تانلِ SSH استفاده کنید."
        )

    app = build_app()
    url = f"http://{host}:{port}"
    logger.info("سرورِ وبِ TRX AI روی %s در حالِ اجراست.", url)
    print(f"🌐 TRX AI روی مرورگر آماده است: {url}")
    print("   (برایِ توقف: Ctrl+C)")

    if open_browser:
        browse_url = url
        token = _configured_token()
        if token:
            browse_url = f"{url}/?token={token}"
        try:
            webbrowser.open(browse_url)
        except Exception as e:  # noqa: BLE001 - نبودِ مرورگرِ قابلِ‌بازکردن (مثلاً سرورِ headless) نباید کرش کند
            logger.debug("بازکردنِ خودکارِ مرورگر شکست خورد (احتمالاً محیطِ headless): %s", e)

    web.run_app(app, host=host, port=port, print=None)
