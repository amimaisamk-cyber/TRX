# -*- coding: utf-8 -*-
"""
Model Manager (سندِ معماری، بخش‌هایِ ۲۶، ۸۰-۸۴).

این پروژه هیچ وزنِ مدلِ Neural (SR/Deblur/OCR آموزش‌دیده) همراهش
ندارد و در این محیط اینترنتی برایِ دانلودشان هم در دسترس نیست. پس
Registry فقط عملیاتِ کلاسیکِ واقعاً پیاده‌شده را AVAILABLE می‌کند و
معادلِ Neural هرکدام را صادقانه UNAVAILABLE نگه می‌دارد -- دقیقاً
طبقِ بخشِ ۸۱ («Commander فقط مدل‌هایِ Available را انتخاب کند»).
"""

from __future__ import annotations

from dataclasses import dataclass

from ..dependencies import CV2_AVAILABLE
from .contracts import STATUS_CLASSICAL, STATUS_NEURAL_UNAVAILABLE


@dataclass
class ModelInfo:
    model_id: str
    model_type: str
    backend: str
    status: str
    quality_profile: str


class ModelManager:
    """discover_models()/select_model() ساده -- بدونِ فایلِ وزنِ واقعی."""

    def __init__(self):
        backend = "cv2+numpy" if CV2_AVAILABLE else "pillow-only"
        self._registry = {
            "denoise": ModelInfo("CLASSICAL_DENOISE_V1", "denoise", backend, STATUS_CLASSICAL, "medium"),
            "deblur": ModelInfo("CLASSICAL_UNSHARP_DEBLUR_V1", "deblur", backend, STATUS_CLASSICAL, "medium"),
            "super_resolution": ModelInfo(
                "CLASSICAL_LANCZOS_UPSCALE_V1", "super_resolution", backend, STATUS_CLASSICAL, "low-medium"
            ),
            "low_light": ModelInfo("CLASSICAL_GAMMA_CLAHE_V1", "low_light", backend, STATUS_CLASSICAL, "medium"),
            "color_restore": ModelInfo("CLASSICAL_GRAYWORLD_V1", "color_restore", backend, STATUS_CLASSICAL, "medium"),
            "artifact_removal": ModelInfo(
                "CLASSICAL_MEDIAN_DERING_V1", "artifact_removal", backend, STATUS_CLASSICAL, "low-medium"
            ),
            "detail_restore": ModelInfo("CLASSICAL_UNSHARP_DETAIL_V1", "detail_restore", backend, STATUS_CLASSICAL, "medium"),
            # هیچ‌کدامِ این‌ها واقعاً موجود نیستند -- عمداً این‌جا نگه‌داشته
            # شده‌اند تا Commander/Report همیشه صادقانه بگویند چرا از
            # نسخه‌یِ Neural استفاده نشد.
            "neural_super_resolution": ModelInfo(
                "NEURAL_SR_V1", "super_resolution", "-", STATUS_NEURAL_UNAVAILABLE, "-"
            ),
            "neural_deblur": ModelInfo("NEURAL_DEBLUR_V1", "deblur", "-", STATUS_NEURAL_UNAVAILABLE, "-"),
            "neural_ocr": ModelInfo("NEURAL_OCR_V1", "ocr", "-", STATUS_NEURAL_UNAVAILABLE, "-"),
        }

    def discover(self) -> dict:
        return dict(self._registry)

    def is_available(self, op: str) -> bool:
        info = self._registry.get(op)
        return bool(info and info.status == STATUS_CLASSICAL)

    def model_for(self, op: str) -> ModelInfo:
        return self._registry.get(op)

    def backend_label(self) -> str:
        return "cv2+numpy" if CV2_AVAILABLE else "pillow-only"
