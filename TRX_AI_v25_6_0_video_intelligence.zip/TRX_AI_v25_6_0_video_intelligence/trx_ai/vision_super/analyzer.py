# -*- coding: utf-8 -*-
"""
Analyzer Arm (سندِ معماری، بخشِ ۱۱): فقط تحلیل می‌کند، هیچ پیکسلی را
تغییر نمی‌دهد. ورودی: PerceptionState + برچسب‌هایِ VisionBrain.
خروجی: لیستِ DamageIssue + لیستِ عملیاتِ پیشنهادی + یک گزارشِ متنی
(همان قالبِ «ANALYZER REPORT» در سند).

آستانه‌ها heuristic و کلاسیک‌اند (نه خروجیِ یک مدلِ یادگرفته‌شده)؛
severity/confidence همیشه به همین دلیل صادقانه محافظه‌کارانه‌اند.
"""

from __future__ import annotations

from typing import List

from .contracts import DamageIssue, PerceptionState, VisionState


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


class DamageAnalyzer:
    def diagnose(self, p: PerceptionState, image_types: List[str]) -> VisionState:
        issues: List[DamageIssue] = []
        ops: List[str] = []

        if p.backend == "cv2+numpy":
            blur_severity = _clamp(1.0 - (p.sharpness / 150.0))
            noise_severity = _clamp(p.noise_estimate / 18.0)
        else:
            blur_severity = _clamp(1.0 - (p.edge_density * 4.0))
            noise_severity = _clamp(p.noise_estimate / 18.0)

        if blur_severity > 0.35:
            conf = _clamp(0.5 + blur_severity * 0.4)
            issues.append(DamageIssue("BLUR", round(blur_severity, 2), round(conf, 2)))
            ops.append("deblur")

        if noise_severity > 0.3:
            conf = _clamp(0.5 + noise_severity * 0.4)
            issues.append(DamageIssue("SENSOR_NOISE", round(noise_severity, 2), round(conf, 2)))
            ops.append("denoise")

        if p.low_light:
            under = _clamp((LOW_LIGHT_REF - p.brightness) / LOW_LIGHT_REF) if p.brightness < LOW_LIGHT_REF else 0.0
            issues.append(DamageIssue("UNDEREXPOSURE", round(_clamp(under + 0.2), 2), 0.7))
            ops.append("low_light")

        if p.brightness > 235:
            issues.append(DamageIssue("OVEREXPOSURE", round(_clamp((p.brightness - 235) / 20), 2), 0.6))

        if p.compression_artifact_score > 0.3:
            issues.append(DamageIssue("JPEG_ARTIFACTS", round(p.compression_artifact_score, 2), 0.5))
            ops.append("artifact_removal")

        if p.contrast_std < 30:
            issues.append(DamageIssue("LOW_CONTRAST", round(_clamp((30 - p.contrast_std) / 30), 2), 0.55))
            ops.append("color_restore")

        if p.saturation_mean < 40 and "SCREENSHOT" not in image_types:
            issues.append(DamageIssue("COLOR_FADE", round(_clamp((40 - p.saturation_mean) / 40), 2), 0.45))
            if "color_restore" not in ops:
                ops.append("color_restore")

        if p.width < 900:
            issues.append(DamageIssue("LOW_RESOLUTION", 0.6, 0.9))
            ops.append("super_resolution")

        if not issues:
            issues.append(DamageIssue("NONE_DETECTED", 0.0, 0.6))

        # جزئیات همیشه آخرین پاسِ ظریف است (بعد از تمیزکردنِ نویز/بلور)
        ops.append("detail_restore")

        overall_confidence = round(sum(i.confidence for i in issues) / len(issues), 2)

        return VisionState(
            perception=p,
            image_types=image_types,
            issues=issues,
            recommended_ops=ops,
            confidence=overall_confidence,
        )

    def report(self, state: VisionState) -> str:
        p = state.perception
        lines = [
            "ANALYZER REPORT",
            "",
            f"Resolution: {p.width}x{p.height}",
            f"Types: {', '.join(state.image_types)}",
            "",
        ]
        for issue in state.issues:
            lines.append(f"{issue.type}: severity={issue.severity * 100:.0f}% confidence={issue.confidence * 100:.0f}%")
        lines.append("")
        lines.append(f"Recommended: {' + '.join(state.recommended_ops)}")
        lines.append(f"Backend: {p.backend} (classical heuristics, no trained neural model)")
        return "\n".join(lines)


LOW_LIGHT_REF = 90.0
