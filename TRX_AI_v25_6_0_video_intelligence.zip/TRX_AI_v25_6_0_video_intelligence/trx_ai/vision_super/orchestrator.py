# -*- coding: utf-8 -*-
"""
Vision Orchestrator (سندِ معماری، بخش‌هایِ ۲۹، ۷۸).

Pipeline:
  INPUT -> PERCEPTION -> VISION BRAIN -> ANALYZER -> COMMANDER -> PLAN
        -> SPECIALIST ARMS -> QUALITY JUDGE -> VERSION MANAGER -> MEMORY
        -> BEST RESULT

این ماژول تنها نقطه‌ی ورودیِ عمومیِ vision_super است. ``vision.py``
(ImageEngine) فقط همین را صدا می‌زند.
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time

from ..logging_config import get_logger
from .analyzer import DamageAnalyzer
from .brain import VisionBrain
from .commander import Commander
from .contracts import (
    AI_STATUS_CLASSICAL_FALLBACK,
    AI_STATUS_NO_OPERATION_NEEDED,
    AI_STATUS_REAL_AI,
    STATUS_NEURAL_ACTIVE,
    RestorationReport,
)
from .judge import QualityJudge
from .memory import MemoryEngine
from .models_registry import ModelManager
from .optimizer import IterativeOptimizer
from .perception import PerceptionEngine
from .resource import ResourceManager
from .version_manager import VersionManager

logger = get_logger(__name__)


class VisionOrchestrator:
    def __init__(self, files_dir: str):
        self.files_dir = files_dir
        memory_path = os.path.join(files_dir, ".vision_memory.json")
        self.memory = MemoryEngine(memory_path)
        self.models = ModelManager()
        self.resources = ResourceManager()
        self.perception = PerceptionEngine()
        self.brain = VisionBrain()
        self.analyzer = DamageAnalyzer()
        self.judge = QualityJudge()

    # ------------------------------------------------------------
    def analyze_only(self, img) -> tuple:
        """بخشِ ۱۱ -- فقط تشخیص، بدونِ تغییرِ هیچ پیکسلی. برایِ حالتِ
        «فقط بگو چه مشکلی داره» مفید است."""
        p = self.perception.analyze(img)
        types = self.brain.classify(p)
        state = self.analyzer.diagnose(p, types)
        return state, self.analyzer.report(state)

    # ------------------------------------------------------------
    def restore(self, img, out_path: str) -> tuple:
        """اجرایِ کاملِ چرخه؛ خروجی: (final_img, RestorationReport)."""
        device = self.resources.profile()
        commander = Commander(self.models, self.memory)
        version_manager = VersionManager()
        optimizer = IterativeOptimizer(self.judge, version_manager)

        state, analyzer_text = self.analyze_only(img)
        logger.info("VISION ANALYZE:\n%s", analyzer_text)

        plans = commander.build_plans(state)
        target = self.judge.target_for(state.image_types)

        tmp_dir = tempfile.mkdtemp(prefix="trx_vision_")
        best_version = None
        try:
            before_score, best_version = optimizer.run(img, state, plans, tmp_dir, target)
            if best_version.round_no > 0:
                from PIL import Image

                with Image.open(best_version.image_path) as loaded:
                    final_img = loaded.convert("RGB").copy()
            else:
                final_img = img.convert("RGB")
            final_img.save(out_path)

            gain = best_version.score.overall - before_score.overall
            self.memory.record_case(
                image_types=state.image_types,
                issues=[i.type for i in state.issues],
                plan=best_version.plan_name,
                ops=best_version.ops_applied,
                before=before_score.overall,
                after=best_version.score.overall,
                success=gain > 0,
            )
            for op in best_version.ops_applied:
                self.memory.record_operation(op, gain, success=gain > 0)
            self.memory.flush()

            # HONEST AI REPORTING (بخشِ ۱۳۰): «AI استفاده شد» فقط وقتی
            # True است که حداقل یکی از عملیاتِ واقعاً اجراشده روی یک
            # مدلِ ثبت‌شده با وضعیتِ STATUS_NEURAL_ACTIVE اجرا شده باشد --
            # نه صرفاً «هر عملیاتی اجرا شد». قبلاً
            # ``ai_used=bool(best_version.ops_applied)`` بود، یعنی حتی
            # وقتی denoise/deblur/super_resolution با پیاده‌سازیِ کاملاً
            # کلاسیک (Pillow/OpenCV) اجرا می‌شدند، گزارش می‌گفت «AI: YES»
            # که از نظرِ معنایی نادرست بود. با ثبتِ فعلیِ ModelManager
            # (models_registry.py) که فقط عملیاتِ CLASSICAL را
            # AVAILABLE می‌کند، این مقدار در حالِ حاضر همیشه False
            # می‌شود -- که دقیقاً بازتابِ صادقانه‌یِ همین است که پروژه
            # هنوز هیچ مدلِ Neuralِ واقعی ندارد؛ اگر روزی یک Arm واقعاً
            # Neural (مثلاً Real-ESRGAN) با STATUS_NEURAL_ACTIVE ثبت
            # شود، همین محاسبه بدونِ تغییرِ دیگری True خواهد شد.
            real_ai_ops = [
                op for op in best_version.ops_applied
                if getattr(self.models.model_for(op), "status", None) == STATUS_NEURAL_ACTIVE
            ]
            ai_used = bool(real_ai_ops)
            if ai_used:
                ai_status = AI_STATUS_REAL_AI
            elif best_version.ops_applied:
                ai_status = AI_STATUS_CLASSICAL_FALLBACK
            else:
                ai_status = AI_STATUS_NO_OPERATION_NEEDED

            report = RestorationReport(
                ai_used=ai_used,
                ai_status=ai_status,
                model=f"CLASSICAL_PIPELINE ({device.backend})" if not ai_used else f"NEURAL_PIPELINE ({device.backend})",
                backend=device.backend,
                operations=best_version.ops_applied,
                quality_before=before_score.overall,
                quality_after=best_version.score.overall,
                confidence=state.confidence,
                rounds=len(optimizer.log),
                reached_target=best_version.score.overall >= target,
                target=target,
                rejected_versions=version_manager.rejected_count,
                log=optimizer.log,
                issues=state.issues,
            )
            return final_img, report
        finally:
            version_manager.cleanup(keep=best_version)
            shutil.rmtree(tmp_dir, ignore_errors=True)
