# -*- coding: utf-8 -*-
"""
Vision Brain (سندِ معماری، بخشِ ۲).

سندِ اصلی می‌گوید: «اگر Neural Model در دسترس نبود، STATUS =
NEURAL_MODEL_UNAVAILABLE و سیستم نباید وانمود کند که AI اجرا شده.»

این محیط نه اینترنت دارد نه هیچ وزنِ مدلِ از‌قبل‌آموزش‌دیده‌ای همراهش
آمده، پس اینجا دقیقاً همان قانون را اجرا می‌کنیم: هیچ شبکه‌یِ عصبی‌ای
بارگذاری نمی‌شود. classify() یک طبقه‌بندیِ Rule-Based روی رویِ خروجیِ
Perception Engine انجام می‌دهد -- ابزاری واقعی و مفید، اما صادقانه
کلاسیک، نه یک مدلِ یادگرفته‌شده.
"""

from __future__ import annotations

from .contracts import PerceptionState, STATUS_NEURAL_UNAVAILABLE


class VisionBrain:
    neural_status = STATUS_NEURAL_UNAVAILABLE

    def classify(self, p: PerceptionState) -> list:
        """بخشِ ۴ -- برچسب‌هایِ همزمان (نه فقط یک کلاس)."""
        types = []

        if p.text_probability > 0.55:
            types.append("TEXT_IMAGE" if p.edge_density > 0.25 else "DOCUMENT")
        if p.low_light:
            types.append("LOW_LIGHT")
            types.append("NIGHT")
        if p.compression_artifact_score > 0.35:
            types.append("COMPRESSED_IMAGE")
        if p.aspect_ratio and (p.aspect_ratio > 1.6 or p.aspect_ratio < 0.6) and p.edge_density < 0.15:
            types.append("LANDSCAPE")
        if p.saturation_mean < 25 and p.edge_density > 0.1:
            types.append("SCREENSHOT")

        if not types:
            types.append("PHOTO")

        return types
