# -*- coding: utf-8 -*-
"""
Iterative Optimization Engine (سندِ معماری، بخش‌هایِ ۳۶-۴۳، ۹۶-۹۹).

هر Planِ کاندید (A/B/C) از رویِ عکسِ *اصلی* دوباره اجرا می‌شود (نه رویِ
خروجیِ Planِ قبلی) تا نویزِ باقیمانده رویِ‌هم انباشته نشود -- همان
اصلی که pipeline.py قبلی هم رعایت می‌کرد. Quality Judge هرکدام را
امتیاز می‌دهد؛ VersionManager فقط بهترین را نگه می‌دارد (Rollback
خودکار برایِ بقیه). Anti-Loop: حداکثرِ تعدادِ Plan امتحان‌شده محدود
است و اگر Planِ اول به هدف رسید، بقیه اجرا نمی‌شوند.
"""

from __future__ import annotations

from typing import List

from .arms import ARM_REGISTRY
from .contracts import ExecutionPlan, VisionState
from .judge import QualityJudge
from .version_manager import VersionManager

MAX_PLANS = 3  # بخشِ ۹۷ -- SEARCH SPACE CONTROL


class IterativeOptimizer:
    def __init__(self, judge: QualityJudge, version_manager: VersionManager):
        self.judge = judge
        self.version_manager = version_manager
        self.log: List[str] = []

    def run(self, original_img, state: VisionState, plans: List[ExecutionPlan], tmp_dir: str, target: float):
        before_score = self.judge.score_image(original_img)
        self.version_manager.add(0, original_img, before_score, "ORIGINAL", [], tmp_dir)
        self.log.append(f"[JUDGE] before overall={before_score.overall:.1f}")

        for round_no, plan in enumerate(plans[:MAX_PLANS], start=1):
            img = original_img
            applied_ops = []
            for op in plan.ops:
                arm_cls = ARM_REGISTRY.get(op)
                if not arm_cls:
                    continue
                try:
                    img = arm_cls().execute(img, state, tmp_dir)
                    applied_ops.append(op)
                except Exception as e:  # noqa: BLE001 -- یک Arm خراب نباید کلِ Pipeline را بترکاند (بخشِ ۱۳۶)
                    self.log.append(f"[{op.upper()}] FAILED: {e}")

            after_score = self.judge.score_image(img)
            self.log.append(
                f"[COMMANDER] {plan.name} ({' -> '.join(applied_ops) or '(no-op)'}) "
                f"=> overall={after_score.overall:.1f}"
            )

            best_before = self.version_manager.best
            self.version_manager.add(round_no, img, after_score, plan.name, applied_ops, tmp_dir)

            if best_before and not self.judge.is_better(best_before.score, after_score, min_gain=0.0):
                self.version_manager.mark_rejected()
                self.log.append(f"[ROLLBACK] {plan.name} rejected (kept v{best_before.round_no})")

            if self.version_manager.best.score.overall >= target:
                self.log.append(f"[EARLY_STOP] target {target:.0f} reached")
                break

        best = self.version_manager.best
        self.log.append(f"[JUDGE] best={best.plan_name} overall={best.score.overall:.1f}")
        return before_score, best
