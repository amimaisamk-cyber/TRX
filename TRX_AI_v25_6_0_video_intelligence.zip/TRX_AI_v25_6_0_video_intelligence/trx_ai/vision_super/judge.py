# -*- coding: utf-8 -*-
"""
Quality Judge (سندِ معماری، بخش‌هایِ ۳۱-۳۵).

مستقل از هر Armی است -- فقط رویِ عکسِ قبل/بعد Perception را دوباره
اجرا می‌کند و یک QualityScore ترکیبی می‌سازد. هیچ معیارِ تکی به‌تنهایی
تصمیمِ نهایی نیست (بخشِ ۳۲: "Sharpness بالا رفت ولی Artifacts بیشتر
بالا رفت -> نباید بهتر حساب شود").

معیارها همه کلاسیک‌اند (Neural IQA در این محیط موجود نیست -- بخشِ ۳۴
صادقانه رد می‌شود، نه شبیه‌سازی).
"""

from __future__ import annotations

from .contracts import PerceptionState, QualityScore
from .perception import PerceptionEngine

# هدفِ کیفیت بر اساسِ نوعِ عکس (بخشِ ۳۵) -- قابلِ‌تنظیم.
QUALITY_TARGETS = {
    "DOCUMENT": 94,
    "TEXT_IMAGE": 96,
    "NIGHT": 88,
    "LOW_LIGHT": 88,
}
DEFAULT_TARGET = 90


def _norm(value: float, lo: float, hi: float) -> float:
    if hi == lo:
        return 0.0
    return max(0.0, min(100.0, (value - lo) / (hi - lo) * 100.0))


class QualityJudge:
    def __init__(self):
        self._perception = PerceptionEngine()

    def target_for(self, image_types) -> float:
        for t in image_types:
            if t in QUALITY_TARGETS:
                return QUALITY_TARGETS[t]
        return DEFAULT_TARGET

    def score_state(self, p: PerceptionState) -> QualityScore:
        if p.backend == "cv2+numpy":
            sharpness_score = _norm(p.sharpness, 20, 400)
        else:
            sharpness_score = _norm(p.sharpness, 5, 90)

        detail_score = _norm(p.edge_density * 100, 3, 35)
        noise_score = 100.0 - _norm(p.noise_estimate, 2, 22)
        artifact_score = 100.0 - (p.compression_artifact_score * 100.0)
        # رنگ: نه خیلی کم‌رنگ نه خیلی اشباع
        color_score = 100.0 - abs(_norm(p.saturation_mean, 0, 140) - 55.0) * (100.0 / 55.0)
        color_score = max(0.0, min(100.0, color_score))
        # نوردهی: فاصله از روشناییِ میانه‌یِ ایده‌آل (~125) + کنتراستِ کافی
        exposure_penalty = abs(p.brightness - 125.0) / 125.0 * 60.0
        exposure_score = max(0.0, 100.0 - exposure_penalty) * min(1.0, (p.contrast_std / 40.0))
        exposure_score = max(0.0, min(100.0, exposure_score))

        weights = {
            "sharpness": 0.22,
            "detail": 0.18,
            "noise": 0.20,
            "artifact": 0.15,
            "color": 0.10,
            "exposure": 0.15,
        }
        overall = (
            sharpness_score * weights["sharpness"]
            + detail_score * weights["detail"]
            + noise_score * weights["noise"]
            + artifact_score * weights["artifact"]
            + color_score * weights["color"]
            + exposure_score * weights["exposure"]
        )

        return QualityScore(
            sharpness_score=sharpness_score,
            detail_score=detail_score,
            noise_score=noise_score,
            artifact_score=artifact_score,
            color_score=color_score,
            exposure_score=exposure_score,
            overall=overall,
        )

    def score_image(self, img) -> QualityScore:
        p = self._perception.analyze(img)
        return self.score_state(p)

    def is_better(self, before: QualityScore, after: QualityScore, min_gain: float = 0.5) -> bool:
        """بخشِ ۳۲ -- رد کردنِ نتیجه‌ای که فقط از یک زاویه بهتر شده.
        قانون: overall باید حداقل min_gain بالاتر باشد *و* artifact/detail
        به‌طرزِ محسوسی بدتر نشده باشند."""
        if after.overall < before.overall + min_gain:
            return False
        if after.artifact_score < before.artifact_score - 15:
            return False
        if after.detail_score < before.detail_score - 20:
            return False
        return True
