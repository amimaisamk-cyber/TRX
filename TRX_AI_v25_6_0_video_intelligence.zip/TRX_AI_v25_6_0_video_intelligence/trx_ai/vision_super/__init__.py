# -*- coding: utf-8 -*-
"""
TRX VISION SUPER SYSTEM -- پیاده‌سازیِ کلاسیک (بدونِ مدلِ Neural، طبقِ
سندِ معماری در سه بخش). نقطه‌ی ورودِ عمومی: ``VisionOrchestrator``.
"""

from .orchestrator import VisionOrchestrator

__all__ = ["VisionOrchestrator"]
