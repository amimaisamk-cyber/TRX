# -*- coding: utf-8 -*-
"""Version Manager (سندِ معماری، بخش‌هایِ ۳۷-۳۸) -- همیشه بهترین نسخه نگه‌داشته می‌شود."""

from __future__ import annotations

import os
from typing import List, Optional

from ..logging_config import get_logger
from .contracts import QualityScore, Version

logger = get_logger(__name__)


class VersionManager:
    def __init__(self):
        self.versions: List[Version] = []
        self.rejected_count = 0

    def add(self, round_no: int, img, score: QualityScore, plan_name: str, ops_applied: List[str], tmp_dir: str) -> Version:
        path = os.path.join(tmp_dir, f"v{round_no}_{plan_name}.png")
        img.save(path, format="PNG")
        version = Version(round_no=round_no, image_path=path, score=score, plan_name=plan_name, ops_applied=ops_applied)
        self.versions.append(version)
        return version

    def mark_rejected(self):
        self.rejected_count += 1

    @property
    def best(self) -> Optional[Version]:
        if not self.versions:
            return None
        return max(self.versions, key=lambda v: v.score.overall)

    def cleanup(self, keep: Optional[Version] = None):
        """فقط بهترین نسخه نگه داشته می‌شود؛ بقیه‌یِ فایل‌هایِ موقت پاک می‌شوند
        (بخشِ ۱۴۰: PRIVACY -- Temporary Files باید قابلِ‌پاک‌سازی باشند)."""
        keep_path = keep.image_path if keep else (self.best.image_path if self.best else None)
        for v in self.versions:
            if v.image_path != keep_path and os.path.exists(v.image_path):
                try:
                    os.remove(v.image_path)
                except OSError as e:
                    logger.debug("پاک‌کردنِ فایلِ موقتِ نسخه‌ی رد‌شده شکست خورد: %s", e)
