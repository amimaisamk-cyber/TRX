# -*- coding: utf-8 -*-
"""
Memory Engine (سندِ معماری، بخش‌هایِ ۴۴-۴۶، ۸۷-۹۱).

سه لایه:
  - Short Term: فقط در طولِ یک اجرا، در حافظه‌یِ RAM (نه فایل).
  - Case Memory: یک رکورد به‌ازایِ هر پردازش (بدونِ خودِ عکس -- طبقِ
    بخشِ ۴۶: «خودِ تصویر اصلی را بدون اجازه‌ی کاربر در حافظه‌ی دائمی
    ذخیره نکن»).
  - Strategy Memory: آمارِ تجمیعی‌یِ هر عملیات (success/failure/gain)
    که Commander برایِ اولویت‌دهی استفاده می‌کند.

هر دویِ Case/Strategy رویِ دیسک، به‌صورتِ یک فایلِ JSONِ ساده (بدونِ
دیتابیسِ سنگین) نگه‌داری می‌شوند تا بینِ اجراهایِ مختلف دوام بیاورند.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Dict, List

from ..logging_config import get_logger

logger = get_logger(__name__)

_MAX_CASES = 300  # جلوگیری از رشدِ بی‌نهایتِ فایل (سندِ معماری بخشِ ۹۷: SEARCH SPACE CONTROL مشابه)


@dataclass
class OperationStats:
    success_count: int = 0
    failure_count: int = 0
    total_gain: float = 0.0

    @property
    def average_gain(self) -> float:
        n = self.success_count + self.failure_count
        return self.total_gain / n if n else 0.0

    @property
    def priority(self) -> float:
        """بخشِ ۴۹ -- اولویتِ ساده از رویِ نرخِ موفقیت و میانگینِ سود."""
        n = self.success_count + self.failure_count
        if n == 0:
            return 0.5  # بدونِ تجربه‌یِ قبلی -- خنثی
        success_rate = self.success_count / n
        return max(0.0, min(1.0, 0.5 * success_rate + 0.5 * min(1.0, max(0.0, self.average_gain) / 20.0)))


class MemoryEngine:
    def __init__(self, memory_path: str):
        self.memory_path = memory_path
        self._lock = Lock()
        self.short_term: Dict[str, object] = {}
        self._cases: List[dict] = []
        self._strategy: Dict[str, OperationStats] = {}
        self._load()

    # ------------------------------------------------------------
    def _load(self):
        if not os.path.exists(self.memory_path):
            return
        try:
            with open(self.memory_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._cases = data.get("cases", [])[-_MAX_CASES:]
            for op, stats in data.get("strategy", {}).items():
                self._strategy[op] = OperationStats(
                    success_count=stats.get("success_count", 0),
                    failure_count=stats.get("failure_count", 0),
                    total_gain=stats.get("total_gain", 0.0),
                )
        except Exception as e:  # noqa: BLE001 -- حافظه‌ی خراب نباید کلِ سیستم را متوقف کند
            logger.warning("بارگذاریِ vision memory شکست خورد: %s", e)

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.memory_path) or ".", exist_ok=True)
            data = {
                "cases": self._cases[-_MAX_CASES:],
                "strategy": {
                    op: {
                        "success_count": s.success_count,
                        "failure_count": s.failure_count,
                        "total_gain": s.total_gain,
                    }
                    for op, s in self._strategy.items()
                },
            }
            with open(self.memory_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
        except Exception as e:  # noqa: BLE001
            logger.warning("ذخیره‌یِ vision memory شکست خورد: %s", e)

    # ------------------------------------------------------------
    #   Strategy Memory -- برایِ اولویت‌دهیِ Commander (بخشِ ۴۹)
    # ------------------------------------------------------------
    def priority_for(self, op: str) -> float:
        with self._lock:
            stats = self._strategy.get(op)
            return stats.priority if stats else 0.5

    def record_operation(self, op: str, gain: float, success: bool):
        with self._lock:
            stats = self._strategy.setdefault(op, OperationStats())
            if success:
                stats.success_count += 1
            else:
                stats.failure_count += 1
            stats.total_gain += gain

    # ------------------------------------------------------------
    #   Case Memory -- یک رکورد به‌ازایِ هر پردازش (بدونِ خودِ عکس)
    # ------------------------------------------------------------
    def record_case(self, image_types: List[str], issues: List[str], plan: str,
                     ops: List[str], before: float, after: float, success: bool):
        with self._lock:
            self._cases.append({
                "ts": time.time(),
                "image_types": image_types,
                "issues": issues,
                "plan": plan,
                "ops": ops,
                "before": round(before, 1),
                "after": round(after, 1),
                "success": success,
            })
            self._save()

    def best_known_plan_for(self, image_types: List[str]) -> List[str]:
        """بخشِ ۴۵ (EXPERIMENT MEMORY) -- ساده‌ترین شکلِ آن: بهترین
        ops-sequence که قبلاً برایِ همین ترکیبِ برچسب‌ها بیشترین gain را
        داده، اگر موردی ثبت شده باشد."""
        with self._lock:
            candidates = [c for c in self._cases if set(c.get("image_types", [])) == set(image_types) and c.get("success")]
            if not candidates:
                return []
            best = max(candidates, key=lambda c: c["after"] - c["before"])
            return best.get("ops", [])

    def flush(self):
        with self._lock:
            self._save()
