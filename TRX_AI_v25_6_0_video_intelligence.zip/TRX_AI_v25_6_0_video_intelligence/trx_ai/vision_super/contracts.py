# -*- coding: utf-8 -*-
"""
قراردادهایِ مشترکِ VISION SUPER SYSTEM (نگاه کنید به سندِ معماری،
بخش‌های ۲، ۳، ۵، ۱۲، ۱۳، ۳۲، ۳۳).

همه‌یِ ماژول‌هایِ vision_super با همین چند dataclass با هم حرف می‌زنند
تا Arm/Analyzer/Judge/Commander مستقل از پیاده‌سازیِ یکدیگر بمانند.

نکته‌یِ صداقت (سندِ معماری، بخشِ ۲ و ۱۳۰): این پروژه هیچ مدلِ Neural
واقعی (SR/Deblur/OCR آموزش‌دیده) همراهش نیست و دسترسیِ اینترنتی برایِ
دانلودِ چنین مدلی هم در این محیط وجود ندارد. پس هرجا سندِ اصلی از
«Neural Model» حرف می‌زند، این پیاده‌سازی به‌جایش یک الگوریتمِ کلاسیکِ
واقعی (Pillow/NumPy/OpenCV) اجرا می‌کند و آن را با ``NEURAL_MODEL_UNAVAILABLE``
یا ``CLASSICAL`` علامت می‌زند -- هرگز وانمود نمی‌کند که یک مدلِ
یادگرفته‌شده اجرا شده است.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ------------------------------------------------------------
#   وضعیتِ مدل/بخش (بخش ۲، ۸۰-۸۳)
# ------------------------------------------------------------
STATUS_CLASSICAL = "CLASSICAL"                        # الگوریتمِ کلاسیکِ واقعی، کار می‌کند
STATUS_NEURAL_UNAVAILABLE = "NEURAL_MODEL_UNAVAILABLE"  # صادقانه: مدلِ یادگرفته‌شده در دسترس نیست
STATUS_NEURAL_ACTIVE = "NEURAL_ACTIVE"                # وزنِ Neuralِ واقعی نصب و درحالِ اجراست (فعلاً هیچ‌کجایِ
                                                        # این پروژه این وضعیت را واقعاً برنمی‌گرداند -- برایِ
                                                        # روزی که مدلِ Neuralِ واقعی -- مثلِ Real-ESRGAN -- اضافه
                                                        # شود نگه داشته شده)
STATUS_SKIPPED = "SKIPPED"
STATUS_FAILED = "FAILED"

# مقادیرِ ممکنِ RestorationReport.ai_status -- بخشِ ۱۳۰ (HONEST AI
# REPORTING) به‌طورِ صریح می‌خواهد که «AI استفاده شد» با «یک الگوریتمِ
# کلاسیک اجرا شد» هیچ‌وقت قاطی نشوند. این چهار مقدار همان تفکیک را
# در گزارشِ خروجی رسمی می‌کنند (به‌جایِ یک ``ai_used: bool`` مبهم که
# فقط می‌گفت «آیا عملیاتی اجرا شد»، صرفِ‌نظر از این‌که آن عملیات
# Neural بوده یا کلاسیک):
AI_STATUS_REAL_AI = "REAL_AI"                    # حداقل یک عملیاتِ واقعاً Neural اجرا شد
AI_STATUS_CLASSICAL_FALLBACK = "CLASSICAL_FALLBACK"  # فقط الگوریتمِ کلاسیک اجرا شد (وضعیتِ فعلیِ همیشگیِ این پروژه)
AI_STATUS_NO_OPERATION_NEEDED = "NO_OPERATION_NEEDED"  # عکس از قبل مشکلی نداشت، هیچ Armی اجرا نشد


@dataclass
class PerceptionState:
    """خروجیِ Perception Engine (بخشِ ۳) -- فقط اندازه‌گیریِ خام."""

    width: int
    height: int
    aspect_ratio: float
    brightness: float          # ۰-۲۵۵
    contrast_std: float        # انحرافِ‌معیارِ روشنایی
    sharpness: float           # هرچه بیشتر = تیزتر (واریانسِ لاپلاسین یا معادلِ Pillow)
    noise_estimate: float      # هرچه بیشتر = نویزی‌تر
    dynamic_range: float       # max-min روشنایی (تقریبی)
    saturation_mean: float
    edge_density: float        # چگالیِ لبه، برایِ تشخیصِ متن/سند مفید است
    low_light: bool
    compression_artifact_score: float  # تخمینِ بلوک‌آرتیفکتِ JPEG (بخشِ ۷/۲۳)
    text_probability: float    # ۰..۱ (بخشِ ۹)
    backend: str                # "cv2+numpy" یا "pillow-only"


@dataclass
class DamageIssue:
    """یک مشکلِ تشخیص‌داده‌شده (بخشِ ۵)."""

    type: str           # مثلاً "MOTION_BLUR", "SENSOR_NOISE", "UNDEREXPOSURE"
    severity: float      # ۰..۱
    confidence: float    # ۰..۱


@dataclass
class VisionState:
    """خروجیِ ترکیبیِ Vision Brain + Analyzer (بخشِ ۲ و ۱۱)."""

    perception: PerceptionState
    image_types: List[str] = field(default_factory=list)   # بخشِ ۴ (چندبرچسبی)
    issues: List[DamageIssue] = field(default_factory=list)
    recommended_ops: List[str] = field(default_factory=list)
    neural_status: str = STATUS_NEURAL_UNAVAILABLE
    confidence: float = 0.6


@dataclass
class QualityScore:
    """بخشِ ۳۲/۳۳ -- معیارهایِ کلاسیکِ کیفیت، ترکیب‌شده در overall."""

    sharpness_score: float
    detail_score: float
    noise_score: float
    artifact_score: float
    color_score: float
    exposure_score: float
    overall: float
    breakdown: Dict[str, float] = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {
            "sharpness": round(self.sharpness_score, 1),
            "detail": round(self.detail_score, 1),
            "noise": round(self.noise_score, 1),
            "artifact": round(self.artifact_score, 1),
            "color": round(self.color_score, 1),
            "exposure": round(self.exposure_score, 1),
            "overall": round(self.overall, 1),
        }


@dataclass
class ExecutionPlan:
    """بخشِ ۱۳ -- ترتیبِ Armهایی که باید اجرا شوند."""

    name: str
    ops: List[str]
    reasoning: str = ""


@dataclass
class ArmResult:
    """بخشِ ۱۵ (ARM CONTRACT) -- خروجیِ استانداردِ هر Arm."""

    op: str
    applied: bool
    status: str                  # CLASSICAL / SKIPPED / FAILED
    image_path: Optional[str]    # مسیرِ عکسِ خروجی (اگر applied=True)
    params: dict = field(default_factory=dict)
    notes: str = ""


@dataclass
class Version:
    """بخشِ ۳۷ -- یک نسخه‌یِ کاندید در طولِ چرخه‌یِ بهینه‌سازی."""

    round_no: int
    image_path: str
    score: QualityScore
    plan_name: str
    ops_applied: List[str]
    timestamp: float = field(default_factory=time.time)


@dataclass
class RestorationReport:
    """بخشِ ۱۳۰ -- HONEST AI REPORTING، خروجیِ نهاییِ Orchestrator."""

    ai_used: bool
    ai_status: str            # یکی از AI_STATUS_* -- نگاه کنید به توضیحِ بالا
    model: str
    backend: str
    operations: List[str]
    quality_before: float
    quality_after: float
    confidence: float
    rounds: int
    reached_target: bool
    target: float
    rejected_versions: int
    log: List[str] = field(default_factory=list)
    issues: List[DamageIssue] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "ai": self.ai_used,
            "ai_status": self.ai_status,
            "model": self.model,
            "backend": self.backend,
            "operations": self.operations,
            "quality_before": round(self.quality_before, 1),
            "quality_after": round(self.quality_after, 1),
            "gain": round(self.quality_after - self.quality_before, 1),
            "confidence": round(self.confidence, 2),
            "rounds": self.rounds,
            "reached_target": self.reached_target,
            "target": self.target,
            "rejected_versions": self.rejected_versions,
        }

    def to_text(self) -> str:
        ai_line_by_status = {
            AI_STATUS_REAL_AI: "AI: YES (real trained neural model executed)",
            AI_STATUS_CLASSICAL_FALLBACK: "AI: NO (classical algorithm pipeline only -- no trained neural model available)",
            AI_STATUS_NO_OPERATION_NEEDED: "AI: NO (no restoration operation was needed)",
        }
        lines = [
            "HONEST AI REPORT",
            ai_line_by_status.get(self.ai_status, f"AI: NO ({self.ai_status})"),
            f"MODEL: {self.model}",
            f"BACKEND: {self.backend}",
            f"OPERATIONS: {' -> '.join(self.operations) if self.operations else '(none needed)'}",
            f"QUALITY: {self.quality_before:.1f} -> {self.quality_after:.1f} "
            f"({'+' if self.quality_after >= self.quality_before else ''}"
            f"{self.quality_after - self.quality_before:.1f})",
            f"CONFIDENCE: {self.confidence * 100:.0f}%",
            f"ROUNDS: {self.rounds} (rejected {self.rejected_versions} worse version(s))",
            f"TARGET: {self.target:.0f} -> {'REACHED' if self.reached_target else 'NOT REACHED (best available kept)'}",
        ]
        return "\n".join(lines)
