# -*- coding: utf-8 -*-
"""
Deblur Arm (سندِ معماری، بخش‌هایِ ۱۷-۱۸).

نکته‌یِ صداقت: تشخیصِ نوعِ دقیقِ بلور (Motion/Defocus/Gaussian) و
جهتِ حرکت بدونِ یک مدلِ Neural واقعی قابلِ‌اعتماد نیست. اینجا بلور را
یک دسته‌یِ واحد در نظر می‌گیریم و با Unsharp Mask (کلاسیک) جبران
می‌کنیم -- طبقِ اولویتِ بخشِ ۱۷:
    NEURAL DEBLUR -> SPECIALIZED MODEL -> CLASSICAL FALLBACK
چون دوتایِ اول موجود نیستند، مستقیم به Classical Fallback می‌رویم و
این را در گزارش صادقانه اعلام می‌کنیم (هیچ‌جا "Neural Deblur" ادعا
نمی‌شود).
"""

from __future__ import annotations

from ...dependencies import CV2_AVAILABLE
from ..contracts import VisionState
from .base import BaseArm


class DeblurArm(BaseArm):
    op_name = "deblur"

    def execute(self, img, state: VisionState, out_path_hint: str):
        severity = next((i.severity for i in state.issues if i.type == "BLUR"), 0.4)
        radius = 1.2 + severity * 2.3      # 1.2 .. 3.5
        percent = int(110 + severity * 140)  # 110 .. 250
        if CV2_AVAILABLE:
            return self._execute_cv2(img, radius, percent)
        return self._execute_pillow(img, radius, percent)

    def _execute_pillow(self, img, radius: float, percent: int):
        from PIL import ImageFilter

        return img.filter(ImageFilter.UnsharpMask(radius=radius, percent=percent, threshold=2))

    def _execute_cv2(self, img, radius: float, percent: int):
        import cv2
        import numpy as np
        from PIL import Image

        arr = cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)
        blurred = cv2.GaussianBlur(arr, (0, 0), sigmaX=radius)
        weight = percent / 100.0
        sharpened = cv2.addWeighted(arr, 1.0 + weight, blurred, -weight, 0)
        return Image.fromarray(cv2.cvtColor(sharpened, cv2.COLOR_BGR2RGB))
