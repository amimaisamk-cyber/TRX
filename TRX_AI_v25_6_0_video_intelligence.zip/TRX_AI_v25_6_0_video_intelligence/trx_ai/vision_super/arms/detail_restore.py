# -*- coding: utf-8 -*-
"""Detail Restoration Arm (سندِ معماری، بخشِ ۲۰): آخرین پاسِ ظریف، نه Fake Detail."""

from __future__ import annotations

from ..contracts import VisionState
from .base import BaseArm


class DetailRestoreArm(BaseArm):
    op_name = "detail_restore"

    def execute(self, img, state: VisionState, out_path_hint: str):
        from PIL import ImageFilter

        # پاسِ نهاییِ سبک -- شعاعِ کوچک، درصدِ متوسط، فقط برایِ برگرداندنِ
        # لبه‌هایِ ظریفی که پاس‌هایِ قبلی (denoise/deblur) کمی نرم کرده‌اند.
        return img.filter(ImageFilter.UnsharpMask(radius=1.0, percent=60, threshold=3))
