# -*- coding: utf-8 -*-
"""
Super Resolution Arm (سندِ معماری، بخشِ ۱۹).

سند می‌گوید: «Resize به‌تنهایی Super Resolution محسوب نمی‌شود.» --
موافقیم. چون هیچ مدلِ Neural SR در این محیط موجود نیست، این Arm
صادقانه یک CLASSICAL_UPSCALE (Lanczos + شارپن‌کردنِ سبک برایِ جبرانِ
نرم‌شدنِ طبیعیِ Resize) انجام می‌دهد، نه یک "Super Resolution" واقعی؛
گزارشِ نهایی هم دقیقاً همین را می‌گوید (بدونِ ادعایِ AI-generated detail).
"""

from __future__ import annotations

from ..contracts import VisionState
from .base import BaseArm

MAX_TARGET_WIDTH = 2400  # جلوگیری از بزرگ‌نماییِ بی‌رویه‌ی حافظه‌بر


class SuperResolutionArm(BaseArm):
    op_name = "super_resolution"

    def execute(self, img, state: VisionState, out_path_hint: str):
        from PIL import Image, ImageFilter

        w, h = img.size
        if w >= 900:
            return img  # عکسِ از‌قبل‌بزرگ -- بزرگ‌ترکردن جزئیاتِ واقعی اضافه نمی‌کند
        scale = min(2.0, MAX_TARGET_WIDTH / max(w, 1))
        scale = max(1.0, scale)
        new_size = (int(w * scale), int(h * scale))
        upscaled = img.resize(new_size, Image.LANCZOS)
        # شارپنِ سبک برایِ جبرانِ نرم‌شدنِ طبیعیِ Lanczos resize
        return upscaled.filter(ImageFilter.UnsharpMask(radius=1.5, percent=90, threshold=2))
