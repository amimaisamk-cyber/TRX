# -*- coding: utf-8 -*-
"""Specialist Arm System (سندِ معماری، بخشِ ۱۴) -- هر Arm مستقل و Plug-in‌مانند."""

from .artifact_removal import ArtifactRemovalArm
from .base import BaseArm
from .color_restore import ColorRestoreArm
from .deblur import DeblurArm
from .denoise import DenoiseArm
from .detail_restore import DetailRestoreArm
from .low_light import LowLightArm
from .super_resolution import SuperResolutionArm

ARM_REGISTRY = {
    "denoise": DenoiseArm,
    "deblur": DeblurArm,
    "super_resolution": SuperResolutionArm,
    "low_light": LowLightArm,
    "color_restore": ColorRestoreArm,
    "artifact_removal": ArtifactRemovalArm,
    "detail_restore": DetailRestoreArm,
}

__all__ = ["BaseArm", "ARM_REGISTRY"]
