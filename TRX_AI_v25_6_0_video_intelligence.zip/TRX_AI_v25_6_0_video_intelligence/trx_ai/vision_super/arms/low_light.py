# -*- coding: utf-8 -*-
"""Low Light Arm (سندِ معماری، بخشِ ۲۱): Exposure -> Shadow Recovery -> Highlight Protection."""

from __future__ import annotations

from ...dependencies import CV2_AVAILABLE
from ..contracts import VisionState
from .base import BaseArm


class LowLightArm(BaseArm):
    op_name = "low_light"

    def execute(self, img, state: VisionState, out_path_hint: str):
        if CV2_AVAILABLE:
            return self._execute_cv2(img)
        return self._execute_pillow(img)

    def _execute_pillow(self, img, gamma: float = 1.6):
        from PIL import ImageEnhance

        # گاما (روشن‌کردنِ سایه‌ها بدونِ سوزوندنِ نورهای روشن) با یک
        # جدولِ Lookup ساده -- نیازی به numpy ندارد.
        inv_gamma = 1.0 / gamma
        lut = [min(255, int((v / 255.0) ** inv_gamma * 255.0)) for v in range(256)]
        rgb = img.convert("RGB")
        r, g, b = rgb.split()
        r, g, b = r.point(lut), g.point(lut), b.point(lut)
        out = type(rgb).merge("RGB", (r, g, b))
        return ImageEnhance.Contrast(out).enhance(1.05)

    def _execute_cv2(self, img):
        import cv2
        import numpy as np
        from PIL import Image

        arr = cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)
        lab = cv2.cvtColor(arr, cv2.COLOR_BGR2LAB)
        l_channel, a_channel, b_channel = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l_channel = clahe.apply(l_channel)
        out = cv2.cvtColor(cv2.merge((l_channel, a_channel, b_channel)), cv2.COLOR_LAB2BGR)
        return Image.fromarray(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
