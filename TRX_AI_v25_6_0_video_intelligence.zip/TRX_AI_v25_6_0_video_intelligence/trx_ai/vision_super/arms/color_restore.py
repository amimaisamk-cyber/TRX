# -*- coding: utf-8 -*-
"""Color Restoration Arm (سندِ معماری، بخشِ ۲۲): White Balance + Saturation/Contrast Recovery."""

from __future__ import annotations

from ..contracts import VisionState
from .base import BaseArm


class ColorRestoreArm(BaseArm):
    op_name = "color_restore"

    def execute(self, img, state: VisionState, out_path_hint: str):
        from PIL import ImageEnhance, ImageOps

        rgb = img.convert("RGB")
        # Gray-World White Balance: میانگینِ هر کانال را به میانگینِ کلی نزدیک کن
        r, g, b = rgb.split()
        means = [c.getextrema() and sum(c.getdata()) / (c.width * c.height) for c in (r, g, b)]
        overall = sum(means) / 3.0
        if min(means) > 1:
            scales = [min(1.6, max(0.6, overall / m)) for m in means]
            r = r.point(lambda v, s=scales[0]: min(255, int(v * s)))
            g = g.point(lambda v, s=scales[1]: min(255, int(v * s)))
            b = b.point(lambda v, s=scales[2]: min(255, int(v * s)))
            rgb = type(rgb).merge("RGB", (r, g, b))

        # کنتراستِ ملایم بدونِ کلیپ‌کردنِ شدید (autocontrast با cutoff کم)
        rgb = ImageOps.autocontrast(rgb, cutoff=1)
        rgb = ImageEnhance.Color(rgb).enhance(1.15)
        return rgb
