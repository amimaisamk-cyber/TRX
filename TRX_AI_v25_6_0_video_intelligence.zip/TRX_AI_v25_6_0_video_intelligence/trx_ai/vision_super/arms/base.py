# -*- coding: utf-8 -*-
"""ARM CONTRACT (سندِ معماری، بخشِ ۱۵) -- Interface یکسان برایِ همه‌یِ Armها."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..contracts import ArmResult, VisionState


class BaseArm(ABC):
    op_name: str = "base"
    status = "CLASSICAL"

    def can_handle(self, state: VisionState) -> bool:
        return self.op_name in state.recommended_ops

    @abstractmethod
    def execute(self, img, state: VisionState, out_path_hint: str):
        """ورودی: تصویرِ PIL. خروجی: تصویرِ PIL جدید (بدونِ ذخیره روی دیسک --
        VersionManager مسئولِ ذخیره‌سازیِ نسخه‌هاست)."""
        raise NotImplementedError

    def report(self, applied: bool, notes: str = "") -> ArmResult:
        return ArmResult(op=self.op_name, applied=applied, status=self.status, image_path=None, notes=notes)
