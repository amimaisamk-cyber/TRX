# -*- coding: utf-8 -*-
"""Artifact Removal Arm (سندِ معماری، بخشِ ۲۳): کاهشِ Halo/Ringing/بلوکِ JPEG."""

from __future__ import annotations

from ..contracts import VisionState
from .base import BaseArm


class ArtifactRemovalArm(BaseArm):
    op_name = "artifact_removal"

    def execute(self, img, state: VisionState, out_path_hint: str):
        from PIL import ImageFilter

        # یک پاسِ ملایمِ median (اندازه‌یِ کوچک) برایِ کاهشِ بلوکِ JPEG/نویزِ
        # باقیمانده، بدونِ محوکردنِ محسوسِ لبه‌ها.
        return img.filter(ImageFilter.MedianFilter(size=3))
