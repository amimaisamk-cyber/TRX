# -*- coding: utf-8 -*-
"""Denoise Arm (سندِ معماری، بخشِ ۱۶) -- شدتِ Adaptive بر اساسِ severity."""

from __future__ import annotations

from ...dependencies import CV2_AVAILABLE
from ..contracts import VisionState
from .base import BaseArm


class DenoiseArm(BaseArm):
    op_name = "denoise"

    def execute(self, img, state: VisionState, out_path_hint: str):
        severity = next((i.severity for i in state.issues if i.type == "SENSOR_NOISE"), 0.4)
        if CV2_AVAILABLE:
            return self._execute_cv2(img, severity)
        return self._execute_pillow(img, severity)

    def _execute_pillow(self, img, severity: float):
        from PIL import ImageFilter

        # OFF/LOW/MEDIUM/HIGH/EXTREME (بخشِ ۱۶) -- اندازه‌یِ فردِ MedianFilter
        if severity < 0.2:
            return img  # OFF
        size = 3 if severity < 0.45 else 5 if severity < 0.7 else 7 if severity < 0.9 else 9
        out = img.filter(ImageFilter.MedianFilter(size=size))
        if severity > 0.7:
            out = out.filter(ImageFilter.GaussianBlur(radius=0.4))
        return out

    def _execute_cv2(self, img, severity: float):
        import cv2
        import numpy as np

        arr = cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)
        h = int(4 + severity * 22)  # 4..26 -- OFF..EXTREME پیوسته
        if h <= 4:
            return img
        denoised = cv2.fastNlMeansDenoisingColored(arr, None, h=h, hColor=h, templateWindowSize=7, searchWindowSize=21)
        from PIL import Image

        return Image.fromarray(cv2.cvtColor(denoised, cv2.COLOR_BGR2RGB))
