# -*- coding: utf-8 -*-
"""
Commander Arm (سندِ معماری، بخش‌هایِ ۱۲-۱۴، ۴۹-۵۰).

Analyzer فقط می‌گوید «چه مشکلی هست»؛ Commander تصمیم می‌گیرد «با چه
ترتیبی حلش کنیم» و چند Planِ کاندید (A/B/C) می‌سازد تا Quality Judge
بینِ‌شان انتخاب کند (بخشِ ۴۲: A/B/C PIPELINE TEST).
"""

from __future__ import annotations

from typing import List

from .contracts import ExecutionPlan, VisionState
from .memory import MemoryEngine
from .models_registry import ModelManager

# ترتیبِ منطقیِ پیش‌فرض: اول نور/نویز پاک شود، بعد بلور، بعد رنگ،
# بعد بزرگ‌نمایی، بعد آرتیفکت، جزئیات همیشه آخر (تا رویِ نتیجه‌یِ نهایی
# اثر بگذارد، نه رویِ چیزی که بعداً دوباره denoise می‌شود).
CANONICAL_ORDER = [
    "low_light",
    "denoise",
    "deblur",
    "color_restore",
    "super_resolution",
    "artifact_removal",
    "detail_restore",
]


class Commander:
    def __init__(self, models: ModelManager, memory: MemoryEngine):
        self.models = models
        self.memory = memory

    def build_plans(self, state: VisionState) -> List[ExecutionPlan]:
        wanted = [op for op in state.recommended_ops if self.models.is_available(op)]
        # حذفِ تکراری با حفظِ اولین رخداد
        seen = set()
        wanted = [op for op in wanted if not (op in seen or seen.add(op))]

        ordered = [op for op in CANONICAL_ORDER if op in wanted]
        plans = [ExecutionPlan(
            name="PLAN_A",
            ops=ordered,
            reasoning="ترتیبِ استاندارد: نور/نویز -> بلور -> رنگ -> بزرگ‌نمایی -> آرتیفکت -> جزئیات",
        )]

        # PLAN_B: اگر هم denoise هم deblur لازم بود، جایشان را عوض کن
        # (تجربه‌یِ عمومی: در بلورِ حرکتیِ شدید، اول deblur نتیجه‌یِ
        # واضح‌تری می‌دهد چون denoise جلوترِ لبه‌هایِ حرکتی را محو می‌کند).
        if "denoise" in ordered and "deblur" in ordered:
            alt = list(ordered)
            i, j = alt.index("denoise"), alt.index("deblur")
            alt[i], alt[j] = alt[j], alt[i]
            plans.append(ExecutionPlan(
                name="PLAN_B",
                ops=alt,
                reasoning="deblur قبل از denoise (برایِ بلورِ شدید ممکن است بهتر باشد)",
            ))

        # PLAN_C: اگر عکس کوچک هم بود، اول بزرگ‌نمایی را جلو بینداز --
        # گاهی deblur/denoise رویِ عکسِ بزرگ‌تر جزئیاتِ بهتری نگه می‌دارد.
        if "super_resolution" in ordered and ordered.index("super_resolution") != 0:
            alt = ["super_resolution"] + [op for op in ordered if op != "super_resolution"]
            plans.append(ExecutionPlan(
                name="PLAN_C",
                ops=alt,
                reasoning="بزرگ‌نمایی زودتر انجام شود، بعد بقیه‌ی ترمیم رویِ عکسِ بزرگ‌تر",
            ))

        # اولویت‌دهی از رویِ Strategy Memory (بخشِ ۴۹): فقط برایِ لاگ/توضیح؛
        # ترتیب توسطِ CANONICAL_ORDER تعیین می‌شود، نه اینجا -- عملیاتِ
        # کلاسیک آن‌قدر ارزان‌اند که حذف‌کردنِ بر اساسِ اولویت لازم نیست.
        for op in wanted:
            _ = self.memory.priority_for(op)

        return plans[:3]
