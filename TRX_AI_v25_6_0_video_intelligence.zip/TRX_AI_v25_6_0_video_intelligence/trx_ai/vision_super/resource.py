# -*- coding: utf-8 -*-
"""Resource Manager (سندِ معماری، بخش‌هایِ ۲۵، ۱۰۱-۱۰۴) -- نسخه‌ی ساده."""

from __future__ import annotations

from dataclasses import dataclass

from ..dependencies import CV2_AVAILABLE, PSUTIL_AVAILABLE


@dataclass
class DeviceProfile:
    ram_available_mb: float
    backend: str
    opencv: bool
    low_memory_mode: bool


LOW_MEMORY_THRESHOLD_MB = 400.0


class ResourceManager:
    def profile(self) -> DeviceProfile:
        ram_mb = -1.0
        if PSUTIL_AVAILABLE:
            try:
                import psutil

                ram_mb = psutil.virtual_memory().available / (1024 * 1024)
            except Exception:  # noqa: BLE001
                ram_mb = -1.0
        low_memory = 0 <= ram_mb < LOW_MEMORY_THRESHOLD_MB
        return DeviceProfile(
            ram_available_mb=ram_mb,
            backend="cv2+numpy" if CV2_AVAILABLE else "pillow-only",
            opencv=CV2_AVAILABLE,
            low_memory_mode=low_memory,
        )
