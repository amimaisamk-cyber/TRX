# -*- coding: utf-8 -*-
"""
Perception Engine (سندِ معماری، بخشِ ۳).

مسئولیت: تبدیلِ عکسِ خام به یک ``PerceptionState`` قابلِ‌استفاده --
هیچ پیکسلی تغییر نمی‌کند، فقط اندازه می‌گیرد.

دو backend، دقیقاً هم‌راستا با بقیه‌یِ پروژه (``dependencies.CV2_AVAILABLE``):
  - وقتی OpenCV/NumPy هست: واریانسِ لاپلاسین برایِ sharpness، تخمینِ
    نویز با فیلترِ میانه، هیستوگرامِ HSV برایِ اشباع.
  - وقتی نیست (Termux/Android معمولاً): همان تخمین‌هایِ خالصِ Pillow
    که ``image_quality.analyzer.ImageAnalyzer`` از قبل استفاده می‌کند
    (بدونِ بازنویسیِ چیزی که از قبل تست شده).
"""

from __future__ import annotations

from ..dependencies import CV2_AVAILABLE
from ..logging_config import get_logger
from .contracts import PerceptionState

logger = get_logger(__name__)

LOW_LIGHT_THRESHOLD = 90.0


class PerceptionEngine:
    def analyze(self, img) -> PerceptionState:
        img = img.convert("RGB")
        if CV2_AVAILABLE:
            try:
                return self._analyze_cv2(img)
            except Exception as e:  # noqa: BLE001 -- هیچ‌وقت نباید کلِ تحلیل را خراب کند
                logger.debug("تحلیلِ perception با OpenCV شکست خورد، به Pillow بازمی‌گردیم: %s", e)
        return self._analyze_pillow(img)

    # ------------------------------------------------------------
    def _analyze_pillow(self, img) -> PerceptionState:
        from PIL import ImageChops, ImageFilter, ImageStat

        gray = img.convert("L")
        blurred = gray.filter(ImageFilter.GaussianBlur(radius=2))
        roughness_stat = ImageStat.Stat(ImageChops.difference(gray, blurred))
        edges = gray.filter(ImageFilter.FIND_EDGES)
        edge_stat = ImageStat.Stat(edges)
        brightness_stat = ImageStat.Stat(gray)
        hsv = img.convert("HSV")
        sat_stat = ImageStat.Stat(hsv.getchannel("S"))
        extrema = gray.getextrema()

        width, height = img.size
        brightness = brightness_stat.mean[0]
        return PerceptionState(
            width=width,
            height=height,
            aspect_ratio=round(width / height, 3) if height else 0.0,
            brightness=brightness,
            contrast_std=brightness_stat.stddev[0],
            sharpness=edge_stat.mean[0],
            noise_estimate=roughness_stat.mean[0],
            dynamic_range=float(extrema[1] - extrema[0]),
            saturation_mean=sat_stat.mean[0],
            edge_density=edge_stat.mean[0] / 255.0,
            low_light=brightness < LOW_LIGHT_THRESHOLD,
            # بدونِ DCT واقعی (سنگین بدونِ numpy)، فقط یک تخمینِ خشن از
            # رویِ نسبتِ edge/noise -- کم‌دقیق، برایِ همین وزنِ کمی در
            # Analyzer می‌گیرد.
            compression_artifact_score=max(0.0, min(1.0, roughness_stat.mean[0] / 40.0)),
            text_probability=min(1.0, (edge_stat.mean[0] / 255.0) * 2.2),
            backend="pillow-only",
        )

    # ------------------------------------------------------------
    def _analyze_cv2(self, img) -> PerceptionState:
        import cv2
        import numpy as np

        arr = np.array(img)  # RGB
        bgr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        sharpness = float(laplacian.var())

        median = cv2.medianBlur(gray, 5)
        noise_estimate = float(np.mean(np.abs(gray.astype(np.int16) - median.astype(np.int16))))

        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        saturation_mean = float(np.mean(hsv[:, :, 1]))

        brightness = float(np.mean(gray))
        contrast_std = float(np.std(gray))
        dynamic_range = float(int(gray.max()) - int(gray.min()))

        edges = cv2.Canny(gray, 60, 150)
        edge_density = float(np.mean(edges > 0))

        # تخمینِ آرتیفکتِ فشرده‌سازی: انرژیِ لبه در مرزهایِ بلوکِ ۸×۸
        # (بلوکینگِ JPEG دقیقاً همان‌جا خودش را نشان می‌دهد) نسبت به کلِ عکس.
        h, w = gray.shape
        block_edges = 0.0
        try:
            gx = np.abs(np.diff(gray.astype(np.int16), axis=1))
            cols = list(range(7, w - 1, 8))
            if cols:
                block_edges = float(np.mean(gx[:, cols])) / (float(np.mean(gx)) + 1e-6)
        except Exception:  # noqa: BLE001
            block_edges = 0.0
        compression_artifact_score = max(0.0, min(1.0, (block_edges - 1.0)))

        width, height = img.size
        return PerceptionState(
            width=width,
            height=height,
            aspect_ratio=round(width / height, 3) if height else 0.0,
            brightness=brightness,
            contrast_std=contrast_std,
            sharpness=sharpness,
            noise_estimate=noise_estimate,
            dynamic_range=dynamic_range,
            saturation_mean=saturation_mean,
            edge_density=edge_density,
            low_light=brightness < LOW_LIGHT_THRESHOLD,
            compression_artifact_score=compression_artifact_score,
            text_probability=min(1.0, edge_density * 3.5),
            backend="cv2+numpy",
        )
