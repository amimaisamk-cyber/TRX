# -*- coding: utf-8 -*-
"""
پیکربندی لاگ‌گیری متمرکز برای TRX Enterprise AI.

به‌جای پخش‌شدن print() های خطا در سراسر کد، همه‌ی رخدادهای مهم
(خطاها، هشدارها، شروع/پایان عملیات حساس) از طریق logging استاندارد
پایتون ثبت می‌شوند تا در محیط تولید قابل پایش و عیب‌یابی باشند.

خروجی پیام‌های کاربرپسند فارسی که قبلاً با print() نمایش داده می‌شدند
دست‌نخورده باقی می‌مانند؛ این ماژول فقط یک لایه‌ی مشاهده‌پذیری اضافه
می‌کند و هیچ رفتار موجودی را تغییر نمی‌دهد.
"""

from __future__ import annotations

import logging
import logging.handlers
import os
from pathlib import Path

LOG_DIR = Path(os.environ.get("TRX_LOG_DIR", "logs"))
LOG_FILE = LOG_DIR / "trx_ai.log"
LOG_LEVEL = os.environ.get("TRX_LOG_LEVEL", "INFO").upper()

_LOGGER_NAME = "trx_ai"
_configured = False


def get_logger(name: str = _LOGGER_NAME) -> logging.Logger:
    """بازگرداندن یک logger فرزند با پیکربندی یکسان."""
    setup_logging()
    return logging.getLogger(name)


def setup_logging(level: str | None = None) -> logging.Logger:
    """
    پیکربندی یک‌بارهٔ سیستم لاگ.

    - خروجی کنسول: فقط پیام‌های WARNING به بالا (تا رابط کاربری Rich شلوغ نشود).
    - فایل چرخشی logs/trx_ai.log: همه‌ی سطوح از TRX_LOG_LEVEL به بالا،
      با حداکثر ۵ فایل ۱ مگابایتی.
    """
    global _configured
    logger = logging.getLogger(_LOGGER_NAME)
    if _configured:
        return logger

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger.setLevel(level or LOG_LEVEL)
    logger.propagate = False

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=1_000_000, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(fmt)
    file_handler.setLevel(level or LOG_LEVEL)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(fmt)
    console_handler.setLevel(logging.WARNING)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    _configured = True
    logger.debug("سیستم لاگ‌گیری راه‌اندازی شد.")
    return logger
