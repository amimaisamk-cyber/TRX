# -*- coding: utf-8 -*-
"""
ارکستریتورِ حلقه‌ی بهبودِ کیفیت.

سه بازو (Analyzer / Executor / Evaluator) هرکدام کاملاً مستقل و
به‌تنهایی معتبرند (هرکدام در فایلِ خودشان، بدونِ وابستگیِ متقابل به
جزئیاتِ همدیگر). این فایل فقط چرخه‌شان را کنار هم می‌چیند:

    ۱. Analyzer عکسِ خام را می‌سنجد و یک پلن می‌سازد.
    ۲. Executor پلن را رویِ عکسِ *خام* اجرا می‌کند (نه رویِ خروجیِ دورِ
       قبل -- نگاه کنید به توضیحِ ImageExecutor.execute).
    ۳. Evaluator نتیجه را با عکسِ خام مقایسه و نمره می‌دهد.
    ۴. اگر نمره >= TARGET_SCORE برسد، همان‌جا تمام می‌شود.
       اگر نه، Analyzer با توجه به نمره یک پلنِ اصلاح‌شده می‌سازد و
       دوباره از مرحله‌ی ۲ شروع می‌شود -- تا سقفِ MAX_ITERATIONS.
    ۵. در پایان، بهترین نتیجه‌ای که در کلِ چرخه دیده شده (نه لزوماً
       آخرین تلاش) به‌عنوانِ خروجیِ نهایی انتخاب می‌شود؛ چون امکان دارد
       تلاشِ آخر از تلاشِ ماقبلش بدتر شده باشد.

MAX_ITERATIONS یک سقفِ ایمنی است: اگر عکس آن‌قدر خراب باشد که هرگز به
۹۰٪ نرسد (مثلاً کاملاً تارِ حرکتی)، چرخه باید بالاخره متوقف شود و
بهترین‌چیزی که پیدا کرده را برگرداند -- نه اینکه تا ابد تکرار کند.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

from .analyzer import ImageAnalyzer
from .evaluator import ImageEvaluator
from .executor import ImageExecutor


@dataclass
class EnhancementResult:
    out_path: str
    before_size: tuple
    after_size: tuple
    score: float               # ۰ تا ۱۰۰
    iterations_used: int
    reached_target: bool
    log: list                  # رشته‌هایِ توضیحِ هر تلاش (برایِ دیباگ/شفافیت)


class ImageEnhancementPipeline:
    TARGET_SCORE = 90.0
    MAX_ITERATIONS = 6  # سقفِ ایمنی -- از حلقه‌ی بی‌پایان جلوگیری می‌کند

    def __init__(self):
        self.analyzer = ImageAnalyzer()
        self.executor = ImageExecutor()
        self.evaluator = ImageEvaluator()

    @staticmethod
    def _same_effective_plan(a, b) -> bool:
        """مقایسه‌ی دو پلن با نادیده‌گرفتنِ فیلدِ ``reasoning`` (که همیشه فرق دارد)."""
        fields = ("median_size", "gaussian_radius", "denoise_passes", "unsharp_radius",
                  "unsharp_percent", "unsharp_threshold", "contrast_factor", "color_factor")
        return all(getattr(a, f) == getattr(b, f) for f in fields)

    def run(self, image_path: str, files_dir: str, scale: float = 2.0) -> EnhancementResult:
        from PIL import Image

        with Image.open(image_path) as raw:
            original = raw.convert("RGB")
            before_size = original.size

            metrics = self.analyzer.analyze(original)
            plan = self.analyzer.initial_plan(metrics)
            plan.upscale_target_scale = scale

            best_score = -1.0
            best_img = None
            best_breakdown = {}
            log = []

            for iteration in range(1, self.MAX_ITERATIONS + 1):
                candidate = self.executor.execute(original, plan)
                score, breakdown = self.evaluator.score(original, candidate)
                log.append(
                    f"تلاشِ {iteration}: نمره={score:.1f}٪ | {plan.reasoning} | "
                    f"noise={breakdown['noise_reduction']:.2f} "
                    f"detail={breakdown['detail_retention']:.2f} "
                    f"exposure={breakdown['exposure']:.2f}"
                )

                if score > best_score:
                    best_score, best_img, best_breakdown = score, candidate, breakdown

                if score >= self.TARGET_SCORE:
                    break

                next_plan = self.analyzer.refine_plan(plan, metrics, breakdown, iteration + 1)
                if self._same_effective_plan(next_plan, plan):
                    # هیچ اهرمی برایِ بهبودِ بیشتر باقی نمانده -- ادامه‌دادن
                    # فقط همان نتیجه را تکرار می‌کند و تلاش‌هایِ باقی‌مانده
                    # را هدر می‌دهد؛ همین‌جا با بهترین نتیجه‌ای که پیدا شده
                    # متوقف می‌شویم.
                    log.append(f"توقفِ زودهنگام: هیچ اهرمِ دیگری برایِ بهبود باقی نمانده (بعد از تلاشِ {iteration}).")
                    break
                plan = next_plan
            else:
                iteration = self.MAX_ITERATIONS

            base, _ = os.path.splitext(os.path.basename(image_path))
            out_name = f"{base}_enhanced.jpg"
            out_path = os.path.join(files_dir, out_name)
            best_img.save(out_path, "JPEG", quality=95)

            return EnhancementResult(
                out_path=out_path,
                before_size=before_size,
                after_size=best_img.size,
                score=best_score,
                iterations_used=len(log),
                reached_target=best_score >= self.TARGET_SCORE,
                log=log,
            )
