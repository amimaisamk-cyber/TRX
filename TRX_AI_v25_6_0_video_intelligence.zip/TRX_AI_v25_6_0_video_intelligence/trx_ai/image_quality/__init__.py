# -*- coding: utf-8 -*-
"""
پکیجِ بهبودِ کیفیتِ عکس -- سه بازوی مستقل + یک ارکستریتور.

    analyzer.py   -- ImageAnalyzer: می‌سنجد و پلن می‌سازد
    executor.py   -- ImageExecutor: پلن را اجرا می‌کند (denoise/upscale/sharpen/contrast)
    evaluator.py  -- ImageEvaluator: نتیجه را نمره می‌دهد
    pipeline.py   -- ImageEnhancementPipeline: چرخه‌ی «تحلیل -> اجرا -> ارزیابی -> تکرار»

فقط از Pillow استفاده می‌کند (بدونِ numpy/cv2)، پس رویِ Pydroid هم کار
می‌کند -- نگاه کنید به بحثِ مربوط در trx_ai/dependencies.py (CV2_AVAILABLE).
"""

from .analyzer import ExecutionPlan, ImageAnalyzer, ImageMetrics
from .evaluator import ImageEvaluator
from .executor import ImageExecutor
from .pipeline import EnhancementResult, ImageEnhancementPipeline

__all__ = [
    "ImageAnalyzer",
    "ImageMetrics",
    "ExecutionPlan",
    "ImageExecutor",
    "ImageEvaluator",
    "ImageEnhancementPipeline",
    "EnhancementResult",
]
