# -*- coding: utf-8 -*-
"""
بازویِ «اجراکننده» (Executor).

مسئولیتِ این ماژول فقط اجرایِ دستورِ ``ExecutionPlan`` است که بازویِ
Analyzer می‌سازد -- هیچ تصمیمی خودش نمی‌گیرد (نه دربابِ اینکه چقدر
denoise لازم است، نه دربابِ اینکه پردازش خوب بوده یا نه؛ آن کارِ
Evaluator است). هر مرحله («بازو») در این‌جا یک تابعِ کاملاً مستقل و
خودکفاست: ورودی‌اش عکس + چند عددِ ساده است، خروجی‌اش فقط عکس -- هیچ
تابعی از حالتِ توابعِ دیگر خبر ندارد، پس هرکدام به‌تنهایی هم قابلِ
فراخوانی/تست است.

ترتیبِ اجرا (execute): denoise -> upscale -> sharpen -> contrast/color.
این ترتیب عمداً همین است: اگر شارپ‌کردن قبل از denoise انجام شود،
خودِ نویز هم مثلِ لبه‌هایِ واقعی تیزتر می‌شود.
"""

from __future__ import annotations

from .analyzer import ExecutionPlan


# ------------------------------------------------------------
#   بازو ۱: کاهشِ نویز -- کاملاً مستقل، فقط median_size/gaussian_radius می‌گیرد
# ------------------------------------------------------------
def denoise_arm(img, median_size: int, gaussian_radius: float, passes: int = 1):
    from PIL import ImageFilter

    if median_size < 3:
        median_size = 3
    if median_size % 2 == 0:  # MedianFilter فقط اندازه‌ی فرد قبول می‌کند
        median_size += 1

    out = img
    for _ in range(max(1, passes)):
        out = out.filter(ImageFilter.MedianFilter(size=median_size))
        if gaussian_radius > 0:
            out = out.filter(ImageFilter.GaussianBlur(radius=gaussian_radius))
    return out


# ------------------------------------------------------------
#   بازو ۲: بزرگ‌نمایی -- کاملاً مستقل، فقط وقتی که Analyzer صریحاً بخواهد
# ------------------------------------------------------------
def upscale_arm(img, target_scale: float):
    from PIL import Image

    target_scale = max(1.5, min(target_scale, 4.0))
    new_size = (int(img.width * target_scale), int(img.height * target_scale))
    return img.resize(new_size, Image.LANCZOS)


# ------------------------------------------------------------
#   بازو ۳: شارپ‌کردن -- کاملاً مستقل، فقط پارامترهایِ UnsharpMask می‌گیرد
# ------------------------------------------------------------
def sharpen_arm(img, radius: float, percent: int, threshold: int):
    from PIL import ImageFilter

    return img.filter(ImageFilter.UnsharpMask(radius=radius, percent=percent, threshold=threshold))


# ------------------------------------------------------------
#   بازو ۴: کنتراست/اشباعِ رنگ -- کاملاً مستقل
# ------------------------------------------------------------
def contrast_arm(img, contrast_factor: float, color_factor: float):
    from PIL import ImageEnhance

    out = ImageEnhance.Contrast(img).enhance(contrast_factor)
    out = ImageEnhance.Color(out).enhance(color_factor)
    return out


class ImageExecutor:
    """فقط هماهنگ‌کننده‌ی چهار بازویِ بالا، به همان ترتیبِ ثابت."""

    def execute(self, original_img, plan: ExecutionPlan):
        """
        همیشه از رویِ ``original_img`` شروع می‌کند (نه رویِ خروجیِ تلاشِ
        قبلی) -- این عمدی‌ست: اگر هر تلاش رویِ خروجیِ تلاشِ قبل اعمال
        شود، چند دور median filter پشتِ‌سرِهم عکس را به‌جایِ تمیزکردن
        محو (over-smooth) می‌کند. هر تلاش یک اجرایِ تازه با پارامترهایِ
        جدید رویِ همان عکسِ خام است.
        """
        out = denoise_arm(original_img, plan.median_size, plan.gaussian_radius, plan.denoise_passes)
        if plan.do_upscale:
            out = upscale_arm(out, plan.upscale_target_scale)
        out = sharpen_arm(out, plan.unsharp_radius, plan.unsharp_percent, plan.unsharp_threshold)
        out = contrast_arm(out, plan.contrast_factor, plan.color_factor)
        return out
