# -*- coding: utf-8 -*-
"""
بازویِ «ارزیاب» (Evaluator).

مسئولیتِ این ماژول فقط مقایسه‌ی عکسِ اصلی با عکسِ پردازش‌شده و دادنِ
یک نمره‌ی ۰ تا ۱۰۰ است. نه تصمیم می‌گیرد که چه پردازشی لازم است (کارِ
Analyzer)، نه خودش پردازشی انجام می‌دهد (کارِ Executor) -- فقط قضاوت.

سه معیار با وزنِ متفاوت:
    noise_reduction (وزن ۵۰٪) -- چقدر «خشنیِ» فرکانسِ‌بالا (نویز) نسبت
        به عکسِ اصلی کم شده. مهم‌ترین معیار چون کاربر عکسِ نویزی داده.
    detail_retention (وزن ۳۰٪) -- آیا denoise آن‌قدر زیاد نبوده که
        جزئیاتِ واقعی (لبه‌هایِ برج، مرزِ ماه، ...) هم محو شده باشد.
    exposure (وزن ۲۰٪) -- آیا روشنایی/کنتراستِ نهایی در بازه‌ی معقول
        است (نه خیلی تیره، نه سوخته).
"""

from __future__ import annotations

from .analyzer import ImageAnalyzer, ImageMetrics


class ImageEvaluator:
    def __init__(self):
        # از همان منطقِ اندازه‌گیریِ Analyzer استفاده می‌کند تا معیارها
        # رویِ عکسِ اصلی و عکسِ پردازش‌شده دقیقاً قابلِ‌مقایسه باشند --
        # ولی خودِ Evaluator هرگز پلن نمی‌سازد، فقط می‌سنجد.
        self._measurer = ImageAnalyzer()

    def score(self, original_img, processed_img) -> tuple[float, dict]:
        orig = self._measurer.analyze(original_img)
        result = self._measurer.analyze(processed_img)

        noise_reduction = self._noise_reduction_score(orig, result)
        detail_retention = self._detail_retention_score(orig, result)
        exposure = self._exposure_score(result)

        overall = 100.0 * (0.5 * noise_reduction + 0.3 * detail_retention + 0.2 * exposure)
        overall = max(0.0, min(100.0, overall))

        breakdown = {
            "noise_reduction": noise_reduction,
            "detail_retention": detail_retention,
            "exposure": exposure,
            "overall": overall,
        }
        return overall, breakdown

    @staticmethod
    def _noise_reduction_score(orig: ImageMetrics, result: ImageMetrics) -> float:
        if orig.roughness <= 0:
            return 1.0  # عکسِ اصلی از اول نویز نداشت
        reduction = (orig.roughness - result.roughness) / orig.roughness
        return max(0.0, min(1.0, reduction))

    @staticmethod
    def _detail_retention_score(orig: ImageMetrics, result: ImageMetrics) -> float:
        if orig.edge_energy <= 0:
            return 1.0
        # انتظار داریم بخشِ زیادی از edge_energyِ اصلی نویز بوده باشد، پس
        # افتِ آن طبیعی است؛ اما اگر به‌شدت افتاده باشد (عکس تارِ محض شده)
        # یعنی denoise جزئیاتِ واقعی را هم با خودش برده.
        ratio = result.edge_energy / (orig.edge_energy * 0.35)
        return max(0.0, min(1.0, ratio))

    @staticmethod
    def _exposure_score(result: ImageMetrics) -> float:
        b = result.brightness
        if 60 <= b <= 200:
            brightness_score = 1.0
        elif b < 60:
            brightness_score = max(0.0, b / 60)
        else:  # b > 200
            brightness_score = max(0.0, (255 - b) / 55)

        # کنتراستِ خیلی پایین (عکسِ صاف/خاکستری) هم جریمه می‌شود
        contrast_score = min(1.0, result.contrast_std / 35)
        return 0.7 * brightness_score + 0.3 * contrast_score
