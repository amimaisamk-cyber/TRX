# -*- coding: utf-8 -*-
"""
بازویِ «تحلیل‌گر» (Analyzer).

مسئولیتِ این ماژول فقط یک چیز است: نگاه‌کردن به عکس و گفتنِ اینکه
چه چیزی مشکل دارد و چه دستوری باید به بازویِ اجراکننده داده شود.
این ماژول هیچ پیکسلی را تغییر نمی‌دهد -- فقط می‌خواند و تصمیم می‌گیرد.
کاملاً مستقل از Executor و Evaluator است؛ فقط با Image و اعداد کار
می‌کند، پس به‌تنهایی هم قابلِ تست/استفاده است.

خروجیِ اصلی: ``ExecutionPlan`` -- یک دیکشنری از پارامترهایِ ساده
(مثلِ ``median_size``) که بازویِ اجراکننده مستقیماً مصرف می‌کند.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ImageMetrics:
    """اندازه‌گیریِ خامِ عکس -- بدونِ نیاز به numpy/cv2، فقط با Pillow."""

    brightness: float          # میانگینِ روشنایی، ۰ تا ۲۵۵
    contrast_std: float        # انحرافِ‌معیارِ روشنایی (پراکندگی/کنتراست)
    roughness: float           # تخمینِ نویز: تفاوتِ عکس با نسخه‌ی بلورشده‌اش
    edge_energy: float         # تخمینِ جزئیات/لبه: میانگینِ خروجیِ FIND_EDGES
    width: int
    height: int


@dataclass
class ExecutionPlan:
    """دستورِ کاملی که بازویِ اجراکننده بدونِ هیچ تصمیمِ اضافه اجرا می‌کند."""

    median_size: int = 3          # اندازه‌ی MedianFilter (باید فرد باشد)
    gaussian_radius: float = 0.0  # شعاعِ GaussianBlurِ اضافی بعد از median
    denoise_passes: int = 1       # چند بار پشتِ‌سرِهم denoise تکرار شود
    unsharp_radius: float = 1.5
    unsharp_percent: int = 130
    unsharp_threshold: int = 2
    contrast_factor: float = 1.10
    color_factor: float = 1.08
    do_upscale: bool = False
    upscale_target_scale: float = 2.0
    # فقط برایِ لاگ/دیباگ -- در Executor مصرف نمی‌شود:
    reasoning: str = ""


class ImageAnalyzer:
    """
    اندازه‌گیری + برنامه‌ریزی. بدونِ حالت (stateless) به‌جز آستانه‌ها،
    پس هر فراخوانی مستقل از فراخوانی‌هایِ قبلی است.
    """

    # میانگینِ روشناییِ زیرِ این مقدار یعنی عکس کم‌نور است (سنسورِ دوربین
    # در تاریکی نویزِ بیشتری تولید می‌کند).
    LOW_LIGHT_THRESHOLD = 90
    # عکسِ بزرگ‌تر از این عرض دیگر بزرگ‌نمایی نمی‌شود (بزرگ‌نماییِ عکسِ
    # از‌قبل‌بزرگ هیچ جزئیاتِ واقعی اضافه نمی‌کند).
    UPSCALE_MAX_WIDTH = 900

    def analyze(self, img) -> ImageMetrics:
        """اندازه‌گیریِ چهار معیارِ ساده از رویِ عکسِ اصلی (فقط Pillow)."""
        from PIL import ImageChops, ImageFilter, ImageStat

        gray = img.convert("L")
        blurred = gray.filter(ImageFilter.GaussianBlur(radius=2))
        roughness_stat = ImageStat.Stat(ImageChops.difference(gray, blurred))
        edges = gray.filter(ImageFilter.FIND_EDGES)

        brightness_stat = ImageStat.Stat(gray)

        return ImageMetrics(
            brightness=brightness_stat.mean[0],
            contrast_std=brightness_stat.stddev[0],
            roughness=roughness_stat.mean[0],
            edge_energy=ImageStat.Stat(edges).mean[0],
            width=img.width,
            height=img.height,
        )

    def initial_plan(self, metrics: ImageMetrics) -> ExecutionPlan:
        """پلنِ شروع (تلاشِ اول) -- فقط از رویِ معیارهایِ عکسِ خام."""
        low_light = metrics.brightness < self.LOW_LIGHT_THRESHOLD
        # نویزِ خیلی شدید (مثلِ عکسِ شبِ ISOِ بالا) به یک شروعِ قوی‌تر
        # از همان تلاشِ اول نیاز دارد، وگرنه چرخه فقط برایِ رسیدن به
        # نقطه‌ی معقول چند دور الکی تلف می‌کند.
        heavy_noise = metrics.roughness > 12

        if heavy_noise:
            median_size, gaussian_radius = 7, 0.8
        elif low_light:
            median_size, gaussian_radius = 5, 0.6
        else:
            median_size, gaussian_radius = 3, 0.0

        do_upscale = metrics.width < self.UPSCALE_MAX_WIDTH
        unsharp_percent = 120 if do_upscale else 150
        unsharp_radius = 2.0 if do_upscale else 1.5

        return ExecutionPlan(
            median_size=median_size,
            gaussian_radius=gaussian_radius,
            unsharp_radius=unsharp_radius,
            unsharp_percent=unsharp_percent,
            unsharp_threshold=2,
            contrast_factor=1.10,
            color_factor=1.08,
            do_upscale=do_upscale,
            reasoning=(
                f"شروع: brightness={metrics.brightness:.0f} "
                f"roughness={metrics.roughness:.1f} "
                f"(heavy_noise={heavy_noise}, low_light={low_light})"
            ),
        )

    def refine_plan(
        self,
        previous_plan: ExecutionPlan,
        previous_metrics: ImageMetrics,
        result_breakdown: dict,
        iteration: int,
    ) -> ExecutionPlan:
        """
        پلنِ تلاشِ بعدی، بر اساسِ نمره‌یِ تلاشِ قبلی. این‌جا نمی‌آید عکس
        را دوباره پردازش کند -- Executor همیشه از رویِ عکسِ *اصلی*
        دوباره شروع می‌کند (نگاه کنید به pipeline.py) تا نویزِ باقیمانده
        روی‌هم انباشته نشود و فقط تارتر شدنِ پی‌درپی رخ ندهد.
        """
        plan = ExecutionPlan(**previous_plan.__dict__)

        noise_score = result_breakdown.get("noise_reduction", 0.0)
        detail_score = result_breakdown.get("detail_retention", 0.0)
        exposure_score = result_breakdown.get("exposure", 0.0)

        notes = []
        NOISE_TARGET = 0.85  # (نه ۰.۷۵) تا در مرزهایِ محاسباتی هم اهرمِ بعدی فعال بماند

        # هنوز نویزی‌ست -> اول median_size را زیاد کن؛ وقتی median_size
        # به سقف رسید (دیگر از این اهرم چیزی گیر نمی‌آید)، یک اهرمِ دیگر
        # را فعال کن: خودِ denoise را چند بار پشتِ‌سرِهم تکرار کن.
        if noise_score < NOISE_TARGET and plan.median_size < 9:
            plan.median_size = min(plan.median_size + 2, 9)
            plan.gaussian_radius = min(plan.gaussian_radius + 0.3, 1.6)
            notes.append(f"denoise قوی‌تر شد (median={plan.median_size})")
        elif noise_score < NOISE_TARGET and plan.denoise_passes < 3:
            plan.denoise_passes += 1
            notes.append(f"denoise چندپاسه شد ({plan.denoise_passes} پاس)")

        # جزئیات بیش‌ازحد محو شده (over-smoothing) -> denoise را کمی
        # سبک‌تر کن و شارپ را قوی‌تر تا لبه‌ها برگردند
        elif detail_score < 0.5 and (plan.median_size > 3 or plan.denoise_passes > 1):
            if plan.denoise_passes > 1:
                plan.denoise_passes -= 1
            else:
                plan.median_size = max(plan.median_size - 2, 3)
            plan.unsharp_percent = min(plan.unsharp_percent + 30, 220)
            notes.append(f"denoise سبک‌تر و شارپ قوی‌تر شد (median={plan.median_size}, passes={plan.denoise_passes})")

        # روشنایی/کنتراستِ نامناسب -> اصلاحِ تدریجی
        if exposure_score < 0.7:
            if previous_metrics.brightness < 80:
                plan.contrast_factor = min(plan.contrast_factor + 0.05, 1.35)
                notes.append("کنتراست بیشتر شد (عکس هنوز تیره است)")
            elif previous_metrics.brightness > 200:
                plan.contrast_factor = max(plan.contrast_factor - 0.05, 0.95)
                notes.append("کنتراست کمتر شد (عکس روبه‌سوختگی است)")

        plan.reasoning = f"تلاشِ #{iteration}: " + ("، ".join(notes) if notes else "بدونِ تغییرِ محسوس")
        return plan
