# -*- coding: utf-8 -*-
"""
موتور رابط کاربری (UIEngine): پنل‌های تمیز و کم‌شلوغ با یک رنگ لهجه‌ی
گرمِ واحد، جداسازیِ واضح بین پیام‌های سیستم/پزشکی/اورژانسی، و یک جلوه‌ی
نمایشِ تدریجیِ پاسخ (به‌جای چاپ یک‌باره‌ی کل متن).

نکته: shaping فارسی (arabic_reshaper/python-bidi) و نرمال‌سازی با hazm
عمداً غیرفعال شدند — در محیطِ اجرای واقعی (Termux/اندروید) نصب/ایمپورتِ
این کتابخانه‌ها با خطا مواجه می‌شد (hazm وابستگی‌های سنگینی مثل numpy/nltk
دارد که روی اندروید معمولاً build نمی‌شوند). به‌جای یک ویژگیِ ناپایدار،
ترجیح داده شد این بخش کامل کامنت شود تا برنامه همیشه پایدار اجرا شود؛
کدشان برای مرجع/فعال‌سازیِ احتمالیِ آینده (روی دسکتاپ/سرور) نگه داشته
شده. persiantools (تقویم شمسی/ارقام) چون گزارشِ خطا نداشت، فعال ماند.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Tuple

from rich.align import Align
from rich.box import HEAVY, ROUNDED
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .logging_config import get_logger

logger = get_logger(__name__)

# ---- شکل‌دهیِ متن فارسی: عمداً غیرفعال شد (نصب/ایمپورت در Termux خطا می‌داد) ----
# try:
#     import arabic_reshaper
#     from bidi.algorithm import get_display
#
#     _SHAPING_AVAILABLE = True
# except ImportError:
#     _SHAPING_AVAILABLE = False
#     logger.warning(
#         "arabic_reshaper/python-bidi نصب نیست؛ متن فارسی ممکن است در برخی "
#         "ترمینال‌ها ناپیوسته نمایش داده شود."
#     )
_SHAPING_AVAILABLE = False

# ---- نرمال‌سازیِ متن فارسی با hazm: عمداً غیرفعال شد (نصب/ایمپورت در Termux خطا می‌داد) ----
# try:
#     from hazm import Normalizer as _HazmNormalizer
#
#     _normalizer = _HazmNormalizer()
#     _NORMALIZE_AVAILABLE = True
# except Exception:  # noqa: BLE001 - نبودِ hazm یا خطای بارگذاریِ مدل نباید برنامه را متوقف کند
#     _normalizer = None
#     _NORMALIZE_AVAILABLE = False
#     logger.warning("hazm نصب نیست؛ نرمال‌سازیِ متن فارسی غیرفعال است.")
_normalizer = None
_NORMALIZE_AVAILABLE = False

# ---- تقویم شمسی/ارقام فارسی با persiantools (اختیاری) ----
try:
    from persiantools import digits as _pdigits
    from persiantools.jdatetime import JalaliDate as _JalaliDate

    _PERSIANTOOLS_AVAILABLE = True
except ImportError:
    _PERSIANTOOLS_AVAILABLE = False
    logger.warning("persiantools نصب نیست؛ از تبدیل تقویمِ داخلی استفاده می‌شود.")

# ==========================================================
#   پالت رنگ: یک لهجه‌ی گرم واحد + خاکستری‌های خنثی
# ==========================================================
ACCENT = "#CC785C"
ACCENT_SOFT = "#D9A184"
INK = "#E8E6E1"
MUTED = "grey62"
DANGER = "#D9534F"
SUCCESS = "#6BAA75"


def reshape_fa(text: str) -> str:
    """
    (غیرفعال) این تابع قبلاً متن فارسی را با hazm نرمال‌سازی و با
    arabic_reshaper/python-bidi شکل‌دهی می‌کرد؛ چون این کتابخانه‌ها در
    محیطِ اجرای واقعی نصب/ایمپورت نمی‌شدند، فعلاً غیرفعال شده و متن را
    بدون تغییر برمی‌گرداند. امضای تابع عمداً حفظ شده تا همه‌جای کد که
    از آن استفاده می‌کنند (بدون تغییر) کار کنند.
    """
    if not text:
        return text
    result = text
    if _NORMALIZE_AVAILABLE:
        try:
            result = "\n".join(_normalizer.normalize(line) if line.strip() else line
                                for line in result.split("\n"))
        except Exception:  # noqa: BLE001
            logger.debug("نرمال‌سازیِ hazm شکست خورد؛ ادامه با متن خام.")
    if _SHAPING_AVAILABLE:
        try:
            result = "\n".join(
                get_display(arabic_reshaper.reshape(line)) if line.strip() else line
                for line in result.split("\n")
            )
        except Exception:  # noqa: BLE001 - نمایش هرگز نباید کل برنامه را متوقف کند
            logger.debug("شکل‌دهیِ فارسی برای یک خط شکست خورد؛ نمایشِ متنِ خام.")
    return result


class _TerminalStreamHandle:
    """
    نگه‌دارنده‌ی یک نمایشِ زنده (Live) در ترمینال برایِ استریمِ توکن‌به‌توکنِ
    یک پاسخ. مصرف‌کننده با هر تکه‌ی جدیدی که تولید می‌شود
    ``update(متنِ‌کامل‌تاکنون)`` صدا می‌زند؛ ``close()`` باید در
    پایان (چه موفق چه با خطا) صدا زده شود تا Live آزاد شود.

    نکته: این پروژه دیگر به هیچ APIِ مولدِ خارجی وصل نمی‌شود، پس در حالِ
    حاضر core.py از این مسیر استفاده نمی‌کند؛ فقط برایِ سازگاریِ آینده
    (مثلاً استریمِ خروجیِ یک ابزارِ محلیِ کند) نگه داشته شده.
    """

    def __init__(self, console: Console, title: str, style: str):
        from rich.live import Live

        self._title = title
        self._style = style
        self._live = Live(console=console, refresh_per_second=12, transient=False)
        self._live.__enter__()

    def update(self, text: str) -> None:
        shaped = reshape_fa(text)
        try:
            self._live.update(
                Panel(Text(shaped, style=INK), title=f"[bold]{self._title}[/bold]",
                      border_style=self._style, box=ROUNDED, padding=(1, 2))
            )
        except Exception as e:  # noqa: BLE001 - آپدیتِ نمایش هرگز نباید استریم را متوقف کند
            logger.debug("به‌روزرسانیِ نمایشِ زنده شکست خورد: %s", e)

    def close(self) -> None:
        try:
            self._live.__exit__(None, None, None)
        except Exception as e:  # noqa: BLE001
            logger.debug("بستنِ نمایشِ زنده شکست خورد: %s", e)


class UIEngine:
    """رابط کاربریِ کنسولی؛ همه‌ی برچسب‌ها/عنوان‌ها/راهنما فارسی هستند."""

    APP_NAME = "TRX AI"
    APP_TAGLINE = "دستیار هوشمند فارسی‌زبان شما"

    _FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
    _EN_DIGITS = "0123456789"
    _FA_MONTHS = [
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
    ]

    def __init__(self):
        self.console = Console(highlight=False)

    # ----------------------------------------------------------------
    #   ابزارهای کمکیِ نمایشی
    # ----------------------------------------------------------------
    def e2f(self, value) -> str:
        """اعداد انگلیسی را به ارقام فارسی تبدیل می‌کند (ترجیحاً با persiantools)."""
        if _PERSIANTOOLS_AVAILABLE:
            try:
                return _pdigits.en_to_fa(str(value))
            except Exception as e:  # noqa: BLE001
                logger.debug("persiantools.en_to_fa شکست خورد، به تبدیلِ داخلی بازمی‌گردیم: %s", e)
        table = str.maketrans(self._EN_DIGITS, self._FA_DIGITS)
        return str(value).translate(table)

    def f2e(self, value) -> str:
        """ارقام فارسی را به انگلیسی برمی‌گرداند (ترجیحاً با persiantools)."""
        if _PERSIANTOOLS_AVAILABLE:
            try:
                return _pdigits.fa_to_en(str(value))
            except Exception as e:  # noqa: BLE001
                logger.debug("persiantools.fa_to_en شکست خورد، به تبدیلِ داخلی بازمی‌گردیم: %s", e)
        table = str.maketrans(self._FA_DIGITS, self._EN_DIGITS)
        return str(value).translate(table)

    def get_farsi_date_time(self) -> Tuple[str, str]:
        """تاریخ شمسی و ساعت سیستم را با ارقام فارسی برمی‌گرداند: (تاریخ, ساعت)."""
        now = datetime.now()
        if _PERSIANTOOLS_AVAILABLE:
            try:
                jdate = _JalaliDate.today()
                date_str = self.e2f(f"{jdate.day} {self._FA_MONTHS[jdate.month - 1]} {jdate.year}")
                return date_str, self.e2f(now.strftime("%H:%M:%S"))
            except Exception as e:  # noqa: BLE001
                logger.debug("محاسبه‌ی تاریخِ شمسی با persiantools شکست خورد، به fallback داخلی بازمی‌گردیم: %s", e)
        jy, jm, jd = self._gregorian_to_jalali(now.year, now.month, now.day)
        date_str = self.e2f(f"{jd} {self._FA_MONTHS[jm - 1]} {jy}")
        time_str = self.e2f(now.strftime("%H:%M:%S"))
        return date_str, time_str

    @staticmethod
    def _gregorian_to_jalali(gy: int, gm: int, gd: int):
        """تبدیل میلادی به شمسی؛ فقط زمانی استفاده می‌شود که persiantools نصب نباشد."""
        g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]
        gy2 = gy - 1600
        gm2 = gm - 1
        gd2 = gd - 1
        g_day_no = 365 * gy2 + (gy2 + 3) // 4 - (gy2 + 99) // 100 + (gy2 + 399) // 400
        for i in range(gm2):
            g_day_no += g_days_in_month[i]
        if gm2 > 1 and ((gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0):
            g_day_no += 1
        g_day_no += gd2
        j_day_no = g_day_no - 79
        j_np = j_day_no // 12053
        j_day_no %= 12053
        jy = 979 + 33 * j_np + 4 * (j_day_no // 1461)
        j_day_no %= 1461
        if j_day_no >= 366:
            jy += (j_day_no - 1) // 365
            j_day_no = (j_day_no - 1) % 365
        jm = 0
        for i in range(11):
            if j_day_no < j_days_in_month[i]:
                jm = i
                break
            j_day_no -= j_days_in_month[i]
        else:
            jm = 11
        jm += 1
        jd = j_day_no + 1
        return jy, jm, jd

    # ----------------------------------------------------------------
    #   بنر ابتدایی و راهنما
    # ----------------------------------------------------------------
    def show_header(self, user_name: str, personality: str, active_session: str):
        self.console.clear()
        title = Text(f"✦ {self.APP_NAME}", style=f"bold {ACCENT}")
        subtitle = Text(self.APP_TAGLINE, style=MUTED)

        status = Table.grid(padding=(0, 2))
        status.add_column(justify="left", style=MUTED)
        status.add_column(justify="left", style=f"bold {INK}")
        status.add_row("کاربر", reshape_fa(user_name))
        status.add_row("شخصیت", reshape_fa(personality))
        status.add_row("پروژه", reshape_fa(active_session or "پیش‌فرض"))

        body = Table.grid(padding=(1, 0))
        body.add_row(Align.center(title))
        body.add_row(Align.center(subtitle))
        body.add_row(Text(""))
        body.add_row(Align.center(status))

        self.console.print(Panel(body, box=ROUNDED, border_style=ACCENT, padding=(1, 4)))

    def show_guide(self):
        table = Table(
            title="راهنمای سریع",
            box=ROUNDED,
            border_style=ACCENT,
            title_style=f"bold {ACCENT}",
            header_style=f"bold {INK}",
        )
        table.add_column("دستور", style=ACCENT_SOFT, no_wrap=True)
        table.add_column("عملکرد", style=INK)

        rows = [
            ("خروج / exit / quit", "پایان جلسه"),
            ("آمار", "نمایش داشبورد آمار سیستم"),
            ("داشبورد", "RAM/CPU، زمانِ پاسخ، تعدادِ درخواست‌ها و لاگِ خطاهای اخیر"),
            ("یادم بنداز <کار> [فردا/امروز ساعت N]", "ثبتِ یک کار/یادآوری"),
            ("کارهام چیه", "نمایشِ فهرستِ کارها"),
            ("کار N رو انجام دادم / حذف کن", "تکمیل یا حذفِ یک کار"),
            ("۱۰ کیلومتر به مایل", "تبدیلِ واحد (طول/وزن/دما)"),
            ("رمز عبور قوی بساز", "تولیدِ رمزِ عبورِ امن"),
            ("خرج کردم ۵۰ هزار تومان برای نهار", "ثبتِ یک خرج"),
            ("خلاصه‌ی خرج‌هام", "گزارشِ هزینه‌ها بر اساسِ دسته"),
            ("بی‌ام‌آی من چنده وزنم X قدم Y", "محاسبه‌ی BMI"),
            ("۲۳۴ ضربدر ۵۶ چند میشه", "ماشین‌حسابِ امن (محلی، بدونِ API)"),
            ("ترجمه کن سلام به انگلیسی", "ترجمه‌ی متن"),
            ("معنی کلمه سرندیپیتی", "معنیِ لغت (واژه‌یاب)"),
            ("سرچ / جستجو <موضوع>", "جستجویِ رایگان (ویکی‌پدیا، سپس DuckDuckGo)"),
            ("هوای تهران چطوره", "آب‌وهوایِ یک شهر"),
            ("قیمت دلار", "جستجویِ نرخِ ارز/طلا (وب)"),
            ("بخوان <مسیر فایل>", "خواندنِ محتوایِ فایل: PDF, Word, Excel, txt/py/json/csv/html/css/js/md, عکس"),
            ("این کد رو تحلیل/اصلاح کن", "بررسیِ کد و پیشنهادِ اصلاح (محلی)"),
            ("تحلیل پروژه [مسیر]", "اسکنِ ساختارِ یک پروژه‌ی کد"),
            ("چاپ(«سلام») / بگو(«...»)", "مفسرِ فارسی — اجرایِ کدِ فارسی (کاملاً محلی)"),
            ("علائم/دارو/بیماری...", "مشاوره‌ی پزشکیِ اولیه (محلی، Medical AI)"),
            ("یاد بگیر: <مطلب>", "افزودنِ یک واقعیت به حافظه‌ی بلندمدت"),
            ("یادت هست ...؟ / آخرین بار چی گفتم", "جستجو در حافظه/تاریخچه‌ی گفتگو"),
            ("اسمم چیه / نام من علی", "پرسیدن/تغییرِ نامِ کاربر"),
            ("پشتیبان‌گیری / بازیابی", "بکاپ‌گیری و بازگردانیِ کاملِ داده‌ها"),
            ("تحلیل احساسی", "درصدِ پرسش/جواب، درد دل، خوشحالی و احساساتِ گفتگویِ اخیر"),
            ("تاریخچه", "نمایش تاریخچه‌ی اخیرِ گفتگو"),
            ("پروژه‌ها", "فهرست پروژه‌ها/موضوعاتِ ذخیره‌شده"),
            ("پروژه جدید <نام>", "تغییر به / ساختِ یک پروژه"),
            ("گزارش", "خروجی‌گرفتنِ تاریخچه در قالب گزارش HTML"),
            ("شخصیت <نام>", "تغییر شخصیتِ دستیار"),
            ("راهنما", "نمایش دوباره‌ی همین راهنما"),
            ("📷 پیوستِ عکس (فقط در وب)", "توصیفِ عکس؛ با کپشنِ «متن...» → OCR، با «کیفیت...» → بهبودِ کیفیت"),
            ("📎 پیوستِ فایل (فقط در وب)", "همان «بخوان» بالا، اما با آپلودِ مستقیمِ فایل از دستگاهِ خودتان"),
            ("یه ویدیو از زیر آب بساز", "🎬 ساختِ صحنه‌ی ویدیوییِ متحرک (محلی، بدونِ API) — برایِ مثال‌هایِ بیشتر: «راهنمای ویدیو»"),
            ("دوربین رو نزدیک‌تر کن / نور رو کم کن", "🎬 اصلاحِ همان صحنه‌ی ویدیو (فقط بعد از ساختنِ یک صحنه)"),
            ("(متن آزاد)", "هر چیزی بپرسید — همه‌چیز کاملاً محلی یا با منابعِ رایگانِ وب است، بدونِ هیچ APIِ خارجی"),
        ]
        for cmd, desc in rows:
            table.add_row(reshape_fa(cmd), reshape_fa(desc))

        self.console.print(table)
        self.console.print(
            Text(
                "نکته: آزادانه و به فارسیِ روان بنویسید — دستیار جملات طبیعی را می‌فهمد.",
                style=MUTED,
            )
        )

    # ----------------------------------------------------------------
    #   نمایش پاسخ‌ها
    # ----------------------------------------------------------------
    def thinking(self, label: str = "در حال پردازش..."):
        """اسپینرِ یکدست برای عملیات ناهمگام (وب/فایل/ترجمه و ...)."""
        return self.console.status(f"[bold {ACCENT}]● {label}[/bold {ACCENT}]", spinner="dots")

    def stream_start(self, title: str = "", style: str = ACCENT):
        """
        شروعِ نمایشِ زنده‌ی یک پاسخِ در‌حالِ‌تولید، توکن‌به‌توکن (نه
        شبیه‌سازیِ حرف‌به‌حرفِ متنِ از‌قبل‌کاملِ animated_print).
        از rich.live.Live استفاده می‌کند تا هر بار که ``handle.update(text)``
        صدا زده شود، پنل بلافاصله به‌روز شود.

        نکته: این پروژه دیگر به هیچ APIِ مولدِ خارجی وصل نمی‌شود؛ در حالِ
        حاضر core.py این متد را صدا نمی‌زند (فقط برایِ سازگاریِ آینده
        نگه داشته شده).

        بازمی‌گرداند: یک ``_TerminalStreamHandle`` با متدهایِ
        ``update(full_text_so_far)`` و ``close()``.
        """
        return _TerminalStreamHandle(self.console, title or "پاسخ", style or ACCENT)

    async def animated_print(self, text: str, title: str = "", style: str = ACCENT, speed: float = 0.006):
        """
        پاسخ را در یک پنلِ تمیز نمایش می‌دهد؛ به‌جای چاپِ یک‌بارهٔ کل متن،
        یک جلوه‌ی «نمایش تدریجی» شبیه استریم‌شدنِ پاسخ اجرا می‌کند تا حس
        یک گفتگوی زنده منتقل شود.
        """
        shaped = reshape_fa(text)
        panel_title = title or "پاسخ"
        border = style if style else ACCENT

        # برای متن‌های خیلی طولانی، انیمیشن را برای جلوگیری از کندی رد کن
        animate = len(shaped) <= 1600

        if not animate:
            self.console.print(
                Panel(Markdown(shaped) if self._looks_markdown(shaped) else Text(shaped, style=INK),
                      title=f"[bold]{panel_title}[/bold]", border_style=border, box=ROUNDED, padding=(1, 2))
            )
            return

        from rich.live import Live

        revealed = ""
        with Live(console=self.console, refresh_per_second=30, transient=False) as live:
            for ch in shaped:
                revealed += ch
                live.update(
                    Panel(Text(revealed, style=INK), title=f"[bold]{panel_title}[/bold]",
                          border_style=border, box=ROUNDED, padding=(1, 2))
                )
                await asyncio.sleep(speed)

    @staticmethod
    def _looks_markdown(text: str) -> bool:
        return any(marker in text for marker in ("**", "\n•", "\n- ", "\n#"))

    def show_emergency(self, message: str):
        """پیام اورژانسی: قابِ متمایز و پرکنتراست تا فوراً توجه را جلب کند."""
        shaped = reshape_fa(message)
        self.console.print(Rule(style=DANGER))
        self.console.print(
            Panel(
                Text(shaped, style=f"bold {INK}"),
                title="[bold white on red] 🚨 اورژانسی [/bold white on red]",
                border_style=DANGER,
                box=HEAVY,
                padding=(1, 2),
            )
        )
        self.console.print(Rule(style=DANGER))

    def show_followup_question(self, question: str):
        """
        سؤال پیگیریِ بله/خیرِ موتور پزشکی: عمداً از پنل تشخیصِ کامل جدا و
        کوچک‌تر نمایش داده می‌شود تا کاربر بلافاصله متوجه شود باید پاسخ
        کوتاهی (بله/خیر) بدهد، نه منتظر یک گزارش کامل بماند.
        """
        shaped = reshape_fa(question)
        self.console.print(
            Panel(
                Text(shaped, style=f"bold {INK}"),
                title="[bold]🩺 سؤال پیگیری[/bold]",
                subtitle="[dim]پاسخ با «بله» یا «خیر»[/dim]",
                border_style=ACCENT_SOFT,
                box=ROUNDED,
                padding=(1, 2),
            )
        )

    # ----------------------------------------------------------------
    #   تصویر (vision.py): در ترمینال جایی برایِ نمایشِ واقعیِ عکس نیست،
    #   پس فقط مسیرِ فایل روی دیسک را نشان می‌دهیم -- امضایِ متد عیناً
    #   با GuiUIEngine.show_image یکی است تا core.py بدونِ شاخه‌زنیِ
    #   جداگانه برایِ هر رابط کار کند.
    # ----------------------------------------------------------------
    def show_image(self, url: str, title: str = "", caption: str = ""):
        shaped_caption = reshape_fa(caption) if caption else ""
        body = f"📁 فایل: {url}" + (f"\n{shaped_caption}" if shaped_caption else "")
        self.console.print(
            Panel(Text(body, style=INK), title=f"[bold]{title or '📷 تصویر'}[/bold]",
                  border_style=ACCENT_SOFT, box=ROUNDED, padding=(1, 2))
        )

    # ----------------------------------------------------------------
    #   صحنه‌ی ویدیویی (trx_ai/video/): در ترمینال جایی برایِ اجرایِ
    #   HTML/CSS/JS نیست، پس فقط مسیرِ فایل و مدت را نشان می‌دهیم --
    #   امضایِ متد عیناً با GuiUIEngine.show_scene یکی است (همان اصلی که
    #   بالاتر برایِ show_image توضیح داده شد) تا core_engine/tool_router.py
    #   بدونِ دانستنِ نوعِ رابطِ فعال، ``ai.ui.show_scene(...)`` را صدا بزند.
    # ----------------------------------------------------------------
    def show_scene(self, url: str, scene_id: str = "", title: str = "", duration: float = 0):
        body = f"📁 فایل: {url}\n🆔 شناسه: {scene_id}" + (f"\n⏱ مدت: {duration} ثانیه" if duration else "")
        body += "\n(برایِ دیدنِ صحنه‌ی متحرک، فایل را در مرورگر باز کنید.)"
        self.console.print(
            Panel(Text(body, style=INK), title=f"[bold]{title or '🎬 صحنه‌ی ویدیو'}[/bold]",
                  border_style=ACCENT_SOFT, box=ROUNDED, padding=(1, 2))
        )

    # ----------------------------------------------------------------
    #   تبدیل متن به گفتار (صدای نورالِ مایکروسافت - edge-tts)
    # ----------------------------------------------------------------
    def voice_prompt(self):
        """پرامپتِ «آیا صدا می‌خواهید؟» را نمایش می‌دهد."""
        self.console.print(
            f"\n[bold {ACCENT}]🔊 بشنوید پاسخ را؟ (۱: مرد | ۲: زن | اینتر: رد کردن): [/bold {ACCENT}]",
            end="",
        )

    def voice_generating(self):
        return self.console.status(f"[bold {ACCENT}]🗣️ در حال تولید صدا (صدای نورالِ مایکروسافت)...[/bold {ACCENT}]")

    def voice_saved(self, filepath: str):
        self.console.print(f"[bold {SUCCESS}]✓ فایل صوتی: {filepath}[/bold {SUCCESS}]")

    def voice_failed(self):
        self.console.print(f"[bold {DANGER}]❌ خطا در تولید صدا.[/bold {DANGER}]")
