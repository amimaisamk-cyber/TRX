# -*- coding: utf-8 -*-
"""
موتورِ تصویرِ سراسریِ پروژه (نه مخصوصِ بخشِ پزشکی): دریافتِ عکس از
کاربر، «دیدنِ» آن (توصیف/پاسخ به سؤال دربارهٔ محتوایِ آن)، استخراجِ
متنِ داخلِ آن، و بالابردنِ کیفیتش.

سه ابزارِ مستقل، هرکدام در یک متد:

    ImageEngine.save_incoming(...)      -- ذخیره‌یِ امنِ فایلِ ورودی
    ImageEngine.read_text(...)          -- «ابزارِ جداکردنِ متن» (OCR)
    ImageEngine.enhance_quality(...)    -- «ابزارِ زیادکردنِ کیفیت»
    ImageEngine.describe(...)           -- «ابزارِ خواندنِ/دیدنِ تصویر»
                                            (توصیفِ فنیِ محلی، توسطِ
                                            Vision Super)

این پروژه دیگر به هیچ APIِ مولدِ خارجی (Gemini یا مشابه) برایِ دیدنِ
عکس وصل نمی‌شود:
    - «ابزارِ جداکردنِ متن» (OCR) کاملاً محلی است: `pytesseract` (اختیاری
      -- نگاه کنید به dependencies.py). اگر نصب نباشد، صادقانه اعلام
      می‌شود که OCR در دسترس نیست، نه یک متنِ ساختگی.
    - «ابزارِ دیدنِ تصویر» از پایپ‌لاینِ محلیِ Vision Super (تحلیلِ فنی:
      نور/کنتراست/وضوح/رنگ) استفاده می‌کند -- یک تحلیلِ فنیِ واقعی، نه
      ادعایِ دروغینِ تشخیصِ معناییِ اشیاء که بدونِ یک مدلِ Vision واقعی
      امکان‌پذیر نیست.
"""

from __future__ import annotations

import base64
import mimetypes
import os
import re
import uuid
from typing import Optional

from .dependencies import CV2_AVAILABLE, OCR_AVAILABLE, PIL_AVAILABLE
from .logging_config import get_logger

logger = get_logger(__name__)

ALLOWED_MIME_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif", "image/bmp"}
MAX_IMAGE_BYTES = 15 * 1024 * 1024  # ۱۵ مگابایت -- سقفِ منطقی برایِ یک عکسِ موبایل


class ImageValidationError(ValueError):
    """ورودیِ نامعتبر (نوعِ فایل ناشناخته یا حجمِ بیش‌ازحد) -- پیامش مستقیم قابلِ‌نمایش به کاربر است."""


def _ext_for_mime(mime_type: str) -> str:
    ext = mimetypes.guess_extension(mime_type or "") or ".jpg"
    return ".jpg" if ext == ".jpe" else ext


class ImageEngine:
    """رابطِ سطح‌بالایِ ابزارهایِ تصویر؛ core.py فقط با همین کار می‌کند."""

    def __init__(self, files_dir: str):
        self.files_dir = files_dir
        os.makedirs(self.files_dir, exist_ok=True)

    # ------------------------------------------------------------
    #   ذخیره‌یِ امنِ فایلِ ورودی
    # ------------------------------------------------------------
    def save_incoming(self, raw_bytes: bytes, mime_type: str) -> str:
        """
        اعتبارسنجی + ذخیره؛ در صورتِ نامعتبربودن، `ImageValidationError`
        با پیامِ فارسیِ قابلِ‌نمایش می‌اندازد (نه یک AssertionError خام).
        خروجی: مسیرِ کاملِ فایلِ ذخیره‌شده رویِ دیسک.
        """
        if not raw_bytes:
            raise ImageValidationError("❌ فایلِ عکس خالی بود.")
        if len(raw_bytes) > MAX_IMAGE_BYTES:
            mb = MAX_IMAGE_BYTES // (1024 * 1024)
            raise ImageValidationError(f"❌ حجمِ عکس بیش از حدِ مجاز است (حداکثر {mb} مگابایت).")
        if mime_type not in ALLOWED_MIME_TYPES:
            raise ImageValidationError(f"❌ نوعِ فایل «{mime_type}» پشتیبانی نمی‌شود (فقط عکس: jpg/png/webp/gif/bmp).")

        name = f"{uuid.uuid4().hex}{_ext_for_mime(mime_type)}"
        path = os.path.join(self.files_dir, name)
        with open(path, "wb") as f:
            f.write(raw_bytes)
        return path

    # ------------------------------------------------------------
    #   ابزارِ جداکردنِ متن (OCR)
    # ------------------------------------------------------------
    async def read_text(self, image_path: str, session=None) -> str:
        """
        OCR کاملاً محلی با pytesseract. اگر Tesseract نصب نبود، صادقانه
        می‌گوید که OCR در دسترس نیست (نه یک متنِ ساختگی). ``session``
        فقط برایِ سازگاریِ امضایِ متد با core.py نگه داشته شده -- دیگر
        استفاده نمی‌شود چون هیچ فراخوانیِ شبکه‌ای در این مسیر نیست.
        """
        local_text = self._read_text_local(image_path)
        if local_text is not None:
            return local_text if local_text.strip() else "📭 متنی در این عکس پیدا نشد."

        return (
            "❌ OCR در حالِ حاضر فعال نیست.\n"
            "نصبِ pytesseract + موتورِ Tesseract-OCR (و در صورتِ نیاز زبانِ فارسی) لازم است."
        )

    def _read_text_local(self, image_path: str) -> Optional[str]:
        if not OCR_AVAILABLE:
            return None
        try:
            import pytesseract
            from PIL import Image

            # Pydroid/Android does not install the Tesseract binary through pip.
            # Probe a few common executable locations before calling it.
            try:
                import shutil
                exe = shutil.which("tesseract")
                if exe:
                    pytesseract.pytesseract.tesseract_cmd = exe
                else:
                    for candidate in (
                        "/data/data/ru.iiec.pydroid3/files/usr/bin/tesseract",
                        "/data/data/com.termux/files/usr/bin/tesseract",
                        "/usr/bin/tesseract",
                    ):
                        if os.path.isfile(candidate):
                            pytesseract.pytesseract.tesseract_cmd = candidate
                            break
            except Exception as e:
                logger.debug("پیداکردنِ باینریِ tesseract شکست خورد: %s", e)

            image = Image.open(image_path)
            # --- ارتقاء: پیش‌پردازشِ محلی برایِ جبرانِ نبودِ Gemini Vision ---
            # قبلاً Gemini Vision دقتِ بالاتری برایِ عکس‌هایِ کج/کم‌نور/
            # کم‌کنتراست داشت. حالا که این مسیر کاملاً محلی است، قبل از
            # OCR یک پیش‌پردازشِ سبک (سیاه‌وسفید + افزایشِ کنتراست +
            # threshold تطبیقی با OpenCV، اگر نصب باشد) اجرا می‌شود تا
            # نرخِ موفقیتِ pytesseract روی عکس‌هایِ واقعیِ موبایل بالاتر برود.
            preprocessed = self._preprocess_for_ocr(image) or image
            try:
                text = pytesseract.image_to_string(preprocessed, lang="fas+eng")
            except Exception as first_error:
                logger.info("OCR فارسی در دسترس نبود؛ تلاش انگلیسی: %s", first_error)
                try:
                    text = pytesseract.image_to_string(preprocessed, lang="eng")
                except Exception as second_error:
                    logger.warning("OCR محلی شکست خورد: %s", second_error)
                    return None

            # اگر پیش‌پردازش‌شده نتیجه‌ی ضعیفی داد، یک‌بار هم رویِ عکسِ
            # خامِ اصلی امتحان می‌کنیم (بعضی عکس‌ها با threshold بدتر می‌شوند).
            if not text or not text.strip():
                try:
                    text = pytesseract.image_to_string(image, lang="fas+eng")
                except Exception as e:
                    logger.debug("OCRِ محلی روی عکسِ خام هم شکست خورد: %s", e)
            return text
        except Exception as e:  # noqa: BLE001
            logger.warning("OCR محلی شکست خورد: %s", e)
            return None

    @staticmethod
    def _preprocess_for_ocr(image):
        """سیاه‌وسفید + افزایشِ کنتراست + threshold تطبیقی، برایِ دقتِ بهترِ OCR محلی.

        فقط اگر OpenCV نصب باشد اجرا می‌شود؛ در غیرِاین‌صورت ``None``
        برمی‌گرداند تا ``_read_text_local`` مستقیماً رویِ عکسِ خام کار کند.
        """
        if not CV2_AVAILABLE:
            return None
        try:
            import cv2
            import numpy as np
            from PIL import Image

            rgb = np.array(image.convert("RGB"))
            gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
            gray = cv2.bilateralFilter(gray, 7, 50, 50)
            thresh = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 11
            )
            return Image.fromarray(thresh)
        except Exception as e:  # noqa: BLE001
            logger.debug("پیش‌پردازشِ OCR محلی شکست خورد، رویِ عکسِ خام ادامه می‌دهیم: %s", e)
            return None

    # ------------------------------------------------------------
    #   ابزارِ زیادکردنِ کیفیت (کاملاً محلی، بدونِ نیاز به اینترنت)
    # ------------------------------------------------------------
    # عکسِ بزرگ‌تر از این عرض را دیگر بزرگ‌نمایی نمی‌کنیم -- بزرگ‌نماییِ
    # یک عکسِ از قبل بزرگ (مثلِ خروجیِ معمولِ دوربینِ موبایل، ۳۰۰۰+ پیکسل)
    # هیچ جزئیاتِ واقعی اضافه نمی‌کند، فقط فایل را بزرگ‌تر می‌کند --
    # نتیجه: کاربر هیچ بهبودِ محسوسی نمی‌بیند (باگی که واقعاً گزارش شد).
    UPSCALE_MAX_WIDTH = 900

    # میانگینِ روشناییِ کانالِ grayscale (۰ تا ۲۵۵) که زیرِ آن عکس
    # «کم‌نور» در نظر گرفته می‌شود -- عکسِ کم‌نور معمولاً نویزِ سنسورِ
    # دوربین در آن بیشتر است (خصوصاً موبایل)، پس denoiseِ قوی‌تری لازم
    # دارد؛ وگرنه شارپ‌کردن همان نویز را هم "تیزتر" نشان می‌دهد.
    LOW_LIGHT_BRIGHTNESS_THRESHOLD = 90

    def _is_low_light(self, img) -> bool:
        """میانگینِ روشناییِ عکس را حساب می‌کند (بدونِ نیاز به numpy)."""
        from PIL import ImageStat

        stat = ImageStat.Stat(img.convert("L"))
        return stat.mean[0] < self.LOW_LIGHT_BRIGHTNESS_THRESHOLD

    def enhance_quality(self, image_path: str, scale: float = 2.0) -> tuple:
        """
        نقطه‌ی ورودِ عمومیِ «ابزارِ زیادکردنِ کیفیت».

        دو backend، هر دو در نهایت یک نمره‌ی ۰-۱۰۰ هم برمی‌گردانند (نه
        فقط ادعا) تا فراخوان (core.py) بتواند به‌جایِ حدس، عددِ واقعیِ
        بهبود را نشان دهد:

            CV2_AVAILABLE=True  (دسکتاپ/سرور، نه Pydroid -- نگاه کنید به
                dependencies.py): یک پاسِ قویِ fastNlMeansDenoisingColored
                + CLAHE، بدونِ چرخه (چون این الگوریتم خودش از اول قوی
                است و معمولاً نیازی به تکرار ندارد).

            CV2_AVAILABLE=False (مسیرِ پیش‌فرض/پشتیبانی‌شده، رویِ Pydroid
                هم کار می‌کند): ``trx_ai.image_quality.ImageEnhancementPipeline``
                -- یک حلقه‌ی «بسنج -> اجرا کن -> ارزیابی کن -> اگر به
                ۹۰٪ نرسید، پارامترها را اصلاح کن و دوباره تلاش کن» تا
                سقفِ ۴ تلاش. سه بازویِ آن (Analyzer/Executor/Evaluator)
                کاملاً مستقل‌اند؛ نگاه کنید به trx_ai/image_quality/.

        خروجی: ``(out_path, before_size, after_size, score_info)`` --
        ``score_info`` یک دیکشنری با کلیدهایِ ``score``/``iterations``/
        ``reached_target`` است (یا ``None`` اگر به هر دلیلی نمره‌گیری
        ممکن نبود).
        """
        if not PIL_AVAILABLE:
            raise RuntimeError(
                "❌ کتابخانه‌ی Pillow نصب نیست؛ ابزارِ بهبودِ کیفیت در دسترس نیست."
            )

        try:
            return self._enhance_quality_vision_super(image_path)
        except Exception as e:  # noqa: BLE001 -- بخشِ ۱۳۶ (Failure Isolation): یک خرابی
            # در سیستمِ جدید نباید کلِ ابزار را از کار بیندازد، بلکه به
            # مسیرِ قدیمیِ ساده‌ترِ pipeline.py برمی‌گردد.
            logger.warning("VISION SUPER SYSTEM شکست خورد، بازگشت به pipelineِ قدیمی: %s", e)

        if CV2_AVAILABLE:
            out_path, before_size, after_size = self._enhance_quality_cv2(image_path, scale)
            score_info = self._score_result(image_path, out_path)
            return out_path, before_size, after_size, score_info

        from .image_quality import ImageEnhancementPipeline

        result = ImageEnhancementPipeline().run(image_path, self.files_dir, scale)
        for line in result.log:
            logger.info("بهبودِ کیفیت -- %s", line)
        score_info = {
            "score": result.score,
            "iterations": result.iterations_used,
            "reached_target": result.reached_target,
        }
        return result.out_path, result.before_size, result.after_size, score_info

    def _enhance_quality_vision_super(self, image_path: str) -> tuple:
        """
        مسیرِ اصلی -- VISION SUPER SYSTEM (نگاه کنید به trx_ai/vision_super/).

        Perception -> Vision Brain -> Analyzer -> Commander (چند Planِ
        کاندید) -> Specialist Arms -> Quality Judge -> Version Manager
        -> Memory. صادقانه: هیچ مدلِ Neural اجرا نمی‌شود (این محیط
        وزنِ مدلِ آموزش‌دیده یا دسترسیِ اینترنتی برایِ دانلودش ندارد)؛
        همه‌ی Armها الگوریتمِ کلاسیکِ واقعی‌اند (نگاه کنید به
        ``vision_super.contracts.STATUS_CLASSICAL``).
        """
        from PIL import Image

        from .vision_super import VisionOrchestrator

        with Image.open(image_path) as img:
            before_size = img.size
            rgb = img.convert("RGB")
            orchestrator = VisionOrchestrator(self.files_dir)
            base, ext = os.path.splitext(os.path.basename(image_path))
            out_path = os.path.join(self.files_dir, f"{base}_enhanced.png")
            final_img, report = orchestrator.restore(rgb, out_path)
            after_size = final_img.size

        for line in report.log:
            logger.info("VISION SUPER -- %s", line)
        logger.info("VISION SUPER REPORT:\n%s", report.to_text())

        score_info = {
            "score": report.quality_after,
            "iterations": report.rounds,
            "reached_target": report.reached_target,
            "report": report.as_dict(),
        }
        return out_path, before_size, after_size, score_info

    def _score_result(self, original_path: str, enhanced_path: str) -> Optional[dict]:
        """نمره‌دهیِ یک‌باره به خروجیِ مسیرِ cv2 با همان Evaluatorِ pipelineِ Pillow."""
        try:
            from PIL import Image

            from .image_quality import ImageEvaluator

            with Image.open(original_path) as o, Image.open(enhanced_path) as e:
                score, _ = ImageEvaluator().score(o.convert("RGB"), e.convert("RGB"))
            return {"score": score, "iterations": 1, "reached_target": score >= 90.0}
        except Exception as ex:  # noqa: BLE001 -- نمره‌دهی هرگز نباید کلِ ابزار را خراب کند
            logger.warning("نمره‌دهیِ کیفیت شکست خورد: %s", ex)
            return None

    def _enhance_quality_cv2(self, image_path: str, scale: float = 2.0) -> tuple:
        """
        مسیرِ اختیاریِ قوی‌تر -- فقط وقتی cv2 نصب باشد (دسکتاپ/سرور، نه
        Pydroid). denoiseِ کلاسیکِ fastNlMeansDenoisingColored محسوساً
        نویزِ رنگیِ ISOِ بالا (مثلِ عکسِ شب) را بهتر از فیلترهایِ Pillow
        پاک می‌کند؛ CLAHE هم سایه‌ها را بدونِ سوزوندنِ نورها روشن می‌کند.

        توجه: این یک الگوریتمِ کلاسیک است، نه یک مدلِ مولدِ هوشِ مصنوعی --
        نویزِ واقعی را پاک می‌کند اما جزئیاتِ ازدست‌رفته را «حدس» نمی‌زند؛
        برایِ عکسِ خیلی نویزی نتیجه واضح‌تر و تمیزتر می‌شود، نه معجزه‌آسا.
        """
        import cv2
        import numpy as np
        from PIL import Image

        with Image.open(image_path) as pil_img:
            pil_img = pil_img.convert("RGB")
            before_size = pil_img.size
            low_light = self._is_low_light(pil_img)
            img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        # شدتِ denoise بر اساسِ کم‌نور بودنِ عکس -- تاریکی معمولاً یعنی
        # ISOِ دوربین بالاتر رفته و نویزِ رنگی بیشتر است.
        h = 18 if low_light else 8
        denoised = cv2.fastNlMeansDenoisingColored(
            img, None, h=h, hColor=h, templateWindowSize=7, searchWindowSize=21
        )

        # CLAHE رویِ کانالِ L (فضایِ LAB) -- روشن‌کردنِ سایه‌ها بدونِ اینکه
        # نویزِ جدید اضافه شود یا نورهایِ روشن (مثلِ ماه/چراغ) بسوزند.
        lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
        l_channel, a_channel, b_channel = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8))
        l_channel = clahe.apply(l_channel)
        contrasted = cv2.cvtColor(cv2.merge((l_channel, a_channel, b_channel)), cv2.COLOR_LAB2BGR)

        if before_size[0] < self.UPSCALE_MAX_WIDTH:
            scale = max(1.5, min(scale, 4.0))
            new_size = (int(before_size[0] * scale), int(before_size[1] * scale))
            contrasted = cv2.resize(contrasted, new_size, interpolation=cv2.INTER_LANCZOS4)

        # شارپ‌کردنِ نهایی با unsharp mask
        blurred = cv2.GaussianBlur(contrasted, (0, 0), sigmaX=2)
        sharpened = cv2.addWeighted(contrasted, 1.3, blurred, -0.3, 0)

        base, _ = os.path.splitext(os.path.basename(image_path))
        out_name = f"{base}_enhanced.jpg"
        out_path = os.path.join(self.files_dir, out_name)
        cv2.imwrite(out_path, sharpened, [cv2.IMWRITE_JPEG_QUALITY, 95])
        after_size = (sharpened.shape[1], sharpened.shape[0])
        return out_path, before_size, after_size

    # ------------------------------------------------------------
    #   ابزارِ خواندنِ/دیدنِ تصویر (توصیف یا پاسخ به سؤالِ کاربر)
    # ------------------------------------------------------------
    async def describe(self, image_path: str, question: str, session=None) -> str:
        """توصیفِ کاملاً محلیِ تصویر با پایپ‌لاینِ Vision Super.

        این یک تحلیلِ فنیِ واقعی است (ابعاد/نوع/نور/شارپنس + هر متنِ
        قابلِ‌خواندنِ داخلِ عکس با OCR محلی)، نه ادعایِ دروغینِ تشخیصِ
        معناییِ اشخاص/اشیا/صحنه که بدونِ یک مدلِ Vision واقعی امکان‌پذیر
        نیست. ``session`` فقط برایِ سازگاریِ امضایِ متد با core.py نگه
        داشته شده و استفاده نمی‌شود.
        """
        try:
            from PIL import Image
            from .vision_super import VisionOrchestrator

            with Image.open(image_path) as img:
                state, report = VisionOrchestrator(self.files_dir).analyze_only(img.convert("RGB"))
                p = state.perception
                question_text = question.strip()
                header = "📷👁️ تحلیلِ محلیِ تصویر (بدون هیچ APIِ خارجی)"
                if question_text:
                    header += f"\nسؤال: {question_text}"

                # --- ارتقاء: OCR محلی به‌عنوانِ زمینه‌ی اضافه ---
                # قبلاً Gemini Vision با یک فراخوانیِ واحد هم صحنه را
                # توصیف می‌کرد هم هر متنِ داخلش را می‌خواند. حالا که این
                # مسیر کاملاً محلی است، اگر عکس متنی داشته باشد (مثلاً
                # اسکرین‌شات یا تابلو)، همان OCR محلی به‌عنوانِ بخشِ
                # تکمیلیِ توصیف اضافه می‌شود تا این قابلیت از دست نرود.
                ocr_snippet = None
                try:
                    ocr_text = self._read_text_local(image_path)
                    if ocr_text and ocr_text.strip():
                        ocr_snippet = ocr_text.strip()[:500]
                except Exception as e:
                    logger.debug("افزودنِ OCRِ محلی به گزارشِ توصیفِ عکس شکست خورد: %s", e)

                parts = [
                    header,
                    "",
                    f"ابعاد: {p.width}×{p.height}",
                    f"نوعِ تشخیص‌داده‌شده: {', '.join(state.image_types) or 'نامشخص'}",
                    f"روشنایی: {p.brightness:.1f}",
                    f"شارپنس: {p.sharpness:.1f}",
                    "",
                    report,
                ]
                if ocr_snippet:
                    parts += ["", f"📝 متنِ خوانده‌شده از داخلِ عکس:\n{ocr_snippet}"]
                return "\n".join(parts)
        except Exception as e:  # noqa: BLE001
            logger.warning("تحلیلِ محلیِ تصویر شکست خورد: %s", e)
            return "❌ تحلیلِ محلیِ تصویر شکست خورد. فایلِ تصویر یا وابستگی‌های پردازش تصویر را بررسی کنید."


# ------------------------------------------------------------
#   کمکی: تشخیصِ نیتِ کاربر از رویِ کپشنِ همراهِ عکس
# ------------------------------------------------------------
_TEXT_INTENT_RE = re.compile(r'متن|بخون|OCR|استخراج', re.IGNORECASE)
_QUALITY_INTENT_RE = re.compile(r'کیفیت|واضح|شارپ|بزرگ.?ترش|رزولوشن')


def classify_image_caption(caption: str) -> str:
    """خروجی: 'text' | 'quality' | 'describe' (پیش‌فرض)."""
    caption = caption or ""
    if _TEXT_INTENT_RE.search(caption):
        return "text"
    if _QUALITY_INTENT_RE.search(caption):
        return "quality"
    return "describe"


def image_to_base64(image_path: str) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


def guess_mime(image_path: str) -> str:
    mime, _ = mimetypes.guess_type(image_path)
    return mime or "image/jpeg"
