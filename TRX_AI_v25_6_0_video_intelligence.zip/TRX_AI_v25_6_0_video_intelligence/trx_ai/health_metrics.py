# -*- coding: utf-8 -*-
"""
محاسبه‌گرِ شاخص‌های سلامتی (BMI، وزنِ ایده‌آل، نیازِ روزانه‌ی کالری).

این ماژول عمداً از medical.py جداست: medical.py برای «تشخیصِ افتراقیِ
علائم» است (چه بیماری‌ای شبیهِ علائمِ من است)، این ماژول برای «محاسبه‌ی
یک عددِ مشخص از رویِ قد/وزن/سن» است — دو کارِ متفاوت با دو نوع منطق.

فرمول‌ها:
    BMI = وزن(kg) / قد(m)^2   — استانداردِ WHO
    نیازِ کالری = فرمولِ Mifflin-St Jeor (دقیق‌تر از Harris-Benedictِ قدیمی)
"""

from __future__ import annotations

import re
from typing import Optional

from .text_normalize import normalize_text as _normalize_text

_ACTIVITY_MULTIPLIERS = {
    "کم تحرک": 1.2, "بی تحرک": 1.2, "sedentary": 1.2,
    "کم": 1.375, "سبک": 1.375, "light": 1.375,
    "متوسط": 1.55, "moderate": 1.55,
    "زیاد": 1.725, "سنگین": 1.725, "active": 1.725,
    "خیلی زیاد": 1.9, "very active": 1.9,
}


def calculate_bmi(weight_kg: float, height_cm: float) -> dict:
    """
    شاخصِ توده‌ی بدنی (BMI) و رده‌بندیِ آن طبقِ استانداردِ WHO را
    برمی‌گرداند.
    """
    if weight_kg <= 0 or height_cm <= 0:
        raise ValueError("قد و وزن باید عددِ مثبت باشند")
    height_m = height_cm / 100
    bmi = weight_kg / (height_m ** 2)

    if bmi < 18.5:
        category = "کمبودِ وزن"
    elif bmi < 25:
        category = "وزنِ طبیعی"
    elif bmi < 30:
        category = "اضافه‌وزن"
    else:
        category = "چاقی"

    ideal_min = 18.5 * (height_m ** 2)
    ideal_max = 24.9 * (height_m ** 2)

    return {
        "bmi": round(bmi, 1),
        "category": category,
        "ideal_weight_range": (round(ideal_min, 1), round(ideal_max, 1)),
    }


def calculate_daily_calories(weight_kg: float, height_cm: float, age: int,
                              gender: str, activity: str = "متوسط") -> dict:
    """
    نیازِ کالریِ روزانه با فرمولِ Mifflin-St Jeor: ابتدا BMR (متابولیسمِ
    پایه) سپس ضربدرِ ضریبِ فعالیت.
    """
    if weight_kg <= 0 or height_cm <= 0 or age <= 0:
        raise ValueError("قد، وزن و سن باید عددِ مثبت باشند")

    is_male = gender.strip() in ("مرد", "آقا", "male", "m")
    bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age + (5 if is_male else -161)

    multiplier = _ACTIVITY_MULTIPLIERS.get(activity.strip().lower(), 1.55)
    daily_calories = bmr * multiplier

    return {
        "bmr": round(bmr),
        "daily_calories": round(daily_calories),
        "weight_loss_calories": round(daily_calories - 500),   # کاهشِ ~۰.۵ کیلو در هفته
        "weight_gain_calories": round(daily_calories + 500),
    }


def _extract_number(text: str, keyword_patterns) -> Optional[float]:
    for pattern in keyword_patterns:
        match = re.search(pattern, text)
        if match:
            return float(match.group(1))
    return None


def format_bmi_response(text: str) -> str:
    """
    یک جمله‌ی آزاد مثلِ «قدم ۱۷۵ وزنم ۷۰ است bmi چقدره» را تجزیه و
    گزارشِ BMI را برمی‌گرداند.
    """
    t = _normalize_text(text)

    height = _extract_number(t, [r'قد[می]?\s*(?:من)?\s*(\d+(?:\.\d+)?)', r'(\d+(?:\.\d+)?)\s*سانتی\s*متر'])
    weight = _extract_number(t, [r'وزن[می]?\s*(?:من)?\s*(\d+(?:\.\d+)?)', r'(\d+(?:\.\d+)?)\s*کیلو(?:گرم)?'])

    if height is None or weight is None:
        return (
            "❌ برای محاسبه‌ی BMI به قد و وزن نیاز دارم. مثال: "
            "«قدم ۱۷۵ وزنم ۷۰ است bmi چقدره»"
        )

    # اگر قد به‌اشتباه به متر شبیه بود (زیرِ ۳)، به سانتی‌متر تبدیلش کن
    if height < 3:
        height *= 100

    try:
        result = calculate_bmi(weight, height)
    except ValueError as e:
        return f"❌ {e}"

    low, high = result["ideal_weight_range"]
    return (
        f"⚖️ **شاخصِ توده‌ی بدنی (BMI):** {result['bmi']} — {result['category']}\n\n"
        f"📏 محدوده‌ی وزنِ ایده‌آل برای قدِ {height:g} سانتی‌متر: {low} تا {high} کیلوگرم\n\n"
        f"ℹ️ BMI فقط یک شاخصِ کلی است و عضله/چربی را جدا نمی‌کند؛ برایِ ارزیابیِ دقیق‌تر با پزشک مشورت کنید."
    )
