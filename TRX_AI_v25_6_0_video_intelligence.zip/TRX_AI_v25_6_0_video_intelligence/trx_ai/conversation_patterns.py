# -*- coding: utf-8 -*-
"""TRX AI Conversation Pattern Engine v2 (+ لایه‌ی معنایی اختیاری).

The engine learns interaction patterns from multi-turn conversations rather than
memorising isolated phrases. Retrieval was originally a purely lexical/keyword
scorer (``score()``); it is deliberately still dependency-free by default so it
remains usable on Android/Pydroid without sentence-transformers installed.

اگر ``sentence-transformers`` نصب باشد (``trx_ai.embedding_backend`` -- همان
مدلِ محلیِ به‌اشتراک‌گذاشته‌شده با NLU و حافظه‌ی برداری)، هر گفته‌ی کاربر و هر
الگویِ چندنوبتی به یک بردارِ عددی (embedding) هم تبدیل می‌شود و در کنارِ
امتیازِ لغویِ قبلی، شباهتِ *معنایی* هم در بازیابی و رتبه‌بندیِ الگوها اثر
می‌گذارد -- یعنی الگوهایی که واقعاً هم‌معنیِ پیامِ فعلی‌اند (نه فقط
هم‌کلمه) هم پیدا می‌شوند، و بازیابیِ سبکِ گفتارِ کاربر از کلِ تاریخچه (نه
فقط N پیامِ آخر) بر اساسِ نزدیکیِ معنایی انجام می‌شود. بدونِ این پکیج،
رفتار دقیقاً همان نسخه‌ی قبلی (فقط لغوی) می‌ماند -- هیچ رگرسیونی رخ
نمی‌دهد.

## افزوده‌یِ این نسخه (v3): امضا، اطمینان، زمینه و توالی

چهار قابلیتِ افزوده، همه اختیاری/محافظه‌کارانه و بدونِ تغییرِ رفتارِ
پیش‌فرض در نبودِ داده‌یِ کافی:

- **Context Embedding** (``context_emb``): علاوه بر embeddingِ خودِ
  آخرین جمله، یک embeddingِ دوم از *زمینه*‌یِ چند نوبتِ اخیر هم ذخیره
  می‌شود -- برایِ جمله‌هایِ کوتاه/گنگ («باشه، پس چیکار کنم؟») که فقط در
  کنارِ نوبت‌هایِ قبلی معنا پیدا می‌کنند.
- **Pattern Signature** (``signature``): یک اثرِ انگشتِ فشرده و قطعی از
  نوع/احساس/نیاز/کنش/موضوع؛ برایِ تشخیصِ سریعِ «این رفتار قبلاً از این
  کاربر دیده شده» بدونِ محاسبه‌یِ دوباره‌یِ امتیازِ کامل.
- **Confidence** (``confidence``): اطمینانِ برچسب‌گذاری -- ترکیبِ فاصله‌یِ
  رقیبِ اول و دوم در امتیازدهیِ کلیدواژه‌ای با تکرارِ تاریخیِ همان امضا.
  یک جمله‌یِ مبهم با یک کلیدواژه‌یِ ضعیف اطمینانِ پایین می‌گیرد و در
  ``prompt_context`` صادقانه به‌عنوانِ حدس علامت‌گذاری می‌شود، نه دانشِ
  قطعی.
- **Sequence Matching** (``act_sequence`` / ``sequence_similarity``):
  شباهتِ *ترتیبی* توالیِ کنش‌هایِ گفتاری (نه فقط شباهتِ یک پیامِ تکی) با
  ``difflib.SequenceMatcher`` -- تشخیصِ اینکه روندِ کلیِ گفتگویِ جاری با
  یک الگویِ قبلی یکسان است، حتی اگر کلماتِ هر نوبت فرق کند.

هر چهار مورد کاملاً افزوده‌اند: فیلدهایِ قدیمی/دیتایِ ذخیره‌شده‌یِ قبل از
این نسخه بدونِ این کلیدها می‌مانند و ``.get(..., default)`` در همه‌جا
تضمین می‌کند که نبودِ آن‌ها خطا ایجاد نکند.
"""

from __future__ import annotations

import difflib
import json
import math
import random
import re
from collections import Counter
from datetime import datetime
from typing import Dict, List, Optional

# لایه‌ی معنایی -- کاملاً اختیاری و افزوده (رجوع به توضیحِ کلاس در پایین:
# «سازگاریِ محلیِ برنامه بدونِ این ماژول تغییر نمی‌کند»). خودِ import هرگز
# fail نمی‌شود چون embedding_backend.py هم دقیقاً به همین فلسفه ساخته شده --
# بدونِ sentence-transformers نصب‌شده، is_available() فقط False برمی‌گرداند.
from . import embedding_backend as _semantic_backend
from .nlu.matchers.keyword import phrase_in_text


# حداکثر طولِ «اضافه»ای که یک کلمه می‌تواند نسبت به کلمه‌ی دیگر داشته
# باشد تا هنوز «همان کلمه با یک پسوندِ صرفیِ کوتاه» حساب شود، نه یک
# کلمه‌ی کاملاً متفاوتِ ترکیبی/مشتقه (رجوع به توضیحِ کاملِ استفاده در
# ``ConversationPatternEngine.score``).
_MAX_INFLECTION_SUFFIX_LEN = 2


def _is_short_inflection(a: str, b: str) -> bool:
    shorter, longer = (a, b) if len(a) <= len(b) else (b, a)
    if shorter == longer:
        return True
    return longer.startswith(shorter) and (len(longer) - len(shorter)) <= _MAX_INFLECTION_SUFFIX_LEN


class ConversationPatternEngine:
    KEY = "memory:conversation_patterns_v2"
    # v5 راهنما: پیکره‌ی Bootstrap از ~۱۷۳ به ~۴۶۰+ الگو رسید (سندِ
    # درخواستِ کاربر برای پوششِ گسترده‌ترِ مکالماتِ روزمره)؛ اگر
    # MAX_PATTERNS همان ۳۲۰ قبلی می‌ماند، self.patterns[-MAX_PATTERNS:]
    # همان ابتدا بخشی از الگوهایِ جدید (یا حتی الگوهایِ واقعاً یادگرفته‌شده
    # از کاربر) را حذف می‌کرد. عدد جدید فضایِ کافی برایِ کلِ Bootstrap +
    # رشدِ واقعیِ الگوهایِ کاربر می‌گذارد.
    MAX_PATTERNS = 900
    MAX_UTTERANCE_PATTERNS = 1000
    WINDOW_TURNS = 14
    BOOTSTRAP_VERSION = "v5_broad_460"
    BOOTSTRAP_KEY = "memory:conversation_patterns_bootstrap"

    EMOTION_CUES = {
        "sad": ["ناراحتم", "غمگین", "دلم گرفته", "حالم بده", "تنها", "گریه", "دلگیر", "خسته ام", "خسته‌ام", "خسته شدم", "خسته شده‌ام", "خیلی خسته", "دلم شکست", "بی حوصله", "بی‌حوصله"],
        "happy": ["خوشحالم", "خیلی خوب", "عالیه", "عالی", "ذوق", "خوشحال", "حال خوب", "کیف کردم", "راضیم"],
        "angry": ["عصبانی", "حرصم", "اعصابم", "متنفرم", "کلافه", "عصبانی‌ام", "عصبانی ام", "رو مخم"],
        "anxious": ["نگران", "استرس", "می‌ترسم", "میترسم", "نگرانم", "استرس دارم", "نمی‌دونم چی کار کنم", "دلشوره"],
        "grateful": ["ممنون", "مرسی", "دمت گرم", "تشکر", "لطف کردی", "خیلی ممنون"],
        "confused": ["نمی‌فهمم", "نمیفهمم", "گیج", "متوجه نمی‌شم", "متوجه نمیشم", "چرا اینطوری", "نفهمیدم"],
        "excited": ["بزن بریم", "ترکوندیم", "خفن", "محشر", "خیلی باحاله", "هیجان زده", "هیجان‌زده", "وای چه خوب"],
        "hopeful": ["امیدوارم", "درست میشه", "می‌خوام بهتر", "امید دارم", "شاید بشه"],
    }

    TYPE_CUES = {
        "venting": ["دلم گرفته", "ناراحتم", "حالم بده", "درد دل", "کلافه", "خسته‌ام", "خسته ام", "خسته شدم", "خیلی خسته", "نمی‌کشم"],
        "celebration": ["موفق شدم", "قبول شدم", "بردم", "عالی شد", "خوشحالم", "انجامش دادم", "بالاخره شد"],
        "technical": ["کد", "پروژه", "پایتون", "api", "باگ", "خطا", "سرور", "کتابخانه", "ماژول", "zip"],
        "planning": ["برنامه", "برنامه‌ریزی", "چطور انجام", "مراحل", "می‌خوام بسازم", "میخوام بسازم", "قدم بعدی"],
        "storytelling": ["امروز", "دیروز", "یادمه", "وقتی", "یه بار", "داشتم", "رفتم", "بعدش"],
        "question": ["؟", "چیست", "چیه", "چرا", "چطور", "چگونه", "آیا", "کیه", "کجاست", "چند"],
        "casual": ["سلام", "خوبی", "چه خبر", "چیکار می‌کنی", "حالت چطوره", "مرسی", "داداش"],
        "learning": ["یاد بگیر", "یاد بگیرم", "یادگیری", "درس", "امتحان", "تمرین", "توضیح بده"],
        "creative": ["داستان", "ایده", "اسم خفن", "طراحی", "بساز", "خلق", "نویس"],
        "relationships": ["دوستم", "دوست", "خانواده", "رابطه", "سوءتفاهم", "پیام صمیمی"],
    }

    ACT_CUES = {
        "request": ["می‌خوام", "میخوام", "میشه", "لطفاً", "کمکم کن", "بکن", "برام", "بفرست"],
        "question": ["؟", "چرا", "چطور", "چگونه", "آیا", "چی", "کجاست", "کی"],
        # «امروز» (صرفاً قیدِ زمان) و «من» (صرفاً ضمیر) عمداً از اینجا
        # حذف شدند -- به‌اندازه‌ای عمومی‌اند که تقریباً هر جمله‌ی
        # فارسیِ اول‌شخص (حتی یک سؤالِ کاملاً بی‌ربط مثلِ «هوای امروز
        # تهران چطوره») را هم «sharing» می‌زدند، بدونِ اینکه واقعاً
        # نشانه‌ای از روایت/تعریفِ شخصی باشند -- برخلافِ بقیه‌ی
        # عبارت‌هایِ این لیست («دلم»، «حالم»، «اتفاق افتاد») که واقعاً
        # به لحنِ روایتِ شخصی اشاره دارند.
        "sharing": ["دلم", "حالم", "داشتم", "رفتم", "اتفاق افتاد"],
        "gratitude": ["ممنون", "مرسی", "دمت گرم", "تشکر"],
        "agreement": ["آره", "بله", "درسته", "اوکی", "باشه", "قبوله"],
        "disagreement": ["نه", "اشتباهه", "اینطور نیست", "قبول ندارم"],
        "continuation": ["خب", "حالا", "بعدش", "ادامه", "پس", "خوب"],
    }

    NEED_CUES = {
        "emotional_support": ["درد دل", "ناراحتم", "دلم گرفته", "حالم بده", "تنها", "خسته‌ام", "خسته ام", "خسته شدم", "خیلی خسته", "دوستم سرد", "گریه"],
        "encouragement": ["می‌ترسم", "نگرانم", "سخته", "نمی‌تونم", "نمیشه", "ناامید"],
        "celebrate_with_me": ["خوشحالم", "موفق شدم", "عالی شد", "بردم", "ترکوندیم", "ذوق"],
        "information": ["چیست", "چیه", "چرا", "چطور", "تعریف", "معنی", "اطلاعات"],
        "solution": ["حل", "درستش", "رفع", "باگ", "خطا", "مشکل", "چطور درست"],
        "planning": ["برنامه", "مراحل", "قدم", "اول", "بعدش", "چطور بسازم"],
        "companionship": ["حرف بزن", "گپ", "همراه", "حوصله", "تنها", "بیا صحبت"],
    }

    NEGATIONS = {"نه", "نیست", "ندارم", "نبود"}
    STOP = {
        "این", "اون", "برای", "از", "به", "که", "را", "رو", "من", "تو", "یک", "یه", "هم", "با", "در", "چی", "چرا", "چطور", "است", "هست", "بود", "شد", "می", "کنم", "کردم", "کرد", "خیلی", "خودم", "خودت", "اینجا", "اونجا",
        # قیدهایِ زمانِ عمومی -- محتوایِ موضوعیِ صفر دارند (هر جمله‌ای
        # می‌تواند «امروز»/«دیروز» باشد)، اما چون طولشان >=۴ حرف است، قبلاً
        # وارد _topics() می‌شدند و باعث می‌شدند دو پیامِ کاملاً بی‌ربط که
        # هر دو فقط «امروز» گفته بودند، هم‌موضوع به‌حساب بیایند.
        "امروز", "دیروز", "فردا", "امشب", "دیشب", "الان", "الآن",
    }

    STRATEGIES = {
        "venting": "اول احساس را بفهم و بازتاب بده؛ قضاوت نکن؛ راه‌حل را فقط وقتی مناسب است پیشنهاد کن.",
        "celebration": "با انرژی متناسب شادی کاربر را همراهی کن و موفقیتش را طبیعی تأیید کن.",
        "technical": "هدف، محدودیت و خطا را دقیق نگه دار؛ پاسخ مرحله‌ای، عملی و قابل اجرا بده.",
        "planning": "هدف نهایی را در طول مکالمه حفظ کن؛ گزینه‌ها را اولویت‌بندی و قدم بعدی را مشخص کن.",
        "storytelling": "داستان را قطع نکن؛ جزئیات مهم را حفظ کن و سؤال مرتبط بپرس.",
        "question": "به سؤال مستقیم جواب بده؛ اگر ابهام واقعی وجود دارد فقط یک سؤال روشن‌کننده بپرس.",
        "casual": "طبیعی، دوستانه و نه بیش از حد رسمی جواب بده و مکالمه را زنده نگه دار.",
        "general": "زمینه، لحن و هدف چند نوبت اخیر را حفظ کن و از پاسخ‌های قالبی دوری کن.",
    }

    @staticmethod
    def _normalize(text: str) -> str:
        text = (text or "").replace("ي", "ی").replace("ى", "ی").replace("ك", "ک").replace("‌", " ")
        text = re.sub(r"[ـ]+", "", text)
        return re.sub(r"\s+", " ", text).strip()

    @classmethod
    def _tokens(cls, text: str) -> List[str]:
        return [w for w in re.findall(r"[\wآ-ی]{2,}", cls._normalize(text).lower()) if w not in cls.STOP and not w.isdigit()]

    @classmethod
    def _scores(cls, text: str, groups: Dict[str, List[str]]) -> Dict[str, float]:
        t = cls._normalize(text).lower()
        scores = {}
        for key, cues in groups.items():
            hits = 0.0
            for cue in cues:
                c = cls._normalize(cue).lower()
                # مرزبندیِ کلمه، نه substringِ خام -- باگِ واقعی که این حل
                # می‌کند: کلیدواژه‌یِ «کد» (نوعِ technical) قبلاً داخلِ
                # «کدام»/«کدوم» هم match می‌گرفت (چون substring بود)، پس
                # «کدام رستوران بهتره؟» به‌اشتباه technical تشخیص داده
                # می‌شد. همین باگ رویِ «نه» داخلِ «خونه»/«بهانه» و ده‌ها
                # کلمه‌یِ رایجِ دیگر هم اثر داشت -- رجوع به
                # ``matchers/keyword.phrase_in_text`` (همان منطقِ
                # مرزبندیِ کلمه که موتورِ تشخیصِ نیت از قبل استفاده
                # می‌کرد، اینجا هم به‌کار گرفته شده تا دو پیاده‌سازیِ
                # موازی نداشته باشیم).
                if phrase_in_text(t, c):
                    # Explicit phrases carry more weight than a short cue.
                    hits += 1.0 + min(0.8, max(0, len(c.split()) - 1) * 0.15)
            scores[key] = hits
        return scores

    @classmethod
    def emotion_profile(cls, text: str) -> Dict[str, float]:
        raw = cls._scores(text, cls.EMOTION_CUES)
        total = sum(raw.values()) or 1.0
        return {k: round(v / total, 3) for k, v in raw.items() if v}

    @classmethod
    def _emotion(cls, text: str) -> str:
        p = cls.emotion_profile(text)
        return max(p, key=p.get) if p else "neutral"

    @classmethod
    def _conversation_type(cls, text: str) -> str:
        scores = cls._scores(text, cls.TYPE_CUES)
        best = max(scores, key=scores.get)
        return best if scores[best] else "general"

    @classmethod
    def dialogue_act(cls, text: str) -> str:
        scores = cls._scores(text, cls.ACT_CUES)
        best = max(scores, key=scores.get)
        return best if scores[best] else "statement"

    @classmethod
    def user_need(cls, text: str) -> str:
        scores = cls._scores(text, cls.NEED_CUES)
        best = max(scores, key=scores.get)
        return best if scores[best] else "conversation"

    # ------------------------------------------------------------------
    #   امضا (Pattern Signature) + اطمینان (Confidence) + توالی (Sequence)
    # ------------------------------------------------------------------
    @classmethod
    def _label_confidence(cls, scores: Dict[str, float]) -> float:
        """
        اطمینانِ یک دسته‌بندیِ کلیدواژه‌ای (احساس/نوع/نیاز). دو مؤلفه:
        (۱) فاصله‌ی نسبیِ برنده از رقیبِ بعدی -- دو گزینه‌ی تقریباً
        هم‌امتیاز یعنی اطمینانِ کم، حتی اگر مجموع امتیاز زیاد باشد؛
        (۲) قدرتِ مطلقِ برخورد -- یک تک‌کلیدواژه‌ی کوتاه نباید همان
        اطمینانِ چند برخوردِ صریح را بگیرد. خروجی بینِ ۰ و ۱؛ بدونِ هیچ
        برخوردی (تمام امتیازها صفر/خالی) اطمینان صفر است، یعنی برچسبِ
        پیش‌فرض («خنثی»/«عمومی») صادقانه به‌عنوانِ حدس علامت‌گذاری می‌شود.
        """
        if not scores:
            return 0.0
        ordered = sorted(scores.values(), reverse=True)
        top = ordered[0]
        if top <= 0:
            return 0.0
        second = ordered[1] if len(ordered) > 1 else 0.0
        margin = (top - second) / top
        strength = min(1.0, top / 1.5)
        return round(0.5 * margin + 0.5 * strength, 3)

    @classmethod
    def signature(cls, pattern: dict) -> str:
        """
        امضایِ فشرده و قطعیِ یک الگو -- «اثرِ انگشتِ» رفتاری، نه یک ID
        یکتا. دو الگویِ متفاوت که نوع/احساس/نیاز/کنش و موضوعِ اصلی‌شان
        یکسان است عمداً امضایِ یکسان می‌گیرند: این دقیقاً چیزی است که
        برایِ تشخیصِ سریعِ «این رفتار از این کاربر قبلاً دیده شده» لازم
        است (نه شباهتِ فازیِ معنایی، بلکه یک کلیدِ دقیق و ارزان برایِ
        شمارش/merge -- رجوع به ``signature_frequency`` و ``add``).

        فقط موضوعاتِ *تک‌کلمه‌ای* وارد امضا می‌شوند، نه بایگرام‌ها. باگِ
        واقعی: bigramهایِ ``_topics()`` («ناراحتم دلم» در برابرِ «دلم
        ناراحتم») به ترتیبِ دقیقِ کلماتِ همان یک جمله حساس‌اند -- یعنی
        اگر یک الگو کمتر از ۳ موضوعِ تک‌کلمه‌ایِ واقعی داشته باشد (خیلی
        رایج برایِ جمله‌هایِ کوتاه)، جایگاهِ سومِ امضا با یک bigram پر
        می‌شد و همین باعث می‌شد *همان جمله با ترتیبِ کلماتِ متفاوت* (که
        از نظرِ معنایی کاملاً یکسان است) امضایِ متفاوتی بگیرد -- دقیقاً
        برخلافِ هدفِ خودِ این تابع («تشخیصِ تکرارِ رفتار، نه شباهتِ لغویِ
        دقیق»). موضوعاتِ تک‌کلمه‌ای به ترتیبِ تکرار/طول از قبل در
        ``_topics()`` اولویت‌بندی شده‌اند، پس ترتیبشان در پترن حفظ
        می‌شود؛ فقط اینجا فیلترِ «بدونِ فاصله» اضافه شده.
        """
        unigram_topics = [t for t in pattern.get("topics", []) if " " not in t]
        topics = tuple(sorted(unigram_topics[:3]))
        parts = [
            pattern.get("type", "general"),
            pattern.get("emotion", "neutral"),
            pattern.get("need", "conversation"),
            pattern.get("dialogue_act", "statement"),
            "+".join(topics),
            # user_state (اگر توسطِ trx_ai.nlu.user_state تشخیص داده شده
            # باشد) هم بخشی از امضا می‌شود -- طبقِ سندِ ارتقایِ
            # User-State/Response-Strategy: «User State نیز وارد Pattern
            # Signature شود». داده‌یِ قدیمی/بدونِ این فیلد همیشه
            # "unknown" می‌گیرد -- سازگار و بدونِ رگرسیون.
            pattern.get("user_state") or "unknown",
        ]
        return "|".join(parts)

    @classmethod
    def sequence_similarity(cls, seq_a: List[str], seq_b: List[str]) -> float:
        """
        شباهتِ *ترتیبی* دو زنجیره از برچسب‌هایِ کنشِ گفتاری (مثلاً
        ``["question", "sharing", "gratitude"]``) با
        ``difflib.SequenceMatcher``. برخلافِ شباهتِ لغوی/معناییِ یک پیامِ
        تکی، این ترتیبِ چند نوبتِ گفتگو را مقایسه می‌کند -- یعنی «این
        کاربر معمولاً همین توالیِ رفتاری را دنبال می‌کند» (مثلاً همیشه با
        پرسش شروع و با قدردانی تمام می‌کند)، حتی اگر کلماتِ هر نوبت کاملاً
        فرق کند. زنجیره‌یِ خالی همیشه شباهتِ صفر می‌دهد (نه خطا).
        """
        if not seq_a or not seq_b:
            return 0.0
        return difflib.SequenceMatcher(None, seq_a, seq_b).ratio()

    @classmethod
    def _topics(cls, turns: List[Dict[str, str]]) -> List[str]:
        text = " ".join(cls._normalize(t.get("content", "")) for t in turns)
        words = cls._tokens(text)
        freq = Counter(words)
        # Add adjacent content-word pairs; they are much more meaningful than
        # isolated words for Persian conversation.
        bigrams = Counter(" ".join(pair) for pair in zip(words, words[1:]) if pair[0] != pair[1])
        candidates = [(w, n) for w, n in freq.items() if len(w) >= 4]
        candidates.sort(key=lambda x: (-x[1], -len(x[0]), x[0]))
        topics = [w for w, _ in candidates[:8]]
        for pair, _ in sorted(bigrams.items(), key=lambda x: (-x[1], -len(x[0])))[:4]:
            if len(pair) > 7 and pair not in topics:
                topics.append(pair)
        return topics[:10]

    @classmethod
    def _negation(cls, text: str) -> bool:
        t = cls._normalize(text).lower()
        # «نمی» یک پیشوندِ صرفیِ فارسی است که مستقیم به فعل می‌چسبد
        # (نمی‌خوام، نمیشه، نمیتونم، نمیدونم...)، نه یک کلمه‌ی مستقلِ
        # قابلِ مرزبندی -- پس جداگانه به‌صورتِ پیشوندِ *کلمه* چک می‌شود
        # (نه substringِ خامِ کلِ جمله، که مثلاً داخلِ «نمیخکوب» هم می‌زد).
        # بقیه‌ی نشانه‌ها کلماتِ مستقل‌اند و با مرزِ کلمه‌یِ کامل
        # (phrase_in_text) چک می‌شوند تا داخلِ کلماتِ بی‌ربط (مثلاً «نه»
        # داخلِ «خونه»/«بهانه») به‌اشتباه match نگیرند -- باگِ واقعیِ
        # substring که قبلاً اینجا بود.
        if any(w.startswith("نمی") for w in t.split()):
            return True
        return any(phrase_in_text(t, n) for n in cls.NEGATIONS)

    @classmethod
    def _sentiment_direction(cls, turns: List[Dict[str, str]]) -> str:
        vals = []
        order = {"sad": -2, "angry": -2, "anxious": -1, "confused": -0.5, "neutral": 0, "grateful": 1, "happy": 2, "excited": 2.5, "hopeful": 1.5}
        for t in turns:
            if t.get("role") != "user":
                continue
            vals.append(order.get(cls._emotion(t.get("content", "")), 0))
        if len(vals) < 2:
            return "stable"
        delta = vals[-1] - vals[0]
        if delta > 1: return "improving"
        if delta < -1: return "declining"
        return "stable"

    @classmethod
    def _arc(cls, turns: List[Dict[str, str]]) -> str:
        types = [cls._conversation_type(t.get("content", "")) for t in turns if t.get("role") == "user"]
        if not types:
            return "opening"
        uniq = list(dict.fromkeys(types))
        if len(uniq) >= 2:
            return "evolving:" + "->".join(uniq[-3:])
        return "focused:" + uniq[0]

    @classmethod
    def build_pattern(
        cls,
        turns: List[Dict[str, str]],
        source: str = "local",
        user_state: Optional[str] = None,
    ) -> Optional[dict]:
        if not turns:
            return None
        turns = [{"role": t.get("role", "user"), "content": cls._normalize(t.get("content", ""))} for t in turns]
        user_texts = [t["content"] for t in turns if t["role"] == "user"]
        user_text = " ".join(user_texts)
        if len(user_text) < 8:
            return None
        ep = cls.emotion_profile(user_text)
        dominant = max(ep, key=ep.get) if ep else "neutral"
        ctype = cls._conversation_type(user_text)
        # Last user turn is more predictive of what the assistant should do now,
        # while the full window describes the conversation's longer arc.
        last = user_texts[-1] if user_texts else user_text
        emb_vec = _semantic_backend.encode(last) if _semantic_backend.is_available() else None

        # Context embedding -- زمینه‌یِ چند نوبتِ آخرِ کاربر (تا ۳ تا)، نه
        # فقط آخرین جمله. برایِ جمله‌هایِ کوتاه/گنگ («باشه، پس چیکار کنم؟»)
        # که فقط در کنارِ نوبت‌هایِ قبلی معنا پیدا می‌کنند. اگر فقط یک نوبت
        # وجود داشته باشد، با embeddingِ آخرین جمله یکسان می‌شود (بدونِ
        # هزینه‌یِ اضافه‌ی معنادار).
        context_text = " ".join(user_texts[-3:]) if user_texts else ""
        context_emb_vec = (
            _semantic_backend.encode(context_text)
            if context_text and _semantic_backend.is_available() else None
        )

        # Sequence -- توالیِ کنش‌هایِ گفتاریِ کاربر در همین پنجره؛ برایِ
        # sequence_similarity در score() (شباهتِ ترتیبیِ چند نوبتی، نه فقط
        # شباهتِ یک پیامِ تکی).
        act_sequence = [cls.dialogue_act(t["content"]) for t in turns if t["role"] == "user"]

        # Confidence -- میانگینِ اطمینانِ سه دسته‌بندیِ کلیدواژه‌ای رویِ
        # آخرین جمله؛ فقط مبتنی بر خودِ متن است (بدونِ نیاز به نمونه‌ای از
        # کلاس/instance)، چون build_pattern عمداً یک متدِ stateless می‌ماند
        # (در تست‌ها هم مستقیم رویِ کلاس صدا زده می‌شود).
        label_conf = round((
            cls._label_confidence(cls._scores(last, cls.TYPE_CUES)) +
            cls._label_confidence(cls._scores(last, cls.EMOTION_CUES)) +
            cls._label_confidence(cls._scores(last, cls.NEED_CUES))
        ) / 3, 3)

        pattern = {
            "id": f"p_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
            # embedding عددیِ آخرین حرفِ کاربر -- None اگر پکیجِ اختیاری نصب
            # نباشد؛ در آن صورت score() فقط به لایه‌ی لغویِ قبلی سقوط می‌کند.
            "emb": _semantic_backend.vector_to_str(emb_vec) if emb_vec is not None else None,
            "context_emb": _semantic_backend.vector_to_str(context_emb_vec) if context_emb_vec is not None else None,
            "type": ctype,
            "emotion": dominant,
            "emotion_profile": ep,
            "dialogue_act": cls.dialogue_act(last),
            "need": cls.user_need(last),
            "topics": cls._topics(turns),
            "arc": cls._arc(turns),
            "act_sequence": act_sequence,
            "sentiment_direction": cls._sentiment_direction(turns),
            "negation": cls._negation(last),
            "strategy": cls.STRATEGIES.get(ctype, cls.STRATEGIES["general"]),
            "signals": list(dict.fromkeys([t["content"][:140] for t in turns if t["role"] == "user"][-5:])),
            "source": source,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "strength": 0.60 if source == "local" else 0.90,
            "confidence": label_conf,
            # وضعیتِ کاربر (trx_ai.nlu.user_state) -- اختیاری و *جدا* از
            # emotion/need (که صرفاً لغوی/داخلیِ همین موتورند). None اگر
            # صدازننده آن را حساب نکرده -- بدونِ رگرسیون.
            "user_state": user_state,
        }
        # امضا بعد از ساختِ dict محاسبه می‌شود چون خودش به فیلدهایِ همان
        # الگو (نوع/احساس/نیاز/کنش/موضوع/وضعیت) نیاز دارد.
        pattern["signature"] = cls.signature(pattern)
        return pattern

    @classmethod
    def score(
        cls,
        pattern: dict,
        query: str,
        context_text: str = "",
        recent_sequence: Optional[List[str]] = None,
    ) -> float:
        q = cls._normalize(query).lower()
        qt = set(cls._tokens(q))
        score = 0.0
        ptopics = set(pattern.get("topics", []))
        qjoined = " ".join(qt)
        topic_hits = 0
        for topic in ptopics:
            tl = topic.lower()
            # مرزِ کلمه، نه substringِ خام -- باگِ واقعی که این حل می‌کند:
            # موضوعِ «خواب» (از یک الگویِ قبلیِ «مشکلِ خواب») داخلِ کلمه‌یِ
            # کاملاً بی‌ربطِ «خوابگاه» هم substring بود، پس یک پیامِ
            # کاملاً نامرتبط درباره‌ی خوابگاهِ دانشگاه، الگویِ ونتینگِ
            # قدیمیِ «مشکلِ خواب» را با امتیازِ بالایِ آستانه‌ی بازیابی
            # (relevant()) برمی‌گرداند.
            if phrase_in_text(q, tl) or phrase_in_text(qjoined, tl):
                topic_hits += 1
                score += 0.13
                continue
            # Persian morphology is often expressed through short suffixes
            # (e.g. دوست→دوستم، ناراحت→ناراحتم). قبلاً با `b.startswith(a)`
            # چک می‌شد که باعثِ باگِ substring از درِ پشتی بود: «خواب»
            # پیشوندِ «خوابگاه» هم هست. اما جایگزینیِ آن با برابریِ
            # ``stem()``ِ کامل هم زیادی سخت‌گیرانه بود -- چون فهرستِ
            # پسوندهایِ ``nlu.normalizer.stem`` پسوندهایِ تک‌حرفیِ
            # محاوره‌ایِ خیلی رایج (م/ت/ش چسبیده -- «دوستم»، «ناراحتم»)
            # را پوشش نمی‌دهد (و افزودنِ آن‌ها به فهرستِ *سراسریِ* stem
            # ریسکِ جمع‌شدنِ کلماتِ بی‌ربط را در کل خط‌لوله‌یِ NLU بالا
            # می‌برد، نه فقط اینجا). راه‌حلِ متعادل: پیشوند بودن را با
            # سقفی رویِ طولِ اضافه‌ی *پسوند* (حداکثر ۲ حرف -- طولِ
            # واقعیِ اکثرِ پسوندهایِ صرفیِ فارسی) می‌پذیریم، نه هر
            # پیشوندی: «دوست»→«دوستم» فقط ۱ حرف اضافه دارد (قبول)، اما
            # «خواب»→«خوابگاه» ۳ حرف اضافه دارد (رد -- ترکیب/مشتقه است،
            # نه صرفِ ساده).
            tt = cls._tokens(tl)
            if any(
                len(a) >= 3 and any(_is_short_inflection(a, b) for b in qt)
                for a in tt
            ):
                topic_hits += 1
        score += min(0.42, topic_hits * 0.105)
        # General lexical similarity gives patterns a chance even when the exact
        # topic cue was never written into the built-in vocabulary.
        signal_words = set()
        for signal in pattern.get("signals", []):
            signal_words.update(cls._tokens(signal))
        if signal_words and qt:
            lexical = len(signal_words & qt) / max(1, min(len(signal_words), len(qt)))
            score += min(0.20, lexical * 0.20)
        emotion = cls._emotion(q)
        if emotion != "neutral" and emotion == pattern.get("emotion"):
            score += 0.20
        qneed = cls.user_need(q)
        if qneed != "conversation" and qneed == pattern.get("need"):
            score += 0.16
        qact = cls.dialogue_act(q)
        # قرینه‌سازی با «نوع پیش‌فرض» -- همان اصلی که سه خط بالاتر برایِ
        # emotion/need اعمال شده اینجا برایِ act/type نبود: dialogue_act
        # وقتی هیچ نشانه‌یِ صریحی نمی‌بیند، به‌طورِ پیش‌فرض "statement"
        # برمی‌گرداند، و اکثرِ پیام‌هایِ خنثی/دسته‌بندی‌نشده هم به همین
        # مقدار می‌رسند -- پس مقایسه‌یِ بدونِ‌قید یعنی هر دو پیامِ کاملاً
        # بی‌ربط که هر دو دسته‌بندی‌نشده باشند، به‌اشتباه هم‌کنشِ گفتاری
        # حساب می‌شوند.
        if qact != "statement" and qact == pattern.get("dialogue_act"):
            score += 0.10
        qtype = cls._conversation_type(q)
        # همان استدلال برایِ نوعِ پیش‌فرضِ "general".
        if qtype != "general" and qtype == pattern.get("type"):
            score += 0.10
        # هم‌کنشیِ نفی -- فقط وقتی که *واقعاً* نشانه‌یِ نفی در یکی از دو
        # طرف باشد. باگِ واقعی: قبلاً `False == False` (یعنی «نه پیام و
        # نه الگو نفی ندارند») هم +۰.۰۳ می‌گرفت -- که برایِ حدودِ ۹۰٪ از
        # جمله‌هایِ خنثیِ فارسی صادق است، یعنی این «شاهد» عملاً هیچ چیزی
        # را افتراق نمی‌داد؛ فقط یک کفِ ثابتِ کوچک به امتیازِ هر جفتِ
        # کاملاً بی‌ربط اضافه می‌کرد.
        q_negated = cls._negation(q)
        p_negated = bool(pattern.get("negation"))
        if (q_negated or p_negated) and q_negated == p_negated:
            score += 0.03
        for signal in pattern.get("signals", []):
            sw = set(cls._tokens(signal))
            if sw and qt:
                overlap = len(sw & qt) / max(1, len(sw))
                score += min(0.08, overlap * 0.08)
        # توجه: قبلاً اینجا یک source_bonus=0.16 (برایِ الگوهایِ غیرِ
        # builtin) هم به این امتیاز اضافه می‌شد -- اما یک بونوسِ *ثابتِ*
        # ۰.۱۶، وقتی به‌تنهایی از آستانه‌یِ بازیابیِ relevant() (۰.۱۲)
        # بیشتر است، یعنی هر الگوی غیرِ builtinی که ذخیره شده، صرفاً به
        # خاطرِ *منبعش* (نه هیچ شاهدِ واقعیِ موضوعی/لغوی/معنایی) بالایِ
        # آستانه می‌رفت و به‌عنوانِ «مرتبط» بازیابی می‌شد -- باگِ واقعیِ
        # کشف‌شده: یک الگویِ کاملاً بی‌ربط («دیروز رفتم بازار کفش
        # خریدم») برایِ *هر* پیامِ بی‌ربطِ دیگری امتیازِ ۰.۱۴ می‌گرفت،
        # همیشه بالایِ ۰.۱۲. این هم دقیقاً همان تکرارِ منطق بود که
        # قوانینِ قرمزِ پروژه صراحتاً منع کرده‌اند: relevant() از قبل
        # همین ترجیح را *درست* پیاده‌سازی کرده بود (پایین‌تر در همین
        # فایل، ``key=lambda x: x[0] + (0.25 if ... != "builtin" else
        # 0.0)``) -- اما فقط برایِ *ترتیبِ* نتایج، نه برایِ آستانه‌یِ
        # مطلق. حالا فقط همان یک نسخه‌یِ درست باقی مانده: ``score()``
        # فقط بر اساسِ شاهدِ واقعی قضاوت می‌کند؛ ترجیحِ «غیر-builtin»
        # تنها در رتبه‌بندیِ نتایجِ *از قبل مرتبط* اثر می‌گذارد، نه در
        # تشخیصِ مرتبط بودن.

        # لایه‌ی معنایی -- افزوده، هرگز جایگزین: اگر پکیج نصب نباشد یا این
        # الگو (داده‌ی قدیمی از قبلِ این نسخه) فیلدِ emb نداشته باشد، این
        # بخش سهمی صفر دارد و رفتار دقیقاً همان نسخه‌ی لغویِ قبلی می‌ماند.
        pattern_emb = pattern.get("emb")
        if pattern_emb and _semantic_backend.is_available():
            query_vec = _semantic_backend.encode(query)
            stored_vec = _semantic_backend.str_to_vector(pattern_emb)
            if query_vec is not None and stored_vec is not None:
                import numpy as _np

                sim = float(_np.dot(query_vec, stored_vec) / (
                    _np.linalg.norm(query_vec) * _np.linalg.norm(stored_vec) + 1e-9
                ))
                # فقط شباهتِ واقعاً معنی‌دار (>۰.۴) امتیاز می‌گیرد -- نویزِ
                # شباهتِ پایه‌ایِ همه‌ی جمله‌های فارسی با هم را حذف می‌کند.
                if sim > 0.4:
                    score += (sim - 0.4) / 0.6 * 0.35

        # Context embedding -- بونوسِ جداگانه و کوچک‌تر از شباهتِ پیامِ
        # تکی: وقتی صدازننده (relevant()) متنِ زمینه‌ی چند نوبتِ اخیر را هم
        # بدهد، این الگو حتی اگر پیامِ *فعلی* به‌تنهایی گنگ باشد («باشه،
        # پس چیکار کنم؟») بر اساسِ زمینه‌یِ قبل از آن هم می‌تواند بازیابی
        # شود. بدونِ context_text یا context_emb، این بخش هیچ اثری ندارد.
        pattern_ctx_emb = pattern.get("context_emb")
        if context_text and pattern_ctx_emb and _semantic_backend.is_available():
            ctx_vec = _semantic_backend.encode(context_text)
            stored_ctx_vec = _semantic_backend.str_to_vector(pattern_ctx_emb)
            if ctx_vec is not None and stored_ctx_vec is not None:
                import numpy as _np

                csim = float(_np.dot(ctx_vec, stored_ctx_vec) / (
                    _np.linalg.norm(ctx_vec) * _np.linalg.norm(stored_ctx_vec) + 1e-9
                ))
                if csim > 0.4:
                    score += (csim - 0.4) / 0.6 * 0.20

        # Sequence matching -- شباهتِ *ترتیبیِ* توالیِ کنش‌هایِ گفتاریِ
        # گفتگویِ جاری با توالیِ ذخیره‌شده‌یِ این الگو. یک تطبیقِ خوبِ لغوی/
        # معناییِ *یک* پیام کافی نیست اگر روندِ کلیِ گفتگو با این الگو فرق
        # دارد؛ برعکس، حتی وقتی کلماتِ پیامِ فعلی تازه‌اند، اگر رفتارِ
        # چندنوبتیِ همیشگیِ کاربر همین باشد (مثلاً «پرسش -> فنی -> قدردانی»)
        # این الگو باید امتیازِ اضافه بگیرد. بدونِ recent_sequence، بدونِ اثر.
        if recent_sequence and pattern.get("act_sequence"):
            seq_sim = cls.sequence_similarity(recent_sequence, pattern["act_sequence"])
            if seq_sim > 0.3:
                score += (seq_sim - 0.3) / 0.7 * 0.15

        return min(1.0, score * float(pattern.get("strength", 0.6)))

    @classmethod
    def emotional_support_mode(cls, text: str) -> bool:
        """True when the user appears to need emotional presence before advice."""
        t = cls._normalize(text).lower()
        emotion = cls._emotion(t)
        need = cls.user_need(t)
        ctype = cls._conversation_type(t)
        # Explicit requests for a solution override the default no-advice rule.
        explicit_solution = any(x in t for x in [
            "راهکار بده", "راه حل بده", "راه‌حل بده", "چیکار کنم",
            "چه کار کنم", "کمکم کن حل", "حلش کن", "چی کار کنم"
        ])
        return (emotion in {"sad", "angry", "anxious"} or
                need == "emotional_support" or ctype == "venting") and not explicit_solution

    # ------------------------------------------------------------------
    #   پاسخِ همدلانه‌ی کاملاً محلی (بدونِ نیاز به اینترنت/Gemini)
    # ------------------------------------------------------------------
    # قبلاً همه‌ی این تشخیص‌ها (emotion_profile/emotional_support_mode)
    # فقط وقتی واقعاً در پاسخِ نهایی اثر می‌کردند که مسیرِ Gemini در
    # دسترس بود (کلید تنظیم‌شده + اینترنت وصل)؛ سیستم‌پرامپتِ core.py
    # صراحتاً می‌گفت «اگر کاربر درد دل می‌کند، فقط همدل باش»، اما این
    # دستورالعمل فقط داخلِ خودِ Gemini اجرا می‌شد. وقتی Gemini در دسترس
    # نبود (خیلی رایج روی یک گوشیِ بدونِ کلیدِ API یا بدونِ اینترنت)،
    # فallback یک پیامِ کاملاً عمومی و رباتی بود («سؤال خود را دقیق‌تر
    # مطرح کنید») که حتی برایِ «امروز خیلی ناراحتم» هم همین را نشان
    # می‌داد -- یعنی فهمِ احساس هیچ اثری روی پاسخِ واقعی نداشت مگر با
    # اینترنت. این تابع همان فهم را مستقیماً به یک پاسخِ همدلانه (نه
    # گزارشِ آماری، نه پرسیدنِ اطلاعات) تبدیل می‌کند -- کاملاً آفلاین.
    EMPATHY_TEMPLATES = {
        "sad": [
            "می‌فهمم چقدر سنگینه؛ حق داری اینطوری حس کنی. اگه دوست داری، بیشتر برام بگو چی شده.",
            "این حسی که داری واقعاً سخته. من اینجام و گوش می‌دم، عجله‌ای برای هیچی نیست.",
            "بابت این حالت متأسفم. گاهی فقط شنیده‌شدن کافیه -- هر چقدر دوست داری بگو.",
            "حس می‌کنم امروز روزِ سختی بوده. لازم نیست چیزی رو قشنگ جلوه بدی، همینطور که هست بگو.",
        ],
        "angry": [
            "کاملاً حق داری عصبانی باشی؛ این حس رو جدی می‌گیرم. چی شده که اینقدر اذیتت کرده؟",
            "می‌شنوم که چقدر رو اعصابته. بگو چی گذشته، بدونِ قضاوت گوش می‌دم.",
            "این حسِ کلافگی طبیعیه با چیزی که گذشته. هر وقت خواستی بگی، من اینجام.",
        ],
        "anxious": [
            "نگرانی همیشه سنگینه، مخصوصاً وقتی نمی‌دونی از کجا شروع بشه. می‌خوای با هم مرتبش کنیم؟",
            "می‌فهمم چقدر ذهنت درگیره. یه نفسِ عمیق بکش؛ هر وقت آماده بودی بگو چی نگرانت کرده.",
            "استرس داشتن تو این شرایط طبیعیه. اگه بخوای می‌تونیم قدم‌به‌قدم باهاش کنار بیایم.",
        ],
        "grateful": [
            "خواهش می‌کنم، همیشه اینجام. خوشحالم که کمکی از دستم برمیاد.",
            "این حرفت خیلی گرم بود، ممنون. هر وقت به چیزی نیاز داشتی بگو.",
        ],
        "confused": [
            "بذار با هم روشنش کنیم. دقیقاً کدوم قسمتش گنگه؟",
            "طبیعیه که گیج بشی. از هرجا که راحتی شروع کن، با هم می‌فهمیمش.",
        ],
        "happy": [
            "وای چه خبرِ خوبی! خیلی خوشحال شدم برات. بیشتر تعریف کن چی شده.",
            "این عالیه! حقته که خوشحال باشی. چطور شد؟",
            "چقدر خوشحال‌کننده‌ست این خبر! خیلی دلم می‌خواد بیشتر بدونم.",
        ],
        "excited": [
            "هیجانت رو حس کردم! تعریف کن دقیقاً چی شده که اینقدر ذوق‌زده‌ای.",
            "انرژیت عالیه! بگو ببینم قضیه چیه.",
        ],
        "hopeful": [
            "امیدواری خیلی خوبه؛ نگه‌ش دار. چی باعث شد اینطوری فکر کنی؟",
        ],
        "generic_venting": [
            "اینجام و گوش می‌دم. هر چی تو ذهنته، با خیالِ راحت بگو.",
            "حس می‌کنم چیزی رو تو دلت داری. من آماده‌ام بشنوم.",
        ],
    }

    @classmethod
    def local_empathetic_reply(cls, text: str) -> Optional[str]:
        """
        پاسخِ همدلانه‌ی کاملاً آفلاین برایِ وقتی که پیام حسی/عاطفی است.
        اگر پیام حسی نباشد (پرسشِ فنی، دستور و ...)، None برمی‌گرداند تا
        مسیرِ عادیِ core.py (ویکی‌پدیا/DuckDuckGo) بدونِ تغییر ادامه یابد --
        این تابع فقط جای پیامِ رباتیِ عمومیِ fallback را می‌گیرد، نه هر پاسخی.
        """
        t = cls._normalize(text).lower()
        emotion = cls._emotion(t)
        ctype = cls._conversation_type(t)
        is_support = cls.emotional_support_mode(t)
        is_celebratory = ctype == "celebration" or emotion in {"happy", "excited"}

        if is_support:
            bucket = cls.EMPATHY_TEMPLATES.get(emotion) or cls.EMPATHY_TEMPLATES["generic_venting"]
            return random.choice(bucket)
        if is_celebratory:
            bucket = cls.EMPATHY_TEMPLATES.get(emotion) or cls.EMPATHY_TEMPLATES["happy"]
            return random.choice(bucket)
        if emotion == "grateful":
            return random.choice(cls.EMPATHY_TEMPLATES["grateful"])
        return None

    @classmethod
    def _utterance_pattern(
        cls,
        content: str,
        index: int,
        context_text: str = "",
        user_state: Optional[str] = None,
    ) -> dict:
        text = cls._normalize(content)
        emb_vec = _semantic_backend.encode(text) if _semantic_backend.is_available() else None
        # context_text (اختیاری): چند نوبتِ *قبل* از همین گفته، برایِ ساختِ
        # context_emb -- به همین دلیل جداگانه پاس داده می‌شود (نه از خودِ
        # ``text``)، چون این متد چیزی از تاریخچه نمی‌داند مگر صدازننده
        # (``observe``) آن را بدهد.
        context_emb_vec = (
            _semantic_backend.encode(context_text)
            if context_text and _semantic_backend.is_available() else None
        )
        label_conf = round((
            cls._label_confidence(cls._scores(text, cls.TYPE_CUES)) +
            cls._label_confidence(cls._scores(text, cls.EMOTION_CUES)) +
            cls._label_confidence(cls._scores(text, cls.NEED_CUES))
        ) / 3, 3)
        pattern = {
            "id": f"u_{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{index}",
            "emb": _semantic_backend.vector_to_str(emb_vec) if emb_vec is not None else None,
            "context_emb": _semantic_backend.vector_to_str(context_emb_vec) if context_emb_vec is not None else None,
            "text": text[:500],
            "emotion": cls._emotion(text),
            "emotion_profile": cls.emotion_profile(text),
            "type": cls._conversation_type(text),
            "dialogue_act": cls.dialogue_act(text),
            "need": cls.user_need(text),
            "topics": cls._topics([{"role": "user", "content": text}])[:8],
            "support_mode": cls.emotional_support_mode(text),
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "confidence": label_conf,
            "user_state": user_state,
        }
        pattern["signature"] = cls.signature(pattern)
        return pattern

    # Built-in conversational experience. These are broad, generic examples
    # used only as starting patterns; they are not treated as facts about the user.
    # The corpus intentionally spans everyday life, emotions, learning, technology,
    # hobbies, planning, creativity, relationships, games, travel, food, money,
    # health, media, science and troubleshooting.
    BOOTSTRAP_SEEDS = [
        # casual / companionship
        ("سلام، امروز چه خبر؟", "casual"), ("حوصله‌ام سر رفته، بیا یکم حرف بزنیم", "casual"),
        ("امروز خیلی خسته‌ام ولی دلم می‌خواد گپ بزنم", "casual"), ("به نظرت امروز چه کار جالبی انجام بدم؟", "casual"),
        ("من برگشتم، کجای بحث بودیم؟", "casual"), ("یه چیزی تو ذهنمه ولی نمی‌دونم از کجا شروع کنم", "casual"),
        # emotions / venting
        ("امروز خیلی ناراحتم و فقط می‌خوام یکی گوش بده", "venting"), ("از رفتار دوستم دلم گرفته", "venting"),
        ("خیلی عصبانی‌ام و نمی‌خوام الان نصیحت بشنوم", "venting"), ("نگران آینده‌ام و ذهنم آروم نمی‌شه", "venting"),
        ("امروز حس تنهایی دارم", "venting"), ("خیلی خسته‌ام از اینکه همه چیز سخت شده", "venting"),
        ("یه خبر خیلی خوب دارم، بالاخره موفق شدم", "celebration"), ("خیلی ذوق دارم، پروژه‌ام جواب داد", "celebration"),
        # relationships
        ("دوستم سرد شده و نمی‌دونم چطور باهاش حرف بزنم", "relationships"),
        ("با خانواده‌ام بحث کردم و هنوز ناراحتم", "relationships"),
        ("یکی از دوستام یه کار خوب برام انجام داد و خوشحالم", "relationships"),
        ("چطور می‌تونم بدون دعوا سوءتفاهم رو حل کنم؟", "relationships"),
        ("می‌خوام برای دوستم یک پیام صمیمی بنویسم", "relationships"),
        ("وقتی کسی جوابم رو نمی‌ده، چطور باهاش برخورد کنم؟", "relationships"),
        # learning / school
        ("می‌خوام پایتون یاد بگیرم، از کجا شروع کنم؟", "learning"),
        ("این مفهوم ریاضی رو ساده توضیح می‌دی؟", "learning"),
        ("امروز باید برای امتحان درس بخونم و تمرکز ندارم", "learning"),
        ("فرق این دو مفهوم رو با مثال توضیح بده", "learning"),
        ("یه برنامه مطالعه برای چند روز آینده می‌خوام", "learning"),
        ("چطور چیزی که یاد گرفتم رو بهتر به خاطر بسپارم؟", "learning"),
        # coding / software
        ("این خطای پایتون یعنی چی؟", "technical"), ("کدم فقط یک بار اجرا می‌شه، مشکل از کجاست؟", "technical"),
        ("می‌خوام یک API به پروژه‌ام وصل کنم", "technical"), ("این تابع رو چطور تمیزتر طراحی کنم؟", "technical"),
        ("پروژه‌ام خیلی بزرگ شده و نمی‌دونم چطور ماژولارش کنم", "technical"),
        ("کتابخانه نصب نمی‌شه و روی گوشی کار می‌کنم", "technical"),
        ("چطور خطایابی یک پروژه بزرگ رو شروع کنم؟", "technical"),
        ("می‌خوام تست واحد برای این ماژول بنویسم", "technical"),
        # AI / conversation
        ("چطور یک دستیار مکالمه‌ای حافظه‌دار بسازم؟", "technical"),
        ("می‌خوام AI از مکالمه‌ها الگو یاد بگیره", "technical"),
        ("فرق حافظه کوتاه‌مدت و بلندمدت در چت‌بات چیه؟", "question"),
        ("چطور می‌شه احساس و نیت جمله رو جداگانه تشخیص داد؟", "question"),
        ("چطور یک مدل زبانی رو با ابزارها ترکیب کنم؟", "technical"),
        # planning / goals
        ("می‌خوام برای این پروژه قدم‌به‌قدم برنامه بریزم", "planning"),
        ("هدفم اینه که تا آخر ماه پروژه رو تمام کنم", "planning"),
        ("بین چند کار گیر کردم، اولویت‌بندی کمکم می‌کنی؟", "planning"),
        ("برای فردا یک برنامه ساده و قابل اجرا می‌خوام", "planning"),
        ("چطور یک هدف بزرگ رو به کارهای کوچک تقسیم کنم؟", "planning"),
        ("برنامه‌ام عقب افتاده، چطور دوباره جمعش کنم؟", "planning"),
        # creativity / writing
        ("یه ایده برای داستان علمی‌تخیلی می‌خوام", "creative"),
        ("کمکم کن یک اسم خفن برای پروژه پیدا کنم", "creative"),
        ("می‌خوام یک بازی ساده ولی سرگرم‌کننده طراحی کنم", "creative"),
        ("برای رابط کاربری برنامه‌ام چند ایده بده", "creative"),
        ("یه داستان کوتاه با پایان غیرمنتظره بساز", "creative"),
        ("چطور ایده خامم رو تبدیل به یک پروژه واقعی کنم؟", "creative"),
        # games / entertainment
        ("یه بازی خوب برای گوشی معرفی کن", "entertainment"),
        ("دنبال یک بازی رانندگی جهان‌بازم", "entertainment"),
        ("چه بازی‌ای برای بازی دونفره جذابه؟", "entertainment"),
        ("یک فیلم کمدی خانوادگی خوب می‌خوام", "entertainment"),
        ("چرا بعضی بازی‌ها بعد از چند ساعت داغ می‌کنن؟", "question"),
        ("می‌خوام یک بازی خودم بسازم، چه سبکی مناسب شروعه؟", "creative"),
        # electronics / hardware
        ("می‌خوام چند بلندگو رو به یک آمپلی‌فایر وصل کنم", "technical"),
        ("باتری‌هام زود خالی می‌شن، چه چیزهایی رو بررسی کنم؟", "technical"),
        ("یک ماشین کنترلی ساختم و موتور گرم می‌شه", "technical"),
        ("فرق ولتاژ و جریان رو با مثال توضیح بده", "question"),
        ("چطور سیم‌کشی پروژه‌ام رو مرتب و امن کنم؟", "technical"),
        ("برای پروژه الکترونیکی‌ام چه چیزهایی رو قبل از روشن کردن چک کنم؟", "planning"),
        # science / curiosity
        ("چرا آسمان آبی دیده می‌شه؟", "question"), ("ابرها چطور تشکیل می‌شن؟", "question"),
        ("باتری چطور انرژی ذخیره می‌کنه؟", "question"), ("هوش مصنوعی چطور متن تولید می‌کنه؟", "question"),
        ("تفاوت اینترنت و وب چیه؟", "question"), ("چرا بعضی فلزها رساناترند؟", "question"),
        # daily life / organization
        ("امروز چند کار عقب‌افتاده دارم و گیج شدم", "planning"),
        ("اتاقم شلوغه و نمی‌دونم از کجا مرتبش کنم", "planning"),
        ("چطور زمانم رو بین درس و تفریح تقسیم کنم؟", "planning"),
        ("امروز انرژی ندارم، کارهام رو چطور سبک‌تر کنم؟", "planning"),
        ("برای خرید چند وسیله باید بودجه‌ام رو مدیریت کنم", "planning"),
        # money / shopping
        ("برای خرید یک وسیله بین قیمت و کیفیت مرددم", "question"),
        ("چطور برای یک خرید بزرگ پس‌انداز کنم؟", "planning"),
        ("دو محصول شبیه هم دارم، چطور مقایسه‌شون کنم؟", "question"),
        ("بودجه‌ام محدوده و باید بین چند گزینه انتخاب کنم", "planning"),
        # food / cooking
        ("برای شام یک غذای ساده پیشنهاد بده", "casual"),
        ("چطور یک غذای سریع با مواد کم درست کنم؟", "question"),
        ("طعم غذا خیلی شور شده، چه کار کنم؟", "question"),
        ("می‌خوام برای چند روز غذاها رو از قبل برنامه‌ریزی کنم", "planning"),
        # travel / places
        ("برای یک سفر کوتاه چه چیزهایی لازم دارم؟", "planning"),
        ("بین دو مقصد برای سفر مرددم", "question"),
        ("می‌خوام یک برنامه سفر کم‌هزینه بچینم", "planning"),
        ("در یک شهر جدید چطور سریع با محیط آشنا بشم؟", "question"),
        # health general (non-diagnostic conversational examples)
        ("امروز خیلی خسته‌ام و می‌خوام درباره حال عمومی‌ام حرف بزنم", "venting"),
        ("برای خواب منظم چه عادت‌هایی می‌تونه کمک‌کننده باشه؟", "question"),
        ("استرس دارم و ذهنم شلوغه", "venting"),
        ("برای یک سؤال پزشکی می‌خوام اول اطلاعات معتبر پیدا کنم", "question"),
        # stories / memories
        ("امروز یک اتفاق عجیب برام افتاد", "storytelling"),
        ("یادمه بچگی یک بار چنین چیزی دیدم", "storytelling"),
        ("بذار از اول ماجرا رو برات تعریف کنم", "storytelling"),
        ("بعد از اون اتفاق، همه چیز تغییر کرد", "storytelling"),
        ("می‌خوام یک خاطره رو تعریف کنم، فقط گوش بده", "storytelling"),
        # opinions / decisions
        ("بین دو انتخاب گیر کردم و نظر بی‌طرفانه می‌خوام", "question"),
        ("به نظرت این تصمیم منطقیه؟", "question"),
        ("خودم هنوز مطمئن نیستم چه چیزی می‌خوام", "sharing"),
        ("مزایا و معایب این دو گزینه رو مقایسه کن", "question"),
        # motivation / confidence
        ("حس می‌کنم پیشرفت نمی‌کنم", "venting"),
        ("می‌خوام دوباره انگیزه پیدا کنم", "planning"),
        ("از شروع کردن می‌ترسم چون ممکنه شکست بخورم", "venting"),
        ("بالاخره کاری که مدت‌ها تمرین کردم جواب داد", "celebration"),
        # meta conversation
        ("اگر حرفم مبهم بود ازم سؤال روشن‌کننده بپرس", "general"),
        ("وقتی ناراحتم اول گوش بده و سریع راهکار نده", "venting"),
        ("وقتی خوشحالم باهام خوشحال شو", "celebration"),
        ("وقتی دارم داستان تعریف می‌کنم وسط حرفم نپر", "storytelling"),
        ("وقتی سؤال فنی می‌پرسم جواب عملی و دقیق می‌خوام", "technical"),
        ("اگر چیزی رو نمی‌دونی صادقانه بگو", "general"),
        ("برای ورزش و تحرک روزانه یک برنامه ساده می‌خوام", "planning"),
        ("امروز حوصله ورزش ندارم و فقط خسته‌ام", "venting"),
        ("تازه یک مهارت جدید شروع کردم و هیجان‌زده‌ام", "celebration"),
        ("می‌خوام عادت بدی رو کم‌کم تغییر بدم", "planning"),
        ("چطور یک عادت خوب رو پایدار کنم؟", "question"),
        ("برای خواب بهتر دنبال یک روتین ساده‌ام", "planning"),
        ("صبح‌ها سخت بیدار می‌شم و برنامه‌ام به هم می‌ریزه", "sharing"),
        ("می‌خوام کتاب خوندن رو وارد برنامه روزانه‌ام کنم", "planning"),
        ("چه کتابی برای شروع یک موضوع جدید خوبه؟", "question"),
        ("از یک موضوع علمی عجیب خوشم اومده و می‌خوام بیشتر بدونم", "question"),
        ("می‌خوام درباره فضا و سیاره‌ها گپ بزنیم", "casual"),
        ("چرا بعضی صداها برای آدم آرامش‌بخشن؟", "question"),
        ("موسیقی مناسب تمرکز پیشنهاد می‌دی؟", "question"),
        ("امروز یک فیلم دیدم که پایانش خیلی ذهنم رو درگیر کرد", "sharing"),
        ("بیا درباره یک فیلمی که دیدم بحث کنیم", "casual"),
        ("برای یک بازی، داستان و شخصیت می‌خوام طراحی کنم", "creative"),
        ("چطور برای بازی‌ام سیستم مرحله طراحی کنم؟", "technical"),
        ("بازیکن‌ها معمولاً از چه چیزهایی در بازی لذت می‌برن؟", "question"),
        ("می‌خوام کنترل لمسی بازی رو بهتر کنم", "technical"),
        ("گوشی‌ام موقع اجرای برنامه داغ می‌کنه", "technical"),
        ("چطور مصرف حافظه برنامه‌ام رو کمتر کنم؟", "technical"),
        ("این پروژه روی گوشی کند شده، از کجا بررسی کنم؟", "technical"),
        ("چطور فایل‌های پروژه‌ام رو مرتب کنم؟", "planning"),
        ("قبل از انتشار برنامه چه چیزهایی رو تست کنم؟", "planning"),
        ("می‌خوام از پروژه‌ام نسخه پشتیبان بگیرم", "technical"),
        ("فایل zip من باز نمی‌شه، چه چیزهایی رو چک کنم؟", "technical"),
        ("اینترنت ضعیفه و برنامه‌ام مرتب قطع می‌شه", "technical"),
        ("چطور یک برنامه رو بدون اینترنت تا حد ممکن کاربردی کنم؟", "technical"),
        ("می‌خوام اطلاعات کاربرها امن باقی بمونه", "technical"),
        ("برای رمز عبور امن چه اصولی رو رعایت کنم؟", "question"),
        ("چطور یک اپ ساده برای خودم طراحی کنم؟", "planning"),
        ("یک ایده عجیب دارم، بذار کامل توضیحش بدم", "sharing"),
        ("فکر می‌کنم ایده‌ام خوبه ولی مطمئن نیستم", "venting"),
        ("نمی‌خوام قضاوتم کنی، فقط می‌خوام حرف بزنم", "venting"),
        ("اگر خوشحال بودم با انرژی جوابم بده", "celebration"),
        ("اگر گیج بودم قدم‌به‌قدم توضیح بده", "question"),
        ("اگر چند انتخاب داشتم کمک کن مقایسه‌شون کنم", "planning"),
        ("اگر داستان می‌گم جزئیاتش رو یادت بمونه", "storytelling"),
        ("اگر اشتباه کردم محترمانه بهم بگو", "general"),
        ("اگر حرف قبلیم با حرف جدیدم تناقض داشت متوجهش شو", "general"),
        # --- v5 broad-corpus expansion (originally authored, everyday coverage) ---
        ("سلام، چطوری؟", "casual"),
        ("سلام رفیق، چه خبرا؟", "casual"),
        ("صبح بخیر، امروز حالت چطوره؟", "casual"),
        ("شب بخیر، فردا می‌بینمت", "casual"),
        ("چه خبر؟ کجایی این روزا؟", "casual"),
        ("خیلی وقته نبودم، دلم برات تنگ شده بود", "casual"),
        ("امروز حوصله‌ی هیچی رو ندارم، فقط بیا حرف بزنیم", "casual"),
        ("یه چیز خنده‌دار برام تعریف کن", "casual"),
        ("یه جوک بگو حالم بهتر شه", "casual"),
        ("امروز هوا چقدر خوبه، دلم می‌خواد برم بیرون", "casual"),
        ("هیچ کاری ندارم امروز، بیا گپ بزنیم", "casual"),
        ("دلم یه چیز سرگرم‌کننده می‌خواد", "casual"),
        ("رئیسم امروز سرم داد زد و خیلی ناراحتم", "venting"),
        ("کارم زیاده و نمی‌رسم", "venting"),
        ("امروز تو محل کارم بحث شد و هنوز عصبانی‌ام", "venting"),
        ("از شغلم راضی نیستم ولی نمی‌دونم چیکار کنم", "venting"),
        ("همکارم کارمو انداخت گردن من", "venting"),
        ("می‌خوام برای مصاحبه کاری آماده بشم", "planning"),
        ("رزومه‌ام رو چطور بهتر کنم؟", "question"),
        ("امروز اولین روز کاریمه و استرس دارم", "venting"),
        ("حقوقم کفاف زندگیم رو نمی‌ده", "venting"),
        ("می‌خوام شغلم رو عوض کنم ولی می‌ترسم", "venting"),
        ("پروژه‌ی کاری‌ام دیرکرد داره و فشار زیاده", "venting"),
        ("امروز یه ترفیع گرفتم، خیلی خوشحالم", "celebration"),
        ("فردا امتحان دارم و اصلا آماده نیستم", "venting"),
        ("استرس امتحان دارم و دستام می‌لرزه", "venting"),
        ("نمره‌ام بد شد و ناامید شدم", "venting"),
        ("چطور برای امتحان نهایی برنامه بریزم؟", "planning"),
        ("حافظه‌ام برای درس خوندن ضعیفه، چیکار کنم؟", "question"),
        ("امروز امتحانم خیلی خوب پیش رفت", "celebration"),
        ("نمی‌تونم رو درسم تمرکز کنم، ذهنم پرته", "venting"),
        ("برای کنکور چطور زمان‌بندی کنم؟", "planning"),
        ("دیشب اصلا نخوابیدم و امروز داغونم", "venting"),
        ("چرا هر شب دیر می‌خوابم با اینکه نمی‌خوام؟", "question"),
        ("چند روزه بدخواب شدم", "venting"),
        ("برای خواب بهتر چه کاری می‌تونم بکنم؟", "question"),
        ("صبح‌ها هیچ انرژی ندارم", "venting"),
        ("امروز کل روز خواب‌آلود بودم", "venting"),
        ("می‌خوام شروع کنم به ورزش کردن ولی انگیزه ندارم", "planning"),
        ("چند روزه باشگاه نرفتم و حس بدی دارم", "venting"),
        ("یه برنامه ساده ورزشی برای خونه می‌خوام", "planning"),
        ("امروز اولین بار دویدم و حالم عالیه", "celebration"),
        ("چطور می‌تونم به ورزش کردن عادت کنم؟", "question"),
        ("بعد از ورزش بدنم خیلی درد می‌گیره", "sharing"),
        ("همش کارامو عقب می‌ندازم", "venting"),
        ("چطور تنبلی رو کنار بذارم؟", "question"),
        ("انگیزه‌ام رو از دست دادم", "venting"),
        ("می‌خوام یه عادت جدید بسازم ولی همیشه شکست می‌خورم", "venting"),
        ("امروز بالاخره کاری که عقب انداخته بودم رو انجام دادم", "celebration"),
        ("چرا هر بار تصمیم می‌گیرم ولی عمل نمی‌کنم؟", "question"),
        ("گربه‌ام امروز مریض شده و نگرانشم", "venting"),
        ("سگم امروز یه کار خنده‌دار کرد", "sharing"),
        ("می‌خوام یه حیوون خونگی بگیرم، چی پیشنهاد می‌دی؟", "question"),
        ("گربه‌ام گم شده و خیلی نگرانم", "venting"),
        ("بالاخره سگم رو آموزش دادم بشینه", "celebration"),
        ("خونه‌ام خیلی به‌هم ریخته و حوصله مرتب کردن ندارم", "venting"),
        ("چطور خونه‌ام رو سریع تمیز کنم؟", "question"),
        ("امروز کل خونه رو مرتب کردم، حالم خیلی خوبه", "celebration"),
        ("لوله‌ی آشپزخونه چکه می‌کنه", "technical"),
        ("چطور وسایل اضافه‌ی خونه رو دسته‌بندی کنم؟", "planning"),
        ("آخر ماهه و پولم ته کشیده", "venting"),
        ("می‌خوام یه بودجه‌بندی ساده برای خودم بذارم", "planning"),
        ("چطور بین خرج و پس‌انداز تعادل برقرار کنم؟", "question"),
        ("امروز تونستم یه مقدار پول پس‌انداز کنم", "celebration"),
        ("یه هزینه غیرمنتظره داشتم و برنامه‌ام به‌هم ریخت", "venting"),
        ("امروز هوا خیلی سرده، حسابی یخ زدم", "sharing"),
        ("بارون میاد و دلم می‌خواد فقط بشینم چایی بخورم", "casual"),
        ("این گرما داره حسابی اذیتم می‌کنه", "venting"),
        ("عاشق بوی خاک بعد بارونم", "sharing"),
        ("نوروز داره نزدیک می‌شه و هیجان دارم", "celebration"),
        ("تولدمه و امروز حسابی خوشحالم", "celebration"),
        ("امسال مهمونی عید رو کجا برگزار کنیم؟", "planning"),
        ("سال نو رو چطور شروع کنم که بهتر پیش بره؟", "question"),
        ("امسال تعطیلات رو کجا برم خوبه؟", "question"),
        ("با خواهرم دعوام شد و حالم گرفته‌ست", "venting"),
        ("پدر و مادرم درکم نمی‌کنن", "venting"),
        ("امروز با خانواده‌ام وقت خوبی داشتم", "celebration"),
        ("چطور با خانواده‌ام راحت‌تر حرف بزنم؟", "question"),
        ("برادرم همیشه باهام رقابت می‌کنه و خسته‌کننده شده", "venting"),
        ("تو جمع خجالت می‌کشم حرف بزنم", "venting"),
        ("چطور دوست جدید پیدا کنم؟", "question"),
        ("احساس می‌کنم هیچ‌کس درکم نمی‌کنه", "venting"),
        ("امروز تو یه جمع جدید خیلی راحت بودم، خوشحالم", "celebration"),
        ("از قضاوت شدن می‌ترسم", "venting"),
        ("می‌خوام گیتار یاد بگیرم", "learning"),
        ("چند وقته پیانو تمرین می‌کنم ولی پیشرفت نمی‌کنم", "venting"),
        ("امروز بالاخره یه آهنگ کامل رو تونستم بزنم", "celebration"),
        ("چطور صدای خوندنم رو بهتر کنم؟", "question"),
        ("دنبال یه آهنگ آروم برای تمرکزم", "question"),
        ("می‌خوام نقاشی رو شروع کنم ولی نمی‌دونم از کجا", "planning"),
        ("امروز یه نقاشی کشیدم که خیلی دوستش دارم", "celebration"),
        ("چطور تکنیک سایه‌زدن رو یاد بگیرم؟", "question"),
        ("دیشب بازی تیم موردعلاقه‌ام رو باختیم و ناراحتم", "venting"),
        ("امروز تیممون برد و خیلی خوشحالم", "celebration"),
        ("می‌خوام فوتبال بازی کردن رو جدی‌تر دنبال کنم", "planning"),
        ("چرا هر بار تیمم تو لحظه آخر می‌بازه؟", "venting"),
        ("لپ‌تاپم خیلی کند شده", "technical"),
        ("وای‌فای خونه‌مون مدام قطع می‌شه", "technical"),
        ("برنامه‌ام موقع نصب ارور می‌ده", "technical"),
        ("گیت کانفلیکت داده و نمی‌دونم چطور حلش کنم", "technical"),
        ("داکر کانتینرم بالا نمیاد", "technical"),
        ("دیتابیسم کوئری‌هاش خیلی کند شدن", "technical"),
        ("جاوااسکریپتم یه ارور عجیب می‌ده تو کنسول", "technical"),
        ("گوشیم فضای ذخیره‌سازیش پر شده", "technical"),
        ("چطور یه فایل بزرگ رو فشرده کنم؟", "question"),
        ("سایتم روی موبایل درست نمایش داده نمی‌شه", "technical"),
        ("چطور از پروژه‌ام بکاپ خودکار بگیرم؟", "planning"),
        ("پسوردم رو فراموش کردم و نمی‌تونم وارد بشم", "technical"),
        ("بین دو تا گوشی مونده‌ام کدومو بخرم", "question"),
        ("این محصول ارزش خریدن داره یا نه؟", "question"),
        ("می‌خوام یه هدیه خوب برای دوستم پیدا کنم", "question"),
        ("امروز یه چیزی خریدم که خیلی راضیم ازش", "celebration"),
        ("پشیمونم که این وسیله رو خریدم", "venting"),
        ("می‌خوام یه دسر ساده درست کنم", "question"),
        ("غذام سوخت و ناراحتم", "venting"),
        ("یه رسپی خوب برای مهمونی می‌خوام", "question"),
        ("امروز یه غذای جدید امتحان کردم و خیلی خوب شد", "celebration"),
        ("چطور نون خونگی درست کنم؟", "question"),
        ("می‌خوام برای اولین بار تنها سفر کنم", "planning"),
        ("سفر آخرم عالی بود، هنوز خاطره‌اش هستم", "sharing"),
        ("چطور برای سفر خارج از کشور آماده بشم؟", "planning"),
        ("چمدونم رو چطور بهینه ببندم؟", "question"),
        ("بلیط سفرم کنسل شد و ناراحتم", "venting"),
        ("می‌خوام یه نسخه بهتر از خودم بشم", "planning"),
        ("چطور اعتماد به نفسم رو بالا ببرم؟", "question"),
        ("امروز یه قدم کوچیک ولی مهم برداشتم", "celebration"),
        ("حس می‌کنم هیچ پیشرفتی نمی‌کنم", "venting"),
        ("چطور با شکست کنار بیام؟", "question"),
        ("چرا شب‌ها ستاره‌ها رو می‌بینیم ولی روزها نه؟", "question"),
        ("دایناسورها چطور منقرض شدن؟", "question"),
        ("چرا زبان‌های مختلف اینقدر متفاوتن؟", "question"),
        ("مغز چطور خاطرات رو ذخیره می‌کنه؟", "question"),
        ("چرا بعضی حیوون‌ها مهاجرت می‌کنن؟", "question"),
        ("اقیانوس‌ها چقدر عمیقن؟", "question"),
        ("چرا زمان تو فضا متفاوت می‌گذره؟", "question"),
        ("هوش مصنوعی چه فرقی با انسان داره؟", "question"),
        ("چرا بعضی زبان‌ها از راست به چپ نوشته می‌شن؟", "question"),
        ("می‌خوام از یه نفر رسمی عذرخواهی کنم", "planning"),
        ("ممنونم که همیشه کمکم می‌کنی", "casual"),
        ("امروز یکی بهم خیلی کمک کرد و قدردانم", "celebration"),
        ("چطور یه عذرخواهی صمیمانه بنویسم؟", "question"),
        ("بچه‌ام امروز اذیت می‌کرد و خسته شدم", "venting"),
        ("چطور با بچه‌ام بهتر ارتباط برقرار کنم؟", "question"),
        ("امروز بچه‌ام یه چیز جدید یاد گرفت و خیلی خوشحالم", "celebration"),
        ("یه کتاب خوب برای تعطیلات پیشنهاد بده", "question"),
        ("این سریال رو تموم کردم و دلم گرفته که تموم شد", "sharing"),
        ("دنبال یه فیلم ترسناک خوبم", "question"),
        ("این کتابی که می‌خوندم خیلی عمیق بود", "sharing"),
        ("امروز روز خیلی بدی بود", "venting"),
        ("همه چیز داره روی هم جمع می‌شه", "venting"),
        ("نمی‌دونم چرا امروز اینقدر بی‌حوصله‌ام", "venting"),
        ("حس می‌کنم دارم عقب می‌مونم از همه", "venting"),
        ("امروز ترافیک خیلی اذیتم کرد", "venting"),
        ("گوشیم افتاد و صفحه‌اش ترک خورد", "venting"),
        ("کارت بانکیم گم شده و نگرانم", "venting"),
        ("امروز یه روز آروم و خوب بود", "sharing"),
        ("بالاخره یه روز بدون استرس داشتم", "celebration"),
        ("حوصله‌ام سر رفته یه چیزی بگو بخندم", "casual"),
        ("یه ضرب‌المثل قشنگ بگو", "casual"),
        ("یه جمله انگیزشی برام بگو", "casual"),
        ("می‌خوام انگلیسیم رو تقویت کنم", "learning"),
        ("چطور لغات جدید رو بهتر به خاطر بسپارم؟", "question"),
        ("امروز تونستم یه مکالمه کامل انگلیسی انجام بدم", "celebration"),
        ("گرامر زبان جدید برام گیج‌کننده‌ست", "venting"),
        ("چه روشی برای یادگیری زبان سریع‌تره؟", "question"),
        ("می‌خوام یه زبان جدید غیر از انگلیسی یاد بگیرم", "planning"),
        ("جاوا یا پایتون برای شروع بهتره؟", "question"),
        ("ری‌اکت یاد گرفتنش سخته؟", "question"),
        ("چطور یه API با فلسک بسازم؟", "technical"),
        ("پروژه جاوااسکریپتم مموری لیک داره", "technical"),
        ("چطور کد تمیزتر بنویسم؟", "question"),
        ("SQL query من خیلی کند اجرا می‌شه", "technical"),
        ("چطور یونیت تست برای پروژه بنویسم؟", "learning"),
        ("گیت‌هاب اکشن‌هام fail می‌شن", "technical"),
        ("چطور یه پروژه اوپن‌سورس شروع کنم؟", "planning"),
        ("درباره پس‌انداز کردن باهام حرف بزن", "question"),
        ("چطور عادت خرج کردن بی‌رویه رو کنار بذارم؟", "question"),
        ("امروز یه هدف مالی کوچیک برام محقق شد", "celebration"),
        ("روش پومودورو چیه و چطور کار می‌کنه؟", "question"),
        ("چطور یادداشت‌برداری بهتری داشته باشم؟", "question"),
        ("حافظه کوتاه‌مدتم ضعیفه، راهکاری هست؟", "question"),
        ("امروز با یه روش جدید درس خوندم و جواب داد", "celebration"),
        ("تو یه بازی گیر کردم و رد نمی‌شم", "venting"),
        ("امروز بالاخره یه باس سخت رو شکست دادم", "celebration"),
        ("دنبال یه بازی چندنفره خوبم", "question"),
        ("چرا بعضی بازی‌ها اینقدر اعتیادآورن؟", "question"),
        ("می‌خوام شروع کنم به استریم کردن بازی", "planning"),
        ("برف اومده و همه چی سفیده، خیلی قشنگه", "sharing"),
        ("این چند روز هوا ابری بوده و حس‌وحالم گرفته‌ست", "venting"),
        ("عاشق فصل پاییزم", "sharing"),
        ("همخونه‌ام باهام هماهنگ نیست و اذیت‌کننده شده", "venting"),
        ("همسایه‌مون سروصدای زیادی می‌کنه", "venting"),
        ("با همخونه‌ام یه برنامه مشترک خوب چیدیم", "celebration"),
        ("نمی‌دونم رشته دانشگاهیم رو عوض کنم یا نه", "venting"),
        ("بین موندن تو این شهر یا رفتن مردد‌م", "venting"),
        ("یه تصمیم بزرگ گرفتم و هنوز نگرانم درست بوده یا نه", "venting"),
        ("بالاخره یه تصمیم سخت رو گرفتم و آرومم", "celebration"),
        ("می‌خوام شروع کنم به نوشتن روزانه", "planning"),
        ("یه شعر کوتاه درباره دوستی بگو", "creative"),
        ("چطور برای داستانم شخصیت بسازم؟", "question"),
        ("امروز یه متن نوشتم که خودم ازش خوشم اومد", "celebration"),
        ("فرق بین این دو کلمه چیه؟", "question"),
        ("این اصطلاح یعنی چی؟", "question"),
        ("چطور یه جمله رسمی‌تر بنویسم؟", "question"),
        ("این متن رو خلاصه کن", "question"),
        ("این جمله رو بهتر می‌تونی بنویسی؟", "question"),
        ("ممنون بابت کمکت، خیلی به دردم خورد", "casual"),
        ("امروز حرفات واقعا کمکم کرد", "casual"),
        ("خیلی خوب توضیح دادی، ممنون", "casual"),
        ("امروز حس می‌کنم هیچی درست پیش نمی‌ره", "venting"),
        ("یه حس بدی دارم ولی نمی‌دونم دلیلش چیه", "venting"),
        ("امروز خیلی آروم و راضی‌ام", "sharing"),
        ("دلم می‌خواد یکم با خودم خلوت کنم", "sharing"),
        ("امروز یه خبر غیرمنتظره شنیدم و هنوز شوکه‌ام", "sharing"),
        ("نمی‌دونم باید خوشحال باشم یا نگران", "venting"),
        ("امروز یاد یه خاطره قدیمی افتادم و دلتنگ شدم", "sharing"),
        ("حس می‌کنم دارم زیادی به همه چیز فکر می‌کنم", "venting"),
        ("امروز یکی بهم گفت بهم افتخار می‌کنه", "celebration"),
        ("از تنهایی این روزا خسته شدم", "venting"),
        ("اپلیکیشنم روی گوشیای مختلف رفتار متفاوتی داره", "technical"),
        ("بعد آپدیت، برنامه‌ام کرش می‌کنه", "technical"),
        ("چطور یه اپ رو برای آیفون هم منتشر کنم؟", "question"),
        ("نوتیفیکیشن‌های اپم درست نمایش داده نمی‌شن", "technical"),
        ("چطور سرعت لود اپلیکیشنم رو بهتر کنم؟", "question"),
        ("می‌خوام هفته‌ام رو از قبل برنامه‌ریزی کنم", "planning"),
        ("لیست کارهام خیلی طولانیه، از کجا شروع کنم؟", "planning"),
        ("چطور بین چند پروژه همزمان تعادل نگه دارم؟", "planning"),
        ("امروز تونستم طبق برنامه پیش برم، خوشحالم", "celebration"),
        ("چرا آتشفشان‌ها فوران می‌کنن؟", "question"),
        ("چرا بعضی آدما چپ‌دستن؟", "question"),
        ("خواب دیدن چه فایده‌ای داره؟", "question"),
        ("چرا موسیقی روی حس آدم اینقدر تاثیر داره؟", "question"),
        ("رنگین‌کمان چطور تشکیل می‌شه؟", "question"),
        ("چرا بعضی زبون‌ها منقرض می‌شن؟", "question"),
        ("نمی‌دونم چطور احساسم رو به یه نفر بگم", "venting"),
        ("یه رابطه‌ام تازه تموم شده و خیلی سخته", "venting"),
        ("امروز یه قرار خوب داشتم", "celebration"),
        ("چطور بفهمم یه رابطه سالمه یا نه؟", "question"),
        ("امروز صبح دیر از خواب بیدار شدم و همه‌چی به‌هم ریخت", "venting"),
        ("اتوبوس رو جا گذاشتم و مجبور شدم پیاده برم", "venting"),
        ("امروز یه غریبه بهم خیلی محبت کرد", "sharing"),
        ("موبایلم رو جایی گم کردم و پیدا نمی‌کنم", "venting"),
        ("امروز یه چیز جدید امتحان کردم که همیشه ازش می‌ترسیدم", "celebration"),
        ("نمی‌دونم چرا امروز همه چی رو منفی می‌بینم", "venting"),
        ("یه هدیه غیرمنتظره گرفتم امروز", "celebration"),
        ("دلم می‌خواد یه روز کامل فقط استراحت کنم", "sharing"),
        ("امروز یه فرصت خوب از دست دادم و ناراحتم", "venting"),
        ("بالاخره یه کار قدیمی رو که معطل مونده بود تموم کردم", "celebration"),
        ("چطور بفهمم دارم زیادی به خودم سخت می‌گیرم؟", "question"),
        ("امروز یاد گرفتم چطور نه بگم به کاری که نمی‌خواستم", "celebration"),
        ("حس می‌کنم باید یه تغییر بزرگ تو زندگیم بدم", "venting"),
        ("یه دوست قدیمی امروز بهم پیام داد و خیلی خوشحال شدم", "celebration"),
        ("امروز یه چیزی خوندم که دیدم زندگیم رو عوض کرد", "sharing"),
        ("چرا بعضی روزا همه چی سخت‌تر از همیشه‌ست؟", "venting"),
        ("امروز به خودم افتخار کردم", "celebration"),
        ("یه اشتباه کردم و نمی‌دونم چطور جبرانش کنم", "venting"),
        ("امروز یکی از رویاهام یه قدم نزدیک‌تر شد", "celebration"),
        ("چطور با آدمای سمی تو زندگیم برخورد کنم؟", "question"),
    ]

    BOOTSTRAP_CONVERSATIONS = [
        ["سلام، امروز خیلی خسته‌ام.", "می‌فهمم. اگر دوست داری می‌تونیم فقط کمی حرف بزنیم.", "آره، فعلاً فقط می‌خوام یکی گوش بده."],
        ["از رفتار دوستم ناراحتم.", "می‌خوای بیشتر درباره اتفاقی که افتاد بگی؟", "آره، چون انتظارش رو نداشتم و دلم گرفته."],
        ["خیلی خوشحالم، بالاخره پروژه‌ام اجرا شد!", "چه خوب! معلومه برایش زحمت کشیدی.", "آره، حالا می‌خوام چند قابلیت جدید هم اضافه کنم."],
        ["یه باگ عجیب توی پایتون دارم.", "خطا یا رفتار غیرمنتظره‌اش رو بفرست.", "فقط یک بار اجرا می‌شه و بعد دکمه غیرفعال می‌مونه."],
        ["می‌خوام پایتون یاد بگیرم.", "الان در چه سطحی هستی؟", "مقدماتی‌ام و بیشتر با گوشی تمرین می‌کنم."],
        ["برای فردا کلی کار دارم.", "مهم‌ترین کارها کدوم‌اند؟", "درس، پروژه و کمی استراحت؛ نمی‌خوام همه‌اش روی هم بریزه."],
        ["یک ایده برای بازی دارم.", "چه سبکی در ذهنته؟", "یک بازی ساده لمسی با پیشرفت مرحله‌ای."],
        ["امروز یک اتفاق عجیب افتاد.", "از اولش برام تعریف کن.", "صبح شروع شد و بعد یک تماس همه چیز رو عوض کرد."],
        ["می‌خوام درباره هوش مصنوعی بیشتر بدونم.", "بیشتر کدوم بخشش برات جالبه؟", "اینکه چطور از مکالمه‌های قبلی الگو یاد می‌گیره."],
        ["گوشی موقع اجرای برنامه داغ می‌کنه.", "چه بخشی بیشتر CPU یا حافظه مصرف می‌کنه؟", "وقتی GUI و چند کار همزمان بازه بیشتر می‌شه."],
        ["برای یک سفر کوتاه برنامه می‌خوام.", "مقصد و مدت سفر چقدره؟", "دو روزه و بودجه‌ام هم محدوده."],
        ["بین دو وسیله برای خرید مرددم.", "قیمت و کیفیت هر دو رو مقایسه کنیم؟", "آره، دوام برام مهم‌تر از ظاهرشه."],
        ["برای شام چیز ساده می‌خوام.", "مواد اصلی که داری چیه؟", "تخم‌مرغ، سیب‌زمینی و چند سبزی دارم."],
        ["نگران امتحانم.", "بیشتر از سختی درس نگرانی یا کمبود زمان؟", "بیشتر از این می‌ترسم که چیزهایی که خوندم یادم بره."],
        ["امروز حس تنهایی دارم.", "می‌خوای درباره چیزی که اذیتت می‌کنه حرف بزنیم؟", "آره، فقط فعلاً دنبال راه‌حل نیستم."],
        ["می‌خوام یک پروژه بزرگ رو تمیزتر کنم.", "اول ساختار فایل‌ها و مسئولیت هر ماژول رو مشخص کنیم؟", "آره، الان core خیلی شلوغ شده."],
        ["چرا آسمون آبیه؟", "می‌خوای ساده توضیح بدم یا علمی‌تر؟", "اول ساده، بعد اگر جالب بود عمیق‌ترش کنیم."],
        ["یک فیلم دیدم که پایانش عجیب بود.", "کدوم بخش پایان بیشتر ذهنت رو درگیر کرد؟", "اینکه معلوم نبود تصمیم شخصیت اصلی درست بوده یا نه."],
        ["می‌خوام عادت کتاب خوندن بسازم.", "روزانه چه مقدار زمان واقع‌بینانه داری؟", "حدود بیست دقیقه، ولی بعضی روزها انرژی ندارم."],
        ["می‌خوام کنترل لمسی بازی رو بهتر کنم.", "مشکل بیشتر دقت لمسه یا چیدمان دکمه‌ها؟", "هر دو؛ مخصوصاً روی صفحه کوچک."],
        ["از یک تصمیم مطمئن نیستم.", "می‌خوای مزایا و معایب دو گزینه رو کنار هم بذاریم؟", "آره، ولی آخرش تصمیم با خودم باشه."],
        ["یک خاطره قدیمی یادم افتاده.", "دوست داری تعریفش کنی؟", "آره، جزئیاتش رو هم یادم هست."],
        ["می‌خوام برنامه‌ام بدون اینترنت هم تا حد ممکن کار کنه.", "کدام قابلیت‌ها باید کاملاً محلی باشند؟", "مکالمه ساده، حافظه و ابزارهای پایه."],
        ["اگر ناراحت بودم سریع نصیحت نکن.", "باشه؛ اول می‌شنوم و احساس حرفت رو می‌فهمم.", "همین باعث می‌شه راحت‌تر حرف بزنم."],
        # --- v5 broad-corpus expansion ---
        ["امروز خیلی خسته شدم.", "می‌فهمم. اگه دوست داری یکم استراحت کن، من اینجام هر وقت خواستی حرف بزن.", "آره فقط می‌خوام یکم دراز بکشم و بعد برگردم."],
        ["رئیسم امروز سرم داد زد.", "چقدر سخته این حس؛ می‌خوای بگی دقیقاً چی شد؟", "یه اشتباه کوچیک بود ولی خیلی بد برخورد کرد."],
        ["فردا امتحان دارم و استرس دارم.", "طبیعیه. چقدر برات مونده که مرور کنی؟", "هنوز دو فصل مونده و وقت کمه."],
        ["دیشب اصلا نخوابیدم.", "چه بد. چیزی ذهنت رو درگیر کرده بود؟", "آره، یه فکر مدام تو سرم بود."],
        ["می‌خوام ورزش رو شروع کنم ولی انگیزه ندارم.", "شروع همیشه سخت‌تر از ادامه‌دادنه. یه قدم کوچیک برات چیه؟", "شاید فقط یه پیاده‌روی کوتاه، همین."],
        ["گربه‌ام مریض شده.", "چقدر نگران‌کننده‌ست. دامپزشک دیدتش؟", "هنوز نه، فردا می‌برمش."],
        ["خونه‌ام خیلی به‌هم ریخته.", "گاهی شروع از یه گوشه کوچیک کمک می‌کنه. از کجا دوست داری شروع کنی؟", "شاید از اتاقم شروع کنم."],
        ["آخر ماهه و پولم ته کشیده.", "این ماه‌ها واقعاً استرس‌زان. چیز فوری‌ای پیش اومده؟", "نه فقط هزینه‌های عادی زیاد بودن."],
        ["امروز هوا خیلی سرده.", "لباس گرم پوشیدی؟ این هفته قراره سردتر هم بشه.", "آره ولی بازم سردمه."],
        ["نوروز داره نزدیک می‌شه.", "چه هیجان‌انگیز! برنامه خاصی داری؟", "می‌خوام خونه رو کامل بچینم."],
        ["با خواهرم دعوام شد.", "دعوای خانوادگی همیشه سنگینه. می‌خوای بگی چی شد؟", "سر یه موضوع کوچیک شروع شد ولی بزرگ شد."],
        ["تو جمع خجالت می‌کشم حرف بزنم.", "خیلیا این حس رو دارن. تو چه موقعیت‌هایی بیشتر اذیتت می‌کنه؟", "بیشتر تو جمع‌های جدید."],
        ["می‌خوام گیتار یاد بگیرم.", "عالیه! قبلاً هیچ سازی زدی؟", "نه، کاملاً از صفر شروع می‌کنم."],
        ["دیشب بازی تیممون رو باختیم.", "چقدر ناراحت‌کننده. بازی نزدیک بود؟", "آره، تا دقیقه آخر امید داشتیم."],
        ["لپ‌تاپم خیلی کند شده.", "چند وقته این‌طوریه؟ اخیراً برنامه جدیدی نصب کردی؟", "آره چند روزه یه برنامه سنگین نصب کردم."],
        ["بین دو تا گوشی مونده‌ام.", "چه چیزی برات مهم‌تره، دوربین یا باتری؟", "بیشتر باتری، چون زیاد بیرونم."],
        ["می‌خوام یه دسر ساده درست کنم.", "چه موادی الان تو خونه داری؟", "تخم‌مرغ، آرد و شکلات دارم."],
        ["می‌خوام برای اولین بار تنها سفر کنم.", "چه هیجان‌انگیز و چه استرس‌زا هم‌زمان! مقصد رو انتخاب کردی؟", "هنوز مطمئن نیستم، دارم گزینه‌ها رو می‌سنجم."],
        ["حس می‌کنم هیچ پیشرفتی نمی‌کنم.", "این حس گاهی حتی وقتی داری پیشرفت می‌کنی هم میاد. چی باعث شده این‌طوری فکر کنی؟", "انگار هر روز همون چرخه‌ی تکراریه."],
        ["چرا شب‌ها ستاره‌ها رو می‌بینیم ولی روزها نه؟", "می‌خوای ساده توضیح بدم یا کمی علمی‌تر؟", "اول ساده، بعد اگه جالب بود بیشتر بگو."],
        ["می‌خوام از یه نفر عذرخواهی کنم.", "چه اتفاقی افتاده که می‌خوای عذرخواهی کنی؟", "یه حرفی زدم که ناراحتش کرد و پشیمونم."],
        ["بچه‌ام امروز اذیت می‌کرد.", "روزای سخت با بچه‌ها طبیعیه. الان حالت چطوره؟", "خسته‌ام ولی الان که آروم شده بهترم."],
        ["یه سریال رو تموم کردم و دلم گرفته.", "این حس آشناست، وقتی یه داستان خوب تموم می‌شه. چیزی که بیشتر دوست داشتی چی بود؟", "شخصیت اصلیش، خیلی واقعی بود."],
        ["امروز روز خیلی بدی بود.", "متاسفم که این‌طور بوده. می‌خوای بگی چی گذشت یا فقط می‌خوای یکم آروم بشی؟", "فعلاً فقط می‌خوام یکم آروم بشم."],
        ["جاوا یا پایتون برای شروع بهتره؟", "بستگی داره هدفت چیه؛ می‌خوای وب بسازی یا داده تحلیل کنی؟", "بیشتر می‌خوام برنامه‌های ساده بنویسم."],
        ["می‌خوام انگلیسیم رو تقویت کنم.", "الان بیشتر رو کدوم مهارت ضعیف‌تری؟ شنیداری، گفتاری یا نوشتاری؟", "بیشتر تو مکالمه‌ی روون مشکل دارم."],
        ["تو یه بازی گیر کردم و رد نمی‌شم.", "کدوم قسمتش سخت‌ترین بخشه؟", "یه باس آخر که خیلی سریع حمله می‌کنه."],
        ["نمی‌دونم رشته دانشگاهیم رو عوض کنم یا نه.", "این تصمیم واقعاً بزرگیه. چی باعث شده به تغییر فکر کنی؟", "حس می‌کنم دیگه علاقه‌ی قبل رو ندارم."],
        ["همخونه‌ام باهام هماهنگ نیست.", "چه چیزی بیشتر باعث دردسر شده، نظافت یا هزینه‌ها؟", "بیشتر سر نظافت و سروصدا."],
        ["امروز یکی بهم گفت بهم افتخار می‌کنه.", "چه حس قشنگی! کی این حرف رو بهت زد؟", "یکی از نزدیک‌ترین دوستام بود."],
    ]

    @classmethod
    def _bootstrap_pattern(cls, text: str, label: str, index: int) -> dict:
        p = cls.build_pattern([
            {"role": "user", "content": text},
            {"role": "assistant", "content": ""},
        ], source="builtin") or {}
        # Preserve the intended broad category when cue scoring is ambiguous.
        if label and label not in {"general", "casual"}:
            p["type"] = label
        p["id"] = f"builtin_{index:04d}"
        p["strength"] = 0.52
        p["source"] = "builtin"
        p["signals"] = [text]
        # امضا باید *بعد* از بازنویسیِ احتمالیِ type دوباره محاسبه شود، وگرنه
        # با فیلدهایِ واقعیِ همین الگو ناسازگار می‌ماند.
        p["signature"] = cls.signature(p)
        return p

    def _bootstrap(self):
        """Seed broad, dependency-free conversational experience once per DB."""
        version = self.db.get_profile(self.BOOTSTRAP_KEY, "")
        if version == self.BOOTSTRAP_VERSION:
            return
        # Keep user-learned patterns; only add the built-in baseline if missing.
        existing_ids = {p.get("id") for p in self.patterns}
        added = 0
        for i, (text, label) in enumerate(self.BOOTSTRAP_SEEDS, 1):
            pid = f"builtin_{i:04d}"
            if pid in existing_ids:
                continue
            self.patterns.append(self._bootstrap_pattern(text, label, i))
            added += 1

        base = len(self.BOOTSTRAP_SEEDS)
        for j, convo in enumerate(self.BOOTSTRAP_CONVERSATIONS, 1):
            pid = f"builtin_conv_{j:03d}"
            if pid in existing_ids:
                continue
            pattern = self.build_pattern(
                [{"role": "user" if i % 2 == 0 else "assistant", "content": text}
                 for i, text in enumerate(convo)],
                source="builtin",
            )
            if pattern:
                pattern["id"] = pid
                pattern["strength"] = 0.60
                pattern["source"] = "builtin"
                pattern["signals"] = [x for i, x in enumerate(convo) if i % 2 == 0][-5:]
                self.patterns.append(pattern)
                added += 1

        self.patterns = self.patterns[-self.MAX_PATTERNS:]
        self.db.set_profile(self.BOOTSTRAP_KEY, self.BOOTSTRAP_VERSION)
        self._save()

    def __init__(self, db):
        self.db = db
        self.patterns: List[dict] = []
        self.utterance_patterns: List[dict] = []
        self.turn_buffer: List[Dict[str, str]] = []
        self.turns_since_learn = 0
        self._load()
        self._bootstrap()

    def _load(self):
        raw = self.db.get_profile(self.KEY, "[]")
        try:
            data = json.loads(raw) if raw else []
            # v2 stored a plain list. Keep it as learned multi-turn patterns.
            if isinstance(data, dict):
                self.patterns = data.get("patterns", []) or []
                self.utterance_patterns = data.get("utterance_patterns", []) or []
            else:
                self.patterns = data if isinstance(data, list) else []
        except (TypeError, json.JSONDecodeError):
            self.patterns = []

    def _save(self):
        self.patterns = self.patterns[-self.MAX_PATTERNS:]
        self.utterance_patterns = self.utterance_patterns[-self.MAX_UTTERANCE_PATTERNS:]
        payload = {"patterns": self.patterns, "utterance_patterns": self.utterance_patterns}
        self.db.set_profile(self.KEY, json.dumps(payload, ensure_ascii=False))

    def observe(self, role: str, content: str, user_state: Optional[str] = None) -> Optional[dict]:
        """
        ``user_state``: خروجیِ اختیاریِ ``trx_ai.nlu.user_state.detect(...)``
        برایِ همین پیام (فقط برایِ ``role="user"`` معنا دارد). کاملاً
        اختیاری -- صدازننده‌ای که این موتور را نمی‌شناسد (کدِ قدیمی) هنوز
        بدونِ تغییر کار می‌کند؛ فقط فیلدِ ``user_state`` پترن‌هایِ جدید
        ``None``/``"unknown"`` می‌ماند.
        """
        content = self._normalize(content)
        self.turn_buffer.append({"role": role, "content": content or ""})
        self.turn_buffer = self.turn_buffer[-(self.WINDOW_TURNS * 2):]

        # Every user utterance becomes a compact learned pattern. This is the
        # user's requested "list of patterns": each line is preserved with
        # its conversational meaning, emotion, need and topics.
        if role == "user" and content:
            self.turns_since_learn += 1
            # زمینه = نوبت‌هایِ *قبل* از همین گفته (خودِ گفته را که همین الان
            # به turn_buffer اضافه شد، حساب نمی‌کنیم).
            context_text = " ".join(
                t["content"] for t in self.turn_buffer[:-1] if t["role"] == "user"
            )[-400:]
            up = self._utterance_pattern(
                content, len(self.utterance_patterns), context_text=context_text, user_state=user_state,
            )
            # اطمینانِ نهایی: ترکیبِ اطمینانِ لغویِ همین یک پیام با تکرارِ
            # تاریخیِ همین امضا -- اگر این «نوع رفتار» از این کاربر قبلاً
            # چند بار دیده شده، اطمینانِ برچسب حتی برایِ یک جمله‌ی نسبتاً
            # مبهم هم بالاتر می‌رود (سابقه چیزی است که خودِ متن به‌تنهایی
            # ندارد).
            repeat_count = self.signature_frequency(up["signature"])
            history_conf = min(1.0, repeat_count / 5.0)
            up["repeat_count"] = repeat_count
            up["confidence"] = round(0.65 * up["confidence"] + 0.35 * history_conf, 3)
            self.utterance_patterns.append(up)
            self.utterance_patterns = self.utterance_patterns[-self.MAX_UTTERANCE_PATTERNS:]
            self._save()

        # Multi-turn patterns are still learned periodically from the whole
        # window so individual utterances do not replace conversation-level learning.
        if self.turns_since_learn >= 3 and role in {"user", "assistant"}:
            self.turns_since_learn = 0
            pattern = self.build_pattern(self.turn_buffer, user_state=user_state)
            if pattern:
                self.add(pattern)
                return pattern
        return None

    def signature_frequency(self, sig: str, within: int = 300) -> int:
        """
        تعدادِ دفعاتی که امضایِ ``sig`` در ``within`` گفته‌یِ اخیرِ کاربر
        تکرار شده -- مبنایِ مؤلفه‌یِ «سابقه» در Confidence و برایِ نمایشِ
        «این عادتِ گفتاریِ شناخته‌شده‌ای است» در ``prompt_context``.
        """
        return sum(1 for u in self.utterance_patterns[-within:] if u.get("signature") == sig)

    def _recent_context_text(self, n: int = 3) -> str:
        """آخرین ``n`` گفته‌یِ کاربر در نشستِ جاری، برایِ context embedding."""
        user_msgs = [t["content"] for t in self.turn_buffer if t["role"] == "user"]
        return " ".join(user_msgs[-n:])

    def _recent_act_sequence(self) -> List[str]:
        """توالیِ کنش‌هایِ گفتاریِ کاربر در پنجره‌یِ جاری، برایِ Sequence Matching."""
        return [self.dialogue_act(t["content"]) for t in self.turn_buffer if t["role"] == "user"]

    def recent_utterance_patterns(self, limit: int = 12) -> List[dict]:
        return list(reversed(self.utterance_patterns[-max(1, limit):]))

    def relevant_utterance_patterns(self, query: str, limit: int = 12) -> List[dict]:
        """
        بازیابیِ گفته‌هایِ کاربر که واقعاً به ``query`` *معنایی* نزدیک‌اند --
        از کلِ تاریخچه (تا ``MAX_UTTERANCE_PATTERNS``)، نه فقط N موردِ آخر.

        قبل از این متد، ``prompt_context`` فقط آخرین ۱۲ گفته را (بدونِ توجه
        به ربطشان به پیامِ فعلی) نشان می‌داد. اینجا اگر لایه‌ی embedding
        فعال باشد، شباهتِ کسینوسیِ هر گفته با پیامِ فعلی محاسبه و مرتب
        می‌شود -- یعنی مثلاً اگر کاربر الان دوباره درباره‌ی همان موضوعِ
        هفته‌ی پیش حرف بزند، آن گفته‌ی قدیمی (حتی اگر جزوِ ۱۲ موردِ آخر
        نباشد) دوباره پیدا می‌شود. بدونِ پکیجِ اختیاری، دقیقاً به
        ``recent_utterance_patterns`` (رفتارِ قبلی) سقوط می‌کند.
        """
        if not _semantic_backend.is_available() or not self.utterance_patterns:
            return self.recent_utterance_patterns(limit)

        query_vec = _semantic_backend.encode(query)
        if query_vec is None:
            return self.recent_utterance_patterns(limit)

        import numpy as _np

        candidates = self.utterance_patterns[-400:]  # سقفِ عملیِ محاسبه؛ به‌اندازه‌ی کافی طولانی
        scored = []
        q_norm = query_vec / (_np.linalg.norm(query_vec) + 1e-9)
        for idx, u in enumerate(candidates):
            vec = _semantic_backend.str_to_vector(u.get("emb")) if u.get("emb") else None
            if vec is None:
                continue
            sim = float(_np.dot(q_norm, vec / (_np.linalg.norm(vec) + 1e-9)))

            # Context embedding -- شباهتِ اضافیِ کوچک اگر موقعیتی که این
            # گفته در آن زده شده هم به پیامِ فعلی نزدیک باشد؛ جایگزینِ
            # شباهتِ محتوایی نمی‌شود، فقط آن را تقویت می‌کند.
            ctx_vec = _semantic_backend.str_to_vector(u.get("context_emb")) if u.get("context_emb") else None
            if ctx_vec is not None:
                ctx_sim = float(_np.dot(q_norm, ctx_vec / (_np.linalg.norm(ctx_vec) + 1e-9)))
                sim = sim * 0.8 + ctx_sim * 0.2

            # کمی تازگی را هم به شباهتِ معنایی اضافه می‌کنیم تا رفتارِ اخیر
            # همچنان بر رفتارِ خیلی قدیمی اولویت داشته باشد.
            recency_bonus = (idx / max(1, len(candidates) - 1)) * 0.08

            # Confidence -- گفته‌یِ کاملاً مبهم (اطمینانِ پایین) کمی وزنش در
            # بازیابی کم می‌شود؛ بدونِ حذفِ کامل (هنوز می‌تواند بازیابی شود
            # اگر شباهتش خیلی بالاست).
            conf_weight = 0.85 + 0.15 * float(u.get("confidence", 1.0))
            scored.append((sim * conf_weight + recency_bonus, u))

        if not scored:
            return self.recent_utterance_patterns(limit)

        scored.sort(key=lambda x: x[0], reverse=True)
        return [u for sim, u in scored[:limit] if sim > 0.25] or self.recent_utterance_patterns(limit)

    # ------------------------------------------------------------------
    #   گزارشِ درصدیِ حال‌وهوایِ گفتگو (موتورِ جدید)
    # ------------------------------------------------------------------
    # قبلاً `emotion_profile`/`_emotion`/`_conversation_type` فقط برایِ
    # *یک* پیام در لحظه محاسبه می‌شدند و فقط داخلی مصرف می‌شدند (تصمیمِ
    # لحن/راهبرد، هرگز به کاربر نشان داده نمی‌شدند). اینجا با تجمیعِ
    # همان برچسب‌هایی که هر پیامِ کاربر از قبل ذخیره کرده (utterance_patterns
    # در دیتابیس، نه فقط حافظه‌ی این نشست)، یک گزارشِ درصدی از *کلِ*
    # گفتگویِ اخیر ساخته می‌شود: چند درصد پرسش/جواب بوده، چند درصد درد دل
    # (venting)، چند درصد جشن/خوشحالی، و ترکیبِ احساساتِ غالب.
    @staticmethod
    def _as_percentages(counter: Counter, total: int) -> Dict[str, float]:
        if not total:
            return {}
        return {k: round(v / total * 100, 1) for k, v in counter.items()}

    def mood_report(self, limit: int = 30) -> Dict:
        """
        درصدِ نوع/احساسِ پیام‌هایِ اخیرِ کاربر (نه فقط آخرین پیام). خروجی
        شاملِ: تعدادِ پیام‌هایِ بررسی‌شده، درصدِ هر نوعِ گفتگو (پرسش،
        درد دل، جشن، فنی، ...)، درصدِ هر احساس (ناراحت، خوشحال، عصبانی،
        نگران، ...)، و سه شاخصِ خلاصه‌شده‌ی پرکاربرد: `qa_pct` (پرسش/جواب)،
        `venting_pct` (درد دل/نیازِ حمایتِ احساسی) و `celebration_pct`
        (جشن/خوشحالی). اگر هنوز پیامی ثبت نشده، `{"total": 0}` برمی‌گردد.
        """
        recent = self.recent_utterance_patterns(limit=limit)
        total = len(recent)
        if not total:
            return {"total": 0}

        type_counter = Counter(u.get("type", "general") for u in recent)
        emotion_counter = Counter(u.get("emotion", "neutral") for u in recent)
        act_counter = Counter(u.get("dialogue_act", "statement") for u in recent)

        venting_count = sum(
            1 for u in recent
            if u.get("type") == "venting" or u.get("need") == "emotional_support"
        )
        qa_count = sum(
            1 for u in recent
            if u.get("dialogue_act") == "question" or u.get("type") == "question"
        )
        celebration_count = sum(
            1 for u in recent
            if u.get("type") == "celebration" or u.get("emotion") in {"happy", "excited"}
        )

        return {
            "total": total,
            "types_pct": self._as_percentages(type_counter, total),
            "emotions_pct": self._as_percentages(emotion_counter, total),
            "acts_pct": self._as_percentages(act_counter, total),
            "qa_pct": round(qa_count / total * 100, 1),
            "venting_pct": round(venting_count / total * 100, 1),
            "celebration_pct": round(celebration_count / total * 100, 1),
        }

    _LABELS_FA = {
        # types
        "venting": "درد دل", "celebration": "جشن/خوشحالی", "technical": "فنی",
        "planning": "برنامه‌ریزی", "storytelling": "خاطره‌گویی", "question": "پرسش",
        "casual": "گپ روزمره", "learning": "یادگیری", "creative": "خلاقانه",
        "relationships": "روابط", "general": "عمومی",
        # emotions
        "sad": "ناراحتی", "happy": "خوشحالی", "angry": "عصبانیت",
        "anxious": "نگرانی", "grateful": "قدردانی", "confused": "سردرگمی",
        "excited": "هیجان", "hopeful": "امیدواری", "neutral": "خنثی",
        # acts
        "request": "درخواست", "sharing": "به‌اشتراک‌گذاری", "gratitude": "قدردانی",
        "agreement": "موافقت", "disagreement": "مخالفت", "continuation": "ادامه‌ی گفتگو",
        "statement": "بیانِ ساده",
    }

    def format_mood_report(self, limit: int = 30) -> str:
        """نسخه‌ی متنیِ آماده‌ی نمایش به کاربر، با اعداد به‌صورتِ درصد."""
        report = self.mood_report(limit=limit)
        if not report.get("total"):
            return "📊 هنوز گفتگویی برایِ تحلیل ثبت نشده؛ چند پیام رد و بدل کن، بعد دوباره بپرس."

        def top_lines(pct_map: Dict[str, float], n: int = 6) -> List[str]:
            ranked = sorted(pct_map.items(), key=lambda kv: kv[1], reverse=True)[:n]
            return [f"  • {self._LABELS_FA.get(k, k)}: {v}%" for k, v in ranked if v > 0]

        lines = [f"📊 **تحلیلِ حال‌وهوایِ گفتگو** (بر پایه‌ی {report['total']} پیامِ اخیرِ تو)\n"]
        lines.append(f"❓ پرسش/جواب: {report['qa_pct']}%")
        lines.append(f"💬 درد دل: {report['venting_pct']}%")
        lines.append(f"🎉 جشن/خوشحالی: {report['celebration_pct']}%\n")
        lines.append("🎭 ترکیبِ احساسات:")
        lines.extend(top_lines(report["emotions_pct"]))
        lines.append("\n🗂️ نوعِ گفتگو:")
        lines.extend(top_lines(report["types_pct"]))
        lines.append(
            "\n⚠️ این یک تخمینِ لغویِ ساده است (بر اساسِ کلیدواژه‌ها)، نه "
            "تشخیصِ روان‌شناختی؛ اگر حسِ واقعیت با این عدد فرق دارد، حرفِ خودت درست‌تر است."
        )
        return "\n".join(lines)

    def add(self, pattern: dict):
        for old in self.patterns:
            # Never merge a real learned/user pattern into the generic built-in
            # corpus. Built-ins are a baseline; learned experience must remain
            # individually addressable and can therefore outrank the baseline.
            if old.get("source") == "builtin" and pattern.get("source") != "builtin":
                continue
            same_type = old.get("type") == pattern.get("type")
            same_need = old.get("need") == pattern.get("need")
            overlap = set(old.get("topics", [])) & set(pattern.get("topics", []))
            if same_type and (same_need or len(overlap) >= 1):
                old["topics"] = list(dict.fromkeys(old.get("topics", []) + pattern.get("topics", [])))[:12]
                old["strategy"] = pattern.get("strategy", old.get("strategy"))
                old["emotion_profile"] = pattern.get("emotion_profile", old.get("emotion_profile", {}))
                old["arc"] = pattern.get("arc", old.get("arc"))
                old["strength"] = min(1.0, float(old.get("strength", .6)) + .045)
                # همگرایی/تکرار خودش شکلی از شواهد است: هر بار که یک الگویِ
                # جدید با همین نوع/نیاز/موضوع ادغام می‌شود، اطمینان کمی
                # بالا می‌رود.
                old["confidence"] = round(min(1.0, float(old.get("confidence", 0.5)) + .04), 3)
                old["signature"] = pattern.get("signature", old.get("signature", self.signature(old)))
                old["created_at"] = pattern.get("created_at")
                self._save()
                return
        self.patterns.append(pattern)
        self._save()

    def relevant(self, query: str, limit: int = 6) -> List[dict]:
        context_text = self._recent_context_text()
        recent_sequence = self._recent_act_sequence()
        ranked = sorted(
            (
                (self.score(p, query, context_text=context_text, recent_sequence=recent_sequence), p)
                for p in self.patterns
            ),
            key=lambda x: x[0] + (0.25 if x[1].get("source") != "builtin" else 0.0),
            reverse=True,
        )
        return [p for score, p in ranked[:limit] if score >= 0.12]

    def prompt_context(self, query: str, limit: int = 6) -> str:
        found = self.relevant(query, limit)
        current = self.build_pattern([{"role": "user", "content": query}])
        if not found and not current:
            return ""
        lines = [
            "الگوی گفتگوی TRX (راهنماست، نه حقیقت قطعی درباره کاربر):",
            "از زمینه و لحن استفاده کن؛ احساس یا شخصیت کاربر را بدون شواهد قطعی فرض نکن."
        ]
        if current:
            conf = current.get("confidence", 0.0)
            lines.append(
                f"وضعیت فعلی: نوع={current['type']} | احساس={current['emotion']} | نیاز={current['need']} | "
                f"کنش گفتاری={current['dialogue_act']} | روند احساس={current['sentiment_direction']} | "
                f"اطمینانِ برچسب={conf}"
            )
            if conf < 0.35:
                lines.append(
                    "(این برچسب از رویِ یک متنِ کوتاه/مبهم حدس زده شده؛ با احتیاطِ بیشتری در نظرش بگیر.)"
                )
            repeat_count = self.signature_frequency(self.signature(current))
            if repeat_count >= 3:
                lines.append(
                    f"(این الگویِ رفتاری دستِ‌کم {repeat_count} بار دیگر از این کاربر دیده شده -- "
                    "یک عادتِ گفتاریِ نسبتاً شناخته‌شده است، نه یک حدسِ تکی.)"
                )
        if self.emotional_support_mode(query):
            lines.append(
                "حالت همراهی عمیق: اول دردش را بشنو، نه اینکه فوراً راهکار بدهی. احساس کاربر را بازتاب بده، "
                "با لحن گرم پاسخ بده، سؤال کوتاه و مرتبط بپرس، عجله برای حل مشکل نکن. "
                "از قضاوت، کلیشه و راهکار/نصیحت ناخواسته پرهیز کن. اگر کاربر درد دل می‌کند، هدف اصلی ایجاد حس شنیده‌شدن است."
            )
        learned = self.relevant_utterance_patterns(query, limit=12)
        if learned:
            label = (
                "چند نمونه از حرف‌های واقعیِ کاربر که به پیامِ فعلی مرتبط‌اند"
                if _semantic_backend.is_available()
                else "چند نمونه از حرف‌های واقعی اخیر کاربر"
            )
            lines.append(f"{label} (برای فهم سبک و زمینه؛ تقلید لفظی نکن):")
            for u in learned:
                lines.append(
                    f"  • احساس={u.get('emotion')} | نیاز={u.get('need')} | موضوع‌ها={', '.join(u.get('topics', [])[:4]) or 'عمومی'} | "
                    f"حمایت={u.get('support_mode')} | متن={u.get('text','')[:180]}"
                )
        for p in found:
            topics = ", ".join(p.get("topics", [])[:7]) or "عمومی"
            lines.append(
                f"- الگوی قبلی: نوع={p.get('type','general')} | احساس={p.get('emotion','neutral')} | "
                f"نیاز={p.get('need','conversation')} | موضوع‌ها={topics} | قوس={p.get('arc','')} | "
                f"راهبرد={p.get('strategy','')}"
            )
        return "\n".join(lines)
