# -*- coding: utf-8 -*-
"""
response_strategy.py -- انتخابِ سبکِ پاسخ بر اساسِ Intent + User State +
Conversation Phase + Pattern.

این ماژول عمداً «فقط منطقِ انتخاب» است -- هیچ متنِ پاسخی تولید نمی‌کند
و به هیچ UI/core.py وصل نیست (دقیقاً همان جداییِ ``nlu/disambiguator.py``:
منطق از سیم‌کشی جدا). خروجی همیشه یکی از این برچسب‌هاست (بخشِ ۱۳ سند):

    normal, empathetic_short, calm_helpful, simplify, encourage,
    explain_step_by_step, ask_clarifying_question, do_not_push,
    celebrate_success, concise_answer

مسئولیتِ تبدیلِ این برچسب به متنِ واقعیِ پاسخ با لایه‌یِ پاسخ‌دهنده
(core.py / EMPATHY_TEMPLATES در conversation_patterns.py و مشابه) است.
"""

from __future__ import annotations

from typing import Iterable, Optional

STRATEGIES = (
    "normal", "empathetic_short", "calm_helpful", "simplify", "encourage",
    "explain_step_by_step", "ask_clarifying_question", "do_not_push",
    "celebrate_success", "concise_answer", "positive_confirmation",
)

# نگاشتِ پایه‌یِ حالت→راهبرد -- دقیقاً جدولِ بخشِ ۱۴ سند، به‌علاوه‌یِ چند
# حالتِ اضافه (bored/curious/excited/happy/angry/stressed/dissatisfied)
# که سند صراحتاً برایشان یک نمونه‌ی جداگانه نداد اما در فهرستِ Stateهای
# پایه (بخشِ ۴) هستند -- نگاشتِ آن‌ها با همان روحِ راهبردهایِ موجود
# انتخاب شده (نه راهبردِ جدیدِ اختراعی).
STRATEGY_BY_STATE: dict[str, str] = {
    "tired": "empathetic_short",
    "frustrated": "calm_helpful",
    "confused": "simplify",
    "disengaged": "do_not_push",
    "satisfied": "positive_confirmation",
    "sad": "empathetic_short",
    "angry": "calm_helpful",
    "stressed": "calm_helpful",
    "bored": "encourage",
    "curious": "explain_step_by_step",
    "excited": "normal",
    "happy": "normal",
    "dissatisfied": "calm_helpful",
    "neutral": "normal",
}


# جمله‌هایِ کوتاهِ آماده به‌ازایِ هر راهبرد -- کاملاً آفلاین، هیچ تماسِ
# شبکه‌ای/APIِ خارجی ندارند (بخشِ ۲۲ سند). این‌ها *جداگانه* از
# ``ConversationPatternEngine.EMPATHY_TEMPLATES`` نگه داشته شده‌اند
# (که خودش مبتنی بر تاکسونومیِ قدیمیِ emotion است، نه user_state) --
# دقیقاً طبقِ اصلِ معماریِ سند: دو محورِ مستقل نباید با هم ادغام شوند.
# فقط برایِ راهبردهایی که پاسخِ عمومیِ pipeline (core.py) هنوز چیزِ
# بهتری برایشان ندارد؛ برایِ "normal"/"concise_answer" عمداً ``None``
# است تا مسیرِ عادیِ جستجو/پاسخ‌دهیِ محلی دست‌نخورده بماند.
# جمله‌هایِ کوتاهِ آماده به‌ازایِ هر راهبرد -- کاملاً آفلاین، هیچ تماسِ
# شبکه‌ای/APIِ خارجی ندارند (بخشِ ۲۲ سند). این‌ها *جداگانه* از
# ``ConversationPatternEngine.EMPATHY_TEMPLATES`` نگه داشته شده‌اند
# (که خودش مبتنی بر تاکسونومیِ قدیمیِ emotion است، نه user_state) --
# دقیقاً طبقِ اصلِ معماریِ سند: دو محورِ مستقل نباید با هم ادغام شوند.
# فقط برایِ راهبردهایی که پاسخِ عمومیِ pipeline (core.py) هنوز چیزِ
# بهتری برایشان ندارد؛ برایِ "normal"/"concise_answer" عمداً ``None``
# است تا مسیرِ عادیِ جستجو/پاسخ‌دهیِ محلی دست‌نخورده بماند.
#
# هر مقدار یک ``tuple`` از چند نسخه‌ی هم‌معنی است (نه یک رشته‌یِ تنها):
# با کاربری که چند نوبتِ پی‌درپی همان حالت را دارد (مثلاً چند بار پشتِ‌
# سرِ‌هم «خسته‌ام»)، شنیدنِ دقیقاً همان جمله باعثِ حسِ «پاسخِ رباتیِ
# تکراری» می‌شود (بخشِ ۱۳ سند: «آیا پاسخ‌ها طبیعی هستند؟»). عنصرِ اول
# در هر tuple عیناً همان متنِ قبل از این ارتقا است -- یعنی
# ``reply_hint()`` (که جاهایِ دیگری مثلِ ``tool_router.py`` هم صدایش
# می‌زنند) برایِ اولین‌بار همیشه دقیقاً همان رفتارِ قبلی را دارد؛ فقط
# ``ResponseEngine`` (بخشِ پاسخِ Cognition Core) با توجه‌ به نوبت‌شمار
# می‌تواند نسخه‌یِ دومی هم انتخاب کند.
STRATEGY_REPLY_HINTS: dict[str, tuple[str, ...]] = {
    "empathetic_short": (
        "می‌فهمم. اگه دوست داری می‌تونیم یه کم مکث کنیم و بعد ادامه بدیم.",
        "حق داری. هر وقت آماده بودی ادامه می‌دیم، عجله‌ای نیست.",
    ),
    "calm_helpful": (
        "حق داری خسته‌کننده شده. بیا این بار از اول حدس نزنیم؛ دقیقاً بگو "
        "کجا گیر کردی تا قدم‌به‌قدم با هم بررسی کنیم.",
        "می‌فهمم کلافه‌کننده‌ست. بیا دوباره از یه‌جایِ مشخص شروع کنیم، بدونِ حدس‌زدن.",
    ),
    "simplify": (
        "بذار ساده‌تر بگم. دقیقاً کدوم قسمتش برات گنگه؟",
        "باشه، یه بار دیگه ساده‌تر توضیح می‌دم. کجاش رو دقیق‌تر بخوای؟",
    ),
    "do_not_push": (
        "باشه، اصراری نیست. هر وقت خواستی ادامه بدیم، من اینجام.",
    ),
    "encourage": (
        "می‌دونم یکم تکراری شده، ولی داری نزدیک می‌شی. یه قدمِ کوچیکِ دیگه امتحان کنیم؟",
        "کارت درسته، فقط یه ذره دیگه صبر. یه تلاشِ دیگه بزنیم؟",
    ),
    "explain_step_by_step": (
        "باشه، بیا قدم‌به‌قدم بریم جلو تا کاملاً روشن بشه.",
    ),
    "ask_clarifying_question": (
        "می‌خوام مطمئن بشم درست فهمیدم -- دقیقاً منظورت چیه؟",
    ),
    "celebrate_success": (
        "عالی شد! خیلی خوشحالم که جواب داد. 🎉",
    ),
    "positive_confirmation": (
        "خوشحالم که حل شد. اگه چیزِ دیگه‌ای هم لازم داشتی بگو.",
    ),
}


def reply_hints(strategy: str) -> tuple[str, ...]:
    """همه‌یِ نسخه‌هایِ هم‌معنیِ پیشنهادِ کوتاهِ این راهبرد را برمی‌گرداند
    (ممکن است یک یا چند نسخه باشد). فقط انتخابِ *سبکِ* ارتباط است --
    تولیدِ متنِ اصلیِ پاسخ را تغییر نمی‌دهد.
    """
    return STRATEGY_REPLY_HINTS.get(strategy, ())


def reply_hint(strategy: str) -> Optional[str]:
    """سازگاری با API قبلی: همیشه اولین نسخه را برمی‌گرداند -- دقیقاً
    همان مقداری که پیش از این ارتقا برمی‌گشت (رگرسیونی برایِ فراخوان‌هایِ
    موجود مثلِ ``tool_router.py`` وجود ندارد)."""
    hints = reply_hints(strategy)
    return hints[0] if hints else None


def choose_strategy(
    user_state: str,
    phase: str = "unknown",
    uncertain: bool = False,
    secondary_states: Optional[Iterable[str]] = None,
) -> str:
    """
    ``phase`` وقتی سرنخِ قوی‌تری دارد (موفقیت/ابهام) بر نگاشتِ صرفِ حالت
    اولویت می‌گیرد -- مثلاً کاربرِ «راضی»ای که تازه به یک موفقیتِ مشخص
    رسیده (phase=success) باید celebrate_success بگیرد، نه فقط
    positive_confirmationِ عمومی.
    """
    secondary = set(secondary_states or ())

    if phase == "success":
        return "celebrate_success"
    if phase == "clarification":
        return "ask_clarifying_question"
    if phase == "repeated_failure" and ({"frustrated", "tired"} & ({user_state} | secondary)):
        return "calm_helpful"

    strategy = STRATEGY_BY_STATE.get(user_state, "normal")

    # حالتِ نامطمئن رویِ یک حالتِ خنثی: به‌جایِ فرضِ بی‌پایه‌ی یک لحنِ
    # خاص، پاسخِ کوتاه و بدونِ فرضِ احساسی بده (بخشِ ۷: «رفتارِ شدید بر
    # اساسِ State ضعیف انجام نده»).
    if uncertain and strategy == "normal":
        return "concise_answer"

    return strategy



def communication_profile(strategy: str) -> dict[str, str]:
    """
    پروفایلِ ارتباطیِ این راهبرد -- ``tone`` برایِ لحن، ``length`` برایِ
    اینکه ``ResponseEngine`` چقدر باید جزئیاتِ خامِ ابزارها را کنارِ
    hint بگذارد (بخشِ ۶ سند: «نیاز به جزئیات»/«عجله»).

    ``length="short"`` یعنی: کاربر در حالتی است (خسته/کلافه/بی‌علاقه)
    که یک پاسخِ فنیِ طولانی کنارِ hint او را بیشتر خسته می‌کند --
    ``ResponseEngine.compose_plan_result`` این را برایِ کوتاه‌کردنِ
    بدنه‌ی نتیجه‌ی ابزارها می‌خواند (نه خودِ hint، که همیشه کوتاه است).
    """
    profiles: dict[str, dict[str, str]] = {
        "empathetic_short": {"tone": "supportive", "length": "short"},
        "calm_helpful": {"tone": "calm", "length": "guided"},
        "simplify": {"tone": "clear", "length": "short"},
        "do_not_push": {"tone": "gentle", "length": "short"},
        "encourage": {"tone": "supportive", "length": "guided"},
        "explain_step_by_step": {"tone": "clear", "length": "step_by_step"},
        "ask_clarifying_question": {"tone": "neutral", "length": "question"},
        "celebrate_success": {"tone": "warm", "length": "normal"},
        "positive_confirmation": {"tone": "warm", "length": "normal"},
        "concise_answer": {"tone": "neutral", "length": "short"},
        "normal": {"tone": "neutral", "length": "normal"},
    }
    return profiles.get(strategy, {"tone": "neutral", "length": "normal"})
