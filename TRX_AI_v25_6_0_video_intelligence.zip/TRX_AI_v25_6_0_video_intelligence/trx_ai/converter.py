# -*- coding: utf-8 -*-
"""
مبدلِ واحد — تبدیلِ طول، وزن، دما، حجم و سرعت با نام‌های فارسیِ واحدها.

مثال‌های پشتیبانی‌شده:
    «۱۰۰ کیلومتر به مایل»
    «۵۰ کیلوگرم به پوند»
    «۳۰ درجه سانتیگراد به فارنهایت»
    «۲ لیتر به گالن»
"""

from __future__ import annotations

import re
from typing import Optional, Tuple

from .text_normalize import normalize_text as _normalize_text


# هر واحد: (دسته, ضریبِ تبدیل به واحدِ پایه‌ی همان دسته)
# دسته‌ی دما جداگانه با فرمول مدیریت می‌شود (خطی نیست).
_UNITS = {
    # طول (پایه: متر)
    "متر": ("length", 1.0), "m": ("length", 1.0),
    "کیلومتر": ("length", 1000.0), "km": ("length", 1000.0),
    "سانتی متر": ("length", 0.01), "سانتیمتر": ("length", 0.01), "cm": ("length", 0.01),
    "میلی متر": ("length", 0.001), "میلیمتر": ("length", 0.001), "mm": ("length", 0.001),
    "مایل": ("length", 1609.344), "mile": ("length", 1609.344),
    "فوت": ("length", 0.3048), "foot": ("length", 0.3048), "feet": ("length", 0.3048),
    "اینچ": ("length", 0.0254), "inch": ("length", 0.0254),
    "یارد": ("length", 0.9144), "yard": ("length", 0.9144),

    # وزن (پایه: کیلوگرم)
    "کیلوگرم": ("weight", 1.0), "کیلو": ("weight", 1.0), "kg": ("weight", 1.0),
    "گرم": ("weight", 0.001), "g": ("weight", 0.001), "gram": ("weight", 0.001),
    "میلی گرم": ("weight", 0.000001), "میلیگرم": ("weight", 0.000001), "mg": ("weight", 0.000001),
    "پوند": ("weight", 0.45359237), "pound": ("weight", 0.45359237), "lb": ("weight", 0.45359237),
    "اونس": ("weight", 0.0283495), "ounce": ("weight", 0.0283495), "oz": ("weight", 0.0283495),
    "تن": ("weight", 1000.0), "ton": ("weight", 1000.0),

    # حجم (پایه: لیتر)
    "لیتر": ("volume", 1.0), "liter": ("volume", 1.0), "litre": ("volume", 1.0),
    "میلی لیتر": ("volume", 0.001), "میلی‌لیتر": ("volume", 0.001), "ml": ("volume", 0.001),
    "گالن": ("volume", 3.78541), "gallon": ("volume", 3.78541),

    # سرعت (پایه: کیلومتر بر ساعت)
    "کیلومتر بر ساعت": ("speed", 1.0), "km/h": ("speed", 1.0), "کیلومتر در ساعت": ("speed", 1.0),
    "متر بر ثانیه": ("speed", 3.6), "m/s": ("speed", 3.6),
    "مایل بر ساعت": ("speed", 1.60934), "mph": ("speed", 1.60934),

    # دما (فرمولِ خاصِ خودش دارد؛ ضریب استفاده نمی‌شود)
    "سانتیگراد": ("temperature", None), "سلسیوس": ("temperature", None), "celsius": ("temperature", None),
    "فارنهایت": ("temperature", None), "fahrenheit": ("temperature", None),
    "کلوین": ("temperature", None), "kelvin": ("temperature", None),
}

_UNIT_PATTERN = "|".join(sorted((re.escape(u) for u in _UNITS), key=len, reverse=True))
_CONVERT_RE = re.compile(
    rf'(\d+(?:\.\d+)?)\s*(?:درجه\s*)?({_UNIT_PATTERN})\s*(?:به|=|->|تبدیل\s*به)\s*(?:درجه\s*)?({_UNIT_PATTERN})',
    re.IGNORECASE,
)


def _to_celsius(value: float, unit: str) -> float:
    if unit in ("سانتیگراد", "سلسیوس", "celsius"):
        return value
    if unit in ("فارنهایت", "fahrenheit"):
        return (value - 32) * 5 / 9
    if unit in ("کلوین", "kelvin"):
        return value - 273.15
    raise ValueError(f"واحدِ دمای ناشناخته: {unit}")


def _from_celsius(value_c: float, unit: str) -> float:
    if unit in ("سانتیگراد", "سلسیوس", "celsius"):
        return value_c
    if unit in ("فارنهایت", "fahrenheit"):
        return value_c * 9 / 5 + 32
    if unit in ("کلوین", "kelvin"):
        return value_c + 273.15
    raise ValueError(f"واحدِ دمای ناشناخته: {unit}")


def convert(value: float, from_unit: str, to_unit: str) -> float:
    """
    مقدار را از from_unit به to_unit تبدیل می‌کند. اگر دو واحد هم‌دسته
    نباشند (مثلاً متر به کیلوگرم)، ValueError می‌دهد.
    """
    from_unit = from_unit.strip().lower()
    to_unit = to_unit.strip().lower()
    if from_unit not in _UNITS or to_unit not in _UNITS:
        raise ValueError("واحد شناخته‌شده نیست")

    from_cat, from_factor = _UNITS[from_unit]
    to_cat, to_factor = _UNITS[to_unit]
    if from_cat != to_cat:
        raise ValueError(f"واحدهای «{from_unit}» و «{to_unit}» هم‌دسته نیستند")

    if from_cat == "temperature":
        celsius = _to_celsius(value, from_unit)
        return _from_celsius(celsius, to_unit)

    base_value = value * from_factor
    return base_value / to_factor


def parse_and_convert(text: str) -> Optional[Tuple[float, str, str, float]]:
    """
    یک جمله‌ی آزاد مثلِ «۱۰۰ کیلومتر به مایل» را پیدا و تبدیل می‌کند.
    خروجی: (مقدارِ اصلی, واحدِ مبدأ, واحدِ مقصد, نتیجه) یا None اگر
    الگویی پیدا نشد.
    """
    t = _normalize_text(text)
    match = _CONVERT_RE.search(t)
    if not match:
        return None
    value = float(match.group(1))
    from_unit = match.group(2).strip().lower()
    to_unit = match.group(3).strip().lower()
    try:
        result = convert(value, from_unit, to_unit)
    except ValueError:
        return None
    return value, from_unit, to_unit, result


def format_conversion_result(text: str) -> str:
    parsed = parse_and_convert(text)
    if parsed is None:
        return (
            "❌ نتوانستم واحدها را تشخیص بدهم. مثال: «۱۰۰ کیلومتر به مایل» یا "
            "«۵۰ کیلوگرم به پوند» یا «۳۰ درجه سانتیگراد به فارنهایت»."
        )
    value, from_unit, to_unit, result = parsed
    return f"📐 {value:g} {from_unit} = {result:.4g} {to_unit}"
