# -*- coding: utf-8 -*-
"""
مدیریتِ کارها/یادآوری‌ها (Task/Reminder Manager) — یک قابلیتِ کاملاً
تازه: می‌شود گفت «یادم بنداز فردا ساعت ۵ به دکتر زنگ بزنم»، فهرستِ
کارها را دید، یکی را انجام‌شده علامت زد یا حذف کرد. هر بار که برنامه
اجرا می‌شود (یا در طولِ یک جلسه)، کارهایی که سررسیدشان رسیده به‌طور
خودکار به کاربر یادآوری می‌شوند.

محدودیتِ صادقانه: تشخیصِ زمان یک NLP کاملِ تاریخ نیست؛ فقط الگوهای
رایجِ فارسی («امروز»، «فردا»، «ساعت N») را می‌فهمد. اگر جمله هیچ‌کدام
از این‌ها را نداشته باشد، کار بدونِ سررسید ثبت می‌شود (همچنان به‌عنوانِ
یک آیتمِ ساده در فهرستِ کارها کاربردی است، فقط یادآوریِ خودکار نمی‌گیرد).
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Optional, Tuple

from .text_normalize import normalize_text as _normalize_text

_TIME_PATTERN = re.compile(r'ساعت\s+(\d{1,2})(?::(\d{2}))?')


def parse_due_date(text: str, now: datetime = None) -> Tuple[Optional[datetime], str]:
    """
    از یک جمله‌ی فارسیِ آزاد، تاریخ/ساعتِ سررسید را استخراج می‌کند.
    خروجی: (datetime یا None, متنِ باقی‌مانده پس از حذفِ عبارت‌های زمانی
    — همان چیزی که باید به‌عنوانِ عنوانِ کار ذخیره شود).

    پشتیبانی‌شده: «امروز»، «فردا»، «پس‌فردا»، «ساعت N» یا «ساعت N:MM».
    ترکیبِ این‌ها هم کار می‌کند: «فردا ساعت ۱۷».
    """
    now = now or datetime.now()
    t = _normalize_text(text)
    due_date = None
    day_found = False

    if "پس فردا" in t or "پس‌فردا" in t:
        due_date = now + timedelta(days=2)
        day_found = True
        t = t.replace("پس‌فردا", "").replace("پس فردا", "")
    elif "فردا" in t:
        due_date = now + timedelta(days=1)
        day_found = True
        t = t.replace("فردا", "")
    elif "امروز" in t:
        due_date = now
        day_found = True
        t = t.replace("امروز", "")

    time_match = _TIME_PATTERN.search(t)
    hour = minute = None
    if time_match:
        hour = int(time_match.group(1))
        minute = int(time_match.group(2) or 0)
        t = t[:time_match.start()] + t[time_match.end():]

    if hour is not None:
        base = due_date or now
        due_date = base.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if not day_found and due_date < now:
            # فقط «ساعت» گفته شده و آن ساعت امروز گذشته - فرض بر فرداست
            due_date += timedelta(days=1)
    elif day_found:
        due_date = due_date.replace(hour=9, minute=0, second=0, microsecond=0)

    remaining = re.sub(r'\s+', ' ', t).strip(" :،")
    return due_date, remaining


class TaskManager:
    """رابطِ سطح‌بالا بینِ core.py و DatabaseManager برای کارها/یادآوری‌ها."""

    def __init__(self, db):
        self.db = db

    def add_from_text(self, text: str, project: str = None) -> dict:
        """
        یک جمله‌ی آزاد (مثلاً «یادم بنداز فردا ساعت ۵ نون بخرم») را به
        عنوان + سررسید تجزیه و در دیتابیس ثبت می‌کند.
        """
        # حذفِ عبارت‌های آغازینِ رایج پیش از تجزیه‌ی تاریخ
        cleaned = re.sub(
            r'^(یادم\s*بنداز|یادآوری\s*کن(\s*که)?|به\s*کارهام\s*اضافه\s*کن|کار\s*جدید)\s*[:：]?\s*',
            '', text.strip()
        )
        due_date, title = parse_due_date(cleaned)
        title = title.strip() or cleaned.strip() or "کارِ بدونِ عنوان"
        due_iso = due_date.strftime("%Y-%m-%d %H:%M:%S") if due_date else None
        task_id = self.db.add_task(title, due_iso, project)
        return {"id": task_id, "title": title, "due_at": due_date}

    def format_task_list(self, include_done: bool = False, project: str = None) -> str:
        tasks = self.db.list_tasks(include_done=include_done, project=project)
        if not tasks:
            return "📭 هیچ کارِ ثبت‌شده‌ای نداری." if not include_done else "📭 هیچ کاری (حتی انجام‌شده) ثبت نشده."

        lines = ["📋 **کارهای تو:**\n"]
        for task_id, title, due_at, done in tasks:
            status = "✅" if done else "⬜"
            due_str = f"  ⏰ {due_at}" if due_at else ""
            lines.append(f"{status} #{task_id} {title}{due_str}")
        lines.append("\n(برای انجام‌شده‌کردن: «کار ۲ رو انجام دادم» | برای حذف: «کار ۲ رو حذف کن»)")
        return "\n".join(lines)

    def complete_by_id(self, task_id: int) -> str:
        if self.db.complete_task(task_id):
            return f"✅ کار #{task_id} به‌عنوانِ انجام‌شده علامت خورد."
        return f"❌ کاری با شماره‌ی #{task_id} پیدا نشد."

    def delete_by_id(self, task_id: int) -> str:
        if self.db.delete_task(task_id):
            return f"🗑️ کار #{task_id} حذف شد."
        return f"❌ کاری با شماره‌ی #{task_id} پیدا نشد."

    def check_due_reminders(self) -> list:
        """
        کارهایی که سررسیدشان رسیده و هنوز یادآوری نشده‌اند را برمی‌گرداند
        و آن‌ها را reminded علامت می‌زند (تا هر پیام دوباره نشان داده
        نشوند). باید در ابتدای هر نوبت (یا هنگامِ ورود) صدا زده شود.
        """
        now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        due = self.db.get_due_tasks(now_iso)
        for task_id, _title, _due_at in due:
            self.db.mark_task_reminded(task_id)
        return due

    @staticmethod
    def extract_task_id(text: str) -> Optional[int]:
        """شماره‌ی کار را از جمله‌ای مثلِ «کار ۲ رو انجام دادم» استخراج می‌کند."""
        t = _normalize_text(text)
        match = re.search(r'#?\s*(\d+)', t)
        return int(match.group(1)) if match else None
