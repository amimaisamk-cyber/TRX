# -*- coding: utf-8 -*-
"""
ساختارهای داده‌ی هسته‌ی «حلقه‌ی عامل خودمختار» (Autonomous Agent Loop).

این ماژول عمداً بدون‌منطق (فقط dataclass/Enum) نگه داشته شده تا بقیه‌ی
زیرماژول‌های `trx_ai.agent` (planner, executor, guardrails, memory,
reflection, loop) بدون وابستگیِ حلقوی به همین چند نوع مشترک تکیه کنند.

فلسفه‌ی طراحی: دقیقاً مثل بقیه‌ی پروژه، همه‌چیز باید بدون هیچ کلید/سرویس
بیرونیِ اجباری کار کند (fallback محلی/heuristic)، و اگر بعداً یک موتور
LLM واقعی وصل شد (مثلاً از طریق `llm_decide` در `planner.py`)، بدون
تغییرِ ساختاریِ حلقه فقط کیفیتِ تصمیم‌گیری بهتر شود.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ActionType(str, Enum):
    """نوعِ اقدامی که planner در هر گام از حلقه انتخاب می‌کند."""

    TOOL_CALL = "tool_call"
    FINAL_ANSWER = "final_answer"
    ASK_USER = "ask_user"


class StopReason(str, Enum):
    """چرا حلقه متوقف شد -- برای شفافیت در trace و لاگ."""

    GOAL_SATISFIED = "goal_satisfied"
    NO_MORE_TOOLS = "no_more_tools"
    BUDGET_EXHAUSTED = "budget_exhausted"
    GUARDRAIL_TRIPPED = "guardrail_tripped"
    NEEDS_USER_INPUT = "needs_user_input"
    ERROR = "error"


@dataclass(frozen=True)
class AgentAction:
    """
    خروجیِ یک تصمیمِ planner در یک گام.

    - ``TOOL_CALL``: باید ``tool_name`` + ``tool_args`` پر باشد.
    - ``FINAL_ANSWER``: باید ``final_answer`` پر باشد.
    - ``ASK_USER``: باید ``question`` پر باشد (وقتی حلقه نمی‌تواند بدون
      اطلاعاتِ بیشتر از کاربر ادامه دهد -- به‌جای حدس‌زدن).
    """

    type: ActionType
    thought: str = ""
    tool_name: str | None = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    final_answer: str | None = None
    question: str | None = None


@dataclass
class ToolResult:
    """نتیجه‌ی اجرایِ یک ابزار -- همیشه امن (هرگز استثنا throw نمی‌کند)."""

    tool_name: str
    ok: bool
    output: str = ""
    error: str | None = None
    latency_ms: float = 0.0
    raw: Any = None

    def as_observation(self) -> str:
        """متنِ خوانا برایِ افزودن به scratchpad/context."""
        if self.ok:
            return self.output.strip()
        return f"⚠️ ابزار «{self.tool_name}» شکست خورد: {self.error or 'نامشخص'}"


@dataclass
class AgentStep:
    """یک گامِ کاملِ حلقه: تصمیم + (در صورتِ tool_call) نتیجه + reflection."""

    index: int
    action: AgentAction
    result: ToolResult | None = None
    reflection: dict[str, Any] | None = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class AgentConfig:
    """
    گاردریل‌ها/بودجه‌ی یک اجرایِ حلقه‌ی عامل.

    مقادیرِ پیش‌فرض عمداً محافظه‌کارانه‌اند (این یک دستیارِ شخصی روی
    گوشی/دسکتاپ است، نه سرویسِ بک‌اند با منابعِ نامحدود).
    """

    max_steps: int = 6
    max_wall_seconds: float = 45.0
    max_calls_per_tool: int = 2
    allowed_tools: set[str] | None = None  # None یعنی همه‌ی ابزارهای ثبت‌شده مجازند
    min_confidence_to_finish: float = 0.55
    verbose: bool = False


@dataclass
class AgentTrace:
    """گزارشِ کاملِ یک اجرا -- برای نمایش به کاربر یا لاگِ عیب‌یابی."""

    goal: str
    steps: list[AgentStep] = field(default_factory=list)
    final_answer: str | None = None
    success: bool = False
    stop_reason: StopReason = StopReason.ERROR
    total_wall_seconds: float = 0.0

    def tool_calls_made(self) -> int:
        return sum(1 for s in self.steps if s.action.type == ActionType.TOOL_CALL)

    def format_trace_fa(self) -> str:
        """نمایشِ خلاصه‌ی گام‌به‌گام به فارسی (برایِ حالتِ verbose/دیباگ)."""
        lines = [f"🧭 هدف: {self.goal}"]
        for step in self.steps:
            if step.action.type == ActionType.TOOL_CALL:
                status = "✅" if (step.result and step.result.ok) else "❌"
                lines.append(
                    f"  {status} گامِ {step.index + 1}: ابزارِ «{step.action.tool_name}» "
                    f"({step.action.thought or 'بدون توضیح'})"
                )
            elif step.action.type == ActionType.ASK_USER:
                lines.append(f"  ❓ گامِ {step.index + 1}: نیاز به اطلاعاتِ بیشتر از کاربر")
        lines.append(f"🏁 پایان ({self.stop_reason.value}) در {self.total_wall_seconds:.2f} ثانیه.")
        return "\n".join(lines)
