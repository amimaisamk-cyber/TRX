# -*- coding: utf-8 -*-
"""
مکانیزمِ تصمیم‌گیریِ خودمختار (Autonomous Agent Loop) برایِ TRX AI.

این پکیج به هوش مصنوعی اجازه می‌دهد خودش ابزارها (وب، بینایی، پایگاه‌
دانش، ماشین‌حساب، فایل، ...) را به‌صورتِ زنجیره‌ای برای حل‌کردنِ یک
هدف صدا بزند -- بدون اینکه کاربر تک‌تکِ مراحل را دستی فرمان دهد.

استفاده‌ی سریع::

    from trx_ai.agent import build_default_registry, AgentLoop, AgentConfig

    registry = build_default_registry(ai)  # ai = نمونه‌ی TRXEnterpriseAI
    trace = await AgentLoop(registry, AgentConfig(max_steps=5)).run(
        "جمعیتِ فعلیِ ایران رو پیدا کن و با ۱۴۰۰ مقایسه کن"
    )
    print(trace.final_answer)

ماژول‌ها (هرکدام یک مسئولیتِ تخصصی -- به `ARCHITECTURE.md` رجوع کنید):

    types.py         dataclass/Enum های مشترک
    tool_registry.py ثبت‌نام ابزارها + آداپتورِ موتورهایِ موجودِ پروژه
    planner.py        تصمیمِ «گامِ بعدی چیست» (heuristic + قلابِ LLM)
    guardrails.py      سقفِ گام/زمان/تکرار -- ایمنیِ حلقه
    memory.py          scratchpad کوتاه‌مدتِ یک اجرا
    reflection.py       ارزیابیِ کافی‌بودن + سنتزِ پاسخِ نهایی
    loop.py             هماهنگ‌کننده‌ی نهایی
"""

from __future__ import annotations

from .cognition import CognitionCore
from .guardrails import GuardrailViolation, LoopGuard
from .loop import AgentLoop, run_agent
from .memory import Scratchpad
from .planner import AgentPlanner, HeuristicPlanner
from .reflection import StepReflector
from .tool_registry import AgentTool, ToolRegistry, build_default_registry
from .types import (
    ActionType,
    AgentAction,
    AgentConfig,
    AgentStep,
    AgentTrace,
    StopReason,
    ToolResult,
)

__all__ = [
    "ActionType",
    "AgentAction",
    "AgentConfig",
    "AgentLoop",
    "AgentPlanner",
    "AgentStep",
    "AgentTool",
    "AgentTrace",
    "CognitionCore",
    "GuardrailViolation",
    "HeuristicPlanner",
    "LoopGuard",
    "Scratchpad",
    "StepReflector",
    "StopReason",
    "ToolRegistry",
    "ToolResult",
    "build_default_registry",
    "run_agent",
]
