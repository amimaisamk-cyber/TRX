# -*- coding: utf-8 -*-
"""
گاردریل‌های ایمنی/بودجه‌ی حلقه‌ی عامل.

هدف: جلوگیری از سه خطرِ کلاسیکِ هر «agent loop»ی که خودش تصمیم می‌گیرد
چه ابزاری را کِی صدا بزند:

1. **حلقه‌ی بی‌پایان** -- همان ابزار با همان آرگومان‌ها بارها صدا زده شود.
2. **مصرفِ بی‌رویه‌ی زمان/منابع** -- تعدادِ گام یا زمانِ کل بدون سقف.
3. **دسترسیِ خارج از مجوز** -- ابزاری صدا زده شود که صراحتاً در
   allow-list این اجرا نبوده (مثلاً وقتی رابطِ فراخوان فقط اجازه‌ی
   ابزارهایِ read-only را داده).

این ماژول کاملاً مستقل و بدون‌حالت‌ِ سراسری است؛ هر اجرایِ `AgentLoop`
یک نمونه‌ی تازه از `LoopGuard` می‌سازد.
"""

from __future__ import annotations

import time
from typing import Any

from .types import AgentConfig


class GuardrailViolation(Exception):
    """وقتی یک گام از حلقه از مرزهای ایمنی/بودجه رد می‌شود، این خطا بالا می‌رود.

    `AgentLoop` این استثنا را می‌گیرد و حلقه را به‌شکلِ کنترل‌شده (نه کرش)
    با یک پاسخِ نهاییِ best-effort متوقف می‌کند.
    """


def _signature(tool_name: str, tool_args: dict[str, Any]) -> tuple:
    """امضایِ قابلِ‌هشِ یک فراخوانی -- برایِ تشخیصِ تکرارِ عینی."""
    try:
        items = tuple(sorted((k, str(v)) for k, v in tool_args.items()))
    except Exception:
        items = (("_raw", str(tool_args)),)
    return (tool_name, items)


class LoopGuard:
    """نگه‌دارِ وضعیتِ ایمنی/بودجه برایِ یکِ اجرایِ `AgentLoop.run(...)`."""

    def __init__(self, config: AgentConfig):
        self.config = config
        self._start_time = time.monotonic()
        self._steps_taken = 0
        self._calls_per_tool: dict[str, int] = {}
        self._seen_signatures: set[tuple] = set()

    # ---------------------------------------------------------- زمان/گام

    @property
    def elapsed_seconds(self) -> float:
        return time.monotonic() - self._start_time

    @property
    def steps_remaining(self) -> int:
        return max(0, self.config.max_steps - self._steps_taken)

    @property
    def budget_exhausted(self) -> bool:
        return (
            self._steps_taken >= self.config.max_steps
            or self.elapsed_seconds >= self.config.max_wall_seconds
        )

    def record_step(self) -> None:
        self._steps_taken += 1

    # ---------------------------------------------------------- فراخوانیِ ابزار

    def check_before_call(self, tool_name: str, tool_args: dict[str, Any]) -> None:
        """
        پیشِ از اجرایِ واقعیِ ابزار صدا زده می‌شود.

        بالا رفتنِ ``GuardrailViolation`` یعنی این فراخوانی مجاز نیست --
        نه به این معنا که خودِ ابزار خطا داده.
        """
        if self.budget_exhausted:
            raise GuardrailViolation(
                f"بودجه‌ی حلقه تمام شده (گام: {self._steps_taken}/{self.config.max_steps}, "
                f"زمان: {self.elapsed_seconds:.1f}s/{self.config.max_wall_seconds}s)."
            )

        if self.config.allowed_tools is not None and tool_name not in self.config.allowed_tools:
            raise GuardrailViolation(f"ابزارِ «{tool_name}» در فهرستِ مجاز این اجرا نیست.")

        used = self._calls_per_tool.get(tool_name, 0)
        if used >= self.config.max_calls_per_tool:
            raise GuardrailViolation(
                f"ابزارِ «{tool_name}» بیش از سقفِ مجاز ({self.config.max_calls_per_tool}) "
                "در این اجرا صدا زده شده."
            )

        sig = _signature(tool_name, tool_args)
        if sig in self._seen_signatures:
            raise GuardrailViolation(
                f"فراخوانیِ تکراریِ عینیِ ابزارِ «{tool_name}» با همان آرگومان‌ها -- "
                "برای پیشگیری از حلقه‌ی بی‌پایان متوقف شد."
            )

    def record_call(self, tool_name: str, tool_args: dict[str, Any]) -> None:
        """پس از اجرایِ موفق/ناموفق (اما مجاز) یک فراخوانی، وضعیت را به‌روز می‌کند."""
        self._calls_per_tool[tool_name] = self._calls_per_tool.get(tool_name, 0) + 1
        self._seen_signatures.add(_signature(tool_name, tool_args))
