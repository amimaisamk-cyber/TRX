# -*- coding: utf-8 -*-
"""
ثبت‌نام و آداپتورِ یکپارچه‌یِ ابزارها برایِ حلقه‌ی عامل.

هیچ منطقِ جدیدِ ابزار در این فایل نیست -- فقط یک لایه‌ی نازکِ آداپتور
که موتورهایِ *موجودِ* پروژه (`tools.py`, `vision.py`, `database.py`,
`medical/`, `tasks.py`, `expenses.py`) را پشتِ یک واسطِ یکسان و
async-یِ ``AgentTool.run(**kwargs) -> ToolResult`` می‌گذارد، تا
``planner``/``loop`` بدون دانستنِ جزئیاتِ هر موتور بتوانند آن‌ها را
زنجیره‌ای صدا بزنند.

هیچ ابزاری هرگز استثنا بالا نمی‌برد؛ هر خطا به یک ``ToolResult(ok=False, ...)``
تبدیل می‌شود -- همان اصلِ «برنامه هیچ‌وقت کرش نمی‌کند» که در بقیه‌ی
پروژه هم رعایت شده.
"""

from __future__ import annotations

import inspect
import re
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from ..logging_config import get_logger
from .types import ToolResult

logger = get_logger(__name__)

RunFunc = Callable[..., Awaitable[str]]


@dataclass
class AgentTool:
    """
    توصیفِ یک ابزارِ قابل‌استفاده برایِ عامل.

    - ``name``: شناسه‌ی پایدار (در trace/guardrails استفاده می‌شود).
    - ``description``: توضیحِ کوتاهِ فارسی -- برای نمایش در trace و
      (در آینده) برای پرامپتِ یک LLM planner.
    - ``keywords``: کلیدواژه‌هایِ فارسی/انگلیسی برایِ امتیازدهیِ heuristic
      (بدونِ نیاز به هیچ مدلی، شبیهِ همان روشِ ``IntentEngine``).
    - ``run``: تابعِ async که آرگومان‌های استخراج‌شده از هدف را می‌گیرد
      و یک رشته‌ی متنی (پاسخِ خامِ ابزار) برمی‌گرداند. اگر نیاز به
      آرگومانِ خاصی (مثلِ ``city`` یا ``code``) دارد، خودش باید آن را
      از ``goal_text`` استخراج کند یا پیش‌فرضِ امن برگرداند.
    - ``read_only``: آیا این ابزار فقط می‌خواند (برایِ allow-listِ
      محتاطانه‌تر در ``AgentConfig.allowed_tools`` مفید است).
    """

    name: str
    description: str
    run: RunFunc
    keywords: list[str] = field(default_factory=list)
    read_only: bool = True

    def score(self, goal_text: str) -> float:
        """امتیازِ heuristicِ تطابقِ این ابزار با متنِ هدف (۰..۱)."""
        if not self.keywords:
            return 0.0
        text = goal_text or ""
        hits = sum(1 for kw in self.keywords if re.search(re.escape(kw), text, re.IGNORECASE))
        return min(1.0, hits / max(1, len(self.keywords) // 2 or 1))

    async def run_safe(self, **kwargs: Any) -> ToolResult:
        """اجرایِ ابزار با محافظتِ کامل در برابرِ استثنا/تایم‌اوت."""
        start = time.monotonic()
        try:
            sig = inspect.signature(self.run)
            accepted = {k: v for k, v in kwargs.items() if k in sig.parameters}
            output = await self.run(**accepted)
            latency = (time.monotonic() - start) * 1000
            if output is None:
                return ToolResult(self.name, ok=False, error="ابزار خروجیِ خالی برگرداند.", latency_ms=latency)
            return ToolResult(self.name, ok=True, output=str(output), latency_ms=latency)
        except Exception as exc:  # noqa: BLE001 -- عمداً گسترده: هیچ ابزاری نباید حلقه را بترکاند
            latency = (time.monotonic() - start) * 1000
            logger.warning("ابزارِ agentی «%s» خطا داد: %s", self.name, exc)
            return ToolResult(self.name, ok=False, error=f"{type(exc).__name__}: {exc}", latency_ms=latency)


class ToolRegistry:
    """مجموعه‌ی ابزارهایِ در دسترسِ یک اجرایِ حلقه‌ی عامل."""

    def __init__(self) -> None:
        self._tools: dict[str, AgentTool] = {}

    def register(self, tool: AgentTool) -> None:
        if tool.name in self._tools:
            logger.debug("ابزارِ «%s» دوباره ثبت شد؛ نسخه‌ی قبلی جایگزین می‌شود.", tool.name)
        self._tools[tool.name] = tool

    def get(self, name: str) -> AgentTool | None:
        return self._tools.get(name)

    def all(self) -> list[AgentTool]:
        return list(self._tools.values())

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def rank(self, goal_text: str, exclude: set[str] | None = None) -> list[tuple[AgentTool, float]]:
        """ابزارها را بر اساسِ تطابق با ``goal_text`` رتبه‌بندی می‌کند (نزولی)."""
        exclude = exclude or set()
        scored = [
            (tool, tool.score(goal_text))
            for tool in self._tools.values()
            if tool.name not in exclude
        ]
        scored.sort(key=lambda pair: pair[1], reverse=True)
        return scored


# ==============================================================
#   ساختِ رجیستریِ پیش‌فرض -- آداپتورِ موتورهایِ موجودِ پروژه
# --------------------------------------------------------------
# ``ai`` نمونه‌ی ``TRXEnterpriseAI`` است (``core.py``)؛ این تابع فقط
# می‌خواند (``ai.session``, ``ai.db``, ``ai.image_engine``, ...)، هیچ
# وضعیتِ جدیدی روی آن نمی‌گذارد.
# ==============================================================


def build_default_registry(ai: Any) -> ToolRegistry:
    """رجیستریِ پیش‌فرضِ ابزارها را با اتصال به موتورهایِ زنده‌ی ``ai`` می‌سازد."""

    # ایمپورت‌های محلی برای پرهیز از وابستگیِ حلقوی در زمانِ importِ پکیج
    from ..tools import (
        CalculatorEngine,
        CodeIntelligence,
        FileManager,
        TranslatorEngine,
        WeatherEngine,
        WebSearchEngine,
    )

    registry = ToolRegistry()

    # ---------------------------------------------------------- جستجوی دانش/وب

    async def _web_search(query: str = "", **_: Any) -> str:
        q = (query or "").strip()
        if not q:
            return "❌ عبارتِ جستجو خالی است."
        wiki = await WebSearchEngine.get_wikipedia(ai.session, q)
        if wiki:
            return f"📚 ویکی‌پدیا:\n{wiki}"
        ddg = await WebSearchEngine.search_duckduckgo(ai.session, q)
        if ddg:
            return ddg
        return f"⚠️ چیزی برایِ «{q}» در ویکی‌پدیا/DuckDuckGo پیدا نشد."

    registry.register(
        AgentTool(
            name="web_search",
            description="جستجویِ ویکی‌پدیایِ فارسی و DuckDuckGo برایِ سؤالاتِ دانشی/واقعیت‌محور.",
            keywords=["چیست", "کیست", "کجاست", "چه کسی", "تعریف", "درباره", "جستجو", "search"],
            run=_web_search,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- پایگاه‌دانشِ محلی

    async def _knowledge_base(query: str = "", **_: Any) -> str:
        q = (query or "").strip()
        if not q:
            return "❌ عبارتِ جستجوی دانشِ محلی خالی است."
        hit = ai.db.search_knowledge(q)
        if hit:
            return f"🧠 دانشِ محلیِ ذخیره‌شده:\n{hit}"
        return "⚠️ در دانشِ محلی چیزی برای این عبارت ثبت نشده."

    registry.register(
        AgentTool(
            name="knowledge_base",
            description="بررسیِ دانشِ محلیِ ذخیره‌شده در sqlite قبل از رفتن به وب (ارزان‌تر و آفلاین).",
            keywords=["می‌دونی", "قبلا گفتم", "یادت هست"],
            run=_knowledge_base,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- آب و هوا

    _CITY_RE = re.compile(r"(?:آب\s*و\s*هوایِ?|هوایِ?|weather (?:in|of))\s+([آ-یa-zA-Z\s]{2,30})")

    async def _weather(query: str = "", **_: Any) -> str:
        match = _CITY_RE.search(query or "")
        city = match.group(1).strip() if match else None
        if not city:
            return "❌ نامِ شهر برایِ آب‌وهوا مشخص نیست."
        return await WeatherEngine.get_weather(ai.session, city)

    registry.register(
        AgentTool(
            name="weather",
            description="دریافتِ وضعیتِ فعلیِ آب‌وهوایِ یک شهر (wttr.in).",
            keywords=["آب و هوا", "هوا چطوره", "weather", "دما"],
            run=_weather,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- ماشین‌حساب

    async def _calculator(query: str = "", **_: Any) -> str:
        return CalculatorEngine.safe_eval(query or "", formatter_func=lambda r: str(r))

    registry.register(
        AgentTool(
            name="calculator",
            description="محاسبه‌ی امنِ عبارت‌های ریاضی (بدونِ eval خام، فقط ast).",
            keywords=["+", "-", "*", "/", "محاسبه", "حاصل", "جمع", "تفریق", "ضرب", "تقسیم"],
            run=_calculator,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- ترجمه

    async def _translator(query: str = "", **_: Any) -> str:
        return await TranslatorEngine.get_translation(ai.session, query or "", mode="auto")

    registry.register(
        AgentTool(
            name="translator",
            description="ترجمه‌ی خودکارِ متن بینِ فارسی و انگلیسی.",
            keywords=["ترجمه", "translate", "معنی جمله"],
            run=_translator,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- بینایی/تصویر (آخرین تصویرِ آپلودشده)

    async def _vision(query: str = "", **_: Any) -> str:
        image_path = getattr(ai, "_last_image_path", None)
        if not image_path:
            return "⚠️ هیچ تصویری در این جلسه آپلود نشده تا تحلیل شود."
        if any(kw in (query or "") for kw in ("متنِ", "متن", "بخوان", "OCR", "ocr")):
            return await ai.image_engine.read_text(image_path, session=ai.session)
        return await ai.image_engine.describe(image_path, query or "", session=ai.session)

    registry.register(
        AgentTool(
            name="vision",
            description="توصیف/OCR روی آخرین تصویرِ آپلودشده در همین جلسه (Gemini Vision).",
            keywords=["عکس", "تصویر", "image", "عکسو", "بخوان"],
            run=_vision,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- تحلیل‌گرِ کد

    async def _code_intelligence(query: str = "", **_: Any) -> str:
        return CodeIntelligence.analyze_and_fix(query or "")

    registry.register(
        AgentTool(
            name="code_intelligence",
            description="تحلیلِ ساختاری/امنیتیِ یک قطعه‌کدِ پایتون (بر پایه‌ی ast، بدونِ اجرا).",
            keywords=["```", "کد", "دیباگ", "def ", "import "],
            run=_code_intelligence,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- خوانشِ فایل

    _PATH_RE = re.compile(r"([./]?[\w\-./]+\.(?:pdf|docx?|xlsx?|txt|py|json|csv|html?|md))", re.IGNORECASE)

    async def _file_read(query: str = "", **_: Any) -> str:
        match = _PATH_RE.search(query or "")
        if not match:
            return "❌ مسیرِ فایلِ معتبری در متنِ هدف پیدا نشد."
        return FileManager.read_file(match.group(1))

    registry.register(
        AgentTool(
            name="file_read",
            description="خوانشِ محتوایِ یک فایلِ محلی (pdf/docx/xlsx/txt/py/json/csv/html/md) که مسیرش در هدف آمده.",
            keywords=[".pdf", ".docx", ".xlsx", ".txt", ".csv", "فایل"],
            run=_file_read,
            read_only=True,
        )
    )

    # ---------------------------------------------------------- کارها/یادآوری (نوشتنی)

    async def _add_task(query: str = "", **_: Any) -> str:
        result = ai.task_manager.add_from_text(query or "", project=ai.session_mgr.active_session)
        return result.get("message", str(result)) if isinstance(result, dict) else str(result)

    registry.register(
        AgentTool(
            name="add_task",
            description="ثبتِ یک کار/یادآوریِ جدید بر اساسِ متنِ هدف.",
            keywords=["یادآوری", "کار جدید", "task", "بهم یادآوری کن"],
            run=_add_task,
            read_only=False,
        )
    )

    return registry
