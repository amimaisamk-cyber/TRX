# -*- coding: utf-8 -*-
"""
trx_ai.agent.cognition -- پیاده‌سازیِ «Cognition Core Upgrade» سند.

اصلِ بنیادیِ سند: ``AI CORE > AGENT > TOOLS`` (نه ``WEB > AGENT > ANSWER``).

این پکیج *بالایِ* ``trx_ai.agent`` (Agent Loop موجود) می‌نشیند -- هیچ‌چیزِ
موجود را حذف/بازنویسی نمی‌کند (بخشِ ۲۷: اصلِ Modular/Additive)، فقط قبل
از رسیدن به AgentLoop یک لایه‌ی «فکرکردن» اضافه می‌کند:

    User -> Understanding -> Context -> Reasoning -> Planning
         -> AgentController (روی AgentLoop موجود) -> Reflection
         -> Response -> User

استفاده‌ی سریع (دقیقاً هم‌شکلِ ``AgentLoop`` قبلی، برایِ جایگزینیِ ساده
در ``core.py``)::

    from trx_ai.agent.cognition import CognitionCore

    core = CognitionCore(registry)
    trace = await core.run(goal)   # -> همان AgentTrace قبلی
    print(trace.final_answer)
"""

from __future__ import annotations

import time

from ..planner import LlmDecideFunc
from ..tool_registry import ToolRegistry
from ..types import ActionType, AgentConfig, AgentStep, AgentTrace, StopReason
from .context import CognitionContext, ContextEngine
from .decision import AgentController, StepRun
from .planning import Plan, PlanningEngine
from .reasoning import ReasoningEngine, ReasoningVerdict
from .reflection import CognitionReflector, ReflectionReport
from .response import ResponseEngine
from .state import CognitionState, CognitionStateTracker
from .understanding import Understanding, analyze as analyze_understanding

__all__ = [
    "CognitionContext",
    "CognitionCore",
    "CognitionState",
    "CognitionStateTracker",
    "ContextEngine",
    "AgentController",
    "Plan",
    "PlanningEngine",
    "ReasoningEngine",
    "ReasoningVerdict",
    "ReflectionReport",
    "CognitionReflector",
    "ResponseEngine",
    "StepRun",
    "Understanding",
]


class CognitionCore:
    """
    هماهنگ‌کننده‌ی نهایی -- جایگزینِ نقطه‌ی ورودیِ ``AgentLoop`` در
    فراخوان‌هایِ سطحِ‌بالا (مثلِ ``core.py``)، بدونِ تغییرِ شکلِ خروجی.

    خودِ ``AgentLoop`` دست‌نخورده باقی می‌ماند و در ``AgentController``
    برایِ اجرایِ واقعیِ هر گام (با تمامِ guardrailهایِ موجود) استفاده
    می‌شود -- این کلاس فقط *قبل* از آن فکر می‌کند و *بعد* از آن پاسخ را
    طبیعی می‌کند.
    """

    def __init__(
        self,
        registry: ToolRegistry,
        config: AgentConfig | None = None,
        llm_decide: LlmDecideFunc | None = None,
    ):
        self.registry = registry
        self.config = config or AgentConfig()
        self._llm_decide = llm_decide

    async def run(
        self,
        goal: str,
        *,
        ai: object = None,
        db: object = None,
        topic: str | None = None,
        turn_count: int = 0,
        previous_failures: int = 0,
    ) -> AgentTrace:
        goal = (goal or "").strip()
        tracker = CognitionStateTracker()
        start = time.monotonic()

        if not goal:
            tracker.enter(CognitionState.FAILED, note="هدفِ خالی")
            trace = AgentTrace(goal=goal, stop_reason=StopReason.ERROR)
            trace.final_answer = "❌ هدفی برای عامل مشخص نشده."
            return trace

        # ۱) Understanding
        tracker.enter(CognitionState.UNDERSTANDING)
        understanding = analyze_understanding(
            goal, db=db, topic=topic, turn_count=turn_count, previous_failures=previous_failures
        )

        # ۲) Context -- ``query=goal`` تا حافظه‌ی بلندمدت/معنایی
        #    (``ai.memory.get_relevant_memory``) واقعاً چیزی برای
        #    جستجوکردن داشته باشد (قبل از این ارتقا همیشه خالی می‌ماند).
        context = ContextEngine.build(
            ai=ai,
            query=goal,
            topic=topic,
            turn_count=turn_count,
            previous_failures=previous_failures,
        )

        # ۳) Reasoning -- قبل از هر انتخابِ ابزار (بخشِ ۵ و ۱۱)
        tracker.enter(CognitionState.REASONING)
        verdict = ReasoningEngine.assess(understanding, context)

        if not verdict.needs_tool:
            # مسیرِ گفتگویِ محض -- هیچ ابزاری، هیچ Web ای (بخشِ ۱۳).
            tracker.enter(CognitionState.RESPONDING, note="گفتگوی محض، بدونِ ابزار")
            body = ResponseEngine.compose_conversation(understanding)
            tracker.enter(CognitionState.COMPLETED)
            trace = AgentTrace(
                goal=goal,
                final_answer=body,
                success=True,
                stop_reason=StopReason.GOAL_SATISFIED,
                total_wall_seconds=time.monotonic() - start,
            )
            return trace

        # ۴) Planning -- تجزیه‌ی هدف به مرحله(ها) (بخشِ ۶)
        tracker.enter(CognitionState.PLANNING, note=verdict.rationale)
        plan = PlanningEngine.build_plan(goal, verdict)

        # ۵) Execute -- تفویض به AgentController (روی AgentLoop موجود)
        controller = AgentController(self.registry, self.config, llm_decide=self._llm_decide)
        runs = await controller.run_plan(plan, tracker)

        # ۶) Reflect -- بررسیِ واقعیِ نتیجه (بخشِ ۸)
        tracker.enter(CognitionState.REFLECTING)
        report = CognitionReflector.evaluate(len(plan.steps), runs)

        # ۷) Replan محدود: اگر Reflection گفت «Web می‌تونست کمک کنه» و
        #    بودجه باقی مانده، فقط همان گام‌هایِ شکست‌خورده را یک‌بار با
        #    Web مجاز دوباره امتحان کن (بخشِ ۲۵: Error Recovery، نه
        #    شکستِ کاملِ بی‌بازگشت).
        remaining_wall = self.config.max_wall_seconds - (time.monotonic() - start)
        if report.replan_with_web_indices and remaining_wall > 3.0:
            tracker.enter(CognitionState.REPLANNING, note="retry با Web مجاز برایِ گام‌هایِ شکست‌خورده")
            retry_plan = Plan(
                goal=plan.goal,
                is_multi_step=plan.is_multi_step,
                steps=[
                    step
                    for step in plan.steps
                    if step.index in report.replan_with_web_indices
                ],
            )
            for step in retry_plan.steps:
                step.allow_web = True  # type: ignore[misc]  -- retry صریحاً Web را مجاز می‌کند

            retry_config = AgentConfig(
                max_steps=self.config.max_steps,
                max_wall_seconds=max(3.0, remaining_wall),
                max_calls_per_tool=self.config.max_calls_per_tool,
                allowed_tools=self.config.allowed_tools,
                min_confidence_to_finish=self.config.min_confidence_to_finish,
                verbose=self.config.verbose,
            )
            retry_controller = AgentController(self.registry, retry_config, llm_decide=self._llm_decide)
            retry_runs = await retry_controller.run_plan(retry_plan, tracker)

            by_index = {r.step.index: r for r in runs}
            for retry_run in retry_runs:
                by_index[retry_run.step.index] = retry_run
            runs = [by_index[s.index] for s in plan.steps if s.index in by_index]

            tracker.enter(CognitionState.REFLECTING, note="ارزیابیِ مجدد بعدِ retry")
            report = CognitionReflector.evaluate(len(plan.steps), runs)

        # ۸) Response -- پاسخِ طبیعیِ نهایی (بخشِ ۱۶)
        tracker.enter(CognitionState.RESPONDING)
        body, success, stop_reason, tools_used = ResponseEngine.compose_plan_result(
            understanding, runs, report
        )

        tracker.enter(CognitionState.COMPLETED if success else CognitionState.FAILED)

        # جمع‌کردنِ همه‌ی AgentStepهایِ زیرگام‌ها با ایندکسِ پیوسته -- برایِ
        # سازگاریِ کاملِ با فراخوان‌هایِ فعلی (مثلِ ``core.py``) که
        # ``trace.steps`` را برایِ خلاصه‌ی ابزارهایِ استفاده‌شده می‌خوانند.
        merged_steps: list[AgentStep] = []
        for run in runs:
            for step in run.trace.steps:
                merged_steps.append(
                    AgentStep(
                        index=len(merged_steps),
                        action=step.action,
                        result=step.result,
                        reflection=step.reflection,
                    )
                )

        trace = AgentTrace(
            goal=goal,
            steps=merged_steps,
            final_answer=body,
            success=success,
            stop_reason=stop_reason,
            total_wall_seconds=time.monotonic() - start,
        )
        return trace
