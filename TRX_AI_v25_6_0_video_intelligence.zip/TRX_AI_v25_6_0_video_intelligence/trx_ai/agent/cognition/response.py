# -*- coding: utf-8 -*-
"""
response.py -- «پاسخِ طبیعیِ TRX» (بخشِ ۱۶ سند: UI نباید Searching/Extracting
نشان دهد؛ خروجیِ اصلی باید پاسخِ TRX باشد).

این ماژول متنِ خامِ گام‌ها را به یک پاسخِ خوانا تبدیل می‌کند و -- اگر
Reasoning تشخیص داده بود که این یک گفتگویِ احساسی بود -- از همان
``response_strategy.reply_hints``/``communication_profile`` (که از قبل
و آفلاین در پروژه هست) برایِ یک مقدمه‌ی هم‌دلانه استفاده می‌کند؛ هیچ
متنِ پاسخِ جدیدی از صفر اختراع نمی‌کند.

ارتقایِ v25.4.1 (Communication Core): پیش از این، ``reply_hint`` همیشه
دقیقاً همان یک جمله را برمی‌گرداند -- کاربری که چند نوبتِ پی‌درپی همان
حالت را دارد (مثلاً چندبار «خسته‌ام») هر بار عیناً همان متن را می‌دید،
که حسِ رباتیِ تکراری می‌دهد (بخشِ ۱۳ سند). و ``communication_profile``
اصلاً جایی خوانده نمی‌شد -- تعریف‌شده بود ولی مُرده (بخشِ ۱ سند: توهمِ
پیشرفت). حالا این ماژول: (۱) بر اساسِ ``turn_count`` (که از ``Context``
واقعی می‌آید، نه همیشه صفر) بینِ چند نسخه‌ی هم‌معنیِ hint می‌چرخد، و
(۲) وقتی ``communication_profile`` می‌گوید ``length="short"``، بدنه‌ی
نتیجه‌ی ابزارها را کوتاه می‌کند تا کاربرِ خسته/کلافه یک دیوارِ متن کنارِ
پیامِ هم‌دلانه نبیند.
"""

from __future__ import annotations

from ... import response_strategy
from ..reflection import StepReflector
from ..types import StopReason
from .decision import StepRun
from .reflection import ReflectionReport
from .understanding import Understanding

#: سقفِ بدنه‌ی نتیجه وقتی ``communication_profile(...)["length"] == "short"``
#: است -- عددی دلبخواهی نیست: تقریباً هم‌اندازه‌یِ ۲-۳ پاراگرافِ کوتاه،
#: یعنی هنوز جواب کامل و قابلِ‌فهم می‌ماند، فقط دیوارِ متن نمی‌شود.
_SHORT_BODY_CHARS = 420


class ResponseEngine:
    """ساختِ پاسخِ نهاییِ متنی از رویِ خروجیِ Reasoning/Planning/Reflection."""

    @staticmethod
    def _pick_hint(strategy: str, understanding: Understanding) -> str | None:
        """
        یکی از نسخه‌هایِ هم‌معنیِ hint را برمی‌گرداند -- اگر فقط یک نسخه
        وجود داشته باشد، همیشه همان (بدونِ تغییرِ رفتار برایِ راهبردهایی
        که هنوز نسخه‌ی دومی برایشان نوشته نشده). اگر چند نسخه باشد،
        بر اساسِ ``turn_count`` واقعی می‌چرخد تا تکراریِ عینی نشود --
        همان ``turn_count``ای که در ارتقایِ Context Core به Understanding
        وصل شد (پیش از آن همیشه صفر بود).
        """
        variants = response_strategy.reply_hints(strategy)
        if not variants:
            return None
        if len(variants) == 1:
            return variants[0]
        try:
            turn_count = int((understanding.raw.get("context") or {}).get("turn_count", 0) or 0)
        except Exception:  # noqa: BLE001
            turn_count = 0
        return variants[turn_count % len(variants)]

    @staticmethod
    def _shorten_body(body: str) -> str:
        """کوتاه‌کردنِ بدنه‌ی طولانی -- ترجیحاً روی مرزِ یک پاراگراف/گامِ
        کامل، نه وسطِ کلمه، تا خواندنی بماند."""
        if len(body) <= _SHORT_BODY_CHARS:
            return body
        cut = body.rfind("\n\n", 0, _SHORT_BODY_CHARS)
        if cut < 100:
            cut = body.rfind(" ", 0, _SHORT_BODY_CHARS)
        if cut < 50:
            cut = _SHORT_BODY_CHARS
        return body[:cut].rstrip() + "\n\n… (خلاصه کردم؛ اگه جزئیاتِ کامل رو می‌خوای، بگو)"

    @staticmethod
    def compose_conversation(understanding: Understanding) -> str:
        """مسیرِ «بدونِ ابزار» -- گفتگویِ محض (بخشِ ۱۳ سند)."""
        hint = ResponseEngine._pick_hint(understanding.response_strategy, understanding)
        if hint:
            return hint
        return "باشه، شنیدم. اگه چیزی هست که بتونم کمکت کنم، فقط بگو."

    @staticmethod
    def compose_plan_result(
        understanding: Understanding,
        runs: list[StepRun],
        reflection: ReflectionReport,
    ) -> tuple[str, bool, StopReason, list[str]]:
        """
        مسیرِ «با ابزار» -- ترکیبِ نتیجه‌ی همه‌ی گام‌ها به یک پاسخِ واحد.

        خروجی: ``(متن, success, stop_reason, tools_used)``.
        """
        if not runs:
            return (
                "❌ نتونستم برای این درخواست هیچ گامی اجرا کنم.",
                False,
                StopReason.ERROR,
                [],
            )

        tools_used: list[str] = []
        for run in runs:
            for step in run.trace.steps:
                if step.action.tool_name and step.action.tool_name not in tools_used:
                    tools_used.append(step.action.tool_name)

        is_multi = len(runs) > 1
        segments: list[str] = []
        for i, run in enumerate(runs):
            answer = (run.trace.final_answer or "").strip()
            if not answer:
                continue
            if is_multi:
                segments.append(f"{i + 1}. {run.step.text.strip()}\n{answer}")
            else:
                segments.append(answer)

        body = "\n\n".join(segments) if segments else (
            "❌ هیچ گامی نتیجه‌ی قابلِ‌استفاده‌ای نداد."
        )

        # لحنِ هم‌دلانه را فقط وقتی اضافه می‌کنیم که Reasoning اصلاً به این
        # جمع‌بندی رسیده که کاربر حالِ خاصی داشته و *هم‌زمان* یک درخواستِ
        # کاری هم داشته (وگرنه مسیرِ ``compose_conversation`` جدا اجرا شده).
        hint = ResponseEngine._pick_hint(understanding.response_strategy, understanding)
        if hint and understanding.user_state != "neutral":
            profile = response_strategy.communication_profile(understanding.response_strategy)
            if profile.get("length") == "short":
                body = ResponseEngine._shorten_body(body)
            body = f"{hint}\n\n{body}"

        success = reflection.satisfied
        last_stop = runs[-1].trace.stop_reason
        if any(r.trace.stop_reason == StopReason.NEEDS_USER_INPUT for r in runs) and not success:
            stop_reason = StopReason.NEEDS_USER_INPUT
        elif success:
            stop_reason = StopReason.GOAL_SATISFIED
        else:
            stop_reason = last_stop

        return body, success, stop_reason, tools_used

