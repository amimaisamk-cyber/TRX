# -*- coding: utf-8 -*-
"""
state.py -- ماشین‌حالتِ صریحِ ``CognitionCore`` (بخشِ ۱۵ سندِ ارتقا).

هدف: هر اجرایِ ``CognitionCore.run(...)`` باید از یک توالیِ مشخص و
قابل‌دیباگِ حالت‌ها عبور کند -- نه یک جعبه‌سیاه. این ماژول فقط داده و
یک ثبت‌کننده‌ی سبک است؛ هیچ منطقِ تصمیم‌گیری‌ای اینجا نیست (همان اصلِ
جداییِ مسئولیت که در بقیه‌ی ``trx_ai.agent`` رعایت شده).

سبک/Lazy نگه‌داشته شده (بخشِ ۲۶ سند: محدودیت‌هایِ گوشی) -- فقط یک
لیستِ کوچک در حافظه، بدونِ هیچ I/O یا وابستگیِ بیرونی.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class CognitionState(str, Enum):
    """توالیِ حالت‌هایِ یک اجرایِ کاملِ Cognition Core (دقیقاً بخشِ ۱۵ سند)."""

    IDLE = "idle"
    UNDERSTANDING = "understanding"
    REASONING = "reasoning"
    PLANNING = "planning"
    EXECUTING = "executing"
    OBSERVING = "observing"
    REFLECTING = "reflecting"
    REPLANNING = "replanning"
    RESPONDING = "responding"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class StateTransition:
    state: CognitionState
    note: str = ""
    timestamp: float = field(default_factory=time.monotonic)


class CognitionStateTracker:
    """
    ثبتِ توالیِ حالت‌هایِ یک اجرا -- برایِ لاگ/دیباگ (نه برایِ نمایش به
    کاربرِ نهایی). هیچ اعتبارسنجی‌ِ سخت‌گیرانه‌ای روی توالیِ مجاز انجام
    نمی‌دهد (مثلاً REPLANNING -> EXECUTING مجاز است) چون قصدِ این کلاس
    مشاهده‌پذیری است، نه اجبارِ یک state machine رسمی.
    """

    def __init__(self) -> None:
        self._history: list[StateTransition] = []
        self.enter(CognitionState.IDLE)

    def enter(self, state: CognitionState, note: str = "") -> None:
        self._history.append(StateTransition(state=state, note=note))

    @property
    def current(self) -> CognitionState:
        return self._history[-1].state

    @property
    def history(self) -> list[StateTransition]:
        return list(self._history)

    def format_trace_fa(self) -> str:
        """نمایشِ خلاصه‌ی توالیِ حالت‌ها به فارسی -- فقط برایِ حالتِ verbose/لاگ."""
        return " → ".join(t.state.value for t in self._history)
