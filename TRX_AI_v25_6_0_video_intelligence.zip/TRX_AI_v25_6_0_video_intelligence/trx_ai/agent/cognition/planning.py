# -*- coding: utf-8 -*-
"""
planning.py -- «برای رسیدن به هدف چه مراحلی لازم است؟» (بخشِ ۶ سند).

فرقِ این لایه با ``HeuristicPlanner`` (در ``trx_ai.agent.planner``):
آن یکی در *حینِ* اجرا، گام‌به‌گام «ابزارِ بعدی چیست؟» تصمیم می‌گیرد؛
این‌جا *قبل* از اجرا، هدف به یک فهرستِ مراحل (در صورتِ چندمرحله‌ای
بودن) تجزیه می‌شود -- دقیقاً مثالِ بخشِ ۶ سند:

    «این پروژه را بررسی کن و مشکل اصلی را پیدا کن.»
        Step 1 -> ساختار پروژه را بررسی کن
        Step 2 -> ...

هر ``PlanStep`` یک زیرهدفِ متنی + سرنخِ ابزار/مجازبودنِ Web دارد که از
``ReasoningEngine`` می‌آید؛ اجرایِ واقعیِ هر گام هنوز با
``trx_ai.agent.loop.AgentLoop`` (guardrail/retry/reflection کاملِ
موجود) انجام می‌شود -- این لایه فقط *چیدمانِ* مراحل است، نه اجرایشان.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .reasoning import ReasoningEngine, ReasoningVerdict

#: سقفِ تعدادِ زیرگام‌ها -- محدودیتِ گوشی (بخشِ ۲۶)، از رشدِ بی‌رویه‌ی
#: یک هدفِ عجیب‌وغریب با ده‌ها "و بعد" جلوگیری می‌کند.
MAX_PLAN_STEPS = 4


@dataclass
class PlanStep:
    index: int
    text: str
    preferred_tool: str | None
    allow_web: bool


@dataclass
class Plan:
    goal: str
    steps: list[PlanStep] = field(default_factory=list)
    is_multi_step: bool = False


class PlanningEngine:
    """ساختِ یک ``Plan`` از رویِ هدفِ خام + ``ReasoningVerdict`` سطحِ‌بالا."""

    @classmethod
    def build_plan(cls, goal: str, verdict: ReasoningVerdict) -> Plan:
        goal = (goal or "").strip()

        if not verdict.is_multi_step:
            return Plan(
                goal=goal,
                is_multi_step=False,
                steps=[
                    PlanStep(
                        index=0,
                        text=goal,
                        preferred_tool=verdict.preferred_tool,
                        allow_web=verdict.allow_web,
                    )
                ],
            )

        raw_parts = [
            p.strip()
            for p in ReasoningEngine._MULTI_STEP_CONNECTORS.split(goal)  # noqa: SLF001
            if p.strip()
        ]
        raw_parts = raw_parts[:MAX_PLAN_STEPS] or [goal]

        steps: list[PlanStep] = []
        for i, part in enumerate(raw_parts):
            tool_hint, allow_web = ReasoningEngine.local_gate(part)
            steps.append(
                PlanStep(
                    index=i,
                    text=part,
                    preferred_tool=tool_hint or (verdict.preferred_tool if i == 0 else None),
                    allow_web=allow_web,
                )
            )

        return Plan(goal=goal, is_multi_step=len(steps) > 1, steps=steps)
