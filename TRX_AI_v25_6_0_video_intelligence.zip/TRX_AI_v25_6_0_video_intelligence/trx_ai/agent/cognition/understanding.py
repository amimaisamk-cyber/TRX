# -*- coding: utf-8 -*-
"""
understanding.py -- لایه‌یِ «درکِ زبانِ طبیعی و هدفِ کاربر» (بخشِ ۳.۱ سند).

این ماژول عمداً هیچ NLUیِ جدیدی از صفر نمی‌سازد -- طبقِ اصلِ خودِ سند
(بخشِ ۳.۱: «نباید صرفاً keyword matching باشد») از موتورهایِ *موجودِ*
پروژه استفاده می‌کند که خودشان دقیقاً همین کار را می‌کنند:

    ``trx_ai.intelligence.IntentEngine``  -> نیت + اطمینان
    ``trx_ai.understanding.build_understanding`` -> User State + Phase +
        Response Strategy (از یک سندِ ارتقایِ قبلی، دقیقاً همان لایه‌ای
        که این ماژول باید رویش بایستد، نه آن را بازنویسی کند)

تنها چیزِ *جدیدِ* این فایل، طبقه‌بندیِ «نوعِ درخواست» (پرسش/دستور/
گفتگو/کمک) است که سندِ فعلی (بخشِ ۳.۱) صریحاً خواسته و در هیچ‌جایِ
دیگرِ پروژه وجود نداشت.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Optional

from ...intelligence import IntentEngine
from ... import understanding as legacy_understanding

# --------------------------------------------------------------------
#   طبقه‌بندیِ نوعِ درخواست (Request Kind)
# --------------------------------------------------------------------
# عمداً heuristic و سبک -- طبقِ فلسفه‌یِ کلِ پروژه (بدونِ نیاز به مدل).
# این *جایگزینِ* IntentEngine نیست؛ یک لایه‌یِ درشت‌دانه‌ترِ بالایِ آن
# است که Reasoning Engine (بخشِ ۵) برایِ تصمیمِ «اصلاً ابزار لازم است؟»
# به آن نیاز دارد.

_QUESTION_MARKERS = re.compile(
    r"(چیست|چیه|کیست|کیه|کجاست|کجاس|چرا|چطور|چگونه|آیا|\?|چند(?:ه|است)?)"
)
#: عمداً بدونِ لنگرِ ``^``: در فارسیِ محاوره‌ای فعلِ امری اغلب انتهایِ
#: جمله می‌آید («این پروژه رو بررسی کن»)، نه ابتدایِ آن.
_COMMAND_MARKERS = re.compile(
    r"(برو|پیدا کن|بررسی کن|بساز|بنویس|محاسبه کن|ترجمه کن|بخوان|"
    r"جستجو کن|تحلیل کن|یادآوری کن|ثبت کن|اضافه کن)"
)
_HELP_MARKERS = re.compile(r"(کمکم کن|راهنمایی|چیکار کنم|چطور می‌تونم)")


def classify_request_kind(text: str) -> str:
    """
    یکی از ``question`` | ``command`` | ``help_request`` | ``conversation``.

    این فقط یک برچسبِ کمکی است -- تصمیمِ نهاییِ «نیاز به ابزار» با
    ``ReasoningEngine`` است، نه این تابع.
    """
    t = (text or "").strip()
    if not t:
        return "conversation"
    if _HELP_MARKERS.search(t):
        return "help_request"
    if _COMMAND_MARKERS.search(t):
        return "command"
    if _QUESTION_MARKERS.search(t):
        return "question"
    return "conversation"


@dataclass
class Understanding:
    """خروجیِ یکپارچه‌ی لایه‌ی Understanding -- ورودیِ Context/Reasoning."""

    text: str
    intent: str
    intent_confidence: float
    request_kind: str
    user_state: str
    user_state_secondary: list[str]
    response_strategy: str
    conversation_phase: str
    raw: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return dict(self.raw)


def analyze(
    text: str,
    *,
    db: Any = None,
    context_text: str = "",
    topic: Optional[str] = None,
    turn_count: int = 0,
    previous_failures: int = 0,
    pattern: Optional[dict] = None,
    context_modes: Optional[list[str]] = None,
) -> Understanding:
    """
    نقطه‌یِ ورودیِ اصلیِ لایه‌ی Understanding.

    ``db`` اختیاری است -- اگر داده نشود (مثلاً در تست‌هایِ آفلاین)،
    موتورهایِ زیرین به fallbackِ محلیِ خودشان می‌روند (همان رفتاری که
    از قبل در ``trx_ai.understanding``/``IntentEngine`` هست).
    """
    text = (text or "").strip()
    intent, confidence, _processed = IntentEngine.detect_intent(text, context_modes, db)

    raw = legacy_understanding.build_understanding(
        intent=intent,
        intent_confidence=confidence,
        text=text,
        context_text=context_text,
        topic=topic,
        turn_count=turn_count,
        previous_failures=previous_failures,
        pattern=pattern,
        db=db,
    )

    return Understanding(
        text=text,
        intent=intent,
        intent_confidence=float(confidence),
        request_kind=classify_request_kind(text),
        user_state=raw["user_state"]["primary"],
        user_state_secondary=list(raw["user_state"]["secondary"]),
        response_strategy=raw["response_strategy"],
        conversation_phase=raw["conversation_phase"],
        raw=raw,
    )
