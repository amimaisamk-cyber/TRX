# -*- coding: utf-8 -*-
"""
context.py -- لایه‌یِ «این پیام در چه زمینه‌ای گفته شده؟» (بخشِ ۴ سند).

طبقِ سند، Context باید ترکیبی از: تاریخچه‌ی مکالمه، حافظه‌یِ کوتاه‌مدت،
حافظه‌ی بلندمدت، موضوعِ فعال، Entityها و نتایجِ ابزارهایِ قبلی باشد.

این ماژول دوباره چیزی را بازسازی نمی‌کند -- بلکه سه منبعِ *موجودِ*
پروژه را که همین اطلاعات را دارند به یک ساختارِ واحد جمع می‌کند:

    - ``Scratchpad`` (``trx_ai.agent.memory``) -> نتایجِ ابزارهایِ همین اجرا
    - ``ai.memory`` / ``ai.db`` (اگر داده شود) -> حافظه‌ی بلندمدت/موضوعِ فعال
    - آرگومان‌هایِ صریحِ فراخوان (topic/entities/history) -> برایِ حالتی
      که فراخوان از قبل این‌ها را در دست دارد (مثلِ ``core.py``)

این لایه عمداً "بهترین‌تلاش" است: اگر منبعی در دسترس نبود (مثلاً در
تست‌هایِ آفلاین)، بی‌صدا حذف می‌شود -- هیچ استثنایی بالا نمی‌رود.

--------------------------------------------------------------------
ارتقایِ Core (v25.4.0 -- «اتصالِ واقعیِ Context»)
--------------------------------------------------------------------
تا قبل از این ارتقا، ``long_term_hint`` همیشه رشته‌ی خالی بود --
``ContextEngine.build`` هیچ‌وقت واقعاً به ``ai.memory.get_relevant_memory``/
``ai.memory.get_context``/``ai.memory.current_topic`` سر نمی‌زد، با
اینکه این متدها از قبل در ``memory_store.py`` وجود دارند و در مسیرِ
اصلیِ چت (``tool_router.py``) استفاده می‌شوند. یعنی «حافظه‌ی
بلندمدت» فقط در نام وجود داشت، نه در عمل (بخشِ ۱۲ سند: Context ≠
Memory -- اما هیچ‌کدام واقعاً وصل نبودند).

حالا اگر ``ai`` و ``query`` هر دو داده شوند، ``build`` تلاش می‌کند:
    - ``active_topic``  را از ``ai.memory.current_topic`` (اگر
      ``entity_stack`` چیزی نداشت) کامل کند.
    - ``recent_history_text`` را از ``ai.memory.get_context(...)``
      بگیرد (فقط وقتی فراخوان از قبل چیزی نداده -- بخشِ Context
      Budgeting: طول به ۸۰۰ نویسه محدود می‌شود).
    - ``long_term_hint`` را از ``ai.memory.get_relevant_memory(query)``
      بسازد (حداکثر ۳ نتیجه، هرکدام کوتاه‌شده).
همچنان کاملاً best-effort: هر خطا بی‌صدا نادیده گرفته می‌شود.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from ..memory import Scratchpad

_MAX_HISTORY_CHARS = 800
_MAX_HINT_ITEMS = 3
_MAX_HINT_CHARS = 120


@dataclass
class CognitionContext:
    """خروجیِ یکپارچه‌ی Context Engine -- ورودیِ Reasoning/Planning/Response."""

    active_topic: str = ""
    entities: list[str] = field(default_factory=list)
    recent_history_text: str = ""
    long_term_hint: str = ""
    turn_count: int = 0
    previous_failures: int = 0

    def combined_text(self) -> str:
        """متنِ فشرده‌ی همه‌ی منابعِ زمینه -- برایِ Reasoning/Planning."""
        parts = []
        if self.active_topic:
            parts.append(f"موضوعِ فعال: {self.active_topic}")
        if self.entities:
            parts.append("Entityها: " + "، ".join(self.entities))
        if self.recent_history_text:
            parts.append(self.recent_history_text)
        if self.long_term_hint:
            parts.append(f"حافظه‌ی بلندمدت: {self.long_term_hint}")
        return "\n".join(parts)


class ContextEngine:
    """ساخت/به‌روزرسانیِ ``CognitionContext`` از منابعِ در دسترس."""

    @staticmethod
    def build(
        *,
        ai: Any = None,
        query: str = "",
        topic: Optional[str] = None,
        entities: Optional[list[str]] = None,
        recent_history_text: str = "",
        turn_count: int = 0,
        previous_failures: int = 0,
    ) -> CognitionContext:
        active_topic = topic or ""
        long_term_hint = ""
        memory = getattr(ai, "memory", None) if ai is not None else None

        # اگر نمونه‌ی زنده‌ی ``TRXEnterpriseAI`` داده شده، تلاش می‌کنیم
        # موضوعِ فعال/آخرین entity را از حافظه‌ی موجودِ آن بخوانیم --
        # کاملاً محافظه‌کارانه (``getattr`` با پیش‌فرضِ امن، هیچ‌وقت crash).
        if memory is not None and not active_topic:
            current_topic = getattr(memory, "current_topic", None)
            if current_topic:
                active_topic = str(current_topic)
            else:
                entity_stack = getattr(memory, "entity_stack", None)
                if entity_stack:
                    try:
                        active_topic = str(entity_stack[-1])
                    except Exception:  # noqa: BLE001
                        active_topic = ""

        # حافظه‌ی کوتاه‌مدتِ واقعی -- فقط وقتی فراخوان از قبل چیزی
        # نداده (تا override دستی همیشه اولویت داشته باشد).
        if memory is not None and not recent_history_text:
            try:
                fetched = memory.get_context(max_messages=6, include_summary=True)
                if fetched:
                    recent_history_text = fetched[:_MAX_HISTORY_CHARS]
            except Exception:  # noqa: BLE001
                pass

        # حافظه‌ی بلندمدت/معنایی -- فقط اگر پرس‌وجویی برای جستجو داریم.
        if memory is not None and query:
            try:
                hits = memory.get_relevant_memory(query, limit=_MAX_HINT_ITEMS)
                pieces = [
                    str(hit.get("content", ""))[:_MAX_HINT_CHARS]
                    for hit in (hits or [])
                    if hit.get("content")
                ]
                if pieces:
                    long_term_hint = "؛ ".join(pieces)
            except Exception:  # noqa: BLE001
                pass

        # تعدادِ نوبت‌ها -- اگر فراخوان مقدار نداده، از تاریخچه‌ی
        # واقعی تخمین می‌زنیم (بهتر از همیشه صفر بودن).
        if memory is not None and turn_count == 0:
            short_term = getattr(memory, "short_term", None)
            if short_term:
                try:
                    turn_count = len(short_term)
                except Exception:  # noqa: BLE001
                    turn_count = 0

        return CognitionContext(
            active_topic=active_topic,
            entities=list(entities or []),
            recent_history_text=recent_history_text,
            long_term_hint=long_term_hint,
            turn_count=turn_count,
            previous_failures=previous_failures,
        )

    @staticmethod
    def from_scratchpad(scratchpad: Scratchpad, base: CognitionContext) -> CognitionContext:
        """افزودنِ خلاصه‌ی نتایجِ ابزارهایِ *همین اجرا* به یک Context موجود."""
        obs_text = scratchpad.context_text()
        merged_history = (
            f"{base.recent_history_text}\n{obs_text}".strip()
            if base.recent_history_text
            else obs_text
        )
        return CognitionContext(
            active_topic=base.active_topic,
            entities=base.entities,
            recent_history_text=merged_history,
            long_term_hint=base.long_term_hint,
            turn_count=base.turn_count,
            previous_failures=base.previous_failures,
        )
