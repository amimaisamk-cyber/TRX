# -*- coding: utf-8 -*-
"""
decision.py -- ``AgentController``: اجرایِ یک ``Plan`` چندمرحله‌ای.

طبقِ بخشِ ۹ سند («Tool Registry نباید تصمیم‌گیرِ اصلی باشد») و بخشِ ۷
(«Agent Loop جدید»)، این ماژول *خودش* هیچ ابزاری صدا نمی‌زند و هیچ
guardrail/retry از نو نمی‌سازد -- برایِ هر ``PlanStep``، همان
``trx_ai.agent.loop.AgentLoop`` (با تمامِ محافظت‌های موجودش: بودجه،
تکرارِ ابزار، امضایِ فراخوانی) را با یک ``allowed_tools`` فیلترشده
(طبقِ تصمیمِ Reasoning Engine درباره‌ی Web) صدا می‌زند.

مسئولیتِ *جدیدِ* این فایل فقط دو چیز است:
    ۱) تقسیمِ بودجه‌ی کلی بینِ چند زیرگام (به‌جایِ یک هدفِ تخت).
    ۲) انتقالِ نتیجه‌ی یک گام به‌عنوانِ زمینه به گامِ بعدی.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from ..loop import AgentLoop
from ..planner import LlmDecideFunc
from ..tool_registry import ToolRegistry
from ..types import AgentConfig, AgentTrace, StopReason
from .planning import Plan, PlanStep
from .state import CognitionState, CognitionStateTracker


def _with_reasoning_hint(
    step: PlanStep, registry: ToolRegistry, upstream: LlmDecideFunc | None
) -> LlmDecideFunc:
    """
    استفاده از همان قلابِ اختیاریِ ``llm_decide`` که ``AgentPlanner`` از قبل
    برایِ اتصالِ یک تصمیم‌گیرِ خارجی طراحی کرده بود (``planner.py``) --
    اما به‌جایِ یک LLM واقعی، پیشنهادِ *قطعیِ* Reasoning Engine
    (``step.preferred_tool``) را در همان قالبِ ساختاریافته تزریق می‌کند.

    فقط در *اولین* تصمیمِ این زیرگام اثر می‌گذارد (وقتی scratchpad هنوز
    خالی است)؛ از گامِ دوم به بعد بی‌صدا به heuristic معمولی (رتبه‌بندیِ
    کلیدواژه‌ای) برمی‌گردد -- دقیقاً همان تضمینِ «هرگز چیزی را نمی‌شکند»
    که خودِ ``planner.py`` مستند کرده.
    """

    async def _decide(goal: str, context_text: str) -> dict[str, Any] | None:
        if upstream is not None:
            try:
                result = await upstream(goal, context_text)
                if result is not None:
                    return result
            except Exception:  # noqa: BLE001 -- سقوطِ امن به بخشِ زیر
                pass

        is_first_call = (not context_text) or context_text.strip().startswith("(هنوز")
        if is_first_call and step.preferred_tool and registry.get(step.preferred_tool) is not None:
            return {
                "action": "tool",
                "tool": step.preferred_tool,
                "args": {"query": goal},
                "thought": f"Reasoning Engine ابزارِ «{step.preferred_tool}» را توصیه کرد.",
            }
        return None

    return _decide


@dataclass
class StepRun:
    step: PlanStep
    trace: AgentTrace


class AgentController:
    """اجراکننده‌ی یک ``Plan`` -- زیرِ Cognition Core، بالایِ ``AgentLoop``."""

    def __init__(
        self,
        registry: ToolRegistry,
        base_config: AgentConfig | None = None,
        llm_decide: LlmDecideFunc | None = None,
    ):
        self.registry = registry
        self.base_config = base_config or AgentConfig()
        self._llm_decide = llm_decide

    async def run_plan(
        self,
        plan: Plan,
        state_tracker: CognitionStateTracker,
    ) -> list[StepRun]:
        runs: list[StepRun] = []
        start = time.monotonic()
        steps_used = 0
        prev_answer = ""

        for step in plan.steps:
            remaining_steps = self.base_config.max_steps - steps_used
            remaining_wall = self.base_config.max_wall_seconds - (time.monotonic() - start)
            if remaining_steps <= 0 or remaining_wall <= 0:
                break

            allowed_tools = self._allowed_tools_for(step)
            sub_config = AgentConfig(
                max_steps=max(1, min(remaining_steps, self.base_config.max_steps)),
                max_wall_seconds=max(3.0, remaining_wall),
                max_calls_per_tool=self.base_config.max_calls_per_tool,
                allowed_tools=allowed_tools,
                min_confidence_to_finish=self.base_config.min_confidence_to_finish,
                verbose=self.base_config.verbose,
            )

            step_text = step.text
            if prev_answer and plan.is_multi_step:
                step_text = f"(نتیجه‌ی مرحله‌یِ قبل: {prev_answer[:300]})\nهدف: {step.text}"

            state_tracker.enter(CognitionState.EXECUTING, note=f"گامِ {step.index + 1}: {step.text[:60]}")
            step_decide = _with_reasoning_hint(step, self.registry, self._llm_decide)
            trace = await AgentLoop(self.registry, sub_config, llm_decide=step_decide).run(step_text)
            state_tracker.enter(CognitionState.OBSERVING, note=f"نتیجه‌ی گامِ {step.index + 1}: success={trace.success}")

            steps_used += trace.tool_calls_made() or 1
            if trace.success and trace.final_answer:
                prev_answer = trace.final_answer

            runs.append(StepRun(step=step, trace=trace))

            if trace.stop_reason == StopReason.BUDGET_EXHAUSTED:
                break

        return runs

    def _allowed_tools_for(self, step: PlanStep) -> set[str] | None:
        base_allowed = self.base_config.allowed_tools
        universe = set(base_allowed) if base_allowed is not None else set(self.registry.names())
        if not step.allow_web:
            universe.discard("web_search")
        return universe
