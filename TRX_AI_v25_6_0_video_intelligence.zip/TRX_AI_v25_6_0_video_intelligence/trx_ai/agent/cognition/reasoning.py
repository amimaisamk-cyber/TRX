# -*- coding: utf-8 -*-
"""
reasoning.py -- «قبل از انتخابِ Tool باید مشخص شود مسئله چیست» (بخشِ ۵).

این فایل پیاده‌سازیِ مستقیمِ دو قانونِ بنیادیِ سند است:

    بخشِ ۵:  Reasoning First, Tool Second
    بخشِ ۱۱: NEVER_USE_WEB_BY_DEFAULT

قبل از این ماژول، ``HeuristicPlanner`` مستقیماً ابزارها را بر اساسِ
تطابقِ کلیدواژه‌ای رتبه‌بندی می‌کرد -- و چون کلیدواژه‌هایِ ``web_search``
(«چیست»، «کیست»، «درباره»، ...) در گفتارِ روزمره‌ی فارسی بسیار رایج‌اند،
همان مشکلِ دقیقِ بخشِ ۱ سند («Search > Web > Answer» به‌جایِ یک AI
مرکزی) رخ می‌داد.

``ReasoningEngine.assess`` این گام را *قبل* از رتبه‌بندیِ ابزار اضافه
می‌کند: تشخیص می‌دهد اصلاً ابزار لازم است یا نه، و اگر لازم است، آیا
Web مجاز است یا باید به ابزارهایِ محلی/دانشِ داخلی بسنده شود.

هیچ استثنایی throw نمی‌کند (همان اصلِ کلِ ``trx_ai.agent``)؛ در نبودِ
سرنخِ کافی، محافظه‌کارانه‌ترین گزینه (عدمِ نیاز به Web) انتخاب می‌شود --
دقیقاً معنیِ «NEVER_USE_WEB_BY_DEFAULT».
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from .context import CognitionContext
from .understanding import Understanding

# --------------------------------------------------------------------
#   حالت‌هایِ «گفتگو/احساسی» -- این‌ها هرگز نباید Tool صدا بزنند
#   (تستِ ۱ سند: «از دستت خسته شدم» -> Conversation، نه Web)
# --------------------------------------------------------------------
_CONVERSATIONAL_STATES = {
    "tired", "frustrated", "confused", "disengaged", "sad", "angry",
    "stressed", "bored", "dissatisfied", "satisfied", "excited", "happy",
}

# --------------------------------------------------------------------
#   سرنخ‌هایِ محلی/بدونِ‌نیاز-به-وب -- اگر هرکدام مطابقت داشت، ابزارِ
#   محلیِ مربوطه انتخاب می‌شود و Web به‌طورِ صریح رد می‌شود.
# --------------------------------------------------------------------
_LOCAL_TOOL_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("code_intelligence", re.compile(r"```|(?:^|\s)def\s|(?:^|\s)import\s|تابع|خطا (?:می‌ده|میده|داره)|traceback", re.IGNORECASE)),
    ("file_read", re.compile(r"\.(pdf|docx?|xlsx?|txt|py|json|csv|html?|md)\b", re.IGNORECASE)),
    ("calculator", re.compile(r"[\d۰-۹]\s*[+\-*/×÷]\s*[\d۰-۹]|محاسبه کن|حاصلِ|حاصل\s")),
    ("translator", re.compile(r"ترجمه کن|ترجمه‌ش|translate")),
    ("weather", re.compile(r"آب\s*و\s*هوا|هوای?\s+\S+\s+چطور")),
    ("add_task", re.compile(r"یادآوری کن|بهم یادآوری|تسکِ جدید|کارِ جدید")),
]

# --------------------------------------------------------------------
#   سرنخ‌هایِ «اطلاعاتِ زنده/جدید لازم است» (بخشِ ۱۱). دو‌سطحی:
#     STRONG  -> به‌تنهایی کافی‌اند (قیمت/نرخ/اخبار/... همیشه یعنی
#                داده‌ی بیرونی، صرفِ‌نظر از باقیِ جمله)
#     WEAK    -> کلماتِ زمانِ عمومی («امروز»، «الان») که در گفتارِ
#                احساسی/گفتگوییِ روزمره هم زیاد می‌آیند («امروز خیلی
#                خسته‌ام») -- این‌ها *به‌تنهایی* کافی نیستند؛ فقط وقتی
#                کنارِ یک نشانه‌یِ پرسشِ صریح باشند حساب می‌شوند.
# --------------------------------------------------------------------
_STRONG_LIVE_MARKERS = re.compile(
    r"(آخرین|جدیدترین|قیمتِ?\s|نرخِ?\s|اخبار|خبرِ|نتیجه‌یِ بازی|زنده)"
)
_WEAK_TIME_MARKERS = re.compile(
    r"(امروز|الان|اکنون|همین الان|این\s*هفته|این\s*ماه|امسال|سالِ جاری)"
)
_EXPLICIT_WEB_MARKERS = re.compile(r"(جستجو کن|سرچ کن|وب رو بگرد|گوگل کن|search)")

# سرنخِ پرسشِ دانشیِ عمومی (فقط وقتی هیچ سرنخِ محلی/گفتگویی نبود، این
# می‌تواند ما را به سراغِ knowledge_base/web ببرد -- بخشِ ۵.۲).
_FACTUAL_QUESTION_MARKERS = re.compile(r"(چیست|چیه|کیست|کیه|کجاست|تعریفِ|درباره‌یِ|درباره)")


def _is_live_info(text: str) -> bool:
    """
    STRONG به‌تنهایی کافی است. WEAK فقط وقتی همراهِ یک نشانه‌یِ پرسشِ
    صریح (بخشِ ``_QUESTION_MARKERS``-مانند یا «؟») باشد -- تا جمله‌ی
    صرفاً احساسیِ «امروز خیلی خسته‌ام» را با «قیمتِ امروزِ دلار چنده؟»
    اشتباه نگیرد.
    """
    if _STRONG_LIVE_MARKERS.search(text):
        return True
    if _WEAK_TIME_MARKERS.search(text) and ("؟" in text or re.search(r"چطور|چنده|چیست|چیه|کجاست", text)):
        return True
    return False


@dataclass
class ReasoningVerdict:
    """خروجیِ Reasoning Engine -- ورودیِ Planning Engine (بخشِ ۶)."""

    needs_tool: bool
    allow_web: bool
    preferred_tool: Optional[str]
    is_multi_step: bool
    rationale: str
    excluded_tools: set[str] = field(default_factory=set)


class ReasoningEngine:
    """
    پیاده‌سازیِ بخشِ ۵ سند: «Reasoning First, Tool Second».

    ``assess`` یک‌بار برایِ کلِ هدف صدا زده می‌شود (توسطِ ``CognitionCore``)
    و ``local_gate`` برایِ هر زیرگامِ یک برنامه‌ی چندمرحله‌ای (توسطِ
    ``PlanningEngine``) -- تا محاسبه‌ی سنگینِ NLU برایِ هر زیرگام تکرار
    نشود (بخشِ ۲۶: محدودیت‌هایِ گوشی).
    """

    # اگر هیچ ابزارِ محلی/زنده‌ای مطابقت نداشت ولی پرسش دانشیِ عمومی
    # به‌نظر می‌رسد، این ابزارها (به‌ترتیبِ اولویت) قبل از Web امتحان
    # می‌شوند -- knowledge_base همیشه ارزان‌تر/آفلاین‌تر از web_search است.
    _FALLBACK_KNOWLEDGE_TOOL = "knowledge_base"

    _MULTI_STEP_CONNECTORS = re.compile(r"(?:\s+و\s+بعد(?:ش)?\s+|\s+سپس\s+|؛|\s+و\s+همچنین\s+)")

    @staticmethod
    def _with_context_note(rationale: str, context: CognitionContext) -> str:
        """
        غنی‌سازیِ rationale با سرنخ‌هایِ واقعیِ Context (بخشِ ۱۲/۱۴ سند)
        -- تصمیمِ ابزار را تغییر نمی‌دهد (برای امنِ ماندنِ تست‌های
        موجود)، فقط قابلِ‌ردیابی می‌کند که Reasoning واقعاً چه چیزی از
        Context دیده؛ پیش از این ارتقا ``context`` اصلاً خوانده نمی‌شد.
        """
        notes = []
        if context.active_topic:
            notes.append(f"موضوعِ فعال: «{context.active_topic}»")
        if context.previous_failures >= 2:
            notes.append(f"{context.previous_failures} تلاشِ ناموفقِ اخیر")
        if context.long_term_hint:
            notes.append("سرنخِ حافظه‌ی بلندمدت موجود بود")
        if not notes:
            return rationale
        return f"{rationale} [Context: {'، '.join(notes)}]"

    @classmethod
    def assess(cls, understanding: Understanding, context: CognitionContext) -> ReasoningVerdict:
        text = understanding.text

        local_tool = cls._match_local_tool(text)
        is_multi_step = cls._looks_multi_step(text)

        # ۱) گفتگو/احساس با نبودِ هیچ سرنخِ کاریِ محلی -> اصلاً ابزار لازم نیست
        #    (تستِ ۱ سند). اگر یک سرنخِ محلیِ صریح هست (مثلاً کدی که خطا
        #    می‌ده)، حالِ احساسیِ همراهش نباید مانعِ اجرایِ ابزار شود --
        #    فقط لحنِ پاسخ را (در Response Engine) نرم می‌کند.
        if local_tool is None and not cls._has_explicit_task_marker(text):
            if understanding.user_state in _CONVERSATIONAL_STATES or understanding.request_kind == "conversation":
                return ReasoningVerdict(
                    needs_tool=False,
                    allow_web=False,
                    preferred_tool=None,
                    is_multi_step=False,
                    rationale=cls._with_context_note(
                        f"حالتِ کاربر «{understanding.user_state}» و بدونِ سرنخِ کاری -> گفتگویِ محض.",
                        context,
                    ),
                )

        # ۲) سرنخِ محلیِ صریح (کد/فایل/محاسبه/ترجمه/هوا/تسک) -> همان ابزار،
        #    Web به‌طورِ صریح از این گام حذف می‌شود.
        if local_tool is not None:
            return ReasoningVerdict(
                needs_tool=True,
                allow_web=False,
                preferred_tool=local_tool,
                is_multi_step=is_multi_step,
                rationale=cls._with_context_note(
                    f"سرنخِ محلیِ صریح برایِ ابزارِ «{local_tool}»؛ Web لازم نیست.", context
                ),
                excluded_tools={"web_search"},
            )

        # ۳) نیازِ صریح/زنده به اطلاعاتِ بیرونی -> Web مجاز است
        #    (دقیقاً استثنایِ بخشِ ۱۱: «اطلاعاتِ جدید/لحظه‌ای لازم باشد»).
        if _EXPLICIT_WEB_MARKERS.search(text) or _is_live_info(text):
            return ReasoningVerdict(
                needs_tool=True,
                allow_web=True,
                preferred_tool="web_search",
                is_multi_step=is_multi_step,
                rationale=cls._with_context_note(
                    "سرنخِ صریحِ جستجو یا نیاز به اطلاعاتِ لحظه‌ای/جدید تشخیص داده شد.", context
                ),
            )

        # ۴) پرسشِ دانشیِ عمومی بدونِ نیاز به زنده‌بودن -> اول دانشِ محلی،
        #    Web فقط اگر آن هم کافی نبود (این تصمیم را planner/loop با
        #    رتبه‌بندیِ طبیعیِ ``ToolRegistry.rank`` می‌گیرد؛ اینجا فقط
        #    هردو را مجاز می‌کنیم، نه اینکه Web را اولویتِ اول بدهیم).
        if _FACTUAL_QUESTION_MARKERS.search(text):
            return ReasoningVerdict(
                needs_tool=True,
                allow_web=True,
                preferred_tool=cls._FALLBACK_KNOWLEDGE_TOOL,
                is_multi_step=is_multi_step,
                rationale=cls._with_context_note(
                    "پرسشِ دانشیِ عمومی؛ ابتدا دانشِ محلی، وب فقط در صورتِ ناکافی‌بودن.", context
                ),
            )

        # ۵) پیش‌فرضِ نهایی طبقِ NEVER_USE_WEB_BY_DEFAULT: نه گفتگویِ خالص
        #    تشخیص داده شد، نه سرنخِ محلی، نه نیازِ زنده -- بهتر است ابزار
        #    را با احتیاط امتحان کنیم ولی Web را کنار بگذاریم؛ اگر هیچ
        #    ابزارِ دیگری هم تطابق نداشت، ``AgentLoop`` خودش به ASK_USER
        #    می‌رسد (رفتارِ امنِ موجود).
        return ReasoningVerdict(
            needs_tool=True,
            allow_web=False,
            preferred_tool=None,
            is_multi_step=is_multi_step,
            rationale=cls._with_context_note(
                "نه گفتگو، نه سرنخِ محلی، نه نیازِ زنده -- طبقِ NEVER_USE_WEB_BY_DEFAULT، Web فعلاً کنار گذاشته می‌شود.",
                context,
            ),
            excluded_tools={"web_search"},
        )

    @classmethod
    def local_gate(cls, subgoal_text: str) -> tuple[Optional[str], bool]:
        """
        نسخه‌ی سبکِ ``assess`` برایِ یک زیرگامِ برنامه‌ی چندمرحله‌ای --
        فقط سرنخ‌هایِ محلی/زنده‌ی متنی را چک می‌کند (بدونِ NLU سنگین).

        خروجی: ``(preferred_tool_or_None, allow_web)``.
        """
        local_tool = cls._match_local_tool(subgoal_text)
        if local_tool is not None:
            return local_tool, False
        if _EXPLICIT_WEB_MARKERS.search(subgoal_text) or _is_live_info(subgoal_text):
            return "web_search", True
        if _FACTUAL_QUESTION_MARKERS.search(subgoal_text):
            return cls._FALLBACK_KNOWLEDGE_TOOL, True
        return None, False

    # ------------------------------------------------------------ کمکی‌ها

    @staticmethod
    def _match_local_tool(text: str) -> Optional[str]:
        for tool_name, pattern in _LOCAL_TOOL_PATTERNS:
            if pattern.search(text or ""):
                return tool_name
        return None

    @staticmethod
    def _has_explicit_task_marker(text: str) -> bool:
        """آیا متن، صرفِ‌نظر از حالِ احساسی، یک درخواستِ کاریِ روشن دارد؟"""
        return bool(
            _is_live_info(text)
            or _EXPLICIT_WEB_MARKERS.search(text)
            or _FACTUAL_QUESTION_MARKERS.search(text)
        )

    @classmethod
    def _looks_multi_step(cls, text: str) -> bool:
        parts = [p for p in cls._MULTI_STEP_CONNECTORS.split(text or "") if p.strip()]
        return len(parts) > 1
