# -*- coding: utf-8 -*-
"""
reflection.py -- «Reflection باید واقعی باشد» (بخشِ ۸ سند).

روی ``trx_ai.agent.reflection.StepReflector`` موجود سوار می‌شود (که
خودش قبلاً کیفیتِ متنی/طول/تناقضِ ساده را با ``ReflectionEngine``ی
عمومیِ پروژه چک می‌کند) و فقط سؤال‌هایِ *مخصوصِ چندمرحله‌ای‌بودن* را
اضافه می‌کند که بخشِ ۸ صریحاً خواسته:

    - آیا هدف حل شد؟ (هر گام یا کافیِ کلی؟)
    - آیا ابزارِ اشتباه انتخاب شد؟ (گام‌هایی که هیچ ابزارِ مرتبطی
      نداشتند و به ASK_USER/بی‌نتیجه رسیدند)
    - آیا مرحله‌ی دیگری لازم است؟ (بودجه تمام نشده ولی برنامه ناقص ماند)
    - آیا باید برنامه تغییر کند (Replan)؟ -- مشخصاً: گام‌هایی که Web از
      آن‌ها دریغ شده بود و شکست خوردند، کاندیدِ یک‌بار retryِ کنترل‌شده
      با Web مجاز هستند (بخشِ ۲۵: Error Recovery، نه شکستِ کامل).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..types import StopReason
from .decision import StepRun


@dataclass
class ReflectionReport:
    satisfied: bool
    confidence: float
    notes: list[str] = field(default_factory=list)
    #: ایندکسِ گام‌هایی که کاندیدِ retryِ با Web مجاز هستند (بخشِ ۲۵).
    replan_with_web_indices: list[int] = field(default_factory=list)
    plan_incomplete: bool = False


class CognitionReflector:
    """ارزیابیِ واقعیِ نتیجه‌ی یک ``Plan`` اجراشده (نه فقط ``True`` کورکورانه)."""

    @staticmethod
    def evaluate(plan_step_count: int, runs: list[StepRun]) -> ReflectionReport:
        if not runs:
            return ReflectionReport(satisfied=False, confidence=0.0, notes=["هیچ گامی اجرا نشد."])

        notes: list[str] = []
        successes = [r for r in runs if r.trace.success]
        failures = [r for r in runs if not r.trace.success]

        satisfied = len(successes) > 0
        confidence = len(successes) / max(1, len(runs))

        plan_incomplete = len(runs) < plan_step_count
        if plan_incomplete:
            notes.append(f"فقط {len(runs)} از {plan_step_count} گامِ برنامه اجرا شد (بودجه/زمان).")

        replan_candidates: list[int] = []
        for run in failures:
            web_was_excluded = not run.step.allow_web
            no_useful_tool = run.trace.stop_reason in (
                StopReason.NEEDS_USER_INPUT,
                StopReason.NO_MORE_TOOLS,
            )
            if web_was_excluded and no_useful_tool:
                replan_candidates.append(run.step.index)
                notes.append(
                    f"گامِ {run.step.index + 1} («{run.step.text[:40]}») بدونِ ابزارِ محلیِ مناسب شکست خورد؛ "
                    "کاندیدِ retry با Web مجاز است."
                )

        if failures and not replan_candidates:
            notes.append("برخی گام‌ها شکست خوردند اما دلیل آن نبودِ Web نبود؛ retryِ Web کمکی نمی‌کند.")

        if not notes:
            notes.append("همه‌ی گام‌ها با کیفیتِ قابلِ‌قبول برآورده شدند.")

        return ReflectionReport(
            satisfied=satisfied,
            confidence=round(confidence, 3),
            notes=notes,
            replan_with_web_indices=replan_candidates,
            plan_incomplete=plan_incomplete,
        )
