# -*- coding: utf-8 -*-
"""
تصمیم‌گیرِ «گامِ بعدی چیست؟» در حلقه‌ی عامل.

دو لایه، دقیقاً به همان فلسفه‌یِ «پاسخ‌دهیِ عمومی سه‌لایه» که در بقیه‌ی
پروژه هست (README را ببینید):

1. **HeuristicPlanner** -- کاملاً محلی، بدونِ نیاز به هیچ کلید/سرویسی.
   ابزارها را بر اساسِ تطابقِ کلیدواژه‌ای با متنِ هدف رتبه‌بندی می‌کند و
   یکی‌یکی امتحان می‌کند؛ همینکه scratchpad «کافی» شد (به تشخیصِ
   ``StepReflector``)، پاسخِ نهایی را می‌سازد.
2. **قلاب (hook) اختیاریِ LLM** -- اگر فراخوان یک تابعِ async
   ``llm_decide(goal, context) -> dict | None`` بدهد (مثلاً وقتی/اگر
   این پروژه دوباره به یک LLM واقعی وصل شود)، planner اول از آن
   می‌پرسد؛ در هر خطا/پاسخِ نامعتبر، بی‌صدا به heuristic برمی‌گردد --
   یعنی وصل‌کردنِ بعدیِ یک مدل هرگز چیزی را نمی‌شکند.

خروجیِ هر دو لایه به یک ``AgentAction`` یکسان normalize می‌شود.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from ..logging_config import get_logger
from .memory import Scratchpad
from .reflection import StepReflector
from .tool_registry import ToolRegistry
from .types import ActionType, AgentAction, AgentConfig

logger = get_logger(__name__)

LlmDecideFunc = Callable[[str, str], Awaitable[dict[str, Any] | None]]


class HeuristicPlanner:
    """
    برنامه‌ریزِ محلیِ بدونِ نیاز به مدل.

    منطق در هر گام:
    ۱. اگر حداقل یک ابزار موفق بوده و ``StepReflector`` می‌گوید هدف
       برآورده شده -> ``FINAL_ANSWER``.
    ۲. وگرنه بهترین ابزارِ امتحان‌نشده را (بر اساسِ امتیازِ کلیدواژه‌ای)
       انتخاب کن -> ``TOOL_CALL``.
    ۳. اگر هیچ ابزارِ امتیازدارِ امتحان‌نشده‌ای باقی نماند:
       - اگر حداقل یک نتیجه‌ی موفق داریم -> ``FINAL_ANSWER`` (بهترینِ
         ممکن با آنچه داریم).
       - وگرنه -> ``ASK_USER`` (بهتر از حدسِ کورِ یک ابزارِ کاملاً
         نامرتبط).
    """

    #: اگر هیچ ابزاری امتیازِ تطابق بالاتر از این آستانه نداشت، آن را
    #: «نامرتبط» در نظر می‌گیریم (به‌جای صدازدنِ یک ابزارِ کاملاً بی‌ربط).
    MIN_TOOL_SCORE = 0.12

    def __init__(self, registry: ToolRegistry):
        self.registry = registry

    def decide(self, goal: str, scratchpad: Scratchpad, config: AgentConfig) -> AgentAction:
        if scratchpad.has_any_success:
            verdict = StepReflector.evaluate(goal, scratchpad)
            if verdict.satisfied and verdict.confidence >= config.min_confidence_to_finish:
                return AgentAction(
                    type=ActionType.FINAL_ANSWER,
                    thought=f"هدف با اطمینانِ {verdict.confidence:.2f} برآورده شد.",
                    final_answer=StepReflector.synthesize_answer(goal, scratchpad),
                )

        ranked = self.registry.rank(goal, exclude=scratchpad.tried_tools)
        if config.allowed_tools is not None:
            ranked = [(t, s) for t, s in ranked if t.name in config.allowed_tools]

        if ranked and ranked[0][1] >= self.MIN_TOOL_SCORE:
            best_tool, score = ranked[0]
            return AgentAction(
                type=ActionType.TOOL_CALL,
                thought=f"ابزارِ «{best_tool.name}» بیشترین تطابق را دارد (امتیاز={score:.2f}).",
                tool_name=best_tool.name,
                tool_args={"query": goal},
            )

        if scratchpad.has_any_success:
            return AgentAction(
                type=ActionType.FINAL_ANSWER,
                thought="ابزارِ مرتبطِ دیگری باقی نماند؛ با بهترینِ موجود جواب می‌دهیم.",
                final_answer=StepReflector.synthesize_answer(goal, scratchpad),
            )

        return AgentAction(
            type=ActionType.ASK_USER,
            thought="هیچ ابزاری با هدف تطابقِ کافی نداشت.",
            question=(
                "متوجهِ دقیقِ درخواستت نشدم و هیچ‌کدوم از ابزارهام (وب، آب‌وهوا، "
                "ماشین‌حساب، ترجمه، فایل، کد، ...) واضح مرتبط نبودن. می‌تونی یه‌جوریِ "
                "دیگه یا با جزئیاتِ بیشتر بگی چی می‌خوای؟"
            ),
        )


class AgentPlanner:
    """
    Wrapperِ عمومیِ planner: اول (اگر داده شده) از یک LLM می‌پرسد، در
    غیر این صورت/در هر خطا، به ``HeuristicPlanner`` سقوط می‌کند.
    """

    def __init__(
        self,
        registry: ToolRegistry,
        llm_decide: LlmDecideFunc | None = None,
    ):
        self._heuristic = HeuristicPlanner(registry)
        self._llm_decide = llm_decide

    async def decide(self, goal: str, scratchpad: Scratchpad, config: AgentConfig) -> AgentAction:
        if self._llm_decide is not None:
            try:
                raw = await self._llm_decide(goal, scratchpad.context_text())
                action = _parse_llm_decision(raw)
                if action is not None:
                    return action
            except Exception as exc:  # noqa: BLE001
                logger.warning("قلابِ LLM planner خطا داد؛ سقوط به heuristic: %s", exc)

        return self._heuristic.decide(goal, scratchpad, config)


def _parse_llm_decision(raw: dict[str, Any] | None) -> AgentAction | None:
    """
    تبدیلِ خروجیِ ساختاریافته‌ی (احتمالیِ) یک LLM به ``AgentAction``.

    فرمِ مورد انتظار:
    ``{"action": "tool"|"final"|"ask", "tool": str, "args": dict,
       "answer": str, "question": str, "thought": str}``

    هر ورودیِ نامعتبر/ناقص باعثِ ``None`` می‌شود (یعنی سقوط به heuristic)
    -- هرگز استثنا تا بیرون این تابع بالا نمی‌رود.
    """
    if not isinstance(raw, dict):
        return None
    action = raw.get("action")
    thought = str(raw.get("thought", ""))
    try:
        if action == "tool" and raw.get("tool"):
            return AgentAction(
                type=ActionType.TOOL_CALL,
                thought=thought,
                tool_name=str(raw["tool"]),
                tool_args=dict(raw.get("args") or {}),
            )
        if action == "final" and raw.get("answer"):
            return AgentAction(type=ActionType.FINAL_ANSWER, thought=thought, final_answer=str(raw["answer"]))
        if action == "ask" and raw.get("question"):
            return AgentAction(type=ActionType.ASK_USER, thought=thought, question=str(raw["question"]))
    except Exception:  # noqa: BLE001
        return None
    return None
