# -*- coding: utf-8 -*-
"""
حافظه‌ی کاریِ کوتاه‌مدتِ یک اجرایِ حلقه‌ی عامل (Scratchpad).

این «حافظه» با ``MemoryEngine`` موجودِ پروژه (`memory_store.py`) کاملاً
فرق دارد: آن یکی حافظه‌ی *بلندمدتِ* کاربر است (بین جلسات باقی می‌ماند)،
این یکی فقط طولِ عمرِ *یک* فراخوانیِ ``AgentLoop.run(...)`` را دارد --
مثلِ برگه‌ی یادداشتی که یک عامل هنگامِ حل‌کردنِ یک مسئله جلوی خودش
می‌گذارد و در پایان دور می‌ریزد.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .types import ToolResult


@dataclass
class Observation:
    tool_name: str
    ok: bool
    text: str


class Scratchpad:
    """نگه‌دارنده‌ی مشاهداتِ (نتایجِ ابزار) یک اجرا، به‌ترتیبِ زمانی."""

    def __init__(self, max_chars: int = 4000):
        self._observations: list[Observation] = []
        self._tried_tools: set[str] = set()
        self.max_chars = max_chars

    def add_result(self, result: ToolResult) -> None:
        self._tried_tools.add(result.tool_name)
        self._observations.append(
            Observation(tool_name=result.tool_name, ok=result.ok, text=result.as_observation())
        )

    @property
    def tried_tools(self) -> set[str]:
        return set(self._tried_tools)

    @property
    def has_any_success(self) -> bool:
        return any(o.ok for o in self._observations)

    def successful_texts(self) -> list[str]:
        return [o.text for o in self._observations if o.ok and o.text]

    def context_text(self) -> str:
        """
        خلاصه‌ای فشرده از همه‌ی مشاهداتِ تا این لحظه -- برایِ:
        1) planner (heuristic یا LLM) تا بداند چه چیزی «قبلاً پیدا شده».
        2) StepReflector تا کامل‌بودنِ اطلاعات را ارزیابی کند.
        3) synthesize_answer تا پاسخِ نهایی را بسازد.

        سقفِ ``max_chars`` برای جلوگیری از رشدِ بی‌رویه‌ی context رعایت
        می‌شود -- دقیقاً همان فلسفه‌یِ ``runtime_intelligence.compact_text``
        در بقیه‌ی پروژه.
        """
        parts = []
        for obs in self._observations:
            mark = "✅" if obs.ok else "❌"
            parts.append(f"[{mark} {obs.tool_name}] {obs.text}")
        joined = "\n\n".join(parts)
        if len(joined) > self.max_chars:
            joined = joined[: self.max_chars].rstrip() + " …"
        return joined or "(هنوز هیچ ابزاری نتیجه‌ای برنگردانده.)"
