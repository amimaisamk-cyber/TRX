# -*- coding: utf-8 -*-
"""
``AgentLoop`` -- هماهنگ‌کننده‌ی اصلیِ حلقه‌ی عامل خودمختار.

این همان تکه‌ای است که سؤالِ کاربر را «حل می‌کند»: هدف را می‌گیرد،
مکرراً از ``AgentPlanner`` می‌پرسد «گامِ بعدی چیست؟»، ابزارِ انتخابی را
(با محافظتِ ``LoopGuard``) اجرا می‌کند، نتیجه را در ``Scratchpad``
می‌نویسد، و وقتی ``FINAL_ANSWER`` یا ``ASK_USER`` گرفت یا بودجه تمام
شد، متوقف می‌شود -- همه بدونِ اینکه کاربر مجبور باشد تک‌تکِ ابزارها را
دستی صدا بزند.

طراحیِ ماژولار عمدی است: هرکدام از این پنج نگرانی در فایلِ خودش است
و این فایل فقط آن‌ها را «سیم‌کِشی» می‌کند:

    tool_registry.py -> چه ابزارهایی هست و چطور صدا زده می‌شوند
    planner.py        -> گامِ بعدی چیست
    guardrails.py      -> آیا این گام مجاز/ایمن است
    memory.py          -> چه چیزی تا الان فهمیده‌ایم (scratchpad)
    reflection.py      -> آیا کافی است؛ پاسخِ نهایی چیست
"""

from __future__ import annotations

import time

from ..logging_config import get_logger
from .guardrails import GuardrailViolation, LoopGuard
from .memory import Scratchpad
from .planner import AgentPlanner, LlmDecideFunc
from .reflection import StepReflector
from .tool_registry import ToolRegistry
from .types import ActionType, AgentConfig, AgentStep, AgentTrace, StopReason

logger = get_logger(__name__)


class AgentLoop:
    """یک اجرایِ قابلِ‌استفاده‌ی مجددِ حلقه‌ی عامل، بسته به یک ``ToolRegistry``."""

    def __init__(
        self,
        registry: ToolRegistry,
        config: AgentConfig | None = None,
        llm_decide: LlmDecideFunc | None = None,
    ):
        self.registry = registry
        self.config = config or AgentConfig()
        self.planner = AgentPlanner(registry, llm_decide=llm_decide)

    async def run(self, goal: str) -> AgentTrace:
        """اجرایِ کاملِ حلقه برایِ یک هدفِ متنی؛ خروجی یک ``AgentTrace``."""
        goal = (goal or "").strip()
        trace = AgentTrace(goal=goal)
        if not goal:
            trace.stop_reason = StopReason.ERROR
            trace.final_answer = "❌ هدفی برای عامل مشخص نشده."
            return trace

        scratchpad = Scratchpad()
        guard = LoopGuard(self.config)
        start = time.monotonic()

        while True:
            if guard.budget_exhausted:
                trace.stop_reason = StopReason.BUDGET_EXHAUSTED
                trace.final_answer = StepReflector.synthesize_answer(goal, scratchpad)
                trace.success = scratchpad.has_any_success
                break

            action = await self.planner.decide(goal, scratchpad, self.config)
            step_index = len(trace.steps)

            if action.type == ActionType.FINAL_ANSWER:
                trace.steps.append(AgentStep(index=step_index, action=action))
                trace.final_answer = action.final_answer
                trace.success = True
                trace.stop_reason = StopReason.GOAL_SATISFIED
                break

            if action.type == ActionType.ASK_USER:
                trace.steps.append(AgentStep(index=step_index, action=action))
                trace.final_answer = action.question
                trace.success = False
                trace.stop_reason = StopReason.NEEDS_USER_INPUT
                break

            # ActionType.TOOL_CALL
            tool = self.registry.get(action.tool_name or "")
            if tool is None:
                logger.warning("planner ابزارِ ناشناخته‌ی «%s» را انتخاب کرد.", action.tool_name)
                trace.steps.append(
                    AgentStep(
                        index=step_index,
                        action=action,
                        reflection={"error": "ابزار در رجیستری پیدا نشد"},
                    )
                )
                # این را هم به‌عنوانِ «امتحان‌شده» علامت می‌زنیم که در حلقه‌ی
                # بعدی planner دوباره همان ابزارِ ناموجود را انتخاب نکند.
                scratchpad._tried_tools.add(action.tool_name or "")  # noqa: SLF001
                continue

            try:
                guard.check_before_call(tool.name, action.tool_args)
            except GuardrailViolation as violation:
                logger.info("گاردریل مانعِ فراخوانیِ «%s» شد: %s", tool.name, violation)
                trace.steps.append(
                    AgentStep(index=step_index, action=action, reflection={"guardrail": str(violation)})
                )
                trace.stop_reason = StopReason.GUARDRAIL_TRIPPED
                trace.final_answer = StepReflector.synthesize_answer(goal, scratchpad)
                trace.success = scratchpad.has_any_success
                break

            result = await tool.run_safe(**action.tool_args)
            guard.record_call(tool.name, action.tool_args)
            guard.record_step()
            scratchpad.add_result(result)

            verdict = StepReflector.evaluate(goal, scratchpad)
            trace.steps.append(
                AgentStep(
                    index=step_index,
                    action=action,
                    result=result,
                    reflection={"satisfied": verdict.satisfied, "confidence": verdict.confidence},
                )
            )

            if self.config.verbose:
                logger.info(
                    "گامِ %d: ابزار=%s ok=%s اطمینان=%.2f",
                    step_index + 1,
                    tool.name,
                    result.ok,
                    verdict.confidence,
                )

        trace.total_wall_seconds = time.monotonic() - start
        return trace


async def run_agent(
    registry: ToolRegistry,
    goal: str,
    config: AgentConfig | None = None,
    llm_decide: LlmDecideFunc | None = None,
) -> AgentTrace:
    """تابعِ راحتِ یک‌خطی برایِ کدهایی که نمی‌خواهند خودشان ``AgentLoop`` بسازند."""
    return await AgentLoop(registry, config=config, llm_decide=llm_decide).run(goal)
