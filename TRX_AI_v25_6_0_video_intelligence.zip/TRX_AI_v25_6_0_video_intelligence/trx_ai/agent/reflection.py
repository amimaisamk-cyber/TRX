# -*- coding: utf-8 -*-
"""
ارزیابیِ «آیا هدف برآورده شده؟» و سنتزِ پاسخِ نهایی از رویِ scratchpad.

این ماژول عمداً روی ``intelligence.ReflectionEngine`` موجود سوار می‌شود
(به‌جای بازنویسی از صفر) تا همان معیارِ کیفیت/طول/تناقض که برای پاسخ‌هایِ
عادیِ برنامه استفاده می‌شود، برایِ پاسخِ نهایی حلقه‌ی عامل هم اعمال شود؛
فقط یک معیارِ اضافه (پیشرفتِ واقعی/تعدادِ موفقیت) روی آن می‌گذاریم که
مخصوصِ چندمرحله‌ای‌بودنِ agent loop است.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from ..intelligence import ReflectionEngine
from .memory import Scratchpad


@dataclass
class ReflectionVerdict:
    satisfied: bool
    confidence: float
    reason: str


class StepReflector:
    """پُلی بینِ ``ReflectionEngine`` عمومیِ پروژه و نیازهایِ حلقه‌ی عامل."""

    @staticmethod
    def evaluate(goal: str, scratchpad: Scratchpad) -> ReflectionVerdict:
        if not scratchpad.has_any_success:
            return ReflectionVerdict(False, 0.0, "هنوز هیچ ابزاری نتیجه‌ی موفق نداده.")

        combined = "\n".join(scratchpad.successful_texts())
        check = ReflectionEngine.check(combined, goal)

        confidence = check["confidence"]
        satisfied = (not check["needs_refinement"]) and confidence >= 0.5

        # سیگنالِ اضافه‌یِ مخصوصِ agent: اگر متنِ جمع‌شده به‌قدرِ کافی
        # با کلیدواژه‌های هدف پوشانی دارد و هیچ نشانه‌ی خطا/عدمِ نتیجه
        # نیست، اطمینان را کمی بالا می‌بریم تا حلقه بی‌جهت ادامه پیدا
        # نکند (پرهیز از over-calling ابزارها).
        goal_words = set(re.findall(r"[آ-ی\w]{3,}", (goal or "").lower()))
        answer_words = set(re.findall(r"[آ-ی\w]{3,}", combined.lower()))
        overlap_ratio = len(goal_words & answer_words) / max(1, len(goal_words))
        if overlap_ratio > 0.3 and "⚠️" not in combined:
            confidence = min(1.0, confidence + 0.1)

        reason = "؛ ".join(check["issues"]) if check["issues"] else "کیفیتِ پاسخ قابلِ‌قبول است."
        return ReflectionVerdict(satisfied=satisfied, confidence=confidence, reason=reason)

    @staticmethod
    def synthesize_answer(goal: str, scratchpad: Scratchpad) -> str:
        """ساختنِ پاسخِ نهاییِ خوانا از رویِ مشاهداتِ موفقِ scratchpad."""
        texts = scratchpad.successful_texts()
        if not texts:
            return (
                "❌ متأسفانه با ابزارهایِ در دسترس نتوانستم اطلاعاتِ کافی برایِ "
                f"«{goal}» پیدا کنم. می‌تونی سؤال رو دقیق‌تر یا به‌شکلِ دیگه‌ای بپرسی؟"
            )

        seen: set[str] = set()
        deduped: list[str] = []
        for text in texts:
            key = text.strip()[:120]
            if key in seen:
                continue
            seen.add(key)
            deduped.append(text.strip())

        body = "\n\n".join(deduped)
        refined = ReflectionEngine.refine_answer(
            body, goal, issues=[], suggestions=[]
        )
        return refined
