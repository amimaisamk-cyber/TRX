# -*- coding: utf-8 -*-
"""
understanding.py -- ``ConversationUnderstanding``: ساختارِ مرکزیِ بخشِ
۳۳ سندِ ارتقا.

این ماژول عمداً هیچ‌کدام از موتورهایِ زیرینِ خودش را از نو محاسبه
نمی‌کند -- Intent (از ``IntentEngine``/``nlu.scorer`` که از قبل وجود
دارند)، Topic و Pattern (از ``ConversationPatternEngine`` که از قبل
وجود دارد) باید توسطِ صدازننده حاضر و آماده داده شوند. این تابع فقط
User State + Conversation Phase + Response Strategی را *اضافه* و همه
را در یک دیکشنریِ واحد جمع می‌کند -- دقیقاً طبقِ اصلِ معماریِ سند
(بخشِ ۲۴): «سه سیستمِ مستقل ولی قابلِ همکاری»، نه ادغام/بازنویسی.
"""

from __future__ import annotations

from typing import Optional

from .nlu import conversation_phase as phase_engine
from .nlu import user_state as user_state_engine
from . import response_strategy


def build_understanding(
    *,
    intent: str,
    intent_confidence: float,
    text: str,
    context_text: str = "",
    topic: Optional[str] = None,
    turn_count: int = 0,
    previous_failures: int = 0,
    pattern: Optional[dict] = None,
    db=None,
) -> dict:
    """
    خروجی دقیقاً هم‌شکلِ نمونه‌یِ بخشِ ۳۳ سند است:

        {
          "intent": {"name": ..., "confidence": ...},
          "user_state": {"primary": ..., "secondary": [...], "confidence": ...},
          "topic": ...,
          "conversation_phase": ...,
          "context": {"turn_count": ..., "previous_failures": ...},
          "pattern": {...},
          "response_strategy": ...,
        }
    """
    state_result = user_state_engine.detect(text, context_text=context_text, db=db)
    secondary = [s.state for s in state_result.states if s.state != state_result.primary_state]

    conv_phase = phase_engine.detect_phase(
        text, user_state=state_result.primary_state, previous_failures=previous_failures,
    )

    strategy = response_strategy.choose_strategy(
        state_result.primary_state,
        phase=conv_phase,
        uncertain=state_result.uncertain,
        secondary_states=secondary,
    )

    return {
        "intent": {"name": intent, "confidence": round(float(intent_confidence), 3)},
        "user_state": {
            "primary": state_result.primary_state,
            "secondary": secondary,
            "confidence": state_result.confidence,
            "uncertain": state_result.uncertain,
        },
        "topic": topic or "",
        "conversation_phase": conv_phase,
        "context": {"turn_count": turn_count, "previous_failures": previous_failures},
        "pattern": pattern or {},
        "response_strategy": strategy,
    }
