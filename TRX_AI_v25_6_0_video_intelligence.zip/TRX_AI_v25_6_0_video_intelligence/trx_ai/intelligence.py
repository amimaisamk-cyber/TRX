# -*- coding: utf-8 -*-
"""
موتورهای «تفکر» سیستم: تشخیص نیت، امتیازدهی ابزار، خودارزیابی پاسخ
(Reflection) و یادگیری خودکار از نتایج جستجوی وب.

این ماژول کاملاً بدون‌حالت (stateless) است و به هیچ‌یک از ماژول‌های
دیگر برنامه وابسته نیست؛ به همین دلیل به‌سادگی قابل تست واحد است.
"""

from __future__ import annotations

import random
import re
from .logging_config import get_logger

logger = get_logger(__name__)

# ==========================================================
#   IntentEngine / ToolScorer -- لایه‌ی سازگاری
# ----------------------------------------------------------
# پیاده‌سازیِ واقعیِ تشخیصِ نیت به trx_ai.nlu منتقل شده (رجوع به
# روادمپِ ماژولارسازی). این‌ها همان چهار ماژولی‌اند که کلاس‌هایِ
# پایین‌تر برایِ رابطِ سازگاریِ خودشان لازم دارند.
from . import nlu as _nlu
from .nlu import normalizer as _nlu_normalizer
from .nlu import registry as _nlu_registry
from .nlu.matchers import keyword as _keyword_matcher
from .nlu.matchers import synonym as _synonym_matcher
from .nlu.matchers import regex as _regex_matcher
from .nlu.matchers import fuzzy as _fuzzy_matcher
from .nlu.matchers import semantic as _semantic_matcher
from .nlu.smalltalk_registry import SMALLTALK_SPECS

# ==========================================================
#   هسته‌ی ++C اختیاری برایِ تشخیصِ نیت (بخشِ زیرِ فشار)
# ----------------------------------------------------------
# `IntentEngine.detect_intent` روی *هر پیامِ ورودی* اجرا می‌شود و طبق
# اندازه‌گیری، حلقه‌ی امتیازدهیِ کلیدواژه‌ای (۲۱ نیت × تا ۱۵۶ کلیدواژه،
# با ساختِ regex تازه برای هر کلیدواژه در هر فراخوانی) حدودِ ۶۵۰
# میکروثانیه به ازای هر پیام طول می‌کشد — تنها بخشِ واقعاً «زیرِ فشار»ِ
# این پروژه. آن حلقه در trx_ai/native/intent_native.cpp به ++C بازنویسی
# شده (بدونِ pybind11، مستقیم با CPython C API، پس وابستگیِ نصبیِ
# اضافه‌ای ندارد).
#
# اگر ماژولِ کامپایل‌شده (`_intent_native*.so`) کنارِ این فایل باشد،
# ازش استفاده می‌شود؛ وگرنه به‌طور کاملاً شفاف به همان پیاده‌سازیِ خالصِ
# پایتونی برمی‌گردیم — یعنی نصب‌نکردنِ کامپایلر هرگز برنامه را نمی‌شکند،
# فقط این یک تابع کمی کندتر اجرا می‌شود.
try:
    from . import _intent_native as _native  # type: ignore
except ImportError:
    _native = None
    logger.info(
        "ماژولِ نیتیوِ ++C (_intent_native) پیدا نشد؛ از نسخه‌ی خالصِ پایتونیِ "
        "تشخیصِ نیت استفاده می‌شود. برایِ سرعتِ بیشتر: "
        "bash trx_ai/native/build_and_install.sh"
    )


class JokeEngine:
    """
    مجموعه‌ای از جوک/لطیفه‌های تمیز و خانوادگی به فارسی، برای نیتِ
    «joke». عمداً از موضوعاتِ حساس (سیاسی، قومیتی، جنسیتی، توهین‌آمیز)
    پرهیز شده است.
    """

    _JOKES = [
        "یارو به دکترش می‌گه: دکتر هر وقت قهوه می‌خورم چشمم درد می‌گیره. دکتر می‌گه: قاشق رو از فنجون بردار!",
        "معلم پرسید: بچه‌ها بگید «هیچ‌کس» با چه حرفی شروع می‌شه؟ یکی گفت: با فرار از مدرسه، آقا معلم!",
        "پسر به باباش می‌گه: بابا فرق «نمی‌دونم» و «نمی‌خوام بدونم» چیه؟ بابا می‌گه: نمی‌دونم، نمی‌خوام بدونم!",
        "دو تا کامپیوتر با هم چت می‌کردن، یکیشون گفت: من مریضم. اون یکی گفت: ویروس گرفتی؟",
        "یارو زنگ می‌زنه اورژانس می‌گه: بیمارستان اونجاست؟ می‌گن بله. می‌گه: خب چرا جواب تلفنو می‌دی، بدو برس!",
        "مهندس نرم‌افزار به همسرش می‌گه برو نون بگیر، اگه تخم‌مرغ داشتن ۱۲ تا بگیر. زنش با ۱۲ تا نون برمی‌گرده. می‌گه چرا اینقدر نون گرفتی؟ می‌گه: تخم‌مرغ داشتن!",
        "بچه از باباش پرسید: بابا چرا بعضی‌ها می‌گن پول خوشبختی نمیاره؟ بابا گفت: چون بلد نیستن درست خرجش کنن!",
        "یارو رفته دندون‌پزشکی می‌گه: دکتر دندونم درد می‌کنه ولی دکتر پول ندارم! دکتر می‌گه: نگران نباش، صدا نمی‌کنم!",
        "دو تا دوست به هم می‌گن: چرا انقدر لاغر شدی؟ اون یکی می‌گه: رفتم رژیم گرفتم. می‌پرسه چه رژیمی؟ می‌گه: هر چی تو یخچاله واسه بقیه بذارم!",
        "معلم به دانش‌آموز گفت: بگو ببینم زمینِ گرد چه شکلیه؟ گفت: مثل توپ فوتباله ولی بزرگ‌تر و بدون بادکنکِ داخلش!",
    ]

    @classmethod
    def get_random_joke(cls, exclude: str | None = None) -> str:
        """
        یک جوک تصادفی برمی‌گرداند. اگر `exclude` داده شود (آخرین جوکِ
        گفته‌شده)، تا حد امکان از تکرارِ فوری همان جوک پرهیز می‌شود.
        """
        pool = cls._JOKES
        if exclude and len(pool) > 1:
            candidates = [j for j in pool if j != exclude]
        else:
            candidates = pool
        return random.choice(candidates)


class IntentEngine:
    """
    (لایه‌ی سازگاری) تشخیصِ نیت -- پیاده‌سازیِ واقعی اکنون در
    ``trx_ai.nlu`` است (رجوع به روادمپِ ماژولارسازیِ IntentEngine).

    این کلاس فقط رابطِ عمومیِ قبلی را حفظ می‌کند:
        - ``detect_intent(text, context_modes, db)`` -> (intent, confidence, raw_text)
        - ``INTENT_PATTERNS`` / ``STRUCTURAL_COMMANDS`` / ``NEGATIONS``
        - ``_normalize`` / ``_keyword_hit_score``

    هدف: هیچ فایلِ دیگری در پروژه (core.py، benchmark.py، تست‌ها) نیازی
    به تغییر نداشته باشد. کلیدواژه‌ها/regexها/وزن‌ها دیگر اینجا تکرار
    نمی‌شوند -- منبعِ واحدِ حقیقت ``trx_ai.nlu.registry`` است (که خودش
    از ``trx_ai/nlu/intents/*.py`` خودکار بارگذاری می‌شود).
    """

    NEGATIONS = _keyword_matcher.NEGATIONS

    # نگاشتِ سازگاری با شکلِ دیکشنریِ قدیمی -- هرجایِ دیگری (اگر باشد)
    # که با ``IntentEngine.INTENT_PATTERNS[name]["keywords"]`` کار می‌کند
    # همچنان کار می‌کند.
    INTENT_PATTERNS = {
        name: {
            "keywords": list(spec.keywords),
            "regex": list(spec.regex),
            "weight": spec.weight,
            "category": spec.category,
        }
        for name, spec in _nlu_registry.PATTERNS.items()
    }

    STRUCTURAL_COMMANDS = list(_nlu_registry.STRUCTURAL)

    @staticmethod
    def _normalize(text: str) -> str:
        return _nlu_normalizer.normalize(text)

    @classmethod
    def _keyword_hit_score(cls, text: str, keyword: str) -> float:
        return _keyword_matcher.keyword_hit_score(text, keyword)

    @classmethod
    def detect_intent(cls, text, context_modes=None, db=None):
        """
        Returns: (intent_name, confidence_score, processed_text)
        -- همان قراردادِ سه‌تاییِ قبلی؛ پیاده‌سازیِ واقعی در
        ``trx_ai.nlu.scorer.detect`` است.
        """
        result = _nlu.detect(text, context=context_modes, db=db)
        return result.intent, result.confidence, result.raw_text


class ToolScorer:
    """
    (لایه‌ی سازگاری) انتخابِ بهترین ابزار -- پیاده‌سازیِ واقعی اکنون در
    ``trx_ai.nlu.scorer.score_tools`` است. ``TOOLS`` و ``_KEYWORD_SOURCE``
    دیگر دیکشنری‌هایِ دستیِ جدا نیستند؛ مستقیماً از همان registryِ
    IntentEngine ساخته می‌شوند -- دقیقاً رفعِ باگِ «دو منبعِ حقیقتِ
    موازی» که در روادمپ مستند شده بود.
    """

    TOOLS = _nlu_registry.TOOLS
    _KEYWORD_SOURCE = _nlu_registry.KEYWORD_SOURCE

    @classmethod
    def score_tools(cls, text, intent, confidence, context=None):
        """Returns: (tool_name, tool_scores_dict, tool_confidence)"""
        return _nlu.score_tools(text, intent, confidence, context=context)


class SmallTalkEngine:
    """
    پاسخِ محلی (بدونِ نیاز به هیچ APIِ بیرونی) برایِ گفتگویِ آزادِ روزمره
    — سلام‌واحوال‌پرسی، معرفیِ خود، سؤالِ توانایی‌ها، تشکر، خداحافظی و....

    چرا این کلاس اضافه شد: قبلاً وقتی هیچ نیتِ خاصی (ماشین‌حساب، ترجمه،
    جستجو، پزشکی...) تشخیص داده نمی‌شد، تنها گزینه یک جمله‌ی ثابتِ
    تکراری بود. این کلاس یک لایه‌ی میانی می‌سازد: برایِ دسته‌بندی‌هایِ
    رایجِ گفتگوی روزمره، به‌جایِ یک جمله‌ی ثابت، از میانِ چند پاسخِ متنوع
    و طبیعی به‌صورتِ تصادفی انتخاب می‌کند — یعنی حتی بدونِ هیچ APIِ
    خارجی‌ای، تجربه‌ی گفتگو قابلِ‌قبول و غیرِ رباتیک می‌ماند. سؤالاتِ
    واقعاً بازِ/خارج از این دسته‌ها به ویکی‌پدیا/DuckDuckGo (رایگان،
    بدونِ کلید) سپرده می‌شوند.

    عمداً «stateless» و بدونِ وابستگی به core.py است — فقط متن، نامِ
    کاربر و لحنِ شخصیتِ فعلی را می‌گیرد و رشته برمی‌گرداند.
    """

    # اولویتِ رفعِ تساوی وقتی چند دسته امتیازِ برابر می‌گیرند -- همان
    # ترتیبِ قدیمیِ لیستِ regex، فقط برایِ رفعِ ابهام نگه داشته شده.
    _TIEBREAK_ORDER = (
        "thanks", "farewell", "compliment", "insult", "identity",
        "capability", "boredom", "wellbeing", "greeting",
    )
    # حداقل امتیازِ لازم برایِ پذیرفتنِ یک دسته -- یک تطبیقِ تک‌کلیدواژه‌ای
    # (۱.۰) یا حتی یک نجاتِ فازی/معناییِ ضعیف (۰.۵) را رد نمی‌کند، اما
    # نویزِ خیلی کوچک را هم فیلتر می‌کند.
    _MIN_SCORE = 0.35

    @classmethod
    def _scores(cls, norm: str) -> dict[str, float]:
        scores: dict[str, float] = {}
        for name, spec in SMALLTALK_SPECS.items():
            s = 0.0
            for kw in spec.keywords:
                s += _keyword_matcher.keyword_hit_score(norm, kw)
            if spec.synonyms:
                s += _synonym_matcher.synonym_score(norm, spec.synonyms, spec.weight)
            if spec.regex:
                s += _regex_matcher.regex_score(norm, spec.regex, spec.weight)
            if s > 0:
                scores[name] = s

        # فازی -- فقط برایِ دسته‌هایی که هنوز صفرند (نجاتِ غلطِ تایپی/
        # پسوندِ محاوره‌ای، نه جایگزینیِ یک تطبیقِ دقیق).
        for name, spec in SMALLTALK_SPECS.items():
            if scores.get(name, 0.0) > 0 or not spec.fuzzy_enabled:
                continue
            fs = _fuzzy_matcher.fuzzy_score(norm, spec.keywords or spec.synonyms, spec.weight)
            if fs:
                scores[name] = fs

        # معنایی -- فقط برایِ دسته‌هایی که هنوز صفرند و فقط اگر
        # sentence-transformers واقعاً نصب/لود شده باشد؛ وگرنه بی‌صدا ۰.
        for name, spec in SMALLTALK_SPECS.items():
            if scores.get(name, 0.0) > 0 or not spec.semantic_enabled:
                continue
            ss = _semantic_matcher.semantic_score(norm, spec, spec.weight, threshold=spec.threshold)
            if ss:
                scores[name] = ss

        return scores

    @classmethod
    def categorize(cls, text: str) -> str | None:
        norm = _nlu_normalizer.normalize(text or "")
        if not norm:
            return None
        # علائمِ نگارشیِ چسبیده به کلمه (مثلِ «خوبی؟») نباید مانعِ تطبیقِ
        # کلیدواژه شوند -- matchers/keyword.py مرزِ (?!\S) می‌خواهد که با
        # یک علامتِ چسبیده نقض می‌شود؛ اینجا قبل از امتیازدهی جدا می‌شوند.
        norm = re.sub(r"[؟?!.,،؛:]+", " ", norm)
        norm = re.sub(r"\s+", " ", norm).strip()
        if not norm:
            return None
        scores = cls._scores(norm)
        if not scores:
            return None
        best = max(
            scores.items(),
            key=lambda kv: (kv[1], -cls._TIEBREAK_ORDER.index(kv[0]) if kv[0] in cls._TIEBREAK_ORDER else 0),
        )
        name, score = best
        return name if score >= cls._MIN_SCORE else None

    _RESPONSES: dict[str, list[str]] = {
        "greeting": [
            "سلام{name}! خوش اومدی، چه کمکی از دستم برمیاد؟",
            "درود{name}! امروز چطور می‌تونم کمکت کنم؟",
            "سلام{name} 🙂 آماده‌ام کمک کنم — چی تو ذهنته؟",
        ],
        "wellbeing": [
            "ممنونم{name}، من همیشه آماده و سرحالم! خودت چطوری؟",
            "عالی‌ام، مرسی که پرسیدی{name}! کاری هست انجام بدم؟",
            "خوبم{name}، در خدمتتم. چیزی لازم داری؟",
        ],
        "thanks": [
            "خواهش می‌کنم{name}، خوشحال شدم کمک کردم 🙂",
            "قابلی نداشت{name}! هر وقت خواستی در خدمتم.",
            "این وظیفمه{name}، هر سؤالِ دیگه‌ای هم داشتی بگو.",
        ],
        "farewell": [
            "خداحافظ{name}! هر وقت خواستی برگرد، اینجام.",
            "به امیدِ دیدار{name} 👋",
            "فعلاً{name}! مراقبِ خودت باش.",
        ],
        "identity": [
            "من TRX AI هستم{name}، یک دستیارِ هوشمندِ فارسی‌زبان که می‌تونم "
            "تو محاسبات، ترجمه، جستجو، سلامت، مدیریتِ کارها و خیلی چیزهایِ دیگه کمکت کنم.",
            "اسمم TRX AI‌ه{name} — طراحی شدم که به فارسی روان باهات صحبت کنم و "
            "تو کارهای روزمره‌ات کمکت کنم.",
        ],
        "capability": [
            "می‌تونم محاسبه کنم، ترجمه کنم، تو ویکی‌پدیا و وب جستجو کنم، "
            "کارها/یادآوری‌هات رو مدیریت کنم، هزینه‌هات رو ثبت کنم، BMI حساب کنم، "
            "رمزِ عبور بسازم، و به سؤالاتِ پزشکیِ عمومی هم جواب بدم. فقط بگو چی می‌خوای{name}.",
            "کارهایی مثلِ ترجمه، جستجویِ وب، ماشین‌حساب، تبدیلِ واحد، مدیریتِ "
            "کارها/خرج‌ها و مشاوره‌ی سلامتِ عمومی از پسم برمیان{name}. امتحان کن!",
        ],
        "compliment": [
            "لطف داری{name}! خوشحالم که کمک بودم 😊",
            "ممنون{name}، تلاشم اینه که بهتر و بهتر بشم.",
        ],
        "insult": [
            "متوجهم که راضی نبودی{name}. بگو دقیقاً چی درست نبود تا بهتر کمک کنم.",
            "ببخشید اگه انتظارت رو برآورده نکردم{name}؛ دوباره امتحان کنیم؟",
        ],
        "boredom": [
            "بیا یه‌کاری کنیم! می‌خوای یه جوک بگم، یا یه چیزی رو باهم جستجو کنیم؟",
            "حوصله‌ت سر رفته؟ بگو «یه جوک بگو» تا بخندونمت، یا هر سؤالی داری بپرس!",
        ],
        "courtesy_appreciation": [
            "ممنون{name} 😄 تو هم خسته نباشی!",
            "لطف داری{name}، خسته نباشی خودت هم!",
            "خیلی ممنون{name} 🙏 امیدوارم کارت راه بیفته.",
        ],
    }

    @classmethod
    def respond(cls, category: str, user_name: str | None = None) -> str | None:
        pool = cls._RESPONSES.get(category)
        if not pool:
            return None
        name_suffix = f" {user_name}" if user_name and user_name != "کاربر محترم" else ""
        template = random.choice(pool)
        return template.format(name=name_suffix)


class ReflectionEngine:
    """
    بررسی کیفیت پاسخ قبل از ارسال
    """

    @staticmethod
    def check(answer, query, context=None):
        """
        بررسی‌های پیشرفته:
        1. کامل بودن
        2. ارتباط با سؤال
        3. وجود تناقض
        4. کیفیت نگارش
        5. اطمینان از صحت
        """
        issues = []
        confidence = 1.0
        suggestions = []

        # بررسی طول
        if len(answer) < 20:
            issues.append("پاسخ بسیار کوتاه")
            confidence -= 0.2
            suggestions.append("افزودن جزئیات بیشتر")

        # بررسی نشانه‌های خطا
        if any(err in answer.lower() for err in ["❌", "خطا", "error", "متاسفم"]):
            confidence -= 0.3
            issues.append("پاسخ حاوی خطا")
            suggestions.append("تأیید اطلاعات")

        # بررسی ارتباط (کلمات مشترک)
        query_words = set(re.findall(r'[آ-ی\w]{3,}', query.lower()))
        answer_words = set(re.findall(r'[آ-ی\w]{3,}', answer.lower()))
        overlap = len(query_words & answer_words)
        if overlap == 0 and len(query_words) > 2:
            issues.append("پاسخ ممکن است بی‌ربط باشد")
            confidence -= 0.15
            suggestions.append("تطابق با سؤال")

        # بررسی وجود پاسخ واقعی
        if "نمی‌دانم" in answer or "اطلاعی ندارم" in answer:
            confidence -= 0.3
            issues.append("پاسخ مبهم")
            suggestions.append("درخواست جستجو")

        # بررسی منابع
        if any(src in answer for src in ["ویکی‌پدیا", "دانشنامه", "جستجو", "منبع"]):
            confidence += 0.1

        # بررسی تناقض (اگر Context داشته باشیم)
        if context and "پاسخ قبلی" in context:
            if any(neg in answer for neg in ["اما", "ولی", "درحالی‌که"]) and any(pos in answer for pos in ["بله", "درست"]):
                issues.append("تناقض احتمالی")
                confidence -= 0.1

        confidence = max(0.0, min(1.0, confidence))
        
        return {
            "is_valid": len(issues) == 0,
            "issues": issues,
            "suggestions": suggestions,
            "confidence": confidence,
            "needs_refinement": confidence < 0.7 or len(issues) > 0
        }

    @staticmethod
    def refine_answer(answer, query, issues, suggestions):
        """اصلاح پاسخ بر اساس بازخورد Reflection"""
        refined = answer
        
        if not issues:
            return refined
        
        # افزودن توضیح کامل‌تر
        if "پاسخ بسیار کوتاه" in issues:
            refined += "\n\nبرای اطلاعات بیشتر می‌توانید سؤال را دقیق‌تر مطرح کنید."
        
        # اصلاح ارتباط
        if "پاسخ ممکن است بی‌ربط باشد" in issues:
            refined = f"با توجه به سؤال شما '{query}':\n\n" + refined
        
        return refined

    @staticmethod
    def format_confidence(score):
        """نمایش درصد اطمینان با رنگ"""
        percent = int(score * 100)
        if percent >= 80:
            return f"[bold green]✅ اطمینان: {percent}%[/bold green]"
        elif percent >= 50:
            return f"[bold yellow]⚠️ اطمینان: {percent}%[/bold yellow]"
        else:
            return f"[bold red]❓ اطمینان: {percent}%[/bold red]"

class AutonomousLearningEngine:
    @staticmethod
    def _summarize(text, limit=2):
        clean = re.sub(r'[^\w\s]', '', text)
        words = [w for w in clean.lower().split() if len(w) > 3]
        freq = {}
        for w in words:
            freq[w] = freq.get(w, 0) + 1
        sentences = re.split(r'[.\n]', text)
        scored = {s: sum(freq.get(w, 0) for w in s.lower().split()) for s in sentences}
        top = sorted(scored.items(), key=lambda x: x[1], reverse=True)[:limit]
        result = [s[0].strip() for s in top if len(s[0].strip()) > 15]
        return ". ".join(result) + "." if result else text[:200] + "..."

    @staticmethod
    def extract_and_store_knowledge(query, web_response, db_manager):
        if not web_response or len(web_response) < 60:
            return False
        clean_query = re.sub(r'(چیست|کیست|؟)', '', query).strip().lower()
        if not clean_query:
            return False
        summary = AutonomousLearningEngine._summarize(web_response)
        db_manager.add_knowledge(clean_query, summary, confidence=0.90)
        return True
