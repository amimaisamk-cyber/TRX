# -*- coding: utf-8 -*-
"""
گزارشِ یکپارچه‌یِ سلامتِ TRX AI -- پیاده‌سازیِ مستقیمِ بندِ ۶ روادمپِ
نسخه‌ی بعدی («Evaluation داخلی»، نه به‌عنوانِ قابلیتِ کاربری):

    NLU accuracy       91 → 95
    memory precision   78 → 92
    router accuracy    87 → 94
    regressions        12 → 3

اجرا::

    python -m trx_ai.eval.report            # فقط گزارش بده
    python -m trx_ai.eval.report --save      # گزارش بده و baseline را جایگزین کن

کدِ خروج: 0 اگر هیچ رگرسیونِ شکست‌خورده/نقض‌شده‌ای نبود، وگرنه 1 --
تا بشود این را در CI هم صدا زد.
"""

from __future__ import annotations

import argparse
import sys

from ..nlu.eval import run_eval as nlu_eval
from . import baseline as baseline_mod
from . import memory_eval, regression_eval, router_eval


def collect_snapshot() -> dict:
    nlu_result = nlu_eval.evaluate()
    memory_result = memory_eval.evaluate()
    router_result = router_eval.evaluate()
    regression_result = regression_eval.evaluate()

    return {
        "nlu_accuracy": nlu_result["accuracy"],
        "memory_precision": memory_result["precision"],
        "router_accuracy": router_result["accuracy"],
        "regressions_failed": regression_result["failed"] if regression_result["available"] else None,
        "_raw": {
            "nlu": nlu_result,
            "memory": memory_result,
            "router": router_result,
            "regression": regression_result,
        },
    }


def _print_report(old: dict, new: dict) -> bool:
    """چاپِ گزارش؛ خروجی: آیا وضعیتِ فعلی «سالم» است (بدونِ نقض)."""
    healthy = True

    print("=== گزارشِ ارزیابیِ TRX AI ===\n")
    print(f"NLU accuracy       {baseline_mod.format_percent_delta(old.get('nlu_accuracy'), new['nlu_accuracy'])}")
    print(f"Memory precision   {baseline_mod.format_percent_delta(old.get('memory_precision'), new['memory_precision'])}")
    print(f"Router accuracy    {baseline_mod.format_percent_delta(old.get('router_accuracy'), new['router_accuracy'])}")

    reg = new["_raw"]["regression"]
    if reg["available"]:
        print(f"Regressions (fail) {baseline_mod.format_count_delta(old.get('regressions_failed'), reg['failed'])}   (از {reg['total']} تست)")
        if reg["missing_files"]:
            healthy = False
            print(f"  ⚠️ فایل‌هایِ رگرسیونِ یافت‌نشده: {reg['missing_files']}")
        if reg["failed"]:
            healthy = False
    else:
        print(f"Regressions (fail) — نامشخص: {reg['reason']}")

    nlu_r = new["_raw"]["nlu"]
    if nlu_r["negative_violations"]:
        healthy = False
        print(f"\n⚠️ {nlu_r['negative_violations']} نمونه‌یِ منفیِ NLU نقض شده (اجرایِ "
              f"``python -m trx_ai.nlu.eval.run_eval`` جزئیات را نشان می‌دهد).")

    router_r = new["_raw"]["router"]
    if router_r["false_positive_tools"]:
        healthy = False
        print(f"⚠️ {router_r['false_positive_tools']} نمونه‌یِ منفیِ Router نقض شده (اجرایِ "
              f"``python -m trx_ai.eval.router_eval`` جزئیات را نشان می‌دهد).")

    mem_r = new["_raw"]["memory"]
    failed_mem_cases = [
        c["name"]
        for group in (mem_r["pronoun"], mem_r["relevance"])
        for c in group["cases"]
        if not c["ok"]
    ]
    if failed_mem_cases:
        healthy = False
        print(f"⚠️ سناریوهایِ Memoryِ شکست‌خورده: {', '.join(failed_mem_cases)}")

    return healthy


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="گزارشِ یکپارچه‌یِ ارزیابیِ TRX AI")
    parser.add_argument("--save", action="store_true", help="baseline را با نتیجه‌یِ همین اجرا جایگزین کن")
    args = parser.parse_args(argv)

    old = baseline_mod.load_baseline()
    new = collect_snapshot()

    healthy = _print_report(old, new)

    if args.save:
        to_save = {k: v for k, v in new.items() if k != "_raw"}
        baseline_mod.save_baseline(to_save)
        print(f"\n✅ baseline در {baseline_mod.BASELINE_PATH} ذخیره شد.")

    return 0 if healthy else 1


if __name__ == "__main__":
    sys.exit(main())
