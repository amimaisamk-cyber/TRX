# -*- coding: utf-8 -*-
"""
شمارشِ عینیِ تست‌هایِ رگرسیون (بندِ ۶ روادمپ: ``regressions 12 → 3``).

عمداً به‌جایِ صدازدنِ pytest با subprocess (کند و شکننده در برابرِ
مسیرِ اجرا)، از APIِ برنامه‌نویسیِ خودِ pytest (``pytest.main`` +
یک پلاگینِ سبک برایِ جمع‌آوریِ نتیجه) استفاده می‌شود -- درون همان
فرآیندِ پایتون.

pytest به‌عمد به‌عنوانِ وابستگیِ اجباریِ ``trx_ai`` اضافه نمی‌شود (فقط
در ``requirements-dev.txt`` است)؛ اگر نصب نباشد، این ماژول به‌جایِ
کرش‌کردن، یک نتیجه‌ی روشن و قابلِ‌فهم برمی‌گرداند تا ``eval/report.py``
بتواند بقیه‌ی معیارها (NLU/Memory/Router) را بدونِ وقفه گزارش بدهد.
"""

from __future__ import annotations

import os

_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# فایل‌هایی که صراحتاً «تستِ رگرسیون» شمرده می‌شوند (طبقِ نام‌گذاریِ
# خودِ پروژه). افزودنِ تستِ رگرسیونِ جدید یعنی فقط اضافه‌کردن به همین
# تاپل -- این ماژول جایِ دیگری نیاز به تغییر ندارد.
REGRESSION_TEST_FILES: tuple[str, ...] = (
    "tests/test_medical_safety_regression.py",
)


class _ResultCollector:
    """پلاگینِ سبکِ pytest برایِ جمع‌آوریِ pass/fail بدونِ چاپِ اضافی."""

    def __init__(self) -> None:
        self.passed = 0
        self.failed = 0
        self.failures: list[str] = []

    def pytest_runtest_logreport(self, report):
        if report.when == "call":
            if report.outcome == "passed":
                self.passed += 1
            elif report.outcome == "failed":
                self.failed += 1
                self._record(report)
        elif report.when == "setup" and report.outcome == "failed":
            # خطایِ setup/import یعنی خودِ تست هرگز اجرا نشد -- همچنان
            # باید به‌عنوانِ شکست شمرده شود، وگرنه یک import شکسته در
            # عدد نهایی «پنهان» می‌ماند.
            self.failed += 1
            self._record(report)

    def _record(self, report) -> None:
        last_line = ""
        if report.longreprtext:
            last_line = report.longreprtext.strip().splitlines()[-1]
        self.failures.append(f"{report.nodeid}: {last_line}")


def evaluate(test_files: tuple[str, ...] | None = None) -> dict:
    """
    خروجی:
      available: آیا pytest اصلاً در دسترس بود؟
      passed / failed / total: شمارشِ تست‌ها
      missing_files: فایل‌هایِ رگرسیونی که در REGRESSION_TEST_FILES
          اسم برده شده‌اند ولی روی دیسک پیدا نشدند (نشانه‌ی جابه‌جایی/
          حذفِ سهوی)
      failures: خلاصه‌یِ هر تستِ شکست‌خورده (برایِ دیباگِ سریع)
    """
    try:
        import pytest
    except ImportError:
        return {
            "available": False,
            "reason": "pytest نصب نیست (requirements-dev.txt را نصب کنید).",
            "passed": 0,
            "failed": 0,
            "total": 0,
            "missing_files": [],
            "failures": [],
        }

    files = test_files or REGRESSION_TEST_FILES
    abs_paths = [os.path.join(_ROOT_DIR, f) for f in files]
    existing = [p for p in abs_paths if os.path.exists(p)]
    missing = [f for f, p in zip(files, abs_paths) if p not in existing]

    collector = _ResultCollector()
    if existing:
        pytest.main(["-q", "--no-header", *existing], plugins=[collector])

    total = collector.passed + collector.failed
    return {
        "available": True,
        "passed": collector.passed,
        "failed": collector.failed,
        "total": total,
        "missing_files": missing,
        "failures": collector.failures,
    }


if __name__ == "__main__":
    result = evaluate()
    if not result["available"]:
        print(f"⚠️ {result['reason']}")
    else:
        print(f"رگرسیون: {result['passed']}/{result['total']} پاس")
        if result["missing_files"]:
            print(f"⚠️ فایل‌هایِ یافت‌نشده: {result['missing_files']}")
        for line in result["failures"]:
            print(f"  ❌ {line}")
