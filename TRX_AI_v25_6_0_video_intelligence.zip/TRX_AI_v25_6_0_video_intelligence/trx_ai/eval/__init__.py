# -*- coding: utf-8 -*-
"""
لایه‌یِ ارزیابیِ یکپارچه‌ی TRX AI (بندِ ۶ روادمپِ نسخه‌ی بعدی: «Evaluation
داخلی»، هدفِ کلی‌ترِ نقشه‌راه: «Zero Blind Decisions»).

این پکیج با ``trx_ai/nlu/eval`` فرق دارد:
    trx_ai/nlu/eval   → فقط دقتِ IntentEngine.detect (متن → نیت).
    trx_ai/eval       → گزارشِ یکپارچه‌یِ چند لایه در کنارِ هم:
                        NLU (از طریقِ nlu/eval)، Memory، Router، Regression.

هیچ‌کدام از ماژول‌هایِ این پکیج «قابلیتِ کاربری» نیستند -- دقیقاً طبقِ
تأکیدِ روادمپ («نه به‌عنوانِ قابلیتِ کاربری») -- فقط ابزارِ توسعه‌اند،
شبیهِ ``scripts/benchmark.py``. هیچ‌کدام در مسیرِ اجرایِ برنامه
(main.py/web_main.py/gui_main.py) import نمی‌شوند.

استفاده::

    python -m trx_ai.eval.report            # فقط گزارش بده
    python -m trx_ai.eval.report --save      # گزارش بده و baseline را به‌روز کن
"""
