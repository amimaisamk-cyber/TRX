# -*- coding: utf-8 -*-
"""
ارزیابیِ عینیِ لایه‌ی Memory (بندِ ۶ روادمپ، پیش‌نیازِ بندِ ۲: قبل از
اینکه ``MemoryScore`` ترکیبی ساخته شود، باید یک عددِ پایه داشته باشیم
که نشان بدهد الان -- با منطقِ فعلیِ ``resolve_pronoun`` + ``get_relevant_memory``
-- چقدر درست عمل می‌کند).

دو دسته سناریو، هر دو رویِ کدِ *واقعی* اجرا می‌شوند (نه شبیه‌سازی):

۱) ``PronounScenario`` -- دقیقاً همان جریانِ دوگامیِ واقعیِ برنامه را
   تکرار می‌کند (نگاه کنید به ``core_engine/turn_processor.finalize``):
       گامِ ۱: ``extract_topic_entity(query)`` → ``add_message(..., topic=...)``
       گامِ ۲: ``resolve_pronoun(followup_query)``
   این شاملِ خودِ سناریویِ رگرسیونِ «اکبر عبدی → کوروش کبیر» هم هست، تا
   اگر کسی بعداً pattern-هایِ ``resolve_pronoun`` را دوباره شل کند،
   بلافاصله در عدد افت دیده شود -- نه فقط در یک گزارشِ کاربر.

۲) ``RelevanceScenario`` -- چند حقیقت/پروژه در حافظه ذخیره می‌شود،
   بعد پرسیده می‌شود کدام‌یک باید در رتبه‌ی اول ``get_relevant_memory``
   برگردد.

هر دو دسته با ``MemoryEngine`` واقعی و ``FakeProfileDB`` (بدونِ
vector_db، پس بدونِ نیازِ اجباری به chromadb) اجرا می‌شوند.
"""

from __future__ import annotations

from dataclasses import dataclass

from ._fakedb import FakeProfileDB
from ..memory_store import MemoryEngine


@dataclass(frozen=True)
class PronounScenario:
    name: str
    setup_query: str
    followup_query: str
    expect_injection: bool
    expected_entity: str | None = None


# نمونه‌یِ اول دقیقاً همان رگرسیونِ مستندشده در PRONOUN_MEMORY_BUGFIX_NOTES.md
# است -- نباید هرگز دوباره برگردد.
PRONOUN_SCENARIOS: tuple[PronounScenario, ...] = (
    PronounScenario(
        name="regression_akbar_abdi_kourosh",
        setup_query="اکبر عبدی که بود؟",
        followup_query="کوروش کبیر کیست؟",
        expect_injection=False,
    ),
    PronounScenario(
        name="rtx4090_price_pronoun",
        setup_query="RTX4090 چیه؟",
        followup_query="قیمتش چقدره؟",
        expect_injection=True,
        expected_entity="RTX4090",
    ),
    PronounScenario(
        name="python_learn_pronoun",
        setup_query="پایتون چیه؟",
        followup_query="اونو از کجا یاد بگیرم؟",
        expect_injection=True,
        expected_entity="پایتون",
    ),
    PronounScenario(
        name="independent_new_question",
        setup_query="زبان برنامه‌نویسی پایتون چیه؟",
        followup_query="پایتخت فرانسه کجاست؟",
        expect_injection=False,
    ),
)


@dataclass(frozen=True)
class RelevanceScenario:
    name: str
    facts: tuple[str, ...]
    query: str
    expected_substring: str


RELEVANCE_SCENARIOS: tuple[RelevanceScenario, ...] = (
    RelevanceScenario(
        name="project_language_lookup",
        facts=("پروژه‌ی فعلی‌ام با پایتون نوشته شده", "اسمِ گربه‌ام میو است"),
        query="پروژه‌ی من با چه زبانی نوشته شده",
        expected_substring="پایتون",
    ),
    RelevanceScenario(
        name="unrelated_fact_not_top",
        facts=("اسمِ گربه‌ام میو است", "علاقه‌مندِ فوتبال هستم"),
        query="گربه‌ام چه اسمی داره",
        expected_substring="میو",
    ),
)


def _run_pronoun_scenarios() -> dict:
    results = []
    for sc in PRONOUN_SCENARIOS:
        mem = MemoryEngine(FakeProfileDB())
        topic = mem.extract_topic_entity(sc.setup_query)
        mem.add_message("user", sc.setup_query, topic=topic)
        mem.add_message("assistant", "(پاسخِ فرضی برایِ آماده‌سازیِ entity_stack)")

        resolved, ref_entity = mem.resolve_pronoun(sc.followup_query)
        injected = resolved != sc.followup_query

        ok = injected == sc.expect_injection
        if ok and sc.expect_injection:
            ok = ref_entity == sc.expected_entity

        results.append({
            "name": sc.name,
            "ok": ok,
            "resolved": resolved,
            "ref_entity": ref_entity,
        })

    correct = sum(1 for r in results if r["ok"])
    return {"total": len(results), "correct": correct, "cases": results}


def _run_relevance_scenarios() -> dict:
    results = []
    for sc in RELEVANCE_SCENARIOS:
        mem = MemoryEngine(FakeProfileDB())
        for fact in sc.facts:
            mem.save_fact(fact)

        top_results = mem.get_relevant_memory(sc.query, limit=3)
        top_content = top_results[0]["content"] if top_results else ""
        ok = sc.expected_substring in top_content

        results.append({
            "name": sc.name,
            "ok": ok,
            "top_content": top_content,
        })

    correct = sum(1 for r in results if r["ok"])
    return {"total": len(results), "correct": correct, "cases": results}


def evaluate() -> dict:
    """
    خروجی:
      precision: نسبتِ کلِ سناریوهایِ درست از مجموعِ pronoun + relevance
      pronoun / relevance: جزئیاتِ هر دسته به‌طورِ جداگانه (برایِ دیباگ
          و برایِ اینکه اگر فقط یک دسته رگرس کرد، معلوم باشد کدام)
    """
    pronoun = _run_pronoun_scenarios()
    relevance = _run_relevance_scenarios()
    total = pronoun["total"] + relevance["total"]
    correct = pronoun["correct"] + relevance["correct"]
    return {
        "precision": correct / total if total else 0.0,
        "total": total,
        "correct": correct,
        "pronoun": pronoun,
        "relevance": relevance,
    }


if __name__ == "__main__":
    result = evaluate()
    print(f"دقتِ Memory: {result['precision']:.2%} ({result['correct']}/{result['total']})")
    for group_name, group in (("Pronoun", result["pronoun"]), ("Relevance", result["relevance"])):
        print(f"\n[{group_name}] {group['correct']}/{group['total']}")
        for case in group["cases"]:
            if not case["ok"]:
                print(f"  ❌ {case['name']} → {case}")
