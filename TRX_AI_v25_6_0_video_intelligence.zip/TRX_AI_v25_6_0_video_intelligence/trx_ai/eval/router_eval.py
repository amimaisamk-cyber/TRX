# -*- coding: utf-8 -*-
"""
ارزیابیِ عینیِ زنجیره‌ی «تشخیصِ نیت → انتخابِ ابزار» (بندِ ۶ روادمپ،
پیش‌نیازِ بندِ ۳: قبل از تبدیلِ Router به یک Decision Engینِ کامل
(NO_TOOL / ASK_CLARIFICATION / USE_MEMORY / ...)، باید معلوم باشد
لایه‌ی *فعلیِ* انتخابِ ابزار -- یعنی ``score_tools`` -- چقدر درست کار
می‌کند).

فرق با ``trx_ai.nlu.eval.run_eval``:
    آن هارنس فقط ``detect`` را می‌سنجد (متن → نیت). حتی اگر نیت درست
    باشد، ``score_tools`` می‌تواند به‌خاطرِ رقابتِ کلیدواژه‌ای بینِ چند
    ابزار، ابزارِ اشتباهی انتخاب کند -- خطایی که در run_eval.py اصلاً
    دیده نمی‌شود چون آن فقط ``result.intent`` را چک می‌کند.

دیتاست: به‌جایِ ساختنِ یک دیتاستِ مستقل (منبعِ سومِ حقیقت)، دقیقاً از
همان ``positive_examples``/``negative_examples`` هرِ ``IntentSpec``ای
که ``ref_tool`` دارد استفاده می‌شود -- همان فلسفه‌ی ``nlu/eval/dataset.py``.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..nlu import registry
from ..nlu.scorer import detect, score_tools


@dataclass(frozen=True)
class RouterCase:
    text: str
    expected_tool: str
    is_negative: bool = False


def build_dataset() -> list[RouterCase]:
    cases: list[RouterCase] = []
    for _name, spec in registry.PATTERNS.items():
        if not spec.ref_tool:
            continue
        for text in spec.positive_examples:
            cases.append(RouterCase(text=text, expected_tool=spec.ref_tool))
        for text in spec.negative_examples:
            cases.append(RouterCase(text=text, expected_tool=spec.ref_tool, is_negative=True))
    return cases


def evaluate() -> dict:
    """
    خروجی:
      accuracy: نسبتِ نمونه‌هایِ مثبتی که به ابزارِ درست رسیدند
      total / correct: شمارشِ خام
      false_positive_tools: تعدادِ نمونه‌هایِ منفی‌ای که اشتباهاً ابزارِ
          هدف را گرفتند (بایست صفر بماند)
      failures / false_positive_details: جزئیات برایِ دیباگ
    """
    dataset = build_dataset()
    positives = [c for c in dataset if not c.is_negative]
    negatives = [c for c in dataset if c.is_negative]

    correct = 0
    failures: list[tuple[str, str, str]] = []
    for case in positives:
        result = detect(case.text)
        tool, _scores, _conf = score_tools(case.text, result.intent, result.confidence)
        if tool == case.expected_tool:
            correct += 1
        else:
            failures.append((case.text, case.expected_tool, tool))

    false_positive_details: list[tuple[str, str]] = []
    for case in negatives:
        result = detect(case.text)
        tool, _scores, _conf = score_tools(case.text, result.intent, result.confidence)
        if tool == case.expected_tool:
            false_positive_details.append((case.text, tool))

    total = len(positives)
    return {
        "accuracy": correct / total if total else 0.0,
        "total": total,
        "correct": correct,
        "negatives_checked": len(negatives),
        "false_positive_tools": len(false_positive_details),
        "failures": failures,
        "false_positive_details": false_positive_details,
    }


if __name__ == "__main__":
    result = evaluate()
    print(f"دقتِ Router: {result['accuracy']:.2%} ({result['correct']}/{result['total']})")
    if result["failures"]:
        print("\nخطاها:")
        for text, expected, got in result["failures"]:
            print(f"  - «{text}» → انتظار: {expected} | واقعی: {got}")
    if result["false_positive_tools"]:
        print(f"\n⚠️ {result['false_positive_tools']} نمونه‌یِ منفی اشتباهاً ابزارِ هدف را گرفتند:")
        for text, tool in result["false_positive_details"]:
            print(f"  - «{text}» → نباید {tool} انتخاب می‌شد")
