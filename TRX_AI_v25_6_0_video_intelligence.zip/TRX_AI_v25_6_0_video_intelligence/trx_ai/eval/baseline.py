# -*- coding: utf-8 -*-
"""
اسنپ‌شاتِ عددیِ سلامتِ سیستم -- دقیقاً همان چیزی که روادمپ خواسته بود:

    NLU accuracy       91 → 95
    memory precision   78 → 92
    router accuracy    87 → 94
    regressions        12 → 3

فایلِ اسنپ‌شات (``eval_baseline.json`` در ریشه‌ی پروژه) عمداً در گیت
commit می‌شود -- تا هر توسعه‌دهنده/PR عددِ «قبل» را از رویِ خودِ فایل
ببیند، نه فقط از رویِ حافظه‌ی محلیِ خودش.
"""

from __future__ import annotations

import json
import os

_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BASELINE_PATH = os.path.join(_ROOT_DIR, "eval_baseline.json")


def load_baseline() -> dict:
    if not os.path.exists(BASELINE_PATH):
        return {}
    try:
        with open(BASELINE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_baseline(snapshot: dict) -> None:
    with open(BASELINE_PATH, "w", encoding="utf-8") as f:
        json.dump(snapshot, f, ensure_ascii=False, indent=2, sort_keys=True)


def format_percent_delta(old, new: float) -> str:
    """مثلِ روادمپ: ``91% → 95% ↑`` یا در نبودِ baseline: ``95% (بدونِ baseline)``."""
    if old is None:
        return f"{new:.0%}  (بدونِ baseline قبلی)"
    trend = "↑" if new > old else ("↓" if new < old else "=")
    return f"{old:.0%} → {new:.0%} {trend}"


def format_count_delta(old, new: int) -> str:
    """مثلِ روادمپ: ``12 → 3 ↓`` (برایِ regressions، کمتر یعنی بهتر)."""
    if old is None:
        return f"{new}  (بدونِ baseline قبلی)"
    trend = "↓" if new < old else ("↑" if new > old else "=")
    return f"{old} → {new} {trend}"
