# -*- coding: utf-8 -*-
"""
دیتابیسِ ساختگیِ درون‌حافظه‌ای -- فقط برایِ ایزوله‌کردنِ ``memory_eval``
از SQLiteِ واقعیِ ``DatabaseManager``: سریع‌تر است، هیچ فایلی روی دیسک
نمی‌سازد و بینِ اجراهایِ eval نشتیِ حالت ندارد.

فقط سه متدی پیاده‌سازی می‌شوند که ``MemoryEngine``/``MemoryCorrectionEngine``
واقعاً صدا می‌زنند (``get_profile``, ``set_profile``, ``get_profile_by_prefix``)
-- امضایِ دقیقاً منطبق با ``trx_ai.database.DatabaseManager``، تا اگر رفتارِ
واقعیِ آن کلاس تغییر کرد، ناسازگاری همین‌جا (نه در وسطِ eval) دیده شود.
"""

from __future__ import annotations


class FakeProfileDB:
    """پیاده‌سازیِ حداقلیِ رابطِ profile-storage، فقط برایِ eval/تست."""

    def __init__(self) -> None:
        self._store: dict[str, str] = {}

    def get_profile(self, key: str, default=None):
        return self._store.get(key, default)

    def set_profile(self, key: str, value) -> None:
        self._store[key] = value

    def get_profile_by_prefix(self, prefix: str) -> list[tuple[str, str]]:
        return [(k, v) for k, v in self._store.items() if k.startswith(prefix)]
