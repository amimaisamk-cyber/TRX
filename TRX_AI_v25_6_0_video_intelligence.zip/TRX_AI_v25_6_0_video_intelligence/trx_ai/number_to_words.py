# -*- coding: utf-8 -*-
"""
تبدیلِ عدد به حروفِ فارسی. مثال: ۱۲۳۴ → «یک هزار و دویست و سی و چهار».

محدوده‌ی پشتیبانی‌شده: اعدادِ صحیح از -999,999,999,999 تا ۹۹۹,۹۹۹,۹۹۹,۹۹۹
(تا «میلیارد»). اعدادِ اعشاری با گردکردن به عددِ صحیح رد می‌شوند (اعلامِ
صریح، نه گردکردنِ خاموش).
"""

from __future__ import annotations

import re

from .text_normalize import normalize_text as _normalize_text

_ONES = ["", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه"]
_TEENS = ["ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده",
          "شانزده", "هفده", "هجده", "نوزده"]
_TENS = ["", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"]
_HUNDREDS = ["", "صد", "دویست", "سیصد", "چهارصد", "پانصد",
             "ششصد", "هفتصد", "هشتصد", "نهصد"]
_SCALES = ["", "هزار", "میلیون", "میلیارد", "بیلیون"]


def _three_digit_to_words(n: int) -> str:
    """عددِ ۰ تا ۹۹۹ را به حروف تبدیل می‌کند."""
    if n == 0:
        return ""
    parts = []
    hundreds, remainder = divmod(n, 100)
    if hundreds:
        parts.append(_HUNDREDS[hundreds])
    if remainder:
        if remainder < 10:
            parts.append(_ONES[remainder])
        elif remainder < 20:
            parts.append(_TEENS[remainder - 10])
        else:
            tens, ones = divmod(remainder, 10)
            if ones:
                parts.append(f"{_TENS[tens]} و {_ONES[ones]}")
            else:
                parts.append(_TENS[tens])
    return " و ".join(parts)


def number_to_persian_words(n: int) -> str:
    """
    عددِ صحیح را به حروفِ فارسی تبدیل می‌کند. برای اعدادِ خارج از محدوده
    (بیشتر از ۹۹۹,۹۹۹,۹۹۹,۹۹۹,۹۹۹ یا اعشاری) ValueError می‌دهد.
    """
    if not isinstance(n, int):
        raise ValueError("فقط عددِ صحیح پشتیبانی می‌شود")
    if n == 0:
        return "صفر"

    negative = n < 0
    n = abs(n)
    if n >= 10 ** 15:
        raise ValueError("عدد خیلی بزرگ است (بیشتر از محدوده‌ی پشتیبانی‌شده)")

    groups = []
    scale_idx = 0
    while n > 0:
        n, group = divmod(n, 1000)
        if group:
            groups.append((group, scale_idx))
        scale_idx += 1

    parts = []
    for group, scale_idx in reversed(groups):
        words = _three_digit_to_words(group)
        scale = _SCALES[scale_idx] if scale_idx < len(_SCALES) else ""
        parts.append(f"{words} {scale}".strip())

    result = " و ".join(parts)
    return f"منفی {result}" if negative else result


def extract_and_convert(text: str):
    """
    اولین عددِ صحیح را از یک جمله‌ی آزاد (مثلِ «۱۲۳۴۵ رو به حروف بنویس»)
    استخراج و به حروف تبدیل می‌کند. اگر عددی پیدا نشود یا اعشاری باشد،
    پیامِ خطای مناسب برمی‌گرداند (نه استثنا).
    """
    normalized = _normalize_text(text)
    match = re.search(r'-?\d+(\.\d+)?', normalized)
    if not match:
        return "❌ عددی در متن پیدا نشد."
    raw = match.group(0)
    if "." in raw:
        return f"❌ فقط اعدادِ صحیح پشتیبانی می‌شود (نه {raw})."
    try:
        n = int(raw)
        words = number_to_persian_words(n)
        return f"🔢 {raw} → {words}"
    except ValueError as e:
        return f"❌ {e}"
