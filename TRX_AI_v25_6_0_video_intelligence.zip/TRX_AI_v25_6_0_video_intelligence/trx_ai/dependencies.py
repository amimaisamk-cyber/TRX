# -*- coding: utf-8 -*-
"""
مدیریت وابستگی‌های پروژه.

بهبود نسبت به نسخه‌ی قبلی:
    - نصب خودکار پکیج‌ها دیگر به‌صورت «پنهان» در لحظه‌ی import ماژول انجام
      نمی‌شود، بلکه از طریق تابع صریح ``ensure_required_packages()`` که فقط
      یک‌بار در نقطه‌ی ورود برنامه (main.py) فراخوانی می‌گردد.
    - رفتار پیش‌فرض دقیقاً مثل قبل حفظ شده: اگر پکیجی موجود نباشد به‌طور
      خودکار نصب می‌شود؛ اما اکنون این کار با متغیر محیطی قابل کنترل است:

        TRX_AUTO_INSTALL=0   -> نصب خودکار غیرفعال می‌شود و راهنمای نصب دستی
                                (pip install -r requirements.txt) نمایش داده می‌شود.

    - همه‌ی خطاهای نصب اکنون در فایل لاگ هم ثبت می‌شوند (قابل عیب‌یابی)،
      علاوه بر پیام فارسی که قبلاً روی صفحه چاپ می‌شد.
    - پرچم‌های در دسترس‌بودن ماژول‌های اختیاری (Chroma، SentenceTransformer،
      pdfplumber، docx، openpyxl، PIL، psutil) دقیقاً مانند نسخه‌ی اصلی حفظ
      شده‌اند تا رفتار سایر بخش‌های برنامه بدون تغییر بماند.
"""

from __future__ import annotations

import os
import subprocess
import sys

from .logging_config import get_logger

logger = get_logger(__name__)

# ==========================================
#   سه سطحِ وابستگی (CORE / OPTIONAL / EXPERIMENTAL)
# ------------------------------------------
# قبلاً همه‌چیز در یک REQUIRED_MODULES تخت بود — یعنی از نظرِ این فایل،
# نبودِ edge_tts دقیقاً هم‌ارزِ نبودِ aiohttp بود، درحالی‌که این دوتا
# اصلاً هم‌وزن نیستند: بدونِ aiohttp/rich، core.py حتی import هم
# نمی‌شود (وابستگیِ سطحِ ماژول، بدونِ try/except)؛ بدونِ edge_tts، فقط
# یک قابلیت (تبدیلِ متن‌به‌گفتار) غیرفعال می‌ماند و بقیه‌ی برنامه عادی
# کار می‌کند. این تفاوت الان صریح است:
#
#   CORE          بدونِ این‌ها TRX AI اصلاً بالا نمی‌آید.
#   OPTIONAL      هرکدام یک قابلیتِ مشخص را فعال می‌کند؛ نبودش فقط
#                 همان قابلیت را غیرفعال می‌کند (کدِ خودش از قبل
#                 try/except این حالت را دارد).
#   EXPERIMENTAL  سنگین/سرعتش کم و عمداً با ensure_required_packages
#                 نصبِ خودکار نمی‌شوند (مثلاً sentence-transformers چند
#                 صدمگابایت مدل دانلود می‌کند) — فقط تشخیص داده می‌شوند؛
#                 برای فعال‌سازی، کاربر خودش دستی نصب می‌کند.
# ==========================================

CORE_MODULES = {
    "rich": "rich",
    "aiohttp": "aiohttp",
    "bs4": "beautifulsoup4",
}

OPTIONAL_MODULES = {
    "edge_tts": "edge-tts",           # تبدیلِ متن‌به‌گفتار
    # رمزنگاریِ متن (text_crypto.py) — قبلاً نه در REQUIRED_MODULES و
    # نه در requirements.txt بود؛ کدِ خودش try/except دارد و بدونِ آن
    # اجرا می‌شود، اما قابلیتِ رمزنگاری تا ابد غیرفعال می‌ماند، حتی روی
    # یک نصبِ تازه از requirements.txt.
    "cryptography": "cryptography",
    "openpyxl": "openpyxl",           # خواندنِ اکسل
    "PIL": "pillow",                  # پردازشِ تصویر
    "pytz": "pytz",                   # منطقه‌های زمانی
    "watchdog": "watchdog",           # نظارت بر فایل
    "psutil": "psutil",               # داشبوردِ CPU/RAM
    # تقویم شمسی/ارقام فارسی با persiantools (این یکی گزارشِ خطا نداشت، ماند):
    "persiantools": "persiantools",
    # نکته: در کدِ فعلیِ پروژه هیچ‌جا import نمی‌شود (حتی یک‌بار)؛
    # aiohttp جایگزینِ آن شده. اینجا نگه داشته شده چون در
    # requirements.txt هست، اما چون واقعاً هیچ ماژولی به آن وابسته
    # نیست، به‌هیچ‌وجه fatal نیست.
    "requests": "requests",
    # نکته: این پروژه دیگر به هیچ APIِ مولدِ خارجی (Gemini یا مشابه) وصل
    # نمی‌شود؛ هیچ SDK یا پکیجِ مخصوصِ آن هم لازم نیست. تمامِ «هوش» یا
    # کاملاً محلی است یا از منابعِ رایگانِ وب (ویکی‌پدیا/DuckDuckGo) با
    # همینِ aiohttp استفاده می‌کند.
    # نکته: arabic_reshaper / python-bidi / hazm عمداً اینجا نیستند
    # (در نسخه‌ی قبلی بودند). این سه کتابخانه در محیطِ اجرای واقعی
    # (Termux/اندروید) نصب/ایمپورتشان با خطا مواجه می‌شد (hazm
    # به‌خصوص وابستگی‌های سنگینی مثل numpy/nltk دارد که روی اندروید
    # معمولاً build نمی‌شوند) و باعث می‌شد این پیام در هر اجرای برنامه
    # چاپ شود: «❌ خطا در نصب خودکار ...». کدِ استفاده از آن‌ها در
    # ui.py هم به‌طور کامل کامنت شده؛ برای فعال‌سازیِ احتمالی در آینده
    # (مثلاً روی دسکتاپ/سرور که این مشکل را ندارد)، هم اینجا و هم در
    # ui.py باید هم‌زمان از حالتِ کامنت خارج شوند.
}

# نصبِ خودکار برایِ این‌ها عمداً انجام نمی‌شود؛ فقط پایین‌تر تشخیص داده
# می‌شوند (CHROMA_AVAILABLE / SENTENCE_TRANSFORMER_AVAILABLE).
EXPERIMENTAL_MODULES = {
    "chromadb": "chromadb",
    "sentence_transformers": "sentence-transformers",
    # OCR محلیِ عکس (vision.py) — نیازمندِ باینریِ سیستمیِ Tesseract-OCR
    # هم هست، نه فقط این پکیج؛ نگاه کنید به توضیحِ OCR_AVAILABLE پایین‌تر.
    "pytesseract": "pytesseract",
    # denoiseِ کلاسیکِ قوی برایِ ابزارِ بهبودِ کیفیتِ عکس (vision.py) —
    # fastNlMeansDenoisingColored بسیار بهتر از فیلترهایِ ساده‌ی Pillow
    # عمل می‌کند، اما opencv-python چند‌ده مگابایت است و رویِ
    # Termux/اندروید همیشه wheelِ آماده ندارد؛ به همین دلیل نصبِ خودکار
    # عمداً انجام نمی‌شود (مثلِ chromadb) و کدِ vision.py بدونِ آن هم با
    # همان pipelineِ قبلیِ Pillow-only کار می‌کند (نگاه کنید به CV2_AVAILABLE).
    "cv2": "opencv-python-headless",
}

# سازگاریِ عقب‌رو: هر کدِ دیگری (یا اسکریپتِ بیرونی) که هنوز
# REQUIRED_MODULES را import می‌کند، همان چیزی را می‌بیند که قبلاً
# می‌دید (اتحادِ CORE و OPTIONAL).
REQUIRED_MODULES = {**CORE_MODULES, **OPTIONAL_MODULES}


def _install_tier(modules: dict, auto_install: bool, *, fatal: bool) -> None:
    for module_name, pip_name in modules.items():
        try:
            __import__(module_name)
        except ImportError:
            tier_fa = "حیاتی" if fatal else "اختیاری"
            if not auto_install:
                req_file = "requirements-core.txt" if fatal else "requirements.txt"
                print(
                    f"{'🔴' if fatal else '🟡'} ماژولِ {tier_fa}ِ '{module_name}' یافت نشد. "
                    f"لطفاً دستور زیر را اجرا کنید:\n"
                    f"    pip install -r {req_file}"
                )
                logger.warning("ماژول %s موجود نیست و نصب خودکار غیرفعال است (fatal=%s).", module_name, fatal)
                continue

            print(f"📦 ماژولِ {tier_fa}ِ '{module_name}' یافت نشد. در حال نصب خودکار...")
            logger.info("در حال نصب خودکار پکیج: %s (fatal=%s)", pip_name, fatal)
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", pip_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except Exception as e:  # noqa: BLE001 - می‌خواهیم اجرای برنامه ادامه یابد
                if fatal:
                    print(
                        f"❌ نصبِ خودکارِ '{pip_name}' شکست خورد. این پکیج برایِ اجرایِ TRX AI "
                        f"حیاتی است؛ برنامه ممکن است در ادامه با خطا متوقف شود. "
                        f"نصبِ دستی: pip install {pip_name}"
                    )
                else:
                    print(
                        f"⚠️ نصبِ خودکارِ '{pip_name}' شکست خورد؛ فقط همان یک قابلیت غیرفعال "
                        f"می‌ماند، بقیه‌ی TRX AI عادی ادامه می‌دهد."
                    )
                logger.exception("نصب خودکار پکیج %s شکست خورد (fatal=%s).", pip_name, fatal)


def ensure_required_packages(auto_install: bool | None = None) -> None:
    """
    اطمینان از نصب‌بودنِ پکیج‌های سطحِ CORE و OPTIONAL.

    سطحِ EXPERIMENTAL عمداً اینجا نصب نمی‌شود — این‌ها سنگین‌اند
    (sentence-transformers چند صدمگابایت مدل دانلود می‌کند) و فقط وقتی
    کاربر خودش صریحاً بخواهدشان باید نصب شوند، نه خودکار در هر اجرا.

    Args:
        auto_install: اگر None باشد، از متغیر محیطی TRX_AUTO_INSTALL
            (پیش‌فرض: فعال، دقیقاً مثل رفتار قبلی) استفاده می‌شود.
    """
    if auto_install is None:
        auto_install = os.environ.get("TRX_AUTO_INSTALL", "1") != "0"

    _install_tier(CORE_MODULES, auto_install, fatal=True)
    _install_tier(OPTIONAL_MODULES, auto_install, fatal=False)


# ==========================================
#   پرچم‌های در دسترس‌بودن ماژول‌های اختیاری
#   (دقیقاً همان منطق نسخه‌ی اصلی، فقط متمرکزشده)
# ==========================================

try:
    import chromadb  # noqa: F401
    from chromadb.config import Settings as ChromaSettings  # noqa: F401

    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False
    logger.warning("ChromaDB در دسترس نیست. حافظه برداری غیرفعال است.")

try:
    from sentence_transformers import SentenceTransformer  # noqa: F401

    SENTENCE_TRANSFORMER_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMER_AVAILABLE = False
    logger.warning("SentenceTransformer در دسترس نیست. تعبیه‌سازی غیرفعال است.")

try:
    import pdfplumber  # noqa: F401

    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    from docx import Document  # noqa: F401

    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    from openpyxl import load_workbook  # noqa: F401

    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

try:
    from PIL import Image  # noqa: F401

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import pytesseract  # noqa: F401

    # نصبِ خودکار برایِ این یکی عمداً انجام نمی‌شود (مثلِ chromadb):
    # pytesseract فقط یک wrapperِ پایتونی است و بدونِ باینریِ سیستمیِ
    # Tesseract-OCR (که pip اصلاً نصبش نمی‌کند) کار نمی‌کند؛ نصبِ
    # خودکارِ فقط‌پایتونی یک حسِ کاذبِ «نصب شد» می‌داد. اگر این ایمپورت
    # موفق شود یعنی هم پکیجِ پایتونی هم باینریِ سیستمی (که pytesseract
    # موقعِ اولین استفاده‌ی واقعی چک می‌کند) به‌احتمالِ زیاد آماده‌اند.
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False

try:
    import psutil  # noqa: F401

    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    import cv2  # noqa: F401
    import numpy  # noqa: F401 -- opencv بدونِ numpy عملاً بی‌فایده است

    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False
    logger.warning(
        "OpenCV در دسترس نیست. ابزارِ بهبودِ کیفیتِ عکس با pipelineِ سبک‌ترِ "
        "Pillow (بدونِ denoiseِ قوی) کار می‌کند."
    )

# نکته: هیچ ماژول/SDKِ مخصوصِ APIِ مولدِ خارجی در این پروژه نیست — پس
# هیچ پرچمِ availability جداگانه‌ای برایِ آن لازم نیست.

# نکته: بررسیِ در‌دسترس‌بودنِ arabic_reshaper/python-bidi/hazm عمداً حذف
# شد (این کتابخانه‌ها دیگر جایی در پروژه import نمی‌شوند - ui.py هم
# کدشان را کامل کامنت کرده - چون نصب/ایمپورتشان در محیطِ اجرای واقعی
# خطا می‌داد). اگر در آینده دوباره فعال شدند، این بلاک هم باید برگردد:
#
# try:
#     import arabic_reshaper  # noqa: F401
#     from bidi.algorithm import get_display  # noqa: F401
#
#     PERSIAN_SHAPING_AVAILABLE = True
# except ImportError:
#     PERSIAN_SHAPING_AVAILABLE = False
#
# try:
#     from hazm import Normalizer as _HazmNormalizer  # noqa: F401
#
#     PERSIAN_NORMALIZE_AVAILABLE = True
# except ImportError:
#     PERSIAN_NORMALIZE_AVAILABLE = False
PERSIAN_SHAPING_AVAILABLE = False
PERSIAN_NORMALIZE_AVAILABLE = False

try:
    from persiantools import digits as _persian_digits  # noqa: F401
    from persiantools.jdatetime import JalaliDate as _JalaliDate  # noqa: F401

    PERSIAN_TOOLS_AVAILABLE = True
except ImportError:
    PERSIAN_TOOLS_AVAILABLE = False
    logger.warning("persiantools در دسترس نیست. از تبدیل تقویم/ارقامِ داخلی استفاده می‌شود.")
