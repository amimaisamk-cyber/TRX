# -*- coding: utf-8 -*-
"""
مدیریتِ خرج‌ها (Expense Tracker) — «خرج کردم ۵۰ هزار تومان برای نهار»
را می‌فهمد، ثبت می‌کند، و خلاصه‌ی هزینه‌ها را (کل/بر اساسِ دسته) نشان
می‌دهد.

محدودیتِ صادقانه: تشخیصِ مبلغ فقط اعداد به‌همراهِ واحدهایِ رایجِ فارسی
(تومان/هزار تومان/میلیون تومان) را می‌فهمد، نه هر فرمتِ ممکنِ نوشتاریِ
عدد. دسته‌بندی هم بر اساسِ چند کلیدواژه‌ی رایج (غذا/حمل‌ونقل/خرید/
قبض/سرگرمی/سلامت) حدس زده می‌شود؛ اگر هیچ‌کدام تطبیق نداد، دسته
«متفرقه» می‌شود.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta

from .text_normalize import normalize_text as _normalize_text

_AMOUNT_RE = re.compile(
    r'(\d+(?:[.,]\d+)?)\s*(میلیون|هزار)?\s*(تومان|ریال|دلار)?'
)

_CATEGORY_KEYWORDS = {
    "غذا": ["نهار", "شام", "صبحانه", "رستوران", "غذا", "کافه", "خوراک", "فست\u200cفود", "پیتزا"],
    "حمل‌ونقل": ["تاکسی", "اسنپ", "تپسی", "بنزین", "مترو", "اتوبوس", "بلیط"],
    "خرید": ["خرید", "لباس", "کفش", "فروشگاه", "مغازه"],
    "قبض": ["قبض", "آب", "برق", "گاز", "اینترنت", "شارژ", "اجاره"],
    "سرگرمی": ["سینما", "کنسرت", "بازی", "سرگرمی"],
    "سلامت": ["دارو", "دکتر", "پزشک", "بیمارستان", "درمانگاه"],
}


def parse_expense(text: str) -> dict:
    """
    از یک جمله‌ی آزاد، مبلغ/واحد/دسته/توضیح را استخراج می‌کند.
    خروجی: {"amount": float یا None, "category": str, "note": str}
    """
    t = _normalize_text(text)
    match = _AMOUNT_RE.search(t)
    amount = None
    if match:
        number = float(match.group(1).replace(",", "."))
        multiplier = match.group(2)
        if multiplier == "هزار":
            number *= 1_000
        elif multiplier == "میلیون":
            number *= 1_000_000
        amount = number

    category = "متفرقه"
    for cat, keywords in _CATEGORY_KEYWORDS.items():
        if any(kw in t for kw in keywords):
            category = cat
            break

    # حذفِ پیشوندهای رایج و بخشِ عددی از متن، برایِ ساختِ یک یادداشتِ کوتاه
    note = re.sub(r'^(خرج\s*کردم|هزینه\s*کردم|پول\s*دادم)\s*', '', text.strip())
    if match:
        note = note.replace(match.group(0), '', 1)
    note = re.sub(r'\s*(برای|بابت)\s*', ' ', note)
    note = re.sub(r'\s+', ' ', note).strip(" :،") or category

    return {"amount": amount, "category": category, "note": note}


class ExpenseManager:
    """رابطِ سطح‌بالا بینِ core.py و DatabaseManager برایِ خرج‌ها."""

    def __init__(self, db):
        self.db = db

    def add_from_text(self, text: str, project: str = None) -> dict:
        parsed = parse_expense(text)
        if parsed["amount"] is None:
            return parsed
        self.db.add_expense(parsed["amount"], parsed["category"], parsed["note"], project)
        return parsed

    @staticmethod
    def _format_amount(amount: float) -> str:
        return f"{amount:,.0f}".replace(",", "٬")

    def format_summary(self, project: str = None, days: int = 30) -> str:
        since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        rows = self.db.list_expenses(project=project, since=since)
        if not rows:
            return f"📭 در {days} روزِ اخیر هیچ خرجی ثبت نکرده‌ای."

        total = sum(r[1] for r in rows)
        by_category: dict = {}
        for _id, amount, category, _note, _created_at in rows:
            by_category[category] = by_category.get(category, 0) + amount

        lines = [f"💰 **خلاصه‌ی خرج‌های {days} روزِ اخیر**\n", f"جمعِ کل: {self._format_amount(total)} تومان\n"]
        lines.append("**بر اساسِ دسته:**")
        for cat, amount in sorted(by_category.items(), key=lambda x: -x[1]):
            percent = (amount / total * 100) if total else 0
            lines.append(f"  • {cat}: {self._format_amount(amount)} تومان ({percent:.0f}٪)")

        lines.append(f"\n**{min(len(rows), 5)} موردِ اخیر:**")
        for _id, amount, category, note, created_at in rows[:5]:
            lines.append(f"  • {created_at[:10]} | {self._format_amount(amount)} تومان | {category} | {note}")

        return "\n".join(lines)
