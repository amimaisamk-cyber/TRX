# -*- coding: utf-8 -*-
"""
پنجره‌ی اصلیِ رابطِ گرافیکیِ TRX AI (PySide6).

معماری:
    - رشته‌ی اصلی: حلقه‌ی رویدادِ Qt (پنجره، دکمه‌ها، تایپ‌کردن).
    - یک رشته‌ی پس‌زمینه: حلقه‌ی رویدادِ asyncio که TRXEnterpriseAI
      (همان موتورِ ترمینالی، بدونِ هیچ تغییری در منطقش) روی آن اجرا
      می‌شود. ارتباط بین دو رشته:
        GUI → asyncio:  AsyncBridge.call(coroutine) — از طریقِ
                         asyncio.run_coroutine_threadsafe
        asyncio → GUI:  یک صفِ رویداد (GuiUIEngine.events، thread-safe)
                         که یک QTimer هر ۸۰ میلی‌ثانیه می‌خواند و رندر
                         می‌کند.

این طراحی یعنی هیچ‌کدام از منطقِ core.py (تشخیصِ نیت، پزشکی، امنیت،
تایم‌اوت، چندزبانگی، تسک‌منیجر) دوباره‌نویسی نشده — رابطِ گرافیکی فقط
یک لایه‌ی نمایشیِ جدید روی همان موتور است.

نکته: این نسخه ظاهرِ رابط را کاملاً بازطراحی می‌کند (تم رنگی، حباب‌های
گفتگو، هدر، نوار ورودی و میانبرها) بدونِ دست‌زدن به هیچ منطقِ پردازشی.

محدودیتِ شناخته‌شده: مدِ REPL چندخطیِ «مفسر کد فارسی» فعلاً فقط در
نسخه‌ی ترمینالی کار می‌کند (به‌جای فریز کردن، پیامِ توضیحی می‌دهد).
"""

from __future__ import annotations

import asyncio
import sys
import threading
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPushButton,
    QScrollArea,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from .core import TRXEnterpriseAI
from .gui_ui_engine import GuiEvent, GuiUIEngine
from .logging_config import get_logger

logger = get_logger(__name__)


# ==================================================================
#   تمِ رنگی و صفحه‌سبکِ کلیِ برنامه (QSS)
# ==================================================================
COLOR_BG = "#F5F1EC"
COLOR_CARD = "#FFFFFF"
COLOR_PRIMARY = "#CC785C"
COLOR_PRIMARY_DARK = "#B5654A"
COLOR_PRIMARY_LIGHT = "#F0DACE"
COLOR_TEXT = "#2B2521"
COLOR_MUTED = "#8A8177"
COLOR_BORDER = "#E7DED4"
COLOR_DANGER = "#D9534F"
COLOR_SUCCESS = "#4E9A6A"

APP_STYLESHEET = f"""
* {{
    font-family: "Vazirmatn", "Noto Naskh Arabic", "Noto Sans Arabic", "Tahoma", "Arial";
}}
QMainWindow {{
    background: {COLOR_BG};
}}
#RootWidget {{
    background: {COLOR_BG};
}}

/* ---------- هدر ---------- */
#HeaderBar {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                 stop:0 {COLOR_PRIMARY_DARK}, stop:1 {COLOR_PRIMARY});
    border-radius: 16px;
}}
#HeaderTitle {{
    color: #FFFFFF;
    font-size: 19px;
    font-weight: 700;
}}
#HeaderSubtitle {{
    color: rgba(255,255,255,0.85);
    font-size: 12px;
}}
#StatusDot {{
    background: #7CE3A0;
    border-radius: 5px;
}}
#StatusLabel {{
    color: rgba(255,255,255,0.9);
    font-size: 11px;
}}

/* ---------- کارتِ گفتگو ---------- */
#ChatCard {{
    background: {COLOR_CARD};
    border-radius: 16px;
    border: 1px solid {COLOR_BORDER};
}}
QTextBrowser#ChatView {{
    background: transparent;
    border: none;
    padding: 6px;
    font-size: 14px;
    color: {COLOR_TEXT};
}}

/* ---------- نوارِ میانبرها ---------- */
#ShortcutBar {{
    background: transparent;
}}
QPushButton#ChipButton {{
    background: {COLOR_CARD};
    color: {COLOR_TEXT};
    border: 1px solid {COLOR_BORDER};
    border-radius: 14px;
    padding: 6px 14px;
    font-size: 12px;
}}
QPushButton#ChipButton:hover {{
    background: {COLOR_PRIMARY_LIGHT};
    border-color: {COLOR_PRIMARY};
}}
QPushButton#ChipButton:pressed {{
    background: {COLOR_PRIMARY};
    color: white;
}}

/* ---------- نوارِ ورودی ---------- */
#InputBar {{
    background: {COLOR_CARD};
    border: 1px solid {COLOR_BORDER};
    border-radius: 22px;
}}
QLineEdit#InputBox {{
    background: transparent;
    border: none;
    padding: 10px 6px;
    font-size: 14px;
    color: {COLOR_TEXT};
}}
QLineEdit#InputBox:focus {{
    outline: none;
}}
QPushButton#SendButton {{
    background: {COLOR_PRIMARY};
    color: white;
    border: none;
    border-radius: 18px;
    padding: 9px 22px;
    font-size: 13px;
    font-weight: 600;
}}
QPushButton#SendButton:hover {{
    background: {COLOR_PRIMARY_DARK};
}}
QPushButton#SendButton:disabled {{
    background: {COLOR_BORDER};
    color: {COLOR_MUTED};
}}
QCheckBox#VoiceCheck {{
    color: {COLOR_MUTED};
    font-size: 12px;
    spacing: 6px;
}}
QCheckBox#VoiceCheck::indicator {{
    width: 16px;
    height: 16px;
    border-radius: 8px;
    border: 1px solid {COLOR_BORDER};
    background: {COLOR_CARD};
}}
QCheckBox#VoiceCheck::indicator:checked {{
    background: {COLOR_PRIMARY};
    border-color: {COLOR_PRIMARY};
}}

/* ---------- نوارِ وضعیت ---------- */
QStatusBar {{
    background: transparent;
    color: {COLOR_MUTED};
    font-size: 11px;
    border: none;
}}

/* ---------- اسکرول‌بار ---------- */
QScrollBar:vertical {{
    background: transparent;
    width: 8px;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {COLOR_BORDER};
    border-radius: 4px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLOR_PRIMARY};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
"""


def _shadow(blur=24, y=4, alpha=40, color="#000000"):
    effect = QGraphicsDropShadowEffect()
    effect.setBlurRadius(blur)
    effect.setOffset(0, y)
    c = QColor(color)
    c.setAlpha(alpha)
    effect.setColor(c)
    return effect


class AsyncBridge:
    """اجرایِ یک حلقه‌ی asyncio در یک نخِ پس‌زمینه، به‌همراهِ یک متدِ
    thread-safe برایِ زمان‌بندیِ کوروتین‌ها از نخِ Qt."""

    def __init__(self):
        self.loop: asyncio.AbstractEventLoop | None = None
        self._ready = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self._ready.set()
        self.loop.run_forever()

    def start(self):
        self._thread.start()
        self._ready.wait()

    def call(self, coro):
        """کوروتین را روی حلقه‌ی پس‌زمینه اجرا می‌کند (غیربلاک‌کننده برایِ Qt)؛ concurrent.futures.Future برمی‌گرداند."""
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def stop(self):
        if self.loop:
            self.loop.call_soon_threadsafe(self.loop.stop)


def _escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _now() -> str:
    return datetime.now().strftime("%H:%M")


def _bubble(text: str, *, align: str, bg: str, fg: str, border: str = "", label: str = "") -> str:
    """
    یک حبابِ گفتگویِ راست‌چین/چپ‌چین با استفاده از جدول (سازگارترین
    روش با موتورِ RichText محدودِ Qt که پشتیبانیِ کاملی از
    display:inline-block ندارد).
    """
    side_pad_left = "18%" if align == "right" else "2%"
    side_pad_right = "2%" if align == "right" else "18%"
    border_css = f"border:1px solid {border};" if border else ""
    label_html = (
        f"<div style='font-size:11px; font-weight:700; margin-bottom:3px; color:{fg if bg != COLOR_CARD else COLOR_PRIMARY};'>{label}</div>"
        if label else ""
    )
    return (
        "<table width='100%' style='margin:4px 0;' cellspacing='0' cellpadding='0'><tr>"
        f"<td style='padding-left:{side_pad_left}; padding-right:{side_pad_right};'>"
        f"<div style='background:{bg}; color:{fg}; {border_css} border-radius:14px; "
        f"padding:10px 14px; text-align:right;'>{label_html}{text}"
        f"<div style='font-size:10px; color:{fg}; opacity:0.6; margin-top:4px;'>{_now()}</div>"
        "</div></td></tr></table>"
    )


class ChatWindow(QMainWindow):
    # سیگنال‌هایِ Qt (نه QTimer.singleShot از نخِ دیگر) برایِ برگشتن از
    # نخِ پس‌زمینه‌ی asyncio به نخِ اصلیِ GUI — به دلیلِ باگِ توضیح‌داده‌شده
    # در _send_text پایین‌تر.
    _turn_finished = Signal(object)
    _init_finished = Signal(object)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("TRX AI — دستیار هوشمند فارسی")
        self.resize(980, 720)
        self.setMinimumSize(720, 560)
        self.setLayoutDirection(Qt.RightToLeft)

        self.bridge = AsyncBridge()
        self.bridge.start()

        self.ui_engine = GuiUIEngine()
        self.app_core = TRXEnterpriseAI()

        # اگر پنجره درحالی بسته شود که یک پیام یا init_for_gui هنوز
        # روی نخِ پس‌زمینه در حالِ اجراست، callback‌شان (_on_done) بعداً
        # سعی می‌کند سیگنالی را emit کند که به ویجت‌هایی وصل است که
        # ممکن است تا آن لحظه توسطِ Qt واقعاً حذف (deleted) شده باشند —
        # نتیجه یک RuntimeError («wrapped C/C++ object ... has been
        # deleted») است که می‌تواند کرشِ برنامه هنگامِ بستن باشد. این
        # پرچم را closeEvent قبل از هر کاری True می‌کند؛ اسلات‌هایی که
        # به ویجت دست می‌زنند با دیدنِ آن بلافاصله برمی‌گردند.
        self._closing = False

        # وضعیتِ استریمِ زنده‌ی در‌حالِ‌اجرا (نگاه کنید به _render_event
        # برایِ "stream_start"/"stream_delta"/"stream_end"). فقط یک
        # استریم هم‌زمان ممکن است فعال باشد چون send_btn تا پایانِ نوبتِ
        # جاری غیرفعال است، پس تضمین می‌شود این حباب همیشه آخرین چیزِ
        # موجود در chat_view باشد.
        self._active_stream_id = None
        self._stream_anchor_pos = None
        self._stream_title = ""
        self._stream_style = ""

        self._build_ui()

        # QueuedConnection خودکار (چون این سیگنال‌ها از یک نخِ دیگر emit
        # می‌شوند) تنها راهِ تضمین‌شده برایِ اجرایِ اسلات‌ها روی نخِ GUI است.
        self._turn_finished.connect(self._on_turn_finished)
        self._init_finished.connect(self._on_init_finished)

        # ==========================================
        #   چرا اینجا دیگر بلاک نمی‌شویم (صفحه‌ی سفید)
        # ------------------------------------------
        # یک نسخه‌ی قبلی همین‌جا (پیش از اینکه run() پایین‌ترِ همین فایل
        # window.show() را صدا بزند) با
        # `self.bridge.call(...).result(timeout=30)` نخِ GUI را تا ۳۰
        # ثانیه بلاک می‌کرد. چون پنجره هنوز show() نشده بود، اندروید در
        # تمامِ این مدت فقط یک صفحه‌ی سفیدِ خالی نشان می‌داد (رفتارِ
        # استانداردِ اندروید وقتی نخِ UI پیش از اولین فریمِ رندرشده بلاک
        # باشد) — و اگر init_for_gui کند بود یا گیر می‌کرد، همان صفحه‌ی
        # سفید برای همیشه می‌ماند.
        #
        # راه‌حل: __init__ سریع برمی‌گردد (فقط ویجت‌ها ساخته می‌شوند)، تا
        # run() بتواند بلافاصله window.show() را صدا بزند و اولین فریمِ
        # واقعی رندر شود؛ گفتگویِ نام و init_for_gui با
        # QTimer.singleShot(0, ...) به بعد از این نقطه موکول می‌شوند —
        # این استفاده از QTimer.singleShot امن است چون از خودِ نخِ GUI
        # صدا زده می‌شود (بر خلافِ باگِ مشابه در _send_text که از نخِ
        # asyncio صدا زده می‌شد)، فقط اجرایش را تا شروعِ حلقه‌ی رویدادِ Qt
        # (app.exec()) به تعویق می‌اندازد.
        # ==========================================
        self.send_btn.setEnabled(False)
        self.input_box.setEnabled(False)
        for btn in self.shortcut_buttons:
            btn.setEnabled(False)
        self._append_html(
            f"<div style='color:{COLOR_MUTED}; text-align:center; margin:10px 0;'>⏳ در حال آماده‌سازی…</div>"
        )

        self.poll_timer = QTimer(self)
        self.poll_timer.timeout.connect(self._drain_events)
        self.poll_timer.start(80)

        QTimer.singleShot(0, self._ask_name_and_init)

    def _ask_name_and_init(self):
        """
        اجرا می‌شود بلافاصله بعد از اینکه پنجره show() و رندرِ اولش
        انجام شد (نه قبلش) — گفتگویِ نام و init_for_gui (که هر دو
        می‌توانند طول بکشند) دیگر جلویِ نمایشِ اولیه‌ی پنجره را نمی‌گیرند.
        """
        name_dialog = QInputDialog(self)
        name_dialog.setLayoutDirection(Qt.RightToLeft)
        name_dialog.setWindowTitle("خوش آمدید")
        name_dialog.setLabelText("نام شما (اختیاری — Enter برای رد کردن):")
        line_edit = name_dialog.findChild(QLineEdit)
        if line_edit is not None:
            line_edit.setLayoutDirection(Qt.RightToLeft)
            line_edit.setAlignment(Qt.AlignRight)
        ok = bool(name_dialog.exec())
        name = name_dialog.textValue()
        preset_name = name.strip() if ok and name.strip() else None

        future = self.bridge.call(
            self.app_core.init_for_gui(self.ui_engine, user_name=preset_name)
        )

        def _on_done(fut):
            # این callback رویِ نخِ پس‌زمینه‌ی asyncio اجرا می‌شود، پس
            # مثلِ _send_text باید از سیگنال (نه QTimer.singleShot)
            # برایِ برگشتن به نخِ GUI استفاده کند.
            self._init_finished.emit(fut.exception())

        future.add_done_callback(_on_done)

    def _on_init_finished(self, exc):
        if self._closing:
            return
        self.send_btn.setEnabled(True)
        self.input_box.setEnabled(True)
        self.input_box.setFocus()
        for btn in self.shortcut_buttons:
            btn.setEnabled(True)
        if exc:
            logger.exception("خطا در راه‌اندازیِ اولیه‌ی GUI: %s", exc)
            self._append_html(
                _bubble(
                    f"خطا در راه‌اندازیِ اولیه: {_escape(str(exc))}",
                    align="right", bg="#fdecea", fg=COLOR_DANGER, border=COLOR_DANGER,
                )
            )
        else:
            self._append_html(
                _bubble(
                    "سلام! من TRX AI هستم. هرچی نیاز داری بپرس — از حال‌واحوال گرفته تا کار/خرج/محاسبه.",
                    align="left", bg=COLOR_PRIMARY_LIGHT, fg=COLOR_TEXT, label="🤖 TRX AI",
                )
            )
        self._drain_events()

    # ------------------------------------------------------------
    #   ساختِ رابطِ گرافیکی
    # ------------------------------------------------------------
    def _build_ui(self):
        root = QWidget()
        root.setObjectName("RootWidget")
        outer = QVBoxLayout(root)
        outer.setContentsMargins(16, 16, 16, 12)
        outer.setSpacing(12)

        # ---------- هدر ----------
        header = QFrame()
        header.setObjectName("HeaderBar")
        header.setMinimumHeight(64)
        header.setGraphicsEffect(_shadow(blur=20, y=3, alpha=45, color=COLOR_PRIMARY_DARK))
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(18, 8, 18, 8)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title_lbl = QLabel("🧠 TRX AI")
        title_lbl.setObjectName("HeaderTitle")
        self.subtitle_lbl = QLabel("دستیار هوشمند فارسی")
        self.subtitle_lbl.setObjectName("HeaderSubtitle")
        title_box.addWidget(title_lbl)
        title_box.addWidget(self.subtitle_lbl)
        header_layout.addLayout(title_box)
        header_layout.addStretch(1)

        status_box = QHBoxLayout()
        status_box.setSpacing(6)
        self.status_dot = QLabel()
        self.status_dot.setObjectName("StatusDot")
        self.status_dot.setFixedSize(10, 10)
        self.status_label = QLabel("آماده")
        self.status_label.setObjectName("StatusLabel")
        status_box.addWidget(self.status_label)
        status_box.addWidget(self.status_dot)
        header_layout.addLayout(status_box)

        outer.addWidget(header)

        # ---------- کارتِ گفتگو ----------
        chat_card = QFrame()
        chat_card.setObjectName("ChatCard")
        chat_card.setGraphicsEffect(_shadow(blur=28, y=6, alpha=25))
        chat_card_layout = QVBoxLayout(chat_card)
        chat_card_layout.setContentsMargins(4, 4, 4, 4)

        self.chat_view = QTextBrowser()
        self.chat_view.setObjectName("ChatView")
        self.chat_view.setFrameShape(QFrame.NoFrame)
        self.chat_view.setLayoutDirection(Qt.RightToLeft)
        self.chat_view.setAlignment(Qt.AlignRight)
        self.chat_view.setOpenExternalLinks(False)
        font = QFont()
        # فهرستِ فونت‌هایی که پوششِ خوبی برایِ حروفِ فارسی دارند؛ Qt اولین
        # موردِ در‌دسترس روی دستگاه را انتخاب می‌کند. بدونِ این فهرست، روی
        # بعضی محیط‌ها (مثلاً Pydroid3/اندروید) فونتِ پیش‌فرض حروفِ فارسی
        # را به‌شکلِ ناپیوسته/معیوب رندر می‌کرد.
        font.setFamilies(["Vazirmatn", "Noto Naskh Arabic", "Noto Sans Arabic", "Tahoma", "Arial"])
        font.setPointSize(11)
        self.chat_view.setFont(font)
        chat_card_layout.addWidget(self.chat_view)
        outer.addWidget(chat_card, stretch=1)

        # ---------- نوارِ میانبرها ----------
        shortcuts_scroll = QScrollArea()
        shortcuts_scroll.setObjectName("ShortcutBar")
        shortcuts_scroll.setWidgetResizable(True)
        shortcuts_scroll.setFixedHeight(46)
        shortcuts_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        shortcuts_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        shortcuts_scroll.setFrameShape(QFrame.NoFrame)
        shortcuts_inner = QWidget()
        shortcuts_row = QHBoxLayout(shortcuts_inner)
        shortcuts_row.setContentsMargins(2, 2, 2, 2)
        shortcuts_row.setSpacing(8)
        self.shortcut_buttons = []
        for label, command in [
            ("📊 آمار", "آمار"),
            ("🖥️ داشبورد", "داشبورد"),
            ("📋 کارهام", "کارهام چیه"),
            ("📖 راهنما", "راهنما"),
            ("😄 جوک", "یه جوک بگو"),
        ]:
            btn = QPushButton(label)
            btn.setObjectName("ChipButton")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setToolTip(f"«{command}» را می‌فرستد")
            btn.clicked.connect(lambda checked=False, c=command: self._send_text(c))
            shortcuts_row.addWidget(btn)
            self.shortcut_buttons.append(btn)
        shortcuts_row.addStretch(1)
        shortcuts_scroll.setWidget(shortcuts_inner)
        outer.addWidget(shortcuts_scroll)

        # ---------- نوارِ ورودی ----------
        input_bar = QFrame()
        input_bar.setObjectName("InputBar")
        input_bar.setGraphicsEffect(_shadow(blur=18, y=3, alpha=18))
        input_row = QHBoxLayout(input_bar)
        input_row.setContentsMargins(6, 4, 14, 4)
        input_row.setSpacing(10)

        self.voice_checkbox = QCheckBox("🔊 صوتی")
        self.voice_checkbox.setObjectName("VoiceCheck")
        self.voice_checkbox.setCursor(Qt.PointingHandCursor)
        self.voice_checkbox.setToolTip("پاسخ‌ها را هم به‌صورتِ صوتی بشنو")
        self.voice_checkbox.stateChanged.connect(self._on_voice_toggle)
        input_row.addWidget(self.voice_checkbox)

        clear_btn = QPushButton("🗑️")
        clear_btn.setObjectName("ChipButton")
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.setToolTip("پاک‌کردنِ صفحه‌ی گفتگو (فقط نمایش؛ حافظه‌ی TRX AI دست‌نخورده می‌ماند)")
        clear_btn.setFixedWidth(40)
        clear_btn.clicked.connect(lambda: self.chat_view.clear())
        input_row.addWidget(clear_btn)

        self.send_btn = QPushButton("ارسال ⬅")
        self.send_btn.setObjectName("SendButton")
        self.send_btn.setCursor(Qt.PointingHandCursor)
        self.send_btn.setToolTip("فرستادنِ پیام (یا کلیدِ Enter)")
        self.send_btn.clicked.connect(self._on_send)
        input_row.addWidget(self.send_btn)

        self.input_box = QLineEdit()
        self.input_box.setObjectName("InputBox")
        self.input_box.setLayoutDirection(Qt.RightToLeft)
        self.input_box.setAlignment(Qt.AlignRight)
        self.input_box.setFont(font)
        self.input_box.setPlaceholderText("پیام خود را بنویسید... (مثلاً: سردرد دارم، یا: هوای تهران چطوره)")
        self.input_box.returnPressed.connect(self._on_send)
        input_row.addWidget(self.input_box, stretch=1)

        outer.addWidget(input_bar)

        self.setCentralWidget(root)
        self.statusBar().showMessage("آماده")

    # ------------------------------------------------------------
    #   رویدادهای رابطِ کاربری
    # ------------------------------------------------------------
    def _on_voice_toggle(self, state):
        # ۲ = صدایِ زن (پیش‌فرض)؛ خالی = خاموش. با _handle_voice_option
        # هماهنگ است (۱=مرد، ۲=زن).
        self.ui_engine.auto_voice_choice = "2" if state else ""

    def _on_send(self):
        text = self.input_box.text().strip()
        if not text:
            return
        self.input_box.clear()
        self._send_text(text)

    def _send_text(self, text: str):
        self._append_html(_bubble(_escape(text), align="right", bg=COLOR_PRIMARY, fg="#FFFFFF", label="شما"))
        self.send_btn.setEnabled(False)
        future = self.bridge.call(self.app_core._process_turn(text))

        def _on_done(fut):
            # نکته‌ی مهم: این callback رویِ نخِ پس‌زمینه‌ی asyncio اجرا
            # می‌شود (همان نخی که AsyncBridge._run حلقه‌ی رویدادش را
            # اجرا می‌کند)، نه نخِ GUI. نسخه‌ی قبلی اینجا مستقیماً
            # QTimer.singleShot(0, ...) صدا می‌زد تا به نخِ GUI برگردد —
            # ولی QTimer.singleShot برایِ کارکردن به یک حلقه‌ی رویدادِ Qt
            # رویِ همان نخی که صدایش می‌زند نیاز دارد؛ نخِ asyncio هیچ
            # حلقه‌ی رویدادِ Qt‌ای اجرا نمی‌کند، پس آن تایمر هیچ‌وقت شلیک
            # نمی‌شد و send_btn برای همیشه غیرفعال می‌ماند — دقیقاً همان
            # باگِ «بعد از پیامِ اول دیگر نمی‌شود چیزی فرستاد». راه‌حلِ
            # درست: سیگنالِ Qt، که وقتی نخِ emit با نخِ گیرنده فرق دارد،
            # به‌طورِ خودکار با QueuedConnection به نخِ گیرنده (اینجا:
            # نخِ اصلیِ GUI) تحویل داده می‌شود.
            self._turn_finished.emit(fut.exception())

        future.add_done_callback(_on_done)

    def _on_turn_finished(self, exc):
        """
        روی نخِ GUI اجرا می‌شود (به همینِ خاطر مستقیماً به send_btn/
        chat_view دست می‌زند). با اتصالِ خودکارِ QueuedConnection
        سیگنالِ _turn_finished فراخوانی می‌شود، نه به‌طورِ مستقیم از
        _on_done.
        """
        if self._closing:
            return
        self.send_btn.setEnabled(True)
        self.input_box.setFocus()
        if exc:
            logger.exception("خطا در پردازشِ پیام: %s", exc)
            self._append_html(
                _bubble(f"❌ خطا: {_escape(str(exc))}", align="left", bg="#fdecea", fg=COLOR_DANGER, border=COLOR_DANGER)
            )

    # ------------------------------------------------------------
    #   رندرِ رویدادهایِ رسیده از core.py (از طریقِ GuiUIEngine)
    # ------------------------------------------------------------
    def _drain_events(self):
        if self._closing:
            return
        while True:
            try:
                event = self.ui_engine.events.get_nowait()
            except Exception:
                break
            self._render_event(event)

    def _render_event(self, event: GuiEvent):
        kind = event.kind
        p = event.payload

        if kind == "message":
            title = _escape(p.get("title", "پاسخ"))
            text = _escape(p.get("text", "")).replace("\n", "<br>")
            self._append_html(
                _bubble(text, align="left", bg=COLOR_PRIMARY_LIGHT, fg=COLOR_TEXT, label=f"🤖 {title}")
            )
        elif kind == "emergency":
            text = _escape(p.get("text", "")).replace("\n", "<br>")
            self._append_html(
                _bubble(text, align="left", bg="#fdecea", fg=COLOR_DANGER, border=COLOR_DANGER, label="🚨 اورژانسی")
            )
        elif kind == "followup":
            text = _escape(p.get("text", ""))
            self._append_html(
                _bubble(text, align="left", bg="#fff8ec", fg=COLOR_TEXT, border="#EBC38B", label="🩺 سؤال پیگیری")
            )
        elif kind == "raw":
            text = _escape(p.get("text", "")).replace("\n", "<br>")
            if text.strip():
                self._append_html(
                    f"<div style='color:{COLOR_MUTED}; font-family:monospace; font-size:90%; "
                    f"margin:4px 2px; text-align:right;'>{text}</div>"
                )
        elif kind == "guide":
            rows = p.get("rows", [])
            html_rows = "".join(
                f"<tr><td style='padding:5px 10px; color:{COLOR_PRIMARY}; text-align:right; border-bottom:1px solid {COLOR_BORDER};'><b>{_escape(c)}</b></td>"
                f"<td style='padding:5px 10px; text-align:right; border-bottom:1px solid {COLOR_BORDER};'>{_escape(d)}</td></tr>"
                for c, d in rows
            )
            self._append_html(
                f"<div style='background:{COLOR_CARD}; border:1px solid {COLOR_BORDER}; border-radius:12px; padding:8px; margin:6px 0;'>"
                f"<table dir='rtl' width='100%' cellspacing='0'>{html_rows}</table></div>"
            )
        elif kind == "voice_saved":
            self._append_html(
                f"<div style='color:{COLOR_SUCCESS}; font-size:12px; text-align:right; margin:2px 4px;'>"
                f"✓ فایل صوتی: {_escape(p.get('path', ''))}</div>"
            )
        elif kind == "voice_failed":
            self._append_html(
                f"<div style='color:{COLOR_DANGER}; font-size:12px; text-align:right; margin:2px 4px;'>❌ خطا در تولید صدا.</div>"
            )
        elif kind == "scene":
            # Qt QTextBrowser از iframe/جاوااسکریپت پشتیبانی نمی‌کند، پس
            # اینجا فقط مسیرِ فایل نشان داده می‌شود (کاربر می‌تواند آن را
            # در مرورگر باز کند) -- امن و بدونِ ریسک، مثلِ voice_saved بالا.
            self._append_html(
                f"<div style='color:{COLOR_SUCCESS}; font-size:12px; text-align:right; margin:2px 4px;'>"
                f"🎬 صحنه‌ی ویدیو ساخته شد: {_escape(p.get('url', ''))} "
                f"(برایِ اجرا در مرورگر باز کنید)</div>"
            )
        elif kind == "status_start":
            self.statusBar().showMessage(p.get("label", "..."))
            self.status_label.setText(p.get("label", "..."))
            self._set_status_dot("#F0AD4E")
        elif kind == "status_end":
            self.statusBar().showMessage("آماده")
            self.status_label.setText("آماده")
            self._set_status_dot("#7CE3A0")
        elif kind == "stream_start":
            self._start_stream_bubble(p.get("stream_id"), p.get("title") or "پاسخ", p.get("style") or "")
        elif kind == "stream_delta":
            self._update_stream_bubble(p.get("stream_id"), p.get("text", ""))
        elif kind == "stream_end":
            self._end_stream_bubble(p.get("stream_id"))
        elif kind == "status":
            user = p.get("user", "")
            personality = p.get("personality", "")
            project = p.get("project", "")
            self.setWindowTitle(f"TRX AI — {user} | {personality} | پروژه: {project}")
            parts = [x for x in [user, personality, project and f"پروژه: {project}"] if x]
            self.subtitle_lbl.setText(" · ".join(parts) if parts else "دستیار هوشمند فارسی")
        # kind == "voice_prompt": نیازی به رندر نیست؛ چک‌باکسِ صدا همیشه در دسترس است.

    def _set_status_dot(self, hex_color: str):
        self.status_dot.setStyleSheet(f"background:{hex_color}; border-radius:5px;")

    # ------------------------------------------------------------
    #   حبابِ استریمِ زنده (پاسخِ در‌حالِ‌تولید، توکن‌به‌توکن -- در حالِ
    #   حاضر مصرف‌کننده‌ای ندارد چون این پروژه دیگر به هیچ APIِ مولدِ
    #   خارجی وصل نمی‌شود؛ فقط برایِ سازگاریِ آینده نگه داشته شده)
    # ------------------------------------------------------------
    def _start_stream_bubble(self, stream_id, title: str, style: str):
        """
        نقطه‌ای که chat_view درست پیش از شروعِ حبابِ استریم در آن قرار
        دارد را ذخیره می‌کند (``characterCount() - 1``: انتهایِ سندِ
        فعلی، پیش از هر درجی). بعداً هر ``_update_stream_bubble`` از
        همین‌جا تا انتهایِ سند را پاک و با نسخه‌ی جدیدِ حباب جایگزین
        می‌کند — یعنی به‌جایِ اضافه‌کردنِ یک حبابِ جدید برایِ هر توکن،
        همان یک حباب زنده «بزرگ می‌شود»، دقیقاً حسِ استریمِ ChatGPT/Claude.
        """
        self._active_stream_id = stream_id
        self._stream_title = title
        self._stream_style = style
        # -۱ چون characterCount شاملِ یک کاراکترِ پایانیِ ضمنیِ سند است.
        self._stream_anchor_pos = self.chat_view.document().characterCount() - 1
        self._update_stream_bubble(stream_id, "▍")

    def _update_stream_bubble(self, stream_id, text: str):
        if stream_id != self._active_stream_id or self._stream_anchor_pos is None:
            return  # رویدادِ یک استریمِ قبلاً بسته‌شده/بی‌ربط؛ نادیده بگیر
        bubble_html = _bubble(
            _escape(text).replace("\n", "<br>"),
            align="left", bg=COLOR_PRIMARY_LIGHT, fg=COLOR_TEXT, label=f"🤖 {self._stream_title}",
        )
        wrapped = f'<div dir="rtl" style="direction:rtl; text-align:right; unicode-bidi:embed;">{bubble_html}</div>'

        cursor = QTextCursor(self.chat_view.document())
        cursor.setPosition(self._stream_anchor_pos)
        cursor.movePosition(QTextCursor.End, QTextCursor.KeepAnchor)
        cursor.removeSelectedText()
        cursor.insertHtml(wrapped)

        self.chat_view.moveCursor(QTextCursor.End)
        sb = self.chat_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _end_stream_bubble(self, stream_id):
        if stream_id != self._active_stream_id:
            return
        self._active_stream_id = None
        self._stream_anchor_pos = None

    def _append_html(self, html: str):
        # dir="rtl" صریح لازم است: setLayoutDirection روی خودِ ویجت کافی
        # نبود و باعثِ نمایشِ به‌هم‌ریخته/معکوسِ متنِ فارسی (به‌خصوص وقتی
        # با عدد یا کلمه‌ی انگلیسی مخلوط شده بود) روی Pydroid3/اندروید
        # می‌شد. موتورِ Bidi‌ِ Qt برایِ HTML تزریق‌شده، به dir صریح روی
        # خودِ HTML نیاز دارد، نه فقط تنظیمِ سطحِ ویجت.
        wrapped = f'<div dir="rtl" style="direction:rtl; text-align:right; unicode-bidi:embed;">{html}</div>'
        self.chat_view.moveCursor(QTextCursor.End)
        self.chat_view.insertHtml(wrapped)
        self.chat_view.moveCursor(QTextCursor.End)
        sb = self.chat_view.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ------------------------------------------------------------
    #   خروج
    # ------------------------------------------------------------
    def closeEvent(self, event):
        self._closing = True
        try:
            self.bridge.call(self.app_core.shutdown_gui()).result(timeout=5)
        except Exception as e:  # noqa: BLE001
            logger.debug("خطا هنگامِ بستنِ منظمِ session: %s", e)
        self.bridge.stop()
        event.accept()


def run():
    app = QApplication(sys.argv)
    app.setLayoutDirection(Qt.RightToLeft)
    app.setStyleSheet(APP_STYLESHEET)
    window = ChatWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    run()
