# -*- coding: utf-8 -*-
"""
تنظیمات مرکزی برنامه: مسیرهای داده، صداها و شخصیت‌های هوش مصنوعی.

نسبت به نسخه‌ی اصلی، مسیرهای پوشه اکنون از طریق متغیرهای محیطی هم
قابل بازنویسی هستند (مثلاً برای اجرای تست‌ها یا استقرار در کانتینر)،
اما مقدار پیش‌فرض دقیقاً همان مقادیر قبلی است تا رفتار برنامه تغییر نکند.
"""

from __future__ import annotations

import os

OS_AUDIO_DIR = os.environ.get("TRX_AUDIO_DIR", "ai_voices")
os.makedirs(OS_AUDIO_DIR, exist_ok=True)

OS_PLUGINS_DIR = os.environ.get("TRX_PLUGINS_DIR", "plugins")
os.makedirs(OS_PLUGINS_DIR, exist_ok=True)

OS_FILES_DIR = os.environ.get("TRX_FILES_DIR", "files")
os.makedirs(OS_FILES_DIR, exist_ok=True)

OS_TEMP_DIR = os.environ.get("TRX_TEMP_DIR", "temp")
os.makedirs(OS_TEMP_DIR, exist_ok=True)

VOICES = {
    "1": "fa-IR-FaridNeural",
    "2": "fa-IR-DilaraNeural"
}

# ==========================================
#   شخصیت‌های پیشرفته
# ==========================================

PERSONALITIES = {
    "رسمی": {
        "emoji": "🤖",
        "prefix": "با احترام، ",
        "style": "cyan",
        "desc": "پاسخ‌های دقیق و حرفه‌ای",
        "tone": "formal",
        "response_style": "detailed"
    },
    "دوستانه": {
        "emoji": "😄",
        "prefix": "سلام! ",
        "style": "green",
        "desc": "پاسخ‌های گرم و صمیمی",
        "tone": "casual",
        "response_style": "concise"
    },
    "فنی": {
        "emoji": "💻",
        "prefix": "آنالیز: ",
        "style": "magenta",
        "desc": "پاسخ‌های تخصصی و فنی",
        "tone": "technical",
        "response_style": "detailed"
    },
    "معلم": {
        "emoji": "📚",
        "prefix": "توضیح: ",
        "style": "yellow",
        "desc": "پاسخ‌های آموزشی با مثال",
        "tone": "educational",
        "response_style": "explanatory"
    },
    "خلاق": {
        "emoji": "🎨",
        "prefix": "ایده: ",
        "style": "magenta",
        "desc": "پاسخ‌های خلاقانه و الهام‌بخش",
        "tone": "creative",
        "response_style": "imaginative"
    },
    "تحقیق‌کننده": {
        "emoji": "🔬",
        "prefix": "تحلیل: ",
        "style": "blue",
        "desc": "پاسخ‌های علمی و پژوهشی",
        "tone": "analytical",
        "response_style": "thorough"
    },
    "طنز": {
        "emoji": "😂",
        "prefix": "خوب: ",
        "style": "yellow",
        "desc": "پاسخ‌های طنزآمیز و خنده‌دار",
        "tone": "humorous",
        "response_style": "witty"
    },
    "فیلسوف": {
        "emoji": "🧠",
        "prefix": "تأمل: ",
        "style": "white",
        "desc": "پاسخ‌های عمیق و فلسفی",
        "tone": "philosophical",
        "response_style": "reflective"
    },
    "برنامه‌نویس": {
        "emoji": "👨‍💻",
        "prefix": "کد: ",
        "style": "green",
        "desc": "پاسخ‌های تخصصی برنامه‌نویسی",
        "tone": "technical",
        "response_style": "code_focused"
    },
    "دکتر": {
        "emoji": "👨‍⚕️",
        "prefix": "معاینه: ",
        "style": "red",
        "desc": "پاسخ‌های پزشکی و سلامت",
        "tone": "medical",
        "response_style": "cautious"
    },
    # ==========================================
    #   شخصیت جدید: دکتر کامل (Medical AI)
    # ==========================================
    "دکتر کامل": {
        "emoji": "🏥",
        "prefix": "🩺 تشخیص: ",
        "style": "bright_red",
        "desc": "پاسخ‌های تخصصی پزشکی با رویکرد تشخیصی جامع و دقیق",
        "tone": "medical_professional",
        "response_style": "diagnostic",
        "keywords": ["علائم", "بیماری", "درمان", "دارو", "درد", "تب", "سرفه", "تنفس", "قلب", 
                     "معده", "سر درد", "مفصل", "پوست", "آلرژی", "گلودرد", "فشارخون", "قند خون",
                     "دیابت", "آسم", "میگرن", "آنفولانزا", "کرونا", "واکسن", "تغذیه", "رژیم",
                     "چاقی", "لاغری", "ورزش", "سلامت", "بیمار", "دکتر", "پزشک", "بیمارستان"]
    }
}
