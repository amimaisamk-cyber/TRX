// intent_native.cpp
// -----------------------------------------------------------------------
// هسته‌ی سنگین‌بارِ تشخیصِ نیت (IntentEngine.detect_intent در intelligence.py)
// به ++C بازنویسی شده تا سریع‌تر اجرا شود. بقیه‌ی برنامه (پایتون) بدون
// تغییر می‌ماند؛ این فایل فقط سه تابعِ محاسباتیِ داغ را جایگزین می‌کند:
//
//   normalize(text)                -> یکسان‌سازیِ نویسه‌ها (معادلِ IntentEngine._normalize)
//   keyword_hit_score(text, kw)    -> امتیازِ یک کلیدواژه (معادلِ IntentEngine._keyword_hit_score)
//   score_keywords(text, intents)  -> امتیازدهیِ دسته‌ایِ همه‌ی نیت‌ها در یک فراخوانی
//                                      (به‌جایِ صدها فراخوانیِ جداگانه‌ی پایتون→پایتون)
//
// پیاده‌سازی مستقیماً با CPython C API نوشته شده (نه pybind11)، چون در
// محیطِ بدونِ اینترنت نصبِ pybind11 ممکن نیست؛ Python.h همیشه همراهِ
// خودِ پایتون است، پس این روش هیچ وابستگیِ بیرونیِ اضافه‌ای نمی‌خواهد.
//
// نکته‌ی مهمِ یونیکد: چون UTF-8 «self-synchronizing» است (بایت‌های
// میانیِ یک نویسه‌ی چندبایتی هرگز شکلِ یک بایتِ آغازینِ معتبر یا یک
// نویسه‌ی ASCII را ندارند)، جستجوی زیررشته در سطحِ بایت برایِ تطبیقِ
// متن‌های UTF-8 کاملاً درست و ایمن است؛ نیازی به دیکد کردنِ کامل به
// codepoint برایِ جستجو نیست. فقط برایِ normalize (جایگزینیِ نویسه‌های
// خاص) و برایِ تشخیصِ «آخرین نویسه‌ی کلیدواژه در بازه‌ی عربی/فارسی است
// یا نه»، دیکدِ UTF-8 لازم است.
// -----------------------------------------------------------------------
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <string>
#include <vector>
#include <cstdint>
#include <cctype>

namespace {

// ---------------------------------------------------------------------
//   ابزارهایِ کمکیِ UTF-8
// ---------------------------------------------------------------------

// دیکدِ یک codepoint از یک رشته‌ی UTF-8 در موقعیتِ i؛ طولِ نویسه (بر
// حسبِ بایت) را در out_len می‌گذارد. در صورتِ بایتِ نامعتبر، همان یک
// بایت را به‌عنوانِ codepoint برمی‌گرداند (بدونِ کرش).
uint32_t utf8_decode(const std::string& s, size_t i, size_t& out_len) {
    unsigned char c = static_cast<unsigned char>(s[i]);
    if (c < 0x80) { out_len = 1; return c; }
    if ((c & 0xE0) == 0xC0 && i + 1 < s.size()) {
        out_len = 2;
        return ((c & 0x1Fu) << 6) | (static_cast<unsigned char>(s[i+1]) & 0x3Fu);
    }
    if ((c & 0xF0) == 0xE0 && i + 2 < s.size()) {
        out_len = 3;
        return ((c & 0x0Fu) << 12) |
               ((static_cast<unsigned char>(s[i+1]) & 0x3Fu) << 6) |
               (static_cast<unsigned char>(s[i+2]) & 0x3Fu);
    }
    if ((c & 0xF8) == 0xF0 && i + 3 < s.size()) {
        out_len = 4;
        return ((c & 0x07u) << 18) |
               ((static_cast<unsigned char>(s[i+1]) & 0x3Fu) << 12) |
               ((static_cast<unsigned char>(s[i+2]) & 0x3Fu) << 6) |
               (static_cast<unsigned char>(s[i+3]) & 0x3Fu);
    }
    out_len = 1;
    return c;
}

bool is_ascii_ws(unsigned char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
}

// معادلِ Python str.strip() برایِ فاصله‌هایِ رایج (ASCII)
std::string strip_ws(const std::string& s) {
    size_t start = 0, end = s.size();
    while (start < end && is_ascii_ws(static_cast<unsigned char>(s[start]))) start++;
    while (end > start && is_ascii_ws(static_cast<unsigned char>(s[end - 1]))) end--;
    return s.substr(start, end - start);
}

// ---------------------------------------------------------------------
//   normalize(): معادلِ IntentEngine._normalize
//   - lower() فقط رویِ ASCII (فارسی حرفِ بزرگ/کوچک ندارد)
//   - «ي» عربی (U+064A) -> «ی» فارسی (U+06CC)
//   - «ك» عربی (U+0643) -> «ک» فارسی (U+06A9)
//   - نیم‌فاصله ZWNJ (U+200C) -> فاصله‌ی معمولی
//   - چند فاصله‌ی پیاپی -> یک فاصله
// ---------------------------------------------------------------------
std::string normalize_impl(const std::string& raw) {
    std::string s = strip_ws(raw);
    std::string out;
    out.reserve(s.size());

    size_t i = 0;
    bool last_was_space = false;
    while (i < s.size()) {
        size_t len = 0;
        uint32_t cp = utf8_decode(s, i, len);

        if (cp >= 'A' && cp <= 'Z') {
            out.push_back(static_cast<char>(cp - 'A' + 'a'));
            last_was_space = false;
        } else if (cp == 0x064A) {                 // ي -> ی
            out += "\xDB\x8C";
            last_was_space = false;
        } else if (cp == 0x0643) {                 // ك -> ک
            out += "\xDA\xA9";
            last_was_space = false;
        } else if (cp == 0x200C || is_ascii_ws(static_cast<unsigned char>(cp <= 0xFF ? cp : 0))) {
            // ZWNJ یا فاصله‌ی ASCII: در خروجی حداکثر یک فاصله باقی می‌ماند
            if (!last_was_space) {
                out.push_back(' ');
                last_was_space = true;
            }
        } else {
            out.append(s, i, len);
            last_was_space = false;
        }
        i += len;
    }
    // strip نهایی (اگر فاصله‌ی جمع‌شده در ابتدا/انتها مانده باشد)
    return strip_ws(out);
}

// آیا codepoint آخرِ کلیدواژه یک «نویسه‌ی کلمه‌ای» است؟ (ASCII الفبا/رقم/
// زیرخط، یا محدوده‌ی عربی-فارسی U+0600..U+06FF) — معادلِ
// `re.match(r'.*[\w\u0600-\u06FF]$', kw)` در پایتون.
bool ends_with_word_char(const std::string& kw) {
    if (kw.empty()) return false;
    // برایِ یافتنِ آخرین codepoint، از انتها بایت‌هایِ continuation
    // (10xxxxxx) را رد می‌کنیم تا به بایتِ آغازینِ آخرین نویسه برسیم.
    size_t end = kw.size();
    size_t start = end - 1;
    while (start > 0 && (static_cast<unsigned char>(kw[start]) & 0xC0) == 0x80) {
        start--;
    }
    size_t len = 0;
    uint32_t cp = utf8_decode(kw, start, len);
    if ((cp >= '0' && cp <= '9') || (cp >= 'a' && cp <= 'z') || (cp >= 'A' && cp <= 'Z') || cp == '_') return true;
    if (cp >= 0x0600 && cp <= 0x06FF) return true;
    return false;
}

const char* NEGATIONS[] = {"ندارم", "نیست", "نبود", "نداشتم", "نه "};
constexpr int NUM_NEGATIONS = 5;

// پایتون `text[m.start()-12 : m.start()]` را بر حسبِ ایندکسِ *کاراکتری*
// (کدپوینت) محاسبه می‌کند، نه بایت. چون نویسه‌های فارسی/عربی در UTF-8
// دوبایتی‌اند، عقب‌رفتنِ صرفاً ۱۲ بایت پنجره‌ای نصفه (حدودِ ۶ کاراکتر)
// می‌سازد و نتیجه را نسبت به نسخه‌ی پایتونی جابه‌جا می‌کند. این تابع به
// اندازه‌ی n *کدپوینتِ* کامل (نه بایت) به عقب می‌رود.
size_t step_back_codepoints(const std::string& s, size_t pos, int n) {
    size_t i = pos;
    for (int k = 0; k < n && i > 0; ++k) {
        i--;
        while (i > 0 && (static_cast<unsigned char>(s[i]) & 0xC0) == 0x80) {
            i--;
        }
    }
    return i;
}

bool window_has_negation(const std::string& text, size_t win_start, size_t win_end) {
    if (win_end <= win_start) return false;
    std::string window = text.substr(win_start, win_end - win_start);
    for (int i = 0; i < NUM_NEGATIONS; ++i) {
        if (window.find(NEGATIONS[i]) != std::string::npos) return true;
    }
    return false;
}

// ---------------------------------------------------------------------
//   keyword_hit_score(): معادلِ IntentEngine._keyword_hit_score
//   ورودی: متنِ از قبل normalize شده + یک کلیدواژه‌ی خام (نرمال‌سازیِ
//   کلیدواژه هم همینجا انجام می‌شود، مثلِ نسخه‌ی پایتونی).
// ---------------------------------------------------------------------
double keyword_hit_score_impl(const std::string& norm_text, const std::string& raw_keyword) {
    // kw = keyword.replace(ZWNJ, ' ').strip().lower()  (ZWNJ = E2 80 8C)
    std::string kw;
    kw.reserve(raw_keyword.size());
    {
        size_t i = 0;
        while (i < raw_keyword.size()) {
            if (i + 2 < raw_keyword.size() + 1 &&
                static_cast<unsigned char>(raw_keyword[i]) == 0xE2 &&
                i + 2 < raw_keyword.size() &&
                static_cast<unsigned char>(raw_keyword[i+1]) == 0x80 &&
                static_cast<unsigned char>(raw_keyword[i+2]) == 0x8C) {
                kw.push_back(' ');
                i += 3;
                continue;
            }
            size_t len = 0;
            uint32_t cp = utf8_decode(raw_keyword, i, len);
            if (cp >= 'A' && cp <= 'Z') {
                kw.push_back(static_cast<char>(cp - 'A' + 'a'));
            } else {
                kw.append(raw_keyword, i, len);
            }
            i += len;
        }
    }
    kw = strip_ws(kw);
    if (kw.empty()) return 0.0;

    bool trail_required = ends_with_word_char(kw);
    double score = 0.0;
    size_t pos = 0;
    const size_t klen = kw.size();
    const size_t tlen = norm_text.size();

    while (true) {
        size_t found = norm_text.find(kw, pos);
        if (found == std::string::npos) break;

        bool lead_ok = (found == 0) || (norm_text[found - 1] == ' ');
        size_t end = found + klen;
        bool trail_ok = !trail_required || (end == tlen) || (norm_text[end] == ' ');

        if (lead_ok && trail_ok) {
            size_t win_start = step_back_codepoints(norm_text, found, 12);
            bool negated = window_has_negation(norm_text, win_start, found);
            score += negated ? 0.4 : 1.0;
            pos = end;               // پیشروی غیرِهم‌پوشان، مثلِ finditer برایِ یک الگویِ ثابت‌طول
        } else {
            pos = found + 1;         // مطابقتِ substring بود ولی مرز رعایت نشد؛ یک قدم جلوتر دوباره امتحان کن
        }
    }
    return score;
}

// =======================================================================
//   پوششِ CPython C API
// =======================================================================

PyObject* py_normalize(PyObject*, PyObject* args) {
    const char* text_utf8;
    Py_ssize_t text_len;
    if (!PyArg_ParseTuple(args, "s#", &text_utf8, &text_len)) return nullptr;
    std::string result = normalize_impl(std::string(text_utf8, text_len));
    return PyUnicode_FromStringAndSize(result.data(), result.size());
}

PyObject* py_keyword_hit_score(PyObject*, PyObject* args) {
    const char* text_utf8; Py_ssize_t text_len;
    const char* kw_utf8; Py_ssize_t kw_len;
    if (!PyArg_ParseTuple(args, "s#s#", &text_utf8, &text_len, &kw_utf8, &kw_len)) return nullptr;
    double score = keyword_hit_score_impl(std::string(text_utf8, text_len), std::string(kw_utf8, kw_len));
    return PyFloat_FromDouble(score);
}

// score_keywords(norm_text, intents) -> {intent_name: score}
// intents: لیستی از تاپل‌های (name:str, keywords:list[str], weight:float)
// این تابع کل حلقه‌ی دوگانه‌ی «برای هر نیت، برای هر کلیدواژه» را در
// خودِ ++C انجام می‌دهد تا هزینه‌ی رفت‌وبرگشتِ پایتون↔پایتون برایِ هر
// کلیدواژه (که تا ۱۵۶ بار در هر پیام تکرار می‌شد) حذف شود.
PyObject* py_score_keywords(PyObject*, PyObject* args) {
    const char* text_utf8; Py_ssize_t text_len;
    PyObject* intents_list;
    if (!PyArg_ParseTuple(args, "s#O", &text_utf8, &text_len, &intents_list)) return nullptr;
    if (!PyList_Check(intents_list) && !PyTuple_Check(intents_list)) {
        PyErr_SetString(PyExc_TypeError, "intents must be a list/tuple of (name, keywords, weight)");
        return nullptr;
    }

    std::string norm_text(text_utf8, text_len);
    PyObject* result = PyDict_New();
    if (!result) return nullptr;

    Py_ssize_t n_intents = PySequence_Size(intents_list);
    for (Py_ssize_t i = 0; i < n_intents; ++i) {
        PyObject* item = PySequence_GetItem(intents_list, i);   // new ref
        if (!item) { Py_DECREF(result); return nullptr; }

        PyObject* name_obj = PySequence_GetItem(item, 0);       // new ref
        PyObject* kw_list = PySequence_GetItem(item, 1);        // new ref
        PyObject* weight_obj = PySequence_GetItem(item, 2);     // new ref
        double weight = PyFloat_AsDouble(weight_obj);

        double total = 0.0;
        Py_ssize_t n_kw = PySequence_Size(kw_list);
        for (Py_ssize_t j = 0; j < n_kw; ++j) {
            PyObject* kw_obj = PySequence_GetItem(kw_list, j);   // new ref
            Py_ssize_t kw_len = 0;
            const char* kw_utf8 = PyUnicode_AsUTF8AndSize(kw_obj, &kw_len);
            if (kw_utf8) {
                total += keyword_hit_score_impl(norm_text, std::string(kw_utf8, kw_len)) * weight;
            }
            Py_DECREF(kw_obj);
        }

        if (total > 0.0) {
            PyObject* score_obj = PyFloat_FromDouble(total);
            PyDict_SetItem(result, name_obj, score_obj);
            Py_DECREF(score_obj);
        }

        Py_DECREF(name_obj);
        Py_DECREF(kw_list);
        Py_DECREF(weight_obj);
        Py_DECREF(item);
    }

    return result;
}

PyMethodDef ModuleMethods[] = {
    {"normalize", py_normalize, METH_VARARGS, "Normalize Persian/Arabic text (fast native version)."},
    {"keyword_hit_score", py_keyword_hit_score, METH_VARARGS, "Score a single keyword hit in normalized text."},
    {"score_keywords", py_score_keywords, METH_VARARGS,
     "Batch-score all intents' keywords against normalized text in one native call."},
    {nullptr, nullptr, 0, nullptr}
};

PyModuleDef ModuleDef = {
    PyModuleDef_HEAD_INIT,
    "_intent_native",
    "Native (C++) hot-path implementation of TRX AI's intent scoring core.",
    -1,
    ModuleMethods
};

} // namespace

PyMODINIT_FUNC PyInit__intent_native(void) {
    return PyModule_Create(&ModuleDef);
}
