# -*- coding: utf-8 -*-
"""
ساختِ ماژولِ نیتیوِ ++C (هسته‌ی تشخیصِ نیت).

اجرا:
    cd trx_ai/native
    python3 setup.py build_ext --inplace

خروجی (یک فایلِ .so در لینوکس/مک یا .pyd در ویندوز) باید کنارِ همین
اسکریپت بماند و از آنجا به `trx_ai/` کپی/لینک شود تا
`from trx_ai import _intent_native` پیدایش کند. اسکریپتِ build_and_install.sh
همین کار را خودکار انجام می‌دهد.

این مرحله کاملاً اختیاری است: اگر کامپایل نشود یا فایل .so پیدا نشود،
`intelligence.py` به‌طور خودکار به نسخه‌ی خالصِ پایتونی برمی‌گردد و
برنامه بدونِ هیچ خطایی کار می‌کند — فقط تشخیصِ نیت کمی کندتر می‌شود.
"""
from setuptools import setup, Extension

module = Extension(
    "_intent_native",
    sources=["intent_native.cpp"],
    extra_compile_args=["-O3", "-std=c++17"],
    language="c++",
)

setup(
    name="trx_ai_intent_native",
    version="1.0.0",
    description="Native C++ hot-path for TRX AI's intent scoring core",
    ext_modules=[module],
)
