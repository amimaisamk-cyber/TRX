#!/usr/bin/env bash
# ساخت و نصبِ خودکارِ ماژولِ نیتیوِ ++C در کنارِ trx_ai/
# استفاده: bash trx_ai/native/build_and_install.sh
set -e
cd "$(dirname "$0")"

echo "در حال ساختِ ماژولِ _intent_native ..."
python3 setup.py build_ext --inplace

SO_FILE=$(find . -maxdepth 1 -name "_intent_native*.so" -o -name "_intent_native*.pyd" | head -n 1)
if [ -z "$SO_FILE" ]; then
    echo "❌ ساخت ناموفق بود؛ فایلِ .so/.pyd پیدا نشد."
    exit 1
fi

cp "$SO_FILE" ../
echo "✅ ماژولِ نیتیو با موفقیت ساخته و به trx_ai/ کپی شد: $(basename "$SO_FILE")"
echo "   حالا 'import trx_ai' خودکار از نسخه‌ی ++C استفاده می‌کند."
