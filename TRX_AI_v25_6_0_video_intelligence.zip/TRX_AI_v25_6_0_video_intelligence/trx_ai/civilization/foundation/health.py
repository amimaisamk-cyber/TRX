# -*- coding: utf-8 -*-
"""
Registry سبک برای health check هر Domain.

قانونِ طلایی #10 سندِ تخت‌جمشید: «خرابی یک بخش نباید کل TRX را
بخواباند». بنابراین این registry به‌طور ذاتی fail-soft است: اگر
خودِ یک تابعِ health check exception بیندازد، این ماژول آن را
می‌بلعد و یک HealthReport با وضعیتِ UNKNOWN برمی‌گرداند -- هرگز
exception را به بیرون پرتاب نمی‌کند.

این ماژول هیچ health check ای را خودش پیاده نمی‌کند و هیچ importی
از core.py/intelligence.py ندارد؛ فقط ظرف است. ثبتِ health checkهای
واقعی برای هر Domain (medical، conversation، phase3، ...) کارِ
مرحله‌ی بعدی (وقتی واقعاً به مسیر زنده وصل می‌شویم) است.
"""

from __future__ import annotations

import time
import traceback
from typing import Callable, Dict, Optional

from .contracts import HealthReport, HealthStatus

# امضای هر health check: بدونِ آرگومان، یا HealthReport برمی‌گرداند
# یا exception می‌اندازد (که این ماژول آن را مدیریت می‌کند).
HealthCheckFn = Callable[[], HealthReport]


class HealthRegistry:
    """نگه‌دارنده‌ی توابعِ health check، به ازایِ نامِ Domain."""

    def __init__(self) -> None:
        self._checks: Dict[str, HealthCheckFn] = {}

    def register(self, domain: str, check_fn: HealthCheckFn) -> None:
        """ثبت یا جایگزینیِ health check یک Domain."""
        self._checks[domain] = check_fn

    def unregister(self, domain: str) -> None:
        self._checks.pop(domain, None)

    def known_domains(self) -> list:
        return sorted(self._checks.keys())

    def run_one(self, domain: str) -> Optional[HealthReport]:
        """
        اجرایِ health check یک Domain. اگر Domain ثبت نشده باشد
        None برمی‌گرداند (نه exception -- تصمیمِ «Domain وجود ندارد»
        با فراخوان است، نه با این تابع).
        """
        check_fn = self._checks.get(domain)
        if check_fn is None:
            return None
        return self._run_safely(domain, check_fn)

    def run_all(self) -> Dict[str, HealthReport]:
        """
        اجرایِ همه‌ی health checkهای ثبت‌شده. هر Domain مستقل اجرا
        می‌شود؛ شکستِ یکی بقیه را متوقف نمی‌کند.
        """
        results: Dict[str, HealthReport] = {}
        for domain, check_fn in self._checks.items():
            results[domain] = self._run_safely(domain, check_fn)
        return results

    @staticmethod
    def _run_safely(domain: str, check_fn: HealthCheckFn) -> HealthReport:
        try:
            report = check_fn()
        except Exception:  # noqa: BLE001 -- عمداً گسترده: fail-soft
            return HealthReport(
                domain=domain,
                status=HealthStatus.UNKNOWN,
                detail="health check raised: " + traceback.format_exc(limit=1).strip().splitlines()[-1],
                checked_at=time.time(),
            )
        if not isinstance(report, HealthReport):
            return HealthReport(
                domain=domain,
                status=HealthStatus.UNKNOWN,
                detail="health check did not return a HealthReport",
                checked_at=time.time(),
            )
        return report


def aggregate_status(reports: Dict[str, HealthReport]) -> HealthStatus:
    """
    خلاصه‌ی یک‌خطیِ وضعیتِ کلی از رویِ چند HealthReport:
    بدترین وضعیتِ موجود برنده است (UNHEALTHY > DEGRADED > UNKNOWN > HEALTHY).
    """
    if not reports:
        return HealthStatus.UNKNOWN
    priority = {
        HealthStatus.UNHEALTHY: 3,
        HealthStatus.DEGRADED: 2,
        HealthStatus.UNKNOWN: 1,
        HealthStatus.HEALTHY: 0,
    }
    worst = HealthStatus.HEALTHY
    for report in reports.values():
        if priority[report.status] > priority[worst]:
            worst = report.status
    return worst
