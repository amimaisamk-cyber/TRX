# -*- coding: utf-8 -*-
"""
قراردادهای پایه‌ی Persepolis Foundation.

این فایل فقط dataclass/Enum است -- هیچ رفتاری اجرا نمی‌کند و هیچ
importی از trx_ai.core / trx_ai.intelligence / trx_ai.conversation
ندارد. هدف: یک زبان مشترک (contract) برای Domain manifest، health
status و event envelope که Solar و Lunar (در مراحل بعدی) از همین
قرارداد استفاده کنند، نه هرکدام قرارداد خودشان را بسازند.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class HealthStatus(str, Enum):
    """وضعیتِ سلامتِ یک Domain یا زیرسیستم."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"  # پیش‌فرضِ امن وقتی خودِ health check شکست بخورد


@dataclass(frozen=True)
class HealthReport:
    """نتیجه‌ی یک health check برای یک Domain."""

    domain: str
    status: HealthStatus
    detail: str = ""
    checked_at: float = field(default_factory=time.time)


@dataclass(frozen=True)
class DomainManifest:
    """
    توصیفِ اعلانی (declarative) یک Domain، طبق بندِ ۱-هـ سندِ
    تخت‌جمشید: manifest، version، capabilities، dependencies.

    این یک شیءِ توصیفی است، نه یک registry فعال؛ ساختنِ این شیء هیچ
    ماژولی را import یا اجرا نمی‌کند.
    """

    name: str
    version: str
    capabilities: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    # مسیر پایتونی ماژول واقعی (فقط برای مستندسازی/ابزارها؛ خودِ
    # foundation آن را import نمی‌کند)
    module_path: str = ""
    description: str = ""


@dataclass(frozen=True)
class EventEnvelope:
    """
    یک رویدادِ سبک برای انتشار از Solar به سمتِ Lunar (در مراحل بعدی).

    عمداً حداقلی است: فقط چیزی که برای ردیابی و تحلیلِ بعدی لازم است،
    نه یک payload دلخواه و بی‌قاعده.
    """

    event_type: str
    source_domain: str
    payload: Dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    trace_id: Optional[str] = None
    created_at: float = field(default_factory=time.time)
