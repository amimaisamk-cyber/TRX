# -*- coding: utf-8 -*-
"""
Event Bus سبک -- معادلِ «Event Store یا Event Bus سبک» بندِ ۱۵ سندِ
تخت‌جمشید (مرحله‌ی ۴ از ترتیبِ اجرای واقعی)، اما ساخته‌شده زودتر و در
همین بسته چون هم Solar (در مراحلِ بعدی) و هم Lunar (در مراحلِ بعدی) به
همین یک قراردادِ EventEnvelope نیاز دارند.

طراحی عمداً حداقلی است:

- کاملاً in-process و in-memory (نه صف/DB خارجی) -- سازگار با محدودیتِ
  منابعِ موبایل که خودِ سند تأکید می‌کند.
- bounded: با یک deque با maxlen، نه رشدِ نامحدود (طبقِ اصلِ Memory
  زیاد = هوشمندی بیشتر نیست، در سندِ ممیزیِ بحرانی).
- fail-soft: اگر یک subscriber استثنا بیندازد، publish() آن را می‌بلعد
  و لاگ می‌کند -- هرگز مسیرِ زنده را نمی‌شکند و هرگز subscriberهای
  دیگر را متوقف نمی‌کند.
- در این مرحله به هیچ نقطه‌ای از core.py/conversation/ وصل نشده است؛
  فقط زیرساخت است، طبقِ همان الگویِ phase3 (اول مستقل بساز، بعداً وصل کن).
"""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Callable, Deque, Dict, List

from .contracts import EventEnvelope
from ...logging_config import get_logger

logger = get_logger(__name__)

EventHandler = Callable[[EventEnvelope], None]

DEFAULT_BUFFER_SIZE = 500


class EventBus:
    """صف‌بندی و توزیعِ سبکِ EventEnvelope، bounded و fail-soft."""

    def __init__(self, buffer_size: int = DEFAULT_BUFFER_SIZE) -> None:
        if buffer_size <= 0:
            raise ValueError("buffer_size must be positive")
        self._buffer_size = buffer_size
        self._recent: Deque[EventEnvelope] = deque(maxlen=buffer_size)
        self._subscribers: Dict[str, List[EventHandler]] = defaultdict(list)
        self._wildcard_subscribers: List[EventHandler] = []

    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        """ثبتِ handler برای یک نوعِ رویدادِ خاص."""
        self._subscribers[event_type].append(handler)

    def subscribe_all(self, handler: EventHandler) -> None:
        """ثبتِ handler برای همه‌ی رویدادها (مثلاً Lunar collector)."""
        self._wildcard_subscribers.append(handler)

    def publish(self, event: EventEnvelope) -> None:
        """
        انتشارِ یک رویداد. همیشه در بافرِ اخیر ذخیره می‌شود؛ سپس هر
        subscriber مستقلاً و fail-soft فراخوانی می‌شود.
        """
        self._recent.append(event)
        handlers = list(self._subscribers.get(event.event_type, ())) + list(
            self._wildcard_subscribers
        )
        for handler in handlers:
            try:
                handler(event)
            except Exception:  # noqa: BLE001 -- عمداً گسترده: fail-soft
                logger.warning(
                    "event handler raised for event_type=%s domain=%s",
                    event.event_type,
                    event.source_domain,
                    exc_info=True,
                )

    def recent(self, limit: int = 50) -> List[EventEnvelope]:
        """
        آخرین رویدادهایِ منتشرشده (جدیدترین در انتها)، برایِ مصرفِ
        بعدیِ Lunar بدونِ نیاز به subscribe از قبل.
        """
        if limit <= 0:
            return []
        items = list(self._recent)
        return items[-limit:]

    def __len__(self) -> int:
        return len(self._recent)


_default_bus: EventBus | None = None


def get_event_bus() -> EventBus:
    """دسترسیِ singleton سبک برای استفاده‌ی مشترک؛ برای تست reset_event_bus را ببینید."""
    global _default_bus
    if _default_bus is None:
        _default_bus = EventBus()
    return _default_bus


def reset_event_bus() -> None:
    """فقط برایِ تست: بازنشانیِ singleton به یک EventBus خالیِ جدید."""
    global _default_bus
    _default_bus = None
