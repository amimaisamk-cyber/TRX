# -*- coding: utf-8 -*-
"""Persepolis Foundation -- قراردادها، خطاها، health registry، event bus."""

from __future__ import annotations

from .contracts import DomainManifest, EventEnvelope, HealthReport, HealthStatus
from .errors import DomainNotFoundError, DomainRegistrationError, FoundationError
from .events import EventBus, get_event_bus, reset_event_bus
from .health import HealthRegistry, aggregate_status

__all__ = [
    "DomainManifest",
    "EventEnvelope",
    "HealthReport",
    "HealthStatus",
    "FoundationError",
    "DomainRegistrationError",
    "DomainNotFoundError",
    "EventBus",
    "get_event_bus",
    "reset_event_bus",
    "HealthRegistry",
    "aggregate_status",
]
