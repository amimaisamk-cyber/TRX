# -*- coding: utf-8 -*-
"""خطاهای Persepolis Foundation -- یک سلسله‌مراتبِ کوچک و صریح."""

from __future__ import annotations


class FoundationError(Exception):
    """پایه‌ی همه‌ی خطاهای این پکیج."""


class DomainRegistrationError(FoundationError):
    """ثبتِ یک Domain manifest نامعتبر یا تکراری."""


class DomainNotFoundError(FoundationError):
    """درخواستِ Domainای که در registry ثبت نشده."""
