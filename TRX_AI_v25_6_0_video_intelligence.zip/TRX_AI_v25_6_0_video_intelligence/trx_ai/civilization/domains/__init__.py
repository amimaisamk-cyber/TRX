# -*- coding: utf-8 -*-
"""Registry اعلانیِ Domainهای موجودِ TRX (بدونِ اتصال به مسیرِ زنده)."""

from __future__ import annotations

from .registry import DomainRegistry, build_default_registry

__all__ = ["DomainRegistry", "build_default_registry"]
