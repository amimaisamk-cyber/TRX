# -*- coding: utf-8 -*-
"""
Registry اعلانیِ Domainهای موجودِ TRX، طبقِ بندِ ۱-هـ سندِ تخت‌جمشید
(«هر Domain باید manifest، version، capabilities، dependencies داشته
باشد»).

نکته‌ی مهم: این فقط توصیف است، نه اتصال. ``build_default_registry``
هیچ‌کدام از پکیج‌هایِ واقعی (medical، nlu، conversation، phase3، ...)
را import نمی‌کند -- فقط رشته‌های نام/نسخه/قابلیت را که از رویِ ساختارِ
واقعیِ پروژه (نه حدس) نوشته شده‌اند ثبت می‌کند. این یعنی حتی اگر یکی
از آن پکیج‌ها import شکسته داشته باشد، ساختِ این registry شکست
نمی‌خورد -- خودش یک مصداقِ عملیِ همان قانونِ «خرابیِ یک بخش نباید کل
سیستم را بخواباند» است.

نسخه‌ی هر Domain در این مرحله «unknown» نیست بلکه به بهترین شکلِ ممکن
از نسخه‌یِ کلیِ پکیج (``trx_ai.__version__``) گرفته شده، چون خودِ
Domainها هنوز نسخه‌ی مستقل ندارند -- این یک gap واقعی است، نه یک
جزئیاتِ فراموش‌شده، و همین‌طور در manifest ثبت می‌شود.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from ..foundation.contracts import DomainManifest
from ..foundation.errors import DomainNotFoundError, DomainRegistrationError


class DomainRegistry:
    """نگه‌دارنده‌ی DomainManifestها به ازایِ نام."""

    def __init__(self) -> None:
        self._manifests: Dict[str, DomainManifest] = {}

    def register(self, manifest: DomainManifest, *, replace: bool = False) -> None:
        if not manifest.name:
            raise DomainRegistrationError("manifest.name نمی‌تواند خالی باشد")
        if manifest.name in self._manifests and not replace:
            raise DomainRegistrationError(
                f"Domain «{manifest.name}» قبلاً ثبت شده؛ برای جایگزینی replace=True بدهید"
            )
        self._manifests[manifest.name] = manifest

    def get(self, name: str) -> DomainManifest:
        try:
            return self._manifests[name]
        except KeyError as exc:
            raise DomainNotFoundError(f"Domain «{name}» ثبت نشده") from exc

    def get_or_none(self, name: str) -> Optional[DomainManifest]:
        return self._manifests.get(name)

    def list_all(self) -> List[DomainManifest]:
        return sorted(self._manifests.values(), key=lambda m: m.name)

    def names(self) -> List[str]:
        return sorted(self._manifests.keys())


def build_default_registry() -> DomainRegistry:
    """
    Registryِ پیش‌فرض بر اساسِ نگاشتِ واقعیِ مرحله‌ی ۰ (این ارتقا) بینِ
    پکیج‌های موجودِ ``trx_ai/`` و مفهومِ Domain در سندِ تخت‌جمشید.

    این تابع خالصانه (pure) است: هر بار فراخوانی، یک registry تازه
    می‌سازد و state ای بینِ فراخوانی‌ها به اشتراک نمی‌گذارد.
    """
    try:
        from ... import __version__ as _pkg_version  # noqa: WPS433
    except Exception:  # noqa: BLE001 -- fail-soft: نسخه اختیاری است
        _pkg_version = "unknown"

    registry = DomainRegistry()
    definitions = [
        DomainManifest(
            name="conversation",
            version=_pkg_version,
            capabilities=[
                "normalize", "context_manage", "emotion_analyze", "topic_track",
                "continuity_analyze", "intent_candidates", "intent_arbitrate",
                "action_gate", "response_plan", "response_critic",
            ],
            dependencies=["nlu"],
            module_path="trx_ai.conversation",
            description="Solar Processing -- خط لوله‌ی Conversation Intelligence (بندِ ۹ سند)",
        ),
        DomainManifest(
            name="nlu",
            version=_pkg_version,
            capabilities=["intent_detect", "disambiguate", "user_state", "multi_intent"],
            dependencies=[],
            module_path="trx_ai.nlu",
            description="تشخیصِ نیت و ابهام‌زدایی",
        ),
        DomainManifest(
            name="medical",
            version=_pkg_version,
            capabilities=["symptom_check", "redflag_safety", "medication_info", "therapy_dialogue"],
            dependencies=["nlu"],
            module_path="trx_ai.medical",
            description="موتورِ پزشکی هوشمند + لایه‌ی ایمنی",
        ),
        DomainManifest(
            name="phase3",
            version=_pkg_version,
            capabilities=["neural_shadow", "neural_advisory_partial"],
            dependencies=["conversation"],
            module_path="trx_ai.phase3",
            description="Native Neural Advisory (بندِ ۱۰ سند) -- در حالِ حاضر Shadow Mode",
        ),
        DomainManifest(
            name="core_engine",
            version=_pkg_version,
            capabilities=["turn_processing", "tool_routing", "agent_bridge", "trace", "backup"],
            dependencies=["conversation", "nlu", "medical"],
            module_path="trx_ai.core_engine",
            description="معادلِ کارکردیِ TRX Supervisor (بندِ ۱ سند) -- هنوز بدونِ manifest/policy رسمی",
        ),
        DomainManifest(
            name="tools",
            version=_pkg_version,
            capabilities=["calculator", "translator", "file_ops", "web_search"],
            dependencies=[],
            module_path="trx_ai.tools",
            description="ابزارهای عمومی",
        ),
        DomainManifest(
            name="memory_store",
            version=_pkg_version,
            capabilities=["session", "cache", "vector_memory"],
            dependencies=["database"],
            module_path="trx_ai.memory_store",
            description="حافظه/state -- توجه: طبقِ بندِ ۱۲ سند، مفهوماً از Lunar Memory Consolidation جداست",
        ),
    ]
    for manifest in definitions:
        registry.register(manifest)
    return registry
