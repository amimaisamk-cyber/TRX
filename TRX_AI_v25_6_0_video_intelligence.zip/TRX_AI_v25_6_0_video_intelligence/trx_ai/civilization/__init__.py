# -*- coding: utf-8 -*-
"""
TRX Civilization Architecture -- پیاده‌سازیِ تدریجیِ سندِ «تخت‌جمشید،
خورشید، ماه» (``TRX_AI_Persepolis_Solar_Lunar_Complete_Blueprint.txt``).

وضعیتِ فعلی: **مرحله‌ی ۰+۱ از ترتیبِ اجرای واقعیِ سند (بندِ ۱۵)**.

    مرحله ۰ (انجام‌شده، خارج از کد): mapping کاملِ فایل‌ها/ساختارِ
    واقعیِ پروژه به مفاهیمِ سند -- نتیجه: بخشِ بزرگی از «Solar
    Processing» از قبل در ``trx_ai.conversation`` وجود دارد؛ Lunar و
    governance رسمی کاملاً جدید هستند.

    مرحله ۱ (همین ارتقا): Persepolis Foundation -- فقط قرارداد،
    health registry، event bus سبک، و registry اعلانیِ Domainهای
    موجود. **بدونِ تغییرِ رفتار**: هیچ فایلِ دیگری در ``trx_ai/``
    تغییر نکرده و هیچ importای از این پکیج به بیرون نمی‌رود.

این پکیج عمداً:

- هیچ importای از ``trx_ai.core`` / ``trx_ai.intelligence`` /
  ``trx_ai.conversation`` ندارد (اتصالِ یک‌طرفه‌یِ صفر، دقیقاً مثلِ
  ``phase3`` در مرحله‌ی ۱).
- هیچ Solar Runtime یا Lunar Runtime واقعی نمی‌سازد -- طبقِ هشدارِ
  «توهمِ پیشرفت»، ساختنِ یک کلاسِ ``SolarRuntime`` که فقط دوباره همان
  ``conversation_engine`` را صدا بزند و اسم عوض کند، upgrade واقعی
  نیست. Resource Controller (SOLAR_FULL/BALANCED/LOW/SAFE) و Lunar
  Runtime -- که واقعاً چیزِ جدیدی اضافه می‌کنند -- مراحلِ بعدی هستند.
"""

from __future__ import annotations

from .domains import DomainRegistry, build_default_registry
from .foundation import (
    DomainManifest,
    DomainNotFoundError,
    DomainRegistrationError,
    EventBus,
    EventEnvelope,
    FoundationError,
    HealthRegistry,
    HealthReport,
    HealthStatus,
    aggregate_status,
    get_event_bus,
    reset_event_bus,
)

__civilization_stage__ = (
    "1/many -- Persepolis Foundation only (contracts, health registry, "
    "event bus, declarative domain registry); Solar Runtime and Lunar "
    "Runtime not yet built; zero behavior change to any existing module"
)

__all__ = [
    "DomainManifest",
    "EventEnvelope",
    "HealthReport",
    "HealthStatus",
    "FoundationError",
    "DomainRegistrationError",
    "DomainNotFoundError",
    "EventBus",
    "get_event_bus",
    "reset_event_bus",
    "HealthRegistry",
    "aggregate_status",
    "DomainRegistry",
    "build_default_registry",
    "__civilization_stage__",
]
