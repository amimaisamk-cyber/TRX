# -*- coding: utf-8 -*-
"""
سه ابزارِ کاربردیِ مستقل: تبدیلِ واحد، تولیدِ رمزِ عبورِ امن، و
محاسبه‌ی BMI. هرکدام self-contained و بدونِ وابستگیِ شبکه‌ای هستند.
"""

from __future__ import annotations

import re
import secrets
import string

from .text_normalize import normalize_text as _normalize_text


# ============================================================
#   تبدیلِ واحد
# ============================================================
class UnitConverter:
    """تبدیلِ طول/وزن/دما بین واحدهایِ رایج."""

    _LENGTH_TO_METERS = {
        "متر": 1, "m": 1,
        "کیلومتر": 1000, "km": 1000,
        "سانتیمتر": 0.01, "سانتی\u200cمتر": 0.01, "cm": 0.01,
        "میلیمتر": 0.001, "میلی\u200cمتر": 0.001, "mm": 0.001,
        "مایل": 1609.344, "mile": 1609.344,
        "فوت": 0.3048, "ft": 0.3048,
        "اینچ": 0.0254, "in": 0.0254,
    }
    _WEIGHT_TO_GRAMS = {
        "کیلوگرم": 1000, "کیلو": 1000, "kg": 1000,
        "گرم": 1, "g": 1,
        "پوند": 453.592, "lb": 453.592,
        "اونس": 28.3495, "oz": 28.3495,
    }

    _UNIT_ALIASES = {**{k: ("length", v) for k, v in _LENGTH_TO_METERS.items()},
                     **{k: ("weight", v) for k, v in _WEIGHT_TO_GRAMS.items()}}

    _QUERY_RE = re.compile(
        r'(\d+(?:[.,]\d+)?)\s*([آ-یa-zA-Z]+)\s*(?:به|رو\s*به|=)\s*([آ-یa-zA-Z]+)'
    )

    @classmethod
    def convert_from_text(cls, text: str) -> str:
        """
        یک جمله‌ی آزاد مثلِ «۱۰ کیلومتر به مایل» یا «۲۰ درجه سانتیگراد
        به فارنهایت» را تجزیه و نتیجه را برمی‌گرداند.
        """
        t = _normalize_text(text)

        # --- دما (قاعده‌ی جداگانه چون رابطه‌ی خطیِ ساده نیست) ---
        # «درجه» اختیاری است: هم «۲۰ درجه سانتیگراد به فارنهایت» و هم
        # «۱۰۰ سانتیگراد به فارنهایت» (بدونِ کلمه‌ی «درجه») باید کار کند
        # — قبلاً «درجه» اجباری بود و حالتِ دوم (که خودِ تست‌های پروژه هم
        # همین را بررسی می‌کردند) با «واحد شناخته نشد» رد می‌شد.
        temp_match = re.search(
            r'(\d+(?:[.,]\d+)?)\s*(?:درجه\s*)?(سانتی\u200cگراد|سانتیگراد|فارنهایت|کلوین)'
            r'\s*(?:به|رو\s*به|=)\s*(?:درجه\s*)?(سانتی\u200cگراد|سانتیگراد|فارنهایت|کلوین)',
            t
        )
        if temp_match:
            value = float(temp_match.group(1).replace(",", "."))
            src = temp_match.group(2).replace("سانتی\u200cگراد", "سانتیگراد")
            dst = temp_match.group(3).replace("سانتی\u200cگراد", "سانتیگراد")
            result = cls._convert_temperature(value, src, dst)
            if result is not None:
                return f"🌡️ {cls._fmt(value)} درجه {src} = {cls._fmt(result)} درجه {dst}"
            return "❌ واحدِ دما شناخته نشد."

        match = cls._QUERY_RE.search(t)
        if not match:
            return "❌ عبارت را نفهمیدم. مثال: «۱۰ کیلومتر به مایل» یا «۵ کیلوگرم به پوند»"

        value = float(match.group(1).replace(",", "."))
        src_unit = match.group(2).strip()
        dst_unit = match.group(3).strip()

        src_info = cls._UNIT_ALIASES.get(src_unit)
        dst_info = cls._UNIT_ALIASES.get(dst_unit)
        if not src_info or not dst_info:
            return f"❌ واحدِ «{src_unit}» یا «{dst_unit}» شناخته نشد."
        if src_info[0] != dst_info[0]:
            return "❌ این دو واحد از یک جنس نیستند (مثلاً طول را نمی‌شود به وزن تبدیل کرد)."

        base_value = value * src_info[1]
        result = base_value / dst_info[1]
        return f"📏 {cls._fmt(value)} {src_unit} = {cls._fmt(result)} {dst_unit}"

    @staticmethod
    def _convert_temperature(value: float, src: str, dst: str):
        # اول به سلسیوس
        if src == "سانتیگراد":
            celsius = value
        elif src == "فارنهایت":
            celsius = (value - 32) * 5 / 9
        elif src == "کلوین":
            celsius = value - 273.15
        else:
            return None
        # از سلسیوس به مقصد
        if dst == "سانتیگراد":
            return celsius
        elif dst == "فارنهایت":
            return celsius * 9 / 5 + 32
        elif dst == "کلوین":
            return celsius + 273.15
        return None

    @staticmethod
    def _fmt(value: float) -> str:
        return f"{value:.2f}".rstrip("0").rstrip(".") if "." in f"{value:.2f}" else f"{value:.2f}"


# ============================================================
#   تولیدِ رمزِ عبورِ امن
# ============================================================
class PasswordGenerator:
    """
    تولیدِ رمزِ عبورِ تصادفی با کتابخانه‌ی `secrets` (نه `random`، چون
    `random` برایِ مصارفِ امنیتی مناسب نیست - از CSPRNG سیستم‌عامل
    استفاده نمی‌کند).
    """

    _LENGTH_RE = re.compile(r'طول\s*(\d+)|(\d+)\s*(?:کاراکتر|رقم)')

    @classmethod
    def generate_from_text(cls, text: str) -> str:
        t = _normalize_text(text)
        length_match = cls._LENGTH_RE.search(t)
        length = 16
        if length_match:
            length = int(length_match.group(1) or length_match.group(2))
        length = max(8, min(length, 128))  # محدوده‌ی معقول (حداقلِ ۸، طبقِ generate())
        password = cls.generate(length)
        return f"🔐 رمزِ عبورِ تولیدشده ({length} کاراکتر):\n`{password}`\n\n⚠️ این رمز را جایی امن ذخیره کن؛ اینجا نگه‌داری نمی‌شود."

    @staticmethod
    def generate(length: int = 16) -> str:
        # حداقلِ ۸: با کمتر از این، برآوردنِ هر ۴ کلاسِ کاراکتری
        # (حروفِ کوچک/بزرگ/رقم/نماد) هم‌زمان یا غیرممکن است یا آن‌قدر
        # نادر که حلقه‌ی زیر می‌تواند عملاً برای همیشه بچرخد. این کلمپ
        # مستقیماً داخلِ خودِ generate() است (نه فقط در
        # generate_from_text) تا هر فراخوانی، از هر جا، امن باشد.
        length = max(8, min(length, 128))
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
        while True:
            password = "".join(secrets.choice(alphabet) for _ in range(length))
            # اطمینان از داشتنِ حداقل یک حرفِ بزرگ، کوچک، رقم و نماد
            if (any(c.islower() for c in password) and any(c.isupper() for c in password)
                    and any(c.isdigit() for c in password)
                    and any(c in "!@#$%^&*()-_=+" for c in password)):
                return password


# ============================================================
#   محاسبه‌ی BMI
# ============================================================
class HealthCalculator:
    """محاسبه‌ی شاخصِ توده‌ی بدنی (BMI) — یک فرمولِ استانداردِ عمومی، نه تشخیصِ پزشکی."""

    _NUMBER_RE = re.compile(r'\d+(?:[.,]\d+)?')
    _WEIGHT_KW_RE = re.compile(r'وزن(?:م)?')
    _HEIGHT_KW_RE = re.compile(r'قد(?:م)?')

    @staticmethod
    def _kw_center(kw_match) -> float:
        return (kw_match.start() + kw_match.end()) / 2

    @staticmethod
    def _num_center(num) -> float:
        return (num[0] + num[1]) / 2

    @classmethod
    def _nearest_number(cls, text: str, kw_match, exclude_span=None):
        """
        نزدیک‌ترین عدد به یک کلیدواژه (وزن/قد) را پیدا می‌کند — نه فقط
        عددی که بلافاصله بعدش آمده، چون «۷۰ کیلو وزن دارم» (عدد قبل از
        کلمه) و «وزنم: ۷۰» (علامتِ نگارشی بینِ کلمه و عدد) هم رایج‌اند.
        فالبک: وقتی بیش از دو عدد در متن هست و نمی‌شود با تخصیصِ مشترکِ
        _assign_weight_height یک‌جا تصمیم گرفت.
        """
        numbers = [
            (m.start(), m.end(), m.group()) for m in cls._NUMBER_RE.finditer(text)
            if exclude_span is None or not (m.start() >= exclude_span[0] and m.end() <= exclude_span[1])
        ]
        if not numbers:
            return None
        kw_center = cls._kw_center(kw_match)
        return min(numbers, key=lambda n: abs(cls._num_center(n) - kw_center))

    @classmethod
    def _assign_weight_height(cls, text: str, weight_kw, height_kw):
        """
        وزن و قد را از رویِ عددهایِ متن پیدا می‌کند. باگِ قبلی: وقتی هر دو
        کلیدواژه بینِ دو عدد قرار می‌گرفتند (مثلاً «قدم ۱۷۸ وزنم ۱۹۰»)،
        روشِ قدیمی هر عدد را جداگانه و فقط بر اساسِ نزدیک‌ترین‌بودن به
        «وزن» انتخاب می‌کرد — و چون فاصله‌ی «وزن» تا هر دو عدد می‌توانست
        خیلی نزدیک به هم باشد، گاهی عددِ قد را به‌جایِ وزن برمی‌داشت (نتیجه‌ی
        BMI اشتباه، بدونِ هیچ خطایی). راه‌حل: وقتی دقیقاً دو عدد در متن است،
        بهترین تخصیصِ مشترک (کدام عدد به کدام کلیدواژه) را با مقایسه‌ی
        مجموعِ فاصله‌ها انتخاب می‌کنیم، نه هر کلیدواژه را جداگانه.
        """
        numbers = [(m.start(), m.end(), m.group()) for m in cls._NUMBER_RE.finditer(text)]
        if len(numbers) == 2:
            n1, n2 = numbers
            cost_normal = (abs(cls._num_center(n1) - cls._kw_center(weight_kw))
                           + abs(cls._num_center(n2) - cls._kw_center(height_kw)))
            cost_swapped = (abs(cls._num_center(n2) - cls._kw_center(weight_kw))
                            + abs(cls._num_center(n1) - cls._kw_center(height_kw)))
            return (n1, n2) if cost_normal <= cost_swapped else (n2, n1)

        weight_num = cls._nearest_number(text, weight_kw)
        if not weight_num:
            return None, None
        height_num = cls._nearest_number(text, height_kw, exclude_span=(weight_num[0], weight_num[1]))
        return weight_num, height_num

    @classmethod
    def calculate_from_text(cls, text: str) -> str:
        t = _normalize_text(text)
        weight_kw = cls._WEIGHT_KW_RE.search(t)
        height_kw = cls._HEIGHT_KW_RE.search(t)
        if not weight_kw or not height_kw:
            return ("❌ وزن و قد را متوجه نشدم. مثال: «بی‌ام‌آی من چنده وزنم ۷۰ قدم ۱۷۵»\n"
                    "(وزن به کیلوگرم، قد به سانتیمتر)")

        weight_num, height_num = cls._assign_weight_height(t, weight_kw, height_kw)
        if not weight_num:
            return "❌ عددِ وزن را متوجه نشدم."
        if not height_num:
            return "❌ عددِ قد را متوجه نشدم."

        weight = float(weight_num[2].replace(",", "."))
        height_cm = float(height_num[2].replace(",", "."))
        if weight <= 0 or height_cm <= 0:
            return "❌ وزن/قد باید عددِ مثبت باشد."
        if weight > 500 or height_cm > 300 or height_cm < 50:
            return "❌ عددهای واردشده برایِ وزن/قدِ انسانی معقول به نظر نمی‌رسند؛ لطفاً دوباره بررسی کن."

        height_m = height_cm / 100
        bmi = weight / (height_m ** 2)

        if bmi < 18.5:
            category = "کم‌وزن"
        elif bmi < 25:
            category = "طبیعی"
        elif bmi < 30:
            category = "اضافه‌وزن"
        else:
            category = "چاق"

        return (
            f"⚖️ **شاخصِ توده‌ی بدنی (BMI): {bmi:.1f}**\n\n"
            f"دسته‌بندی: **{category}**\n\n"
            f"📌 این یک فرمولِ استانداردِ عمومی است (وزن ÷ قدِ به‌متر به‌توانِ ۲)، "
            f"نه یک تشخیصِ پزشکی؛ برایِ ارزیابیِ دقیقِ سلامت با پزشک مشورت کن."
        )
