# -*- coding: utf-8 -*-
"""
ابزارهای امنیتیِ مشترک برای هر بخشی از برنامه که کدِ پویا اجرا می‌کند
(exec) — فعلاً `interpreter.py` (مفسر فارسی) و `plugins.py` (اجرای
پلاگین). به‌جای اینکه هر ماژول جداگانه یک نسخه از این منطق را
بازنویسی کند، یک نسخه‌ی مشترک اینجاست تا هر بخشِ جدیدی هم که در آینده
exec() اضافه کند، به‌طور پیش‌فرض همین محافظت را داشته باشد.

این یک sandbox کامل نیست (چیزی مثل PyPy sandbox یا seccomp)؛ هدف،
جلوگیری از رایج‌ترین دسته‌های خطا/آسیب است:
    ۱) حلقه‌ی بی‌پایان که کل برنامه را فریز می‌کند (تایم‌اوت).
    ۲) دسترسیِ سطح‌سیستم‌عاملی (os.system, subprocess, shutil.rmtree, ...)
       — چه با import مستقیم، چه با __import__/importlib.import_module،
       چه با دسترسیِ مستقیم به فایل (open).

محدودیتِ صادقانه: این یک بررسیِ ایستا (AST-based) با یک لیستِ سیاه
است، نه یک ماشین مجازیِ ایزوله. «ارزیابی»/«اجرا»/«کامپایل» (eval/exec/
compile) عمداً بلوک نشده‌اند چون بخشی از واژگانِ رسمیِ خودِ زبان (مفسرِ
فارسی) هستند؛ یعنی اگر کاربر یک رشته‌ی متن را با «اجرا(...)» به exec
بدهد، محتوایِ آن رشته در لحظه‌ی این بررسیِ ایستا هنوز به AST تبدیل
نشده و از دیدِ find_dangerous_pattern دیده نمی‌شود. به همین دلیل، این
ابزار فقط برایِ کدِ محلی/قابل‌اعتماد مناسب است، نه برایِ پذیرشِ کد از
منابعِ ناشناس.
"""

from __future__ import annotations

import ast
import contextlib
from typing import Optional

from .logging_config import get_logger

logger = get_logger(__name__)

try:
    import signal as _signal

    SIGALRM_AVAILABLE = hasattr(_signal, "SIGALRM")
except ImportError:  # pragma: no cover
    _signal = None
    SIGALRM_AVAILABLE = False


class ExecutionTimeout(Exception):
    """برای قطعِ اجرای کدی که بیش‌ازحد طول کشیده (مثلاً حلقه‌ی بی‌نهایت)."""


# فراخوانی‌های سطح‌سیستم‌عاملی که هیچ‌وقت نباید از یک exec() داخلیِ
# برنامه (کدِ کاربر/پلاگین) صدا زده شوند.
#
# «__import__» و «importlib.import_module» عمداً اینجا هستند: قبلاً
# فقط دستورهای import واقعی (ast.Import/ImportFrom) بررسی می‌شدند، در
# نتیجه کدی مثل «__import__('os').system(...)» یا
# «importlib.import_module('os')» که os را نه با import بلکه با یک
# فراخوانیِ تابع بارگذاری می‌کند، هیچ‌وقت به‌عنوان «وارد‌کردنِ ماژول»
# دیده نمی‌شد و از این بررسی رد می‌شد؛ همان‌طور که «open» (دسترسیِ
# مستقیم به فایل‌سیستم) هم اصلاً در لیست نبود. نکته: ast.walk() هر
# Call را حتی وقتی داخلِ یک Call دیگر تودرتو باشد (مثلِ
# «__import__('os').system(...)» که خودِ «__import__('os')» یک گرهِ
# Call مستقل است) جداگانه می‌بیند، پس همین یک بررسی برایِ حالتِ
# تودرتو هم کافی است.
BLOCKED_CALL_NAMES = {
    "os.system", "os.popen", "os.remove", "os.rmdir", "os.unlink",
    "subprocess.call", "subprocess.run", "subprocess.Popen",
    "shutil.rmtree", "pickle.loads", "pickle.load",
    "__import__", "importlib.import_module", "open",
    # این چهارتا اسمِ عادیِ هیچ‌کدام از کلیدواژه‌های مفسرِ فارسی نیستند
    # (نگاه کنید به translations در interpreter.py)، پس بلوک‌کردنشان
    # هیچ قابلیتِ مستندی را نمی‌شکند؛ اما بدونشان، کدِ کاربر می‌توانست
    # با getattr(builtins, '__import__')(...) یا vars(__builtins__) به
    # os برسد بدونِ اینکه اصلاً «__import__» یا نامِ ماژول را مستقیم
    # در متنِ کد بنویسد.
    "getattr", "setattr", "delattr", "vars", "globals", "locals",
}
BLOCKED_IMPORT_MODULES = {
    "os", "subprocess", "shutil", "sys", "socket", "ctypes", "importlib",
    # دسترسیِ شبکه از راه‌هایِ دیگر (نه فقط socket): قبلاً یک پلاگین
    # می‌توانست با «import urllib.request; urllib.request.urlopen(...)»
    # داده را به بیرون بفرستد بدونِ اینکه هیچ‌کدام از بررسی‌های این فایل
    # آن را تشخیص بدهد — چون فقط «socket» در لیست بود، نه بقیه‌یِ
    # ماژول‌هایِ استانداردِ شبکه‌ایِ پایتون.
    "urllib", "http", "ftplib", "smtplib", "telnetlib",
}


def find_dangerous_pattern(python_code: str) -> Optional[str]:
    """
    کدِ پایتونِ آماده‌ی اجرا را برای import/فراخوانیِ خطرناک بررسی
    می‌کند. اگر چیزی پیدا شد، پیامِ توضیحی برمی‌گرداند؛ وگرنه None.
    اگر خودِ کد سینتکس‌اکتر نامعتبر باشد، None برمی‌گرداند (خطای
    سینتکس مسئولیتِ فراخوانی‌کننده است، نه این تابع).
    """
    try:
        tree = ast.parse(python_code)
    except SyntaxError:
        return None

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [node.module] if isinstance(node, ast.ImportFrom) else [a.name for a in node.names]
            for name in names:
                root = (name or "").split(".")[0]
                if root in BLOCKED_IMPORT_MODULES:
                    return f"وارد‌کردنِ ماژولِ «{root}» مسدود است (دسترسیِ سطح‌سیستم‌عاملی)"
        if isinstance(node, ast.Call):
            parts = []
            cur = node.func
            while isinstance(cur, ast.Attribute):
                parts.append(cur.attr)
                cur = cur.value
            if isinstance(cur, ast.Name):
                parts.append(cur.id)
            dotted = ".".join(reversed(parts))
            if dotted in BLOCKED_CALL_NAMES:
                return f"فراخوانیِ «{dotted}(...)» مسدود است (عملیاتِ خطرناکِ سیستمی)"
        if isinstance(node, ast.Attribute):
            # دسترسی به هر attributeی که با «__» شروع و تمام می‌شود
            # (مثلِ ``__class__``, ``__bases__``, ``__subclasses__``,
            # ``__globals__``, ``__mro__``, ``__builtins__``) مسدود
            # است. هیچ‌یک از متدهای ترجمه‌شده‌ی مفسرِ فارسی
            # (append/get/split/...) شکلِ dunder ندارند، پس این بلوک
            # هیچ قابلیتِ مستندی را نمی‌شکند؛ اما دقیقاً همان مسیرِ
            # معروفِ دورزدنِ sandboxهایِ مبتنی‌بر لیستِ سیاه را می‌بندد:
            # زنجیره‌ای مثلِ ``().__class__.__base__.__subclasses__()``
            # هیچ import یا فراخوانیِ نام‌داری ندارد، فقط attribute
            # access است — پس بدونِ این بررسی از دیدِ حلقه‌ی بالا کاملاً
            # نامرئی بود.
            if node.attr.startswith("__") and node.attr.endswith("__"):
                return f"دسترسی به attributeِ «{node.attr}» مسدود است (مسیرِ شناخته‌شده‌ی دورزدنِ sandbox)"
        if isinstance(node, ast.Name):
            # همان بررسیِ بالا، اما برایِ ارجاعِ *مستقیمِ نام* (نه
            # attribute access). مثلاً ``__builtins__`` یک نامِ آزاد در
            # globals است، نه attributeِ چیزِ دیگری؛ کدی مثلِ
            # ``x = __builtins__`` یا ``__builtins__['open']`` هیچ
            # ast.Attribute تولید نمی‌کند و بدونِ این شاخه از بررسیِ بالا
            # کاملاً رد می‌شد. همین‌طور خودِ «open» را هم اینجا به‌عنوانِ
            # یک نامِ مسدود اضافه می‌کنیم: صرفِ *ارجاع* به open (مثلِ
            # ``x = open``) بدونِ فراخوانیِ مستقیم، قبلاً هیچ‌جا بررسی
            # نمی‌شد و بعداً با ``x(...)`` قابلِ دورزدنِ BLOCKED_CALL_NAMES
            # بود.
            if (node.id.startswith("__") and node.id.endswith("__")) or node.id == "open":
                return f"دسترسی/ارجاع به نامِ «{node.id}» مسدود است (مسیرِ شناخته‌شده‌ی دورزدنِ sandbox)"
        if isinstance(node, ast.Subscript):
            # دورزدنِ رایجِ دیگر: به‌جایِ ``__builtins__.open``، از
            # ایندکس‌گذاریِ رشته‌ای استفاده می‌شود، مثلِ
            # ``__builtins__['open']`` یا ``vars(some_obj)['__class__']``.
            # چون کلیدِ subscript معمولاً یک ثابتِ رشته‌ای است، همان
            # اسمِ رشته را با همان قوانینِ بالا (نامِ مسدود یا dunder)
            # می‌سنجیم -- مستقل از اینکه شیءِ پایه چه چیزی است.
            key_node = node.slice
            if isinstance(key_node, ast.Constant) and isinstance(key_node.value, str):
                key = key_node.value
                if (key.startswith("__") and key.endswith("__")) or key in BLOCKED_CALL_NAMES:
                    return f"دسترسیِ ایندکسی به «{key}» مسدود است (مسیرِ شناخته‌شده‌ی دورزدنِ sandbox)"
    return None


# نام‌هایی که هیچ‌وقت نباید در __builtins__ای که به exec()های داخلی
# (مفسر فارسی، پلاگین) تزریق می‌شود حاضر باشند — لایه‌ی دومِ دفاعی،
# مستقل از find_dangerous_pattern. هیچ‌کدام از این نام‌ها معادلِ
# فارسیِ مستندی در translations (نگاه کنید به interpreter.py) ندارند،
# پس حذفشان هیچ قابلیتِ رسمیِ زبان را نمی‌شکند؛ فقط ابزارهایِ
# introspection‌ای را می‌بندد که می‌توانستند بدونِ نوشتنِ صریحِ
# «__import__» یا نامِ یک ماژولِ مسدود، به os/subprocess برسند
# (مثلاً ``getattr(builtins, '__import__')(...)`` یا ``vars(...)``).
_UNSAFE_BUILTIN_NAMES = {
    "__import__",
    "getattr", "setattr", "delattr", "vars", "globals", "locals",
    "breakpoint", "exit", "quit",
    # «open» هم از خودِ builtins تزریق‌شده حذف می‌شود، نه فقط این‌که در
    # find_dangerous_pattern به‌عنوانِ فراخوانیِ مستقیم مسدود باشد. قبلاً
    # این تابع در builtins باقی می‌ماند با این توجیه که «فراخوانیِ
    # مستقیمش از قبل در سطحِ ایستا مسدود است»؛ اما ایستا فقط
    # ``open(...)`` را می‌بیند، نه ``x = open`` و بعد ``x(...)``. حذفِ
    # واقعیِ آن از builtins یک لایه‌ی دفاعیِ دومِ مستقل از AST است. هیچ
    # قابلیتِ مستندی نمی‌شکند: «باز» در translations مفسرِ فارسی هم از
    # قبل جزوِ BLOCKED_CALL_NAMES بود، یعنی حتی قبل از این تغییر هم
    # فراخوانیِ مستقیمِ «باز(...)» همیشه مسدود می‌شد.
    "open",
}

# برخلافِ موارد بالا، «ارزیابی»/«اجرا»/«کامپایل» (eval/exec/compile)
# بخشی از واژگانِ رسمیِ مفسرِ فارسی هستند (translations در
# interpreter.py) و حذفشان رفتارِ مستند را می‌شکند. به‌جایِ حذف، این سه
# با نسخه‌ای Wrap می‌شوند که همان بررسیِ find_dangerous_pattern را —
# همین حالا، رویِ خودِ رشته‌ای که قرار است اجرا شود — دوباره انجام
# می‌دهد. این دقیقاً همان حفره‌ای را می‌بندد که در docstring بالایِ این
# فایل توضیح داده شده: کدی که در زمانِ اجرا یک رشته‌ی «import os» بسازد
# و آن را به «اجرا(...)» بدهد، دیگر بی‌بررسی از این‌جا رد نمی‌شود.
_REEXAMINED_BUILTINS = ("eval", "exec", "compile")


def _guarded(original_name, original_fn):
    def _wrapped(source, *args, **kwargs):
        if isinstance(source, str):
            danger = find_dangerous_pattern(source)
            if danger:
                raise PermissionError(
                    f"دسترسیِ زمانِ‌اجرا مسدود شد ({original_name} با محتوایِ خطرناک): {danger}"
                )
        return original_fn(source, *args, **kwargs)

    _wrapped.__name__ = original_name
    return _wrapped


def restricted_builtins() -> dict:
    """
    یک کپیِ محدودشده از builtins استاندارد برمی‌گرداند که برایِ تزریق
    به‌عنوانِ ``{"__builtins__": ...}`` در globals یک ``exec()`` داخلی
    امن‌تر است:
        - نام‌هایِ _UNSAFE_BUILTIN_NAMES کاملاً حذف شده‌اند (هیچ‌کدام
          کلیدواژه‌ی مستندِ زبان نیستند).
        - eval/exec/compile حذف *نشده‌اند* (چون کلیدواژه‌ی مستند
          هستند: ارزیابی/اجرا/کامپایل) اما با نسخه‌ای Wrap شده‌اند که
          محتوایِ رشته‌ای‌شان را دوباره از فیلترِ find_dangerous_pattern
          رد می‌کند.
        - بقیه‌ی builtinsهایِ عادی (print, len, range, open, input, ...)
          دست‌نخورده می‌مانند — از جمله «open»، چون فراخوانیِ مستقیمِ آن
          از قبل توسطِ find_dangerous_pattern در سطحِ ایستا مسدود است؛
          حذفش از builtins چیزی اضافه نمی‌کرد.

    توجه صادقانه: این هنوز یک ایزوله‌سازیِ کاملِ سیستم‌عامل-درجه نیست.
    """
    import builtins as _builtins_module

    source = dict(_builtins_module.__dict__)
    for name in _UNSAFE_BUILTIN_NAMES:
        source.pop(name, None)
    for name in _REEXAMINED_BUILTINS:
        if name in source:
            source[name] = _guarded(name, source[name])
    return source


@contextlib.contextmanager
def time_limited_execution(seconds: int):
    """
    Context manager که اجرای بلاکِ داخلش را بعد از `seconds` ثانیه با
    ExecutionTimeout قطع می‌کند (فقط روی سیستم‌عامل‌های POSIX که
    SIGALRM دارند - یعنی لینوکس/اندروید/Termux/مک؛ روی ویندوز بدونِ
    تایم‌اوت اجرا می‌شود، چون SIGALRM آنجا وجود ندارد).

    مثال:
        with time_limited_execution(5):
            exec(code, globals_dict)
    """
    if not SIGALRM_AVAILABLE:
        yield
        return

    def _on_timeout(signum, frame):
        raise ExecutionTimeout()

    previous_handler = _signal.signal(_signal.SIGALRM, _on_timeout)
    _signal.alarm(seconds)
    try:
        yield
    finally:
        _signal.alarm(0)
        _signal.signal(_signal.SIGALRM, previous_handler)
