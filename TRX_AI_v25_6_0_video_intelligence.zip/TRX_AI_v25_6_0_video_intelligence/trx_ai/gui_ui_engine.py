# -*- coding: utf-8 -*-
"""
GuiUIEngine — یک جایگزینِ کاملِ UIEngine (همان رابطِ عمومی/همان اسامیِ
متد) که به‌جای چاپ در ترمینال با rich، هر خروجی را به‌صورتِ یک رویدادِ
ساختاریافته (dict) به یک صف (queue) می‌فرستد. رابطِ گرافیکی (gui_app.py)
این صف را می‌خواند و در پنجره نمایش می‌دهد.

چرا این‌طور طراحی شده، نه یک رابطِ کاملاً جدا برایِ GUI:
`TRXEnterpriseAI._process_turn` (در core.py) تمامِ خروجی‌اش را از طریقِ
`self.ui.*` انجام می‌دهد. اگر این کلاس همان متدهای عمومیِ UIEngine را
با همان امضا پیاده کند، کافی‌ست هنگامِ ساختِ TRXEnterpriseAI یک نمونه
از GuiUIEngine به‌جایِ UIEngine تزریق شود — آن‌وقت کل منطقِ مسیریابی،
تشخیصِ نیت، گفتگوی پزشکی، چندزبانگی و... بدونِ تغییر، برایِ GUI هم کار
می‌کند. یعنی هیچ باگی که در ترمینال رفع شده، در GUI دوباره ظاهر نمی‌شود
— دقیقاً همان کد اجرا می‌شود.
"""

from __future__ import annotations

import io
import queue
import re
from datetime import datetime
from typing import Tuple

from rich.console import Console

# تبدیلِ ارقام/تقویم را از UIEngine ترمینالی عیناً قرض می‌گیریم (منطقِ
# خالص، بدونِ وابستگی به rich) تا دوباره‌نویسی نشود.
from .ui import UIEngine as _TerminalUIEngine


class GuiEvent:
    """یک رویدادِ خروجی که باید در GUI نمایش داده شود."""

    def __init__(self, kind: str, **payload):
        self.kind = kind  # "message" | "emergency" | "followup" | "voice_prompt" | "status" | "raw" | "stream_start" | "stream_delta" | "stream_end" | "image" | "scene"
        self.payload = payload
        self.timestamp = datetime.now()


class GuiUIEngine:
    """
    پیاده‌سازیِ رابطِ UIEngine برایِ مصرفِ رابطِ گرافیکی. متدها همان
    امضایِ UIEngine ترمینالی را دارند تا `core.py` بدونِ تغییر کار کند.
    """

    def __init__(self):
        self.events: "queue.Queue[GuiEvent]" = queue.Queue()
        self._digit_helper = _TerminalUIEngine()  # فقط برای e2f/f2e/get_farsi_date_time (بدونِ رندر)
        # اگر GUI یک گزینه‌ی «همیشه صدا داشته باش» فعال کند، این‌جا مقدار
        # می‌گیرد و voice_prompt به‌جایِ بلاک‌کردن، بلافاصله همان انتخاب
        # را برمی‌گرداند.
        self.auto_voice_choice: str = ""  # "" یعنی خاموش، "1"/"2" یعنی صدایِ خودکار
        # در رابطِ وب، متن توسط SpeechSynthesis مرورگر خوانده می‌شود و
        # نباید edge-tts فایل صوتی روی دیسک بسازد.
        self.browser_speech: bool = False

        # core.py گاهی به‌جایِ متنِ ساده، اشیاءِ rich (مثلِ Panel/Table)
        # را مستقیم به self.ui.console.print(...) می‌دهد (مثلاً بنرِ
        # خوش‌آمدگویی، جدولِ آمار/داشبورد). به‌جایِ بازنویسیِ آن بخش‌ها،
        # از یک Console داخلیِ rich که به‌جایِ ترمینال به یک بافرِ متنی
        # می‌نویسد استفاده می‌کنیم تا هر renderable (Panel/Table/متنِ
        # دارایِ تگِ [bold]...[/bold]) درست به متنِ ساده تبدیل شود.
        self._buffer = io.StringIO()
        self._capture_console = Console(file=self._buffer, width=88, no_color=True, highlight=False)

    # ---- تبدیل‌های خالص (بدونِ رندر)، مستقیم از UIEngine ترمینالی ----
    def e2f(self, value) -> str:
        return self._digit_helper.e2f(value)

    def f2e(self, value) -> str:
        return self._digit_helper.f2e(value)

    def get_farsi_date_time(self) -> Tuple[str, str]:
        return self._digit_helper.get_farsi_date_time()

    # ---- «console» جعلی: برایِ فراخوانی‌هایی مثلِ self.ui.console.print(...) ----
    @property
    def console(self):
        return self

    def print(self, *args, **kwargs):
        """
        معادلِ console.print در ترمینال. چه ورودی متنِ سادهٔ دارایِ
        تگِ rich باشد (مثلِ "[bold cyan]...[/bold cyan]") چه یک
        renderable کامل (Panel/Table/Rule)، با همان موتورِ رندرِ rich
        (رو یک بافرِ متنی به‌جایِ ترمینال) به متنِ ساده تبدیل می‌شود.

        نکته‌ی مهم: کاراکترهایِ کادرکشیِ یونیکدِ rich (═ ║ ╔ ╗ ╭ ╮ ...)
        روی برخی دستگاه‌ها (مثلاً Pydroid3/اندروید) در هیچ‌کدام از
        فونت‌های در‌دسترس گلیف ندارند و به‌صورتِ جعبه‌های خالی (تُهی/□)
        نمایش داده می‌شوند. به‌جایِ وابسته‌بودن به این‌که کدام فونت روی
        کدام دستگاه نصب است، این کاراکترها بعد از رندر به معادلِ
        ASCII‌شان تبدیل می‌شوند — ASCII را هر فونتی، روی هر دستگاهی،
        همیشه درست نشان می‌دهد.
        """
        end = kwargs.get("end", "\n")
        self._buffer.seek(0)
        self._buffer.truncate(0)
        try:
            self._capture_console.print(*args, end=end)
        except Exception:  # noqa: BLE001 - نمایش هرگز نباید کرش کند
            self.events.put(GuiEvent("raw", text=" ".join(str(a) for a in args)))
            return
        text = self._buffer.getvalue().rstrip("\n")
        if not text.strip():
            return
        self.events.put(GuiEvent("raw", text=_ascii_box_drawing(text)))

    def status(self, message: str, spinner: str = "dots"):
        """معادلِ console.status: یک رویدادِ «در حالِ پردازش» برایِ نمایشِ لودینگ در GUI."""
        return _StatusContext(self, _strip_rich_markup(message))

    def clear(self):
        pass  # در GUI معنایی ندارد؛ پنجره خودش تاریخچه را نگه می‌دارد

    # ---- بنر/راهنما ----
    def show_header(self, user_name: str, personality: str, active_session: str):
        self.events.put(GuiEvent("status", user=user_name, personality=personality, project=active_session))

    def show_guide(self):
        rows = [
            ("خروج / exit / quit", "پایان جلسه"),
            ("آمار / داشبورد", "آمارِ سیستم / RAM-CPU-زمانِ پاسخ"),
            ("یادم بنداز <کار>", "ثبتِ یک کار/یادآوری"),
            ("کارهام چیه", "نمایشِ فهرستِ کارها"),
            ("۲۳۴ ضربدر ۵۶ / ۱۰ کیلومتر به مایل", "ماشین‌حساب / تبدیلِ واحد (کاملاً محلی)"),
            ("ترجمه کن ... به انگلیسی", "ترجمه‌ی متن"),
            ("معنی کلمه ...", "معنیِ لغت"),
            ("سرچ / جستجو <موضوع>", "جستجویِ رایگان (ویکی‌پدیا، سپس DuckDuckGo)"),
            ("هوای <شهر> / قیمت دلار", "آب‌وهوا / نرخِ ارز"),
            ("بخوان <مسیر فایل>", "خواندنِ PDF/Word/Excel/متن/کد از رویِ سرور"),
            ("این کد رو تحلیل/اصلاح کن", "بررسیِ کد (محلی)"),
            ("تحلیل پروژه [مسیر]", "اسکنِ ساختارِ یک پروژه‌ی کد"),
            ("چاپ(«سلام») / بگو(«...»)", "مفسرِ فارسی — اجرایِ کدِ فارسی"),
            ("علائم/دارو/بیماری...", "مشاوره‌ی پزشکیِ اولیه (محلی)"),
            ("یاد بگیر: <مطلب>", "افزودن به حافظه‌ی بلندمدت"),
            ("تاریخچه", "نمایش تاریخچه‌ی اخیرِ گفتگو"),
            ("پروژه‌ها / پروژه جدید <نام>", "مدیریتِ پروژه‌ها"),
            ("شخصیت <نام>", "تغییر شخصیتِ دستیار"),
            ("📷 پیوستِ عکس", "با دکمه‌ی 📷 کنارِ ورودی؛ کپشنِ «متن...»=OCR، «کیفیت...»=بهبودِ کیفیت، وگرنه تحلیلِ محلی"),
            ("📎 پیوستِ فایل", "با دکمه‌ی 📎 کنارِ ورودی؛ آپلودِ مستقیمِ PDF/Word/Excel/متن/کد از دستگاهِ خودتان"),
            ("یه ویدیو از زیر آب بساز", "🎬 ساختِ صحنه‌ی ویدیوییِ متحرک (محلی) — مثال‌هایِ بیشتر: «راهنمای ویدیو»"),
            ("دوربین رو نزدیک‌تر کن / نور رو کم کن", "🎬 اصلاحِ همان صحنه (فقط بعد از ساختِ یک صحنه)"),
            ("(متن آزاد)", "هر چیزی بپرسید — همه‌چیز محلی یا با منابعِ رایگانِ وب، بدونِ هیچ APIِ خارجی"),
        ]
        self.events.put(GuiEvent("guide", rows=rows))

    # ---- نمایشِ پاسخ‌ها ----
    async def animated_print(self, text: str, title: str = "", style: str = "", speed: float = 0.0):
        """
        در GUI نیازی به «نمایشِ تدریجی» نیست (خودِ ویجت می‌تواند این
        جلوه را با انیمیشنِ CSS/Qt انجام دهد)؛ این متد فقط پیامِ کامل
        را یک‌جا می‌فرستد.
        """
        self.events.put(GuiEvent("message", text=text, title=title or "پاسخ", style=style))

    def show_emergency(self, message: str):
        self.events.put(GuiEvent("emergency", text=message))

    def show_followup_question(self, question: str):
        self.events.put(GuiEvent("followup", text=question))

    def show_image(self, url: str, title: str = "", caption: str = ""):
        """
        عکس (اصلِ ورودیِ کاربر یا خروجیِ ابزارِ بهبودِ کیفیت). فقط یک
        رویدادِ ساده با URLِ سرویس‌شونده از `/files/...` (نگاه کنید به
        webserver.py) -- خودِ رندرِ `<img>` در web_assets.py انجام می‌شود.
        """
        self.events.put(GuiEvent("image", url=url, title=title or "📷 تصویر", caption=caption or ""))

    def show_scene(self, url: str, scene_id: str = "", title: str = "", duration: float = 0):
        """
        صحنه‌ی ویدیوییِ HTML/CSS/JSِ خودکفا (trx_ai/video/). دقیقاً مثلِ
        show_image، فقط یک رویداد با URLِ سرویس‌شونده از `/files/...`
        می‌فرستد -- رندرِ واقعی (iframeِ sandboxed) در web_assets.py است.
        """
        self.events.put(GuiEvent("scene", url=url, scene_id=scene_id,
                                  title=title or "🎬 صحنه‌ی ویدیو", duration=duration))

    # ---- صدا ----
    def voice_prompt(self):
        """
        در ترمینال این متد فقط سؤال را چاپ می‌کند و بعدش core.py با
        async_input منتظرِ پاسخ می‌ماند. در GUI نمی‌خواهیم پیامِ بعدی را
        بلاک کنیم؛ بنابراین اگر کاربر از تنظیماتِ GUI صدا را از پیش
        روشن کرده باشد (`auto_voice_choice`)، همینجا رویدادِ متناظر را
        می‌فرستیم و core.py (که این مقدار را از طریقِ تابعِ ورودیِ
        تزریق‌شده می‌خواند) بلافاصله همان را دریافت می‌کند، بدونِ توقف.
        """
        self.events.put(GuiEvent("voice_prompt"))

    def voice_generating(self):
        return _StatusContext(self, "🗣️ در حال تولید صدا...")

    def voice_saved(self, filepath: str):
        self.events.put(GuiEvent("voice_saved", path=filepath))

    def voice_failed(self):
        self.events.put(GuiEvent("voice_failed"))

    def thinking(self, label: str = "در حال پردازش..."):
        return _StatusContext(self, label)

    def stream_start(self, title: str = "", style: str = ""):
        """
        شروعِ نمایشِ زنده‌ی یک پاسخِ در‌حالِ‌تولید در GUI — معادلِ
        ``UIEngine.stream_start`` ترمینالی. یک شناسه‌ی یکتا برایِ این
        استریم می‌سازد و رویدادِ ``stream_start`` را در صف می‌گذارد؛
        gui_app.py با دیدنِ این رویداد یک حبابِ خالی می‌سازد و موقعیتِ
        آن را نگه می‌دارد تا با هر ``stream_delta`` بعدی، فقط همان حباب
        (نه کلِ تاریخچه‌ی گفتگو) بازنویسی شود.
        """
        return _GuiStreamHandle(self, title or "پاسخ", style)


class _GuiStreamHandle:
    """نگه‌دارنده‌ی یک استریمِ در‌حالِ‌اجرا در GUI؛ نگاه کنید به GuiUIEngine.stream_start."""

    def __init__(self, engine: "GuiUIEngine", title: str, style: str):
        self.engine = engine
        self.stream_id = id(self)
        self.engine.events.put(GuiEvent("stream_start", stream_id=self.stream_id, title=title, style=style))

    def update(self, text: str) -> None:
        self.engine.events.put(GuiEvent("stream_delta", stream_id=self.stream_id, text=text))

    def close(self) -> None:
        self.engine.events.put(GuiEvent("stream_end", stream_id=self.stream_id))


class _StatusContext:
    """جایگزینِ Console.status ترمینال: هم به‌عنوانِ context manager معمولی و هم async قابلِ استفاده است."""

    def __init__(self, engine: GuiUIEngine, label: str):
        self.engine = engine
        self.label = label

    def __enter__(self):
        self.engine.events.put(GuiEvent("status_start", label=self.label))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.engine.events.put(GuiEvent("status_end"))
        return False

    async def __aenter__(self):
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return self.__exit__(exc_type, exc_val, exc_tb)


def _strip_rich_markup(text: str) -> str:
    """
    برچسب‌های سبکِ rich (مثلِ [bold cyan]...[/bold cyan]) را که در
    core.py برایِ ترمینال نوشته شده‌اند حذف می‌کند، چون در GUI با
    CSS/استایلِ Qt جایگزین می‌شوند، نه با این تگ‌ها.
    """
    return re.sub(r"\[/?[a-zA-Z0-9_ #]+\]", "", text)


# نگاشتِ کاراکترهایِ کادرکشیِ یونیکدِ rich (تمامِ سبک‌های box که در
# core.py استفاده شده: ROUNDED, DOUBLE_EDGE, HEAVY, و خطِ افقیِ Rule)
# به معادلِ ASCII. بدونِ این، این کاراکترها روی فونت‌هایی که پوششِ
# محدوده‌ی U+2500 تا U+257F را ندارند، به‌صورتِ جعبه‌هایِ خالی (تُهی)
# دیده می‌شوند — دقیقاً همان چیزی که در Pydroid3/اندروید مشاهده شد.
_BOX_DRAWING_TO_ASCII = str.maketrans({
    "╭": "+", "╮": "+", "╰": "+", "╯": "+",
    "┌": "+", "┐": "+", "└": "+", "┘": "+",
    "├": "+", "┤": "+", "┬": "+", "┴": "+", "┼": "+",
    "─": "-", "│": "|",
    "┏": "+", "┓": "+", "┗": "+", "┛": "+",
    "┣": "+", "┫": "+", "┳": "+", "┻": "+", "╋": "+",
    "━": "-", "┃": "|",
    "╔": "+", "╗": "+", "╚": "+", "╝": "+",
    "╠": "+", "╣": "+", "╦": "+", "╩": "+", "╬": "+",
    "═": "=", "║": "|",
    "‖": "|", "―": "-", "‐": "-",
})


def _ascii_box_drawing(text: str) -> str:
    return text.translate(_BOX_DRAWING_TO_ASCII)
