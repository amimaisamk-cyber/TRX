# -*- coding: utf-8 -*-
"""
موتورهای تفکیک‌شده‌ی هسته‌ی TRX AI.

``trx_ai/core.py`` دیگر یک فایلِ تک‌پارچه‌ی چندهزار خطی نیست؛ هر
مسئولیت به یک موتورِ مستقل در همین بسته منتقل شده و ``TRXEnterpriseAI``
فقط نقشِ «هماهنگ‌کننده» (composition root) را دارد -- نمونه‌ای از هر
موتور را می‌سازد و متدهایِ عمومیِ خودش را به آن‌ها می‌سپارد.

    text_extraction   -- توابعِ محضِ استخراجِ متن (بدونِ state)
    presentation      -- نمایشِ پاسخِ نهایی + پیشنهادِ صدا
    diagnostics       -- داشبورد/کنسولِ محرمانه/متریک/تاریخچه/HTML
    backup_manager    -- پشتیبان‌گیری/بازیابیِ کاملِ داده‌ها
    agent_bridge      -- اتصال به حلقه‌ی عاملِ خودمختار
    tool_router       -- مسیریابیِ نیت → ابزار + پاسخِ عمومیِ چهارلایه
    turn_processor    -- چرخه‌ی کاملِ یک نوبتِ گفتگو (متن/عکس/فایل)

هر موتور یک کلاس است که در سازنده‌اش نمونه‌ی ``TRXEnterpriseAI`` را
می‌گیرد (``ai``) و از attributeهای آن استفاده می‌کند؛ هیچ موتوری state
خصوصیِ غیرضروری نگه نمی‌دارد و هیچ‌کدام مستقیماً به هم وابسته نیستند --
همه از طریقِ همان یک شیءِ ``ai`` هماهنگ می‌شوند.
"""

from .agent_bridge import AgentBridge
from .backup_manager import BackupManager
from .diagnostics import DiagnosticsPanel
from .presentation import PresentationEngine
from .tool_router import ToolRouter
from .trace import TraceRecorder, TraceLog, TurnTrace
from .turn_processor import TurnProcessor
from . import text_extraction

__all__ = [
    "AgentBridge",
    "BackupManager",
    "DiagnosticsPanel",
    "PresentationEngine",
    "ToolRouter",
    "TraceRecorder",
    "TraceLog",
    "TurnTrace",
    "TurnProcessor",
    "text_extraction",
]
