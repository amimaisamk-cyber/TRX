# -*- coding: utf-8 -*-
"""
پلِ اتصال به حلقه‌ی عامل خودمختار (``trx_ai.agent``). مسئولیتِ این
ماژول: تشخیصِ اینکه آیا پیامِ کاربر باید به عاملِ چندابزاره سپرده شود
یا نه، ساختنِ رجیستریِ ابزارهایِ عامل (lazy)، و نمایشِ نتیجه‌ی نهاییِ
اجرایِ عامل. خودِ منطقِ تصمیم‌گیری/برنامه‌ریزی در ``trx_ai.agent``
پیاده‌سازی شده؛ این‌جا فقط نقطه‌ی اتصال (بریج) است.
"""

from __future__ import annotations

import time

from ..agent import AgentConfig, CognitionCore, StopReason, build_default_registry

__all__ = ["AgentBridge"]

# عمداً یک پیشوندِ صریح انتخاب شده (نه تشخیصِ خودکار از رویِ هر پیام)
# چون این حلقه ممکن است چند ابزار را زنجیره‌ای صدا بزند (کندتر/
# شبکه‌ای‌تر از یک پاسخِ معمولی) و کاربر باید صریحاً آن را بخواهد.
AGENT_PREFIXES = ("عامل:", "عامل :", "/agent ", "agent:")


class AgentBridge:
    """اتصالِ گفتگویِ معمولی به حلقه‌ی عاملِ چندابزاره."""

    def __init__(self, ai) -> None:
        self.ai = ai
        self._registry = None  # lazy، چون به ai.session نیاز دارد که دیرتر ساخته می‌شود.

    @staticmethod
    def extract_goal(user_input: str) -> str | None:
        """
        اگر پیام با یکی از پیشوندهای فعال‌سازیِ حلقه‌ی عامل شروع شده،
        متنِ هدف (بدونِ پیشوند) را برمی‌گرداند؛ وگرنه ``None``.
        """
        stripped = (user_input or "").strip()
        for prefix in AGENT_PREFIXES:
            if stripped.lower().startswith(prefix.lower()):
                goal = stripped[len(prefix):].strip()
                return goal or ""
        return None

    def get_registry(self):
        """رجیستریِ ابزارهایِ حلقه‌ی عامل را lazy می‌سازد (نیازمندِ ai.session)."""
        if self._registry is None:
            self._registry = build_default_registry(self.ai)
        return self._registry

    async def handle_task(self, goal: str) -> None:
        """
        اجرایِ کاملِ حلقه‌ی عامل برایِ یک هدفِ کاربر و نمایشِ نتیجه.

        این متد خودش هیچ منطقِ تصمیم‌گیری ندارد -- فقط ``CognitionCore`` را
        صدا می‌زند (که خودش Understanding/Reasoning/Planning را قبل از
        ``AgentLoop`` اجرا می‌کند) و trace را برایِ کاربر (و تاریخچه/
        حافظه‌ی معمولیِ برنامه، از طریقِ همان ``ai._finalize`` که بقیه‌ی
        مسیرها استفاده می‌کنند) قابلِ‌نمایش می‌کند.
        """
        ai = self.ai
        start_time = time.time()
        goal = (goal or "").strip()
        if not goal:
            await ai._present(
                "❓ بعدِ «عامل:» باید بگی هدفت چیه (مثلاً «عامل: جمعیتِ ایران رو پیدا کن و باهاش تقسیمِ ۱۰۰۰ رو حساب کن»).",
                "🤖 حلقه‌ی عامل",
                "yellow",
            )
            return

        # ارتقایِ Core (v25.4.0): تا این‌جا هدفِ عامل بدونِ هیچ حلِ ضمیری
        # به CognitionCore می‌رفت -- مسیرِ اصلیِ چت (``tool_router.py``)
        # از قبل ``ai.memory.resolve_pronoun`` را صدا می‌زد، اما حلقه‌ی
        # عامل این کار را هرگز نمی‌کرد؛ یعنی «عامل: قیمتش رو حساب کن»
        # بعدِ یک سؤالِ قبلی هیچ‌وقت به Entityِ درستِ ``entity_stack``
        # وصل نمی‌شد. اینجا همان تابعِ آزمایش‌شده‌ی موجود را (best-effort،
        # بدونِ تغییرِ منطقِ خودش) روی هدف هم اجرا می‌کنیم.
        resolved_goal = goal
        memory = getattr(ai, "memory", None)
        if memory is not None:
            try:
                resolved_goal, _ = memory.resolve_pronoun(goal)
            except Exception:  # noqa: BLE001
                resolved_goal = goal

        # همچنین موضوعِ فعال/تعدادِ نوبت‌ها/شمارشِ شکست‌هایِ اخیر --
        # که از قبل در ``ai.memory``/``ai.user_state_memory`` موجودند
        # (و در مسیرِ اصلیِ چت استفاده می‌شوند، بخشِ ``tool_router.py``
        # خطِ ۵۳۶) -- به ``CognitionCore`` داده می‌شوند تا Understanding/
        # Context واقعاً چیزی برایِ کار داشته باشند، نه همیشه صفر/خالی.
        topic = getattr(memory, "current_topic", None) if memory is not None else None
        short_term = getattr(memory, "short_term", None) if memory is not None else None
        turn_count = len(short_term) if short_term else 0
        previous_failures = 0
        user_state_memory = getattr(ai, "user_state_memory", None)
        if user_state_memory is not None:
            try:
                previous_failures = user_state_memory.recent_failures()
            except Exception:  # noqa: BLE001
                previous_failures = 0

        registry = self.get_registry()
        with ai.ui.console.status("[bold cyan]🤖 عامل در حالِ فکرکردن/برنامه‌ریزی/اجرایِ ابزارهاست...[/bold cyan]"):
            # از این‌جا به بعد کنترل به CognitionCore سپرده می‌شود (نه
            # مستقیماً AgentLoop): قبل از هر انتخابِ ابزار، اول Understanding
            # + Reasoning تصمیم می‌گیرند اصلاً ابزار (به‌خصوص Web) لازم است
            # یا نه -- طبقِ سندِ «Cognition Core Upgrade».
            trace = await CognitionCore(registry, AgentConfig(verbose=False)).run(
                resolved_goal,
                ai=ai,
                db=ai.db,
                topic=topic,
                turn_count=turn_count,
                previous_failures=previous_failures,
            )

        answer = trace.final_answer or "❌ عامل پاسخی برنگرداند."
        tool_summary = ", ".join(
            step.action.tool_name
            for step in trace.steps
            if step.action.tool_name
        ) or "—"
        footer = f"\n\n🧰 ابزارهایِ استفاده‌شده: {tool_summary} | توقف: {trace.stop_reason.value}"
        display_answer = answer + footer

        if trace.stop_reason == StopReason.NEEDS_USER_INPUT:
            ai.ui.show_followup_question(answer)
        else:
            style = "green" if trace.success else "yellow"
            await ai._present(display_answer, "🤖 نتیجه‌ی حلقه‌ی عامل", style)

        ai._finalize(f"[عامل] {goal}", answer, start_time, "agent_loop", 1.0 if trace.success else 0.4)
