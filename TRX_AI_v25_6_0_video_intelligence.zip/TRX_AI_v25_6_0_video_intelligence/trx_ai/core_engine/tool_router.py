# -*- coding: utf-8 -*-
"""
مسیریابِ ابزارها: قلبِ تصمیم‌گیریِ «برایِ این نیت، کدام موتور باید پاسخ
بدهد». ورودی همیشه یک (intent, confidence, original_text) از قبل
تشخیص‌داده‌شده است (کارِ ``trx_ai.intelligence.IntentEngine``)؛ خروجی،
اجرایِ همان ابزار و نمایشِ پاسخ (از طریقِ ``ai._present``) است.

این بزرگ‌ترین موتورِ تفکیک‌شده از ``core.py`` است چون خودِ مسیریابی
ذاتاً «هاب»ی است که تقریباً به همه‌چیز (حافظه، کش، دیتابیس، وب،
پزشکی، وظایف، خرج‌ها، ...) نیاز دارد. برایِ خواناتر ماندن، به دو
بخشِ داخلی تقسیم شده:
    ۱) شاخه‌های زودبازگشتِ پراولویت (کش/حافظه/پزشکی/همراهِ
       روان‌شناختی/تحلیلِ پروژه) -- هرکدام finalize و return خودشان
       را دارند.
    ۲) اجرایِ ابزارِ انتخاب‌شده توسطِ ``ToolScorer`` + پاسخِ عمومیِ
       چهارلایه (SmallTalk → ویکی‌پدیا → DuckDuckGo → محلی/همدلانه).
"""

from __future__ import annotations

import os
import random
import re
import time
from datetime import datetime

from ..intelligence import (
    AutonomousLearningEngine,
    JokeEngine,
    ReflectionEngine,
    SmallTalkEngine,
    ToolScorer,
)
from ..nlu import conversation_phase
from ..nlu import disambiguator
from ..nlu import user_state as user_state_engine
from .. import response_strategy
from ..health_utils import HealthCalculator, PasswordGenerator, UnitConverter
from ..logging_config import get_logger
from ..tools import (
    CalculatorEngine,
    CodeIntelligence,
    FileManager,
    LanguageEngine,  # noqa: F401 - نگه‌داشته‌شده برایِ سازگاریِ واردسازی با نسخه‌ی قبلی
    TranslatorEngine,
    WeatherEngine,
    WebSearchEngine,
)
from . import text_extraction
from ..conversation import state_tracker as conv_state_tracker
from ..trx_model import conversational_bridge

logger = get_logger(__name__)

__all__ = ["ToolRouter"]

# نیت‌هایی که هرگز نباید از کش پاسخ بگیرند: یا هر بار باید تازه محاسبه
# شوند (محاسبه‌گر/ساعت/ترجمه)، یا خودشان مسیرِ finalize/cache‌ِ
# اختصاصیِ خودشان را دارند (پزشکی/تحلیلِ پروژه/...).
# --- گیتِ ابهام (disambiguator.py) --------------------------------
# ``disambiguator.should_ask_followup`` فقط به *نسبتِ* فاصله‌ی امتیازِ
# نفرِ اول/دوم نگاه می‌کند -- یعنی حتی وقتی هر دو امتیاز ناچیز و
# نویزی‌اند (مثلاً ۰.۱ در برابرِ ۰.۰۹)، همان نسبتِ نزدیک باعثِ پرسیدنِ
# سؤال می‌شود. این آستانه‌ی مطلق، آن حالت را فیلتر می‌کند: فقط وقتی
# نامزدِ برنده حداقل به‌اندازه‌ی یک تطبیقِ کاملِ کلیدواژه (۱.۰) امتیاز
# دارد، سؤالِ ابهام پرسیده می‌شود -- تا رفتارِ over-triggering (که خودِ
# سندِ ممیزی صراحتاً از آن پرهیز خواسته) رخ ندهد.
MIN_AMBIGUITY_SCORE = 1.0
# اگر IntentEngine خودش از قبل به نیتِ اصلی مطمئن است (مثلاً پیامی که
# هم‌زمان به‌طورِ ضعیف یک ابزارِ دیگر را هم لمس می‌کند)، سؤالِ ابهام
# پرسیده نمی‌شود -- این آستانه مانعِ مزاحمت برای مواردی می‌شود که خودِ
# لایه‌ی بالاترِ تشخیصِ نیت هیچ تردیدی نداشته.
MAX_INTENT_CONFIDENCE_FOR_AMBIGUITY = 0.85
# نیت‌هایی که پیش از رسیدن به این بخش، خودشان مسیرِ اختصاصی/امن دارند
# (پزشکی/همراهِ روان‌شناختی/تحلیلِ پروژه با return زودهنگام در بالا)
# اینجا نیستند -- این فهرست برایِ نیت‌هایی‌ست که با اینکه به این بخش
# می‌رسند، پرسیدنِ سؤالِ ابهام برایشان بی‌معنا یا مزاحم است.
# نیت‌هایِ خروجیِ AMS (Ambiguity Management System -- بخشِ ۵۲ به بعدِ سندِ
# AMBIGUITY_MANAGEMENT_COMPLETE_SPEC) هم مثلِ emotional_support/medical/
# project_analysis، خودشان قبلاً یک تصمیمِ آگاه از context گرفته‌اند --
# پرسیدنِ سؤالِ ابهامِ *دوباره* روی آن‌ها بی‌معنا و مزاحم است.
AMS_INTENTS = frozenset({
    "conversation_follow_up", "conversation_repair", "conversation_correction",
    "conversation_topic_transition", "conversation_entity_clarification",
})

AMBIGUITY_EXEMPT_INTENTS = frozenset({"medical", "emotional_support", "project_analysis"}) | AMS_INTENTS

# v25.5.8: وقتی NLUِ بیرونی نیتِ emotional_support را (احتمالاً از رویِ
# شباهتِ معنایی، نه کلیدواژه‌ی تحت‌اللفظی) تشخیص داده، اما خودِ موتورِ
# پزشکی/همراهِ روان‌شناختی با آن موافق نبوده (به health_advice سقوط
# کرده -- نگاه کنید به ``handle_medical_query_online`` در
# ``trx_ai/medical/online.py``)، یعنی این واقعاً یک نوبتِ همراهی نبود.
# به‌جایِ نمایشِ پاسخِ ثابتِ سلامت زیرِ برچسبِ همدلانه (که هم گمراه‌کننده
# است، هم -- طبقِ گزارشِ واقعیِ امیر -- کاربر را کلافه می‌کند)، یکی از
# این پاسخ‌هایِ کوتاه و خنثی نشان داده می‌شود (Generic/Repetition Guard،
# هم‌الگو با AMS بالا). نگاه کنید به
# audit/EMOTIONAL_SUPPORT_MISROUTE_v25_5_8.md.
_EMOTIONAL_SUPPORT_FALLTHROUGH_REPLIES = (
    "باشه -- اگه چیزِ خاصی هست بگو، وگرنه هر وقت خواستی ادامه بده.",
    "دریافت شد. کاری هست که بتونم کمک کنم؟",
    "اوکی. اگه سؤال یا کاری داری، در خدمتم.",
)

SKIP_CACHE_INTENTS = frozenset({
    "calculator", "code_analyzer", "translator", "profile_update",
    "self_learning", "system_time", "persian_interpreter", "memory_save",
    "personality_change", "memory_query", "dictionary", "medical", "currency",
    "project_analysis", "joke", "emotional_support",
    # موتورِ ویدیو/صحنه: هر صحنه بر اساسِ نشستِ فعلی و صحنه‌ی قبلیِ همان
    # نشست ساخته می‌شود (session-dependent)، پس کش‌کردنِ پاسخ بر اساسِ
    # فقط متنِ پیام غلط است -- دو کاربرِ متفاوت با همان جمله باید صحنه‌ی
    # متفاوت بگیرند (نگاه کنید به video/session_manager.py).
    "video_generation", "video_edit_scene", "video_help",
}) | AMS_INTENTS


class ToolRouter:
    """اجرای مسیرِ درست برایِ یک نیتِ از‌قبل‌تشخیص‌داده‌شده."""

    def __init__(self, ai) -> None:
        self.ai = ai

    async def execute(self, intent: str, confidence: float, original_text: str) -> None:
        ai = self.ai
        start_time = time.time()
        answer = ""
        source = "سیستم جامع"
        emoji, prefix, style = ai._get_personality_prefix()
        ai.stats["total_requests"] += 1

        if intent == "neural_draft":
            try:
                from ..phase3.shadow import get_controlled_runner
                conversation_id = getattr(ai.session_mgr, "active_session", None) or "default"
                draft = get_controlled_runner().consume(conversation_id)
                if draft is not None and draft.text:
                    answer = draft.text
                    if ai.current_trace is not None:
                        ai.current_trace.mark(selected_route="phase3:controlled_neural_draft",
                                              detected_intent="neural_draft", confidence=draft.confidence,
                                              context_used=True, neural_model_version=draft.model_version,
                                              neural_latency_ms=draft.latency_ms)
                    await ai._present(answer, "🧠 پاسخ عصبی کنترل‌شده", style)
                    ai._finalize(original_text, answer, start_time, "general", draft.confidence)
                    return
            except Exception as exc:
                logger.debug("Controlled neural draft unavailable: %s", exc)
            intent = "general"

        # --- ارجاع هوشمند ضمایر ---
        resolved_text, ref_entity = ai.memory.resolve_pronoun(original_text)
        if ref_entity and resolved_text != original_text:
            ai.ui.console.print(
                f"[bold dim]🔗 ارجاع: '{original_text}' → درباره '{ref_entity}'[/bold dim]"
            )

        # --- کش ---
        if intent not in SKIP_CACHE_INTENTS:
            cached = ai.cache.get(resolved_text, intent)
            if cached:
                ai.stats["cache_hits"] += 1
                ai.ui.console.print("[bold dim]⚡ از کش بارگذاری شد.[/bold dim]")
                await ai._present(cached, f"{emoji} پاسخ (کش) | منبع: Cache", style)
                # نکته‌ی observability: مسیرِ کش عمداً finalize نمی‌شود (تا
                # پیام و پاسخ دوباره وارد تاریخچه/حافظه نشوند) -- اما برایِ
                # اینکه دستورِ «ردیابی» این نوبت را «غیب» نشان ندهد، خودِ
                # trace اینجا مستقیماً بسته و ثبت می‌شود.
                trace = getattr(ai, "current_trace", None)
                if trace is not None:
                    trace.mark(
                        detected_intent=intent, confidence=confidence,
                        selected_route="cache_hit", fallback_used=False,
                        final_response=cached[:300],
                    )
                    ai.trace_log.push(trace.finish())
                    ai.current_trace = None
                return

        # --- جستجوی حافظه معنایی ---
        if intent in ("general", "web_search"):
            memory_result = await ai._search_memory(resolved_text)
            if memory_result:
                answer = memory_result
                await ai._present(answer, f"{emoji} بازیابی از حافظه", "bright_blue")
                ai.cache.set(resolved_text, answer, intent)
                if ai.current_trace is not None:
                    ai.current_trace.mark(selected_route="semantic_memory_hit", context_used=True, memory_hits=1)
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

        # --- دانش آفلاین ---
        if intent not in SKIP_CACHE_INTENTS:
            offline_res = ai.db.search_knowledge(resolved_text)
            if offline_res:
                answer = f"🧱 [حافظه آفلاین]:\n\n{offline_res}"
                await ai._present(answer, f"{emoji} بازیابی از حافظه", "bright_blue")
                ai.cache.set(resolved_text, answer, intent)
                if ai.current_trace is not None:
                    ai.current_trace.mark(selected_route="offline_knowledge_hit", context_used=True, memory_hits=1)
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

        # ==========================================
        #   مسیریابی پزشکی (اولویت بالا)
        # ------------------------------------------
        # باگ نسخه‌ی قبلی: شرط «یا شخصیت == دکتر کامل» باعث می‌شد وقتی
        # شخصیت روی «دکتر کامل» بود، مطلقاً هر پیامی (even «۲+۲ چند میشه»
        # یا «ترجمه کن») به‌زور به موتور پزشکی فرستاده شود. حالا مسیریابی
        # فقط بر اساس نیتِ واقعیِ تشخیص‌داده‌شده انجام می‌شود؛ شخصیتِ «دکتر
        # کامل» فقط لحن/فرمت پاسخِ پزشکی را عوض می‌کند، نه مسیر آن را.
        # ==========================================
        if intent == "medical":
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="medical_query", tool_execution="MedicalAIEngine")
            result = await ai._handle_medical_query(resolved_text)
            answer = result["message"]
            if result.get("emergency"):
                # پاسخ فوریتی: به‌جای پنل معمولی، با قابِ اورژانسیِ متمایز
                # نمایش داده می‌شود تا در نگاه اول از بقیه‌ی خروجی جدا باشد.
                ai.ui.show_emergency(answer)
            elif not result.get("done", True):
                # سؤال پیگیریِ بله/خیر: پاسخ بعدیِ کاربر (در ابتدای حلقه‌ی
                # اصلی) مستقیماً به گفتگوی پزشکی هدایت می‌شود، نه به
                # مسیریابیِ عادیِ نیت.
                ai.ui.show_followup_question(answer)
            else:
                await ai._present(answer, "🏥 پاسخ پزشکی | منبع: Medical AI", "bright_red")
            if result.get("done", True):
                ai.cache.set(resolved_text, answer, "medical")
                ai._finalize(original_text, answer, start_time, intent, confidence)
            return

        # ==========================================
        #   همراهِ روان‌شناختی (اولین ورود به جلسه)
        # ------------------------------------------
        # مسیرِ *ادامه‌ی* جلسه (پیام‌هایِ بعدیِ همان گفتگو، حتی بدونِ
        # کلیدواژه‌ی احساسی) در turn_processor مدیریت می‌شود، نه اینجا.
        # این شاخه فقط اولین پیامی را می‌گیرد که NLU با کلیدواژه‌های
        # emotional_support تشخیص داده. هر دو مسیر نهایتاً به همان
        # engine.therapy.respond می‌رسند (از طریقِ handle_medical_query_online)
        # تا منطق در یک‌جا (medical/therapy/engine.py) بماند، نه تکراری.
        #
        # v25.5.8: این کامنت فرض می‌کرد "NLU با کلیدواژه‌های emotional_support
        # تشخیص داده" یعنی همان کلیدواژه‌هایی که موتورِ پزشکی هم داخلش چک
        # می‌کند -- اما IntentSpecِ این نیت (trx_ai/nlu/intents/psychology.py)
        # semantic_enabled=True دارد؛ یعنی NLUِ بیرونی می‌تواند این نیت را
        # صرفاً از رویِ شباهتِ معنایی هم تشخیص بدهد، حتی وقتی هیچ‌کدام از
        # EMOTIONAL_SUPPORT_KEYWORDSِ تحت‌اللفظی در متن نیست. در آن حالت،
        # handle_medical_query_online (که فقط کلیدواژه‌ای چک می‌کند) به
        # پاسخِ عمومیِ health_advice سقوط می‌کند -- یک متنِ ثابتِ «تغذیه/
        # خواب/ورزش» که به‌عنوانِ «💙 Therapy Companion» نمایش دادنش هم
        # گمراه‌کننده است و هم (طبقِ گزارشِ واقعیِ امیر) کاربر را کلافه
        # می‌کند. نگاه کنید به audit/EMOTIONAL_SUPPORT_MISROUTE_v25_5_8.md.
        # ==========================================
        if intent == "emotional_support":
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="emotional_support_entry", tool_execution="TherapyCompanion")
            result = await ai._handle_medical_query(resolved_text)
            answer = result["message"]
            if result.get("emergency"):
                ai.ui.show_emergency(answer)
            elif result.get("source") != "therapy":
                # موتورِ پزشکی خودش موافقتِ NLUِ بیرونی را تأیید نکرد (به
                # health_advice سقوط کرد) -- یعنی این واقعاً یک نوبتِ
                # همراهیِ روان‌شناختی نبود. به‌جایِ نمایشِ پاسخِ پزشکیِ ثابت
                # زیرِ برچسبِ همدلانه، یک پاسخِ کوتاه و صادقِ محاوره‌ای (نه
                # پزشکی، نه ادعایِ فهمِ احساسی) نشان می‌دهیم -- هم‌الگو با
                # Generic/Repetition Guardِ همین فایل برایِ AMS.
                answer = random.choice(_EMOTIONAL_SUPPORT_FALLTHROUGH_REPLIES)
                await ai._present(answer, "💬 مکالمه", "cyan")
            else:
                await ai._present(answer, "💙 همراه شما | Therapy Companion", "bright_magenta")
            ai._finalize(original_text, answer, start_time, intent, confidence)
            return

        # ==========================================
        #   تحلیل پروژه («تحلیل پروژه [مسیر]»)
        # ------------------------------------------
        # این دستور در راهنمای سیستم (show_guide) از ابتدا تبلیغ شده بود،
        # اما هیچ نیتی به آن نگاشت نمی‌شد و در نتیجه با هر عبارتی که
        # تایپ می‌شد فقط به پاسخ عمومی می‌رسید — یعنی یک قابلیتِ کاملاً
        # مرده. اکنون مسیر آن به CodeIntelligence.analyze_project وصل شده.
        # ==========================================
        if intent == "project_analysis":
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="project_analysis", tool_execution="CodeIntelligence.analyze_project")
            path_match = re.search(r'پروژه\s+([^\s].*)$', resolved_text.strip())
            target_path = path_match.group(1).strip() if path_match else "."
            if not os.path.exists(target_path):
                answer = (f"❌ مسیر «{target_path}» پیدا نشد.\n"
                          f"مثال درست: تحلیل پروژه ./trx_ai یا تحلیل پروژه .")
            else:
                with ai.ui.console.status("[bold magenta]📊 در حال تحلیل پروژه...[/bold magenta]"):
                    answer = CodeIntelligence.analyze_project(target_path)
            await ai._present(answer, "📊 تحلیل پروژه", "magenta")
            ai.cache.set(resolved_text, answer, "project_analysis")
            ai._finalize(original_text, answer, start_time, intent, confidence)
            return

        # ==========================================
        #   خروجی‌هایِ AMS -- Ambiguity Management System
        # ------------------------------------------
        # طبقِ سندِ AMBIGUITY_MANAGEMENT_COMPLETE_SPEC (بخش‌هایِ ۵۲ تا ۷۹):
        # این پنج نیت هرگز از IntentEngineِ قدیمی نمی‌آیند -- فقط از
        # ``trx_ai/conversation/ambiguity_manager.py`` (از طریقِ
        # ``conversation_engine.process`` -> ``intent_arbitrator``)
        # ساخته می‌شوند، وقتی پیام کوتاه/مبهم/وابسته‌به‌context یا یک
        # شکایت/تصحیحِ مستقیم به خودِ TRX تشخیص داده شود. AMS خودش هیچ
        # پاسخی نساخته (فقط تصمیم گرفته)؛ متنِ واقعی اینجا -- دقیقاً هم‌
        # الگویِ SmallTalkEngine (چند نسخه‌ی متفاوت، نه یک جمله‌ی ثابت،
        # طبقِ اصلِ ۲۶ سند «Generic/Repetition Guard») -- ساخته می‌شود.
        # ==========================================
        if intent in AMS_INTENTS:
            conversation_id = getattr(ai.session_mgr, "active_session", None) or "default"
            snap = conv_state_tracker.get_snapshot(conversation_id)
            topic = snap.active_topic

            if intent == "conversation_follow_up":
                if confidence >= 0.85:
                    # Context Resolution موفق شد -- مرجع/دنباله‌بودنِ پیام
                    # فهمیده شده؛ به‌جایِ حدسِ محتوا (که AMS قاعده‌محور
                    # است، نه یک مدلِ مولد)، صادقانه از خودِ کاربر ادامه
                    # می‌خواهد -- نه یک fallback ربات‌وار.
                    if topic:
                        pool = [
                            f"درباره‌ی «{topic}» داشتیم صحبت می‌کردیم -- دقیق‌تر بگو چی می‌خوای بدونی؟",
                            f"منظورت درباره‌ی «{topic}» بود، درسته؟ بیشتر توضیح بده تا کمک کنم.",
                            f"باشه، همون بحثِ «{topic}» -- ادامه بده، گوش می‌دم.",
                        ]
                    else:
                        pool = ["ادامه می‌دم -- فقط بگو دقیقاً کدوم بخشش رو می‌خوای بیشتر باز کنم."]
                    answer = random.choice(pool)
                elif confidence >= 0.65:
                    # اولین‌بارِ درخواستِ توضیحِ بیشتر (Minimal Clarification).
                    answer = "دقیق نگرفتم منظورت رو -- می‌شه یه‌کم بیشتر توضیح بدی؟"
                else:
                    # بودجه‌ی سؤالِ ابهام تمام شده (A20 سند: از چرخه‌یِ
                    # بی‌نهایتِ سؤال جلوگیری کن) -- دیگر سؤال تکرار نشود.
                    answer = random.choice([
                        "باشه، هروقت خواستی دقیق‌تر بگو، همینجام.",
                        "اوکی، هر وقت آماده بودی ادامه بده.",
                    ])
                await ai._present(answer, "💬 مکالمه", "cyan")
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

            if intent == "conversation_repair":
                # چهار گامِ بخشِ ۲۲ سند: پذیرشِ خطا -> بازسازیِ فهم ->
                # درخواستِ تأیید -- بدونِ دفاعی‌شدن یا تکرارِ عذرخواهیِ
                # اضافه (که خودش می‌تواند آزاردهنده باشد).
                pool = [
                    "متوجه شدم اذیت شدی. بگو دقیقاً کجا گیر کردم تا اصلاح کنم.",
                    "حق داری ناراحت باشی -- بذار دوباره درست متوجه بشم: دقیقاً دنبالِ چی بودی؟",
                    "باشه، از اول: بگو چی می‌خوای تا این‌بار درست جواب بدم.",
                ]
                answer = random.choice(pool)
                await ai._present(answer, "💬 مکالمه", "cyan")
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

            if intent == "conversation_correction":
                pool = [
                    "باشه، فهمیدم -- منظورت اون نبود. ادامه بده، گوش می‌دم.",
                    "اوکی، متوجه شدم تصحیح کردی. از همینجا ادامه بده.",
                    "باشه، همون رو در نظر می‌گیرم. بگو دقیقاً چی؟",
                ]
                answer = random.choice(pool)
                await ai._present(answer, "💬 مکالمه", "cyan")
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

            if intent == "conversation_topic_transition":
                pool = [
                    "باشه، ولش می‌کنیم. چیزِ دیگه‌ای هست کمکت کنم؟",
                    "اوکی، بی‌خیالش. سراغِ چی بریم؟",
                    "باشه، این بحث رو می‌بندیم. چی تو ذهنته؟",
                ]
                answer = random.choice(pool)
                await ai._present(answer, "💬 مکالمه", "cyan")
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

            if intent == "conversation_entity_clarification":
                # A12 سند: فرمانِ صریحِ ابزار (سرچ) با موضوعی که فقط یک
                # ضمیرِ حل‌نشده است -- عمداً *اجرا نمی‌شود*؛ اول موضوع
                # دقیق پرسیده می‌شود.
                answer = "منظورت چیه که برات سرچ کنم؟ اسمش رو دقیق بگو تا جستجو کنم."
                await ai._present(answer, "💬 مکالمه", "cyan")
                ai._finalize(original_text, answer, start_time, intent, confidence)
                return

        # --- مسیریابی ابزارها با امتیازدهی ---
        # context اکنون واقعاً چیزی حمل می‌کند: شمارش استفاده‌ی اخیر از
        # هر ابزار در همین نشست. نسخه‌ی قبلی همیشه context=None می‌فرستاد،
        # پس شاخه‌ی «امتیاز از Context» در ToolScorer عملاً کد مرده بود.
        tool_name, tool_scores, tool_confidence = ToolScorer.score_tools(
            resolved_text, intent, confidence, context=ai.tool_usage_history
        )
        if ai.current_trace is not None:
            ai.current_trace.mark(selected_route=f"tool_router:{tool_name}", tool_execution=tool_name)

        # ==========================================
        #   گیتِ ابهام -- «بپرس، حدس نزن»
        # ------------------------------------------
        # ``nlu/disambiguator.py`` از قبل در پروژه وجود داشت (منطقِ
        # ``should_ask_followup``/``build_followup_question``) اما طبقِ
        # کامنتِ خودِ آن فایل، به هیچ UI/core.py وصل نبود -- یک قابلیتِ
        # کاملاً تعریف‌شده اما disconnected (دقیقاً دسته‌ی «Defined but
        # Disconnected» سندِ ممیزی). اینجا برایِ اولین‌بار واقعاً به
        # مسیرِ اجرای اصلی وصل می‌شود: وقتی دو ابزارِ نامزد امتیازِ
        # نزدیکی دارند و IntentEngine هم به نیتِ اصلی خیلی مطمئن نیست،
        # به‌جایِ اجرایِ حدسیِ یکی از آن‌ها، یک سؤالِ کوتاه پرسیده
        # می‌شود و اجرای واقعی تا پاسخِ کاربر (در turn_processor.py)
        # به تعویق می‌افتد.
        # ==========================================
        ranked_scores = sorted(tool_scores.items(), key=lambda kv: kv[1], reverse=True)
        if (
            intent not in AMBIGUITY_EXEMPT_INTENTS
            and confidence < MAX_INTENT_CONFIDENCE_FOR_AMBIGUITY
            and ranked_scores
            and ranked_scores[0][1] >= MIN_AMBIGUITY_SCORE
            and disambiguator.should_ask_followup(ranked_scores)
        ):
            top_two = (ranked_scores[0][0], ranked_scores[1][0])
            question = disambiguator.build_followup_question(top_two)
            ai._pending_disambiguation = {
                "original_text": original_text,
                "resolved_text": resolved_text,
                "top_two": top_two,
            }
            await ai._present(question, f"{emoji} یه سؤال کوچیک", "cyan")
            if ai.current_trace is not None:
                ai.current_trace.mark(
                    selected_route="ambiguity_clarification",
                    fallback_used=True,
                    final_response=question[:300],
                )
                ai.trace_log.push(ai.current_trace.finish())
                ai.current_trace = None
            return

        # نمایش امتیاز ابزارها (در صورت درخواست)
        if ai.personality in ("فنی", "تحقیق‌کننده"):
            score_display = " | ".join([f"{k}:{v:.0f}" for k, v in tool_scores.items() if v > 0][:5])
            ai.ui.console.print(f"[dim]🔧 امتیاز ابزارها: {score_display}[/dim]")
            ai.ui.console.print(f"[dim]✅ انتخاب: {tool_name} (اطمینان: {tool_confidence:.0%})[/dim]")

        # --- اجرای ابزار انتخاب‌شده ---
        if tool_name == "calculator" or intent == "calculator":
            answer = CalculatorEngine.safe_eval(resolved_text, ai.ui.e2f)
            await ai._present(answer, "🧮 محاسبات", "orange1")

        elif tool_name == "code_analyzer" or intent == "code_analyzer":
            with ai.ui.console.status("[bold magenta]⚙️ در حال تحلیل کد...[/bold magenta]"):
                answer = CodeIntelligence.analyze_and_fix(resolved_text)
            await ai._present(answer, "🛠️ آنالیز کد", "magenta")

        elif tool_name == "translator" or intent in ("translator", "translator_auto"):
            mode = "auto" if intent == "translator_auto" else ai.translation_direction
            clean = re.sub(r'ترجمه.*?:', '', resolved_text).strip() or resolved_text
            with ai.ui.console.status("[bold cyan]🔄 در حال ترجمه...[/bold cyan]"):
                answer = await TranslatorEngine.get_translation(ai.session, clean, mode)
            source = "سرویس ترجمه"
            await ai._present(answer, "🔀 ترجمه", "cyan")

        elif tool_name == "dictionary" or intent == "dictionary":
            with ai.ui.console.status("[bold yellow]📖 جستجو در لغت‌نامه...[/bold yellow]"):
                answer = await WebSearchEngine.get_vajehyab(ai.session, resolved_text)
            source = "واژه‌یاب"
            await ai._present(answer, "📖 معنی واژه", "yellow")

        elif tool_name == "web_search" or intent == "web_search":
            clean_query = text_extraction.extract_search_subject(resolved_text)
            with ai.ui.console.status("[bold yellow]🔍 جستجو در ویکی‌پدیا...[/bold yellow]"):
                wiki_res = await WebSearchEngine.get_wikipedia(ai.session, clean_query)

            if wiki_res and not wiki_res.startswith(("📡", "🌐")):
                answer = f"📚 ویکی‌پدیا:\n\n{wiki_res}"
                source = "ویکی‌پدیا"
                AutonomousLearningEngine.extract_and_store_knowledge(clean_query, wiki_res, ai.db)
                ai.memory.save_fact(f"{clean_query}: {wiki_res[:100]}")
            elif wiki_res and wiki_res.startswith(("📡", "🌐")):
                answer = wiki_res
            else:
                with ai.ui.console.status("[bold yellow]🔍 DuckDuckGo...[/bold yellow]"):
                    web_res = await WebSearchEngine.search_duckduckgo(ai.session, clean_query)
                if web_res:
                    answer = web_res
                    source = "جستجوی وب"
                    AutonomousLearningEngine.extract_and_store_knowledge(clean_query, web_res, ai.db)
                else:
                    answer = "🤖 در این لحظه به وب دسترسی ندارم. اتصال اینترنت را بررسی کنید."
                    source = "سیستم داخلی"
            await ai._present(answer, f"{emoji} پاسخ | منبع: {source}", style)

        elif tool_name == "file_reader":
            file_match = re.search(r'بخوان\s+(.+)', resolved_text)
            if file_match:
                filepath = file_match.group(1).strip()
                answer = FileManager.read_file(filepath)
            else:
                answer = "❌ لطفاً نام فایل را مشخص کنید. مثال: بخوان myfile.pdf"
            await ai._present(answer, "📂 مدیریت فایل", "cyan")

        elif tool_name == "video_generation" or intent in ("video_generation", "video_edit_scene", "video_help"):
            # موتورِ ویدیو/صحنه (trx_ai/video/) -- طبقِ سندِ طراحیِ
            # ``TRX_HTML_Video_Engine_Upgrade_Design``، بخشِ ۲۲: این‌جا فقط
            # مسیریابی می‌شود؛ هیچ جزئیاتِ HTML/CSS/JS/Scene Specification
            # در tool_router دیده نمی‌شود -- همه‌چیز در video/runtime_manager
            # است. importِ محلی (مثلِ الگویِ neural_draft در بالا) تا
            # بارگذاریِ این زیرسیستمِ تازه هیچ ریسکِ import چرخه‌ای برایِ
            # کلِ core در startup ایجاد نکند.
            try:
                from ..video import runtime_manager as video_runtime
                from ..config import OS_FILES_DIR
                session_id = getattr(ai.session_mgr, "active_session", None) or "default"
                result = video_runtime.handle_video_request(session_id, intent, resolved_text)
            except Exception as exc:  # noqa: BLE001 -- شکستِ این زیرسیستمِ تازه نباید کلِ پاسخ‌گویی را بخواباند
                logger.exception("خطای غیرمنتظره در موتورِ ویدیو")
                result = {"status": "error", "message": str(exc)}

            if result.get("status") == "success":
                diag = result.get("diagnostics", {})
                if result.get("mode") == "patch" and result.get("applied_patch"):
                    answer = f"🎬 انجام شد: {result['applied_patch']}."
                elif result.get("mode") in ("patch", "rebuild_same_id"):
                    answer = "🎬 صحنه به‌روزرسانی شد."
                else:
                    answer = (
                        f"🎬 صحنه ساخته شد ({diag.get('environment', '؟')} / "
                        f"{result.get('duration', '؟')} ثانیه / کیفیتِ {diag.get('quality', '؟')}).\n"
                        "برای اصلاح می‌توانید مثلاً بگویید «دوربین رو نزدیک‌تر کن» یا «نور رو کم کن»."
                    )
                if result.get("user_summary"):
                    answer += "\n" + result["user_summary"]
                if diag.get("validation") == "fallback_used":
                    answer += "\n⚠️ ساختِ نسخه‌ی کامل ممکن نشد؛ یک نسخه‌ی ساده‌ی جایگزین نمایش داده می‌شود."
                try:
                    rel_path = os.path.relpath(result["html_path"], OS_FILES_DIR).replace(os.sep, "/")
                    scene_url = f"/files/{rel_path}"
                    ai.ui.show_scene(
                        scene_url, scene_id=result["scene_id"],
                        title="🎬 TRX Video Scene", duration=result.get("duration", 0),
                    )
                except Exception:
                    logger.exception("نمایشِ صحنه در UI شکست خورد (خودِ ساختِ صحنه موفق بود)")
            elif result.get("status") in ("needs_clarification", "help"):
                answer = result.get("message", "برای ساختِ صحنه، لطفاً دقیق‌تر بگویید چه می‌خواهید.")
            else:
                answer = ("❌ در ساختِ صحنه مشکلی پیش آمد. می‌توانید دوباره و با توضیحِ ساده‌تر امتحان کنید.\n"
                          f"(جزئیاتِ فنی: {result.get('message', 'نامشخص')})")
            await ai._present(answer, "🎬 موتورِ ویدیو (Beta)", "magenta")

        elif intent == "persian_interpreter":
            await ai._run_persian_interpreter_mode()
            return

        elif intent == "weather":
            city = text_extraction.extract_city_name(resolved_text)
            with ai.ui.console.status("[bold cyan]🌤️ دریافت اطلاعات آب و هوا...[/bold cyan]"):
                answer = await WeatherEngine.get_weather(ai.session, city)
            await ai._present(answer, "🌦️ آب و هوا", "cyan")

        elif intent == "currency":
            # قبلاً این نیت تشخیص داده می‌شد اما هیچ مسیر اجرایی نداشت و
            # به پاسخ عمومی بی‌ربط سقوط می‌کرد. wttr.in نرخ ارز نمی‌دهد؛
            # ساده‌ترین راه بدون افزودن سرویس جدید، جستجوی وب برای نرخ لحظه‌ای است.
            with ai.ui.console.status("[bold yellow]💰 در حال دریافت نرخ ارز...[/bold yellow]"):
                web_res = await WebSearchEngine.search_duckduckgo(ai.session, resolved_text)
            answer = web_res or "🤖 در این لحظه به اطلاعات نرخ ارز دسترسی ندارم. اتصال اینترنت را بررسی کنید."
            source = "جستجوی وب"
            await ai._present(answer, "💰 نرخ ارز", "green")

        elif intent == "memory_query":
            memory_result = await ai._search_memory(resolved_text)
            answer = memory_result or "🤔 چیزی در حافظه پیدا نکردم. می‌توانید دقیق‌تر بپرسید یا از «یاد بگیر: ...» استفاده کنید."
            await ai._present(answer, "🧠 جستجوی حافظه", "bright_blue")

        elif intent == "profile_query":
            answer = f"👤 نام شما: '{ai.user_name}'"
            await ai._present(answer, "👤 پروفایل", "bright_blue")

        elif intent == "profile_update":
            new_name = resolved_text.replace("نام من", "").replace("اسم من", "").strip()
            if new_name:
                ai.db.set_profile("user_name", new_name)
                ai.user_name = new_name
                answer = f"✅ نام به '{new_name}' تغییر یافت."
            else:
                answer = "❌ فرمت اشتباه. مثال: نام من علی"
            await ai._present(answer, "👤 به‌روزرسانی نام", "bright_blue")

        elif intent == "system_time":
            f_date, f_time = ai.ui.get_farsi_date_time()
            answer = f"🕒 ساعت: {f_time} | تاریخ: {f_date}"
            await ai._present(answer, "🕒 ساعت سیستم", "bright_blue")

        elif intent == "joke":
            answer = JokeEngine.get_random_joke(exclude=ai._last_joke)
            ai._last_joke = answer
            await ai._present(f"😄 {answer}", "😄 یه جوک", "bright_yellow")

        elif intent == "task_add":
            result = ai.task_manager.add_from_text(resolved_text, project=ai.session_mgr.active_session)
            due_str = f"\n⏰ سررسید: {result['due_at'].strftime('%Y-%m-%d %H:%M')}" if result["due_at"] else ""
            answer = f"✅ کار ثبت شد: «{result['title']}» (#{result['id']}){due_str}"
            await ai._present(answer, "📋 کارِ جدید", "green")

        elif intent == "task_list":
            answer = ai.task_manager.format_task_list(project=ai.session_mgr.active_session)
            await ai._present(answer, "📋 کارهای من", "cyan")

        elif intent == "task_done":
            task_id = ai.task_manager.extract_task_id(resolved_text)
            answer = ai.task_manager.complete_by_id(task_id) if task_id else "❌ شماره‌ی کار مشخص نشد."
            await ai._present(answer, "📋 انجام‌شد", "green")

        elif intent == "task_delete":
            task_id = ai.task_manager.extract_task_id(resolved_text)
            answer = ai.task_manager.delete_by_id(task_id) if task_id else "❌ شماره‌ی کار مشخص نشد."
            await ai._present(answer, "📋 حذفِ کار", "red")

        elif intent == "unit_convert":
            answer = UnitConverter.convert_from_text(resolved_text)
            await ai._present(answer, "📏 تبدیلِ واحد", "cyan")

        elif intent == "password_gen":
            answer = PasswordGenerator.generate_from_text(resolved_text)
            await ai._present(answer, "🔐 رمزِ عبور", "magenta")

        elif intent == "bmi":
            answer = HealthCalculator.calculate_from_text(resolved_text)
            await ai._present(answer, "⚖️ محاسبه‌ی BMI", "bright_red")

        elif intent == "expense_add":
            result = ai.expense_manager.add_from_text(resolved_text, project=ai.session_mgr.active_session)
            if result["amount"] is None:
                answer = "❌ مبلغ را متوجه نشدم. مثال: «خرج کردم ۵۰ هزار تومان برای نهار»"
            else:
                answer = f"✅ خرج ثبت شد: {result['amount']:,.0f} تومان | دسته: {result['category']} | {result['note']}"
            await ai._present(answer, "💰 خرجِ جدید", "yellow")

        elif intent == "expense_summary":
            answer = ai.expense_manager.format_summary(project=ai.session_mgr.active_session)
            await ai._present(answer, "💰 خلاصه‌ی خرج‌ها", "yellow")

        elif intent == "backup_data":
            answer = ai._create_backup()
            await ai._present(answer, "🗄️ پشتیبان‌گیری", "green")

        elif intent == "restore_data":
            answer = ai._prompt_restore_confirmation()
            await ai._present(answer, "🗄️ بازیابی", "green")

        elif intent == "mood_report":
            # موتورِ جدید: گزارشِ درصدیِ حال‌وهوایِ گفتگو (پرسش/جواب،
            # درد دل، جشن/خوشحالی و ترکیبِ احساسات) روی پیام‌هایِ اخیرِ
            # کاربر که از قبل توسطِ ConversationPatternEngine ذخیره شده‌اند.
            answer = ai.conversation_patterns.format_mood_report()
            await ai._present(answer, "📊 تحلیلِ احساسیِ گفتگو", "magenta")

        elif intent == "self_learning":
            content = re.sub(r'^\s*(یاد\s*بگیر|یادت\s*باشه|به\s*خاطر\s*بسپار)\s*[:：]?\s*', '',
                              resolved_text, flags=re.IGNORECASE).strip()
            if "=" in content:
                k, v = content.split("=", 1)
                k, v = k.strip(), v.strip()
                if k and v:
                    ai.db.add_knowledge(k, v, confidence=1.0)
                    ai.memory.save_fact(f"{k}: {v}")
                    answer = f"🧠 '{k}' ذخیره شد!"
                else:
                    answer = "❌ کلید یا مقدار خالی. مثال: یاد بگیر: فوتون = ذره نور"
            else:
                ai.memory.save_fact(content)
                answer = f"🧠 حقیقت ذخیره شد: {content}"
            await ai._present(answer, "🧠 یادگیری", "green")

        elif intent == "memory_save":
            project_match = re.search(r'روی\s+(.+?)\s+کار', resolved_text)
            if project_match:
                project_name = project_match.group(1).strip()
                ai.memory.save_project(project_name, resolved_text)
                ai.memory.save_interest(project_name)
                answer = f"📁 پروژه '{project_name}' ثبت شد!\nدفعه بعد یادم می‌آید."
            else:
                ai.memory.save_long_term("notes", datetime.now().strftime("%H%M%S"), resolved_text)
                answer = "📝 یادداشت ذخیره شد!"
            await ai._present(answer, "💾 ذخیره حافظه", "bright_blue")

        # ==========================================
        #   پاسخ عمومی — کاملاً محلی/رایگان، بدونِ هیچ APIِ مولدِ خارجی
        # ------------------------------------------
        # این پروژه دیگر به Gemini یا هیچ سرویسِ مولدِ کلیددارِ دیگری وصل
        # نمی‌شود. چهار لایه به‌ترتیبِ اولویت امتحان می‌شوند، هرکدام یا
        # کاملاً محلی‌اند یا از منابعِ رایگان/بدونِ‌کلیدِ وب استفاده
        # می‌کنند؛ برنامه هیچ‌وقت بدونِ پاسخ نمی‌ماند:
        #   ۱) SmallTalkEngine (کاملاً محلی، صفر تماسِ شبکه‌ای) —
        #      سلام/احوال‌پرسی/تشکر/خداحافظی/معرفیِ خود/توانایی‌ها.
        #   ۲) اگر به‌نظر می‌رسد سؤالِ دانشی/واقعیت‌محور است، ویکی‌پدیا
        #      را امتحان می‌کنیم (رایگان، بدونِ کلید).
        #   ۳) اگر ویکی‌پدیا جواب نداد، DuckDuckGo را امتحان می‌کنیم.
        #   ۴) اگر هیچ‌کدام از بالا جواب نداد: برای پیامِ حسی/عاطفی از
        #      موتورِ کاملاً محلیِ همدلانه استفاده می‌شود؛ در غیرِاین‌صورت
        #      یک پاسخِ ساختاریافته‌ی محلی (با راهنماییِ دستورات) نمایش
        #      داده می‌شود.
        # ==========================================
        else:
            answer = await self._general_answer(ai, resolved_text, original_text, emoji, prefix, style)

        # ==========================================
        #   ثبت نهایی یکپارچه (رفع باگ مهم)
        # ------------------------------------------
        # نسخه‌ی قبلی فقط چند شاخه‌ی خاص (پزشکی، تحلیل پروژه، ذخیره‌ی
        # حافظه، پاسخ عمومی) را finalize می‌کرد. یعنی محاسبه‌گر، مترجم،
        # لغت‌نامه، جستجوی وب، آب‌وهوا، ارز، پروفایل، ساعت و یادگیری —
        # که اکثریت قریب‌به‌اتفاق تعاملات واقعی‌اند — هرگز به تاریخچه یا
        # حافظه‌ی کوتاه‌مدت اضافه نمی‌شدند. اکنون یک نقطه‌ی واحد در انتهای
        # مسیر، همه‌ی این شاخه‌ها را finalize می‌کند (شاخه‌هایی که خودشان
        # زودتر return کرده‌اند از این قاعده جدا هستند و قبلاً درست
        # finalize می‌شوند).
        # ==========================================
        ai.tool_usage_history[tool_name] = ai.tool_usage_history.get(tool_name, 0) + 1
        quality = ai.runtime.quality_check(answer, original_text)
        if not quality["ok"]:
            logger.warning("گیت کیفیت پاسخ: %s", quality["issues"])
            if not answer:
                answer = "⚠️ پاسخ تولید نشد. لطفاً درخواست را دوباره امتحان کنید."
        if ai.current_trace is not None and not quality["ok"]:
            ai.current_trace.mark(quality_flags=list(quality.get("issues") or ["quality_gate_failed"]))
        ai._finalize(original_text, answer, start_time, intent, confidence)

    async def _general_answer(self, ai, resolved_text, original_text, emoji, prefix, style) -> str:
        """
        شاخه‌ی «پاسخِ عمومی»: SmallTalk → ویکی‌پدیا → DuckDuckGo → محلی/
        همدلانه. جداکردنِ این بخش از ``execute`` صرفاً برایِ خوانایی است؛
        متنِ نهاییِ پاسخ را برمی‌گرداند (که ``execute`` برایِ گیتِ کیفیت
        و ``_finalize`` به آن نیاز دارد) -- هر شاخه پیش از بازگشت، خودش
        پاسخ را با ``ai._present`` هم نمایش می‌دهد، دقیقاً مثلِ نسخه‌ی
        قبل از تفکیک.
        """
        history_msgs = ai.memory.get_messages(limit=8)
        memory_context = ai.memory.get_context(max_messages=5)
        pattern_context = ai.conversation_patterns.prompt_context(resolved_text)
        context = ai.runtime.build_context(
            history_msgs,
            memory_context,
            pattern_context,
            max_chars=7000,
        )
        emotional_support_mode = ai.conversation_patterns.emotional_support_mode(resolved_text)
        if ai.current_trace is not None:
            ai.current_trace.mark(
                context_used=bool(context),
                memory_hits=len(history_msgs or []),
            )

        # Do not replace an emotional disclosure with a canned small-talk reply.
        smalltalk_category = None if emotional_support_mode else SmallTalkEngine.categorize(resolved_text)

        if smalltalk_category:
            # --- لایه‌ی ۱: گفتگوی روزمره، کاملاً محلی ---
            answer = SmallTalkEngine.respond(smalltalk_category, ai.user_name)
            await ai._present(answer, f"{emoji} پاسخ", style)
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route=f"general:smalltalk:{smalltalk_category}", fallback_used=False)
            return answer

        # --- لایه‌ی ۲: اگر شکلِ یک پرسشِ دانشی/واقعیت‌محور دارد،
        # قبل از پاسخِ محلی، جستجویِ رایگانِ ویکی‌پدیا/وب را امتحان کن ---
        # نکته: اگر پیام حسی/عاطفی است (مثلاً «چرا همیشه اینطوری
        # میشه؟»)، با اینکه کلمه‌ی پرسشیِ «چرا» دارد، نباید به
        # ویکی‌پدیا فرستاده شود -- قبلاً همین باعث می‌شد یک پیامِ
        # درددل که تصادفاً «چرا»/«چطور» داشت، یک نتیجه‌ی نامرتبطِ
        # دانشنامه‌ای بگیرد به‌جایِ پاسخِ همدلانه.
        looks_like_question = (not emotional_support_mode) and bool(re.search(
            r'(؟|چیست\b|کیست\b|چطور|چگونه|کجا\b|چند\b|چرا\b|آیا\b|معنی|تعریف|کدام)',
            resolved_text,
        ))
        clean_query = text_extraction.extract_search_subject(resolved_text) if looks_like_question else None
        wiki_answer = None
        if looks_like_question:
            try:
                with ai.ui.console.status("[bold yellow]🔍 جستجویِ رایگان در ویکی‌پدیا...[/bold yellow]"):
                    wiki_res = await WebSearchEngine.get_wikipedia(ai.session, clean_query)
                if wiki_res and not wiki_res.startswith(("📡", "🌐")):
                    wiki_answer = f"📚 ویکی‌پدیا:\n\n{wiki_res}"
                    AutonomousLearningEngine.extract_and_store_knowledge(clean_query, wiki_res, ai.db)
                    ai.memory.save_fact(f"{clean_query}: {wiki_res[:100]}")
            except Exception as e:  # noqa: BLE001 - جستجویِ خودکار نباید کلِ نوبت را متوقف کند
                logger.debug("جستجویِ خودکارِ ویکی‌پدیا در پاسخِ عمومی ناموفق بود: %s", e)

        if wiki_answer:
            await ai._present(
                wiki_answer, f"{emoji} پاسخ | منبع: ویکی‌پدیا (بدونِ نیاز به API)", style
            )
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="general:wikipedia", fallback_used=True)
            return wiki_answer

        # --- لایه‌ی ۳: DuckDuckGo (رایگان، بدونِ کلید) --------
        # فقط وقتی واقعاً شکلِ یک پرسش دارد امتحان می‌شود -- وگرنه هر
        # پیامِ غیرپرسشی/غیرِسمال‌تاکی (even یک جمله‌ی صرفاً احساسی)
        # به‌طورِ خودکار به وب فرستاده می‌شد (مشکلِ Web-First).
        ddg_answer = None
        if looks_like_question:
            try:
                with ai.ui.console.status("[bold yellow]🔍 جستجویِ تکمیلی در وب...[/bold yellow]"):
                    ddg_res = await WebSearchEngine.search_duckduckgo(ai.session, clean_query)
                if ddg_res:
                    ddg_answer = ddg_res
                    AutonomousLearningEngine.extract_and_store_knowledge(clean_query, ddg_res, ai.db)
                    ai.memory.save_fact(f"{clean_query}: {ddg_res[:100]}")
            except Exception as e:  # noqa: BLE001 - جستجویِ خودکار نباید کلِ نوبت را متوقف کند
                logger.debug("جستجویِ خودکارِ DuckDuckGo در پاسخِ عمومی ناموفق بود: %s", e)

        if ddg_answer:
            await ai._present(
                ddg_answer, f"{emoji} پاسخ | منبع: DuckDuckGo (بدونِ نیاز به API)", style
            )
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="general:duckduckgo", fallback_used=True)
            return ddg_answer

        # --- لایه‌ی ۴: کاملاً محلی -----------------------
        # نه ویکی‌پدیا نه DuckDuckGo چیزی نداشتند (یا اینترنت قطع بود).
        # این پروژه دیگر به هیچ APIِ مولدِ خارجی سقوط نمی‌کند؛ مستقیماً
        # به پاسخِ محلی می‌رویم. اگر پیام حسی/عاطفی است، به‌جایِ الگویِ
        # رباتیِ عمومی، از موتورِ همدلانه‌ی کاملاً محلی استفاده می‌شود.
        local_empathy = ai.conversation_patterns.local_empathetic_reply(resolved_text)
        if local_empathy:
            await ai._present(local_empathy, f"{emoji} پاسخ", style)
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="general:local_empathy_legacy", fallback_used=True)
            return local_empathy

        # --- User State + Response Strategy ---------
        # conversation_patterns.local_empathetic_reply فقط تاکسونومیِ
        # قدیمیِ emotion را می‌شناسد (ناراحت/عصبانی/نگران/سپاسگزار/...).
        # برایِ وضعیت‌هایِ جدیدی که آن تاکسونومی پوشش نمی‌دهد (کلافه از
        # تلاشِ ناموفق، گیج، بی‌علاقه، کنجکاو، ...) از موتورِ جداگانه‌ی
        # User State + Response Strategy استفاده می‌کنیم -- کاملاً
        # آفلاین، بدونِ جایگزینیِ سیستمِ قدیمی.
        state_result = user_state_engine.detect(
            resolved_text, context_text=ai.conversation_patterns._recent_context_text(), db=ai.db,
        )
        conv_phase = conversation_phase.detect_phase(
            resolved_text,
            user_state=state_result.primary_state,
            previous_failures=ai.user_state_memory.recent_failures(),
        )
        secondary = [
            s.state for s in state_result.states
            if s.state != state_result.primary_state
        ]
        strategy = response_strategy.choose_strategy(
            state_result.primary_state,
            phase=conv_phase,
            uncertain=state_result.uncertain,
            secondary_states=secondary,
        )
        state_answer = (
            None if state_result.uncertain or state_result.primary_state == "neutral"
            else response_strategy.reply_hint(strategy)
        )
        if state_answer:
            await ai._present(state_answer, f"{emoji} پاسخ", style)
            if ai.current_trace is not None:
                ai.current_trace.mark(
                    selected_route=f"general:user_state_strategy:{strategy}",
                    user_state=state_result.primary_state,
                    fallback_used=True,
                )
            return state_answer

        # --- پاسخِ ساختاریافته‌ی محلیِ نهایی ---
        # نکته‌ی حیاتی (رفع باگِ بازخوردِ حافظه): اینجا هرگز نباید
        # `context` خامِ داخلی (که خودش شاملِ پیام‌های قبلیِ AI است) در
        # متنِ نمایش‌داده‌شده به کاربر درج شود. چون این answer در ادامه
        # با ai._finalize دوباره در حافظه ذخیره می‌شود، هر تزریقِ context
        # به answer یعنی پاسخِ بعدی دوباره همین پاسخ (به‌همراه هر چیزی که
        # خودش از قبل تزریق کرده) را در خودش تو‌درتو می‌کند -- یک حلقه‌ی
        # بازخوردِ نمایی که در نسخه‌های قبلی باعثِ خروجی‌هایِ به‌هم‌ریخته و
        # بریده‌شده (مثلِ timestampهای نصفه) می‌شد. `context` هنوز پایین‌تر
        # فقط برای ReflectionEngine.check (بررسیِ داخلیِ کیفیت، هرگز نمایشِ
        # مستقیم به کاربر) استفاده می‌شود -- همین‌جا کافی است.
        #
        # v25.5.3: قبل از boilerplateِ رباتیِ قدیمی، یک تلاشِ اختیاری و
        # کاملاً ایمن برایِ پاسخِ واقعی از مدلِ زبانیِ محلی (اگر کاربر
        # صریحاً فعالش کرده باشد -- نگاه کنید به
        # ``trx_model/conversational_bridge.py``). اگر خاموش باشد، نصب
        # نباشد، یا هر خطایی بدهد، ``None`` برمی‌گردد و مسیرِ قدیمیِ زیر
        # دقیقاً بدونِ تغییر اجرا می‌شود -- هیچ رفتارِ موجودی حذف نشده.
        # v25.5.4: ``db=ai.db`` باعث می‌شود تاریخچه‌ی *واقعیِ* گفتگو
        # (نه فقط پیامِ جاری) ساخته و به مدل داده شود -- نگاه کنید به
        # ``conversational_bridge.build_history_from_db``.
        llm_answer = conversational_bridge.try_generate_reply(resolved_text, db=ai.db)
        if llm_answer:
            await ai._present(llm_answer, f"{emoji} پاسخ", style)
            if ai.current_trace is not None:
                ai.current_trace.mark(selected_route="general:local_llm", fallback_used=False)
            return llm_answer

        answer = f"{prefix}در حال پردازش سؤال شما...\n\n"
        if "چیست" in resolved_text or "کیست" in resolved_text or "چیه" in resolved_text:
            answer += "🔍 ویکی‌پدیا و DuckDuckGo برای این عبارت نتیجه‌ای نداشتند؛ می‌توانید عبارتِ دقیق‌تری را با دستورِ «سرچ [موضوع]» امتحان کنید.\n"
        elif "سلام" in resolved_text or "خوبی" in resolved_text:
            answer += "👋 سلام! خوش آمدید. چطور می‌توانم به شما کمک کنم؟"
        else:
            answer += "🤖 من TRX AI هستم. سؤال خود را دقیق‌تر مطرح کنید یا از دستورات راهنما استفاده کنید."
        answer += "\n\n💡 این پاسخ کاملاً محلی است (بدونِ هیچ APIِ خارجی)."

        reflection = ReflectionEngine.check(answer, original_text, context)
        if reflection["needs_refinement"]:
            answer = ReflectionEngine.refine_answer(
                answer, original_text, reflection["issues"], reflection["suggestions"]
            )
        await ai._present(answer, f"{emoji} پاسخ هوشمند", style)
        if ai.current_trace is not None:
            ai.current_trace.mark(
                selected_route="general:generic_local_fallback",
                fallback_used=True,
                quality_flags=(["needs_refinement"] if reflection["needs_refinement"] else []),
            )
        return answer
