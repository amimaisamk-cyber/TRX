# -*- coding: utf-8 -*-
"""
لایه‌ی مشاهده‌پذیری (Observability Layer) -- اولویتِ ۱ سندِ ارتقایِ نسلِ
بعد (بخشِ ۱۳: «هر درخواست باید شناسه‌ی trace داشته باشد»).

هدف این ماژول اثباتِ عینیِ «چه اتفاقی واقعاً افتاد»ست، نه فقط ادعا:
برایِ هر نوبتِ گفتگو یک شیءِ ``TurnTrace`` می‌سازیم که مرحله‌به‌مرحله پر
می‌شود (ورودی → نرمال‌سازی → intent → مسیرِ انتخابی → ابزار → fallback →
پاسخِ نهایی) و در انتها در یک لاگِ محدود (``TraceLog``) ذخیره می‌شود --
قابلِ نمایش با دستورِ «ردیابی».

طراحیِ عمدیِ کاملاً additive:
    - هیچ فایلِ موجودی رفتارش تغییر نمی‌کند؛ فقط چند نقطه‌ی موجود
      (بیشتر از همه ``TurnProcessor.finalize`` که از قبل تنها قیفِ
      مشترکِ ~۱۲ مسیرِ مختلفِ پاسخ است) یک متدِ ``.mark(...)`` صدا
      می‌زنند که فقط می‌نویسد، هرگز چیزی را conditional نمی‌کند.
    - اگر جایی ``ai.current_trace`` هنوز ساخته نشده باشد (مثلاً مسیرِ
      خیلی زودهنگام)، ``mark`` و ``finish`` بی‌صدا کار نمی‌کنند اما
      خطا هم نمی‌دهند -- مشاهده‌پذیری هرگز نباید خودش یک نقطه‌ی شکستِ
      جدید در مسیرِ اصلیِ گفتگو ایجاد کند.
    - state هیچ فایلِ دیگری تغییر نمی‌کند؛ فقط می‌خواند.
"""

from __future__ import annotations

import time
import uuid
from collections import deque
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

__all__ = ["TurnTrace", "TraceRecorder", "TraceLog"]


# ==========================================
#   طرحواره‌ی trace -- دقیقاً منطبق با بخشِ ۱۳ سندِ ارتقا
# ==========================================
@dataclass
class TurnTrace:
    trace_id: str
    started_at: float

    input: str = ""
    normalized_input: str = ""
    detected_intent: Optional[str] = None
    confidence: Optional[float] = None
    user_state: Optional[str] = None
    context_used: bool = False
    memory_hits: int = 0
    selected_route: Optional[str] = None
    selected_module: Optional[str] = None
    tool_execution: Optional[str] = None
    fallback_used: bool = False
    final_response: Optional[str] = None
    latency_ms: Optional[int] = None
    error: Optional[str] = None
    quality_flags: list = field(default_factory=list)

    # فیلدهایِ داخلی -- برایِ اشکال‌زدایی، در بخشِ ۱۳ نبودند اما رایگان‌اند
    route_history: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


class TraceRecorder:
    """
    یک نمونه از این کلاس دقیقاً معادلِ «یک نوبتِ گفتگو» است. در ابتدایِ
    ``TurnProcessor.process_turn`` ساخته می‌شود (``ai.current_trace``) و
    هر شاخه‌ای که پیش از ``finalize`` بازمی‌گردد، باید ``.mark(...)`` را
    صدا بزند و بعد ``ai.trace_log.push(ai.current_trace)`` را.

    عمداً fail-soft: اگر مقداری اشتباه/غیرمنتظره داده شود، trace را خراب
    نمی‌کند، فقط همان مقدار را ذخیره می‌کند -- این ابزارِ دیباگ است، نه
    یک validator که بخواهد جلویِ چیزی را بگیرد.
    """

    def __init__(self, raw_input: str = "") -> None:
        self.data = TurnTrace(
            trace_id=uuid.uuid4().hex[:8],
            started_at=time.time(),
            input=raw_input,
        )
        self._finished = False

    def mark(self, **fields: Any) -> "TraceRecorder":
        for key, value in fields.items():
            if key == "route_note":
                self.data.route_history.append(str(value))
                continue
            if hasattr(self.data, key):
                setattr(self.data, key, value)
            else:
                # فیلدِ ناشناخته را دور نریز -- در route_history ثبتش کن
                # تا در توسعه‌ی بعدی معلوم شود کجا نیاز به فیلدِ جدید بود.
                self.data.route_history.append(f"{key}={value!r}")
        return self

    def finish(self) -> TurnTrace:
        if not self._finished:
            if self.data.latency_ms is None:
                self.data.latency_ms = int((time.time() - self.data.started_at) * 1000)
            self._finished = True
        return self.data


class TraceLog:
    """لاگِ محدودِ درون‌حافظه‌ای -- بدون هیچ نوشتنِ اجباری روی دیسک
    (پروژه رویِ Android/Pydroid هم اجرا می‌شود؛ I/O اضافه‌ی هر نوبت
    اینجا عمداً اجتناب شده). اگر بعداً لازم شد رویِ دیسک هم بنویسیم
    (بخشِ ۱۳/۱۵ سند)، این کلاس تنها جاییست که باید عوض شود.
    """

    def __init__(self, maxlen: int = 200) -> None:
        self._items: deque[TurnTrace] = deque(maxlen=maxlen)

    def push(self, trace: TurnTrace) -> None:
        self._items.append(trace)

    def last(self, n: int = 1) -> list[TurnTrace]:
        if n <= 1:
            return [self._items[-1]] if self._items else []
        return list(self._items)[-n:]

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self):
        return iter(self._items)
