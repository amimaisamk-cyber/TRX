# -*- coding: utf-8 -*-
"""
پنلِ تشخیص/گزارش‌گیری: هر چیزی که «فقط برایِ نشان‌دادنِ وضعیتِ سیستم»
است و هیچ داده‌ای را تغییر نمی‌دهد (به‌جز نوشتنِ یک فایلِ گزارشِ
HTML روی دیسک) در همین‌جا جمع شده: داشبوردِ توسعه‌دهنده، کنسولِ
محرمانه، مانیتورینگِ کلی، تاریخچه، لیستِ پروژه‌ها، و خروجیِ HTML.

جداکردنِ این بخش از ``core.py`` یعنی هر تغییری در «چطور آمار نشان داده
شود» بدونِ لمسِ مسیریابی/منطقِ گفتگو ممکن است.
"""

from __future__ import annotations

import os
import platform
import random
import time
from datetime import datetime

from rich import box
from rich.panel import Panel
from rich.table import Table

from .. import __version__
from ..dependencies import PSUTIL_AVAILABLE
from ..logging_config import get_logger

if PSUTIL_AVAILABLE:
    import psutil

logger = get_logger(__name__)

__all__ = ["DiagnosticsPanel"]

# طالع‌بینیِ کنسولِ محرمانه -- کاملاً بی‌خطر و ثابت، جدا از منطقِ آماری.
_SECRET_CONSOLE_FORTUNES = (
    "بهترین کد، کدی است که هرگز نوشته نشده — اما وقتی نوشته می‌شود، خوانا باشد. 🧘",
    "هر باگ یک معلمِ صبور است که فقط زبانِ traceback بلد است. 🐛",
    "برنامه‌نویسیِ خوب یعنی سادگی را انتخاب کنی، نه اینکه راهِ دیگری نداشته باشی. ✨",
    "امروز هم یک خط کد کمتر از دیروز بنویس، اما دقیق‌تر. 🎯",
    "دیباگ‌کردن مثل بازیِ کارآگاهی است؛ تو هم قاتلی، هم کارآگاه. 🕵️",
)


def _format_uptime(boot_time: float) -> str:
    uptime_seconds = int(time.time() - boot_time)
    hours, remainder = divmod(uptime_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


class DiagnosticsPanel:
    """گزارش‌ها/داشبوردهایِ فقط-خواندنیِ برنامه."""

    def __init__(self, ai) -> None:
        self.ai = ai

    # ------------------------------------------------------------------
    #   داشبوردِ توسعه‌دهنده
    # ------------------------------------------------------------------
    def show_dashboard(self) -> None:
        """
        داشبوردِ توسعه‌دهنده: مصرفِ RAM/CPU، زمانِ پاسخ، تعدادِ
        درخواست‌ها و لاگِ خطاهای اخیر — همان چیزی که درخواست شده بود.
        برخلافِ کنسولِ محرمانه («درِ مخفی»)، این دستور در راهنما هم
        نمایش داده می‌شود چون یک ابزارِ توسعه‌ایِ رسمی است، نه Easter egg.
        """
        ai = self.ai
        uptime_str = _format_uptime(ai._boot_time)

        # --- RAM/CPU ---
        cpu_line = ram_line = "psutil نصب نیست (pip install psutil)"
        if PSUTIL_AVAILABLE:
            try:
                proc = psutil.Process(os.getpid())
                # interval=None یعنی نسبت به آخرین فراخوانی (نگاه کنید به
                # فراخوانیِ گرم‌کننده در TRXEnterpriseAI.__init__) بدونِ
                # هیچ sleep/بلاک‌کردن. قبلاً interval=0.2 بود که چون این
                # متد sync است و از دلِ یک نوبتِ async صدا زده می‌شود، هر
                # بار «داشبورد» کلِ حلقه‌ی رویداد (و در نتیجه کلِ برنامه،
                # از جمله در GUI) را ۲۰۰ میلی‌ثانیه فریز می‌کرد.
                cpu_percent = proc.cpu_percent(interval=None)
                mem_info = proc.memory_info()
                ram_mb = mem_info.rss / (1024 * 1024)
                sys_ram = psutil.virtual_memory()
                cpu_line = f"{cpu_percent:.1f}% (این فرآیند)"
                ram_line = f"{ram_mb:.1f} MB (این فرآیند) | {sys_ram.percent:.0f}% کلِ سیستم"
            except Exception as e:  # noqa: BLE001 - داشبورد هرگز نباید کرش کند
                logger.debug("خواندنِ آمارِ psutil ناموفق بود: %s", e)
                cpu_line = ram_line = "خطا در خواندنِ آمار"

        # --- زمانِ پاسخ ---
        if ai._response_times:
            times = list(ai._response_times)
            avg_ms = sum(times) / len(times)
            p95_ms = sorted(times)[int(len(times) * 0.95) - 1] if len(times) >= 5 else max(times)
            latency_line = f"میانگین: {avg_ms:.0f}ms | آخرین: {times[-1]}ms | p95: {p95_ms}ms (از {len(times)} درخواستِ اخیر)"
        else:
            latency_line = "هنوز درخواستی ثبت نشده"

        table = Table(
            title="🖥️ داشبورد توسعه‌دهنده — TRX AI",
            box=box.DOUBLE_EDGE, border_style="cyan", show_header=False,
        )
        table.add_column("پارامتر", style="bold white")
        table.add_column("مقدار", style="bold cyan", justify="right")
        table.add_row("مدتِ روشن‌بودن", uptime_str)
        table.add_row("CPU", cpu_line)
        table.add_row("RAM", ram_line)
        table.add_row("زمانِ پاسخ", latency_line)
        table.add_row("تعدادِ کلِ درخواست‌ها", str(ai.stats["total_requests"]))
        table.add_row("Cache hit", str(ai.stats["cache_hits"]))
        table.add_row("تعدادِ خطاها", str(ai.stats["errors"]))
        ai.ui.console.print(table)

        if ai._error_log:
            err_table = Table(title="🪵 آخرین خطاها", box=box.ROUNDED, border_style="red")
            err_table.add_column("زمان", style="dim")
            err_table.add_column("پیام", style="red")
            for entry in list(ai._error_log)[-10:]:
                err_table.add_row(entry["time"], entry["message"])
            ai.ui.console.print(err_table)
        else:
            ai.ui.console.print("[dim]در این نشست هنوز خطایی ثبت نشده.[/dim]")

    # ------------------------------------------------------------------
    #   کنسولِ محرمانه‌ی توسعه‌دهنده
    # ------------------------------------------------------------------
    def show_secret_console(self) -> None:
        """
        🔐 کنسولِ محرمانه‌ی توسعه‌دهنده — یک ویژگیِ پنهان (Easter egg) که
        در «راهنما» عمداً نمایش داده نمی‌شود. کاملاً محلی: هیچ داده‌ای
        جایی ارسال نمی‌شود، فقط آماری از همین اجرای برنامه و کمی حال‌وهوای
        متفاوت به نمایش می‌گذارد.
        """
        ai = self.ai
        uptime_str = _format_uptime(ai._boot_time)

        cache_stats = ai.cache.stats()
        total = ai.stats["total_requests"]
        error_rate = f"{(ai.stats['errors'] / total * 100):.1f}%" if total else "—"

        table = Table(
            title="🔐 کنسولِ محرمانه‌ی توسعه‌دهنده — TRX AI",
            box=box.DOUBLE_EDGE, border_style="magenta", show_header=False,
        )
        table.add_column("پارامتر", style="bold white")
        table.add_column("مقدار", style="bold magenta", justify="right")

        table.add_row("نسخه", __version__)
        table.add_row("مدتِ روشن‌بودنِ این اجرا", uptime_str)
        table.add_row("پردازش‌های این نشست", str(total))
        table.add_row("نرخِ خطا", error_rate)
        table.add_row("Hit-Rate کش", cache_stats["hit_rate"])
        table.add_row("پروژه فعال", ai.session_mgr.active_session)
        table.add_row("شخصیتِ فعال", ai.personality)
        table.add_row("نسخه‌ی پایتون", platform.python_version())
        table.add_row("پلتفرم", platform.system())

        ai.ui.console.print(table)
        ai.ui.console.print(
            Panel(
                random.choice(_SECRET_CONSOLE_FORTUNES),
                title="🔮 طالع‌بینیِ برنامه‌نویس",
                border_style="magenta",
                box=box.ROUNDED,
            )
        )
        ai.ui.console.print("[dim]این یک کنسولِ محلی و محرمانه است؛ هیچ داده‌ای از اینجا به بیرون ارسال نمی‌شود.[/dim]")

    # ------------------------------------------------------------------
    #   مانیتورینگِ کلی
    # ------------------------------------------------------------------
    def show_metrics(self) -> None:
        ai = self.ai
        stats = ai.db.get_stats()
        cache_stats = ai.cache.stats()
        memory_stats = ai.memory.get_memory_stats()
        vector_stats = ai.vector_db.get_stats() if ai.vector_db else {"status": "disabled", "count": 0}

        table = Table(
            title="📊 مانیتورینگ سیستم TRX AI [v20.0]",
            box=box.DOUBLE_EDGE, border_style="cyan"
        )
        table.add_column("پارامتر", style="bold white")
        table.add_column("مقدار", style="bold green", justify="center")

        table.add_row("حجم حافظه معنایی", str(stats["knowledge_size"]))
        table.add_row("تراکنش‌های ثبت‌شده", str(stats["history_size"]))
        table.add_row("میانگین تأخیر", f"{stats['avg_latency']} ms")
        table.add_row("میانگین اطمینان پاسخ", stats["avg_confidence"])
        table.add_row("کش | hit/miss", f"{cache_stats['hits']}/{cache_stats['misses']} ({cache_stats['hit_rate']})")
        table.add_row("اندازه کش", f"{cache_stats['size']}/{cache_stats['max_size']}")
        table.add_row("شخصیت فعال", ai.personality)
        table.add_row("پروژه جاری", ai.session_mgr.active_session)
        table.add_row("پیام‌های حافظه کوتاه‌مدت", str(memory_stats["short_term_size"]))
        table.add_row("پروژه‌های ثبت‌شده", str(memory_stats["projects_count"]))
        table.add_row("علایق ثبت‌شده", str(memory_stats["interests_count"]))
        table.add_row("حقایق ثبت‌شده", str(memory_stats["facts_count"]))
        vector_status_fa = {
            "active": "فعال ✅",
            "disabled": "غیرفعال ⚠️ (pip install chromadb sentence-transformers)",
            "error": "خطا در راه‌اندازی ❌ (به logs/trx_ai.log نگاه کنید)",
        }.get(vector_stats.get("status", "disabled"), "نامشخص")
        table.add_row("حافظه برداری (جستجوی معنایی)",
                       f"{vector_status_fa} — {vector_stats.get('count', 0)} سند")
        table.add_row("پلاگین‌ها", str(len(ai.plugin_system.list_plugins())))

        ai.ui.console.print(table)

    # ------------------------------------------------------------------
    #   ردیابیِ اجرا (trace.py) -- اثباتِ عینیِ «چه اتفاقی افتاد»
    # ------------------------------------------------------------------
    def show_last_trace(self, n: int = 1) -> None:
        """
        نمایشِ آخرین ``n`` رکوردِ trace (بخشِ ۱۳ سندِ ارتقا): برایِ هر
        نوبت نشان می‌دهد ورودی چه بود، چه intentی با چه اطمینانی
        تشخیص داده شد، کدام مسیر/ابزار اجرا شد، آیا fallback فعال شد،
        و پاسخِ نهایی چه بود. اگر هنوز هیچ نوبتی trace نشده (مثلاً
        بلافاصله بعدِ استارت)، صادقانه همین را می‌گوید -- نه یک
        جدولِ خالیِ گمراه‌کننده.
        """
        ai = self.ai
        traces = ai.trace_log.last(n) if getattr(ai, "trace_log", None) else []
        if not traces:
            ai.ui.console.print(
                "[yellow]هنوز هیچ نوبتی ردیابی نشده — این دستور فقط بعد از حداقل یک پیامِ واقعی پر می‌شود.[/yellow]"
            )
            return

        for tr in reversed(traces):
            t = Table(
                title=f"🔎 ردیابیِ نوبت #{tr.trace_id}",
                box=box.ROUNDED, border_style="yellow", show_header=False,
            )
            t.add_column("فیلد", style="bold white")
            t.add_column("مقدار", style="green")
            t.add_row("ورودیِ خام", tr.input[:120] or "—")
            if tr.normalized_input and tr.normalized_input != tr.input:
                t.add_row("ورودیِ نرمال‌شده", tr.normalized_input[:120])
            t.add_row("Intent تشخیص‌داده‌شده", f"{tr.detected_intent or '—'} (اطمینان: {tr.confidence if tr.confidence is not None else '—'})")
            t.add_row("وضعیتِ کاربر", tr.user_state or "—")
            t.add_row("مسیرِ انتخابی", tr.selected_route or "—")
            if tr.selected_module:
                t.add_row("ماژولِ اجراشده", tr.selected_module)
            if tr.tool_execution:
                t.add_row("ابزارِ اجراشده", tr.tool_execution)
            t.add_row("Fallback فعال شد؟", "بله ⚠️" if tr.fallback_used else "خیر")
            t.add_row("حافظه/context استفاده شد؟", f"{'بله' if tr.context_used else 'خیر'} ({tr.memory_hits} نتیجه)")
            t.add_row("پاسخِ نهایی (خلاصه)", (tr.final_response or "—")[:150])
            t.add_row("زمانِ پردازش", f"{tr.latency_ms} ms" if tr.latency_ms is not None else "—")
            if tr.error:
                t.add_row("خطا", f"[bold red]{tr.error}[/bold red]")
            if tr.quality_flags:
                t.add_row("پرچم‌هایِ کیفیت", ", ".join(tr.quality_flags))
            if tr.route_history:
                t.add_row("یادداشت‌هایِ مسیر", " | ".join(str(x) for x in tr.route_history[:5]))
            ai.ui.console.print(t)

    # ------------------------------------------------------------------
    #   تاریخچه / پروژه‌ها / خروجیِ HTML
    # ------------------------------------------------------------------
    def show_history_table(self) -> None:
        ai = self.ai
        records = ai.db.get_recent_history(limit=10)
        if not records:
            ai.ui.console.print("[yellow]تاریخچه خالی است.[/yellow]")
            return

        t = Table(title="📜 تاریخچه گفتگوها", box=box.ROUNDED, border_style="magenta")
        t.add_column("زمان", style="cyan", max_width=20)
        t.add_column("پرسش", style="white", max_width=40)
        t.add_column("پاسخ", style="green", max_width=50)
        for rec in records:
            t.add_row(str(rec[0]), str(rec[1])[:80], str(rec[2])[:100])
        ai.ui.console.print(t)

    def show_projects(self) -> None:
        ai = self.ai
        projects = ai.memory.get_all_projects()
        if not projects:
            ai.ui.console.print("[yellow]هنوز پروژه‌ای ثبت نشده.[/yellow]")
            return

        t = Table(title="📁 پروژه‌های ثبت‌شده", box=box.ROUNDED, border_style="gold1")
        t.add_column("پروژه", style="bold cyan")
        t.add_column("توضیح", style="white")
        t.add_column("زمان", style="dim")

        for name, desc in projects.items():
            if not name.endswith(":time"):
                time_key = f"{name}:time"
                time_str = ai.memory.load_long_term("projects", time_key) or ""
                t.add_row(name, desc[:60] if desc else "", time_str)

        ai.ui.console.print(t)

    def export_history_to_html(self, file_path: str = "trx_ai_v20_report.html") -> None:
        ai = self.ai
        records = ai.db.get_recent_history(limit=50)
        if not records:
            ai.ui.console.print("[yellow]⚠️ تاریخچه‌ای یافت نشد.[/yellow]")
            return

        rows_html = "".join(
            f"<tr><td>{rec[0]}</td><td>{rec[1]}</td><td>{rec[2][:200]}</td></tr>"
            for rec in records
        )

        html_content = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><meta charset="UTF-8"><title>TRX AI Report v20</title>
<style>
  body {{font-family: Tahoma; background:#f4f6f9; padding:20px; direction:rtl}}
  h2 {{color:#1e3a8a; text-align:center}}
  table {{width:100%; border-collapse:collapse; background:white; margin-top:20px}}
  th,td {{padding:12px; text-align:right; border-bottom:1px solid #ddd; vertical-align:top; word-break:break-word}}
  th {{background:#3b82f6; color:white}}
  tr:hover {{background:#f0f4ff}}
  .stats {{background:#e8f4f8; padding:15px; border-radius:8px; margin:20px 0}}
</style>
</head>
<body>
<h2>📊 گزارش TRX AI v20</h2>
<div class="stats">
  <p>📅 تاریخ: {datetime.now().strftime("%Y-%m-%d %H:%M")}</p>
  <p>👤 کاربر: {ai.user_name}</p>
  <p>🎭 شخصیت: {ai.personality}</p>
</div>
<table><tr><th>زمان</th><th>پرسش</th><th>پاسخ</th></tr>{rows_html}</table>
</body></html>"""

        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            ai.ui.console.print(f"[bold green]📊 گزارش HTML: {os.path.abspath(file_path)}[/bold green]")
        except Exception as e:
            ai.ui.console.print(f"❌ خطا: {e}")
            logger.exception("خطا هنگام اجرای دستور: %s", e)
            ai.stats["errors"] += 1
            ai._error_log.append({"time": datetime.now().strftime("%H:%M:%S"), "message": str(e)[:200]})
