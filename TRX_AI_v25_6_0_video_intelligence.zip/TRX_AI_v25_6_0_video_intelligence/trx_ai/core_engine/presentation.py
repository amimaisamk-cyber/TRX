# -*- coding: utf-8 -*-
"""
لایه‌ی «نمایش»: مسئولِ تنهاکاری‌است -- تبدیلِ یک پاسخِ نهاییِ متنی به
چیزی که کاربر واقعاً می‌بیند/می‌شنود: ترجمه به زبانِ ورودی (در صورتِ
نیاز)، نمایشِ پنلِ رنگی، و پیشنهادِ شنیدنِ صوتیِ آن. هیچ منطقِ
تصمیم‌گیریِ «چه پاسخی درست است» اینجا نیست -- آن به عهده‌ی مسیریاب
(``tool_router.py``) و پردازشگرِ نوبت (``turn_processor.py``) است.

این ماژول یک نمونه از ``TRXEnterpriseAI`` را می‌گیرد (``ai``) و از
attributeهایِ آن (``ai.session``، ``ai.ui``، ``ai._response_lang``،
``ai._input_fn``، ``ai.personality``) استفاده می‌کند؛ خودش هیچ
state دائمی‌ای نگه نمی‌دارد.
"""

from __future__ import annotations

import os

from ..config import PERSONALITIES
from ..audio import AudioVoiceEngine
from ..tools import LanguageEngine

__all__ = ["PresentationEngine"]


class PresentationEngine:
    """نمایشِ پاسخِ نهایی + پیشنهادِ صدا + اموجی/پیشوندِ شخصیت."""

    # اموجیِ متناظرِ هر نیت -- برایِ انتخابِ سریع بدونِ نیاز به تحلیلِ متن.
    INTENT_EMOJIS = {
        "calculator": "🧮",
        "translator": "🔀",
        "dictionary": "📖",
        "code_analyzer": "💻",
        "web_search": "🌐",
        "weather": "☀️",
        "currency": "💰",
        "file_reader": "📂",
        "system_time": "🕒",
        "memory_save": "🧠",
        "memory_query": "🧠",
        "personality_change": "🎭",
        "self_learning": "📚",
        "joke": "😄",
        "profile_update": "👤",
        "profile_query": "👤",
        "workflow": "⚡",
        "planning": "📋",
        "medical": "🏥",
    }

    def __init__(self, ai) -> None:
        self.ai = ai

    def get_personality_prefix(self):
        p = PERSONALITIES.get(self.ai.personality, PERSONALITIES["رسمی"])
        return p["emoji"], p["prefix"], p["style"]

    def get_emoji(self, text: str, intent: str = "") -> str:
        """اموجی هوشمند بر اساس متن و نیت"""
        if intent in self.INTENT_EMOJIS:
            return self.INTENT_EMOJIS[intent]

        text_lower = text.lower()
        if any(word in text_lower for word in ["سلام", "خوبی", "حالت"]):
            return "👋"
        if any(word in text_lower for word in ["خنده", "شوخی", "جک"]):
            return "😂"
        if any(word in text_lower for word in ["متاسفم", "ببخشید", "اشتباه"]):
            return "😅"
        if "?" in text or "؟" in text:
            return "❓"
        return "🤖"

    async def present(self, text: str, title: str = "", style: str = "cyan") -> None:
        """
        نقطه‌ی واحد برای نمایشِ هر پاسخِ «نهایی» (نه سؤال پیگیری، نه پیام
        اورژانسی، نه خروجیِ مفسر کد): اگر ورودیِ این نوبت غیرفارسی
        تشخیص داده شده بود، پاسخ را قبل از نمایش به همان زبان ترجمه
        می‌کند («با هر زبان سرچ شود، با همان زبان جواب بده»). سپس پنل
        پاسخ را نشان می‌دهد و بلافاصله بعدش گزینه‌ی شنیدنِ صوتیِ آن (با
        صدای نورالِ مایکروسافت) را پیشنهاد می‌دهد.
        """
        ai = self.ai
        if getattr(ai, "_response_lang", "fa") != "fa":
            text = await LanguageEngine.translate_text(ai.session, text, "fa", ai._response_lang)
        await ai.ui.animated_print(text, title, style)
        await self.handle_voice_option(text)

    async def handle_voice_option(self, text: str) -> None:
        """
        بعد از هر پاسخِ نهایی، به کاربر پیشنهاد می‌دهد پاسخ را با صدای
        نورالِ مایکروسافت (همان زیرساخت edge-tts) بشنود: ۱=مرد، ۲=زن،
        اینتر=رد کردن. برای پیام‌های خطا/اورژانسی/سؤال پیگیری اصلاً
        پیشنهاد داده نمی‌شود (این‌ها از قبل توسط present فیلتر می‌شوند،
        اما این بررسی هم برای فراخوانی‌های مستقیم نگه داشته شده).
        """
        ai = self.ai
        if not text or not text.strip():
            return
        # رابط وب جدید صدا را مستقیماً با SpeechSynthesis مرورگر پخش می‌کند؛
        # در این حالت اصلاً edge-tts را اجرا نکن و فایل صوتی نساز.
        if getattr(ai.ui, "browser_speech", False):
            return
        if any(m in text for m in ["❌", "⚠️", "🚨"]):
            return
        ai.ui.voice_prompt()
        raw_choice = (await ai._input_fn()).strip()
        choice = ai.ui.f2e(raw_choice)  # اگر کاربر رقم فارسی (۱/۲) تایپ کرده باشد هم کار کند
        if choice in ["1", "2"]:
            with ai.ui.voice_generating():
                filepath = await AudioVoiceEngine.text_to_speech_save(text, choice)
            if filepath:
                ai.ui.voice_saved(os.path.abspath(filepath))
            else:
                ai.ui.voice_failed()
