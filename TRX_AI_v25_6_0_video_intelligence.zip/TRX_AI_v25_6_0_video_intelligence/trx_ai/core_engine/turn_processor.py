# -*- coding: utf-8 -*-
"""
پردازشگرِ نوبت: نقطه‌ی ورودیِ واحدِ هر سه رابط (ترمینال/GUI/وب) برایِ
یک پیامِ کاربر -- متنی، عکس، یا فایل. مسئولیتِ این ماژول «چه اتفاقی
باید بیفتد وقتی کاربر چیزی می‌فرستد» است: دستورهایِ ساختاری (آمار/
داشبورد/...)، تشخیصِ زبان، ادامه‌دادنِ گفتگوهایِ چندمرحله‌ای (پزشکی/
همراهِ روان‌شناختی/بازیابی/تصحیحِ نیت)، و در نهایت سپردنِ کنترل به
``ToolRouter`` برایِ پیام‌هایِ عادی. همچنین ثبتِ نهاییِ هر پاسخ در
تاریخچه/حافظه (``finalize``) و بارگذاریِ پروفایلِ کاربر در ابتدایِ
اجرا اینجا هستند، چون این‌ها هم بخشی از چرخه‌ی عمرِ «یک نوبت»/«یک
نشست» محسوب می‌شوند.
"""

from __future__ import annotations

import os
import re
import time
from datetime import datetime

from rich.panel import Panel

from ..config import OS_FILES_DIR, PERSONALITIES
from ..conversation import config as conv_config
from ..conversation import conversation_engine
from ..intelligence import IntentEngine
from ..nlu import disambiguator
from ..nlu import feedback as intent_feedback
from ..nlu import user_state as user_state_engine
from ..logging_config import get_logger
from ..medical.online import fetch_online_medical_info
from ..tools import FileManager, FileValidationError, LanguageEngine
from ..vision import ImageValidationError, classify_image_caption
from .trace import TraceRecorder

logger = get_logger(__name__)

__all__ = ["TurnProcessor"]


class TurnProcessor:
    """پردازشِ یک نوبتِ گفتگو (متن/عکس/فایل) از ابتدا تا ثبتِ نهایی."""

    def __init__(self, ai) -> None:
        self.ai = ai

    # ------------------------------------------------------------------
    #   نوبتِ متنی
    # ------------------------------------------------------------------
    async def process_turn(self, user_input: str) -> bool:
        """
        پردازشِ یک پیامِ کاربر (یک نوبتِ گفتگو).

        هم حلقه‌ی ترمینالی (`start_loop`) و هم رابطِ گرافیکیِ جدید
        (`gui_app.py`) از همینِ یک متد استفاده می‌کنند — نه دو نسخه‌ی
        جداگانه از منطقِ مسیریابی. این یعنی رفتارِ GUI و ترمینال همیشه
        دقیقاً یکسان می‌ماند، و هر بهبودی که در آینده به مسیریابی اضافه
        شود، خودکار در هر دو رابط اثر می‌کند.

        تمامِ خروجی از طریقِ `ai.ui.*` انجام می‌شود (نه `print()` خام)
        تا با تعویضِ `ai.ui` (مثلاً به `GuiUIEngine`)، همین متد بدونِ
        هیچ تغییری برای رابطِ گرافیکی هم کار کند.

        خروجی: False یعنی «جلسه باید تمام شود»، True یعنی ادامه بده.
        """
        ai = self.ai
        # ==========================================
        #   لایه‌ی مشاهده‌پذیری -- شروعِ trace همینِ نوبت (بخشِ ۱۳ سندِ
        #   ارتقا). ``ai.current_trace`` تا انتهایِ نوبت زنده می‌ماند؛
        #   هر شاخه‌ای که پیش از ``finalize`` بازمی‌گردد باید خودش
        #   ``.mark(...)`` و بعد ``ai.trace_log.push(...)`` را صدا بزند
        #   (شاخه‌هایی که به finalize می‌رسند نیازی به این کار ندارند،
        #   چون finalize خودش ثبتِ نهایی را انجام می‌دهد).
        # ==========================================
        trace = TraceRecorder(user_input)
        ai.current_trace = trace
        decision = ai.runtime.inspect(user_input)
        user_input = decision.normalized
        trace.mark(normalized_input=user_input)
        if not user_input:
            return True
        if decision.duplicate:
            logger.debug("درخواست تکراری در بازه کوتاه تشخیص داده شد.")
        if user_input.lower() in ai.EXIT_COMMANDS:
            ai.ui.console.print("👋 خداحافظ!")
            return False

        # یادآوریِ خودکارِ کارهایی که سررسیدشان رسیده (اگر باشد، همین‌جا نشان داده می‌شود)
        due_tasks = ai.task_manager.check_due_reminders()
        for task_id, title, due_at in due_tasks:
            ai.ui.console.print(f"[bold yellow]⏰ یادآوری: «{title}» (سررسید: {due_at}) — کارِ #{task_id}[/bold yellow]")

        # ==========================================
        #   🌍 چندزبانگی: تشخیصِ زبان + ترجمه به فارسی
        # ------------------------------------------
        # کلِ منطقِ داخلیِ برنامه (تشخیصِ نیت، پزشکی، کد،
        # دستورهای ساختاری) روی کلیدواژه‌های فارسی کار
        # می‌کند. اگر ورودی از قبل فارسی باشد (اکثریتِ
        # قطعیِ موارد)، این بررسی کاملاً محلی و بدونِ هیچ
        # تماسِ شبکه‌ای انجام می‌شود؛ فقط برای متنِ واقعاً
        # غیرفارسی یک درخواستِ ترجمه زده می‌شود. اگر شبکه
        # نبود یا ترجمه شکست خورد، بی‌صدا فارسی فرض می‌شود
        # (رفتارِ قبلی، بدونِ تغییر).
        # ==========================================
        ai._response_lang = "fa"
        detected_lang = await LanguageEngine.detect_language(ai.session, user_input)
        if detected_lang != "fa":
            translated_input = await LanguageEngine.translate_text(
                ai.session, user_input, detected_lang, "fa"
            )
            if translated_input and translated_input.strip():
                user_input = translated_input.strip()
                ai._response_lang = detected_lang

        if user_input == "ردیابی":
            # دستورِ جدیدِ لایه‌ی مشاهده‌پذیری: نمایشِ آخرین نوبتِ
            # ثبت‌شده در ``ai.trace_log`` (نگاه کنید به core_engine/trace.py).
            trace.mark(selected_route="structural:ردیابی")
            ai._show_last_trace()
            return True
        if user_input == "آمار":
            trace.mark(selected_route="structural:آمار")
            ai._show_metrics()
            return True
        if user_input == "داشبورد":
            trace.mark(selected_route="structural:داشبورد")
            ai._show_dashboard()
            return True
        if user_input == "تاریخچه":
            trace.mark(selected_route="structural:تاریخچه")
            ai._show_history_table()
            return True
        if user_input == "پروژه‌ها":
            trace.mark(selected_route="structural:پروژه‌ها")
            ai._show_projects()
            return True
        if user_input == "گزارش":
            trace.mark(selected_route="structural:گزارش")
            ai.export_history_to_html()
            return True
        if user_input.startswith("شخصیت "):
            new_personality = user_input.replace("شخصیت ", "").strip()
            if new_personality in PERSONALITIES:
                ai.personality = new_personality
                ai.db.set_profile("personality", new_personality)
                ai.ui.console.print(f"🎭 شخصیت به '{new_personality}' تغییر یافت.")
            else:
                ai.ui.console.print("❌ شخصیت نامعتبر است.")
            return True
        if user_input == "راهنما":
            ai.ui.show_guide()
            return True
        if user_input.startswith("پروژه جدید "):
            project_name = user_input.replace("پروژه جدید ", "").strip()
            ai.session_mgr.switch_session(project_name)
            ai.ui.console.print(f"📁 به پروژه '{project_name}' تغییر کرد.")
            return True

        # ==========================================
        #   🤖 حلقه‌ی عامل خودمختار (Autonomous Agent Loop)
        # ------------------------------------------
        # با پیشوندِ «عامل:» (یا معادلِ انگلیسیِ «/agent »)، به‌جای
        # مسیریابیِ معمولیِ تک‌ابزاره‌ی IntentEngine، کنترل به
        # `trx_ai.agent.cognition.CognitionCore` سپرده می‌شود (از طریقِ
        # ``AgentBridge``): اول Understanding/Reasoning تصمیم می‌گیرند
        # اصلاً ابزار (به‌خصوص Web) لازم است یا نه، بعد در صورتِ نیاز
        # `trx_ai.agent.AgentLoop` ابزارها را به‌ترتیب و زنجیره‌ای صدا
        # می‌زند -- بدونِ اینکه کاربر تک‌تکِ مراحل را دستی بگوید.
        # ==========================================
        agent_goal = ai._extract_agent_goal(user_input)
        if agent_goal is not None:
            trace.mark(selected_route="agent_loop", tool_execution="AgentBridge/CognitionCore")
            await ai._handle_agent_task(agent_goal)
            ai.trace_log.push(trace.finish())
            return True

        # ==========================================
        #   🔐 کنسولِ محرمانه‌ی توسعه‌دهنده (ویژگیِ پنهان)
        # ------------------------------------------
        # این دستور در «راهنما» نمایش داده نمی‌شود؛ فقط با
        # دانستنِ عبارتِ دقیق فعال می‌شود. کاملاً محلی و
        # بی‌خطر است (چیزی جایی ارسال نمی‌شود، فقط آماری از
        # همین اجرای برنامه نمایش می‌دهد) — هدفش صرفاً یک
        # جزیره‌ی شگفت‌انگیزِ کوچک برای خودِ شماست.
        # ==========================================
        if user_input.strip() in ai.SECRET_CONSOLE_TRIGGERS:
            trace.mark(selected_route="structural:secret_console")
            ai._show_secret_console()
            ai.trace_log.push(trace.finish())
            return True

        # ==========================================
        #   تأییدِ صریحِ «بازیابی» (اگر منتظرِ پاسخ باشیم)
        # ------------------------------------------
        # چون بازیابی با overwrite=True داده‌های فعلی را جایگزین
        # می‌کند، ورودیِ بعدیِ کاربر باید همین‌جا به‌عنوانِ تأیید/انصراف
        # تفسیر شود، نه اینکه دوباره وارد مسیریابیِ عادیِ نیت شود.
        # ==========================================
        if ai._pending_restore:
            ai._pending_restore = False
            if user_input.strip() in ai.RESTORE_CONFIRM_WORDS:
                answer = ai._do_restore_latest_backup()
            else:
                answer = "🚫 بازیابی لغو شد. هیچ داده‌ای تغییر نکرد."
            trace.mark(selected_route="backup_restore_confirmation", final_response=answer[:300])
            await ai._present(answer, "🗄️ بازیابی", "green")
            ai.trace_log.push(trace.finish())
            return True

        # ==========================================
        #   پاسخ به سؤالِ ابهام (اگر منتظرِ آن باشیم)
        # ------------------------------------------
        # ``tool_router.execute`` وقتی دو ابزارِ نامزد امتیازِ نزدیکی
        # داشتند، به‌جایِ اجرا، یک سؤالِ کوتاه پرسید و
        # ``ai._pending_disambiguation`` را ست کرد. همینِ پیامِ کاربر
        # پاسخِ آن سؤال است، نه یک پیامِ کاملاً تازه -- باید همین‌جا
        # تفسیر شود، نه اینکه از نو وارد IntentEngine شود (که با متنِ
        # کوتاهی مثلِ «آب‌وهوا» یا «همون اولی» ممکن است دوباره نامطمئن
        # باشد).
        # ==========================================
        if ai._pending_disambiguation is not None:
            pending = ai._pending_disambiguation
            ai._pending_disambiguation = None
            matched = disambiguator.match_clarification_reply(user_input, pending["top_two"])
            if matched:
                # نکته: ``trace`` همینِ نوبتِ جاری است (نه نوبتی که سؤال
                # را پرسید -- آن یکی قبلاً در tool_router.py بسته شد).
                # اینجا فقط mark می‌کنیم و اجازه می‌دهیم ``_execute_route``
                # → ``finalize`` طبقِ روالِ عادی آن را ببندد -- دقیقاً
                # همان الگویِ خطِ پایینِ همین متد (تشخیصِ نیتِ معمولی).
                trace.mark(
                    selected_route="ambiguity_resolved_direct_match",
                    detected_intent=matched,
                    confidence=1.0,
                )
                await ai._execute_route(matched, 1.0, pending["original_text"])
                return True
            # پاسخِ کاربر با هیچ‌کدام از دو نامزد مستقیماً مطابقت نداشت
            # (مثلاً یک توضیحِ تازه داد). به‌جایِ حدسِ کورکورانه‌ی یکی از
            # آن دو، متنِ اصلی + این توضیح را با هم به تشخیصِ کاملِ نیت
            # می‌سپاریم -- محافظه‌کارتر از انتخابِ اجباریِ یکی از دو گزینه.
            combined_text = f"{pending['original_text']} {user_input}".strip()
            intent, confidence, _ = IntentEngine.detect_intent(combined_text, ai.modes, ai.db)
            trace.mark(
                selected_route="ambiguity_resolved_combined_reroute",
                detected_intent=intent,
                confidence=confidence,
            )
            await ai._execute_route(intent, confidence, combined_text)
            return True

        # ==========================================
        #   حلقه‌ی بازخورد/یادگیریِ محلیِ IntentEngine
        # ------------------------------------------
        # گامِ ۵ روادمپِ ماژولارسازی: اگر منتظرِ توضیحِ کاربر دربابِ نیتِ
        # واقعیِ پیامِ قبلی هستیم، همین پیام را برچسبِ آن نیت می‌زنیم و
        # در sqlite ذخیره می‌کنیم؛ در غیرِ این‌صورت، اگر کاربر همین الان
        # با عبارتی مثلِ «نه منظورم این نبود» به تشخیصِ اشتباه اعتراض
        # کرد، آخرین پیام را از تاریخچه می‌گیریم و توضیح می‌خواهیم.
        # ==========================================
        if ai._pending_correction is not None:
            original_query = ai._pending_correction
            ai._pending_correction = None
            guessed_intent, _, _ = IntentEngine.detect_intent(user_input, ai.modes, ai.db)
            intent_feedback.record_correction(original_query, guessed_intent, ai.db)
            answer = (
                f"ممنون! یاد گرفتم که «{original_query}» یعنی «{guessed_intent}». "
                "دفعه‌ی بعد بهتر تشخیص می‌دم."
            )
            trace.mark(
                selected_route="intent_correction_feedback",
                detected_intent=guessed_intent,
                final_response=answer[:300],
            )
            await ai._present(answer, "🧠 یادگیری", "cyan")
            ai.trace_log.push(trace.finish())
            return True

        if intent_feedback.is_correction_trigger(user_input):
            last_turn = ai.db.get_last_turn()
            if last_turn and last_turn[0]:
                ai._pending_correction = last_turn[0]
                answer = (
                    f"باشه! پس منظورت از «{last_turn[0]}» دقیقاً چی بود؟ "
                    "با یه جمله‌ی ساده بگو (مثلاً «می‌خواستم ترجمه کنم» یا «دنبال آب‌وهوا بودم»)."
                )
                trace.mark(selected_route="intent_correction_prompt", final_response=answer[:300])
                await ai._present(answer, "🧠 تصحیح", "cyan")
                ai.trace_log.push(trace.finish())
                return True

        # ==========================================
        #   ادامه‌ی گفتگوی پزشکیِ فعال (سؤال بله/خیر)
        # ------------------------------------------
        # اگر سؤال پیگیری پرسیده شده، ورودیِ بعدیِ کاربر باید
        # همان لحظه به‌عنوان پاسخِ آن سؤال تفسیر شود، نه اینکه
        # از نو وارد تشخیص نیت (IntentEngine) شود؛ وگرنه یک
        # پاسخ ساده مثل «بله» به‌عنوان پیام نامفهوم رد می‌شد.
        # ==========================================
        medical_session_key = self.medical_session_key()
        if ai.medical_engine.has_active_dialogue(medical_session_key):
            start_time = time.time()
            result = ai.medical_engine.answer_symptom_check(medical_session_key, user_input)
            # قبلاً اینجا فقط پیامِ محلی نشان داده می‌شد و به همین بسنده
            # می‌شد -- حتی اگر پایگاه‌دانشِ محلیِ کوچک شواهدِ ضعیفی داشت.
            # الان اگر گفتگو به یک نتیجه‌ی *غیرقطعی* رسیده باشد (result
            # از dialogue/manager.py حالا کلیدِ "sufficient" را هم دارد)،
            # قبل از نمایشِ نهایی، منابعِ آنلاین (MedlinePlus/ویکی‌پدیا)
            # هم برایِ تکمیل بررسی می‌شوند.
            if result.get("done") and not result.get("emergency") and not result.get("sufficient", True):
                query = "، ".join(result.get("symptoms_identified") or []) or result.get("top_diagnosis") or user_input
                try:
                    online_info = await fetch_online_medical_info(query, ai.session)
                except Exception:  # noqa: BLE001 - نبودِ اینترنت نباید گفتگو را متوقف کند
                    online_info = None
                if online_info:
                    result["message"] = (
                        f"🏠 **نزدیک‌ترین تطبیقِ پایگاه‌دانشِ محلی (شواهد محدود):**\n\n{result['message']}\n\n"
                        f"🌐 **اطلاعاتِ تکمیلی از منابعِ آنلاین:**\n\n{online_info}\n\n"
                        f"⚠️ این بخش خلاصه‌ی نتایجِ جستجویِ وب است، نه تشخیصِ قطعی؛ "
                        f"برای تشخیصِ دقیق حتماً به پزشک مراجعه کنید."
                    )
            answer = result["message"]
            if result.get("emergency"):
                ai.ui.show_emergency(answer)
            elif not result.get("done", True):
                ai.ui.show_followup_question(answer)
            else:
                await ai._present(answer, "🏥 پاسخ پزشکی | منبع: Medical AI", "bright_red")
            trace.mark(
                selected_route="medical_dialogue_continuation",
                tool_execution="MedicalAIEngine.answer_symptom_check",
                fallback_used=not result.get("done", True),
            )
            if result.get("done", True):
                ai.cache.set(user_input, answer, "medical")
                self.finalize(user_input, answer, start_time, "medical", 1.0)
            else:
                # سؤالِ پیگیری هنوز تمام نشده -- finalize توسطِ نوبتِ
                # بعدی (وقتی گفتگو done شود) صدا زده می‌شود؛ فعلاً خودِ
                # trace را همین‌جا می‌بندیم تا در «ردیابی» گم نشود.
                ai.trace_log.push(trace.finish())
            return True

        # ==========================================
        #   ادامه‌ی جلسه‌ی فعالِ همراهِ روان‌شناختی
        # ------------------------------------------
        # بدونِ این بلوک، همراهیِ روان‌شناختی فقط تا وقتی کار می‌کرد که
        # پیامِ کاربر دوباره دقیقاً یکی از کلیدواژه‌های احساسی را داشته
        # باشد. اما یک گفتگویِ واقعیِ «درد دل» معمولاً بعد از جمله‌ی اول
        # کاملاً بدونِ آن کلیدواژه‌ها ادامه پیدا می‌کند. این بلوک دقیقاً
        # همان الگویِ has_active_dialogue بالا را برایِ جلسه‌ی همراهیِ
        # روان‌شناختی تکرار می‌کند، به‌شرطی که پیام واضحاً به یک قابلیتِ
        # کاملاً دیگر (ساعت/آب‌وهوا/محاسبه/...) اشاره نداشته باشد --
        # وگرنه اجازه می‌دهیم مسیریابیِ عادیِ نیت آن را پردازش کند.
        # ==========================================
        if ai.medical_engine.therapy.has_active_session(
            medical_session_key
        ) and not ai.medical_engine.therapy.looks_like_unrelated_command(user_input):
            start_time = time.time()
            result = ai.medical_engine.therapy.respond(medical_session_key, user_input)
            answer = result["message"]
            if result.get("emergency"):
                ai.ui.show_emergency(answer)
            else:
                await ai._present(answer, "💙 همراه شما | Therapy Companion", "bright_magenta")
            trace.mark(
                selected_route="therapy_session_continuation",
                tool_execution="TherapyCompanion.respond",
            )
            self.finalize(user_input, answer, start_time, "emotional_support", 1.0)
            return True

        intent, confidence = self._detect_intent(user_input)
        trace.mark(detected_intent=intent, confidence=confidence)
        await ai._execute_route(intent, confidence, user_input)
        return True

    # ------------------------------------------------------------------
    #   تشخیصِ نیت -- سامانه‌ی هوشمندیِ مکالمه (در صورتِ فعال‌بودن) +
    #   بازگشتِ خودکار به IntentEngine قدیمی
    # ------------------------------------------------------------------
    def _detect_intent(self, user_input: str) -> tuple[str, float]:
        """
        اگر ``trx_ai.conversation`` فعال باشد (``TRX_CONV_INTELLIGENCE_ENABLED``)،
        اول از طریقِ ``conversation_engine.process`` (نرمال‌سازی → context →
        احساس → موضوع → پیوستگی → نامزدهایِ intent → داوری → Action Gate →
        نقد) تصمیم گرفته می‌شود. اگر این سیستم خاموش باشد، خطا بدهد، یا
        ``None`` برگرداند (سیگنالِ صریحِ «نتوانستم تصمیم بگیرم»)، بی‌صدا و
        فوری به همان ``IntentEngine.detect_intent`` قدیمی برمی‌گردیم --
        یعنی رفتارِ پیش‌فرضِ TRX هیچ‌وقت به این لایه‌ی جدید *وابسته* نیست،
        فقط در صورتِ فعال‌ و موفق‌بودن از آن *بهره* می‌برد.
        """
        ai = self.ai
        if conv_config.CONVERSATION_INTELLIGENCE_ENABLED:
            try:
                recent_text = ai.conversation_patterns._recent_context_text()
            except Exception:  # noqa: BLE001
                recent_text = ""
            try:
                topic_hint = ai.memory.extract_topic_entity(user_input)
            except Exception:  # noqa: BLE001
                topic_hint = None
            conversation_id = getattr(ai.session_mgr, "active_session", None) or "default"
            result = conversation_engine.process(
                user_input,
                conversation_id=conversation_id,
                context_modes=ai.modes,
                db=ai.db,
                recent_messages=[recent_text] if recent_text else [],
                topic_hint=topic_hint,
            )
            if result is not None:
                intent, confidence, _ = result
                return intent, confidence

        intent, confidence, _ = IntentEngine.detect_intent(user_input, ai.modes, ai.db)
        return intent, confidence

    # ------------------------------------------------------------------
    #   نوبتِ عکس
    # ------------------------------------------------------------------
    async def process_image_turn(self, raw_bytes: bytes, mime_type: str, caption: str = "") -> None:
        """
        پردازشِ یک نوبتِ «عکس»: همان جایگاهی که `process_turn` برایِ
        متن دارد، اینجا برایِ تصویر. سه رابط (وب/GUI/آینده‌یِ CLI) همه
        باید از همینِ یک متد استفاده کنند، نه هرکدام منطقِ خودشان را
        داشته باشند.

        دسته‌بندیِ عمل بر اساسِ کپشنِ همراهِ عکس (`vision.classify_image_caption`):
            «متن»/«بخون»/«استخراج»  → OCR محلی (pytesseract)
            «کیفیت»/«واضح»/«شارپ»  → بهبودِ کیفیتِ محلی (بدونِ نیاز به اینترنت)
            هرچیزِ دیگر (یا خالی)    → تحلیلِ فنیِ محلیِ تصویر (Vision Super)
        """
        ai = self.ai
        start_time = time.time()
        caption = (caption or "").strip()
        # ==========================================
        #   لایه‌ی مشاهده‌پذیری -- تا قبل از این ارتقا، نوبت‌هایِ عکس/فایل
        #   هیچ trace نمی‌ساختند (فقط `process_turn` این کار را می‌کرد)،
        #   پس دستورِ «ردیابی» بعدِ آپلودِ یک عکس، trace نوبتِ متنیِ
        #   *قبلی* را نشان می‌داد -- گمراه‌کننده، دقیقاً نمونه‌ای از
        #   «توهمِ پیشرفت» (ادعایِ observability کامل، ولی نه واقعاً).
        #   همان الگویِ ``process_turn``: هر شاخه‌ای که زودتر برمی‌گردد
        #   خودش trace را می‌بندد؛ شاخه‌هایی که به ``finalize`` می‌رسند
        #   نیازی به این کار ندارند.
        # ==========================================
        trace = TraceRecorder(f"[عکس] {caption}".strip())
        ai.current_trace = trace
        try:
            saved_path = ai.image_engine.save_incoming(raw_bytes, mime_type)
        except ImageValidationError as e:
            trace.mark(selected_route="vision:validation_error", error=str(e))
            ai.trace_log.push(trace.finish())
            ai.current_trace = None
            await ai._present(str(e), "📷 خطا در دریافتِ عکس", "red")
            return

        # برایِ ابزارِ «vision» در `trx_ai/agent` -- تا حلقه‌ی عامل بداند
        # رویِ کدام تصویر (در صورتِ نیاز، بعداً در همین جلسه) کار کند.
        ai._last_image_path = saved_path

        action = classify_image_caption(caption)

        if action == "text":
            trace.mark(selected_route="vision:ocr", tool_execution="ImageEngine.read_text")
            with ai.ui.console.status("[bold cyan]📖 در حالِ خواندنِ متنِ عکس...[/bold cyan]"):
                answer = await ai.image_engine.read_text(saved_path, session=ai.session)
            await ai._present(answer, "📷📖 متنِ استخراج‌شده از عکس", "cyan")
            self.finalize(f"[عکس] {caption}".strip(), answer, start_time, "vision_ocr", 1.0)
            return

        if action == "quality":
            trace.mark(selected_route="vision:quality_enhance", tool_execution="ImageEngine.enhance_quality")
            try:
                with ai.ui.console.status("[bold cyan]✨ در حالِ بالابردنِ کیفیتِ عکس...[/bold cyan]"):
                    enhanced_path, before_size, after_size, score_info = ai.image_engine.enhance_quality(saved_path)
            except RuntimeError as e:
                trace.mark(error=str(e))
                ai.trace_log.push(trace.finish())
                ai.current_trace = None
                await ai._present(str(e), "📷 خطا در بهبودِ کیفیت", "red")
                return
            url = f"/files/{os.path.basename(enhanced_path)}"
            if after_size != before_size:
                detail = f"ابعاد از {before_size[0]}×{before_size[1]} به {after_size[0]}×{after_size[1]} افزایش یافت (+ شارپ‌کردن و کنتراست)."
            else:
                detail = f"ابعاد ({before_size[0]}×{before_size[1]}) از قبل بزرگ بود، فقط شارپ‌کردنِ قوی‌تر و کنتراست/اشباعِ رنگ اعمال شد."
            detail += " برایِ دیدنِ تفاوتِ واقعی، رویِ عکس بزن تا در اندازه‌ی کامل باز شود (این‌جا به‌خاطرِ کوچک‌بودنِ حبابِ چت ممکن است یکسان به‌نظر برسد)."
            if score_info:
                reached = "✅" if score_info["reached_target"] else "⚠️"
                detail += (
                    f"\n{reached} نمره‌ی کیفیت: {score_info['score']:.0f}٪ "
                    f"(پس از {score_info['iterations']} تلاش)."
                )
                if not score_info["reached_target"]:
                    detail += " به هدفِ ۹۰٪ نرسید؛ این بهترین نتیجه‌ای بود که در سقفِ تلاش‌ها پیدا شد."
            ai.ui.show_image(url, "📷✨ عکسِ بهبودیافته", detail)
            self.finalize(f"[عکس] {caption}".strip(), f"عکسِ بهبودیافته: {url}", start_time, "vision_enhance", 1.0)
            return

        # پیش‌فرض: توصیف/پاسخ به سؤال دربارهٔ محتوایِ عکس
        trace.mark(selected_route="vision:describe", tool_execution="ImageEngine.describe")
        with ai.ui.console.status("[bold cyan]👁️ در حالِ دیدنِ عکس...[/bold cyan]"):
            answer = await ai.image_engine.describe(saved_path, caption, session=ai.session)
        await ai._present(answer, "📷👁️ تحلیلِ محلیِ عکس", "cyan")
        self.finalize(f"[عکس] {caption}".strip(), answer, start_time, "vision_describe", 1.0)

    # ------------------------------------------------------------------
    #   نوبتِ فایل
    # ------------------------------------------------------------------
    async def process_file_turn(self, raw_bytes: bytes, filename: str, caption: str = "") -> None:
        """
        پردازشِ یک نوبتِ «آپلودِ فایل» (رابطِ وب): معادلِ دستورِ متنیِ
        «بخوان <مسیر>» (همان ``FileManager.read_file``)، با این تفاوت که
        کاربرِ وب می‌تواند مستقیماً از دستگاهِ خودش فایل آپلود کند.

        فرمت‌هایِ پشتیبانی‌شده دقیقاً همان‌هایِ ``FileManager`` هستند:
        PDF، Word (docx/doc)، Excel (xlsx/xls)، متن/کد (txt/py/json/csv/
        html/css/js/md)، و عکس (که در این مسیر فقط ابعاد/فرمتش گزارش
        می‌شود -- برایِ توصیفِ کاملِ عکس از دکمه‌ی 📷 استفاده کنید).
        """
        ai = self.ai
        start_time = time.time()
        caption = (caption or "").strip()
        filename = (filename or "فایل").strip()
        # لایه‌ی مشاهده‌پذیری -- همان دلیلِ ``process_image_turn`` بالا:
        # بدونِ این، «ردیابی» بعدِ آپلودِ فایل، trace نوبتِ متنیِ قبلی را
        # نشان می‌داد.
        trace = TraceRecorder(f"[فایل: {filename}] {caption}".strip())
        ai.current_trace = trace
        try:
            saved_path = FileManager.save_incoming(raw_bytes, filename, files_dir=OS_FILES_DIR)
        except FileValidationError as e:
            trace.mark(selected_route="file:validation_error", error=str(e))
            ai.trace_log.push(trace.finish())
            ai.current_trace = None
            await ai._present(str(e), "📎 خطا در دریافتِ فایل", "red")
            return

        trace.mark(selected_route="file:read", tool_execution="FileManager.read_file")
        with ai.ui.console.status("[bold cyan]📂 در حالِ خواندنِ فایل...[/bold cyan]"):
            answer = FileManager.read_file(saved_path)

        title = f"📎 فایلِ آپلودشده: {filename}"
        if caption:
            title += f" | یادداشت: {caption}"
        await ai._present(answer, title, "cyan")
        self.finalize(f"[فایل: {filename}] {caption}".strip(), answer, start_time, "file_reader", 1.0)

    # ------------------------------------------------------------------
    #   مدِ مفسرِ کدِ فارسی
    # ------------------------------------------------------------------
    async def run_persian_interpreter_mode(self) -> None:
        ai = self.ai
        if ai._is_gui:
            # مدِ REPL چندخطیِ مفسر فارسی هنوز برایِ رابطِ گرافیکی
            # پیاده‌سازی نشده (نیازمندِ یک ویجتِ ورودیِ چندخطیِ اختصاصی
            # است، نه چت). به‌جایِ فریز کردن (منتظرِ inputِ ترمینالی که
            # هرگز نمی‌رسد)، به‌صراحت اعلام می‌کند که فعلاً فقط در نسخه‌ی
            # ترمینالی در دسترس است.
            ai.ui.console.print(
                "🐍 مدِ مفسرِ کدِ فارسی فعلاً فقط در نسخه‌ی ترمینالیِ TRX AI در دسترس است."
            )
            return
        ai.ui.console.print(Panel(
            "[bold green]🐍 مد مفسر کد فارسی (آسان‌کد X) فعال شد.[/bold green]\n\n"
            "کد فارسی خود را خط به خط وارد کنید.\n"
            "برای اجرا: [bold yellow]پایان[/bold yellow] | "
            "برای خروج: [bold red]خروج از مد[/bold red]",
            border_style="green"
        ))
        ai._persian_code_buffer = ""
        auto_confirm = False

        while True:
            try:
                line = await ai._input_fn("🐍 >>> ")
            except (KeyboardInterrupt, EOFError):
                break

            if line.strip() == "خروج از مد":
                ai.modes = {k: False for k in ai.modes}
                ai.ui.console.print("[bold spring_green1]🤖 به مد چت عمومی بازگشت.[/bold spring_green1]")
                break

            if line.strip() == "پایان":
                if ai._persian_code_buffer.strip():
                    ai.ui.console.print("\n[bold yellow]⚙️ در حال اجرا...[/bold yellow]")
                    result = ai.persian_interpreter.smart_execute(ai._persian_code_buffer, auto_confirm)
                    await ai.ui.animated_print(result, "🐍 خروجی مفسر فارسی", "green")
                    ai.db.add_history_record(
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        f"[کد فارسی]\n{ai._persian_code_buffer[:200]}",
                        result[:500], 0, "Persian Interpreter", "persian_interpreter", 1.0
                    )
                ai._persian_code_buffer = ""
            else:
                ai._persian_code_buffer += line + "\n"

    # ------------------------------------------------------------------
    #   کمکی‌های حافظه/پزشکی/ثبتِ نهایی/پروفایل
    # ------------------------------------------------------------------
    async def search_memory(self, query: str):
        """جستجوی معنایی در حافظه"""
        results = self.ai.memory.get_relevant_memory(query, limit=5)
        if results:
            response = "🧠 نتایج جستجوی حافظه:\n\n"
            for i, result in enumerate(results, 1):
                response += f"{i}. {result.get('content', '')[:200]}\n"
                if result.get('metadata'):
                    response += f"   📌 {result['metadata']}\n"
                response += f"   📊 امتیاز: {result.get('score', 0):.2f}\n\n"
            return response
        return None

    def medical_session_key(self) -> str:
        """کلید جلسه‌ی گفتگوی پزشکی؛ هر «پروژه»/نشست فعال، گفتگوی پیگیریِ خودش را دارد."""
        return self.ai.session_mgr.active_session or "default"

    async def handle_medical_query(self, text: str) -> dict:
        """
        پردازش درخواست پزشکی با موتور پزشکی پیشرفته و متصل به اینترنت.

        خروجی یک دیکشنری {"done": bool, "message": str} است: اگر «done»
        نادرست باشد، یعنی موتور پزشکی یک سؤال پیگیریِ بله/خیر پرسیده و
        پاسخ بعدیِ کاربر باید به همین گفتگو برسد (نه به مسیریابیِ عادیِ نیت).
        """
        ai = self.ai
        session_key = self.medical_session_key()
        if ai.personality == "دکتر کامل":
            response = await ai.medical_engine.format_medical_response_online(
                text, ai.session, ai.personality, session_key=session_key
            )
        else:
            response = await ai.medical_engine.handle_medical_query_online(
                text, ai.session, session_key=session_key
            )
        return response

    def finalize(self, query: str, response: str, start_time: float, intent: str, confidence: float) -> None:
        """ثبت نهایی پاسخ در تاریخچه و حافظه"""
        ai = self.ai
        latency = int((time.time() - start_time) * 1000)
        ai._response_times.append(latency)
        ai.db.add_history_record(
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            query[:200],
            response[:500],
            latency,
            intent=intent,
            confidence=confidence
        )
        # استخراج Entity/موضوع از پیام کاربر برای تغذیه‌ی entity_stack؛
        # بدون این خط، ارجاعِ ضمایر هرگز داده‌ای برای کار کردن نداشت
        # چون قبلاً هیچ‌جا topic به add_message داده نمی‌شد.
        topic = ai.memory.extract_topic_entity(query)
        ai.memory.add_message("user", query, topic=topic)
        ai.memory.add_message("assistant", response)
        # وضعیتِ کاربر (خسته/کلافه/گیج/...) -- محورِ جداگانه از intent،
        # کاملاً محلی و آفلاین. نتیجه هم در حافظه‌ی نشستِ کوتاه‌مدت (TTL)
        # ثبت می‌شود و هم به‌عنوانِ یک فیلدِ اضافه وارد Pattern Signature می‌شود.
        state_result = user_state_engine.detect(
            query, context_text=ai.conversation_patterns._recent_context_text(), db=ai.db,
        )
        ai.user_state_memory.update(state_result)

        # یادگیری الگو بلافاصله محلی انجام می‌شود؛ بنابراین حتی بدون API هم
        # مکالمه‌های قبلی به سبک/راهبرد قابل بازیابی تبدیل می‌شوند.
        ai.conversation_patterns.observe("user", query, user_state=state_result.primary_state)
        ai.conversation_patterns.observe("assistant", response)

        # ==========================================
        #   لایه‌ی مشاهده‌پذیری -- finalize از قبل تنها قیفِ مشترکِ تقریباً
        #   همه‌ی مسیرهایِ واقعیِ پاسخ است (کش/حافظه/پزشکی/همراهِ
        #   روان‌شناختی/محاسبه‌گر/مترجم/پاسخِ عمومی/...)؛ همین‌جا trace را
        #   با داده‌هایی که همین الان محاسبه شدند (وضعیتِ کاربر، latency)
        #   تکمیل و ذخیره می‌کنیم. اگر به هر دلیلی trace ساخته نشده باشد
        #   (مثلاً فراخوانیِ مستقیم از یک تست/اسکریپت)، بی‌صدا رد می‌شویم --
        #   observability هرگز نباید مسیرِ اصلی را بشکند.
        # ==========================================
        trace = getattr(ai, "current_trace", None)
        if trace is not None:
            trace.mark(
                detected_intent=trace.data.detected_intent or intent,
                confidence=trace.data.confidence if trace.data.confidence is not None else confidence,
                user_state=state_result.primary_state,
                final_response=(response or "")[:300],
                latency_ms=latency,
            )
            trace_log = getattr(ai, "trace_log", None)
            if trace_log is not None:
                trace_log.push(trace.finish())
            ai.current_trace = None

    async def load_profile(self) -> None:
        ai = self.ai
        saved_name = ai.db.get_profile("user_name")
        saved_personality = ai.db.get_profile("personality")
        saved_session = ai.db.get_profile("last_session")

        if saved_personality:
            ai.personality = saved_personality
        if saved_session:
            ai.session_mgr.switch_session(saved_session)

        if saved_name:
            ai.user_name = saved_name
        elif ai._user_name_preset:
            # رابطِ گرافیکی نامِ کاربر را از قبل (با دیالوگِ Qt) تنظیم
            # کرده؛ نیازی به پرسیدنِ دوباره از طریقِ ورودیِ ترمینالی نیست.
            ai.db.set_profile("user_name", ai.user_name)
        else:
            ai.ui.console.print(Panel(
                "[bold yellow]👋 سلام! خوش آمدید به TRX AI v20.[/bold yellow]\n"
                "لطفاً نام خود را وارد کنید:",
                border_style="gold1"
            ))
            name = await ai._input_fn("✍️ نام شما: ")
            name = name.strip() or "کاربر محترم"
            ai.db.set_profile("user_name", name)
            ai.user_name = name
