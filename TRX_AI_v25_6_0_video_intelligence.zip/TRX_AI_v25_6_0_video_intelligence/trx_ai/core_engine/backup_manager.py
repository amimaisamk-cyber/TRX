# -*- coding: utf-8 -*-
"""
مدیریتِ پشتیبان‌گیری/بازیابیِ کاملِ داده‌هایِ کاربر (پروفایل، دانش،
کارها، خرج‌ها، تاریخچه). این تنها بخشِ برنامه است که می‌تواند داده‌های
موجود را به‌طورِ کامل جایگزین کند (``overwrite=True``)، پس عمداً از
منطقِ مسیریابیِ معمولی (``tool_router.py``) جدا نگه داشته شده تا
مسئولیتِ «این عمل خطرناک است، تأییدِ صریح لازم دارد» فقط در یک فایل
متمرکز باشد.
"""

from __future__ import annotations

import json
import os
from datetime import datetime

from ..logging_config import get_logger

logger = get_logger(__name__)

__all__ = ["BackupManager"]

_BACKUP_DIR = "backups"
_BACKUP_PREFIX = "trx_backup_"
_BACKUP_SUFFIX = ".json"


class BackupManager:
    """پشتیبان‌گیری/بازیابیِ کاملِ داده‌هایِ کاربر، پشتِ یک تأییدِ صریح."""

    def __init__(self, ai) -> None:
        self.ai = ai

    def create_backup(self) -> str:
        """
        کلِ داده‌های کاربر (پروفایل، دانش، کارها، خرج‌ها، تاریخچه) را به
        یک فایلِ JSON با برچسبِ زمانی می‌نویسد، در پوشه‌ی `backups/`.
        """
        try:
            os.makedirs(_BACKUP_DIR, exist_ok=True)
            data = self.ai.db.export_all_data()
            filename = f"{_BACKUP_PREFIX}{datetime.now().strftime('%Y%m%d_%H%M%S')}{_BACKUP_SUFFIX}"
            filepath = os.path.join(_BACKUP_DIR, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            size_kb = os.path.getsize(filepath) / 1024
            return (f"✅ پشتیبان‌گیری کامل شد: `{os.path.abspath(filepath)}` ({size_kb:.1f} KB)\n"
                    f"برای بازیابی از آخرین پشتیبان: بگو «بازیابی».")
        except Exception as e:
            logger.exception("خطای پشتیبان‌گیری: %s", e)
            return f"❌ پشتیبان‌گیری ناموفق بود: {e}"

    def find_latest_backup(self):
        """
        مسیرِ جدیدترین فایلِ پشتیبان در `backups/` را برمی‌گرداند، یا
        None (به‌همراه پیامِ خطا) اگر چیزی پیدا نشد. جدا از
        do_restore_latest_backup چون هم برایِ نمایشِ پیامِ تأیید (قبل
        از هر کاری) و هم برایِ خودِ بازیابی لازم است.
        """
        if not os.path.isdir(_BACKUP_DIR):
            return None, "❌ هنوز هیچ پشتیبانی گرفته نشده (پوشه‌ی backups وجود ندارد)."
        files = [
            f for f in os.listdir(_BACKUP_DIR)
            if f.startswith(_BACKUP_PREFIX) and f.endswith(_BACKUP_SUFFIX)
        ]
        if not files:
            return None, "❌ هیچ فایلِ پشتیبانی پیدا نشد."
        latest = max(files, key=lambda f: os.path.getmtime(os.path.join(_BACKUP_DIR, f)))
        return os.path.join(_BACKUP_DIR, latest), None

    def prompt_restore_confirmation(self) -> str:
        """
        قدمِ اولِ «بازیابی»: هنوز هیچ داده‌ای دست نمی‌خورد، فقط جدیدترین
        فایلِ پشتیبان را پیدا و معرفی می‌کند و منتظرِ تأییدِ صریحِ کاربر
        می‌ماند (پرچمِ ai._pending_restore در turn_processor بررسی
        می‌شود). چون این عمل با overwrite=True داده‌های فعلیِ
        tasks/expenses/history را کاملاً جایگزین می‌کند، نباید فقط با
        گفتنِ یک کلمه («بازیابی») بی‌سروصدا انجام شود.
        """
        filepath, error = self.find_latest_backup()
        if error:
            return error
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            exported_at = data.get("exported_at", "نامشخص")
        except Exception as e:
            logger.exception("خطای خواندنِ فایلِ پشتیبان برایِ نمایشِ تأیید: %s", e)
            return f"❌ خواندنِ فایلِ پشتیبان ناموفق بود: {e}"

        self.ai._pending_restore = True
        return (
            f"⚠️ آخرین پشتیبان: `{os.path.basename(filepath)}` (گرفته‌شده در {exported_at}).\n"
            f"بازیابی، داده‌های فعلیِ کارها/خرج‌ها/تاریخچه را با محتوایِ همین فایل "
            f"**جایگزین** می‌کند (نه اضافه). برای ادامه بگو «بله»، برای انصراف هر چیزِ دیگری."
        )

    def do_restore_latest_backup(self) -> str:
        """اجرای واقعیِ بازیابی — فقط بعد از تأییدِ صریحِ کاربر صدا زده می‌شود."""
        try:
            filepath, error = self.find_latest_backup()
            if error:
                return error
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            # overwrite=True: «بازیابی» یعنی برگرداندنِ وضعیتِ همان لحظه‌ی
            # پشتیبان‌گیری، نه اضافه‌کردنِ یک کپیِ دیگر رویِ داده‌هایِ
            # فعلی. قبلاً این فراخوانی overwrite را نمی‌داد (پیش‌فرضِ
            # False)، پس هر بار که کاربر «بازیابی» می‌گفت، tasks/expenses/
            # history یک نسخه‌ی تکراری از همان داده‌ها می‌گرفتند.
            imported = self.ai.db.import_all_data(data, overwrite=True)
            return f"✅ بازیابی از `{os.path.basename(filepath)}` انجام شد ({imported} ردیف بازگردانده شد)."
        except Exception as e:
            logger.exception("خطای بازیابی: %s", e)
            return f"❌ بازیابی ناموفق بود: {e}"
