# -*- coding: utf-8 -*-
"""
State Tracker سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۳ سند).

طبقِ سند: «Conversation State با Long-Term Memory یکی نیست؛ state
برایِ همین مکالمه است.» بنابراین این ماژول عمداً:
    - در حافظه‌یِ خودِ پردازش (RAM) نگه‌داری می‌کند، نه دیتابیس/دیسک
    - جایگزینِ ``trx_ai/memory_store.py`` نیست و به آن وابسته نیست
    - کلیدش ``conversation_id`` است -- همان چیزی که در پروژه‌یِ فعلی
      ``ai.session_mgr.active_session`` نامیده می‌شود (نگاه کنید به
      ``TurnProcessor.medical_session_key``) -- تا هر «پروژه»/نشستِ
      فعال، وضعیتِ مکالمه‌یِ خودش را داشته باشد، دقیقاً هم‌شکلِ الگویِ
      موجودِ ``medical_session_key``.

محدودیتِ عمدیِ محیطِ Android/Pydroid: هیچ حدی رویِ تعدادِ نشست‌هایِ
هم‌زمان معمولاً لازم نیست (یک کاربر، چند «پروژه»)، اما برایِ جلوگیریِ
نشتِ حافظه در اجرایِ طولانی‌مدت، یک سقفِ ساده روی تعدادِ نشست‌هایِ
نگه‌داشته‌شده گذاشته شده (LRU ساده با dict ترتیب‌دار).
"""

from __future__ import annotations

import threading
from dataclasses import replace

from .schemas import ContextSnapshot

_MAX_TRACKED_CONVERSATIONS = 200

_lock = threading.Lock()
_sessions: dict[str, ContextSnapshot] = {}


def get_snapshot(conversation_id: str) -> ContextSnapshot:
    """برشِ فعلیِ وضعیتِ مکالمه؛ اگر نشستِ تازه‌ای باشد، یک Snapshotِ خالی می‌سازد."""
    with _lock:
        snap = _sessions.get(conversation_id)
        if snap is None:
            snap = ContextSnapshot()
            _sessions[conversation_id] = snap
        return snap


def update_snapshot(conversation_id: str, **changes) -> ContextSnapshot:
    """
    فیلدهایِ داده‌شده را رویِ Snapshotِ فعلی اعمال می‌کند (``dataclasses.replace``
    -- immutable، بدونِ اثرِ جانبیِ پنهان روی نسخه‌ی قبلی) و نسخه‌یِ
    جدید را ذخیره/برمی‌گرداند.
    """
    with _lock:
        current = _sessions.get(conversation_id, ContextSnapshot())
        updated = replace(current, **changes)
        _sessions[conversation_id] = updated
        if len(_sessions) > _MAX_TRACKED_CONVERSATIONS:
            # ساده‌ترین LRU: قدیمی‌ترین کلیدِ dict (ترتیبِ درج در پایتون
            # ۳.۷+ تضمین‌شده) را حذف کن. هزینه‌یِ محاسباتی ناچیز است
            # چون فقط وقتی سقف رد شود اجرا می‌شود.
            oldest_key = next(iter(_sessions))
            if oldest_key != conversation_id:
                _sessions.pop(oldest_key, None)
        return updated


def reset_snapshot(conversation_id: str) -> None:
    with _lock:
        _sessions.pop(conversation_id, None)


def active_conversation_count() -> int:
    with _lock:
        return len(_sessions)
