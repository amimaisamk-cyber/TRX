# -*- coding: utf-8 -*-
"""
Response Planner سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۱۰ سند).

نکته‌یِ معماریِ مهم -- چرا این ماژول متنِ پاسخ را تولید نمی‌کند:
طبقِ اصلِ ۸ سند («Core فقط هماهنگ‌کننده باشد») و نکته‌یِ «اتصال به
Native Model» («تصمیمِ ابزار فعلاً deterministic بماند؛ مدل فقط
advisory است»)، تولیدِ واقعیِ متنِ پاسخ همچنان وظیفه‌یِ موتورهایِ
مجرب و از‌قبل‌موجودِ پروژه است:
    - ``TherapyCompanion`` برایِ حمایتِ احساسی (خیلی پیشرفته‌تر از
      یک ماژولِ تازه‌ساز -- گفتگویِ پیگیری، تشخیصِ اورژانس، ...)
    - ``SmallTalkEngine`` برایِ گفتگویِ آزادِ روزمره
    - ``ToolRouter`` برایِ ابزارها

پس کارِ این ماژول این است: با توجه به ``RoutingDecision`` +
``ContextSnapshot`` + رابطه‌یِ موضوعی، یک ``ResponsePlan`` (که چه
جنبه‌هایی باید رعایت شوند) بسازد و **کدامِ یک از مسیرهایِ مکالمه‌ایِ
موجود** باید نهایتاً پاسخ را بسازد را در ``selected_intent`` (رویِ
خودِ ``RoutingDecision``) نهایی/تأیید کند -- نوشتنِ متن، نه اینجا.

طراحیِ باز برایِ آینده: وقتی/اگر ``response_composer.py`` مستقل
لازم شد (مثلاً برایِ حالت‌هایی که هیچ‌کدام از مسیرهایِ موجود مناسب
نیستند)، این ``ResponsePlan`` دقیقاً همان ورودی‌ای‌ست که آن ماژول
لازم دارد -- الان تولید می‌شود، حتی قبل از آنکه مصرف‌کننده‌اش آماده
باشد، تا این گام بعداً فقط «افزودنِ یک مصرف‌کننده‌یِ جدید» باشد، نه
«بازطراحیِ دوباره‌یِ داده».
"""

from __future__ import annotations

from .schemas import ContextSnapshot, EmotionReading, ModuleHealth, ModuleResult, ResponsePlan, TopicRelation

_NEGATIVE_EMOTIONS = frozenset({"sad", "tired", "angry", "anxious", "disappointed"})


def plan(
    *,
    emotion: EmotionReading,
    relation: TopicRelation,
    context: ContextSnapshot,
) -> ModuleResult:
    try:
        reflect = emotion.emotion in _NEGATIVE_EMOTIONS or emotion.mixed_emotion
        acknowledge = relation in (
            TopicRelation.CONTINUATION, TopicRelation.EXPLANATION,
            TopicRelation.CAUSE, TopicRelation.CONSEQUENCE, TopicRelation.CONTRAST,
        )
        mention_cause = relation == TopicRelation.CAUSE or bool(context.known_cause)
        ask_followup = reflect and relation != TopicRelation.CORRECTION

        tone = "warm" if reflect else "neutral"
        length = "short" if reflect else "short"  # طبقِ سند، طولِ پاسخِ پیش‌فرض کوتاه بماند

        response_plan = ResponsePlan(
            acknowledge_context=acknowledge,
            reflect_emotion=reflect,
            mention_cause=mention_cause,
            answer_question=(relation == TopicRelation.ANSWER_TO_QUESTION),
            ask_followup=ask_followup,
            tone=tone,
            length=length,
            avoid=("generic_template",) if reflect else (),
        )
        return ModuleResult(value=response_plan, confidence=0.7)
    except Exception as exc:  # noqa: BLE001
        return ModuleResult(value=ResponsePlan(), health=ModuleHealth.FALLBACK, confidence=0.0, error=str(exc))
