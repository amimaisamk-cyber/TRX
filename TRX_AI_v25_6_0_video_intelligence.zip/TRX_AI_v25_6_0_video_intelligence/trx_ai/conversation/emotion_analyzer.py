# -*- coding: utf-8 -*-
"""
Emotion Analyzer سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۴ سند).

تصمیمِ معماریِ کلیدی: این ماژول یک موتورِ تشخیصِ احساسِ *جدید* نیست.
پروژه از قبل ``trx_ai/nlu/user_state.py`` را دارد -- یک موتورِ
چندلایه (کلیدواژه/مترادف/فازی/معنایی/context) که دقیقاً همین کار را
می‌کند و حتی uncertainty را هم مدل کرده. ساختِ یک موتورِ دومِ موازی
دقیقاً همان «سیستم‌هایِ متناقضِ موازی» است که سند در اصلِ ۸ قدغن کرده.

پس کارِ این فایل فقط دو چیز است:
    ۱. نگاشتِ واژگانِ ``user_state`` (tired, frustrated, stressed, ...)
       به واژگانِ سندِ Conversation Intelligence (tired, anxious, ...)
    ۲. تشخیصِ ``mixed_emotion`` -- چیزی که ``user_state`` فعلاً ندارد:
       وقتی احساسِ فعلی با احساسِ *قبلی* (از ``ContextSnapshot``)
       ناسازگار است و یک نشانگرِ تقابل («اما»، «ولی»، «با این حال»)
       هم در جمله هست (مثالِ خودِ سند: «خسته شدم... اما واقعاً
       خوشحالم» → mixed/contrast=true).
"""

from __future__ import annotations

import re
import time

from ..nlu import user_state as _user_state_engine
from .schemas import EmotionReading, ModuleHealth, ModuleResult

# نگاشتِ دسته‌هایِ ``user_state_registry`` به واژگانِ سند. دسته‌هایی که
# در ``user_state`` نیستند (relieved, proud, disappointed) عمداً اینجا
# تولید نمی‌شوند -- گزارشِ نادرست بهتر از حدسِ ساختگی نیست، پس آن‌ها
# بعداً وقتی خودِ user_state_registry گسترش یابد اضافه می‌شوند
# (Unverified -- نیازمندِ گسترشِ registry، نه این فایل).
_STATE_TO_EMOTION = {
    "happy": "happy",
    "excited": "happy",
    "satisfied": "happy",
    "sad": "sad",
    "dissatisfied": "disappointed",
    "tired": "tired",
    "bored": "tired",
    "disengaged": "tired",
    "angry": "angry",
    "frustrated": "angry",
    "stressed": "anxious",
    "confused": "confused",
    "curious": "confused",
    "neutral": "neutral",
}

_CONTRAST_MARKERS = ("اما", "ولی", "با این حال", "درعین‌حال", "درعین حال")

# قطبِ ساده برایِ تشخیصِ ناسازگاریِ احساسِ فعلی/قبلی (نه یک مدلِ دقیق --
# فقط برایِ گیتِ mixed_emotion؛ اصلِ سند فقط می‌خواهد «تناقض» تشخیص
# داده شود، نه شدتِ دقیقِ آن).
_POLARITY = {
    "happy": 1, "relieved": 1, "proud": 1,
    "sad": -1, "tired": -1, "angry": -1, "anxious": -1, "disappointed": -1,
    "confused": 0, "neutral": 0,
}


def _has_contrast_marker(text: str) -> bool:
    return any(marker in text for marker in _CONTRAST_MARKERS)


def analyze(
    normalized_text: str,
    *,
    context_text: str = "",
    previous_emotion: str | None = None,
    db=None,
) -> ModuleResult:
    """
    ``context_text``: چند پیامِ اخیر به‌صورتِ یک رشته (همان چیزی که
    ``user_state.detect`` هم انتظار دارد -- برایِ سازگاری مستقیماً پاس
    داده می‌شود، دو بار محاسبه نمی‌شود).
    ``previous_emotion``: از ``ContextSnapshot.current_emotion`` نوبتِ
    قبل (اگر باشد) -- برایِ تشخیصِ ``mixed_emotion``.
    """
    start = time.perf_counter()
    try:
        result = _user_state_engine.detect(normalized_text, context_text=context_text, db=db)
        emotion = _STATE_TO_EMOTION.get(result.primary_state, "neutral")

        mixed = False
        if (
            previous_emotion
            and previous_emotion != emotion
            and _POLARITY.get(previous_emotion, 0) * _POLARITY.get(emotion, 0) < 0
            and _has_contrast_marker(normalized_text)
        ):
            mixed = True

        reading = EmotionReading(
            emotion=emotion,
            intensity=round(float(result.confidence), 3),
            previous_emotion=previous_emotion,
            mixed_emotion=mixed,
            known_cause=None,  # علت را topic_tracker/continuity_analyzer تعیین می‌کند
            confidence=round(float(result.confidence), 3),
            evidence=tuple(result.evidence[:5]),
        )
        health = ModuleHealth.DEGRADED if result.uncertain else ModuleHealth.OK
        latency = (time.perf_counter() - start) * 1000
        return ModuleResult(value=reading, health=health, confidence=reading.confidence, latency_ms=latency)
    except Exception as exc:  # noqa: BLE001 - اصلِ پایداری: خرابی این ماژول نباید نوبت را بترکاند
        latency = (time.perf_counter() - start) * 1000
        return ModuleResult(
            value=EmotionReading(),  # پیش‌فرضِ امن: neutral
            health=ModuleHealth.FALLBACK,
            confidence=0.0,
            error=str(exc),
            latency_ms=latency,
        )
