# -*- coding: utf-8 -*-
"""
Continuity Analyzer سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۶ سند).

طبقِ سند، امتیاز از این اجزا ساخته شود:
    semantic similarity + temporal relation + discourse markers +
    emotion relation + topic-shift penalty

پیاده‌سازیِ این نسخه عمداً *بدونِ* وابستگیِ اجباری به یک مدلِ
embedding سنگین است (فلسفه‌یِ Offline-First خودِ پروژه -- نگاه کنید
به توضیحِ مشابه در ``trx_ai/nlu/user_state.py``): «شباهتِ معنایی» با
هم‌پوشانیِ لغویِ ساده (Jaccard رویِ توکن‌ها، بعدِ حذفِ stopwordهایِ
رایج) تخمین زده می‌شود -- ارزان، بدونِ نیاز به کتابخانه، و کافی برایِ
تشخیصِ اینکه دو جمله «دربابِ همان چیز» هستند یا نه. اگر بعداً
``embedding_backend`` (که پروژه از قبل دارد) نصب/فعال بود،
می‌شود این تابع را با یک لایه‌یِ اختیاریِ شباهتِ کسینوسی تقویت کرد --
دقیقاً همان الگویِ ``semantic_enabled`` در ``nlu/types.py`` -- اما این
یک قابلیتِ *بعدی*، نه پیش‌نیازِ کارکردِ این ماژول است.

«Temporal relation» طبقِ سند به این معنی است که پیامِ *بلافاصله‌یِ*
قبلی وزنِ بیشتری از پیام‌هایِ دورتر دارد -- این وزن‌دهی از قبل در
``context_manager.build_context_bundle`` (فیلدِ ``recency``) انجام
شده؛ این ماژول همان را مصرف می‌کند، دوباره محاسبه نمی‌کند.
"""

from __future__ import annotations

import re

from .schemas import ContextFragment, ModuleHealth, ModuleResult, TopicRelation

_TOKEN_STRIP_CHARS = "().,!؟?:؛\"'«»"
_STOPWORDS = frozenset({
    "و", "یا", "که", "این", "آن", "را", "به", "از", "در", "با", "برای",
    "هم", "می", "است", "بود", "شد", "شدم", "شدی", "یک", "تا", "هر",
})

# وزنِ هر جزء در امتیازِ نهایی -- جمعشان ۱ است.
_WEIGHT_LEXICAL = 0.35
_WEIGHT_DISCOURSE = 0.30
_WEIGHT_EMOTION = 0.15
_WEIGHT_RECENCY = 0.20

# رابطه‌هایی که خودشان گواهِ قویِ پیوستگی‌اند (از topic_tracker).
_HIGH_CONTINUITY_RELATIONS = frozenset({
    TopicRelation.CONTINUATION, TopicRelation.EXPLANATION, TopicRelation.CAUSE,
    TopicRelation.CONSEQUENCE, TopicRelation.CONTRAST, TopicRelation.CORRECTION,
    TopicRelation.ANSWER_TO_QUESTION,
})
_ZERO_CONTINUITY_RELATIONS = frozenset({TopicRelation.UNRELATED, TopicRelation.TOPIC_SHIFT})


def _tokens(text: str) -> set[str]:
    raw = [t.strip(_TOKEN_STRIP_CHARS) for t in re.split(r"\s+", text or "") if t.strip(_TOKEN_STRIP_CHARS)]
    return {t for t in raw if t not in _STOPWORDS and len(t) > 1}


def _lexical_overlap(current_text: str, recent_fragments: tuple[ContextFragment, ...]) -> float:
    cur_tokens = _tokens(current_text)
    if not cur_tokens or not recent_fragments:
        return 0.0
    # فقط جدیدترین قطعه (بالاترین recency) -- دقیقاً منطقِ «پیامِ
    # بلافاصله‌یِ قبلی وزنِ بیشتری دارد».
    latest = max(recent_fragments, key=lambda f: f.recency)
    ref_tokens = _tokens(latest.text)
    if not ref_tokens:
        return 0.0
    intersection = cur_tokens & ref_tokens
    union = cur_tokens | ref_tokens
    return len(intersection) / len(union) if union else 0.0


def score(
    normalized_text: str,
    *,
    relation: TopicRelation,
    recent_fragments: tuple[ContextFragment, ...] = (),
    mixed_emotion: bool = False,
) -> ModuleResult:
    try:
        lexical = _lexical_overlap(normalized_text, recent_fragments)

        if relation in _HIGH_CONTINUITY_RELATIONS:
            discourse = 1.0
        elif relation in _ZERO_CONTINUITY_RELATIONS:
            discourse = 0.0
        else:
            discourse = 0.5

        emotion_relation = 1.0 if mixed_emotion else 0.5
        recency = 1.0 if recent_fragments else 0.0

        continuity = (
            _WEIGHT_LEXICAL * lexical
            + _WEIGHT_DISCOURSE * discourse
            + _WEIGHT_EMOTION * emotion_relation
            + _WEIGHT_RECENCY * recency
        )
        # جریمه‌یِ صریحِ topic_shift/unrelated -- حتی اگر لغویاً کمی
        # هم‌پوشانی تصادفی داشته باشند، امتیاز نباید بالا برود.
        if relation in _ZERO_CONTINUITY_RELATIONS:
            continuity *= 0.4

        continuity = round(max(0.0, min(1.0, continuity)), 3)
        return ModuleResult(value=continuity, confidence=continuity)
    except Exception as exc:  # noqa: BLE001
        return ModuleResult(value=0.0, health=ModuleHealth.FALLBACK, confidence=0.0, error=str(exc))
