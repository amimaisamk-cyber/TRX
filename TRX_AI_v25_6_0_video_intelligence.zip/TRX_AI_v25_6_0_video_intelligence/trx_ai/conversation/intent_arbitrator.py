# -*- coding: utf-8 -*-
"""
Intent Arbitration سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۸ سند).

پیاده‌سازیِ مستقیمِ شبه‌کدِ خودِ سند:

    if explicit_tool_command: tool
    elif emotional_statement and continuity_high: conversation
    elif keyword_only_match: conversation
    elif tool_confidence >= threshold: tool
    else: conversation_or_clarification

هر شاخه دقیقاً یک ``reason_codes`` مشخص ثبت می‌کند -- طبقِ اصلِ ۹ سند
(«تمامِ تصمیم‌هایِ مهم قابلِ‌مشاهده و قابلِ‌گزارش باشند»)، تا بعداً از
رویِ لاگ بشود فهمید *چرا* یک مسیرِ خاص انتخاب شد، نه فقط چه چیزی.

نکته‌یِ مهم: این ماژول ابهامِ بینِ دو ابزارِ نزدیک‌امتیاز را دوباره
پیاده‌سازی نمی‌کند -- آن منطق از قبل و به‌خوبی در
``core_engine/tool_router.py`` (``disambiguator.should_ask_followup``)
هست. اینجا فقط تصمیم می‌گیرد «ابزار / مکالمه / نیازمندِ توضیح» کدام
است؛ اگر «ابزار» بود، تصمیمِ *کدام* ابزار همچنان طبقِ روالِ فعلی در
ToolRouter گرفته می‌شود.
"""

from __future__ import annotations

from . import config
from .schemas import IntentCandidate, ModuleHealth, ModuleResult, RoutingDecision


def _find(candidates: tuple[IntentCandidate, ...], name: str) -> IntentCandidate | None:
    for c in candidates:
        if c.name == name:
            return c
    return None


def arbitrate(
    candidates: tuple[IntentCandidate, ...],
    *,
    raw_text: str,
    continuity_score: float,
) -> ModuleResult:
    try:
        if not candidates:
            decision = RoutingDecision(
                route="conversation", selected_intent="general", confidence=0.3,
                reason_codes=("no_candidates",), raw_text=raw_text,
            )
            return ModuleResult(value=decision, health=ModuleHealth.DEGRADED, confidence=0.3)

        ranked = sorted(candidates, key=lambda c: -c.score)
        top = ranked[0]
        emotional = _find(candidates, "emotional_statement")
        casual = _find(candidates, "casual_conversation")

        # ۰) بازبینیِ AMS (Ambiguity Management System -- بخشِ ۵۲ به بعدِ
        # سندِ AMBIGUITY_MANAGEMENT_COMPLETE_SPEC). سه نوع تصمیمِ AMS
        # (شکایتِ مستقیم به دستیار/Repair، Correction، و ابزاری که
        # موضوعش صرفاً یک ضمیرِ حل‌نشده است/Entity Clarification -- A09،
        # A12، A13/A14 خودِ سند) باید حتی روی یک تطبیقِ *قویِ* ابزار هم
        # غالب شوند؛ برخلافِ ۴ شاخه‌یِ بعدی که فقط بینِ نامزدهایِ عادی
        # داوری می‌کنند. این تنها استثناست، چون این سه‌مورد ذاتاً
        # «نامزدهایِ رقیب برایِ همان intent» نیستند -- AMS دارد صحتِ
        # خودِ برداشتِ فعلی را زیر سؤال می‌برد، نه یک intent جایگزین
        # پیشنهاد می‌دهد. هیچ‌کدام از ۵ شاخه‌یِ قبلاً‌موجودِ زیر تغییر
        # نکرده‌اند.
        # استثنایِ خودِ استثنا (P0/P1 طبقِ بخشِ ۳ سند): اگر برنده‌یِ فعلی
        # یک فرمانِ *ساختاریِ رسمی* باشد (مثلِ «خروج»/«کارهام چیه» --
        # نگاه کنید به یادداشتِ رگرسیونِ ``intent_candidates.py``)، آن
        # همیشه بالاترین اولویت را دارد؛ AMS هرگز آن را override نمی‌کند.
        top_is_official_structural = top.source == "legacy_intent_engine_official" and top.score >= 0.95

        ams_override_names = ("conversation_repair", "conversation_correction", "conversation_entity_clarification")
        ams_override = (
            None
            if top_is_official_structural
            else next((c for c in candidates if c.name in ams_override_names and c.score >= 0.8), None)
        )
        if ams_override is not None:
            decision = RoutingDecision(
                route="conversation", selected_intent=ams_override.name, confidence=ams_override.score,
                reason_codes=("ams_override", f"ams_type:{ams_override.name}"),
                blocked_tools=tuple(c.name for c in candidates if c.requires_tool and c is not ams_override),
                raw_text=raw_text,
            )
            return ModuleResult(value=decision, confidence=ams_override.score)

        # ۱) فرمانِ صریحِ ابزار: امتیازِ خیلی بالا + واقعاً یک ابزار است.
        if top.requires_tool and top.score >= config.EXPLICIT_TOOL_COMMAND_MIN_SCORE:
            decision = RoutingDecision(
                route="tool", selected_intent=top.name, confidence=top.score,
                reason_codes=("explicit_tool_command",), raw_text=raw_text,
            )
            return ModuleResult(value=decision, confidence=top.score)

        # ۲) پیامِ احساسی + پیوستگیِ بالا با نوبتِ قبل -> مکالمه، حتی اگر
        # یک ابزارِ ضعیف هم لمس شده باشد.
        if emotional and emotional.score >= 0.45 and continuity_score >= config.CONTINUITY_HIGH_THRESHOLD:
            blocked = (top.name,) if (top.requires_tool and top is not emotional) else ()
            decision = RoutingDecision(
                route="conversation", selected_intent="emotional_statement", confidence=emotional.score,
                reason_codes=("emotional_statement_priority", "continuity_high"),
                blocked_tools=blocked, raw_text=raw_text,
            )
            return ModuleResult(value=decision, confidence=emotional.score)

        # ۳) بهترین نامزد یک ابزار است ولی فقط با یک تطبیقِ ضعیفِ
        # کلیدواژه‌ای (نه فرمانِ صریح، نه امتیازِ کافی) -> به مکالمه سپرده
        # می‌شود، نه اجرایِ کورکورانه‌یِ ابزار.
        if top.requires_tool and top.score < config.KEYWORD_ONLY_TOOL_MIN_SCORE:
            fallback_intent = casual.name if casual else "general"
            fallback_score = casual.score if casual else 0.4
            decision = RoutingDecision(
                route="conversation", selected_intent=fallback_intent, confidence=fallback_score,
                reason_codes=("keyword_only_weak_match",), blocked_tools=(top.name,), raw_text=raw_text,
            )
            return ModuleResult(value=decision, confidence=fallback_score)

        # ۴) ابزار با امتیازِ کافی (بدونِ فرمانِ صریح، ولی به‌اندازه‌یِ
        # کافی قوی) -> اجرا.
        if top.requires_tool and top.score >= config.KEYWORD_ONLY_TOOL_MIN_SCORE:
            decision = RoutingDecision(
                route="tool", selected_intent=top.name, confidence=top.score,
                reason_codes=("tool_confidence_threshold",), raw_text=raw_text,
            )
            return ModuleResult(value=decision, confidence=top.score)

        # ۵) پیش‌فرض: مکالمه (یا در آینده clarification، وقتی سیگنال
        # واقعاً هیچ برنده‌یِ روشنی ندارد).
        selected = top.name if not top.requires_tool else (casual.name if casual else "general")
        decision = RoutingDecision(
            route="conversation", selected_intent=selected, confidence=top.score,
            reason_codes=("default_conversation",), raw_text=raw_text,
        )
        return ModuleResult(value=decision, confidence=top.score)

    except Exception as exc:  # noqa: BLE001
        decision = RoutingDecision(
            route="conversation", selected_intent="general", confidence=0.3,
            reason_codes=("arbitration_error",), raw_text=raw_text,
        )
        return ModuleResult(value=decision, health=ModuleHealth.FALLBACK, confidence=0.0, error=str(exc))
