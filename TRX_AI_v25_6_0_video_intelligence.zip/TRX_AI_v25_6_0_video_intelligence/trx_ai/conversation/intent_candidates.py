# -*- coding: utf-8 -*-
"""
Intent Candidate Engine سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۷ سند).

طبقِ سند: «به‌جایِ انتخابِ فوری، چند نامزد تولید کند... Keyword تنها
evidence کافی نیست.»

اتصال به سیستمِ فعلی (طبقِ بخشِ «اتصال به سیستمِ فعلی» در سند):
IntentEngine فعلی (``trx_ai.nlu.scorer.detect``) حذف نمی‌شود؛ از
*تصمیم‌گیرنده‌یِ نهایی* به *تولیدکننده‌یِ نامزد* تبدیل می‌شود. این
ماژول مستقیماً از ``result.scores`` (که ``IntentResult`` از قبل دارد
-- نگاه کنید به ``nlu/scorer.py``) همه‌یِ نیت‌هایِ امتیازدار را
می‌گیرد، نه فقط برنده را؛ به‌علاوه دو نامزدِ ترکیبی که در نسخه‌یِ قدیمی
اصلاً وجود نداشتند:
    - ``emotional_statement`` (از خروجیِ emotion_analyzer)
    - ``casual_conversation`` (از ``SmallTalkEngine.categorize`` -- که
      از قبل در ``trx_ai/intelligence.py`` هست، فقط تا الان به‌عنوانِ
      یک intent رسمی وارد نمی‌شد، مستقیماً در tool_router صدا زده
      می‌شد)
"""

from __future__ import annotations

from .. import intelligence as _intelligence
from ..nlu import registry as _nlu_registry
from ..nlu.matchers.keyword import keyword_hit_score
from ..nlu.matchers.regex import regex_score
from ..nlu.normalizer import normalize as _nlu_normalize
from ..nlu.scorer import detect as _nlu_detect
from .normalizer import space_before_punctuation
from .schemas import EmotionReading, IntentCandidate, ModuleHealth, ModuleResult

# نمرات ``IntentResult.scores`` جمع‌هایِ وزنیِ خامِ نامحدودند (می‌توانند
# ۲۰+ هم بشوند)، نه امتیازِ نرمال‌شده‌یِ ۰..۱. استفاده‌یِ مستقیم از آن‌ها
# به‌عنوانِ «امتیازِ نامزد» در کنارِ امتیازهایِ ۰..۱ (احساس، smalltalk)
# اشتباهِ مقایسه‌ی دو مقیاسِ متفاوت است -- دقیقاً همان باگی که در حینِ
# تستِ این فایل کشف شد: «اما واقعاً خوشحالم» با یک تطبیقِ فازیِ ضعیفِ
# «اما»≈«دما» (فاصله‌ی ویرایشیِ ۱، یک باگِ مستقلِ از‌قبل‌موجود در
# ``nlu/matchers/fuzzy.py`` -- نگاه کنید به یادداشتِ Phase B/C) امتیازِ
# خامِ ۳.۰ می‌گرفت که از آستانه‌هایِ ۰..۱ مقیاسِ این سامانه به‌اشتباه
# رد می‌شد. راه‌حل: دقیقاً همان تبدیلِ ``absolute`` که خودِ
# ``nlu/scorer.py::detect`` برایِ اطمینانِ نهایی استفاده می‌کند
# (``min(score/20.0, 1.0)``) روی *هر* نامزد اعمال می‌شود، نه فقط برنده --
# اکنون همه‌ی نامزدها (فارغ از منبع) روی یک مقیاسِ قابلِ‌مقایسه‌ی ۰..۱
# هستند.
_RAW_SCORE_NORMALIZER = 20.0


def _normalize_raw_score(raw_score: float, *, is_top: bool, official_confidence: float) -> float:
    if is_top:
        # برایِ برنده‌یِ واقعیِ IntentEngine، همان اطمینانِ رسمی (margin+absolute)
        # را نگه می‌داریم -- این همان مقداری‌ست که بقیه‌ی سیستم (آستانه‌های
        # ابهام در tool_router و غیره) قبلاً با آن کالیبره شده.
        return round(float(official_confidence), 3)
    return round(min(max(raw_score, 0.0) / _RAW_SCORE_NORMALIZER, 1.0), 3)


def _has_exact_evidence(normalized_text: str, spec) -> bool:
    """
    True اگر این نیت حداقل یک تطبیقِ *دقیق* (کلیدواژه/مترادف/regex) --
    نه صرفاً فازی -- روی این متن دارد. طبقِ توضیحِ بالا: ``IntentResult.hits``
    فعلاً همیشه خالی است (یک باگِ جداگانه‌یِ کشف‌شده -- ``scorer.py``
    هرگز آن را پر نمی‌کند)، پس اینجا مستقیماً از همان توابعِ اولیه‌ای که
    ``scorer._statistical_scores`` هم استفاده می‌کند دوباره پرس‌وجو
    می‌شود -- بدونِ دست‌زدن به خودِ ``scorer.py`` (ریسکِ صفر برایِ
    امتیازدهیِ اصلی، فقط یک استعلامِ اضافی و ارزان).
    """
    if spec is None:
        return True  # نیتِ بدونِ IntentSpec (مثلاً "general") مشمولِ این چک نیست
    if any(keyword_hit_score(normalized_text, kw) > 0 for kw in spec.keywords):
        return True
    if any(keyword_hit_score(normalized_text, syn) > 0 for syn in spec.synonyms):
        return True
    if spec.regex and regex_score(normalized_text, spec.regex, spec.weight) > 0:
        return True
    return False


def generate(
    raw_text: str,
    *,
    emotion: EmotionReading,
    context_modes=None,
    db=None,
) -> ModuleResult:
    try:
        candidates: list[IntentCandidate] = []
        _min_raw_score = 0.05 * _RAW_SCORE_NORMALIZER  # معادلِ آستانه‌ی قدیمیِ ۰.۰۵ روی مقیاسِ خام

        # نگاه کنید به توضیحِ باگِ مرزبندیِ کلیدواژه در normalizer.py --
        # فقط ورودیِ *موتورهایِ قدیمی* اصلاح می‌شود، raw_text اصلی دست‌نخورده می‌ماند.
        spaced_text = space_before_punctuation(raw_text)
        legacy_result = _nlu_detect(spaced_text, context=context_modes, db=db)
        spaced_normalized = _nlu_normalize(spaced_text)
        ranked_scores = sorted(legacy_result.scores.items(), key=lambda kv: -kv[1])
        for idx, (name, score_val) in enumerate(ranked_scores):
            if score_val < _min_raw_score:
                continue
            spec = _nlu_registry.PATTERNS.get(name)
            intent_hits = tuple(h for h in legacy_result.hits if h.intent == name)
            evidence = tuple(f"{h.matcher}:{h.detail}" for h in intent_hits)[:5]
            is_top = idx == 0 and name == legacy_result.intent
            normalized_score = _normalize_raw_score(
                score_val, is_top=is_top, official_confidence=legacy_result.confidence,
            )
            exact = _has_exact_evidence(spaced_normalized, spec)
            # رفعِ باگِ ۲۰۲۶-۰۹-۲۰ (``BUGFIX_v25_5_2_FEEDBACK_FUZZY_CAP.md``):
            # یک تصحیحِ صریحِ کاربر (نگاه کنید به ``nlu/feedback.py``) از
            # همین سقف معاف است -- چون منبعش یک حدسِ فازیِ تصادفی نیست،
            # بلکه دقیقاً همان چیزی‌ست که کاربر خودش گفته «منظورم این
            # بود». اگر این استثنا نباشد، کلِ قابلیتِ «نه، منظورم این
            # نبود» برایِ دقیقاً همان پیام‌هایِ کوتاه/بدونِ‌کلیدواژه‌یِ
            # رایجی که برایِ آن ساخته شده (پیام‌هایی که از اول نتوانستند
            # کلیدواژه‌ی نیتِ درست را داشته باشند) بی‌اثر می‌ماند.
            has_feedback_evidence = any(h.matcher == "feedback" for h in intent_hits)
            if not exact and not has_feedback_evidence:
                # فقط لایه‌ی فازی این نیت را نجات داده -- محافظه‌کارانه
                # سقف بزن (مثالِ واقعیِ کشف‌شده: «اما»≈«دما» با فاصله‌ی
                # ویرایشیِ ۱، که بدونِ این سقف با اطمینانِ ۰.۷۲ به‌جایِ
                # مکالمه، به‌اشتباه سمتِ ابزار می‌رفت).
                normalized_score = min(normalized_score, 0.3)
                evidence = evidence + ("fuzzy_only",)
            candidates.append(
                IntentCandidate(
                    name=name,
                    score=normalized_score,
                    evidence=evidence or (f"legacy_raw_score:{score_val:.2f}",),
                    requires_tool=bool(spec and spec.ref_tool),
                    source="legacy_intent_engine",
                )
            )

        # باگِ بحرانیِ کشف‌شده در حینِ ممیزی (رجوع به یادداشتِ AMS_AUDIT_2026_09
        # در پایینِ فایل برایِ شرح کامل): وقتی ``nlu/scorer.py::detect`` از
        # مسیرِ «دستوراتِ ساختاریِ قطعی» (``registry.STRUCTURAL`` -- شاملِ
        # کارهام‌چیه/خروج/راهنما/پروفایل/حافظه/شخصیت و غیره، ۲۴ نیت) برنده
        # اعلام می‌کند، آن مسیر عمداً ``IntentResult`` را *بدونِ پرکردنِ
        # scores* برمی‌گرداند (فقط ``intent`` و ``confidence`` ست می‌شوند).
        # حلقه‌یِ بالا فقط از رویِ ``legacy_result.scores.items()`` نامزد
        # می‌سازد؛ پس برایِ هر ۲۴ نیتِ ساختاری، حلقه هیچ نامزدی تولید
        # نمی‌کرد و اجرا مستقیم به ``if not candidates`` می‌رسید -- یعنی
        # نیتِ واقعی و باکیفیت (confidence=0.98) کاملاً دور ریخته می‌شد و
        # جایش «general/0.4» می‌نشست. چون ``conversation_engine.process()``
        # در این حالت هرگز None برنمی‌گرداند (نه استثنا، نه ورودیِ خالی)،
        # ``turn_processor._detect_intent`` هم هرگز به IntentEngine قدیمی
        # برنمی‌گشت -- یعنی حتی فرمانِ «خروج» هم به general تبدیل می‌شد.
        #
        # راه‌حل (کم‌ریسک، افزودنی): اگر نیتِ رسمیِ IntentEngine
        # (``legacy_result.intent``) هنوز در فهرستِ نامزدها نیست (چه از
        # مسیرِ ساختاری، چه هر دلیلِ دیگری که scores آن را نپوشانده)، همان
        # نیت را با اطمینانِ رسمی‌اش به‌عنوانِ یک نامزدِ صریح اضافه کن. هیچ
        # نامزدِ موجودی تغییر نمی‌کند؛ فقط نامزدِ گم‌شده بازگردانده می‌شود.
        existing_names = {c.name for c in candidates}
        if legacy_result.intent != "general" and legacy_result.intent not in existing_names:
            spec = _nlu_registry.PATTERNS.get(legacy_result.intent)
            candidates.append(
                IntentCandidate(
                    name=legacy_result.intent,
                    score=round(float(legacy_result.confidence), 3),
                    evidence=("structural_or_unscored_official_intent",),
                    requires_tool=bool(spec and spec.ref_tool),
                    source="legacy_intent_engine_official",
                )
            )

        if not candidates:
            candidates.append(
                IntentCandidate(name="general", score=0.4, evidence=("no_signal",), source="legacy_intent_engine")
            )

        if emotion.emotion != "neutral" and emotion.confidence >= 0.45:
            candidates.append(
                IntentCandidate(
                    name="emotional_statement",
                    score=round(emotion.confidence, 3),
                    evidence=(f"emotion:{emotion.emotion}",) + emotion.evidence[:3],
                    requires_tool=False,
                    source="emotion_analyzer",
                )
            )

        smalltalk_category = _intelligence.SmallTalkEngine.categorize(raw_text)
        if smalltalk_category:
            candidates.append(
                IntentCandidate(
                    name="casual_conversation",
                    score=0.6,
                    evidence=(f"smalltalk_category:{smalltalk_category}",),
                    requires_tool=False,
                    source="smalltalk_engine",
                )
            )

        return ModuleResult(value=tuple(candidates), confidence=1.0)
    except Exception as exc:  # noqa: BLE001
        fallback = (IntentCandidate(name="general", score=0.4, evidence=("fallback",), source="error_fallback"),)
        return ModuleResult(value=fallback, health=ModuleHealth.FALLBACK, confidence=0.0, error=str(exc))
