# -*- coding: utf-8 -*-
"""
Topic Tracker سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۵ سند).

رابطه‌یِ پیامِ جدید با پیامِ قبلی را از رویِ نشانگرهایِ گفتمانی
(discourse markers) + هم‌پوشانیِ موضوعِ استخراج‌شده تعیین می‌کند --
دقیقاً فهرستِ ۹تاییِ سند: continuation, explanation, cause,
consequence, correction, contrast, answer_to_question, topic_shift,
unrelated.

این یک طبقه‌بندِ آماری/معنایی نیست -- عمداً قاعده‌محور و شفاف است
(هر تصمیم قابلِ‌ردیابی به یک نشانگرِ مشخص است) چون طبقِ اصلِ ۹ سند
«تمامِ تصمیم‌هایِ مهم باید قابلِ‌مشاهده و قابلِ‌گزارش باشند» -- یک
طبقه‌بندِ آماریِ جعبه‌سیاه اینجا دقیقاً همان چیزی‌ست که سند نمی‌خواهد.
استخراجِ خودِ «موضوع» (topic entity) وظیفه‌یِ این ماژول نیست -- آن از
``ai.memory.extract_topic_entity`` (که از قبل وجود دارد) می‌آید و از
طریقِ ``conversation_engine.py`` به‌عنوانِ ``topic_hint`` به اینجا
داده می‌شود؛ اینجا فقط *رابطه* را تعیین می‌کند، نه استخراجِ موضوع را
تکرار می‌کند.
"""

from __future__ import annotations

from .schemas import ModuleHealth, ModuleResult, TopicRelation

_CORRECTION_MARKERS = ("نه منظورم", "منظورم این نبود", "اشتباه گفتم", "نه اونی که گفتم نبود", "درست نگفتم")
# نامِ عمومی برایِ استفاده‌یِ دوباره در ``ambiguity_manager.py`` (ماژولِ AMS) --
# بدونِ کپی‌کردنِ لیست، همان یک منبع.
CORRECTION_MARKERS = _CORRECTION_MARKERS
_CONTRAST_MARKERS = ("اما", "ولی", "با این حال", "درعین‌حال", "درعین حال")
_CAUSE_MARKERS = ("چون", "چونکه", "به خاطر", "بخاطر", "علتش")
_CONSEQUENCE_MARKERS = ("پس", "بنابراین", "درنتیجه", "درنتیجه‌اش")
_TOPIC_SHIFT_MARKERS = ("راستی", "در ضمن", "ضمنا", "ضمناً", "یه چیز دیگه")
_QUESTION_MARKERS = ("چرا", "چیه", "چیست", "چطور", "کی", "کجا", "چند")


def _starts_or_contains(text: str, markers: tuple[str, ...]) -> str | None:
    for m in markers:
        if m in text:
            return m
    return None


def analyze_relation(
    normalized_text: str,
    *,
    active_topic: str | None,
    topic_hint: str | None,
    unanswered_question: str | None = None,
) -> ModuleResult:
    """
    ``topic_hint``: موضوعِ استخراج‌شده از همین پیام (از بیرون داده
    می‌شود -- نگاه کنید به توضیحِ بالا).
    ``unanswered_question``: اگر نوبتِ قبل یک سؤالِ بی‌پاسخ باقی گذاشته
    (از ``ContextSnapshot.unanswered_question``).
    """
    try:
        text = normalized_text or ""
        evidence: list[str] = []

        # اولویت‌بندی طبقِ اهمیتِ گفتمانی: تصحیح > تقابل > علت/نتیجه >
        # تغییرِ موضوعِ صریح > پاسخ‌به‌سؤال > هم‌پوشانیِ موضوع.
        if hit := _starts_or_contains(text, _CORRECTION_MARKERS):
            evidence.append(f"correction_marker:{hit}")
            return ModuleResult(value=(TopicRelation.CORRECTION, tuple(evidence)), confidence=0.9)

        if hit := _starts_or_contains(text, _CONTRAST_MARKERS):
            evidence.append(f"contrast_marker:{hit}")
            return ModuleResult(value=(TopicRelation.CONTRAST, tuple(evidence)), confidence=0.85)

        if hit := _starts_or_contains(text, _CAUSE_MARKERS):
            evidence.append(f"cause_marker:{hit}")
            return ModuleResult(value=(TopicRelation.CAUSE, tuple(evidence)), confidence=0.8)

        if hit := _starts_or_contains(text, _CONSEQUENCE_MARKERS):
            evidence.append(f"consequence_marker:{hit}")
            return ModuleResult(value=(TopicRelation.CONSEQUENCE, tuple(evidence)), confidence=0.75)

        if hit := _starts_or_contains(text, _TOPIC_SHIFT_MARKERS):
            evidence.append(f"topic_shift_marker:{hit}")
            return ModuleResult(value=(TopicRelation.TOPIC_SHIFT, tuple(evidence)), confidence=0.8)

        is_question = "؟" in text or any(qm in text for qm in _QUESTION_MARKERS)
        if unanswered_question and not is_question:
            evidence.append("pending_question_present")
            return ModuleResult(value=(TopicRelation.ANSWER_TO_QUESTION, tuple(evidence)), confidence=0.6)

        if active_topic is None:
            evidence.append("no_prior_topic")
            return ModuleResult(value=(TopicRelation.TOPIC_SHIFT, tuple(evidence)), confidence=0.4)

        if topic_hint and topic_hint == active_topic:
            evidence.append("topic_entity_match")
            return ModuleResult(value=(TopicRelation.CONTINUATION, tuple(evidence)), confidence=0.7)

        if not topic_hint:
            # هیچ موضوعِ تازه‌ای استخراج نشد (مثلاً جمله فقط ضمیر/فعل
            # است) -- محتمل‌ترین حالت ادامه/توضیحِ همان موضوعِ قبلی است.
            evidence.append("no_new_topic_entity")
            return ModuleResult(value=(TopicRelation.EXPLANATION, tuple(evidence)), confidence=0.5)

        evidence.append("topic_entity_mismatch")
        return ModuleResult(value=(TopicRelation.UNRELATED, tuple(evidence)), confidence=0.5)

    except Exception as exc:  # noqa: BLE001
        return ModuleResult(
            value=(TopicRelation.UNRELATED, ()),
            health=ModuleHealth.FALLBACK,
            confidence=0.0,
            error=str(exc),
        )
