# -*- coding: utf-8 -*-
"""
Response Critic سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۱۲ سند).

نسخه‌ی فعلی روی *تصمیمِ مسیریابی* نقد می‌کند، نه متنِ نهاییِ پاسخ --
چون طبقِ ``response_planner.py`` تولیدِ متن هنوز وظیفه‌یِ موتورهایِ
موجود (TherapyCompanion/SmallTalkEngine/ToolRouter) است و آن‌ها بعدِ
این مرحله اجرا می‌شوند. این ماژول آخرین شبکه‌یِ ایمنی است: حتی اگر
arbitrator و action_gate هر دو یک تصمیمِ «tool» را تأیید کرده باشند،
اینجا یک‌بارِ دیگر (ارزان، بدونِ فراخوانیِ شبکه) چک می‌شود که آیا
رابطه‌یِ موضوعیِ پیام با نوبتِ قبل («contrast»/«cause» -- یعنی ادامه‌یِ
مستقیمِ یک موضوعِ احساسی) با اجرایِ یک ابزار همخوانی دارد یا نه.

معیارهایِ کمّیِ سند (Wrong Tool Activation Rate, Topic Break Rate,
...) از همین‌جا قابلِ‌استخراج‌اند -- ``review()`` هر پرچمی که فعال شود
را در ``flags`` برمی‌گرداند تا ``conversation_logger`` آن‌ها را ثبت
کند و بعداً بشود این معیارها را از رویِ لاگ محاسبه کرد.
"""

from __future__ import annotations

from . import config
from .schemas import ModuleHealth, ModuleResult, RoutingDecision, TopicRelation

# رابطه‌هایی که اگر با یک تصمیمِ «tool» همراه شوند، مشکوک‌اند (احتمالِ
# قطعِ ناگهانیِ موضوعِ احساسی/مکالمه‌ای).
_SUSPICIOUS_WITH_TOOL = frozenset({TopicRelation.CONTRAST, TopicRelation.CAUSE, TopicRelation.CORRECTION})


def review(decision: RoutingDecision, *, relation: TopicRelation) -> ModuleResult:
    try:
        flags: list[str] = []
        final = decision

        is_explicit = "explicit_tool_command" in decision.reason_codes
        if decision.route == "tool" and not is_explicit and relation in _SUSPICIOUS_WITH_TOOL:
            flags.append("topic_break_risk")
            final = RoutingDecision(
                route="conversation",
                selected_intent="general",
                confidence=decision.confidence,
                reason_codes=decision.reason_codes + ("critic_downgraded_topic_break_risk",),
                blocked_tools=decision.blocked_tools,
                needs_followup=decision.needs_followup,
                raw_text=decision.raw_text,
            )

        score = 1.0 - (0.5 if flags else 0.0)
        if score < config.RESPONSE_CRITIC_MIN_SCORE:
            flags.append("below_critic_threshold")

        return ModuleResult(value=(final, tuple(flags)), confidence=score)
    except Exception as exc:  # noqa: BLE001
        return ModuleResult(
            value=(decision, ("critic_error",)), health=ModuleHealth.FALLBACK, confidence=0.0, error=str(exc),
        )
