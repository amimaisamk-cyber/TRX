# -*- coding: utf-8 -*-
"""
دیتاکلاس‌های مشترکِ سامانه‌ی هوشمندیِ مکالمه (Conversation Intelligence
System -- سندِ مهندسیِ ۱۴۰۵/۰۶/۲۷).

این فایل عمداً بدونِ هیچ منطقی است -- درست مثلِ ``trx_ai/nlu/types.py``
که همین الگو را برایِ IntentEngine جا انداخته -- فقط شکلِ داده را
تعریف می‌کند تا normalizer، context_manager، state_tracker،
emotion_analyzer، topic_tracker، continuity_analyzer،
intent_candidates، intent_arbitrator، action_gate، response_planner،
response_composer، response_critic و conversation_logger همه یک زبانِ
مشترک داشته باشند.

نکته‌ی مهم دربابِ هم‌زیستی با IntentEngine فعلی: این ماژول جایگزینِ
``trx_ai.nlu`` / ``trx_ai.intelligence.IntentEngine`` نیست. طبقِ سندِ
ارتقا (بخشِ «اتصال به سیستمِ فعلی»)، IntentEngine فعلی حذف نمی‌شود؛
تبدیل می‌شود به یکی از تولیدکننده‌هایِ ``IntentCandidate`` برایِ
``intent_arbitrator``. یعنی ``RoutingDecision`` نهایی همچنان می‌تواند
دقیقاً به همان قراردادِ سه‌تاییِ قدیمی (``intent, confidence,
raw_text``) بازگردانده شود تا ``ToolRouter.execute`` بدونِ تغییر کار
کند -- نگاه کنید به یادداشتِ سازگاری در ``RoutingDecision`` پایین.

وضعیتِ فعلی (Phase A): این ماژول‌ها هنوز به ``turn_processor.py`` وصل
نشده‌اند -- یعنی هیچ رفتارِ موجودی را تغییر نمی‌دهند و هیچ ریسکِ
رگرسیونی ندارند. اتصال (Phase G) مرحله‌ای و بعد از تأییدِ جداگانه
انجام می‌شود.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


# ==========================================================
#   سلامتِ ماژول -- اصلِ پایداریِ سند: «هر ماژول timeout، exception
#   boundary، default output، confidence و health status داشته باشد.
#   در خرابی، fallback اجرا شود و TRX crash نکند.»
# ----------------------------------------------------------
class ModuleHealth(str, Enum):
    """وضعیتِ اجرایِ یک ماژولِ مکالمه در همین نوبت."""

    OK = "ok"                    # اجرا شد و نتیجه‌ی معتبر داد
    DEGRADED = "degraded"        # اجرا شد ولی با confidence پایین/جزئی
    FALLBACK = "fallback"        # خودِ ماژول خطا داد؛ خروجیِ پیش‌فرض برگشت
    TIMEOUT = "timeout"          # به سقفِ زمانیِ مجاز نرسید
    DISABLED = "disabled"        # از طریقِ config.py خاموش است (kill switch)


@dataclass
class ModuleResult:
    """
    پوششِ یکسان برایِ خروجیِ هر ماژولِ زنجیره (Normalizer، ContextManager،
    ...). هدف: هیچ ماژولی مستقیماً استثنا به بیرون پرتاب نکند -- فراخوان
    همیشه یک ``ModuleResult`` می‌گیرد و بر اساسِ ``health`` تصمیم
    می‌گیرد ادامه بدهد یا از ``value`` پیش‌فرض استفاده کند.
    """

    value: object
    health: ModuleHealth = ModuleHealth.OK
    confidence: float = 1.0
    error: str | None = None
    latency_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return self.health in (ModuleHealth.OK, ModuleHealth.DEGRADED)


# ==========================================================
#   MessageRecord
# ==========================================================
@dataclass
class MessageRecord:
    """یک پیامِ منفردِ کاربر یا دستیار، همان‌طور که در سندِ قراردادِ داده آمده."""

    message_id: str
    raw_text: str
    normalized_text: str
    timestamp: float = field(default_factory=time.time)
    speaker: str = "user"  # "user" | "assistant"
    language: str = "fa"
    conversation_id: str = "default"
    metadata: dict = field(default_factory=dict)


# ==========================================================
#   ContextSnapshot
# ==========================================================
@dataclass
class ContextSnapshot:
    """
    برشِ لحظه‌ای از وضعیتِ مکالمه. تولیدشده توسطِ ``context_manager.py``
    + ``state_tracker.py``؛ مصرف‌شده توسطِ تقریباً همه‌ی ماژول‌هایِ بعدیِ
    زنجیره.

    توجه: این با حافظه‌ی بلندمدت (``trx_ai/memory_store.py``) یکی
    نیست -- طبقِ سند: «Conversation State با Long-Term Memory یکی
    نیست؛ state برایِ همین مکالمه است، memory فقط اطلاعاتِ پایدار و
    مفید را نگه می‌دارد.»
    """

    active_topic: str | None = None
    recent_topics: tuple[str, ...] = ()
    current_emotion: str = "neutral"
    previous_emotion: str | None = None
    emotion_intensity: float = 0.0
    known_cause: str | None = None
    recent_event: str | None = None
    conversation_mode: str = "casual"  # "casual" | "task" | "medical" | "therapy" | ...
    user_goal: str | None = None
    unanswered_question: str | None = None
    last_tool: str | None = None
    context_confidence: float = 0.0

    # ==========================================================
    #   فیلدهایِ AMS (Ambiguity Management System -- بخشِ ۵۲ به بعدِ سند)
    # ----------------------------------------------------------
    # این‌ها *افزوده* شده‌اند (اضافه‌کردنِ فیلدِ پیش‌فرض‌دار به یک
    # dataclass) -- هیچ فیلد/رفتارِ قبلی تغییر نکرده، پس هیچ فراخوانیِ
    # قبلیِ ``ContextSnapshot(...)``/``replace(...)`` نیاز به تغییر ندارد.
    last_speech_act: str | None = None  # "complaint" | "question" | "statement" | "request" | None
    last_target: str | None = None  # "assistant" وقتی کاربر مستقیم با خودِ TRX حرف می‌زند
    frustration_score: float = 0.0  # طبقِ بخشِ ۲۱ سند -- با نشانه‌ها بالا می‌رود، آهسته decay می‌شود
    ambiguity_streak: int = 0  # چند نوبتِ متوالیِ ابهامِ حل‌نشده -- بخشِ ۲۰/۸۴ (A20: no infinite loop)
    corrected_topic_locked: bool = False  # بعدِ Correction Engine (بخشِ ۱۷) -- سؤالِ تکراری ممنوع


# ==========================================================
#   IntentCandidate
# ==========================================================
@dataclass
class IntentCandidate:
    """
    یک نامزدِ نیت با شواهد و تناقض‌هایِ خودش -- نه یک تصمیمِ نهایی.
    چند نامزد می‌توانند هم‌زمان تولید شوند (از IntentEngine فعلی، از
    continuity_analyzer، از یک فرمانِ صریح، ...)؛ ``intent_arbitrator``
    بینِ آن‌ها داوری می‌کند.
    """

    name: str
    score: float
    evidence: tuple[str, ...] = ()
    contradictions: tuple[str, ...] = ()
    requires_explicit_command: bool = False
    requires_tool: bool = False
    source: str = "unknown"  # کدام تولیدکننده این نامزد را ساخته (برایِ دیباگ)


# ==========================================================
#   RoutingDecision
# ==========================================================
@dataclass
class RoutingDecision:
    """
    خروجیِ نهاییِ ``intent_arbitrator`` + ``action_gate``.

    سازگاریِ عقب‌رو: ``as_legacy_tuple()`` همان سه‌تاییِ
    ``(intent, confidence, raw_text)`` را برمی‌گرداند که
    ``ToolRouter.execute`` و ``TurnProcessor.process_turn`` امروز
    انتظار دارند -- تا وقتی Phase G (اتصال) انجام شود، هیچ امضایی در
    core_engine نیاز به تغییر ندارد.
    """

    route: str  # "tool" | "conversation" | "clarification" | "no_action"
    selected_intent: str
    confidence: float
    reason_codes: tuple[str, ...] = ()
    blocked_tools: tuple[str, ...] = ()
    needs_followup: bool = False
    raw_text: str = ""

    def as_legacy_tuple(self) -> tuple[str, float, str]:
        return (self.selected_intent, self.confidence, self.raw_text)


# ==========================================================
#   EmotionReading -- خروجیِ emotion_analyzer.py (ماژولِ ۴)
# ==========================================================
@dataclass
class EmotionReading:
    """
    خروجیِ تحلیلِ احساس برایِ همینِ پیام. رویِ ``trx_ai.nlu.user_state``
    سوار است (نگاه کنید به ``emotion_analyzer.py``) -- این کلاس فقط
    واژگانِ آن را به واژگانِ سندِ Conversation Intelligence («happy،
    sad، tired، angry، anxious، relieved، proud، confused،
    disappointed، mixed_emotion، neutral») نگاشت می‌کند.
    """

    emotion: str = "neutral"
    intensity: float = 0.0
    previous_emotion: str | None = None
    mixed_emotion: bool = False
    known_cause: str | None = None
    confidence: float = 0.0
    evidence: tuple[str, ...] = ()


# ==========================================================
#   TopicRelation -- خروجیِ topic_tracker.py (ماژولِ ۵)
# ==========================================================
class TopicRelation(str, Enum):
    """رابطه‌یِ پیامِ جدید با پیامِ قبلی -- دقیقاً فهرستِ ماژولِ ۵ سند."""

    CONTINUATION = "continuation"
    EXPLANATION = "explanation"
    CAUSE = "cause"
    CONSEQUENCE = "consequence"
    CORRECTION = "correction"
    CONTRAST = "contrast"
    ANSWER_TO_QUESTION = "answer_to_question"
    TOPIC_SHIFT = "topic_shift"
    UNRELATED = "unrelated"


# ==========================================================
#   AmbiguityType / AmbiguityAssessment -- خروجیِ ambiguity_manager.py
#   (AMS -- Ambiguity Management System، بخشِ ۵۲ تا ۷۹ سند)
# ==========================================================
class AmbiguityType(str, Enum):
    """طبقِ بخشِ ۵۶ سند -- «Ambiguity Types» (A تا I). فقط زیرمجموعه‌ای که
    این نسخه واقعاً تشخیص می‌دهد اینجا تعریف شده؛ بقیه (TEMPORAL، ENTITY
    به‌جز حالتِ ضمیر-به‌عنوانِ-موضوعِ‌ابزار) در نسخه‌هایِ بعدی اضافه می‌شوند."""

    NONE = "none"
    REFERENTIAL = "referential"  # مرجعِ «این/اون/همون» مشخص نیست
    CONTEXTUAL = "contextual"  # پیامِ کوتاه، فقط با چند پیامِ قبلی قابلِ‌فهم
    SPEECH_ACT = "speech_act"  # شکایت/شوخی/تعارف/سؤال نامشخص است
    ACTION = "action"  # صرفاً حرف‌زدن دربابِ ابزار یا واقعاً اجرا؟
    ENTITY = "entity"  # موجودیتِ موردنظرِ ابزار (مثلاً موضوعِ سرچ) ضمیرِ حل‌نشده است


@dataclass
class AmbiguityAssessment:
    """
    خروجیِ ``ambiguity_manager.assess()``. طبقِ بخشِ ۷۸ سند («OUTPUT»)،
    فقط زیرمجموعه‌ای که این نسخه مصرف می‌کند نگه داشته شده:
    ``ambiguity_detected``, ``ambiguity_type``, ``candidate_name``,
    ``confidence``, ``evidence``, ``needs_clarification``,
    ``clarification_text``, ``state_updates``.

    طبقِ بخشِ ۵۳/۷۹ سند: AMS خودش هیچ Tool اجرا نمی‌کند و پاسخِ نهایی
    نمی‌سازد -- فقط یک IntentCandidate (از طریقِ ``candidate_name``) و
    چند به‌روزرسانیِ state پیشنهاد می‌دهد؛ تصمیمِ نهایی با
    ``intent_arbitrator`` می‌ماند.
    """

    ambiguity_detected: bool = False
    ambiguity_type: AmbiguityType = AmbiguityType.NONE
    candidate_name: str | None = None
    confidence: float = 0.0
    evidence: tuple[str, ...] = ()
    needs_clarification: bool = False
    clarification_text: str | None = None
    # به‌روزرسانی‌هایِ پیشنهادیِ ContextSnapshot (کلید=نامِ فیلد) -- خودِ
    # AMS مستقیماً state را نمی‌نویسد (بخشِ ۳۰ سند: «هیچ ماژول حق تغییرِ
    # مخفیِ State را ندارد»)؛ ``conversation_engine.py`` این را صریحاً
    # اعمال می‌کند.
    state_updates: dict = field(default_factory=dict)


# ==========================================================
#   ContextFragment / ContextBundle -- خروجیِ context_manager.py (ماژولِ ۲)
# ==========================================================
@dataclass
class ContextFragment:
    """یک قطعه‌ی context با منبع/تازگی/ربط/اطمینانِ خودش -- طبقِ ماژولِ ۲ سند."""

    text: str
    source: str  # "recent_message" | "structured_state" | "long_term_memory"
    relevance: float = 0.5
    recency: float = 0.5
    confidence: float = 0.5


@dataclass
class ContextBundle:
    """سه سطحِ context در کنارِ هم -- ورودیِ topic_tracker/continuity_analyzer/response_planner."""

    recent: tuple[ContextFragment, ...] = ()
    structured: ContextSnapshot = field(default_factory=ContextSnapshot)
    long_term: tuple[ContextFragment, ...] = ()


# ==========================================================
#   ResponsePlan
# ==========================================================
@dataclass
class ResponsePlan:
    """
    خروجیِ ``response_planner.py``: به ``response_composer.py`` می‌گوید
    پاسخ *چه شکلی* باشد، نه خودِ متنِ پاسخ را.
    """

    acknowledge_context: bool = False
    reflect_emotion: bool = False
    mention_cause: bool = False
    answer_question: bool = False
    ask_followup: bool = False
    tone: str = "neutral"  # "warm" | "neutral" | "formal" | "playful"
    length: str = "short"  # "short" | "medium" | "long"
    avoid: tuple[str, ...] = ()
    required_facts: tuple[str, ...] = ()
