# -*- coding: utf-8 -*-
"""
Context Manager سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۲ سند).

سه سطح، دقیقاً طبقِ سند:
    الف) چند پیامِ اخیر (recent)
    ب) context ساختاریافته (structured -- همان ``ContextSnapshot`` از ``state_tracker``)
    ج) حافظه‌ی بلندمدتِ مرتبط (long_term)

نکته‌یِ معماریِ عمدی: این ماژول خودش هیچ داده‌ای از ``ai.memory`` یا
``ai.conversation_patterns`` نمی‌خواند -- آن دو در ``trx_ai/core_engine``
هستند و این پکیج (``trx_ai/conversation``) عمداً به هیچ‌کدام از
ماژول‌هایِ core وابسته نیست (تا مستقل قابلِ‌تست بماند، دقیقاً طبقِ
اصلِ ۸ سند: «Core فقط هماهنگ‌کننده باشد؛ منطقِ مکالمه در ماژولِ مستقل
بماند»). به‌جایش، ``conversation_engine.py`` (لایه‌یِ اتصال) این دو
منبع را از ``ai`` می‌گیرد و به شکلِ متنِ ساده به این تابع می‌دهد.
"""

from __future__ import annotations

from .schemas import ContextBundle, ContextFragment, ContextSnapshot


def build_context_bundle(
    *,
    recent_messages: list[str] | None = None,
    structured: ContextSnapshot | None = None,
    long_term_snippets: list[tuple[str, float]] | None = None,
) -> ContextBundle:
    """
    ``recent_messages``: جدیدترین‌ها آخر لیست (همان ترتیبِ متداولِ تاریخچه).
    ``long_term_snippets``: فهرستِ (متن، امتیازِ_شباهت) -- دقیقاً همان
    خروجیِ ``ai.memory.get_relevant_memory`` بعدِ نگاشتِ ساده به تاپل.
    """
    recent = tuple(
        ContextFragment(
            text=msg,
            source="recent_message",
            # پیامِ جدیدتر (اندیسِ بزرگ‌تر) recency بالاتر می‌گیرد.
            recency=round((i + 1) / max(len(recent_messages or []), 1), 3),
            relevance=0.6,
            confidence=0.8,
        )
        for i, msg in enumerate(recent_messages or [])
    )

    long_term = tuple(
        ContextFragment(
            text=text,
            source="long_term_memory",
            relevance=max(0.0, min(1.0, float(score))),
            recency=0.2,  # حافظه‌ی بلندمدت ذاتاً recency پایین‌تری دارد
            confidence=max(0.0, min(1.0, float(score))),
        )
        for text, score in (long_term_snippets or [])
    )

    return ContextBundle(
        recent=recent,
        structured=structured or ContextSnapshot(),
        long_term=long_term,
    )


def summarize_for_logging(bundle: ContextBundle, max_items: int = 3) -> dict:
    """نسخه‌ی فشرده برای ``conversation_logger`` -- کل متنِ خام را لاگ نمی‌کند."""
    return {
        "recent_count": len(bundle.recent),
        "long_term_count": len(bundle.long_term),
        "active_topic": bundle.structured.active_topic,
        "current_emotion": bundle.structured.current_emotion,
        "context_confidence": bundle.structured.context_confidence,
        "top_long_term_relevance": [
            round(f.relevance, 2) for f in sorted(bundle.long_term, key=lambda f: -f.relevance)[:max_items]
        ],
    }
