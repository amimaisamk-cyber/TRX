# -*- coding: utf-8 -*-
"""
Logger سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۱۳ سند).

ثبت می‌کند: ورودی (اختیاری -- طبقِ ``config.LOG_RAW_TEXT``)، متنِ
نرمال‌شده، موضوعِ فعال، امتیازِ پیوستگی، احساس، نامزدهایِ intent،
مسیرِ انتخاب‌شده، ابزارهایِ مسدودشده و reason codeها -- دقیقاً فهرستِ
سند، نه بیشتر («بدونِ ذخیره‌یِ بی‌دلیلِ اطلاعاتِ حساس»).

طراحی از ``trx_ai/logging_config.py`` الگو گرفته (چرخشیِ فایل، مسیرِ
قابلِ‌بازنویسی با متغیرِ محیطی) اما در فایلِ JSON-Lines جداگانه‌ای
می‌نویسد -- نه در ``logs/trx_ai.log`` -- چون این لاگ برایِ eval/تحلیلِ
تصمیم است (ماشین‌خوان)، نه برایِ خواندنِ انسانی در حینِ دیباگِ عمومی.

اصلِ پایداری: نوشتنِ لاگ هرگز نباید یک نوبتِ مکالمه را بترکاند. هر
خطایِ I/O اینجا بی‌صدا (با یک هشدارِ سطحِ logging عادی) قورت داده
می‌شود.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path

from ..logging_config import get_logger
from . import config

logger = get_logger(__name__)

_log_path: Path | None = None


def _resolve_log_path() -> Path:
    global _log_path
    if _log_path is None:
        log_dir = Path(config.CONVERSATION_LOG_DIR)
        log_dir.mkdir(parents=True, exist_ok=True)
        _log_path = log_dir / config.CONVERSATION_LOG_FILE
    return _log_path


def _to_jsonable(value):
    if is_dataclass(value) and not isinstance(value, type):
        return {k: _to_jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    return value


def log_turn_decision(
    *,
    normalized_text: str,
    active_topic: str | None,
    continuity_score: float | None,
    emotion: str | None,
    candidate_intents,
    selected_route,
    blocked_tools=(),
    reason_codes=(),
    raw_text: str | None = None,
    extra: dict | None = None,
) -> bool:
    """
    یک سطر JSON به فایلِ لاگِ تصمیم اضافه می‌کند. برمی‌گرداند True اگر
    نوشتن موفق بود، False اگر (به هر دلیلی) شکست خورد -- فراخوان هرگز
    نباید بر اساسِ این مقدار جریانِ اصلیِ برنامه را متوقف کند.
    """
    try:
        record = {
            "ts": time.time(),
            "normalized_text": normalized_text,
            "active_topic": active_topic,
            "continuity_score": continuity_score,
            "emotion": emotion,
            "candidate_intents": _to_jsonable(candidate_intents),
            "selected_route": _to_jsonable(selected_route),
            "blocked_tools": list(blocked_tools),
            "reason_codes": list(reason_codes),
        }
        if config.LOG_RAW_TEXT and raw_text is not None:
            record["raw_text"] = raw_text
        if extra:
            record["extra"] = _to_jsonable(extra)

        path = _resolve_log_path()
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        return True
    except Exception as exc:  # noqa: BLE001 - لاگ هرگز نباید مسیرِ اصلی را بشکند
        logger.warning("ثبتِ لاگِ تصمیمِ مکالمه شکست خورد: %s", exc)
        return False


def read_recent_decisions(limit: int = 20) -> list[dict]:
    """برایِ دیباگ/داشبورد: آخرین N تصمیمِ ثبت‌شده را می‌خواند."""
    path = _resolve_log_path()
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
        out = []
        for line in lines[-limit:]:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return out
    except Exception as exc:  # noqa: BLE001
        logger.warning("خواندنِ لاگِ تصمیمِ مکالمه شکست خورد: %s", exc)
        return []
