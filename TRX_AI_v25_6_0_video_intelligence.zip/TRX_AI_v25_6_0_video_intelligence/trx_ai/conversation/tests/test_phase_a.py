# -*- coding: utf-8 -*-
"""
تست‌هایِ واحدِ Phase A (schemas + normalizer + logger).

هدف: اثبات اینکه این سه ماژول کار می‌کنند و هیچ‌کدام روی IntentEngine
فعلی اثر نمی‌گذارند (چون Phase A هنوز به هیچ‌جا وصل نیست، صرفاً وجودِ
خودِ ماژول‌ها و رفتارِ ایزوله‌شان بررسی می‌شود).
"""

from __future__ import annotations

import json

from trx_ai.conversation import ModuleHealth, config
from trx_ai.conversation.conversation_logger import (
    _resolve_log_path,
    log_turn_decision,
    read_recent_decisions,
)
from trx_ai.conversation.normalizer import (
    build_message_record,
    detect_colloquial_forms,
    suggest_typo_corrections,
)
from trx_ai.conversation.schemas import IntentCandidate, RoutingDecision


def test_build_message_record_keeps_raw_text():
    result = build_message_record("سلام، حالت خوبه؟", speaker="user")
    assert result.health == ModuleHealth.OK
    record = result.value
    assert record.raw_text == "سلام، حالت خوبه؟"
    assert record.normalized_text  # چیزی خالی برنگشته
    assert record.speaker == "user"
    assert record.message_id


def test_build_message_record_never_raises_on_empty_input():
    result = build_message_record("")
    assert result.value.raw_text == ""
    assert result.value.normalized_text == ""


def test_normalizer_preserves_latin_and_numbers():
    result = build_message_record("قیمت btc امروز چنده؟ ۱۲۳")
    normalized = result.value.normalized_text
    assert "btc" in normalized
    assert "۱۲۳" in normalized


def test_suggest_typo_corrections_finds_close_match():
    # «حوا» به‌جایِ «هوا» -- همان مثالِ خودِ سند/fuzzy.py، فاصله‌ی ۱
    suggestions = suggest_typo_corrections("حوا امروز خوبه", ["هوا", "ابری"])
    assert ("حوا", "هوا") in suggestions


def test_suggest_typo_corrections_ignores_exact_and_latin():
    suggestions = suggest_typo_corrections("هوا خوبه github", ["هوا"])
    assert suggestions == ()


def test_detect_colloquial_forms_reports_without_changing_text():
    found = detect_colloquial_forms("هواشو چک کن")
    assert "هواشو" in found


def test_routing_decision_legacy_tuple_compatibility():
    decision = RoutingDecision(
        route="tool",
        selected_intent="weather",
        confidence=0.91,
        raw_text="هوا چطوره",
    )
    intent, confidence, raw = decision.as_legacy_tuple()
    assert intent == "weather"
    assert confidence == 0.91
    assert raw == "هوا چطوره"


def test_intent_candidate_defaults():
    cand = IntentCandidate(name="emotional_statement", score=0.93, source="test")
    assert cand.requires_tool is False
    assert cand.contradictions == ()


def test_logger_writes_and_reads_back(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "CONVERSATION_LOG_DIR", str(tmp_path))
    monkeypatch.setattr(config, "CONVERSATION_LOG_FILE", "test_decisions.jsonl")
    import trx_ai.conversation.conversation_logger as cl
    monkeypatch.setattr(cl, "_log_path", None)

    ok = log_turn_decision(
        normalized_text="امروز خسته شدم",
        active_topic="mood",
        continuity_score=0.8,
        emotion="tired",
        candidate_intents=[IntentCandidate(name="emotional_statement", score=0.9)],
        selected_route=RoutingDecision(
            route="conversation", selected_intent="emotional_statement", confidence=0.9,
        ),
        blocked_tools=("web_search",),
        reason_codes=("emotional_statement_priority",),
    )
    assert ok is True

    path = cl._resolve_log_path()
    assert path.exists()
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    record = json.loads(lines[0])
    assert record["emotion"] == "tired"
    assert record["blocked_tools"] == ["web_search"]
    assert "raw_text" not in record  # LOG_RAW_TEXT پیش‌فرض False است

    recent = read_recent_decisions(limit=5)
    assert len(recent) == 1
    assert recent[0]["active_topic"] == "mood"


def test_logger_never_raises_on_bad_path(monkeypatch):
    import trx_ai.conversation.conversation_logger as cl
    monkeypatch.setattr(cl, "_resolve_log_path", lambda: (_ for _ in ()).throw(OSError("boom")))
    ok = log_turn_decision(
        normalized_text="x", active_topic=None, continuity_score=None, emotion=None,
        candidate_intents=[], selected_route=None,
    )
    assert ok is False  # شکست خورد اما استثنا بیرون نیامد


def test_conversation_intelligence_kill_switch_is_a_real_bool():
    # از Phase G به بعد پیش‌فرض True است (سیستم متصل)؛ این تست فقط
    # اطمینان می‌دهد که خودِ کلید هنوز یک bool معتبر و قابلِ override
    # با متغیرِ محیطی است -- نه اینکه مقدارش هارد‌کد/خراب شده باشد.
    assert isinstance(config.CONVERSATION_INTELLIGENCE_ENABLED, bool)
