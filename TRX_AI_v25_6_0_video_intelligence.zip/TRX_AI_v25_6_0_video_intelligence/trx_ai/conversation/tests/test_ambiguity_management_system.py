# -*- coding: utf-8 -*-
"""
تست‌هایِ Definition-of-Done برایِ AMS -- دقیقاً همان جدولِ A01 تا A20 در
بخشِ ۸۴ سندِ AMBIGUITY_MANAGEMENT_COMPLETE_SPEC.

این فایل روی خودِ ``conversation_engine.process`` اجرا می‌شود (نه
مستقیماً ``ambiguity_manager``) -- یعنی end-to-end: نرمال‌سازی، context،
AMS، داوری، و نگاشتِ نهایی به نیتِ legacy، همه با هم. هر مقدارِ
"دستی-تأییدشده" (manually verified) در حینِ توسعه با اجرایِ واقعیِ این
pipeline (نه فقط خواندنِ کد) به‌دست آمده -- نگاه کنید به تاریخچه‌یِ
گفتگو/PATCH NOTES برایِ خروجیِ خامِ آن اجراها.
"""

from __future__ import annotations

import pytest

from trx_ai.conversation import conversation_engine, state_tracker


@pytest.fixture
def conv_id():
    cid = "pytest_ams_definition_of_done"
    state_tracker.reset_snapshot(cid)
    yield cid
    state_tracker.reset_snapshot(cid)


def _send(cid, text, **kwargs):
    result = conversation_engine.process(text, conversation_id=cid, **kwargs)
    assert result is not None, f"conversation_engine.process نباید برایِ {text!r} None برگرداند"
    return result


def _with_topic(cid):
    """یک نوبتِ اول که ``کنکور`` را به‌عنوانِ ``active_topic`` قفل می‌کند --
    برایِ آزمونِ A01-A05/A15-A19 که همه به Context نیاز دارند."""
    _send(cid, "امروز راجع به کنکور نگران بودم", topic_hint="کنکور")


# ======================================================================
#   A01-A05 -- Referential/Contextual short follow-ups (بخشِ ۶/۵۵/۸۴)
# ======================================================================
@pytest.mark.parametrize(
    "text",
    ["چی؟", "اون چی شد؟", "این؟", "بعدش؟", "کدوم؟"],
)
def test_short_followup_resolved_via_context(conv_id, text):
    _with_topic(conv_id)
    intent, confidence, _ = _send(conv_id, text)
    assert intent == "conversation_follow_up"
    assert confidence >= 0.8, "با Contextِ موجود، نباید بازهم سؤالِ ابهام بپرسد"


# ======================================================================
#   A06 -- Social act («خسته نباشید») -- هرگز general/ژنریکِ خالی نیست،
#   دستِ‌کم باید امتیازش بالاتر از general/۰.۴ خامِ قدیمی باشد (بخشِ
#   دیگری از این ارتقا -- SmallTalkEngine.courtesy_appreciation -- متنِ
#   واقعیِ پاسخ را می‌سازد).
# ======================================================================
def test_social_courtesy_is_not_generic_fallback(conv_id):
    intent, confidence, _ = _send(conv_id, "خسته نباشید")
    assert intent == "general"
    assert confidence > 0.4, "باید از general/۰.۴ خامِ fallback بالاتر باشد (یعنی یک دسته‌یِ واقعی پیدا شده)"


# ======================================================================
#   A07/A08 -- کنترل: پیامِ احساسیِ خالص و فرمانِ صریحِ ابزار نباید توسطِ
#   AMS دست‌کاری شوند.
# ======================================================================
def test_pure_emotional_statement_untouched(conv_id):
    intent, confidence, _ = _send(conv_id, "واقعاً خوشحالم")
    assert intent == "emotional_support"


def test_explicit_tool_command_untouched(conv_id):
    intent, confidence, _ = _send(conv_id, "آهنگ خوشحالم رو سرچ کن")
    assert intent == "web_search" and confidence >= 0.9


# ======================================================================
#   A09 -- Speech-Act: شکایتِ مستقیم به خودِ TRX -- باید conversation_repair
#   شود، نه general و نه یک ابزار.
# ======================================================================
def test_complaint_to_assistant_triggers_repair(conv_id):
    intent, confidence, _ = _send(conv_id, "تو چرا انقدر رو مخی")
    assert intent == "conversation_repair"
    assert confidence >= 0.8


# ======================================================================
#   A10/A11 -- فرمانِ صریحِ داخلی (P1) -- هرگز نباید AMS/general آن را
#   بگیرد؛ شاملِ رگرسیونِ خودِ این ارتقا (کارهام‌چیه) + نسخه‌ی محاوره‌ای
#   (کارام).
# ======================================================================
@pytest.mark.parametrize("text", ["کارهام چیه", "کارام"])
def test_explicit_internal_command_beats_ams(conv_id, text):
    intent, confidence, _ = _send(conv_id, text)
    assert intent == "task_list"
    assert confidence >= 0.9


# ======================================================================
#   A12 -- Entity ambiguity رویِ فرمانِ ابزار: موضوعِ سرچ فقط یک ضمیرِ
#   حل‌نشده است -- نباید واقعاً سرچ اجرا شود.
# ======================================================================
def test_unresolved_pronoun_blocks_tool_execution(conv_id):
    intent, confidence, _ = _send(conv_id, "اون رو سرچ کن")
    assert intent == "conversation_entity_clarification"
    assert intent != "web_search"


# ======================================================================
#   A13/A14 -- Correction Engine
# ======================================================================
@pytest.mark.parametrize("text", ["نه، اون رو نمی‌گم", "گفتم نتیجه کنکور"])
def test_correction_marker_locks_topic(conv_id, text):
    intent, confidence, _ = _send(conv_id, text)
    assert intent == "conversation_correction"
    snap = state_tracker.get_snapshot(conv_id)
    assert snap.corrected_topic_locked is True


# ======================================================================
#   A15/A16 -- فیلرهایِ کوتاهِ بیشتر + رگرسیونِ over-triggeringِ dictionary
#   (خودِ ممیزی: «یعنی چی؟» قبلاً به‌اشتباه intent=dictionary می‌گرفت).
# ======================================================================
def test_short_filler_khob(conv_id):
    _with_topic(conv_id)
    intent, _, _ = _send(conv_id, "خب؟")
    assert intent == "conversation_follow_up"


def test_yani_chi_no_longer_misfires_to_dictionary(conv_id):
    _with_topic(conv_id)
    intent, _, _ = _send(conv_id, "یعنی چی؟")
    assert intent == "conversation_follow_up"
    assert intent != "dictionary"


# ======================================================================
#   A17/A18 -- Topic/Action Transition
# ======================================================================
@pytest.mark.parametrize("text", ["ولش کن", "بیخیال"])
def test_topic_transition_markers(conv_id, text):
    _with_topic(conv_id)
    intent, _, _ = _send(conv_id, text)
    assert intent == "conversation_topic_transition"
    assert intent != "emotional_support"


# ======================================================================
#   A19 -- Reference Resolution («همون قبلی»)
# ======================================================================
def test_reference_to_previous_topic(conv_id):
    _with_topic(conv_id)
    intent, _, _ = _send(conv_id, "همون قبلی")
    assert intent == "conversation_follow_up"


# ======================================================================
#   A20 -- محافظِ چرخه‌یِ بی‌نهایتِ ابهام: سه پیامِ مبهمِ متوالی، بدونِ
#   Context، نباید سه‌بار پشتِ‌سرهم *همان* سؤالِ روشن‌سازی را بپرسد.
# ======================================================================
def test_no_infinite_clarification_loop(conv_id):
    # هیچ topic_hint‌ای داده نمی‌شود -- یعنی هیچ‌وقت "resolved_via_context"
    # نمی‌شود؛ باید بینِ «سؤال» و «بودجه‌ی سؤال تمام شد» نوسان کند، نه
    # اینکه هربار همان سؤال را دوباره بپرسد.
    _, conf1, _ = _send(conv_id, "چی؟")
    _, conf2, _ = _send(conv_id, "چی؟")
    _, conf3, _ = _send(conv_id, "چی؟")
    confidences = (conf1, conf2, conf3)
    # نبایدِ سخت: یعنی همان "نیاز به توضیحِ بیشتر" با اطمینانِ ۰.۷ سه‌بارِ
    # پیاپی تکرار نشود (این دقیقاً همان چرخه‌ی بی‌نهایتی‌ست که A20 منع می‌کند).
    assert not (confidences[0] == confidences[1] == confidences[2] == 0.7)
