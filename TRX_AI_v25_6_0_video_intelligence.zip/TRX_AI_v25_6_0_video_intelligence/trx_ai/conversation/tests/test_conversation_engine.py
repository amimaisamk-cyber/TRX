# -*- coding: utf-8 -*-
"""
تست‌هایِ سرتاسریِ Phase B تا G -- سناریوهایِ اجباریِ خودِ سندِ مهندسی
+ رگرسیونِ باگ‌هایی که در حینِ همین اتصال کشف و اصلاح شدند.

این فایل روی ``conversation_engine.process`` (تنها نقطه‌ی ورودیِ
عمومیِ پکیج) اجرا می‌شود -- دقیقاً همان چیزی که
``TurnProcessor._detect_intent`` صدا می‌زند -- تا تست‌ها به‌جایِ
جزئیاتِ داخلیِ هر ماژول، رفتارِ نهایی/قابلِ‌مشاهده را تضمین کنند.

پیش‌نیاز برایِ اجرا در محیطِ توسعه‌ی خودِ کاربر: ``pytest``. در محیطِ
این تحویل (sandbox بدونِ شبکه/pytest/aiohttp)، همین منطق به‌صورتِ
اسکریپتِ دستی هم اجرا و ۱۰۰٪ پاس شد -- نگاه کنید به
``CONVERSATION_INTELLIGENCE_PHASE_B_G_NOTES.md``.
"""

from __future__ import annotations

import pytest

from trx_ai.conversation import conversation_engine, state_tracker


@pytest.fixture(autouse=True)
def _isolated_conversation():
    conv_id = "pytest_conv"
    state_tracker.reset_snapshot(conv_id)
    yield conv_id
    state_tracker.reset_snapshot(conv_id)


def _route(conv_id, text, recent=None, topic_hint=None):
    result = conversation_engine.process(
        text, conversation_id=conv_id, recent_messages=recent or [], topic_hint=topic_hint,
    )
    assert result is not None, f"conversation_engine.process بازگشتِ None داد برایِ: {text!r}"
    return result  # (intent, confidence, raw_text)


# ----------------------------------------------------------------
#   سناریوهایِ اجباریِ سندِ مهندسی (بخشِ «تست کن»)
# ----------------------------------------------------------------

def test_multiturn_tired_exam_contrast_stays_conversational(_isolated_conversation):
    """مثالِ اصلیِ سند: خسته/کنکور/اما‌خوشحالم نباید هیچ‌وقت به ابزار برود."""
    conv_id = _isolated_conversation
    for text, recent in [
        ("امروز خسته شدم", None),
        ("کنکور دادم", ["امروز خسته شدم"]),
        ("اما واقعاً خوشحالم", ["کنکور دادم"]),
    ]:
        intent, confidence, _ = _route(conv_id, text, recent=recent)
        assert intent == "emotional_support", f"{text!r} -> {intent} (باید emotional_support باشد)"


def test_pure_happy_statement_is_conversational(_isolated_conversation):
    intent, _, _ = _route(_isolated_conversation, "واقعاً خوشحالم")
    assert intent == "emotional_support"


def test_explicit_search_command_still_reaches_web_search(_isolated_conversation):
    intent, confidence, _ = _route(_isolated_conversation, "آهنگ خوشحالم را سرچ کن")
    assert intent == "web_search"
    assert confidence >= 0.9


def test_topic_shift_to_currency_still_works(_isolated_conversation):
    intent, _, _ = _route(_isolated_conversation, "راستی قیمت دلار چنده؟")
    assert intent == "currency"


def test_real_weather_question_still_reaches_weather_tool(_isolated_conversation):
    """رگرسیونِ باگِ کالیبراسیون: آستانه‌ی خیلی بالا این را قبلاً به‌غلط مسدود می‌کرد."""
    intent, confidence, _ = _route(_isolated_conversation, "فردا هوا چطوره؟")
    assert intent == "weather"
    assert confidence >= 0.5


def test_translation_command_still_works(_isolated_conversation):
    intent, _, _ = _route(_isolated_conversation, "این متن را ترجمه کن")
    assert intent == "translator"


def test_calculator_and_dictionary_unaffected(_isolated_conversation):
    intent1, conf1, _ = _route(_isolated_conversation, "۵ بعلاوه ۳ چقدر میشه")
    assert intent1 == "calculator" and conf1 >= 0.9
    intent2, conf2, _ = _route(_isolated_conversation, "معنی کلمه‌ی سلام چیه")
    assert intent2 == "dictionary" and conf2 >= 0.9


# ----------------------------------------------------------------
#   رگرسیونِ باگ‌هایِ کشف‌شده در همینِ اتصال
# ----------------------------------------------------------------

def test_regression_fuzzy_ama_dama_does_not_trigger_weather(_isolated_conversation):
    """
    باگِ کشف‌شده: «اما» با فاصله‌ی ویرایشیِ ۱ به کلیدواژه‌ی «دما» (وزن‌شناسی)
    شبیه است؛ بدونِ سقفِ fuzzy-only، این جمله به‌غلط به ابزارِ weather
    می‌رفت. این تست تضمین می‌کند که یک جمله‌ی احساسیِ حاویِ «اما» هرگز
    ابزار را صدا نمی‌زند.
    """
    intent, _, _ = _route(_isolated_conversation, "اما امروز اصلاً حوصله ندارم")
    assert intent != "weather"


def test_regression_punctuation_attached_keyword_phrase(_isolated_conversation):
    """
    باگِ کشف‌شده: ``nlu/matchers/keyword.py`` عبارتِ چندکلمه‌ای «خسته ام»
    را وقتی بلافاصله «،» (بدونِ فاصله) می‌آید تشخیص نمی‌دهد. این تست با
    دقیقاً همان جمله‌ی واقعیِ کاربرپسند تضمین می‌کند که این مورد از این
    پس (با پیش‌پردازشِ ``space_before_punctuation``) درست تشخیص داده شود.
    """
    intent, confidence, _ = _route(_isolated_conversation, "خسته‌ام، یه چیزی بگو حالم بهتر شه")
    assert intent == "emotional_support"
    assert confidence >= 0.6


def test_kill_switch_returns_none_signal_when_disabled(monkeypatch, _isolated_conversation):
    """اگر (فرضاً از بیرون) خاموش شود، ``conversation_engine`` هنوز قابلِ‌فراخوانی می‌ماند
    (خودِ خاموش‌کردن در ``TurnProcessor._detect_intent`` چک می‌شود، نه اینجا) --
    این تست فقط پایداریِ خودِ تابع را زیرِ ورودی‌هایِ لبه‌ای می‌سنجد."""
    result = conversation_engine.process("", conversation_id=_isolated_conversation)
    assert result is None  # ورودیِ خالی -> سیگنالِ صریحِ fallback


def test_never_raises_on_garbage_input(_isolated_conversation):
    for junk in [None, "   ", "🙂🙂🙂", "a" * 5000, "123456"]:
        try:
            conversation_engine.process(junk or "", conversation_id=_isolated_conversation)
        except Exception as exc:  # noqa: BLE001
            pytest.fail(f"conversation_engine.process باید هرگز استثنا ندهد؛ داد: {exc}")
