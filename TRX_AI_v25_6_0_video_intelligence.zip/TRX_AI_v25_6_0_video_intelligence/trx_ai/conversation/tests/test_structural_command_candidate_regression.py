# -*- coding: utf-8 -*-
"""
رگرسیونِ باگِ بحرانیِ کشف‌شده در ممیزیِ ۱۴۰۵/۰۶/۲۸ (AMS Audit):

``nlu/scorer.py::detect`` برایِ نیت‌هایِ «ساختاریِ قطعی» (``registry.STRUCTURAL``
-- خروج/راهنما/کارهام‌چیه/پروفایل/شخصیت/حافظه و ۱۹ موردِ دیگر، جمعاً ۲۴ نیت)
یک ``IntentResult`` با ``scores={}`` برمی‌گرداند (چون از مسیرِ آماری/کلیدواژه‌ای
عبور نمی‌کند). ``intent_candidates.generate`` پیش از این اصلاح فقط از رویِ
``legacy_result.scores.items()`` نامزد می‌ساخت -- یعنی نیتِ واقعی (با
confidence=0.98) کاملاً نادیده گرفته می‌شد و بازگشتِ نهایی همیشه
``("general", 0.4, raw_text)`` بود. چون ``conversation_engine.process()``
در این حالت None برنمی‌گرداند، ``TurnProcessor._detect_intent`` هم هرگز به
``IntentEngine`` قدیمی برنمی‌گشت -- یعنی حتی فرمانِ «خروج» هم در مسیرِ
پیش‌فرض (``CONVERSATION_INTELLIGENCE_ENABLED=True``) از کار می‌افتاد.

این فایل دقیقاً همان ۲۴ نیتِ ساختاری را قفل می‌کند تا این رگرسیون دیگر
بی‌صدا برنگردد.
"""

from __future__ import annotations

import pytest

from trx_ai.conversation import conversation_engine, state_tracker
from trx_ai.nlu import registry


@pytest.fixture(autouse=True)
def _isolated_conversation():
    conv_id = "pytest_structural_regression"
    state_tracker.reset_snapshot(conv_id)
    yield conv_id
    state_tracker.reset_snapshot(conv_id)


# نمونه‌یِ واقعیِ هر یک از ۲۳ نیتِ ساختاریِ منحصربه‌فرد (registry.STRUCTURAL
# دو الگوی مجزا برایِ memory_query دارد، پس نامِ نیت ۲۳ تا است، نه ۲۴) --
# هرکدام دستی با خودِ regex تطبیق داده و از رویِ conversation_engine واقعاً
# اجرا شده (نه فرضی) تا مطمئن شویم متنِ نمونه واقعاً به آن نیت می‌رسد.
_STRUCTURAL_SAMPLES: dict[str, str] = {
    "project_analysis": "تحلیل پروژه رو انجام بده",
    "persian_interpreter": "مفسر فارسی فعال شو",
    "self_learning": "یادت باشه فردا جلسه دارم",
    "memory_query": "یادته دیروز چی گفتم",
    "task_done": "کار #3 انجام شد",
    "task_delete": "کار #2 رو حذف کن",
    "task_add": "یادم بنداز قسط رو بدم",
    "task_list": "کارهام چیه",
    "unit_convert": "5 کیلومتر به متر",
    "password_gen": "رمز عبور قوی بساز",
    "bmi": "bmi من چنده",
    "expense_summary": "خلاصه خرجم چیه",
    "expense_add": "خرج کردم 5000 تومن",
    "backup_data": "پشتیبان گیری کن",
    "restore_data": "بازیابی کن",
    "mood_report": "تحلیل احساسی این گفتگو",
    "project_query": "پروژه هام چیه",
    "memory_save": "علاقه: فوتبال",
    "profile_query": "اسم من چیه",
    "profile_update": "اسم من علی است",
    "personality_change": "شخصیت رسمی",
    "help": "راهنما",
    "exit": "خروج",
}


@pytest.mark.parametrize("expected_intent,text", list(_STRUCTURAL_SAMPLES.items()))
def test_structural_intent_survives_conversation_intelligence(_isolated_conversation, expected_intent, text):
    intent, confidence, _ = conversation_engine.process(text, conversation_id=_isolated_conversation)
    assert intent == expected_intent, (
        f"{text!r} باید به نیتِ ساختاریِ {expected_intent!r} برسد، نه {intent!r} "
        f"(اگر intent == 'general' برگشت، یعنی باگِ نادیده‌گرفتنِ نامزدِ ساختاری برگشته)."
    )
    assert confidence >= 0.9, f"نیتِ ساختاری باید اطمینانِ رسمیِ ۰.۹۸ را حفظ کند، گرفت: {confidence}"


def test_every_registered_structural_pattern_has_at_least_one_regression_sample():
    """
    نگهبانِ سازگاری: اگر در آینده یک نیتِ ساختاریِ *جدید* به ``registry.STRUCTURAL``
    اضافه شود، این تست یادآوری می‌کند که نمونه‌اش هم به ``_STRUCTURAL_SAMPLES``
    اضافه شود -- تا پوششِ این رگرسیون کامل بماند.
    """
    declared_intents = {name for name, _pattern in registry.STRUCTURAL}
    missing = declared_intents - set(_STRUCTURAL_SAMPLES)
    assert not missing, (
        f"نیت(های) ساختاریِ بدونِ نمونه‌یِ رگرسیون: {sorted(missing)} -- "
        "به‌روزرسانیِ registry.STRUCTURAL باید با اضافه‌کردنِ نمونه به این فایل هم‌راه شود."
    )
