# -*- coding: utf-8 -*-
"""
Normalizer سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۱ سند).

مسئولیت -- دقیقاً همان چیزی که سند خواسته:
    - نگه‌داشتنِ raw_text (هیچ‌وقت دور ریخته نمی‌شود)
    - یکسان‌سازیِ ی/ي، ک/ك، فاصله و نیم‌فاصله
    - تشخیصِ شکل‌هایِ محاوره‌ای (فقط گزارش، نه اجبار)
    - اصلاحِ *پیشنهادی* غلطِ تایپی -- هرگز خودِ متن را عوض نمی‌کند
    - حفظِ اعداد، علائم، کلماتِ انگلیسی و کد دست‌نخورده

تصمیمِ معماری: به‌جایِ نوشتنِ یک normalizer موازیِ دیگر (که خودِ سند در
اصلِ ۸ این را قدغن کرده -- «سیستم‌هایِ روتینگِ موازی/متناقض»)، این
ماژول مستقیماً رویِ ``trx_ai.nlu.normalizer.normalize`` (که هم پیاده‌سازیِ
نیتیوِ ++C دارد و هم پایتونیِ خالص) و ``trx_ai.nlu.normalizer.stem``
سوار می‌شود. کارِ اضافه‌شده فقط تولیدِ ``MessageRecord`` و پیشنهادِ
اصلاحِ تایپی است -- چیزی که IntentEngine فعلی اصلاً نداشت (آن فقط
normalize می‌کند، پیشنهاد نمی‌دهد).
"""

from __future__ import annotations

import re
import time
import uuid

from ..nlu import _levenshtein
from ..nlu.normalizer import normalize as _nlu_normalize
from ..nlu.normalizer import stem as _nlu_stem
from .schemas import MessageRecord, ModuleHealth, ModuleResult

# اعداد/علائم/کدهایِ انگلیسی نباید دست‌کاری شوند -- فقط برایِ تشخیصِ
# اینکه یک توکن اصلاً کاندیدایِ اصلاحِ تایپیِ فارسی هست یا نه.
_LATIN_OR_DIGIT_RE = re.compile(r"^[A-Za-z0-9_./:\\\-@#]+$")
_TOKEN_STRIP_CHARS = "().,!؟?:؛\"'«»"

# شکل‌هایِ محاوره‌ایِ رایج -- فقط برایِ *گزارش* (colloquial_forms)، نه
# جایگزینی؛ اصلِ سند: «اصلاحِ پیشنهادی، نه تحمیلی».
_COLLOQUIAL_SUFFIXES = ("شو", "شون", "امو", "ه", "ن")

_MAX_TYPO_DISTANCE = 1
# دقیقاً همان آستانه‌یِ ``nlu/matchers/fuzzy.py::_MIN_KEYWORD_LEN`` (۳)
# -- عمداً هم‌راستا نگه داشته شده چون مثالِ مرجعِ خودِ آن ماژول دقیقاً
# «هوا»/«حوا» است (هر دو ۳ حرفی)؛ آستانه‌یِ متفاوت اینجا یعنی همان
# مثالِ مرجع در این ماژول رد می‌شد.
_MIN_WORD_LEN_FOR_TYPO_CHECK = 3

# باگِ کشف‌شده در ``nlu/matchers/keyword.py::_boundary_pattern``: مرزِ
# پایانیِ کلیدواژه با ``(?!\S)`` چک می‌شود -- یعنی *فقط* فاصله یا پایانِ
# رشته را مرز حساب می‌کند، نه علامتِ نگارشی. پس عبارتِ چندکلمه‌ایِ
# «خسته ام» در جمله‌ی کاملاً معمولیِ «خسته ام، یه چیزی بگو...» اصلاً
# تطبیق پیدا نمی‌کند (چون بلافاصله «،» می‌آید، نه فاصله)، درحالی‌که در
# «خسته ام حسابی» یا در انتهایِ جمله تطبیق می‌گیرد. این یک باگِ
# سیستمیِ از‌قبل‌موجود است (روی هر نیت/وضعیتی که کلیدواژه‌اش قبلِ یک
# علامتِ نگارشی بیاید اثر می‌گذارد) -- نگاه کنید به یادداشتِ Phase C/D.
#
# اصلاحِ ریشه‌ای در خودِ ``keyword.py`` عمداً اینجا انجام نمی‌شود (طبقِ
# قاعده‌ی ۴ پروتکلِ ممیزی: آن فایل را ده‌ها نیت/وضعیت به‌طورِ مشترک
# استفاده می‌کنند و تغییرِ مرزبندی نیاز به بررسیِ رگرسیونِ جداگانه و
# تأییدِ صریح دارد). راه‌حلِ *محلی و کم‌ریسک* اینجا: قبل از دادنِ متن
# به موتورهایِ قدیمی (``nlu.scorer.detect``، ``nlu.user_state.detect``)،
# یک فاصله جلویِ علائمِ نگارشیِ چسبیده اضافه می‌شود -- فقط در نسخه‌ی
# میانی‌ای که به آن موتورها داده می‌شود، نه در ``raw_text`` اصلی که
# برایِ اجرا/نمایش نگه‌داری می‌شود.
_TRAILING_PUNCTUATION_RE = re.compile(r"(?<=\S)([،؛,.!؟?:;])")


def _tokens(text: str) -> list[str]:
    return [t.strip(_TOKEN_STRIP_CHARS) for t in re.split(r"\s+", text) if t.strip(_TOKEN_STRIP_CHARS)]


def space_before_punctuation(text: str) -> str:
    """
    یک فاصله جلویِ علائمِ نگارشیِ چسبیده اضافه می‌کند -- فقط برایِ دادن
    به موتورهایِ قدیمیِ کلیدواژه‌محور (نگاه کنید به توضیحِ باگِ بالا).
    ``raw_text`` اصلی هرگز با این تابع جایگزین نمی‌شود.
    """
    if not text:
        return text
    return _TRAILING_PUNCTUATION_RE.sub(r" \1", text)


def suggest_typo_corrections(normalized_text: str, vocabulary: list[str]) -> tuple[tuple[str, str], ...]:
    """
    پیشنهادهایِ (کلمه‌یِ_ورودی، نزدیک‌ترین_واژه‌یِ_شناخته‌شده) برایِ
    توکن‌هایی که دقیقاً در ``vocabulary`` نیستند ولی فاصله‌یِ ویرایشیِ
    کمی با یکی از آن‌ها دارند.

    عمداً محافظه‌کار (دقیقاً همان فلسفه‌یِ ``nlu/matchers/fuzzy.py``):
        - فقط کلماتِ حداقل ۳ حرفی بررسی می‌شوند (کلماتِ کوتاه‌تر نویزی‌اند)
        - حداکثر فاصله‌یِ ویرایشیِ ۱
        - کلماتِ لاتین/عددی/کد رد می‌شوند
        - این تابع هرگز متن را عوض نمی‌کند؛ فقط پیشنهاد برمی‌گرداند --
          مصرف‌کننده (مثلاً response_planner یا یک UI) تصمیم می‌گیرد
          پیشنهاد را نشان بدهد یا نه.
    ``vocabulary`` باید از بیرون داده شود (مثلاً کلیدواژه‌هایِ
    ``nlu.registry``) تا این ماژول خودش یک فرهنگِ لغتِ تکراری نسازد.
    """
    if not normalized_text or not vocabulary:
        return ()
    vocab_set = set(vocabulary)
    suggestions: list[tuple[str, str]] = []
    for tok in _tokens(normalized_text):
        if len(tok) < _MIN_WORD_LEN_FOR_TYPO_CHECK or tok in vocab_set:
            continue
        if _LATIN_OR_DIGIT_RE.match(tok):
            continue
        tok_stem = _nlu_stem(tok)
        best: str | None = None
        for word in vocabulary:
            if abs(len(word) - len(tok)) > _MAX_TYPO_DISTANCE:
                continue
            if _nlu_stem(word) == tok_stem:
                continue  # از قبل معادل است، تایپو نیست
            if _levenshtein.levenshtein_distance(tok, word) <= _MAX_TYPO_DISTANCE:
                best = word
                break
        if best:
            suggestions.append((tok, best))
    return tuple(suggestions)


def detect_colloquial_forms(raw_text: str) -> tuple[str, ...]:
    """گزارشِ (نه اصلاحِ) توکن‌هایی که ظاهرِ محاوره‌ای/چسبیده دارند."""
    found = []
    for tok in _tokens(raw_text or ""):
        for suf in _COLLOQUIAL_SUFFIXES:
            if tok.endswith(suf) and len(tok) > len(suf) + 2:
                found.append(tok)
                break
    return tuple(found)


def build_message_record(
    raw_text: str,
    *,
    speaker: str = "user",
    conversation_id: str = "default",
    language: str = "fa",
    metadata: dict | None = None,
) -> ModuleResult:
    """
    نقطه‌یِ ورودیِ اصلیِ این ماژول: از متنِ خام یک ``MessageRecord``
    می‌سازد. هرگز استثنا پرتاب نمی‌کند -- طبقِ اصلِ پایداریِ سند، در
    صورتِ هر خطایِ غیرمنتظره یک ``ModuleResult`` با
    ``health=ModuleHealth.FALLBACK`` و ``value`` برابرِ یک رکوردِ
    حداقلی (raw_text دست‌نخورده، normalized_text = raw_text) برمی‌گردد.
    """
    start = time.perf_counter()
    try:
        raw = raw_text or ""
        normalized = _nlu_normalize(raw)
        record = MessageRecord(
            message_id=uuid.uuid4().hex[:12],
            raw_text=raw,
            normalized_text=normalized,
            speaker=speaker,
            language=language,
            conversation_id=conversation_id,
            metadata=dict(metadata or {}),
        )
        latency = (time.perf_counter() - start) * 1000
        return ModuleResult(value=record, health=ModuleHealth.OK, confidence=1.0, latency_ms=latency)
    except Exception as exc:  # noqa: BLE001 - این ماژول هرگز نباید کل نوبت را بترکاند
        fallback_record = MessageRecord(
            message_id=uuid.uuid4().hex[:12],
            raw_text=raw_text or "",
            normalized_text=raw_text or "",
            speaker=speaker,
            language=language,
            conversation_id=conversation_id,
            metadata=dict(metadata or {}),
        )
        latency = (time.perf_counter() - start) * 1000
        return ModuleResult(
            value=fallback_record,
            health=ModuleHealth.FALLBACK,
            confidence=0.0,
            error=str(exc),
            latency_ms=latency,
        )
