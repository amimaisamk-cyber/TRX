# -*- coding: utf-8 -*-
"""
Ambiguity Management System -- AMS (سندِ AMBIGUITY_MANAGEMENT_COMPLETE_SPEC،
بخش‌هایِ ۵۲ تا ۷۹).

جایگاه در معماری (طبقِ بخشِ ۵۳/۸۷ سند):

    Continuity Analyzer
        -> Ambiguity Management System (همین فایل)
        -> Intent Candidates
        -> Intent Arbitration
        -> Action Gate

اصلِ اصلیِ سند (بخشِ ۵۲): «ابهام ≠ شکست.» وقتی پیام کوتاه/مبهم/وابسته
به Context است، AMS باید قبل از رسیدنِ نوبت به «general/fallback/search»
یکی از این چهار مسیر را امتحان کند (بخشِ ۵۴):
    1) Context Resolution
    2) Semantic Expansion   -- در این نسخه اجرا نمی‌شود (نیازمندِ مدلِ
       معنایی/Neural که طبقِ بخشِ ۸۰ سند اختیاری و مستقل است)
    3) Candidate Comparison -- وظیفه‌یِ ``intent_arbitrator`` است، نه اینجا
    4) Minimal Clarification

مهم -- طبقِ بخشِ ۵۳/۷۹ سند: AMS مستقیماً Tool اجرا نمی‌کند و پاسخِ نهایی
نمی‌سازد. فقط یک ``AmbiguityAssessment`` برمی‌گرداند که شاملِ (در صورتِ
لزوم) نامِ یک IntentCandidate و چند به‌روزرسانیِ پیشنهادیِ state است؛
تصمیمِ نهایی همچنان با ``intent_arbitrator`` و اجرا با ``action_gate``
می‌ماند -- دقیقاً همان مرزبندیِ مسئولیتی که خودِ این پکیج (`conversation`)
از ابتدا رعایت کرده (نگاه کنید به ``intent_arbitrator.py``).

اصلِ پایداری (بخشِ ۷۹ سند -- AMS Failure Isolation): اگر این ماژول خطا
داد، ``conversation_engine.py`` باید بدونِ AMS ادامه بدهد (نه کرش)؛ این
دقیقاً همان الگویِ ``ModuleResult``یِ بقیه‌یِ ماژول‌هاست.

محدودیتِ صادقانه: تشخیص‌ها در این نسخه قاعده‌محور/کلیدواژه‌ای هستند (نه
یک مدلِ NLU کامل) -- دقیقاً همان فلسفه‌یِ Offline-First که بقیه‌یِ این
پکیج (topic_tracker، continuity_analyzer) هم استفاده می‌کنند. پوششِ
دقیقِ تست‌هایِ A01 تا A20 خودِ سند (بخشِ ۸۴) هدفِ طراحی بوده، نه یک
تعمیمِ کاملاً باز به هر جمله‌یِ فارسی.
"""

from __future__ import annotations

import re

from . import topic_tracker
from .schemas import (
    AmbiguityAssessment,
    AmbiguityType,
    ContextSnapshot,
    ModuleHealth,
    ModuleResult,
    TopicRelation,
)

# ==========================================================
#   نشانه‌هایِ Frustration -- بخشِ ۲۱ سند (فهرستِ عینِ سند)
# ==========================================================
_FRUSTRATION_MARKERS = (
    "چند بار بگم", "گفتم که", "نمی‌فهمی؟", "نمیفهمی؟", "داری رو مخم میری",
    "متوجه نمی‌شی", "متوجه نمیشی", "قبلاً گفتم", "قبلا گفتم", "چرا نمی‌فهمی",
    "چرا نمیفهمی",
)
_FRUSTRATION_INCREMENT = 0.35  # طبقِ مثالِ خودِ سند در بخشِ ۱۷: frustration += 0.35
_FRUSTRATION_DECAY = 0.15  # اگر نوبتِ جاری نشانه‌ای نداشت، آهسته کم شود (بدونِ صفرشدنِ ناگهانی)
_FRUSTRATION_HIGH_THRESHOLD = 0.6  # از این به بالا: question_budget=0 (بخشِ ۲۰ سند)

# ==========================================================
#   Speech-Act: شکایت/اعتراضِ مستقیم به خودِ TRX -- بخشِ ۴۱ سند
#   («تو چرا انقدر رو مخی») + T13/T19 (بخشِ ۴۶) + A09 (بخشِ ۸۴)
# ==========================================================
# دقیقاً «تو» + یک فعل/صفتِ دومِ‌شخصِ منفی -- نه هر جمله‌ی حاویِ «تو».
_COMPLAINT_TO_ASSISTANT_PATTERNS = (
    re.compile(r"تو\s*چرا\s*(انقدر|اینقدر|اینهمه)?\s*رو\s*مخ"),
    re.compile(r"(داری|دارین)\s*رو\s*مخم\s*(میری|میرید|می‌روی)"),
    re.compile(r"نمی[\s\u200c]?فهمی\s*چی\s*(میگم|می‌گم)"),
    re.compile(r"چرا\s*نمی[\s\u200c]?فهمی"),
    re.compile(r"اصلاً?\s*(حواست|گوش)\s*(نیست|نمیدی|نمی‌دی)"),
)

# ==========================================================
#   Topic/Action Transition -- بخشِ A17/A18 سند («ولش کن»، «بیخیال»)
# ==========================================================
_TOPIC_TRANSITION_MARKERS = ("ولش کن", "ولش کنیم", "بیخیال", "بی‌خیال", "فراموشش کن", "مهم نیست دیگه", "اصلا مهم نیست")

# ==========================================================
#   پیام‌هایِ کوتاهِ وابسته به Context -- بخشِ ۶ و ۵۵ سند
# ==========================================================
# هر عبارت با \b طبیعیِ فارسی (مرزِ فاصله) چک می‌شود -- نه substring خام --
# تا مثلاً «همینو میگم» به‌جایِ «همین» با معنایِ دیگر اشتباه گرفته نشود.
_REFERENTIAL_TOKENS = ("این", "اون", "همون", "همین")
_SHORT_FOLLOWUP_TOKENS = (
    "چی", "خب", "چرا", "چطور", "باشه", "واقعا", "واقعاً", "مگه", "پس",
    "یعنی", "بعد", "بعدش", "کدوم", "کدام",
)
_MAX_FOLLOWUP_WORD_COUNT = 5  # طبقِ بخشِ ۸۶ سند (Performance) -- فقط پیامِ واقعاً کوتاه AMS را درگیر کند
_FUNCTION_WORDS = ("رو", "را", "با", "که", "و", "یا", "هم")


_PUNCT_STRIP = "؟?!.،,؛:؛…\"'«»"


def _tokenize(text: str) -> list[str]:
    """توکن‌سازیِ ساده: جدا از رویِ فاصله/نیم‌فاصله، با حذفِ علائمِ نگارشیِ
    چسبیده به ابتدا/انتهایِ هر واژه (تا "چیه" با "چی" یکی گرفته نشود، اما
    "چی؟" هم درست به‌عنوانِ "چی" شناخته شود)."""
    raw = text.replace("\u200c", " ")
    return [w.strip(_PUNCT_STRIP) for w in raw.split() if w.strip(_PUNCT_STRIP)]


def _word_count(text: str) -> int:
    return len(_tokenize(text))


def _contains_any(text: str, tokens: tuple[str, ...]) -> str | None:
    """تطبیقِ *دقیقِ واژه* (نه substring) -- تا "چی" داخلِ "چیه"/"کارهام
    چیه" اشتباهاً به‌عنوانِ فیلرِ کوتاه شناخته نشود. فقط برایِ توکن‌هایِ
    تک‌واژه‌ای (نه عبارت‌هایِ چندواژه‌ای -- برایِ آن‌ها از
    ``_contains_phrase`` استفاده کنید)."""
    words = set(_tokenize(text))
    for tok in tokens:
        if tok in words:
            return tok
    return None


def _contains_phrase(text: str, phrases: tuple[str, ...]) -> str | None:
    """تطبیقِ عبارتِ چندواژه‌ای (substring، با نرمال‌سازیِ نیم‌فاصله) --
    برایِ مواردی مثلِ «ولش کن»/«چند بار بگم» که خودشان چند کلمه‌اند و
    ریسکِ اشتباه‌گرفته‌شدن با یک زیررشته‌یِ کوتاه‌تر را ندارند."""
    normalized = text.replace("\u200c", " ")
    for phrase in phrases:
        if phrase.replace("\u200c", " ") in normalized:
            return phrase
    return None


def _detect_frustration(text: str) -> tuple[bool, str | None]:
    for marker in _FRUSTRATION_MARKERS:
        if marker in text:
            return True, marker
    return False, None


def _detect_complaint_to_assistant(text: str) -> bool:
    return any(p.search(text) for p in _COMPLAINT_TO_ASSISTANT_PATTERNS)


def _detect_topic_transition(text: str) -> str | None:
    return _contains_phrase(text, _TOPIC_TRANSITION_MARKERS)


_GENERIC_CORRECTION_PATTERN = re.compile(r"^نه[،,]?\s+.*\b(نبود|نیست|نمی[\s\u200c]?گم|نگفتم|منظورم)\b")


def _detect_correction(text: str) -> str | None:
    for marker in topic_tracker.CORRECTION_MARKERS:
        if marker in text:
            return marker
    # الگویِ عمومی‌ترِ «گفتم/گفته بودم + موضوع» -- بخشِ ۱۷ سند، مثالِ
    # «چند بار بگم ترسم از بد شدن نتیجه کنکوره» و A14 «گفتم نتیجه کنکور».
    if re.search(r"^گفتم\b", text) or "چند بار بگم" in text:
        return "گفتم/چند_بار_بگم"
    # A13: «نه، اون رو نمی‌گم» -- شروع با «نه» + یک نشانه‌یِ نفی/تصحیح.
    if _GENERIC_CORRECTION_PATTERN.search(text):
        return "نه_+_نفی"
    return None


def _detect_unresolved_pronoun_tool_target(text: str) -> bool:
    """
    A12: «اون رو سرچ کن» -- فرمانِ صریحِ ابزار (سرچ) با موضوعی که فقط
    یک ضمیرِ حل‌نشده است. تشخیص: بعدِ حذفِ خودِ فعلِ ابزار، آنچه می‌ماند
    فقط یک ضمیر است (نه یک اسمِ واقعی).
    """
    if not re.search(r"(سرچ|جستجو|پیدا)\s*کن", text):
        return False
    stripped = re.sub(r"(سرچ|جستجو|پیدا)\s*کن\b", "", text)
    stripped = re.sub(r"\b(رو|را)\b", "", stripped)
    stripped = re.sub(r"[؟?.!]", "", stripped)
    stripped = stripped.strip()
    return stripped in ("این", "اون", "همون", "همین") or stripped == ""


def assess(
    normalized_text: str,
    *,
    raw_text: str,
    snapshot: ContextSnapshot,
    relation: TopicRelation,
    has_strong_tool_candidate: bool,
) -> ModuleResult:
    """
    ``has_strong_tool_candidate``: True اگر ``intent_candidates`` از قبل
    یک نامزدِ ابزارِ صریح/قوی تولید کرده (مثلاً یک فرمانِ ساختاری یا
    امتیازِ خیلی بالا) -- طبقِ اصلِ ۱ سند («Context قبل از Keyword است»)
    این هنوز به AMS اجازه می‌دهد شکایت/تصحیح/فرسودگی را تشخیص بدهد
    (چون این‌ها می‌توانند حتی روی یک پیامِ طولانی هم رخ دهند)، اما AMS
    هرگز یک فرمانِ *ساختاریِ رسمی* (P0/P1 طبقِ بخشِ ۳ سند) را override
    نمی‌کند -- آن تصمیم قبلاً در ``intent_arbitrator`` با اولویتِ بالاتر
    گرفته می‌شود.
    """
    try:
        text = normalized_text or ""
        evidence: list[str] = []
        state_updates: dict = {}

        # ------------------------------------------------------------
        # ۱) Frustration Detector (بخشِ ۲۱) -- همیشه چک می‌شود، صرف‌نظر
        #    از اینکه نتیجه‌اش کاندیدا بسازد یا نه؛ فقط state را می‌سازد.
        # ------------------------------------------------------------
        frustrated, frustration_marker = _detect_frustration(text)
        new_frustration = snapshot.frustration_score
        if frustrated:
            new_frustration = min(1.0, snapshot.frustration_score + _FRUSTRATION_INCREMENT)
            evidence.append(f"frustration_marker:{frustration_marker}")
        else:
            new_frustration = max(0.0, snapshot.frustration_score - _FRUSTRATION_DECAY)
        state_updates["frustration_score"] = round(new_frustration, 3)

        # ------------------------------------------------------------
        # ۲) Correction Engine (بخشِ ۱۷) -- بالاترین اولویتِ AMS، چون
        #    طبقِ سند correction باید فوراً obsolete‌کردنِ تفسیرِ قبلی و
        #    قفل‌شدنِ موضوع را باعث شود، حتی اگر یک نامزدِ ابزارِ ضعیف هم
        #    لمس شده باشد.
        # ------------------------------------------------------------
        correction_marker = _detect_correction(text) or (relation == TopicRelation.CORRECTION)
        if correction_marker:
            state_updates["corrected_topic_locked"] = True
            state_updates["ambiguity_streak"] = 0
            evidence.append(f"correction_marker:{correction_marker}")
            return ModuleResult(
                value=AmbiguityAssessment(
                    ambiguity_detected=True,
                    ambiguity_type=AmbiguityType.CONTEXTUAL,
                    candidate_name="conversation_correction",
                    confidence=0.92,
                    evidence=tuple(evidence),
                    needs_clarification=False,
                    state_updates=state_updates,
                ),
                confidence=0.92,
            )

        # ------------------------------------------------------------
        # ۳) Speech-Act: شکایت/اعتراض مستقیم به TRX (بخشِ ۴۱، A09)
        #    -- طبقِ بخشِ ۲۷ سند («Conversation wins» دربرابرِ Search)،
        #    این باید حتی اگر یک تطبیقِ ضعیفِ ابزار هم وجود داشته باشد
        #    برنده شود؛ AMS این را با امتیازِ بالا پیشنهاد می‌دهد و
        #    ``intent_arbitrator`` طبقِ اولویتِ خودش تصمیم می‌گیرد.
        # ------------------------------------------------------------
        if _detect_complaint_to_assistant(text):
            evidence.append("complaint_target:assistant")
            state_updates["last_speech_act"] = "complaint"
            state_updates["last_target"] = "assistant"
            return ModuleResult(
                value=AmbiguityAssessment(
                    ambiguity_detected=True,
                    ambiguity_type=AmbiguityType.SPEECH_ACT,
                    candidate_name="conversation_repair",
                    confidence=0.9,
                    evidence=tuple(evidence),
                    needs_clarification=False,
                    state_updates=state_updates,
                ),
                confidence=0.9,
            )

        # ------------------------------------------------------------
        # ۴) Entity ambiguity رویِ فرمانِ صریحِ ابزار (بخشِ ۵۶-D، A12)
        #    «اون رو سرچ کن» -- قبل از هر چیز چک می‌شود چون این تنها
        #    حالتی‌ست که AMS باید یک تصمیمِ tool را مسدود کند.
        # ------------------------------------------------------------
        if _detect_unresolved_pronoun_tool_target(text):
            evidence.append("unresolved_pronoun_tool_target")
            return ModuleResult(
                value=AmbiguityAssessment(
                    ambiguity_detected=True,
                    ambiguity_type=AmbiguityType.ENTITY,
                    candidate_name="conversation_entity_clarification",
                    confidence=0.85,
                    evidence=tuple(evidence),
                    needs_clarification=True,
                    clarification_text="منظورت چیه که برات سرچ کنم؟ اسمش رو دقیق بگو.",
                    state_updates=state_updates,
                ),
                confidence=0.85,
            )

        # ------------------------------------------------------------
        # ۵) Topic/Action Transition (بخشِ A17/A18) -- «ولش کن»/«بیخیال»
        # ------------------------------------------------------------
        transition_marker = _detect_topic_transition(text)
        if transition_marker:
            evidence.append(f"topic_transition_marker:{transition_marker}")
            state_updates["active_topic"] = None
            state_updates["ambiguity_streak"] = 0
            return ModuleResult(
                value=AmbiguityAssessment(
                    ambiguity_detected=True,
                    ambiguity_type=AmbiguityType.ACTION,
                    candidate_name="conversation_topic_transition",
                    confidence=0.75,
                    evidence=tuple(evidence),
                    needs_clarification=False,
                    state_updates=state_updates,
                ),
                confidence=0.75,
            )

        # ------------------------------------------------------------
        # ۶) پیام‌هایِ کوتاهِ ارجاعی/دنباله‌ای (بخشِ ۶/۵۵، A01-A05/A15/A16/A19)
        #    فقط اگر پیام واقعاً کوتاه است -- طبقِ بخشِ ۸۶ سند (Fast Path):
        #    پیام‌هایِ واضح نباید بی‌دلیل این مسیر را طی کنند.
        # ------------------------------------------------------------
        tokens_now = _tokenize(text)
        # اگر بعدِ کنارگذاشتنِ فیلر/ضمیر/حروفِ‌ربط، هیچ «کلمه‌یِ محتوایی»
        # باقی نماند (مثلِ «یعنی چی؟» -- هر دو توکن فیلرند)، یعنی پیام
        # ذاتاً نمی‌تواند یک فرمانِ ابزارِ واقعی باشد (هر فرمانِ واقعی به
        # یک موضوع/کلیدواژه نیاز دارد) -- پس حتی اگر یک تطبیقِ آماریِ
        # ضعیف/اشتباهِ ابزار هم لمس شده باشد (بخشِ ممیزی: «یعنی چی؟» تا
        # امروز به‌اشتباه intent=dictionary می‌گرفت چون «یعنی چی» یکی از
        # کلیدواژه‌هایِ آن ابزار است)، AMS باید برنده بماند.
        content_words = [
            w for w in tokens_now
            if w not in _SHORT_FOLLOWUP_TOKENS and w not in _REFERENTIAL_TOKENS and w not in _FUNCTION_WORDS
        ]
        pure_filler_message = not content_words

        if (not has_strong_tool_candidate or pure_filler_message) and _word_count(text) <= _MAX_FOLLOWUP_WORD_COUNT:
            ref_hit = _contains_any(text, _REFERENTIAL_TOKENS)
            filler_hit = _contains_any(text, _SHORT_FOLLOWUP_TOKENS)
            if ref_hit or filler_hit:
                ambiguity_type = AmbiguityType.REFERENTIAL if ref_hit else AmbiguityType.CONTEXTUAL
                evidence.append(f"short_followup_token:{ref_hit or filler_hit}")

                has_context = bool(snapshot.active_topic or snapshot.last_speech_act or snapshot.recent_event)
                if has_context:
                    # Context Resolution (بخشِ ۵۴-۱) موفق شد -- سؤال لازم نیست.
                    evidence.append("resolved_via_context")
                    state_updates["ambiguity_streak"] = 0
                    return ModuleResult(
                        value=AmbiguityAssessment(
                            ambiguity_detected=True,
                            ambiguity_type=ambiguity_type,
                            candidate_name="conversation_follow_up",
                            confidence=0.88,
                            evidence=tuple(evidence),
                            needs_clarification=False,
                            state_updates=state_updates,
                        ),
                        confidence=0.88,
                    )

                # هیچ Contextی برایِ حل‌کردن نیست -- Minimal Clarification
                # (بخشِ ۵۴-۴)، اما با محافظِ چرخه‌یِ بی‌نهایت (A20/بخشِ ۲۰).
                streak = snapshot.ambiguity_streak
                if streak >= 1:
                    # قبلاً یک‌بار سؤال پرسیده شده و کاربر بازهم مبهم جواب
                    # داده -- طبقِ بخشِ ۸۳-H/۸۸ سند: دیگر سؤال تکرار نشود؛
                    # یک پاسخِ طبیعی و صادقانه (نه ربات‌وار) کافی‌ست.
                    evidence.append("clarification_budget_exhausted")
                    state_updates["ambiguity_streak"] = 0
                    return ModuleResult(
                        value=AmbiguityAssessment(
                            ambiguity_detected=True,
                            ambiguity_type=ambiguity_type,
                            candidate_name="conversation_follow_up",
                            confidence=0.6,
                            evidence=tuple(evidence),
                            needs_clarification=False,
                            state_updates=state_updates,
                        ),
                        confidence=0.6,
                    )

                state_updates["ambiguity_streak"] = streak + 1
                return ModuleResult(
                    value=AmbiguityAssessment(
                        ambiguity_detected=True,
                        ambiguity_type=ambiguity_type,
                        candidate_name="conversation_follow_up",
                        confidence=0.7,
                        evidence=tuple(evidence),
                        needs_clarification=True,
                        clarification_text="دقیق نگرفتم منظورت رو -- می‌شه یه‌کم بیشتر توضیح بدی؟",
                        state_updates=state_updates,
                    ),
                    confidence=0.7,
                )

        # ------------------------------------------------------------
        # هیچ نوعِ ابهامِ قابلِ‌تشخیصی نبود -- فقط frustration_score
        # به‌روزرسانی می‌شود (که در بالا محاسبه شده).
        # ------------------------------------------------------------
        return ModuleResult(
            value=AmbiguityAssessment(state_updates=state_updates),
            confidence=1.0,
        )

    except Exception as exc:  # noqa: BLE001 -- بخشِ ۷۹ سند: AMS Failure Isolation
        return ModuleResult(
            value=AmbiguityAssessment(),
            health=ModuleHealth.FALLBACK,
            confidence=0.0,
            error=str(exc),
        )
