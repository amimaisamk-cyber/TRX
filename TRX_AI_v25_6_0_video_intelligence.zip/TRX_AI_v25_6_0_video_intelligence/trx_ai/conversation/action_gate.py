# -*- coding: utf-8 -*-
"""
Action Gate سامانه‌ی هوشمندیِ مکالمه (ماژولِ ۹ سند).

آخرین ایستگاه پیش از اینکه یک تصمیمِ «tool» واقعاً به ``ToolRouter``
برسد. طبقِ سند: «برایِ web search، فرمانِ صریح یا پرسشِ اطلاعاتیِ
روشن لازم است. پیامِ «واقعاً خوشحالم» نباید جستجو شود.»

این گیت مستقلِ arbitrator است (ماژولِ جدا، طبقِ اصلِ ۸ سند) تا حتی
اگر arbitrator به هر دلیلی (باگ/موردِ لبه‌ای) یک تصمیمِ «tool» با
شواهدِ ضعیف تولید کند، این لایه‌یِ دوم مستقلاً دوباره بررسی‌اش کند --
دفاعِ لایه‌ای (defense in depth)، نه اعتمادِ کورکورانه به تصمیمِ قبلی.
"""

from __future__ import annotations

from ..nlu import registry as _nlu_registry
from . import config
from .schemas import ModuleHealth, ModuleResult, RoutingDecision


def check(decision: RoutingDecision) -> ModuleResult:
    try:
        if decision.route != "tool":
            return ModuleResult(value=decision, confidence=decision.confidence)

        spec = _nlu_registry.PATTERNS.get(decision.selected_intent)
        ref_tool = spec.ref_tool if spec else None

        if ref_tool not in config.GATED_TOOLS:
            return ModuleResult(value=decision, confidence=decision.confidence)

        is_explicit = "explicit_tool_command" in decision.reason_codes
        if is_explicit or decision.confidence >= config.GATED_TOOL_MIN_SCORE:
            return ModuleResult(value=decision, confidence=decision.confidence)

        # گیت رد نکرد: به مکالمه سپرده می‌شود، نه اجرایِ ابزارِ
        # پرهزینه/شبکه‌ای بدونِ شواهدِ کافی.
        gated = RoutingDecision(
            route="conversation",
            selected_intent="general",
            confidence=decision.confidence,
            reason_codes=decision.reason_codes + ("action_gate_blocked",),
            blocked_tools=decision.blocked_tools + (ref_tool,),
            needs_followup=decision.needs_followup,
            raw_text=decision.raw_text,
        )
        return ModuleResult(value=gated, confidence=decision.confidence)

    except Exception as exc:  # noqa: BLE001
        # اصلِ پایداری: اگر خودِ گیت خطا داد، محافظه‌کارانه‌ترین کار
        # مسدودکردنِ ابزار است، نه اجرایِ بی‌قید آن.
        safe = RoutingDecision(
            route="conversation", selected_intent="general", confidence=0.0,
            reason_codes=("action_gate_error",), raw_text=decision.raw_text,
        )
        return ModuleResult(value=safe, health=ModuleHealth.FALLBACK, confidence=0.0, error=str(exc))
