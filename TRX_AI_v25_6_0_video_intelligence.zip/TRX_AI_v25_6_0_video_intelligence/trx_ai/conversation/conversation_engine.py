# -*- coding: utf-8 -*-
"""
Conversation Engine -- ارکستراتورِ سامانه‌ی هوشمندیِ مکالمه.

این فایل تنها نقطه‌یِ ورودیِ عمومیِ کلِ پکیج ``trx_ai/conversation`` است.
``core_engine/turn_processor.py`` فقط همین یک تابع را صدا می‌زند
(``process``)؛ هیچ فایلِ دیگری در core_engine مستقیماً با
context_manager/state_tracker/emotion_analyzer/... کار ندارد -- دقیقاً
طبقِ اصلِ ۸ سند («Core فقط هماهنگ‌کننده باشد؛ منطقِ مکالمه در ماژولِ
مستقل بماند»).

زنجیره‌یِ اجرا -- دقیقاً همان چیزی که سند در ابتدا رسم کرده:
    ورودی → نرمال‌سازی → context → تحلیلِ احساس → ردیابیِ موضوع →
    تحلیلِ پیوستگی → نامزدهایِ intent → داوری → Action Gate →
    به‌روزرسانیِ state → برنامه‌ریزیِ پاسخ → نقد → RoutingDecision نهایی

اصلِ پایداری (بخشِ «پایداری» در سند): هیچ‌کدام از گام‌هایِ بالا نباید
کل نوبت را بترکاند. هر گام از قبل خودش (در فایلِ خودش) exception
boundary دارد و ``ModuleResult`` برمی‌گرداند؛ اینجا فقط چک می‌شود که
اگر یک گامِ *حیاتی* (نرمال‌سازی یا داوری) کاملاً شکست خورد،
``process()`` مقدارِ ``None`` برمی‌گرداند -- سیگنالِ روشن به
``turn_processor.py`` که باید به مسیرِ قدیمی (``IntentEngine.detect_intent``
مستقیم) برگردد. یعنی این ماژول هرگز استثنا به بیرون پرتاب نمی‌کند.
"""

from __future__ import annotations

import time

from . import (
    action_gate,
    ambiguity_manager,
    config,
    context_manager,
    continuity_analyzer,
    conversation_logger,
    emotion_analyzer,
    intent_arbitrator,
    intent_candidates,
    normalizer,
    response_critic,
    response_planner,
    state_tracker,
    topic_tracker,
)
from ..logging_config import get_logger
from .schemas import IntentCandidate, RoutingDecision

logger = get_logger(__name__)

# نگاشتِ نامِ نامزدهایِ داخلیِ این سامانه به نامِ نیتِ *واقعیِ* IntentEngine
# فعلی -- تا ``ToolRouter``/``TurnProcessor`` بدونِ هیچ تغییری همان
# مسیرهایِ بالغِ موجود (TherapyCompanion برایِ emotional_support،
# آبشارِ SmallTalk/ویکی‌پدیا/DuckDuckGo برایِ general) را اجرا کنند.
_CANDIDATE_TO_LEGACY_INTENT = {
    "emotional_statement": "emotional_support",
    "casual_conversation": "general",
}


def _to_legacy_intent(name: str) -> str:
    return _CANDIDATE_TO_LEGACY_INTENT.get(name, name)


def _observe_phase3_shadow(
    *,
    raw_text: str,
    conversation_id: str,
    normalized_text: str,
    context,
    recent_messages,
    candidates,
    relation,
    decision,
    emotion,
) -> None:
    """Optional, fail-soft Stage-4 observer. It can never affect routing."""
    try:
        # Do not import trx_ai.phase3 at all unless the explicit Shadow
        # environment switch is on. Importing a package executes its
        # __init__.py, so this tiny gate keeps the default conversation
        # path free of the native neural import cost.
        import os

        enabled = os.environ.get("TRX_PHASE3_ENABLED", "false").strip().lower()
        mode = os.environ.get("TRX_PHASE3_MODE", "disabled").strip().lower()
        if enabled not in ("1", "true", "yes", "on") or mode != "shadow":
            return

        from ..phase3.shadow import get_shadow_runner

        get_shadow_runner().observe(
            raw_text=raw_text,
            conversation_id=conversation_id,
            normalized_text=normalized_text,
            context=context,
            recent_messages=recent_messages or (),
            intent_candidates=candidates or (),
            symbolic_relation=getattr(relation, "value", relation),
            symbolic_decision=decision,
            symbolic_emotion=emotion,
        )
    except Exception as exc:  # noqa: BLE001 - shadow must never break live chat
        logger.debug("Phase 3 Shadow observer skipped: %s", exc)


def _observe_nervous_system(
    *,
    conversation_id: str,
    raw_text: str,
    recent_messages,
    snapshot,
    emotion,
    relation,
    continuity_score,
    candidates,
    decision,
    critic_flags,
    long_term_snippets,
    turn_latency_ms: float,
) -> None:
    """Optional, fail-soft Nervous System observer (v25.5.5 PHASE 2 +
    v25.5.6 Pattern Bridge).

    این تابع هیچ‌وقت روی ``decision`` یا مقدارِ بازگشتیِ ``process`` اثر
    نمی‌گذارد -- فقط اگر ``TRX_NERVOUS_SYSTEM_ENABLED=1`` باشد، خروجیِ
    همین نوبت را در ``NervousSystemCoordinator`` جمع می‌کند (SHADOW).
    """
    try:
        from ..nervous_system import config as ns_config

        if not ns_config.NERVOUS_SYSTEM_ENABLED:
            return

        from ..nervous_system import get_coordinator
        from ..nervous_system import pattern_bridge

        # v25.5.6 -- تلاش برایِ ساختِ خلاصه‌یِ واقعیِ Pattern Engine.
        # کاملاً fail-soft و مستقل: اگر شکست بخورد یا None برگرداند،
        # Coordinator با pattern_engine_context=None ادامه می‌دهد (دقیقاً
        # همان رفتارِ v25.5.5).
        try:
            pattern_engine_context = pattern_bridge.build_pattern_context(
                raw_text, recent_messages
            )
        except Exception as exc:  # noqa: BLE001 - قانونِ عدمِ تخریب
            logger.debug("Pattern Bridge (nervous_system) شکست خورد: %s", exc)
            pattern_engine_context = None

        coordinator = get_coordinator()
        ctx = coordinator.build_context(
            conversation_id=conversation_id,
            raw_text=raw_text,
            recent_messages=recent_messages,
            snapshot=snapshot,
            emotion=emotion,
            relation=relation,
            continuity_score=continuity_score,
            candidates=candidates,
            decision=decision,
            critic_flags=critic_flags,
            long_term_snippets=long_term_snippets,
            turn_latency_ms=turn_latency_ms,
            pattern_engine_context=pattern_engine_context,
        )
        coordinator.record(ctx)
    except Exception as exc:  # noqa: BLE001 - قانونِ عدمِ تخریب v25.5.5
        logger.debug("Nervous System observer skipped: %s", exc)


def process(
    raw_text: str,
    *,
    conversation_id: str = "default",
    context_modes=None,
    db=None,
    recent_messages: list[str] | None = None,
    topic_hint: str | None = None,
    long_term_snippets: list[tuple[str, float]] | None = None,
) -> tuple[str, float, str] | None:
    """
    خروجی: همان سه‌تاییِ قدیمیِ ``(intent, confidence, raw_text)`` که
    ``TurnProcessor.process_turn`` امروز از ``IntentEngine.detect_intent``
    می‌گیرد -- تا ``ai._execute_route(...)`` بدونِ هیچ تغییری کار کند.
    اگر هر جایِ حیاتی شکست بخورد، ``None`` برمی‌گردد (سیگنالِ fallback).
    """
    turn_start = time.perf_counter()
    try:
        norm_result = normalizer.build_message_record(raw_text, conversation_id=conversation_id)
        normalized_text = norm_result.value.normalized_text
        if not normalized_text:
            return None  # ورودیِ خالی -- بگذار مسیرِ قدیمی همان رفتارِ قبلی را داشته باشد

        snapshot = state_tracker.get_snapshot(conversation_id)
        bundle = context_manager.build_context_bundle(
            recent_messages=recent_messages, structured=snapshot, long_term_snippets=long_term_snippets,
        )

        # نگاه کنید به توضیحِ باگِ مرزبندیِ کلیدواژه/علامتِ‌نگارشی در
        # normalizer.py -- user_state.detect هم از همان کلیدواژه‌های
        # چندکلمه‌ای استفاده می‌کند، پس همان ورودیِ اصلاح‌شده به آن هم داده می‌شود.
        spaced_for_legacy = normalizer.space_before_punctuation(raw_text)
        emotion = emotion_analyzer.analyze(
            spaced_for_legacy,
            context_text=" ".join(recent_messages or []),
            previous_emotion=snapshot.current_emotion if snapshot.current_emotion != "neutral" else None,
            db=db,
        ).value

        relation, relation_evidence = topic_tracker.analyze_relation(
            normalized_text,
            active_topic=snapshot.active_topic,
            topic_hint=topic_hint,
            unanswered_question=snapshot.unanswered_question,
        ).value

        continuity_score = continuity_analyzer.score(
            normalized_text, relation=relation, recent_fragments=bundle.recent, mixed_emotion=emotion.mixed_emotion,
        ).value

        candidates_result = intent_candidates.generate(
            raw_text, emotion=emotion, context_modes=context_modes, db=db,
        )
        candidates = candidates_result.value

        # ==================================================================
        # Ambiguity Management System -- AMS (سندِ AMBIGUITY_MANAGEMENT_
        # COMPLETE_SPEC، بخش‌هایِ ۵۲ تا ۷۹). جایگاهش دقیقاً طبقِ نقشه‌یِ
        # معماریِ خودِ سند: بعدِ Continuity Analyzer و *قبل* از Arbitration
        # -- تا اگر AMS یک نامزدِ جدید پیشنهاد داد، همان یک نامزدِ عادیِ
        # دیگر برایِ Arbitration باشد (بخشِ ۵۳ سند: «AMS جایگزینِ Arbitrator
        # نیست، فقط ورودیِ آن را کامل‌تر می‌کند»).
        # ==================================================================
        has_strong_tool_candidate = any(
            c.requires_tool and c.score >= config.KEYWORD_ONLY_TOOL_MIN_SCORE for c in candidates
        )
        ambiguity_result = ambiguity_manager.assess(
            normalized_text,
            raw_text=raw_text,
            snapshot=snapshot,
            relation=relation,
            has_strong_tool_candidate=has_strong_tool_candidate,
        )
        ambiguity = ambiguity_result.value
        if ambiguity.candidate_name:
            candidates = candidates + (
                IntentCandidate(
                    name=ambiguity.candidate_name,
                    score=ambiguity.confidence,
                    evidence=ambiguity.evidence,
                    requires_tool=False,
                    source="ambiguity_manager",
                ),
            )

        arb_result = intent_arbitrator.arbitrate(candidates, raw_text=raw_text, continuity_score=continuity_score)
        decision: RoutingDecision = arb_result.value

        decision = action_gate.check(decision).value

        # response_planner در این نسخه صرفاً یک ResponsePlan تولید می‌کند
        # (برایِ لاگ/آینده)؛ روی انتخابِ نهاییِ intent اثر مستقیم ندارد --
        # طبقِ توضیحِ خودِ آن فایل.
        response_planner.plan(emotion=emotion, relation=relation, context=snapshot)

        decision, critic_flags = response_critic.review(decision, relation=relation).value

        # به‌روزرسانی‌هایِ پیشنهادیِ AMS (frustration/streak/last_speech_act/
        # ...) اینجا صریحاً اعمال می‌شوند -- طبقِ بخشِ ۳۰ سند («هیچ ماژول
        # حق نوشتنِ مستقیمِ state را ندارد»)، AMS خودش state را ننوشت،
        # فقط پیشنهاد داد؛ ``active_topic``یِ صریحِ ``topic_hint`` همیشه
        # اولویت دارد (اگر AMS هم "active_topic": None پیشنهاد داده باشد
        # -- یعنی «ولش کن» -- topic_hint هنوز خالی است، پس آن پیشنهاد
        # اعمال می‌شود).
        snapshot_updates = dict(ambiguity.state_updates)
        snapshot_updates["active_topic"] = topic_hint or snapshot_updates.get("active_topic", snapshot.active_topic)
        snapshot_updates.setdefault("ambiguity_streak", snapshot.ambiguity_streak)
        snapshot_updates.setdefault("frustration_score", snapshot.frustration_score)
        snapshot_updates.setdefault("corrected_topic_locked", snapshot.corrected_topic_locked)
        snapshot_updates.setdefault("last_speech_act", snapshot.last_speech_act)
        snapshot_updates.setdefault("last_target", snapshot.last_target)

        updated_snapshot = state_tracker.update_snapshot(
            conversation_id,
            current_emotion=emotion.emotion,
            previous_emotion=snapshot.current_emotion,
            emotion_intensity=emotion.intensity,
            known_cause=emotion.known_cause or snapshot.known_cause,
            last_tool=decision.selected_intent if decision.route == "tool" else snapshot.last_tool,
            context_confidence=continuity_score,
            **snapshot_updates,
        )

        conversation_logger.log_turn_decision(
            normalized_text=normalized_text,
            active_topic=snapshot.active_topic,
            continuity_score=continuity_score,
            emotion=emotion.emotion,
            candidate_intents=candidates,
            selected_route=decision,
            blocked_tools=decision.blocked_tools,
            reason_codes=decision.reason_codes + tuple(critic_flags),
            raw_text=raw_text,
            extra={"relation": relation.value, "latency_ms": round((time.perf_counter() - turn_start) * 1000, 2)},
        )

        # Nervous System Coordinator (v25.5.5, SHADOW). Observational only --
        # runs after the symbolic decision is complete and can never replace,
        # delay through failure, or mutate the decision returned below.
        # Default config (TRX_NERVOUS_SYSTEM_ENABLED unset) keeps this off.
        _observe_nervous_system(
            conversation_id=conversation_id,
            raw_text=raw_text,
            recent_messages=recent_messages,
            snapshot=updated_snapshot,
            emotion=emotion,
            relation=relation,
            continuity_score=continuity_score,
            candidates=candidates,
            decision=decision,
            critic_flags=critic_flags,
            long_term_snippets=bundle.long_term,
            turn_latency_ms=round((time.perf_counter() - turn_start) * 1000, 2),
        )

        # Stage 4 is observational only. It runs after the symbolic decision
        # is complete and can never replace, delay through failure, or mutate
        # the decision returned below. Default config keeps this path off.
        _observe_phase3_shadow(
            raw_text=raw_text,
            conversation_id=conversation_id,
            normalized_text=normalized_text,
            context=updated_snapshot,
            recent_messages=recent_messages,
            candidates=candidates,
            relation=relation,
            decision=decision,
            emotion=emotion,
        )

        try:
            from ..phase3.config import get_config, Phase3Mode
            from ..phase3.shadow import get_controlled_runner
            cfg = get_config()
            if cfg.enabled and cfg.mode is Phase3Mode.CONTROLLED_FUSION:
                draft = get_controlled_runner().try_advice(
                    conversation_id=conversation_id, text=normalized_text,
                    recent_messages=recent_messages or (),
                    symbolic_route=decision.route,
                    symbolic_intent=decision.selected_intent,
                    symbolic_confidence=decision.confidence,
                )
                if draft is not None:
                    return ('neural_draft', draft.confidence, raw_text)
        except Exception as exc:
            logger.debug('Controlled Phase 3 advice skipped: %s', exc)

        final_intent = _to_legacy_intent(decision.selected_intent)
        return (final_intent, decision.confidence, raw_text)

    except Exception as exc:  # noqa: BLE001 - اصلِ پایداری: هرگز به بیرون پرتاب نکن
        logger.warning("Conversation Intelligence شکست خورد؛ بازگشت به مسیرِ قدیمی: %s", exc)
        return None
