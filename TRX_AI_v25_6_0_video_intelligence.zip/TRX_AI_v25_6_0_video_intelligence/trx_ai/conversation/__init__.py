# -*- coding: utf-8 -*-
"""
Conversation Intelligence System (سندِ مهندسیِ ۱۴۰۵/۰۶/۲۷).

زیرسیستمِ مستقلِ فهمِ پیام/حفظِ context/ردیابیِ وضعیت/جلوگیری از اجرایِ
ابزارِ اشتباه/برنامه‌ریزیِ پاسخ/نقدِ پاسخ.

وضعیتِ پیاده‌سازی (این نسخه):
    Phase A -- schemas + logger + normalizer      ✅ انجام‌شده، تست‌شده
    Phase B -- context_manager + state_tracker    ✅ انجام‌شده، تست‌شده
    Phase C -- topic_tracker + continuity         ✅ انجام‌شده، تست‌شده
    Phase D -- candidates + arbitration           ✅ انجام‌شده، تست‌شده
    Phase E -- action_gate                        ✅ انجام‌شده، تست‌شده
    Phase F -- planner + critic                   ✅ انجام‌شده (نسخه‌ی سبک -- نگاه کنید به notes)
    Phase G -- اتصال به turn_processor.py          ✅ انجام‌شده (پشتِ kill switch + fallback خودکار)
    Phase H -- تست‌هایِ استرس/رگرسیون              ⏳ فقط سناریوهایِ اجباریِ سند تست شدند، نه fuzzing/استرس

نقطه‌ی اتصال: ``core_engine/turn_processor.py`` قبل از
``IntentEngine.detect_intent`` مستقیم، اول ``conversation_engine.process(...)``
را صدا می‌زند. اگر ``config.CONVERSATION_INTELLIGENCE_ENABLED`` خاموش
باشد، یا این تابع هر خطایی بدهد، یا ``None`` برگرداند، بلافاصله و
بی‌صدا به همان ``IntentEngine.detect_intent`` قدیمی برمی‌گردد -- یعنی
حتی با اتصال، رفتارِ قدیمی همیشه به‌عنوانِ fallback زنده می‌ماند.
"""

from __future__ import annotations

from . import config
from .schemas import (
    ContextSnapshot,
    IntentCandidate,
    MessageRecord,
    ModuleHealth,
    ModuleResult,
    ResponsePlan,
    RoutingDecision,
)

__all__ = [
    "config",
    "ContextSnapshot",
    "IntentCandidate",
    "MessageRecord",
    "ModuleHealth",
    "ModuleResult",
    "ResponsePlan",
    "RoutingDecision",
]
