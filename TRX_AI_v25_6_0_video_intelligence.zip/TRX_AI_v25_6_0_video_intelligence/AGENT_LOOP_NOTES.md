# مکانیزمِ تصمیم‌گیریِ خودمختار (Autonomous Agent Loop) v1

## خواسته

اضافه‌کردنِ یک حلقه‌ی عامل (Agent Loop) که هوش مصنوعی بتواند خودش
ابزارها (وب، بینایی، پایگاه‌دانش، ماشین‌حساب، فایل، ...) را به‌صورتِ
زنجیره‌ای برایِ حل‌کردنِ یک مسئله صدا بزند، بدونِ اینکه کاربر تک‌تکِ
مراحل را دستی فرمان دهد -- به‌شکلی کاملاً حرفه‌ای و ماژولار، با
ماژول‌هایِ تخصصی جدا از هم.

## چرا یک پکیجِ جدا (`trx_ai/agent/`) و نه افزودن به `core.py`؟

مسیریابیِ فعلیِ برنامه (`IntentEngine.detect_intent` → `_execute_route`)
عمداً «یک نیت → یک ابزار → یک پاسخ» است؛ ساده، سریع و قابل‌پیش‌بینی.
حلقه‌ی عامل یک نیازِ کیفتاً متفاوت است (چندین ابزار، چند مرحله، تصمیمِ
پویا دربابِ توقف)، و آوردنِ آن مستقیم داخلِ `TRXEnterpriseAI` باعثِ
همان مشکلی می‌شد که `ARCHITECTURE.md` از قبل درباره‌ی `core.py` هشدار
داده (Application و Presentation/Domain به‌هم قاطی می‌شوند). به‌جایش:

- `trx_ai/agent/` یک پکیجِ کاملاً مستقل و قابلِ‌تستِ جداست.
- `core.py` فقط **یک نقطه‌ی اتصال** به آن دارد (`_handle_agent_task`)،
  دقیقاً به همان سبکِ بقیه‌ی مسیرهایِ ویژه (`شخصیت `، `پروژه جدید `).
- هیچ مسیرِ موجودی حذف/تغییرِ رفتار نداده؛ این قابلیت ۱۰۰٪ افزودنی است.

## معماریِ ماژولار (پنج مسئولیتِ جدا)

```
trx_ai/agent/
├── types.py          dataclass/Enum های مشترک (AgentAction, AgentStep,
│                      AgentTrace, AgentConfig, ToolResult, StopReason)
├── tool_registry.py   AgentTool + ToolRegistry + build_default_registry()
├── planner.py          تصمیمِ «گامِ بعدی چیست» (HeuristicPlanner + قلابِ LLM)
├── guardrails.py        LoopGuard: سقفِ گام/زمان/تکرار/allow-list
├── memory.py             Scratchpad: حافظه‌ی کاریِ کوتاه‌مدتِ یک اجرا
├── reflection.py          StepReflector: کافی‌بودن + سنتزِ پاسخِ نهایی
└── loop.py                AgentLoop: هماهنگ‌کننده‌ی نهایی
```

هر فایل دقیقاً یک نگرانی دارد و به بقیه فقط از طریقِ `types.py` وابسته
است -- افزودنِ یک planner یا guardrail جدید نیازی به تغییرِ بقیه ندارد.

### `tool_registry.py` -- آداپتور، نه بازنویسی

هیچ منطقِ ابزارِ *جدیدی* اینجا نیست. هر `AgentTool` فقط یک لایه‌ی نازکِ
async رویِ موتورهایِ *موجودِ* پروژه است:

| ابزارِ عامل | موتورِ موجودِ استفاده‌شده |
|---|---|
| `web_search` | `WebSearchEngine.get_wikipedia` / `search_duckduckgo` |
| `knowledge_base` | `DatabaseManager.search_knowledge` (sqlite محلی) |
| `weather` | `WeatherEngine.get_weather` |
| `calculator` | `CalculatorEngine.safe_eval` (ast، بدونِ eval خام) |
| `translator` | `TranslatorEngine.get_translation` |
| `vision` | `ImageEngine.describe` / `read_text` (رویِ آخرین عکسِ آپلودشده) |
| `code_intelligence` | `CodeIntelligence.analyze_and_fix` |
| `file_read` | `FileManager.read_file` |
| `add_task` | `TaskManager.add_from_text` |

بنابراین هیچ رفتارِ امنیتی/کیفیِ ابزارها (مثلاً گاردِ `ast` در
ماشین‌حساب یا اعتبارسنجیِ فایل) عوض نشده -- فقط پشتِ یک واسطِ یکسان
گذاشته شده تا `planner`/`loop` بتوانند آن‌ها را زنجیره‌ای صدا بزنند.

### `planner.py` -- هوشِ محلی، با قلابِ آماده برایِ آینده

طبقِ همان فلسفه‌ی «پاسخ‌دهیِ سه‌لایه‌یِ بدونِ کلید» که در `README.md`
هست، `HeuristicPlanner` کاملاً محلی و بدونِ نیاز به هیچ API کار
می‌کند: ابزارها را با امتیازدهیِ کلیدواژه‌ای رتبه‌بندی می‌کند، یکی‌یکی
امتحان می‌کند، و با کمکِ `StepReflector` تشخیص می‌دهد کِی اطلاعاتِ
کافی جمع شده.

`AgentPlanner` (پوسته‌یِ عمومی) یک پارامترِ اختیاریِ
`llm_decide(goal, context) -> dict | None` می‌پذیرد: اگر در آینده یک
LLM واقعی دوباره به پروژه وصل شد (نگاه کنید به `core.GenerationUnavailableError`
که توضیح می‌دهد چرا فعلاً هیچ LLMیی وصل نیست)، کافی است این تابع به
`AgentLoop` پاس داده شود -- planner اول از آن می‌پرسد و فقط در خطا/
پاسخِ نامعتبر به heuristic سقوط می‌کند. یعنی وصل‌کردنِ بعدیِ یک مدل
هیچ‌کدام از فایل‌هایِ دیگرِ این پکیج را نمی‌شکند یا نیاز به تغییر ندارد.

### `guardrails.py` -- ایمنیِ حلقه

سه خطرِ کلاسیکِ هر agent loop صریحاً پوشش داده شده (با تست‌هایِ واحد
در `tests/test_agent_loop.py`):

1. **حلقه‌ی بی‌پایان**: فراخوانیِ عینیِ تکراری (همان ابزار + همان
   آرگومان) بلاک می‌شود.
2. **مصرفِ بی‌رویه**: `AgentConfig.max_steps` و `max_wall_seconds`
   (پیش‌فرض: ۶ گام / ۴۵ ثانیه).
3. **دسترسیِ خارج از مجوز**: `AgentConfig.allowed_tools` (مثلاً برایِ
   محدودکردنِ یک اجرا به فقط ابزارهایِ read-only).

هر نقضِ گاردریل به یک `GuardrailViolation` تبدیل می‌شود که `AgentLoop`
می‌گیرد و حلقه را کنترل‌شده (با بهترین پاسخِ ممکنِ تا آن لحظه) متوقف
می‌کند -- هرگز کرش.

### `memory.py` -- Scratchpad، نه MemoryEngine

عمداً از `MemoryEngine`/`VectorDatabase` موجود (`memory_store.py`)
استفاده نشده: آن حافظه‌ی *بین‌جلسه‌ایِ* کاربر است، این یکی فقط طولِ
عمرِ یک اجرا را دارد. اگر بعداً خواستیم نتیجه‌ی یک اجرایِ عامل در
حافظه‌ی بلندمدت هم ذخیره شود، نقطه‌ی طبیعی‌اش داخلِ
`TRXEnterpriseAI._handle_agent_task` است (که از قبل `_finalize` را صدا
می‌زند و تاریخچه را ثبت می‌کند)، نه داخلِ خودِ `Scratchpad`.

### `reflection.py` -- سوارشدن رویِ `ReflectionEngine` موجود

به‌جایِ معیارِ کیفیتِ جدید، همان `intelligence.ReflectionEngine.check`
(طول/تناقض/همپوشانیِ کلمات) استفاده می‌شود، به‌اضافه‌یِ یک سیگنالِ
مخصوصِ agent (نسبتِ پوشانیِ کلیدواژه‌هایِ هدف با مجموعِ مشاهدات).

## نقطه‌ی اتصال در `core.py`

- پیشوندِ فعال‌سازی: `عامل: <هدف>` (یا معادلِ `/agent <هدف>`)، دقیقاً
  کنارِ بقیه‌ی دستورهایِ پیشوندیِ موجود (`شخصیت `، `پروژه جدید `) در
  `_process_turn`.
- `TRXEnterpriseAI._get_agent_registry()`: رجیستریِ ابزارها را lazy
  می‌سازد (چون به `self.session`ی که فقط پس از `start_loop`/
  `init_for_gui` ساخته می‌شود نیاز دارد).
- `TRXEnterpriseAI._handle_agent_task(goal)`: `AgentLoop` را اجرا
  می‌کند، trace را نمایش می‌دهد (فهرستِ ابزارهایِ استفاده‌شده + دلیلِ
  توقف)، و از همانِ `_finalize` برایِ ثبتِ تاریخچه استفاده می‌کند --
  یعنی اجراهایِ عامل هم در «تاریخچه»/«آمار» معمولیِ برنامه دیده
  می‌شوند.
- `self._last_image_path` (جدید، فقط یک خطِ افزوده در
  `_process_image_turn`): تا ابزارِ `vision` بداند رویِ کدام تصویرِ
  همین جلسه کار کند.

هیچ‌کدام از این‌ها مسیرِ موجودِ متن/عکس/فایل را عوض نکرده -- فقط قبل
از ورود به `IntentEngine.detect_intent`، یک شاخه‌یِ کاملاً جدید و
اختیاری اضافه شده.

## چگونه بدونِ رابطِ کاربری استفاده کنیم (برنامه‌نویسی/تست)

```python
from trx_ai.agent import AgentLoop, AgentConfig, build_default_registry

registry = build_default_registry(ai)  # ai = نمونه‌ی TRXEnterpriseAI
trace = await AgentLoop(registry, AgentConfig(max_steps=5)).run(
    "جمعیتِ فعلیِ ایران رو پیدا کن و بر ۱۰۰۰ تقسیم کن"
)
print(trace.final_answer)
print(trace.format_trace_fa())  # گزارشِ گام‌به‌گام برایِ دیباگ
```

## تست‌ها

`tests/test_agent_loop.py` -- ابزارهایِ ساختگی (stub، بدونِ شبکه) برایِ
تستِ سریع/دیتومینستیکِ:

- `AgentTool.score` / `ToolRegistry.rank` (امتیازدهی/استثناکردنِ
  ابزارهایِ امتحان‌شده)
- `run_safe` (هیچ استثنایی از ابزار تا بیرون نمی‌رود)
- `Scratchpad` (ردیابیِ ابزارهایِ امتحان‌شده، سقفِ طولِ context)
- `LoopGuard` (هر چهار نوعِ گاردریل، جداگانه)
- `AgentLoop.run` سرتاسری: تکمیلِ تک‌ابزاره، زنجیره‌شدنِ چندابزاره،
  توقفِ بودجه، بقایِ حلقه پس از خطایِ یک ابزار، پیامِ خالی، عدمِ
  تطابقِ هیچ ابزار (→ `ASK_USER`)
- `build_default_registry` (فقط بررسیِ ساختار/آداپتورها با یک
  `TRXEnterpriseAI` ساختگیِ حداقلی -- بدونِ شبکه)

اجرا (پس از `pip install -r requirements-dev.txt`):

```bash
pytest tests/test_agent_loop.py -v
```

## محدودیت‌هایِ آگاهانه‌یِ این نسخه (v1)

- `HeuristicPlanner` کاملاً کلیدواژه‌ای است؛ برایِ اهدافِ چندبخشیِ
  پیچیده ممکن است زودتر از موعدِ ایده‌آل «کافی» تشخیص دهد. قلابِ
  `llm_decide` دقیقاً برایِ رفعِ همینِ محدودیت -- وقتی/اگر یک LLM
  دوباره وصل شود -- طراحی شده.
- ابزارهایِ نوشتنی (`add_task`) عمداً محدودند؛ اضافه‌کردنِ ابزارهایِ
  نوشتنیِ بیشتر (مثلاً `add_expense`) باید با دقتِ بیشتری در
  `AgentConfig.allowed_tools` کنترل شود تا عامل بدونِ تأییدِ کاربر
  چیزی حذف/بازنویسی نکند.
- `vision` فقط رویِ «آخرین عکسِ آپلودشده در همین جلسه» کار می‌کند؛
  آپلودِ عکسِ جدید *در میانه‌ی* یک اجرایِ عامل پشتیبانی نمی‌شود (رابطِ
  فعلی synchronous/تک‌نوبتی است).
