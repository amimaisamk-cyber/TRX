# -*- coding: utf-8 -*-
"""
نقطه‌ی ورود اجرای TRX Enterprise AI.

اجرا:
    python main.py

متغیرهای محیطی مفید:
    TRX_AUTO_INSTALL=0   غیرفعال‌کردن نصب خودکار پکیج‌های ضروری
    TRX_LOG_LEVEL=DEBUG  تغییر سطح لاگ (پیش‌فرض: INFO)
    TRX_LOG_DIR=logs     مسیر ذخیره‌ی فایل‌های لاگ
"""

from __future__ import annotations

import asyncio
import os
import sys
import traceback


def _ensure_project_root_on_path() -> None:
    """
    اطمینان از این‌که پوشه‌ی ریشه‌ی پروژه (همان‌جایی که پوشه‌ی trx_ai/
    قرار دارد) در sys.path هست، پیش از وارد کردنِ هر ماژولِ trx_ai.

    چرا لازم است: اکثرِ اجراکننده‌ها (`python main.py` از خطِ فرمان)
    به‌طورِ خودکار پوشه‌ی محتویِ اسکریپت را به sys.path اضافه می‌کنند،
    اما بعضی محیط‌ها این کار را نمی‌کنند — مشخصاً Pydroid3 روی اندروید،
    که فایل را از طریقِ ``exec(open(mainpyfile).read(), __main__.__dict__)``
    در ``iiec_run.py`` اجرا می‌کند، نه با فراخوانیِ معمولیِ اسکریپت. نتیجه
    بدونِ این تابع دقیقاً همین خطاست:

        ModuleNotFoundError: No module named 'trx_ai.dependencies';
        'trx_ai' is not a package

    (پایتون یک namespace-package جزئی به نامِ ``trx_ai`` جایی در
    sys.path پیدا می‌کند، اما پوشه‌ی واقعیِ حاویِ ``trx_ai/__init__.py``
    را نمی‌بیند.) راه‌حل: صریحاً پوشه‌ای که ``main.py`` در آن قرار دارد
    (یا پوشه‌ی کاریِ فعلی، به‌عنوانِ fallback) را در ابتدایِ sys.path
    قرار می‌دهیم — قبل از هر importِ trx_ai.
    """
    candidates = []
    file_path = globals().get("__file__")
    if file_path:
        candidates.append(os.path.dirname(os.path.abspath(file_path)))
    if sys.argv and sys.argv[0]:
        candidates.append(os.path.dirname(os.path.abspath(sys.argv[0])))
    candidates.append(os.getcwd())

    for base in candidates:
        if base and os.path.isdir(os.path.join(base, "trx_ai")) and base not in sys.path:
            sys.path.insert(0, base)
            return


_ensure_project_root_on_path()

from trx_ai.dependencies import ensure_required_packages  # noqa: E402  (باید بعد از بوت‌استرپِ مسیر باشد)

# پکیج‌های ضروری باید پیش از وارد کردن ماژول‌هایی که به آن‌ها وابسته‌اند
# (rich، aiohttp، edge_tts و ...) بررسی/نصب شوند.
ensure_required_packages()

from trx_ai.core import TRXEnterpriseAI  # noqa: E402  (باید بعد از bootstrap باشد)
from trx_ai.logging_config import get_logger  # noqa: E402

logger = get_logger(__name__)


def main() -> None:
    ai_system = TRXEnterpriseAI()
    try:
        asyncio.run(ai_system.start_loop())
    except KeyboardInterrupt:
        print("\n👋 سیستم متوقف شد.")
    except Exception as e:  # noqa: BLE001 - این نقطه‌ی ورود، آخرین خط دفاعی است
        print(f"💥 خطای بحرانی: {type(e).__name__}: {e}")
        logger.exception("خطای بحرانی و پردازش‌نشده در main(): %s", e)
        traceback.print_exc()


if __name__ == "__main__":
    main()
