# v25.5.6 — Pattern Bridge: اتصالِ ConversationPatternEngine به pattern_context

طبقِ توافقِ صریحِ امیر: نسخه عمداً کوچک نگه داشته شد -- **فقط** همین یک
مسیر:

```
ConversationPatternEngine (stateless) → pattern_context → NervousSystemCoordinator
→ UnifiedConversationContext → SHADOW
```

و صریحاً **نه**: Local LLM، نه Final Decision، نه Tool Router.

## Current State
- v25.5.5: `NervousSystemCoordinator` ساخته شد، ولی `pattern_context["long_term_pattern_wired"]`
  همیشه `False` بود -- یک ORPHAN مستندشده.

## Weakness
- بدونِ دادهِ واقعیِ Pattern Engine، `UnifiedConversationContext` نمی‌تواند
  چیزهایی مثلِ «شوخی → فیدبکِ منفی» را حتی در حالتِ SHADOW هم مشاهده کند --
  یعنی وقتی روزی مصرف‌کننده وصل شود، اطلاعاتِ لازم از قبل جمع نشده بوده.

## Upgrade Goal
- خروجیِ *واقعیِ* `ConversationPatternEngine.build_pattern` (زیرمجموعه‌یِ
  stateless -- بدونِ نیاز به DB) در `pattern_context["engine"]` ذخیره شود.
- با آزمایشِ A/B اثبات شود که این داده واقعاً بینِ دو مکالمه‌یِ متفاوت،
  متفاوت است (نه فقط یک اسکلتِ همیشه‌ثابت).

## Approach
1. `trx_ai/nervous_system/pattern_bridge.py` (جدید): `build_pattern_context()`
   -- ``turns`` را یا مستقیم می‌گیرد (نقش‌دار: user/assistant) یا از
   ``recent_messages`` (که طبقِ خودِ `ConversationPatternEngine._recent_context_text`
   همیشه فقط گفته‌هایِ کاربر است) + پیامِ فعلی می‌سازد؛ سپس همان
   `@classmethod build_pattern` واقعی را صدا می‌زند (بدونِ بازنویسیِ
   منطقِ آن). خروجی خلاصه می‌شود (بدونِ بردارهایِ عددیِ خام `emb`/`context_emb`).
2. `coordinator.build_context` یک پارامترِ جدید (`pattern_engine_context`)
   می‌گیرد و آن را در `pattern_context["engine"]` می‌گذارد؛
   `long_term_pattern_wired` حالا `pattern_engine_context is not None` است.
3. `_observe_nervous_system` در `conversation_engine.py` (تنها فایلِ لمس‌شده،
   دقیقاً مثلِ v25.5.5) قبل از ساختنِ context، `pattern_bridge.build_pattern_context`
   را fail-soft صدا می‌زند.
4. **دست‌نخورده:** `core.py`، `intelligence.py`، هر ماژولِ دیگرِ
   `trx_ai/conversation/`، Local LLM، Tool Router. `ConversationPatternEngine`
   خودش هم دست‌نخورد -- فقط از بیرون صدا زده شد.

## Capability Impact
- **بهبود یافت:** Context/Observability -- `UnifiedConversationContext`
  حالا واقعاً یک سیگنالِ الگو/احساس/نیاز/آرک دارد، نه یک جای خالی.
- **بدونِ تغییر:** Intelligence/Reliability/Communication/Final Decision --
  چون هنوز SHADOW است.

## Risk
- ریسکِ اصلی: خرابیِ Pattern Engine (که یک فایلِ بزرگ و پیچیده است) کلِ
  نوبت را بترکاند. رفعِ آن: سه لایهِ fail-soft تودرتو (`pattern_bridge.py`
  خودش try/except دارد؛ فراخوانی‌اش در `_observe_nervous_system` هم
  try/except جداگانه دارد؛ و کلِ `_observe_nervous_system` هم از قبل در
  try/except بزرگ‌ترِ خودش است) -- تستِ `test_pattern_engine_crash_never_breaks_the_turn`
  این را با شبیه‌سازیِ واقعیِ crash تأیید کرد.
- ریسکِ کارایی: `build_pattern` یک تابعِ نسبتاً سنگین است (چند بار
  `_scores`/regex رویِ متن). چون فقط وقتی `TRX_NERVOUS_SYSTEM_ENABLED=1`
  است اجرا می‌شود، در پیش‌فرضِ production هیچ هزینه‌ای اضافه نمی‌شود.

## Preservation
- تنها فایلِ *موجودِ* تغییریافته (نسبت به v25.5.5): `conversation_engine.py`
  (فقط چند خط، داخلِ `_observe_nervous_system`)، `coordinator.py`،
  `context_schema.py`، `influence_audit.py` -- همه در پکیجِ خودِ
  `nervous_system` که خودش جدیدِ v25.5.5 بود.
- `ConversationPatternEngine` (فایلِ ۱۶۰۰+ خطی) حتی یک کاراکتر هم تغییر نکرد.

## Validation
- **این‌بار برخلافِ v25.5.5، توانستیم واقعاً کدِ اصلی را اجرا کنیم:**
  با یک stub محلیِ یک‌بارمصرف برایِ `aiohttp` (فقط برایِ حلِ زنجیره‌یِ
  importِ نامرتبطِ `trx_ai.tools` که از طریقِ `trx_ai.nlu` کشیده می‌شود --
  خودِ pattern_bridge به آن نیازی ندارد) + یک shim سبک برایِ `pytest`
  (چون نصبِ واقعیِ pytest در این sandbox بدونِ شبکه ممکن نبود)، **فایلِ
  واقعیِ `tests/test_nervous_system_v25_5_6.py` را مستقیماً اجرا کردیم:
  ۸ از ۸ تست Pass.** فایلِ v25.5.5 (`test_nervous_system_v25_5_5.py`) هم
  دوباره اجرا شد: ۷ از ۷ تست هنوز Pass -- یعنی v25.5.6 هیچ رگرسیونی در
  v25.5.5 ایجاد نکرد.
- چک‌لیستِ قبولیِ خواسته‌شده -- همه واقعاً اجرا و تأیید شدند (نه فقط ادعا):

  | معیار | نتیجه |
  |---|---|
  | Pattern Engine واقعاً فراخوانی شد | ✓ (`test_pattern_engine_is_really_called_via_real_classmethod` -- با spy رویِ خودِ متدِ واقعی، نه mock) |
  | pattern_context تولید شد | ✓ |
  | Coordinator آن را دریافت کرد | ✓ |
  | UnifiedContext آن را نگه داشت | ✓ |
  | A/B دو context متفاوت ساخت | ✓ (signature/topics متفاوت -- جزئیات در `audit/behavioral_report.md`) |
  | خطای Pattern باعث crash نشد | ✓ (crash شبیه‌سازی‌شده، `process()` هنوز جواب داد) |
  | Final Decision تغییر نکرد | ✓ (خروجیِ سه‌تاییِ `process()` با/بدونِ فلگ کاملاً یکسان) |

- **صادقانه:** `sentiment_direction` بینِ سناریویِ A/B فرقی نکرد (چون
  «بی‌مزه» در فرهنگِ لغتِ Engine نیست) -- تفاوت از طریقِ `topics`/`signature`
  اثبات شد، نه هر فیلدی. جزئیات در `audit/behavioral_report.md`.
- stub های `aiohttp`/`pytest` **فقط برایِ اعتبارسنجیِ محلیِ همین نشست**
  بودند و در zipِ تحویلی نیستند -- امیر همچنان باید `pytest` را در محیطِ
  خودش (که این وابستگی‌ها را واقعاً نصب دارد) اجرا کند تا خروجیِ رسمی را
  تأیید کند؛ اما این‌بار سطحِ اطمینانِ ما بالاتر است چون خودِ منطق را (نه
  فقط اسکلتش را) با کدِ واقعی اجرا کردیم.

## Result
- ✅ گپِ مستندشده در v25.5.5 (`long_term_pattern_wired: False`) جزئاً و
  صادقانه بسته شد: زیرمجموعه‌یِ stateless وصل شد و با آزمایشِ A/B اثبات شد.
- ✅ صفر تغییرِ رفتاری در مسیرِ تصمیم‌گیری (SHADOW هنوز برقرار است).
- ✅ صفر وابستگیِ خارجیِ جدید.
- ⚠️ بخشِ DB-backed (`mood_report`, تاریخچه‌یِ چندنشستی) هنوز باز است --
  عمداً، طبقِ توافق برایِ کوچک‌نگه‌داشتنِ این نسخه.
- ⚠️ معیارِ نهاییِ خودِ سندِ v25.5.5 («پاسخ عوض می‌شود؟») هنوز **نه** است --
  دقیقاً طبقِ نقشه‌یِ امیر، آزمایشِ C (حذفِ عمدیِ context و مقایسه‌یِ پاسخ)
  عمداً برایِ نسخه‌یِ بعدی گذاشته شد.

---

## پیشنهاد برایِ v25.5.7
طبقِ نقشه‌یِ خودِ امیر: اولین آزمایشِ واقعیِ «آیا سیستمِ عصبی رفتارِ TRX را
تغییر می‌دهد؟» -- یعنی شروعِ PHASE 3 (اتصالِ Local LLM به‌عنوانِ ADVISORY،
نه CONTROLLED) با همان معیارِ آزمایشیِ C که امیر پیشنهاد داد: یک ورودیِ
یکسان، یک‌بار با `UnifiedConversationContext` واقعی و یک‌بار با
`pattern_context=None`، و مقایسه‌یِ پاسخِ نهایی.
