# Context Core Upgrade (v25.4.0)

این سند طبقِ الگویِ «Upgrade Assessment» (بخشِ ۲۰ سندِ کاربر:
`TRX_AI — UPGRADE PHILOSOPHY & CORE DEVELOPMENT PROTOCOL`) نوشته شده.

## Current State

`trx_ai/agent/cognition/` (Cognition Core Upgrade، از `v25.3.0`) از
قبل معماریِ درستی داشت: `Understanding -> Context -> Reasoning ->
Planning -> Execute -> Reflect -> Response`. اما بررسیِ دقیق نشان داد
لایه‌ی **Context** فقط در نام وجود داشت:

- `CognitionContext.long_term_hint` همیشه `""` بود.
- `ReasoningEngine.assess(understanding, context)` پارامترِ `context`
  را می‌گرفت اما **هیچ‌جایِ بدنه‌ی تابع خوانده نمی‌شد**.
- تنها فراخوانِ واقعیِ `CognitionCore` در برنامه (`AgentBridge.
  handle_task`, مسیرِ «عامل:») هیچ‌وقت `topic`/`turn_count`/
  `previous_failures` را نمی‌داد و `ai.memory.resolve_pronoun` را
  روی هدف صدا نمی‌زد -- برخلافِ مسیرِ اصلیِ چت (`tool_router.py`)
  که این کار را از قبل می‌کند.

## Weakness

طبقِ اصلِ کاربر («Context ≠ Memory»، بخشِ ۱۲) و اصلِ طلایی («واکنش به
Intent + Context + Goal، نه فقط کلمات»، بخشِ ۱۴) -- این‌ها *دقیقاً*
همان قابلیتی بودند که سند می‌خواست، ولی در عمل رشته‌ی داده هرگز از
حافظه‌ی واقعیِ برنامه به Reasoning نمی‌رسید. حلقه‌ی عامل هر بار «کور»
اجرا می‌شد: بدونِ دانستنِ موضوعِ فعال، بدونِ شمارشِ شکست‌هایِ اخیر،
بدونِ حلِ ضمیر. این دقیقاً همان الگویی است که کاربر در بخشِ ۲۱ سند
هشدار داده: «اگر فقط ساختار ظاهری عوض شد ولی Behavior واقعاً بهتر
نشده، Upgrade محسوب نمی‌شود» -- اینجا برعکس بود: ساختار (پارامترها)
از قبل درست بود، اما داده‌ی واقعی هیچ‌وقت از آن‌ها عبور نمی‌کرد.

## Upgrade Goal

بدونِ اضافه‌کردنِ هیچ ماژول/وابستگیِ تازه، دادهٔ *واقعاً موجود* در
`ai.memory`/`ai.user_state_memory` را به لایه‌هایِ Context/Understanding/
Reasoningِ **همان مسیرِ تولیدیِ فعلی** (نه یک مسیرِ تازه) وصل کن.

## Approach

1. `ContextEngine.build` را best-effort به سه متدِ از-قبل-موجودِ
   `MemoryEngine` (`get_context`, `get_relevant_memory`, `current_topic`)
   وصل کن.
2. `AgentBridge.handle_task` را به همان الگویِ `tool_router.py`
   (`resolve_pronoun`, `recent_failures()`) وصل کن.
3. `ReasoningEngine.assess` را وادار کن واقعاً `context` را بخواند --
   فقط در سطحِ rationale (غنی‌سازیِ متن)، **نه** تغییرِ شاخه‌هایِ
   تصمیم‌گیری، تا ریسکِ رفتاریِ صفر بماند.

## Capability Impact

- **Context**: از «همیشه خالی» به «واقعاً از حافظه‌ی کوتاه/بلندمدت
  پُر می‌شود».
- **Understanding**: `conversation_phase`/`previous_failures` در
  مسیرِ عامل حالا همان چیزی است که واقعاً اتفاق افتاده، نه همیشه صفر.
- **Communication** (بخشِ ۱۰/۱۱ سند): حلِ ضمیر در مسیرِ عامل هم فعال
  شد -- «این رو بهترش کن»‌‌های بعدِ «عامل:» حالا به Entityِ درست وصل
  می‌شوند.
- **Reliability**: هیچ منطقِ تصمیم‌گیریِ موجود تغییر نکرد؛ فقط داده‌یِ
  ورودیِ آن دقیق‌تر شد.

## Risk

- تمامِ افزودنی‌ها در `try/except` بی‌صدا هستند (فلسفه‌یِ همان فایل)؛
  نبودِ `ai`/`memory` هیچ استثنایی throw نمی‌کند.
- تغییرِ `reasoning.py` عمداً فقط rationale را دست می‌زند؛ هیچ شاخه‌ی
  `needs_tool`/`allow_web`/`preferred_tool` تغییر نکرد.
- ریسکِ باقی‌مانده: `AgentBridge.handle_task` تست‌پذیریِ مستقیم ندارد
  (چون به یک `ai` کاملِ تزریق‌شده با کنسولِ Rich نیاز دارد) -- تغییرِ
  آن با تست‌هایِ واحدِ مجزا (روی `ContextEngine`/`ReasoningEngine`)
  پوشش داده شد، نه یک تستِ سرتاسریِ خودِ بریج.

## Validation

- همه‌یِ ۱۴ تستِ قبلیِ `tests/test_cognition_core.py` بدونِ تغییر پاس
  شدند (بدونِ‌ pytest، با فراخوانیِ مستقیمِ توابع -- چون `pytest`/
  `aiohttp` در محیطِ این نشست بدونِ شبکه نصب‌شدنی نبودند).
- ۳ تستِ تازه اضافه شد که دقیقاً همین دو نقص را قفل می‌کند:
  `test_context_engine_pulls_long_term_hint_from_real_memory`,
  `test_context_engine_without_ai_stays_backward_compatible`,
  `test_reasoning_rationale_now_reflects_real_context`.
- کامپایلِ همه‌یِ فایل‌هایِ تغییریافته (`py_compile`) بررسی شد.
- **باقی‌مانده:** اجرایِ کاملِ `pytest` روی کل پروژه (`test_agent_loop.py`
  و مشابه که به fixtureهایِ pytest نیاز دارند) در این نشست ممکن نبود؛
  در محیطی با `requirements-dev.txt` نصب‌شده باید تأیید شود.

## Result

`long_term_hint` دیگر همیشه خالی نیست؛ `ReasoningEngine.assess` دیگر
پارامترِ مُرده ندارد؛ مسیرِ «عامل:» حالا همان کیفیتِ Context-awareness
را دارد که مسیرِ اصلیِ چت از قبل داشت. هیچ قابلیتِ تازه‌ای اضافه نشد --
دقیقاً طبقِ اصلِ سند («وقتی بینِ افزودنِ Feature و تقویتِ بخشِ بنیادی
مردد بودی، اگر بخشِ بنیادی ضعیف است، B را انتخاب کن»، بخشِ ۲۳).
